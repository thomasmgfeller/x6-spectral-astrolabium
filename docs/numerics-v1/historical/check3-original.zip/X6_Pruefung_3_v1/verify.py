#!/usr/bin/env python3
"""Independent matrix reconstruction and LAPACK reference. Exits 1 on X6 gate failure."""
from pathlib import Path
from fractions import Fraction
import copy, hashlib, json, math, platform, sys
import numpy as np
import scipy
from scipy.linalg import eigh

ROOT=Path(__file__).resolve().parent

def reference_graph(case):
    names=[];edges=[]
    for raw in case['input'].splitlines():
        p=raw.split('#')[0].split()
        if not p: continue
        for name in p[:1] if len(p)==1 else p[:2]:
            if name not in names:names.append(name)
        if len(p)==3:edges.append((p[0],p[1],Fraction(p[2])))
    n=len(names);idx={name:i for i,name in enumerate(names)}
    A=[[Fraction(0) for _ in range(n)] for _ in range(n)]
    parent=list(range(n))
    def find(i):
        while parent[i]!=i:i=parent[i]
        return i
    for a,b,w in edges:
        i,j=idx[a],idx[b];A[i][j]+=w;A[j][i]+=w;parent[find(i)]=find(j)
    L=[[sum(A[i]) if i==j else -A[i][j] for j in range(n)] for i in range(n)]
    return names,A,L,len({find(i) for i in range(n)})

def evaluate(case,run,contract):
    errors=[]
    def gate(name,condition):
        if not condition:errors.append(name)
    names,Aq,Lq,components=reference_graph(case);n=len(names)
    gate('input',run.get('input')==case['input'])
    gate('nodes',run.get('nodes')==names)
    for key,expected in [('A',Aq),('L',Lq)]:
        try:actual=[[Fraction(x) for x in row] for row in run[key]]
        except (ValueError,TypeError,KeyError,OverflowError):actual=None
        gate('matrix_'+key,actual==expected)
    gate('observation_parity',run.get('observation_parity') is True)
    gate('convergence',run['analysis']['numerical']['converged'] is True)
    gate('exact_nullity',run['analysis']['exactNullity']==components)
    eig=run.get('eigenpairs',[])
    try:
        values=np.array([e['value'] for e in eig],dtype=float)
        V=np.array([e['vector'] for e in eig],dtype=float).T
    except (ValueError,TypeError,KeyError):
        return dict(id=case['id'],status='FAIL',errors=errors+['vector_shape'])
    gate('vector_shape',V.shape==(n,n) and values.shape==(n,))
    if 'vector_shape' in errors:return dict(id=case['id'],status='FAIL',errors=errors)
    gate('finite',bool(np.all(np.isfinite(V)) and np.all(np.isfinite(values))))
    if 'finite' in errors:return dict(id=case['id'],status='FAIL',errors=errors)
    public=run['analysis']['numerical']['eig']
    gate('public_output_parity',len(public)==n and all(
        e['value']==p['value'] and e['residual']==p['residual'] for e,p in zip(eig,public)))
    norms=np.linalg.norm(V,axis=0)
    gate('nonzero_vectors',bool(np.all(norms>0)))
    if 'nonzero_vectors' in errors:return dict(id=case['id'],status='FAIL',errors=errors)
    gate('sorted_spectrum',bool(np.all(values[:-1]<=values[1:])))
    L=np.array(Lq,dtype=float);s=float(np.linalg.norm(L,ord=np.inf))
    denom=s if s else 1.0;Ln=L/denom;vn=values/denom
    w,U=eigh(Ln,driver='evd',check_finite=True)
    residual_cols=np.linalg.norm(Ln@V-V*vn,axis=0)
    residual=float(np.max(residual_cols/norms))
    eigerr=float(np.max(np.abs(vn-w)))
    orth=float(np.linalg.norm(V.T@V-np.eye(n),'fro'))
    lf=float(np.linalg.norm(Ln,'fro'))
    recon=float(np.linalg.norm(Ln-(V*vn)@V.T,'fro')/(lf if lf else 1.0))
    gate('residual',residual<=contract['residual_scaled_limit'] if s else residual==0)
    gate('eigenvalues',eigerr<=contract['eigenvalue_scaled_limit'] if s else eigerr==0)
    gate('orthogonality',orth<=contract['orthogonality_frobenius_limit'])
    gate('reconstruction',recon<=contract['reconstruction_scaled_limit'] if s else recon==0)
    reported=np.array([e['residual'] for e in eig])/denom
    report_diff=float(np.max(np.abs(reported-residual_cols)))
    gate('reported_residual_consistency',report_diff<=1e-14)
    boundaries=[0]+[i for i in range(1,n) if w[i]-w[i-1]>contract['cluster_relative_gap']]+[n]
    projectors=[]
    for a,b in zip(boundaries,boundaries[1:]):
        P=V[:,a:b]@V[:,a:b].T;Pref=U[:,a:b]@U[:,a:b].T
        projectors.append(float(np.linalg.norm(P-Pref,'fro')))
    proj=max(projectors)
    gate('subspace_projectors',proj<=contract['subspace_projector_frobenius_limit'])
    positive_reference=w[components:] if components<n else []
    near_resolution=bool(len(positive_reference) and min(positive_reference)<=contract['eigenvalue_scaled_limit'])
    return dict(id=case['id'],family=case['family'],n=n,status='PASS' if not errors else 'FAIL',errors=errors,
        scale_inf=s,eigenvalue_scaled_error=eigerr,residual_scaled=residual,
        orthogonality_frobenius=orth,reconstruction_scaled=recon,
        subspace_projector_frobenius=proj,cluster_sizes=[b-a for a,b in zip(boundaries,boundaries[1:])],
        reported_residual_difference_scaled=report_diff,exact_nullity=components,
        positive_gap_below_test_resolution=near_resolution,
        reference_residual_scaled=float(np.linalg.norm(Ln@U-U*w,'fro')),
        eigenvalues_x6=values.tolist(),eigenvalues_reference=(w*denom).tolist())

def envelope_errors(data,contract):
    errors=[]
    if data['source']['commit']!=contract['commit']:errors.append('commit')
    if data['source']['app_sha256']!=contract['app_sha256']:errors.append('source_hash')
    if data['source']['contract_sha256']!=hashlib.sha256((ROOT/'contract.json').read_bytes()).hexdigest():errors.append('contract_hash')
    if [r['id'] for r in data['runs']]!=[c['id'] for c in contract['cases']]:errors.append('case_set')
    return errors

def controls(data,contract):
    base=data['runs'][0];case=contract['cases'][0];out=[]
    def neg(label,mutate,expected):
        r=copy.deepcopy(base);mutate(r);errors=evaluate(case,r,contract)['errors']
        out.append(dict(id=label,status='PASS' if expected in errors else 'FAIL',expected=expected,detected=errors))
    def scalar(r):r['eigenpairs'][0]['vector']=[2*x for x in r['eigenpairs'][0]['vector']]
    def duplicate(r):r['eigenpairs'][1]['vector']=r['eigenpairs'][0]['vector'][:]
    def swap(r):
        r['eigenpairs'][0]['vector'],r['eigenpairs'][-1]['vector']=r['eigenpairs'][-1]['vector'],r['eigenpairs'][0]['vector']
    def wrong_eig(r):
        r['eigenpairs'][0]['value']+=0.1;r['analysis']['numerical']['eig'][0]['value']+=0.1
    neg('wrong_matrix',lambda r:r['L'][0].__setitem__(0,2),'matrix_L')
    neg('wrong_pairing',swap,'residual')
    neg('duplicated_vector',duplicate,'orthogonality')
    neg('zero_vector',lambda r:r['eigenpairs'][0].__setitem__('vector',[0]*4),'nonzero_vectors')
    neg('unnormalized_vector',scalar,'orthogonality')
    neg('missing_vector',lambda r:r['eigenpairs'][0].pop('vector'),'vector_shape')
    neg('nonfinite_vector',lambda r:r['eigenpairs'][0]['vector'].__setitem__(0,float('nan')),'finite')
    neg('wrong_eigenvalue',wrong_eig,'eigenvalues')
    neg('false_convergence',lambda r:r['analysis']['numerical'].__setitem__('converged',False),'convergence')
    for label,expected,mutate in [
        ('missing_case','case_set',lambda d:d['runs'].pop()),
        ('wrong_commit','commit',lambda d:d['source'].__setitem__('commit','0'*40))]:
        d=copy.deepcopy(data);mutate(d);errors=envelope_errors(d,contract)
        out.append(dict(id=label,status='PASS' if expected in errors else 'FAIL',expected=expected,detected=errors))
    positives=[]
    r=copy.deepcopy(base);r['eigenpairs'][0]['vector']=[-x for x in r['eigenpairs'][0]['vector']]
    positives.append(dict(id='eigenvector_sign_flip',status=evaluate(case,r,contract)['status']))
    index=next(i for i,c in enumerate(contract['cases']) if c['id']=='complete8')
    r=copy.deepcopy(data['runs'][index]);a=np.array(r['eigenpairs'][1]['vector']);b=np.array(r['eigenpairs'][2]['vector'])
    r['eigenpairs'][1]['vector']=((a+b)/math.sqrt(2)).tolist()
    r['eigenpairs'][2]['vector']=((a-b)/math.sqrt(2)).tolist()
    positives.append(dict(id='degenerate_eigenspace_basis_rotation',status=evaluate(contract['cases'][index],r,contract)['status']))
    return out,positives

def main():
    contract=json.loads((ROOT/'contract.json').read_text());data=json.loads((ROOT/'x6_actual_output.json').read_text())
    env=envelope_errors(data,contract)
    if env:raise RuntimeError('Envelope: '+repr(env))
    results=[evaluate(c,r,contract) for c,r in zip(contract['cases'],data['runs'])]
    negatives,positives=controls(data,contract)
    failed=[r['id'] for r in results if r['status']!='PASS']
    control_ok=all(r['status']=='PASS' for r in negatives+positives)
    report=dict(schema='x6-eigenvectors-check3-results/1',commit=contract['commit'],
        execution='LOCAL_EXECUTED; NOT A SAGE RUN',python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        reference='SciPy LAPACK eigh evd on L/||L||inf; exact Fraction matrix reconstruction',
        source=data['source'],contract=contract,results=results,negative_controls=negatives,positive_controls=positives,
        summary=dict(total=len(results),passed=len(results)-len(failed),failed=failed,controls_passed=control_ok,
            status='PASS' if not failed and control_ok else 'FAIL'))
    (ROOT/'local_results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    for r in results:print(f"{r['id']}: {r['status']}; eig={r['eigenvalue_scaled_error']:.3e}; residual={r['residual_scaled']:.3e}; orth={r['orthogonality_frobenius']:.3e}; errors={r['errors']}")
    print(f"NEGATIVE CONTROLS: {sum(x['status']=='PASS' for x in negatives)}/{len(negatives)}")
    print(f"POSITIVE CONTROLS: {sum(x['status']=='PASS' for x in positives)}/{len(positives)}")
    print('X6 ROBUSTNESS:',report['summary'])
    return int(bool(failed) or not control_ok)

if __name__=='__main__':sys.exit(main())
