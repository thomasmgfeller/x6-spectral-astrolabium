#!/usr/bin/env python3
"""Freeze cases and gates before the first X6 execution. Standard library only."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import json, hashlib, random, datetime

ROOT = Path(__file__).resolve().parent
COMMIT = '7257e51a8df93ff1722d1116103143cc6c827ef4'

def literal(w):
    w = Fraction(w)
    with localcontext() as c:
        c.prec = 100
        return format(Decimal(w.numerator) / Decimal(w.denominator), 'f')

def case(name, n, edges, family, **extra):
    text = '\n'.join([f'v{i}' for i in range(n)] +
                     [f'v{i} v{j} {literal(w)}' for i,j,w in edges])
    return dict(id=name, n=n, input=text, family=family, **extra)

def path(n, w=1):
    return [(i,i+1,w) for i in range(n-1)]

def complete(n, offset=0):
    return [(i+offset,j+offset,1) for i in range(n) for j in range(i+1,n)]

cases = [
    case('path4',4,path(4),'prior'),
    case('triangle',3,complete(3),'prior'),
    case('weighted2',2,path(2,Fraction(1,8)),'prior'),
    case('disconnected',4,[(0,1,1),(2,3,1)],'prior'),
    case('singleton',1,[],'zero'),
    case('isolated4',4,[],'zero'),
    case('complete8',8,complete(8),'repeated'),
    case('cycle8',8,path(8)+[(0,7,1)],'repeated'),
    case('three_triangles',9,complete(3)+complete(3,3)+complete(3,6),'repeated'),
    case('near_triangle',3,[(0,1,1),(1,2,1),(0,2,1+Fraction(1,2**30))],'clustered'),
    case('weak_bridge_30',8,complete(4)+complete(4,4)+[(3,4,Fraction(1,2**30))],'clustered'),
    case('weak_bridge_50',8,complete(4)+complete(4,4)+[(3,4,Fraction(1,2**50))],'clustered'),
]
for exponent in [-50,-40,0,40]:
    scale = Fraction(2)**exponent
    cases.append(case('scaled_pair_'+str(exponent),2,path(2,scale),'scaling', exponent=exponent))
for exponent in [-50,0,40]:
    cases.append(case('scaled_path16_'+str(exponent),16,path(16,Fraction(2)**exponent),'scaling', exponent=exponent))
for n in [8,16,24,32]:
    for seed in [104729,130363]:
        rng=random.Random(seed+n)
        edges=[]
        for i in range(n):
            for j in range(i+1,n):
                if j==i+1 or rng.random()<0.22:
                    edges.append((i,j,Fraction(rng.randint(1,32),8)))
        cases.append(case(f'random_n{n}_seed{seed}',n,edges,'seeded_dyadic',seed=seed))

contract = dict(schema='x6-eigenvectors-check3-contract/1', commit=COMMIT,
    frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    app_sha256=hashlib.sha256((ROOT/'source/app/index.html').read_bytes()).hexdigest(),
    eigenvalue_scaled_limit=1e-12, residual_scaled_limit=1e-12,
    orthogonality_frobenius_limit=1e-12, reconstruction_scaled_limit=1e-12,
    subspace_projector_frobenius_limit=1e-7, cluster_relative_gap=1e-7,
    definitions={
        'scale':'s=||L||_infinity; no floor of 1; exactly zero matrices use absolute zero tests',
        'eigenvalue_scaled_error':'max_j |lambda_X6_j-lambda_ref_j|/s',
        'residual_scaled':'max_j ||L*v_j-lambda_j*v_j||_2/(s*||v_j||_2)',
        'orthogonality':'||V^T*V-I||_F',
        'reconstruction_scaled':'||L-V*diag(lambda)*V^T||_F/||L||_F',
        'cluster':'join adjacent reference eigenvalues if gap <= 1e-7*s; compare projectors, not individual vectors',
        'reference':'scipy.linalg.eigh driver=evd, binary64 numerical reference; exact algebraic spectra for selected Sage cases',
        'scope':'Finite deterministic corpus; no browser, physical evidence, interval certificate or general correctness proof.'},
    cases=cases)
out=ROOT/'contract.json'
if out.exists():
    raise SystemExit('Refusing to overwrite an existing frozen contract')
out.write_text(json.dumps(contract,indent=2)+'\n')
print(f'FROZEN: {len(cases)} cases; {hashlib.sha256(out.read_bytes()).hexdigest()}')
