#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction
import json,hashlib
ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'x6_actual_output.json').read_text())
c=json.loads((ROOT/'contract.json').read_text())
q=lambda x:str(Fraction(x))
cases=[]
for name in ['scaled_pair_0','scaled_pair_-50']:
    r=next(r for r in d['runs'] if r['id']==name)
    cases.append(dict(id=name,input=r['input'],L=[[q(x) for x in row] for row in r['L']],
        eigenvalues=[q(e['value']) for e in r['eigenpairs']],
        vectors=[list(map(q,e['vector'])) for e in r['eigenpairs']],
        converged=r['analysis']['numerical']['converged'],rotations=r['analysis']['numerical']['sweeps'],
        observation_parity=r['observation_parity']))
payload=dict(commit=d['source']['commit'],kernel_sha256=d['source']['kernel_sha256'],cases=cases)
blob=json.dumps(payload,separators=(',',':'))
header='# X6 Check 3: exact confirmation of the minimal scaling counterexample.\n'
header+='import json, hashlib\nfrom fractions import Fraction\nfrom sage.all import *\nfrom sage.env import SAGE_VERSION\n'
header+='DATA_TEXT = '+repr(blob)+'\n'
header+='assert hashlib.sha256(DATA_TEXT.encode()).hexdigest() == '+repr(hashlib.sha256(blob.encode()).hexdigest())+'\n'
header+='data=json.loads(DATA_TEXT)\n'
body='''assert data['commit']=='7257e51a8df93ff1722d1116103143cc6c827ef4'
assert data['kernel_sha256']=='a5adaeb576e6e0417023cc61ac4e431b782362843c2110f121c82d1f8227b46e'
assert [r['id'] for r in data['cases']]==['scaled_pair_0','scaled_pair_-50']
tol=QQ(1)/10**12
print('Sage-Version:',SAGE_VERSION)
print('X6-Commit:',data['commit'])
print('Quelle: echte Node.js-Ausgaben; Eigenvektoren nur beobachtend exportiert.')
statuses=[]
for r in data['cases']:
    w=QQ(str(Fraction(r['input'].splitlines()[-1].split()[2])))
    L=matrix(QQ,[[w,-w],[-w,w]])
    assert matrix(QQ,r['L'])==L
    lam=list(map(QQ,r['eigenvalues']))
    V=matrix(QQ,[[QQ(x) for x in v] for v in r['vectors']]).transpose()
    ref=sorted(L.eigenvalues())
    assert ref==[0,2*w]
    s=2*w
    rel_error=max(abs(lam[j]-ref[j])/s for j in range(2))
    residuals_squared=[]
    for j in range(2):
        v=V.column(j)
        rv=L*v-lam[j]*v
        residuals_squared.append(rv.dot_product(rv)/(s*s*v.dot_product(v)))
    orth=V.transpose()*V-identity_matrix(QQ,2)
    orth_squared=sum(x*x for x in orth.list())
    good=(rel_error<=tol and max(residuals_squared)<=tol*tol and orth_squared<=tol*tol)
    status='PASS' if good else 'FAIL'
    statuses.append(status)
    print(r['id']+': X6 '+status)
    print('  Soll-Eigenwerte:',ref)
    print('  X6-Eigenwerte:',lam)
    print('  Skalierter Eigenwertfehler:',rel_error)
    print('  Skalierte Residuenquadrate:',residuals_squared)
    print('  X6 converged:',r['converged'],'; Rotationen:',r['rotations'])
    assert r['observation_parity'] is True
    if r['id']=='scaled_pair_-50':
        assert w==QQ(1)/2**50
        assert lam==[w,w]
        assert V==identity_matrix(QQ,2)
        assert rel_error==QQ(1)/2
        assert residuals_squared==[QQ(1)/4,QQ(1)/4]
        assert r['converged'] is True and r['rotations']==0
assert statuses==['PASS','FAIL']
print('GEGENBEISPIEL: EXAKT BESTAETIGT')
print('X6-ROBUSTHEIT: FAIL fuer kleine Gewichtsskalen; kein allgemeines PASS.')
print('Geltung: zwei eingebettete X6-Ausgaben; kein X6-Browserlauf.')
'''
out=ROOT/'X6_SageMathCell_Pruefung_3.sage'
out.write_text(header+body)
print(out.read_text())
