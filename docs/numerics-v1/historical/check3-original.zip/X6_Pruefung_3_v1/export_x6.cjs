'use strict';
// Original public output plus a separately executed, observation-only vector export.
const fs=require('node:fs'), path=require('node:path'), vm=require('node:vm'), crypto=require('node:crypto');
const root=__dirname, hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const cb=fs.readFileSync(path.join(root,'contract.json')), contract=JSON.parse(cb);
const app=fs.readFileSync(path.join(root,'source/app/index.html'));
if(hash(app)!==contract.app_sha256) throw Error('Pinned source hash mismatch');
const tag=app.toString('utf8').match(/<iframe\b[^>]*\bid="spectrumFrame"[^>]*>/);
if(!tag) throw Error('spectrumFrame missing');
const attr=tag[0].match(/\bsrcdoc="([^"]*)"/);
const named={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};
const src=attr[1].replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,k)=>k[0]==='#'?String.fromCodePoint(k[1].toLowerCase()==='x'?parseInt(k.slice(2),16):parseInt(k.slice(1),10)):named[k.toLowerCase()]);
const start=src.indexOf('function parse(s)'), end=src.indexOf('function show(o)',start);
if(start<0||end<=start) throw Error('Extraction boundary missing');
const original=src.slice(start,end);
const needle='return {value:lambda,residual:res}';
if(original.split(needle).length!==2) throw Error('Vector capture must replace exactly one return expression');
const observed=original.replace(needle,'return {value:lambda,residual:res,vector:v}');
fs.writeFileSync(path.join(root,'original_kernel.js'),original);
fs.writeFileSync(path.join(root,'observed_kernel.js'),observed);
function ctx(source){const c=vm.createContext({});vm.runInContext(source+'\nglobalThis.api={parse,analyze};',c,{timeout:1000});return c;}
const c0=ctx(original),c1=ctx(observed);
function run(c,input){c.input=input;return JSON.parse(JSON.stringify(vm.runInContext('({graph:api.parse(input),analysis:api.analyze(input)})',c,{timeout:20000})));}
const runs=contract.cases.map(c=>{
 const a=run(c0,c.input),b=run(c1,c.input);
 const stripped=JSON.parse(JSON.stringify(b));
 for(const e of stripped.analysis.numerical.eig) delete e.vector;
 delete stripped.analysis.timestamp;
 const aa=JSON.parse(JSON.stringify(a));delete aa.analysis.timestamp;
 if(JSON.stringify(aa)!==JSON.stringify(stripped))throw Error(c.id+': observation changed output');
 return {id:c.id,input:c.input,nodes:a.graph.nodes,A:a.graph.A,L:a.graph.L,
  analysis:a.analysis,eigenpairs:b.analysis.numerical.eig,observation_parity:true};
});
const report={schema:'x6-eigenvectors-check3-export/1',source:{commit:contract.commit,
 app_sha256:hash(app),kernel_sha256:hash(original),observed_kernel_sha256:hash(observed),
 contract_sha256:hash(cb),exporter_sha256:hash(fs.readFileSync(__filename)),node:process.version,
 execution:'Node.js VM; unchanged original kernel plus observation-only return-field augmentation; no DOM/browser',
 observation_patch:{before:needle,after:'return {value:lambda,residual:res,vector:v}',changes:1}},runs};
process.stdout.write(JSON.stringify(report,(_,v)=>{if(typeof v==='number'&&!Number.isFinite(v))throw Error('Nonfinite number');return v;},2)+'\n');
