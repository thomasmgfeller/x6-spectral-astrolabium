X6 / SageMathCell Gegenpruefung 2 — v1.0

Zweck
Vier tatsaechliche Ausgaben des unveraenderten X6-Spektralkerns gegen
separat definierte exakte Graphreferenzen pruefen.

Browserdurchlauf
1. https://sagecell.sagemath.org/ oeffnen.
2. Sprache Sage waehlen.
3. Den gesamten Inhalt von X6_SageMathCell_Gegenpruefung_2.sage einfuegen.
4. Evaluate anklicken und die vollstaendige Ausgabe aufbewahren.
Das Skript braucht keine weiteren Dateien und keinen Internetzugriff im Kernel.
Die echte X6-Ausgabe ist bereits eingebettet; nichts muss manuell ergaenzt werden.

Erwartetes, noch NICHT durch einen Sage-Lauf bestaetigtes Endergebnis
GESAMT: PASS — 4/4 X6-Faelle und 6/6 Negativkontrollen.
Bei einem Fehler bricht das Skript mit FAIL ab. Fehlende Faelle werden nicht
uebersprungen. Die sechs absichtlich falschen Kopien muessen jeweils aus dem
passenden Grund abgelehnt werden.

Quelle und Ausfuehrung
Repository: https://github.com/thomasmgfeller/x6-spectral-astrolabium
Commit: 7257e51a8df93ff1722d1116103143cc6c827ef4
Datei: app/index.html, eingebettetes iframe spectrumFrame.
Der Block von function parse(s) bis vor function show(o) wurde ohne Aenderung
aus der einmal HTML-dekodierten srcdoc-Zeichenkette entnommen und mit Node.js
v24.19.0 in einer VM ausgefuehrt. Der Block enthaelt Parser, Komponentenlogik,
Jacobi-Verfahren und analyze. Es wurde kein eigener X6-Eigenwertsolver eingesetzt.
Die lokale Quelldatei wurde byteweise mit git show COMMIT:app/index.html verglichen.
Die interne analyze-Versionszeichenkette lautet historisch X6-2.4; verbindlich
fuer diesen Nachweis sind der Commit und die SHA-256-Werte, nicht diese Anzeige.
Dies ist ein Kerntest ohne DOM und kein Test der Browseroberflaeche.

Feste Kriterien (contract.json wurde vor dem Export angelegt)
- Matrizen: exakte Gleichheit bei identischer Knotenreihenfolge.
- Polynome: Sage berechnet det(xI-M) aus den tatsaechlichen X6-Matrizen und
  vergleicht mit separat angegebenen Sollpolynomen fuer A und L.
- Spektrum: alle Eigenwerte von L einschliesslich Vielfachheiten, sortiert.
- Eigenwertfehler <= 1e-12 + 1e-12*abs(exakter Referenzwert).
- Jacobi muss Konvergenz melden.
- Gemeldete Residuen <= 1e-12*max(1, ||L||_infinity); dies ist nur ein
  diagnostisches Kriterium, keine unabhaengige Eigenvektorpruefung.
- Exakte Nullitaet und Spur muessen mit X6 uebereinstimmen.

Zahlentransport
Alle vier Beispiele verwenden ganzzahlige oder dyadische Gewichte (1/8).
Ihre Matrixeintraege sind binaer exakt darstellbar. Ausgegebene numerische
Eigenwerte werden per Fraction(float) in den exakten Bruch des binaeren
Gleitkommawertes umgewandelt. Sage vergleicht diese Brueche mit algebraischen
Referenzzahlen in AA; die PASS/FAIL-Entscheidung verwendet keine zusaetzlich
gerundeten Dezimalreferenzen. RealField(80) dient nur der Ergebnisanzeige.
Dies darf nicht unveraendert als exakter Matrixvergleich fuer beliebige
nicht-binaer-darstellbare Dezimalgewichte interpretiert werden.

Stand bei Vorbereitung
X6-Ausfuehrung: abgeschlossen, 4 Faelle, jeweils Jacobi converged=true.
Lokale Gegenpruefung: PASS fuer 4/4 Faelle. Matrizen und Polynome mit Python
Fraction und Leibniz-Determinante exakt geprueft; Polynomidentitaet durch n+1
rationale Auswertungspunkte bei Grad <= n. Eigenwertfehler separat mit
Decimal bei 80 Stellen geprueft. Groesste Abweichung etwa 1.902e-15.
Der Sage-Durchlauf und dessen sechs Negativkontrollen stehen noch aus.

Reproduktion (Python 3, Node.js und Git; keine zusaetzlichen Python-Pakete)
Ein Checkout des oben angegebenen Repositorys muss auf genau COMMIT stehen.
Im entpackten Paket ausfuehren:
  node export_x6.cjs /pfad/zum/repository > x6_actual_output.json
  python build_check.py
  sage X6_SageMathCell_Gegenpruefung_2.sage
Alternativ den erzeugten Sage-Code wieder in SageMathCell ausfuehren.
Der Exporter verweigert einen anderen Commit oder geaenderte app/index.html.
Zeitstempel in der rohen X6-Ausgabe aendern sich beim erneuten Export; sie
werden nicht in den deterministischen mathematischen Vergleich uebernommen.

Grenzen
Kein allgemeiner Korrektheitsbeweis des Jacobi-Verfahrens, keine Verifikation
von Eigenvektoren, Fourier-/Signal-Lab-Funktionen, Lorentz-Operatoren oder
physikalischen Geraeten. X6 berechnet hier kein eigenes charakteristisches
Polynom; geprueft wird dessen Matrix durch exakte Nachberechnung in Sage.
Hashes sichern Zuordnung und Integritaet, nicht mathematische Wahrheit oder
die Authentizitaet einer fremden Laufzeitumgebung.

Paketinhalt
- X6_SageMathCell_Gegenpruefung_2.sage: vollstaendiger Browsercode
- contract.json: vorab festgelegte Kriterien und Graphen
- x6_actual_output.json: echte rohe JavaScript-Ausgaben
- x6_exact_transport.json: exakter rationaler Zahlentransport
- export_x6.cjs: unveraenderte Funktionen extrahieren und ausfuehren
- build_check.py und check_body.sage: Browsercode reproduzierbar aufbauen
- local_precheck.json: protokollierte lokale Vorpruefung, kein Sage-Ergebnis
- SHA256SUMS: Pruefsummen aller obigen Dateien
