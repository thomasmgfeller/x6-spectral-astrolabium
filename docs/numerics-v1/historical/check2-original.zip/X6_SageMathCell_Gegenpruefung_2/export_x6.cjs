'use strict';
// Extraction/transport only. The numerical routines are executed unchanged.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const root = path.resolve(process.argv[2] || '.');
const contractPath = path.join(__dirname, 'contract.json');
const contractBytes = fs.readFileSync(contractPath);
const contract = JSON.parse(contractBytes);
const git = args => cp.execFileSync('git', args, {cwd: root, encoding:'utf8'}).trim();
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const commit = git(['rev-parse','HEAD']);
if (commit !== contract.commit) throw Error('Wrong repository commit');
const appBytes = fs.readFileSync(path.join(root, 'app/index.html'));
const committedBytes = cp.execFileSync('git',['show',commit+':app/index.html'],{cwd:root});
if (!appBytes.equals(committedBytes)) throw Error('Working app differs from pinned commit');
const tag = appBytes.toString('utf8').match(/<iframe\b[^>]*\bid="spectrumFrame"[^>]*>/);
if (!tag) throw Error('spectrumFrame missing');
const attribute = tag[0].match(/\bsrcdoc="([^"]*)"/);
if (!attribute) throw Error('srcdoc missing');
const named = {amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};
const source = attribute[1].replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,
 (_,k) => k[0]==='#' ? String.fromCodePoint(k[1].toLowerCase()==='x'
 ? parseInt(k.slice(2),16):parseInt(k.slice(1),10)) : named[k.toLowerCase()]);
const start = source.indexOf('function parse(s)');
const end = source.indexOf('function show(o)',start);
if (start < 0 || end <= start) throw Error('Extraction boundaries changed');
const block = source.slice(start,end);
for (const f of ['parse','components','jacobi','analyze']) {
 if (!block.includes('function '+f+'(')) throw Error('Missing '+f);
}
const context = vm.createContext({});
vm.runInContext("'use strict';\n"+block+'\nglobalThis.api={parse,analyze};', context,
 {timeout:1000,filename:'unchanged-spectrumFrame-kernel.js'});
const runs = contract.cases.map(c => {
 context.input = c.input;
 const result = vm.runInContext('({graph:api.parse(input),analysis:api.analyze(input)})',
  context,{timeout:1000});
 return {id:c.id,input:c.input,nodes:result.graph.nodes,A:result.graph.A,L:result.graph.L,
  analysis:result.analysis};
});
const report = {schema:'x6-sage-check2-export/1',
 source:{repository:'thomasmgfeller/x6-spectral-astrolabium',commit,
  source_path:'app/index.html',app_sha256:hash(appBytes),kernel_sha256:hash(block),
  contract_sha256:hash(contractBytes),exporter_sha256:hash(fs.readFileSync(__filename)),
  execution:'Node.js VM; unchanged extracted spectral functions; no DOM/browser',
  node_version:process.version},contract,runs};
process.stdout.write(JSON.stringify(report,(_,v)=>{
 if(typeof v==='number'&&!Number.isFinite(v))throw Error('Nonfinite result');
 return v;
},2)+'\n');
