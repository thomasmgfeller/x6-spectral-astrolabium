"""Prepare a self-contained SageMathCell checker from actual X6 output."""
from pathlib import Path
from fractions import Fraction
import json

ROOT = Path(__file__).resolve().parent
raw = json.loads((ROOT / 'x6_actual_output.json').read_text())
def q(v):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ValueError('Expected finite real number')
    return str(Fraction(v))  # exact rational value of the emitted binary64 number
data = {'source': raw['source'], 'runs': []}
for r in raw['runs']:
    a = r['analysis']
    data['runs'].append(dict(
        id=r['id'], input=r['input'], nodes=r['nodes'],
        A=[[q(v) for v in row] for row in r['A']],
        L=[[q(v) for v in row] for row in r['L']],
        eig=[q(v['value']) for v in a['numerical']['eig']],
        residual=[q(v['residual']) for v in a['numerical']['eig']],
        converged=a['numerical']['converged'], nullity=a['exactNullity'],
        trace=q(a['trace']), reported_version=a['version']))
(ROOT/'x6_exact_transport.json').write_text(json.dumps(data, indent=2)+'\n')
body = (ROOT/'check_body.sage').read_text()
header = '''# X6 / SageMathCell Gegenpruefung 2, Version 1.0
# Vollstaendigen Inhalt in SageMathCell einfuegen; Sprache Sage; Evaluate.
# Daten stammen aus unveraendertem X6-JavaScript, ausgefuehrt in Node.js.
# Bruch-Strings bewahren die EXAKTEN ausgegebenen binaeren Gleitkommazahlen.
# Kein Nachweis fuer beliebige Graphen, Browseroberflaeche oder reale Geraete.
from sage.all import *
from sage.version import version as sage_version
import json, copy
'''
source = header + "DATA = json.loads(r'''" + json.dumps(data, separators=(',',':')) + "''')\n" + body
(ROOT/'X6_SageMathCell_Gegenpruefung_2.sage').write_text(source)
print('Prepared checker:',len(source.encode()),'bytes')
