
COMMIT = '7257e51a8df93ff1722d1116103143cc6c827ef4'
APP_SHA = 'ff60231155f0fc869564ec0eb24c87568943cdd96e154094ae9abd9877bd7ff8'
KERNEL_SHA = 'a5adaeb576e6e0417023cc61ac4e431b782362843c2110f121c82d1f8227b46e'
ATOL = QQ('1/1000000000000')
RTOL = QQ('1/1000000000000')
RESIDUAL_LIMIT = QQ('1/1000000000000')
R = PolynomialRing(QQ, 'x')
x = R.gen()
w = QQ(1)/8
s2 = AA(2).sqrt()

# Unabhaengige Sollwerte; Matrixeintraege und Polynome von Hand angegeben.
# Reihenfolge: ID, Knotennamen, Eingabetext, A, p_A, p_L, Spektrum L, Nullitaet.
REF = [
 ('path4',['a','b','c','d'],'a b 1\nb c 1\nc d 1',
  [[0,1,0,0],[1,0,1,0],[0,1,0,1],[0,0,1,0]],
  x**4-3*x**2+1, x*(x-2)*(x**2-4*x+2), [0,2-s2,2,2+s2], 1),
 ('triangle',['a','b','c'],'a b 1\nb c 1\na c 1',
  [[0,1,1],[1,0,1],[1,1,0]],
  (x-2)*(x+1)**2, x*(x-3)**2, [0,3,3], 1),
 ('weighted2',['a','b'],'a b 0.125', [[0,w],[w,0]],
  x**2-w**2, x*(x-2*w), [0,2*w], 1),
 ('disconnected',['a','b','c','d'],'a b 1\nc d 1',
  [[0,1,0,0],[1,0,0,0],[0,0,0,1],[0,0,1,0]],
  (x**2-1)**2, x**2*(x-2)**2, [0,0,2,2], 2)
]

def require(ok, message):
    if not ok:
        raise AssertionError('FAIL: ' + message)

def rational_matrix(rows):
    return matrix(QQ, [[QQ(v) for v in row] for row in rows])

def verify(data, verbose=False):
    require(data['source']['commit'] == COMMIT, 'Commit')
    require(data['source']['app_sha256'] == APP_SHA, 'Quelldatei-Hash')
    require(data['source']['kernel_sha256'] == KERNEL_SHA, 'Kern-Hash')
    require([v['id'] for v in data['runs']] == [r[0] for r in REF],
            'Vollstaendige Fallliste ohne Duplikate')
    errors = []
    for row, ref in zip(data['runs'], REF):
        name, nodes, input_text, a_rows, pA, pL, eigen, nullity = ref
        require(row['nodes'] == nodes, name + ': Knotenreihenfolge')
        require(row['input'] == input_text, name + ': Eingabetext')
        Aref = matrix(QQ, a_rows)
        n = Aref.nrows()
        Lref = diagonal_matrix(QQ, [sum(r) for r in Aref.rows()]) - Aref
        A, L = rational_matrix(row['A']), rational_matrix(row['L'])
        require(A == Aref, name + ': Adjazenzmatrix exakt')
        require(L == Lref, name + ': Laplace-Matrix exakt')
        # Sage berechnet die Polynome aus den TATSAECHLICHEN X6-Matrizen.
        # X6 exportiert hier kein selbst berechnetes Polynom.
        require(R(A.charpoly('x')) == pA, name + ': p_A exakt')
        require(R(L.charpoly('x')) == pL, name + ': p_L exakt')
        expected = sorted(AA(v) for v in eigen)
        sage_eig = sorted(AA(v) for v in L.eigenvalues())
        require(sage_eig == expected, name + ': Sage-Spektrum exakt')
        require(n-L.rank() == nullity == row['nullity'], name + ': Nullitaet')
        require(QQ(row['trace']) == L.trace(), name + ': Spur')
        require(row['converged'] is True, name + ': Jacobi-Konvergenz')
        actual = [QQ(v) for v in row['eig']]
        require(len(actual) == n and actual == sorted(actual),
                name + ': vollstaendiges sortiertes X6-Spektrum')
        delta = [abs(AA(a)-e) for a,e in zip(actual, expected)]
        for k, (err, e) in enumerate(zip(delta, expected)):
            require(err <= ATOL + RTOL*abs(e), name + ': Eigenwert ' + str(k))
        residual = [QQ(v) for v in row['residual']]
        scale = max(QQ(1), max(sum(abs(v) for v in r) for r in L.rows()))
        require(len(residual) == n and all(0 <= r <= RESIDUAL_LIMIT*scale
                for r in residual), name + ': gemeldete Residuen')
        errors.extend(delta)
        if verbose:
            print(name + ': X6 PASS; Matrix/Polynome exakt; max. Eigenwertfehler =',
                  RealField(80)(max(delta)))
    return max(errors)

print('Sage-Version:', sage_version)
print('X6-Commit:', COMMIT)
print('X6-Ausfuehrung:', DATA['source']['execution'])
print('Eigenwertkriterium: |Fehler| <= 1e-12 + 1e-12*|Referenzwert|')
maximum_error = verify(DATA, verbose=True)

# Kontrollen: absichtlich falsche Daten muessen zur Ablehnung fuehren.
controls = []
bad = copy.deepcopy(DATA); bad['runs'][0]['L'][0][0] = '2'
controls.append(('falsche Matrix', bad, 'Laplace-Matrix exakt'))
bad = copy.deepcopy(DATA); bad['runs'][0]['eig'][-1] = '7/2'
controls.append(('falscher Eigenwert', bad, 'Eigenwert 3'))
bad = copy.deepcopy(DATA); bad['runs'][3]['eig'].pop(0)
controls.append(('fehlender Null-Eigenwert', bad, 'vollstaendiges sortiertes'))
bad = copy.deepcopy(DATA); bad['runs'][3]['nullity'] = 1
controls.append(('falsche Nullitaet', bad, 'Nullitaet'))
bad = copy.deepcopy(DATA); bad['runs'].pop()
controls.append(('fehlender Testfall', bad, 'Vollstaendige Fallliste'))
bad = copy.deepcopy(DATA); bad['source']['commit'] = '0'*40
controls.append(('falscher Commit', bad, 'Commit'))
for label, bad, expected_reason in controls:
    try:
        verify(bad)
    except AssertionError as error:
        require(expected_reason in str(error), 'Unerwarteter Ablehnungsgrund: '+label)
        print('Negativkontrolle:', label, 'korrekt ABGELEHNT')
    else:
        raise AssertionError('FAIL: Negativkontrolle unentdeckt: '+label)

print('\nGESAMT: PASS — 4/4 X6-Faelle und 6/6 Negativkontrollen.')
print('Maximaler Eigenwertfehler:', RealField(80)(maximum_error))
print('Geltung: diese vier Graphen und dieser Commit; kein allgemeiner Beweis.')
print('Eigenvektoren, Browseroberflaeche und physikalische Funktion: NICHT_GEPRUEFT')
print('Residuen: X6-Angaben geprueft; keine unabhaengige Eigenvektorberechnung.')
