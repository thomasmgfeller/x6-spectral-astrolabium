ACVM C1 — Steuerkanal, Referenz 0.1

Status: SOFTWARE_PASS_HARDWARE_OPEN
Linux/POSIX, Python 3.12, g++ mit C++17. Keine Python-Zusatzpakete.

Im entpackten Verzeichnis ausführen:
python3 -m experimental.control_channel doctor
python3 -m experimental.control_channel qualify --output runs/pruefung-001

Anleitung: docs/acvm/control-channel-v0.1/README.md
Prüfbericht: docs/acvm/control-channel-v0.1/VALIDATION.md
Aufbau und Messung: docs/acvm/control-channel-v0.1/HARDWARE.md

Pico-Zielbuild, elektrische und optische Messung nicht ausgeführt.
Der native C++-Kern steuert im Test ein protokolliertes Modell.
Die Pico-Firmware wird als noch nicht gebauter Zielquelltext geliefert.

Ursprungsrepository: https://github.com/thomasmgfeller/x6-spectral-astrolabium
Lokaler Implementierungscommit: 7f20fbc7e55aea371614e9832570c91b45243a04
Dieses neue Paket wurde noch nicht auf GitHub veröffentlicht.
