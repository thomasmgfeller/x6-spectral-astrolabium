ACVM ETF-01 — Konzept 0.1
Stand 13. Oktober 2026

Enthalten sind das 13-seitige Word-Konzept und zwei separate PNG-Bilder.

ACVM ETF-01: Electrical & Thermal Test Fixture.
ACVM-ETF-01-CB1: Control Board mit Standardbauteilen.
ACVM-ETF-01-TC1: austauschbare thermische Prüfplatte.
Astrolabium QD-01: Quantum Dot Test Device, eigenständiger Forschungsentwurf.

Die Bilder wurden mit dem integrierten Bildgenerierungswerkzeug erzeugt.
Sie sind illustrative, nicht maßstäbliche Konzeptansichten und keine CAD-,
Netzlisten-, Fertigungs- oder Mikroskopieunterlagen. Die Chipgrafik zeigt
nur eine vorläufige BLG-Variante mit Testpunkt und benachbartem Ladungssensor.
Aus ihr folgen keine Aussagen über Qubit-Kontrolle oder Fertigbarkeit.

Alle Hardwareprüfungen ETF-T01 bis ETF-T14 stehen auf NOT_RUN.
Die Rechenbeilage enthält idealisierte Lastleistungen, keine Messdaten.
Das Manifest bindet die Paketdateien; es ist kein Validierungsnachweis.
Die Bildvorgaben sind archiviert. Bitidentische Neugenerierung wird nicht behauptet.
