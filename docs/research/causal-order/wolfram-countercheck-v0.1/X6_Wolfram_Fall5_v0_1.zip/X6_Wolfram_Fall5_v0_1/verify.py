#!/usr/bin/env python3
"""Exact offline reproduction using only the Python standard library."""
import argparse
import hashlib
import itertools
import json
import platform
from pathlib import Path

BASE = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_json(name):
    return json.loads((BASE / name).read_text(encoding="utf-8"))

def digest(name):
    return hashlib.sha256((BASE / name).read_bytes()).hexdigest()

def transpose(a):
    return [list(row) for row in zip(*a)]

def add(a, b):
    return [[x+y for x,y in zip(ar,br)] for ar,br in zip(a,b)]

def neg(a):
    return [[-x for x in row] for row in a]

def subtract(a, b):
    return add(a, neg(b))

def multiply(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]

def relabel(a, p):
    return [[a[p[i]][p[j]] for j in range(len(p))] for i in range(len(p))]

def polynomial_multiply(a, b):
    out = [0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j] += x*y
    return out

def characteristic_coefficients(a):
    # Independent determinant expansion over permutations, polynomial integers.
    # Coefficient order is 1,z,z^2,...; no numerical eigenvalue algorithm.
    n = len(a)
    out = [0]*(n+1)
    for p in itertools.permutations(range(n)):
        inversions = sum(p[i] > p[j] for i in range(n) for j in range(i+1,n))
        term = [-1 if inversions % 2 else 1]
        for i in range(n):
            term = polynomial_multiply(term, [-a[i][p[i]], int(i == p[i])])
        for j, x in enumerate(term):
            out[j] += x
    return out

def operators(c):
    ct = transpose(c)
    s, a = add(c,ct), subtract(c,ct)
    return {"S":s, "A":a, "K":subtract(multiply(s,a),multiply(a,s))}

def extrema(c):
    n = len(c)
    return {
        "minimal":[j+1 for j in range(n) if all(c[i][j] == 0 for i in range(n))],
        "maximal":[i+1 for i in range(n) if all(c[i][j] == 0 for j in range(n))],
    }

def strict_order(c):
    n = len(c)
    return (all(type(v) is int and v in (0,1) for row in c for v in row)
            and all(c[i][i] == 0 for i in range(n))
            and all(not (c[i][j] and c[j][k]) or c[i][k]
                    for i in range(n) for j in range(n) for k in range(n)))

def reference(contract):
    c = contract["C"]
    d = transpose(c)
    n = len(c)
    op, od = operators(c), operators(d)
    polys = {name:characteristic_coefficients(m) for name,m in op.items()}
    polysd = {name:characteristic_coefficients(m) for name,m in od.items()}
    rows = []
    perms = list(itertools.permutations(range(n)))
    for p in perms:
        renamed = relabel(c,p)
        rows.append({
            "permutation":[i+1 for i in p],
            "C_to_D":renamed == d,
            "C_to_C":renamed == c,
            "D_to_D":relabel(d,p) == d,
            "reversed_C_to_D":transpose(renamed) == d,
            "C_to_D_entry_mismatches":sum(
                renamed[i][j] != d[i][j] for i in range(n) for j in range(n)),
        })
    counts = {name:sum(row[key] for row in rows) for name,key in (
        ("order_preserving","C_to_D"), ("self_C","C_to_C"),
        ("self_D","D_to_D"), ("order_reversing","reversed_C_to_D"))}
    matrices = {"C":c, "D":d, **op, **{name+"_dual":m for name,m in od.items()}}
    mathematical_result = {
        "matrices":matrices, "polynomial_coefficients":{"C":polys,"D":polysd},
        "extrema":{"C":extrema(c),"D":extrema(d)},
        "permutation_rows":rows, "isomorphism_counts":counts,
    }
    expected = contract["expected"]
    checks = {
        "valid_strict_orders":strict_order(c) and strict_order(d),
        "transpose_dual":d == transpose(c),
        "same_S":op["S"] == od["S"],
        "opposite_A":od["A"] == neg(op["A"]),
        "opposite_K":od["K"] == neg(op["K"]),
        "matrix_symmetries":all(
            transpose(o["S"]) == o["S"] and transpose(o["A"]) == neg(o["A"])
            and transpose(o["K"]) == o["K"] for o in (op,od)),
        "expected_characteristic_polynomials":(
            polys == expected["polynomial_coefficients"] == polysd),
        "same_spectral_fingerprint":polys == polysd,
        "extrema_counts":all(
            [len(mathematical_result["extrema"][key]["minimal"]),
             len(mathematical_result["extrema"][key]["maximal"])] ==
            expected["minimal_maximal_counts"][key] for key in ("C","D")),
        "six_permutations":len(perms) == expected["permutations"] == 6,
        "no_order_isomorphism":counts["order_preserving"] ==
            expected["order_preserving_isomorphisms"] == 0,
        "self_isomorphism_controls":(
            counts["self_C"] == expected["self_isomorphisms_C"] == 2 and
            counts["self_D"] == expected["self_isomorphisms_D"] == 2),
        "dual_reversal_control":counts["order_reversing"] ==
            expected["order_reversing_isomorphisms"] == 2,
        "spectra_invariant_under_relabelling":all(
            characteristic_coefficients(relabel(o[name],p)) ==
            expected["polynomial_coefficients"][name]
            for o in (op,od) for name in ("S","A","K") for p in perms),
        "full_S_A_reconstruction":all(
            add(o["S"],o["A"]) == [[2*v for v in row] for row in relation]
            for o,relation in ((op,c),(od,d))),
        "exact_integer_outputs":all(type(v) is int
            for m in matrices.values() for row in m for v in row)
            and all(type(v) is int for pol in (polys,polysd)
                    for co in pol.values() for v in co),
    }
    require(matrices == expected["matrices"], "Explicit matrix expectations failed")
    require(set(checks) == set(contract["checks"]), "Check IDs differ")
    require(all(v is True for v in checks.values()), "Independent mathematical check failed")
    return mathematical_result, checks

def verify():
    contract = read_json("contract.json")
    math, local_checks = reference(contract)
    raw = read_json("wolfram_response.json")
    require(not raw.get("isError",False), "Wolfram tool error")
    require(len(raw["content"]) == 1 and raw["content"][0]["type"] == "text",
            "Unexpected response content")
    text = raw["content"][0]["text"].strip()
    require(text.startswith("Out[1]= "), "Unexpected Wolfram output or message")
    saved = json.loads(json.loads(text[len("Out[1]= "):]))
    require(saved == read_json("wolfram_result.json"), "Raw/normalized result mismatch")
    require(saved["schema"] == "x6.wolfram.causal-cospectral-check/1", "Schema mismatch")
    require(saved["arithmetic"] == "exact" and contract["tolerance"] == 0,
            "Exact-arithmetic requirement changed")
    require(saved["mathematical_result"] == math,
            "Independent mathematical result differs from Wolfram")
    require(saved["checks"] == local_checks and saved["allChecksPass"] is True,
            "Wolfram assertion mismatch")

    for name, expected_hash in read_json("freeze.json")["files"].items():
        require(digest(name) == expected_hash, "Frozen source changed: "+name)
    manifest_path = BASE / "SHA256.json"
    manifest_checked = manifest_path.exists()
    if manifest_checked:
        manifest = read_json("SHA256.json")["files"]
        observed = {str(p.relative_to(BASE)) for p in BASE.rglob("*")
                    if p.is_file() and p.name != "SHA256.json"}
        require(observed == set(manifest), "Package inventory mismatch")
        for name, expected_hash in manifest.items():
            require(digest(name) == expected_hash, "Package file changed: "+name)
    return {
        "status":"PASS_WITH_SCOPE_LIMITS",
        "wolfram_checks_passed":len(local_checks),
        "python_checks_passed":len(local_checks),
        "characteristic_polynomials_compared":6,
        "permutation_rows_compared":len(math["permutation_rows"]),
        "isomorphism_counts":math["isomorphism_counts"],
        "polynomial_coefficients":math["polynomial_coefficients"],
        "extrema":math["extrema"],
        "arithmetic":"exact integer polynomial arithmetic; tolerance 0",
        "python_version":platform.python_version(),
        "wolfram_kernel_reported":saved["kernelVersion"],
        "freeze_hashes_verified":True,
        "package_manifest_verified":manifest_checked,
        "preliminary_context_lookup":"TOOL_ERROR_RECORDED; not a kernel computation",
        "wolfram_reexecuted_by_this_script":False,
        "scope":"Finite counterexample for stated spectra and order-preserving isomorphism."
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-only",action="store_true",
                        help="Compute exact Python reference without a stored Wolfram response.")
    args = parser.parse_args()
    if args.reference_only:
        mathematical_result, checks = reference(read_json("contract.json"))
        output = {"mathematical_result":mathematical_result, "checks":checks}
    else:
        output = verify()
    print(json.dumps(output,indent=2,ensure_ascii=False))

