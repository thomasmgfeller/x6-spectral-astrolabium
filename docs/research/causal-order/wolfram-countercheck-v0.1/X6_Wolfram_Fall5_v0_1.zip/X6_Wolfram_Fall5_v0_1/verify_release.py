#!/usr/bin/env python3
"""Verify final case-5 package including preserved adapter failure and amendment."""
import json
import sys
sys.dont_write_bytecode = True
import verify

def run():
    out = verify.verify()
    for name, expected_hash in verify.read_json("amendment_freeze.json")["files"].items():
        verify.require(verify.digest(name) == expected_hash, "Amendment hash mismatch: "+name)
    first_raw = verify.read_json("wolfram_response_attempt1.json")
    verify.require(not first_raw.get("isError",False), "Initial raw result missing")
    first_text = first_raw["content"][0]["text"].strip()
    verify.require(first_text.startswith("Out[1]= "), "Unexpected first response")
    first = json.loads(json.loads(first_text[len("Out[1]= "):]))
    verify.require(first == verify.read_json("wolfram_result_attempt1.json"),
                   "Initial raw/normalized mismatch")
    final = verify.read_json("wolfram_result.json")
    verify.require(first["allChecksPass"] is False, "Initial failure concealed")
    verify.require(first["checks"]["expected_characteristic_polynomials"] is False,
                   "Initial failed check missing")
    verify.require(sum(first["checks"].values()) == 15, "Initial check count differs")
    fm = first["mathematical_result"]
    sm = final["mathematical_result"]
    for key in sm:
        if key != "polynomial_coefficients":
            verify.require(fm[key] == sm[key], "Non-polynomial result changed: "+key)
    for order in ("C","D"):
        for op in ("S","A","K"):
            verify.require(fm["polynomial_coefficients"][order][op] ==
                           [-x for x in sm["polynomial_coefficients"][order][op]],
                           "Adapter difference is not the documented sign")
    out.update({"initial_kernel_status":"FAIL_SIGN_CONVENTION",
                "initial_kernel_checks_passed":15,
                "amended_kernel_status":"PASS_NO_MESSAGES",
                "amendment_hashes_verified":True,
                "preserved_sign_convention_failure_verified":True})
    return out

if __name__ == "__main__":
    print(json.dumps(run(),indent=2,ensure_ascii=False))

