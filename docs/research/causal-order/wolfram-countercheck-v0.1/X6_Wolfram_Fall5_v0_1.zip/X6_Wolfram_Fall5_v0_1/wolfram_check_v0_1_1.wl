ClearAll["Global`*"];
c = {{0, 1, 1}, {0, 0, 0}, {0, 0, 0}};
d = Transpose[c]; n = Length[c];
s = c + Transpose[c]; a = c - Transpose[c]; k = s.a - a.s;
sd = d + Transpose[d]; ad = d - Transpose[d]; kd = sd.ad - ad.sd;
ops = <|"S" -> s, "A" -> a, "K" -> k|>;
opsd = <|"S" -> sd, "A" -> ad, "K" -> kd|>;
coeff[m_] := CoefficientList[Expand[(-1)^Length[m] CharacteristicPolynomial[m, z]], z];
cp = Map[coeff, ops]; cpd = Map[coeff, opsd];
expected = <|"S" -> {0, -2, 0, 1}, "A" -> {0, 2, 0, 1}, "K" -> {0, -16, 0, 1}|>;
perms = Permutations[Range[n]];
strict[m_] := And[
 AllTrue[Flatten[m], MemberQ[{0, 1}, #] &],
 Tr[m] == 0,
 And @@ Flatten[Table[If[m[[i, j]] == 1 && m[[j, h]] == 1, m[[i, h]] == 1, True],
 {i, n}, {j, n}, {h, n}]]];
mins[m_] := Select[Range[n], Total[m[[All, #]]] == 0 &];
maxs[m_] := Select[Range[n], Total[m[[#, All]]] == 0 &];
extrema = <|"C" -> <|"minimal" -> mins[c], "maximal" -> maxs[c]|>,
 "D" -> <|"minimal" -> mins[d], "maximal" -> maxs[d]|>|>;
rows = Table[<|"permutation" -> perm,
 "C_to_D" -> SameQ[c[[perm, perm]], d],
 "C_to_C" -> SameQ[c[[perm, perm]], c],
 "D_to_D" -> SameQ[d[[perm, perm]], d],
 "reversed_C_to_D" -> SameQ[Transpose[c[[perm, perm]]], d],
 "C_to_D_entry_mismatches" -> Count[Flatten[c[[perm, perm]] - d], Except[0]]|>, {perm, perms}];
count[key_] := Count[(#[key] &) /@ rows, True];
counts = <|"order_preserving" -> count["C_to_D"], "self_C" -> count["C_to_C"],
 "self_D" -> count["D_to_D"], "order_reversing" -> count["reversed_C_to_D"]|>;
relabelOK = And @@ Flatten[Table[
 SameQ[Map[coeff, Map[#[[perm, perm]] &, ops]], cp] &&
 SameQ[Map[coeff, Map[#[[perm, perm]] &, opsd]], cpd], {perm, perms}]];
matrices = <|"C" -> c, "D" -> d, "S" -> s, "A" -> a, "K" -> k,
 "S_dual" -> sd, "A_dual" -> ad, "K_dual" -> kd|>;
checks = <|
 "valid_strict_orders" -> (strict[c] && strict[d]),
 "transpose_dual" -> SameQ[d, Transpose[c]],
 "same_S" -> SameQ[sd, s],
 "opposite_A" -> SameQ[ad, -a],
 "opposite_K" -> SameQ[kd, -k],
 "matrix_symmetries" -> (SameQ[Transpose[s], s] && SameQ[Transpose[sd], sd] &&
 SameQ[Transpose[a], -a] && SameQ[Transpose[ad], -ad] &&
 SameQ[Transpose[k], k] && SameQ[Transpose[kd], kd]),
 "expected_characteristic_polynomials" -> (SameQ[cp, expected] && SameQ[cpd, expected]),
 "same_spectral_fingerprint" -> SameQ[cp, cpd],
 "extrema_counts" -> SameQ[{Length[mins[c]], Length[maxs[c]], Length[mins[d]], Length[maxs[d]]}, {1, 2, 2, 1}],
 "six_permutations" -> (Length[perms] == Factorial[n] == 6),
 "no_order_isomorphism" -> (counts["order_preserving"] == 0),
 "self_isomorphism_controls" -> (counts["self_C"] == 2 && counts["self_D"] == 2),
 "dual_reversal_control" -> (counts["order_reversing"] == 2),
 "spectra_invariant_under_relabelling" -> relabelOK,
 "full_S_A_reconstruction" -> (SameQ[(s + a)/2, c] && SameQ[(sd + ad)/2, d]),
 "exact_integer_outputs" -> (AllTrue[Flatten[Values[matrices]], IntegerQ] &&
 AllTrue[Flatten[Values[cp]], IntegerQ] && AllTrue[Flatten[Values[cpd]], IntegerQ])|>;
math = <|"matrices" -> matrices, "polynomial_coefficients" -> <|"C" -> cp, "D" -> cpd|>,
 "extrema" -> extrema, "permutation_rows" -> rows, "isomorphism_counts" -> counts|>;
out = <|"schema" -> "x6.wolfram.causal-cospectral-check/1", "kernelVersion" -> $Version,
 "systemID" -> $SystemID, "arithmetic" -> "exact", "mathematical_result" -> math,
 "checks" -> checks, "allChecksPass" -> (And @@ Values[checks]),
 "scope" -> "Finite counterexample for the stated spectra and order-preserving isomorphism; no physical inference."|>;
ExportString[out, "RawJSON"]

