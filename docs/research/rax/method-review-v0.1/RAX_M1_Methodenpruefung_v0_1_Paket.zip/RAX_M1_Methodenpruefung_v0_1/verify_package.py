#!/usr/bin/env python3
"""Verify exact inventory, byte counts and SHA-256 digests after unpacking."""
from pathlib import Path, PurePosixPath
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
expected = set(manifest['files']) | {'MANIFEST.json'}
actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
if actual != expected:
    raise ValueError(('File inventory mismatch', sorted(actual - expected), sorted(expected - actual)))
for name, info in manifest['files'].items():
    posix = PurePosixPath(name)
    if posix.is_absolute() or '..' in posix.parts:
        raise ValueError(('Unsafe manifest path', name))
    path = root.joinpath(*posix.parts)
    if not path.is_file() or path.is_symlink():
        raise ValueError(('Missing or linked file', name))
    data = path.read_bytes()
    if len(data) != info['bytes'] or hashlib.sha256(data).hexdigest() != info['sha256']:
        raise ValueError(('Content mismatch', name))
print(f'PASS: {len(manifest["files"])} files; exact inventory, byte counts and SHA-256 verified')
