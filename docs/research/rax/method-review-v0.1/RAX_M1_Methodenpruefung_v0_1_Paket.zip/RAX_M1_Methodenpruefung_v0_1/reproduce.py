#!/usr/bin/env python3
"""Offline reproduction of the delivered RAX-M1 evidence, in a NEW directory."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import stat
import subprocess
import sys
import zipfile

BASELINE_SHA = '26609c78549be636b770196ca18d8185a8d072c47606726b71d6bda2a81f7d7f'
BASELINE_NAME = 'RAX_B1_Benchmarking_v0_1_Paket.zip'
VOLATILE_KEYS = {'created_utc', 'wall_seconds', 'unit_log', 'test_log'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def equal_semantics(expected, actual, path='checks'):
    if isinstance(expected, dict):
        if not isinstance(actual, dict) or set(expected) != set(actual):
            raise ValueError(f'{path}: key mismatch')
        for key in expected:
            if key not in VOLATILE_KEYS:
                equal_semantics(expected[key], actual[key], f'{path}.{key}')
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(expected) != len(actual):
            raise ValueError(f'{path}: length mismatch')
        for i, (a, b) in enumerate(zip(expected, actual)):
            equal_semantics(a, b, f'{path}[{i}]')
    elif isinstance(expected, float):
        if not isinstance(actual, (int, float)) or not math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-15):
            raise ValueError(f'{path}: numeric mismatch: {expected!r} != {actual!r}')
    elif type(expected) is not type(actual) or expected != actual:
        raise ValueError(f'{path}: mismatch: {expected!r} != {actual!r}')


def verified_extract(archive, dest):
    data = archive.read_bytes()
    if sha(data) != BASELINE_SHA:
        raise ValueError('Published baseline archive SHA-256 mismatch')
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        if len({i.filename for i in infos}) != len(infos):
            raise ValueError('Duplicate archive member')
        for info in infos:
            name = PurePosixPath(info.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in info.filename or stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError(f'Unsafe archive member: {info.filename}')
            path = dest.joinpath(*name.parts)
            if info.is_dir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                content = z.read(info)  # Includes ZIP CRC verification.
                with path.open('xb') as f:
                    f.write(content)
                    f.flush()
                    os.fsync(f.fileno())
                if path.read_bytes() != content:
                    raise OSError(f'Extracted file readback mismatch: {info.filename}')
    extracted = dest / 'RAX_B1_Benchmarking_v0_1'
    subprocess.run([sys.executable, str(extracted / 'verify_package.py')], check=True)
    return extracted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workdir', type=Path, required=True, help='New output directory; existing paths are rejected')
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O: baseline scientific assertions must be active')
    root = Path(__file__).resolve().parent
    if not (root / 'baseline' / BASELINE_NAME).is_file():
        raise FileNotFoundError('Use reproduce.py from the root of the complete delivery package')
    subprocess.run([sys.executable, str(root / 'verify_package.py')], check=True)
    import numpy
    import scipy
    versions = {'python': platform.python_version(), 'numpy': numpy.__version__, 'scipy': scipy.__version__}
    pinned = {'python': '3.12.14', 'numpy': '2.3.5', 'scipy': '1.17.0'}
    if versions != pinned:
        print(f'Runtime differs from recorded versions: {versions}; recorded: {pinned}', flush=True)
    subprocess.run(['git', '--version'], check=True)
    work = args.workdir.resolve()
    try:
        work.relative_to(root)
    except ValueError:
        pass
    else:
        raise ValueError('--workdir must be outside the delivery package')
    work.mkdir(parents=True, exist_ok=False)
    extracted = verified_extract(root / 'baseline' / BASELINE_NAME, work / 'baseline')
    baseline = extracted / 'benchmark'
    # freeze() records a Git HEAD; this disposable local commit is not historical evidence.
    subprocess.run(['git', 'init', '-q', str(work)], check=True)
    sources = ['core.py', 'storage.py', 'run.py', 'reference.py', 'analyze.py', 'test_benchmark.py', 'contract.json']
    subprocess.run(['git', 'add', '--', *[str((baseline / p).relative_to(work)) for p in sources]], cwd=work, check=True)
    subprocess.run(['git', '-c', 'user.name=RAX local reproduction', '-c', 'user.email=reproduction@localhost', '-c', 'commit.gpgsign=false', 'commit', '-qm', 'Local reproduction fixture; not historical source freeze'], cwd=work, check=True)
    output = work / 'method-results'
    subprocess.run([sys.executable, str(root / 'review' / 'audit.py'), '--baseline', str(baseline), '--output', str(output)], check=True)
    subprocess.run([sys.executable, str(root / 'review' / 'verify_examples.py'), str(output)], check=True)
    expected = json.loads((root / 'review/evidence/run-v0.1/METHOD_REVIEW.json').read_text())
    actual = json.loads((output / 'METHOD_REVIEW.json').read_text())
    equal_semantics(expected['checks'], actual['checks'])
    for key in ['status', 'original_files_unchanged', 'original_primary_decisions_changed', 'external_or_blind_review', 'corrective_guards_are_supplemental', 'audit_script_sha256', 'guard_script_sha256']:
        equal_semantics(expected[key], actual[key], key)
    expected_math = json.loads((root / 'review/evidence/run-v0.1/independent-example-check.json').read_text())
    actual_math = json.loads((output / 'independent-example-check.json').read_text())
    equal_semantics(expected_math, actual_math, 'separate_math_and_guards')
    receipt = {'status': 'PASS', 'runtime': versions, 'recorded_runtime': pinned, 'checks_reproduced': len(actual['checks']), 'original_files_unchanged': actual['original_files_unchanged'], 'exact_mathematical_examples_and_six_guard_tests': 'PASS', 'baseline_archive_sha256': BASELINE_SHA, 'ignored_comparison_fields': sorted(VOLATILE_KEYS), 'float_comparison': {'relative_tolerance': 1e-12, 'absolute_tolerance': 1e-15}, 'scope': 'Offline deterministic reproduction by same author; no new confirmatory experiment or independent personnel.'}
    with (work / 'REPRODUCTION.json').open('x') as f:
        json.dump(receipt, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
