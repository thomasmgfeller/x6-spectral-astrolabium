#!/usr/bin/env python3
"""German method-review report, with exact evidence and no new efficacy claim."""
from pathlib import Path
import json,hashlib
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Preformatted
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1] if HERE.parent.name=='experimental' else HERE.parent
E=HERE/'evidence/run-v0.1';R=json.loads((E/'METHOD_REVIEW.json').read_text());C=R['checks'];contract=json.loads((HERE/'REVIEW_CONTRACT.json').read_text());ind=json.loads((E/'independent-example-check.json').read_text())
font='/usr/share/fonts/truetype/dejavu/'
for name,file in [('DV','DejaVuSans.ttf'),('DV-B','DejaVuSans-Bold.ttf'),('DM','DejaVuSansMono.ttf')]:pdfmetrics.registerFont(TTFont(name,font+file))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV',boldItalic='DV-B')
INK=colors.HexColor('#173044');BLUE=colors.HexColor('#196783');GRAY=colors.HexColor('#526473');PALE=colors.HexColor('#eef4f7');LINE=colors.HexColor('#d4e0e7')
s=getSampleStyleSheet()
for name,font,size,leading,color in [('TitleR','DV-B',25,30,INK),('HeadingR','DV-B',16,21,INK),('SubR','DV-B',10.5,15,BLUE),('BodyR','DV',9.2,13.4,INK),('SmallR','DV',7.7,11,GRAY),('CellR','DV',8,11,INK),('CodeR','DM',7.5,11,INK)]:
 s.add(ParagraphStyle(name=name,fontName=font,fontSize=size,leading=leading,textColor=color,spaceAfter=10))
flow=[]
def P(t,style='BodyR'):return Paragraph(t,s[style])
def add(t,style='BodyR'):flow.append(P(t,style))
def title(t):add(t,'HeadingR')
def section(t):add(t,'SubR')
def page(t,kicker):flow.append(PageBreak());add(kicker,'SmallR');title(t)
def table(rows,widths):
 cells=[[P('<font color="white"><b>'+str(v)+'</b></font>' if i==0 else str(v),'CellR') for v in row] for i,row in enumerate(rows)]
 t=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,-1),(-1,-1),.4,LINE)]));flow.append(t);flow.append(Spacer(1,10))
def code(text):flow.append(Preformatted(text,s['CodeR']));flow.append(Spacer(1,4))
def num(x,n=6):return f'{x:.{n}f}'.replace('.',',')

add('RAX-M1 | METHODENPRÜFUNG v0.1','SmallR')
add('Was die Prüfungen<br/>tatsächlich absichern','TitleR')
add('Datenlecks, Unabhängigkeit und Aussagegrenzen<br/>Prüfgegenstand: veröffentlichter RAX-B1-Benchmark<br/>14. Oktober 2026','BodyR')
add('<b>Gesamtbefund:</b> Zwei Fehler in den Validierungsprüfungen sind reproduzierbar bestätigt. Hinzu kommen eine nachgewiesene Zugriffsgrenze der Messschnittstelle und eine Grenze der Freeze-Selbstauskunft. Die Originaldaten bestehen die strengere Vollständigkeitsprüfung und die vollständige Nachrechnung. Es ergibt sich <b>kein Anlass, die acht ursprünglichen Hauptentscheidungen zu ändern</b>: Alle bleiben unentschieden.')
table([['ID / Priorität','Befund','Wirkung auf veröffentlichtes B1'],['M1 / hoch für die Validierung','Negativer Episodenindex ermöglicht doppelte Verwendung einer Zeile trotz PASS.','Im Original nicht vorhanden; 67.584 Zellen vollständig und kanonisch.'],['M2 / mittel','Der Isolationstest verändert eine unbenutzte Prüfvariable. Ein absichtlich datenabhängiger Planer besteht.','Die volle Referenz weist den getesteten Vorhersageeingriff zurück.'],['M3 / bedingt mittel','Der Mess-Callback gibt über Introspektion noch nicht erworbene Ergebnisse frei.','Kein solcher Zugriff im eingefrorenen Planer festgestellt. Relevant für fremde Planer.'],['M4 / niedrig','Freeze meldet keine Testeinsicht, obwohl bereits Testdateien vorliegen.','Die volle Referenz erkennt im Beispiel die falsche Zeitfolge. Kein Beleg früherer Einsicht im Original.']],[85,220,202])
section('Statistische Gegenbeispiele')
add('Vollständig abhängige Wiederholungen können eine nominelle 95-%-Absicherung auf 0 % tatsächliche Überdeckung reduzieren. Das Aussieben anhand derselben Prüfdaten kann den Brier-Fehler eines unveränderten Vorhersagers von 0,41 auf 0,235534 senken. Diese Beispiele sind mathematisch exakt; sie werden <b>nicht als nachgewiesene Fehlanwendungen des ursprünglichen B1-Laufs</b> dargestellt.')
add('Prüfumfang: 36 Dateien gegen das veröffentlichte Archiv abgeglichen, vollständige Originalnachrechnung, gezielte Eingriffe ausschliesslich in Kopien, neun Prüfblöcke, separate Nachrechnung der exakten Beispiele und sechs Testmethoden für Zusatzprüfungen. Interne nachträgliche Prüfung durch denselben Autor; keine externe oder blinde Begutachtung.','SmallR')

page('M1: Doppelte Episode trotz vollständigem PASS','01 / SEMANTISCHE VALIDIERUNG')
add('In reference.py:verify wird episode_index unmittelbar als Python-Listenindex verwendet. Negative Indizes sind dort gültig: -1 bezeichnet das letzte Element. Die Duplikatprüfung verwendet dagegen den unveränderten Index als Schlüssel. Daher gelten (5631, 4, adaptiv) und (-1, 4, adaptiv) als verschieden, obwohl beide dieselbe Episode lesen.')
code("ep = episodes[episode_index]  # -1 liest letzte Episode\nkey = (episode_index, budget, policy)\n# Der Bereich 0 <= episode_index < N wird nicht geprüft.")
section('Eingriff in eine Kopie des Originaldatensatzes')
add('Die adaptive B=4-Zeile der ersten Beobachtungskontrolle wird durch eine Kopie der letzten Aussenmodell-Episode ersetzt. Deren Index wird von 5631 auf -1 gesetzt. Alle übrigen Werte entsprechen der kopierten Episode. Nur in dieser synthetisch veränderten Kopie werden Dateidigest, Länge und CPU-Summe aktualisiert.')
table([['Eigenschaft','Original','Veränderte Kopie'],['Anzahl Plan-/Budgetzeilen','67.584','67.584'],['Beobachtungskontrolle, adaptiv B=4','512 Zeilen','511 Zeilen'],['Aussenmodell, adaptiv B=4','512 Zeilen','513 Zeilen'],['Bisherige Referenz','PASS','PASS'],['Bisherige Analyse','COMPLETE','COMPLETE'],['Zusatzprüfung exakter Zellabdeckung','PASS','Zurückgewiesen: negativer Index']],[252,110,145])
add('Die acht primären mittleren Differenzen sind in diesem Beispiel unverändert, weil der Eingriff Kontrollfälle betrifft. Er belegt dennoch einen echten Fehler der Vollständigkeitsabnahme: Eine fehlende und eine doppelt verwendete Kontrollzeile werden nicht erkannt.')
section('Zusatzregel und Nachweis')
code("if type(i) is not int or not 0 <= i < N:\n    raise ValueError('invalid episode index')\nexpected = set(product(range(N), budgets, policies))\n# Prüfe kanonische Identität, Eindeutigkeit und actual == expected.")
add('hardened_checks.py enthält diese ergänzenden Regeln. Sie bestehen sämtliche 4.224 Entwicklungs- und 67.584 Testzellen der Originalkampagne. Negative/zu grosse Indizes, boolesche oder nicht ganzzahlige Indizes, Duplikate, fehlende Zellen und falsche Identitäten werden gezielt geprüft.')
add('Beleg: 02_negative_index_alias.json enthält die entfernte und eingefügte Zeile, beide Prüfergebnisse, veränderte Zellzahlen sowie SHA-256-Werte der reproduzierbaren Kopie. Neu erzeugte Prüfsummen testen die inhaltliche Validierung; sie behaupten keinen Angriff auf eine unveränderliche Git-Veröffentlichung.','SmallR')

page('M2 und M3: Datenleck-Test und Messschnittstelle','02 / DATENZUGRIFF')
section('M2: Der bisherige Isolationstest ist nicht empfindlich genug')
add('test_exact_budgets_and_holdout_isolation durchläuft zwei Werte einer lokalen Variable unrelated_challenge. Diese wird weder an den Planer übergeben noch mit einer Datenquelle verbunden, die der Planer nutzt. Die verglichenen Aufrufe unterscheiden sich deshalb nicht im wirksamen Prüfdatenzugang.')
code("for unrelated_challenge in [zeros(128), ones(128)]:\n    result = run_policy(..., measure)\n    # unrelated_challenge wird danach nicht verwendet.")
add('Der Gegenversuch ersetzt den Planer vorübergehend durch einen Adapter, der seine Vorhersage aus einer verborgenen Prüfdatenquelle übernimmt. Der bestehende Einzeltest führt 48 solche Aufrufe aus und meldet trotzdem OK. Wird dagegen die tatsächlich gelesene Quelle von null auf eins geändert, ändert sich die Vorhersage; der gezielte Zusatzversuch erkennt genau diesen Lecktyp.')
table([['Prüfweg','Originalplaner','Absichtlich datenabhängiger Planer'],['Bisheriger Einzeltest','Besteht','Besteht trotz Leck'],['Änderung der tatsächlich gelesenen Prüfquelle','Vorhersage unverändert','Vorhersage ändert sich'],['Volle Referenz auf veränderter Ergebniskopie','Original besteht','Zurückweisung: prediction replay']],[205,115,187])
add('Folgerung: Das bisherige Test-OK belegt Messbudget und Wiederholbarkeit der getesteten Aufrufe. Es ist kein Nachweis von Prüfdatenisolation. Die zusätzliche vollständige Nachrechnung verhindert im getesteten Beispiel, dass veränderte Vorhersagen unbemerkt als gültige Ergebnisse gelten.')
section('M3: Verdeckte Daten sind im selben Prozess nicht isoliert')
add('Ein zweiter Probeplaner untersucht den tatsächlich von run.acquire erzeugten Callback über __closure__. Er erreicht die Variablen banks, ei und used und liest 64 potentielle Beobachtungen der aktuellen Episode. Zu diesem Zeitpunkt sind null Messungen verbucht; das geplante Messbudget beträgt vier. Die gelesenen Werte stimmen mit der Original-Ergebnisbank überein.')
add('Der Probeversuch wird unmittelbar beendet und erzeugt keine vollständige Kampagne. Der eingefrorene Originalplaner nutzt diese Introspektion nicht; seine beobachteten Aktionen stimmen mit der separaten Referenz überein. Die Schnittstelle ist jedoch ein kooperatives Programmiermodell, keine wirksame Abschottung für fremden Code.')
add('Für austauschbare oder nicht vertrauenswürdige Planer muss der Datenhalter separat kontrolliert werden: keine Ergebnisbank, kein Prüfdaten-Seed und keine Wahrheit im Zugriff des Planerprozesses. Ein zusätzliches Zugriffsprotokoll und veränderte Prüfwelten bleiben nötig; sie sind keine universelle Sicherheitsgarantie. Belege: 03_ineffective_holdout_unit_test.json und 04_callback_future_data.json.','SmallR')

page('Unabhängigkeit: welche Zahl ist die Stichprobe?','03 / ANNAHMEN UND EXAKTE GEGENBEISPIELE')
D=C['01_sampling_units'];dep=C['06_dependence_counterexamples']
table([['Gezählte Grösse im Original','Wert','Interpretation'],['Plan-/Budgetzeilen','67.584','Zwölf gepaarte Zeilen je Episode'],['Testepisoden insgesamt','5.632','Neun Modellbedingungen plus zwei Kontrollen'],['Primäre Episoden je Kontrast','4.608','Korrekt verwendete Einheit der Hauptintervalle'],['Akquisition, über alle Läufe summiert','1.013.760','Enthält Wiederverwendung derselben Bankpositionen'],['Verschiedene verwendete Akquisitionspositionen',f"{D['distinct_acquisition_bank_positions_used']:,}".replace(',','.'),'Kein Ersatz für die Zahl unabhängiger Episoden'],['Verschiedene Prüfpositionen','720.896','128 je Episode, für zwölf Planläufe gemeinsam'],['Abgeleitete Seed-Domänen','28.832','Keine Kollision; kein Beweis statistischer Unabhängigkeit']],[240,90,177])
add('Die Originalanalyse behandelt die Messpläne gepaart und verwendet N=4.608 je Hauptkontrast. Die acht Kontraste dürfen untereinander abhängig sein: Bonferroni verwendet eine Vereinigungsabschätzung und benötigt keine Unabhängigkeit zwischen ihnen. Die Hoeffding-Schritte benötigen dagegen die deklarierte Unabhängigkeit zwischen Episoden. Unterschiedliche Seed-Namen beweisen diese Annahme nicht [1].')
section('Exaktes Beispiel A: 512 Zeilen, eine Zufallsquelle')
add('Sei Z eine faire Bernoulli-Variable und X₁ = … = X₅₁₂ = Z. Jede Zeile hat Erwartung 1/2, aber alle Zeilen hängen vollständig voneinander ab. Wer sie fälschlich als unabhängig behandelt, erhält einen 95-%-Hoeffding-Radius von '+num(dep['perfect_cluster_pseudoreplication']['incorrect_iid_95_hoeffding_radius'])+'. Der Mittelwert ist immer null oder eins, also stets 0,5 von der Wahrheit entfernt. Die tatsächliche Überdeckung beträgt exakt <b>0 %</b>.')
add('Die zwölfmalige Duplizierung der tatsächlichen B=4-Kontrastwerte lässt ihren Mittelwert unverändert und verkleinert einen naiv berechneten Standardfehler künstlich um den Faktor '+num(dep['same_difference_repeated_12_times']['artificial_precision_factor'],4)+'. B1 begeht diesen Fehler nicht; das Beispiel zeigt die Bedeutung seiner Paarungsstruktur.')
section('Exaktes Beispiel B: richtige Randverteilung, falscher Binomialtest')
add('Für eine Aktion seien Y₁ = … = Y₆₄ = Z mit P(Z=1)=1/2. Jede Einzelmessung erfüllt die Nullhypothese p=1/2. Die Summe ist aber stets 0 oder 64 und nicht binomialverteilt. Der exakte Binomialtest liefert an beiden Enden den p-Wert 2⁻⁶³ und verwirft immer: <b>100 % Fehlalarme</b> statt der vorgesehenen höchstens 0,8333 % je Aktion. Bei unabhängigen Messungen beträgt die exakt berechnete Rate hier 0,814690 % [2].')
add('Diese Konstruktionen sind Annahmen-Stresstests, keine behaupteten Abhängigkeiten der ursprünglichen B1-Daten. Die PRNG-Interpretation und die bedingte Unabhängigkeit des Generators bleiben ausdrücklich Voraussetzungen.','SmallR')

page('Gemeinsame Prüfdaten und Freeze-Selbstauskunft','04 / AUSWAHL UND ZEITREIHENFOLGE')
section('Gemeinsame Prüfung ist keine zweite unabhängige Bestätigung')
add('B1 nutzt dieselben 128 Prüfbeobachtungen einer Episode für den Brier-Score und die Kandidatenverwerfung. Beide Prüfungen sind von der Akquisition getrennt; sie sind nicht zwei voneinander unabhängige Datenbelege. Eine nachträgliche Beschränkung der Leistungsanalyse auf „bestandene“ Prüfmengen wäre eine Selektion anhand des Bewertungsdatensatzes [3].')
section('Exaktes Selektionsbeispiel ohne jede Modellverbesserung')
add('Der wahre Prozess ist Bernoulli(1/2), der feste Vorhersager meldet stets q=0,9. Er wird auf 16 unabhängigen Beobachtungen bewertet. Anschliessend werden nur Stichproben behalten, deren Binomialtest gegen q=0,9 bei 0,05/6 nicht verwirft. Das sind genau die Erfolgszahlen 11 bis 16.')
sel=C['07_holdout_selection_bias']
table([['Grösse','Exakter Wert / Ergebnis'],['Wahrscheinlichkeit, eine Prüfmenge zu behalten','6885/65536 = 10,505676 %'],['Brier vor Selektion','41/100 = 0,410000'],['Brier auf derselben, selektierten Prüfmenge','10811/45900 = 0,235534'],['Scheinbare Verbesserung','2002/11475 = 0,174466'],['Erwarteter Brier auf einer neuen unabhängigen Prüfung','41/100 = 0,410000']],[290,217])
add('Es wurde kein Modell verändert und nichts gelernt. Die günstigere Zahl entsteht ausschliesslich durch Auswahl. B1 behält verworfene Episoden in der Hauptauswertung; diese konkrete Fehlanwendung wurde dort nicht festgestellt. Der Bericht enthält zusätzlich die rein diagnostischen Werte, die ein solches falsches Aussieben im Originaldatensatz ergeben würde. Sie sind keine neuen Leistungsresultate.')
section('M4: test_outcomes_inspected=false wird nicht gemessen')
add('In einer Kopie liegen die vollständigen Testdateien bereits vor. Eine Prüfbeobachtung wird gelesen; danach wird freeze() erneut aufgerufen, nachdem ausschliesslich der kopierte alte Freeze-Vermerk entfernt wurde. Die Funktion läuft erfolgreich und schreibt dennoch test_outcomes_inspected=false.')
add('Die vollständige Referenz weist diese Kopie anschliessend zurück, weil der neue Freeze zeitlich nach dem alten Testbeginn liegt. Ein beigefügter Vorabcheck verhindert bereits den Freeze bei vorhandenen Testartefakten. Die ursprünglichen Zeitstempel sind richtig geordnet. Es gibt damit keinen Befund, dass der Originaltest vor seinem Freeze eingesehen wurde.')
add('Eine Dateiprüfung kann frühere Einsicht ausserhalb des Verzeichnisses oder eine Vorabberechnung mit dem öffentlichen deterministischen Seed nicht ausschliessen. Die Flagge muss als Selbstauskunft bezeichnet werden. Externe Präregistrierung oder Blindprüfung wurden in B1 bereits ausdrücklich nicht beansprucht. Belege: 05_freeze_attestation.json und 07_holdout_selection_bias.json.','SmallR')

page('Aussagen begrenzen und Prüfregeln ergänzen','05 / KONSEQUENZEN')
add('Die folgende Tabelle trennt Aussagen des bestehenden Befunds von unzulässigen Weiterinterpretationen. Sie unterstellt nicht, dass jede zurückgewiesene Formulierung im veröffentlichten Bericht steht.')
table([['Aussage','Methodisches Urteil'],['„Adaptiv ist bestätigt überlegen.“','Nicht gestützt. Sämtliche acht vorab festgelegten simultanen Intervalle enthalten null. Die publizierte Schlussfolgerung ist korrekt unentschieden.'],['„67.584 unabhängige Versuche.“','Falsch als Stichprobeneinheit. Es sind 5.632 Episoden mit zwölf gepaarten Zeilen; die Hauptkontraste nutzen je 4.608. B1 rechnet mit der richtigen Zahl.'],['„Der Isolationstest beweist keinen Zugriff auf Prüfdaten.“','Nicht belegt. Der konkrete Einzeltest bleibt auch beim getesteten Leck grün. Seine Aussage muss eingeschränkt werden.'],['„PASS garantiert die vollständige Episode/Budget/Plan-Abdeckung.“','Für den bisherigen Referenzprüfer widerlegt. Der strenge Zusatzprüfer erkennt das Gegenbeispiel; die Originaldaten bestehen ihn.'],['„Zweite Implementierung ist eine unabhängige Replikation.“','Nicht in personeller oder datenbezogener Hinsicht. Dieselbe Evidenz, dieselbe PRNG-Spezifikation und derselbe Autor.'],['„Gleiche Messbudgets bedeuten gleiche Gesamtrechenkosten.“','Nicht gestützt. Gleiche Messzahlen und Obergrenzen; Voraberzeugung der Zufallspläne und Datenbanken liegt ausserhalb der Online-Zeitmessung.'],['„Synthetische Ergebnisse bestätigen physikalische Modelle.“','Nicht gestützt. Kein neuer U2-Lauf und keine physikalischen Messdaten in dieser Prüfung.']],[225,282])
section('Konkrete Folgerungen nach Priorität')
add('<b>1. Vor weiterer automatisierter Abnahme:</b> Indexbereich/-typ und exakte kartesische Zellabdeckung prüfen. Der ausführbare Zusatzprüfer liegt bei und wurde gegen Original und Gegenbeispiele getestet. Er verändert keine eingefrorenen B1-Dateien.')
add('<b>2. Vor der nächsten Datenleck-Abnahme:</b> Die tatsächlich zugängliche Prüfdatenquelle variieren und absichtlich datenabhängige Testplaner einsetzen. Wiederholbarkeit allein genügt nicht. Die nachgerechneten Aktions- und Posteriorregeln beibehalten.')
add('<b>3. Vor fremden Planern:</b> Datenhalter und Planerausführung mit einer wirksamen Zugriffstrennung betreiben. Der vorliegende Callback soll nicht als Sandbox bezeichnet werden. Diese Prozessarchitektur wurde hier nicht implementiert oder zertifiziert.')
add('<b>4. Für weitere statistische Läufe:</b> Episodenpaarung und Datentrennung bewahren; keine Prüfung bestandener Teilmengen als neue unverzerrte Leistung berichten. Bei realen korrelierten Daten die unabhängige Einheit vorab definieren. Änderungen der Bestätigungskriterien erfordern eine neue Kampagne.')
add('Die Methodenprüfung liefert eine Ergänzung und Korrektur der Prüfinterpretation. Sie wertet die ursprünglichen unentschiedenen Ergebnisse weder zu einem Erfolg noch zu einem Misserfolg um.','SmallR')

page('Belegkette, Reproduktion und Quellen','06 / REPRODUZIERBARKEIT')
add('Geprüfte Veröffentlichung','SubR')
add('GitHub-Commit: '+contract['publication_commit']+'<br/>B1-Quell-Freeze: '+contract['source_freeze_commit']+'<br/>B1-Ergebnisstand: '+contract['source_results_commit']+'<br/>Kampagne der Methodenprüfung: '+R['review'],'SmallR')
add('Veröffentlichter B1-Archivdigest (SHA-256):<br/>'+contract['published_zip_sha256'],'SmallR')
add('Alle 36 Benchmarkdateien wurden mit dem Inhalt dieses Archivs verglichen. Vor und nach den Gegenversuchen blieben ihre SHA-256-Werte gleich. Die Rohdaten wurden vollständig erneut nachgerechnet. Die semantische Zusatzprüfung bestätigt sämtliche Zellen beider Originalpartitionen. Alle Angriffe erfolgten auf temporären Kopien oder vorübergehend ersetzten Funktionsbindungen und wurden zurückgenommen.')
section('Lieferumfang und Befehle')
add('Das Belegpaket enthält den unveränderten veröffentlichten B1-ZIP als Basis, Methodenvertrag, ausführbare Gegenbeispiele, ergänzende Prüfregeln, sämtliche Ergebnis-JSONs, die separate Beispielsprüfung, diesen Bericht und ein SHA-256-Inventar. Die grossen veränderten Kopien werden aus den dokumentierten Rezepten regeneriert; relevante ersetzte Einzelzeilen und Digests sind mitgeliefert.')
code('python verify_package.py\npython reproduce.py --workdir ../new-reproduction')
add('Der Zielordner muss neu sein. Der Einstieg prüft das Basisarchiv, entpackt es sicher, führt die neun Auditblöcke aus und prüft die mathematischen Beispiele sowie die Zusatzregeln erneut. Benötigt: Linux/POSIX, Git, Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0. Ein lokaler Reproduktions-Checkout wird angelegt; es erfolgt kein Upload. Zeitstempel und Laufzeiten variieren; die Befunde und exakten Werte sind reproduzierbar. Die erneute Ausführung ist eine Nachrechnung, keine neue Bestätigungskampagne.')
add('Die exakten statistischen Beispiele wurden zusätzlich ohne Import des ursprünglichen Planers oder Binomialprüfers gegen SciPy-Gates und rationale Summen gerechnet. Sechs gezielte Testmethoden für die Zusatzregeln bestanden. Diese zweite Rechenstrecke stammt ebenfalls vom selben Autor.','SmallR')
section('Methodische Primärquellen')
add('[1] Hoeffding, W. (1963). <i>Probability Inequalities for Sums of Bounded Random Variables.</i> JASA 58(301), 13-30. Voraussetzungen der verwendeten Konzentrationsabschätzung.<br/><link href="https://doi.org/10.1080/01621459.1963.10500830" color="#196783">doi:10.1080/01621459.1963.10500830</link>','SmallR')
add('[2] SciPy, <i>Binomial Distribution</i>, offizielle Dokumentation. Die Binomialverteilung beschreibt die Summe unabhängiger Bernoulli-Versuche. Die Prüfung selbst verwendete die installierte SciPy-Version 1.17.0.<br/><link href="https://docs.scipy.org/doc/scipy/tutorial/stats/discrete_binom.html" color="#196783">docs.scipy.org/doc/scipy/tutorial/stats/discrete_binom.html</link>','SmallR')
add('[3] Dwork, C.; Feldman, V.; Hardt, M.; Pitassi, T.; Reingold, O.; Roth, A. (2015). <i>Generalization in Adaptive Data Analysis and Holdout Reuse.</i> NeurIPS 28. Hintergrund zur adaptiven Wiederverwendung von Prüfdaten; hier kein Einsatz oder Nachweis des dortigen Verfahrens.<br/><link href="https://proceedings.neurips.cc/paper/2015/hash/bad5f33780c42f2588878a9d07405083-Abstract.html" color="#196783">NeurIPS 2015: Generalization and Holdout Reuse</link>','SmallR')
add('Die Programmfehler und Zahlen dieses Berichts beruhen auf den mitgelieferten eigenen Reproduktionen. Die Fachquellen begründen die methodischen Voraussetzungen; sie bestätigen nicht die konkrete Software. Der frühere U1-Archivvorfall wird nicht neu diagnostiziert, und Stromausfallsicherheit wird nicht beansprucht.','SmallR')

def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(LINE);canvas.line(44,39,A4[0]-44,39);canvas.setFont('DV',7);canvas.setFillColor(GRAY);canvas.drawString(44,26,'RAX-M1 · Methodenprüfung v0.1 · Interne nachträgliche Prüfung');canvas.drawRightString(A4[0]-44,26,str(doc.page));canvas.restoreState()
out=ROOT/'output/pdf/RAX_M1_Methodenpruefung_v0_1.pdf';out.parent.mkdir(parents=True,exist_ok=True)
doc=SimpleDocTemplate(str(out),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=38,bottomMargin=50,title='RAX-M1 Methodenprüfung v0.1',author='RAX/X6 - Methodenprüfung mit Codex',pageCompression=1)
doc.build(flow,onFirstPage=footer,onLaterPages=footer);print(out)
