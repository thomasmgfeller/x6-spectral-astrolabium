#!/usr/bin/env python3
"""Separate check of exact statistical examples and supplemental guard behavior.
Does not import audit.py, the B1 planner, or the B1 binomial implementation.
"""
import argparse,copy,json,math,statistics,tempfile,unittest
from fractions import Fraction as F
from pathlib import Path
from scipy.stats import binomtest
from hardened_checks import validate_row_coverage,freeze_preflight

class GuardTests(unittest.TestCase):
    def setUp(self):
        self.c={'test_replicates_per_stratum':2,'strata':[{'id':'s','kind':'IN_MODEL'}],'budgets':[4,8],'policies':['a','f','r']}
        self.e=[{'index':i,'id':f'test:0:{i}'} for i in range(2)]
        self.r=[{'episode_index':i,'episode_id':f'test:0:{i}','stratum':'s','kind':'IN_MODEL','replicate':i,'budget':b,'policy':p} for i in range(2) for b in [4,8] for p in ['a','f','r']]
    def check_rows(self,rs):return validate_row_coverage(self.c,self.e,rs,'test')
    def test_complete_coverage(self):self.assertEqual(self.check_rows(self.r)['exact_cartesian_cells'],12)
    def test_bad_index_types_and_ranges(self):
        for value in [-1,2,True,0.0,'0']:
            rs=copy.deepcopy(self.r);rs[0]['episode_index']=value
            with self.assertRaises(ValueError):self.check_rows(rs)
    def test_duplicate_replaces_missing(self):
        rs=copy.deepcopy(self.r);rs[0]=copy.deepcopy(rs[1])
        with self.assertRaises(ValueError):self.check_rows(rs)
    def test_missing_cell(self):
        with self.assertRaises(ValueError):self.check_rows(self.r[:-1])
    def test_wrong_identity(self):
        rs=copy.deepcopy(self.r);rs[0]['episode_id']='test:0:1'
        with self.assertRaises(ValueError):self.check_rows(rs)
    def test_existing_test_artifact(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(freeze_preflight(tmp)['status'],'PASS')
            (Path(tmp)/'test').mkdir()
            with self.assertRaises(ValueError):freeze_preflight(tmp)


def verify(evidence):
    e=Path(evidence);dep=json.loads((e/'06_dependence_counterexamples.json').read_text());sel=json.loads((e/'07_holdout_selection_bias.json').read_text())
    accepted=[k for k in range(17) if binomtest(k,16,.9).pvalue>.05/6]
    assert accepted==sel['accepted_success_counts']
    weights=[F(math.comb(16,k),65536) for k in range(17)]
    q=F(9,10);scores=[(k*(1-q)**2+(16-k)*q**2)/16 for k in range(17)]
    acceptance=sum(weights[k] for k in accepted);risk=sum(w*s for w,s in zip(weights,scores));selected=sum(weights[k]*scores[k] for k in accepted)/acceptance
    for key,value in [('acceptance_probability',acceptance),('unconditional_brier',risk),('conditional_same_sample_brier',selected),('fresh_independent_evaluation_expected_brier',risk)]:assert F(sel[key]['fraction'])==value
    null_error=sum(F(math.comb(64,k),2**64) for k in range(65) if binomtest(k,64,.5).pvalue<=1/120)
    assert F(dep['dependent_binomial']['iid_exact_false_rejection_probability']['fraction'])==null_error
    actual_correlated_rejection=sum(F(1,2) for z in [0,1] if binomtest(64*z,64,.5).pvalue<=1/120)
    assert actual_correlated_rejection==1
    radius=math.sqrt(math.log(40)/1024)
    coverage=sum(F(1,2) for z in [0,1] if abs(z-.5)<=radius);assert coverage==0
    duplication_factor=math.sqrt((12*4608-1)/(4608-1));assert math.isclose(duplication_factor,dep['same_difference_repeated_12_times']['artificial_precision_factor'],rel_tol=1e-14)
    return {'status':'PASS','exact_selection_bias_checked_against_scipy_gate':True,'exact_dependent_binomial_checked':True,'zero_coverage_counterexample_checked':True,'duplication_precision_factor_checked':True,'selection_risk':str(selected),'iid_type1_error':str(null_error),'scope':'Second implementation by same author; no independent personnel or new statistical experiment.'}

if __name__=='__main__':
    import io
    parser=argparse.ArgumentParser();parser.add_argument('evidence',type=Path);args=parser.parse_args()
    result=verify(args.evidence);log=io.StringIO();tests=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GuardTests));assert tests.wasSuccessful()
    result.update({'guard_test_methods':tests.testsRun,'guard_tests_passed':True,'test_log':log.getvalue()})
    path=args.evidence/'independent-example-check.json'
    with path.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result,indent=2))
