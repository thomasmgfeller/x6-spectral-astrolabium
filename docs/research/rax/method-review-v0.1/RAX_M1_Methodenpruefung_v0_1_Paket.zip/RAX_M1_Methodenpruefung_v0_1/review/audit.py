#!/usr/bin/env python3
"""RAX-M1 post-hoc adversarial methods review. Only copied fixtures are mutated.
Original baseline source files, data, freeze records and conclusions stay intact.
"""
import argparse,ast,contextlib,copy,hashlib,io,json,math,random,shutil,statistics,sys,tempfile,time,unittest
from collections import Counter,defaultdict
from datetime import datetime,timezone
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.stats import binomtest
from hardened_checks import validate_row_coverage,freeze_preflight

HERE=Path(__file__).resolve().parent

def load(p):return json.loads(Path(p).read_text())
def rows_at(p):return [json.loads(x) for x in Path(p).read_text().splitlines()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def as_fraction(x):return {'fraction':str(x),'decimal':float(x)}
def rejected(fn):
    try:fn()
    except (ValueError,FileExistsError,KeyError) as e:return {'rejected':True,'exception':type(e).__name__,'reason':str(e)}
    return {'rejected':False}


def main(base,out):
    base=Path(base).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(base))
    import core,run,reference,analyze,test_benchmark
    from storage import encoded,write_once,verify_complete
    e=base/'evidence/campaign-v0.1';c=load(e/'contract.json');episodes=load(e/'test/episodes.json');rows=rows_at(e/'test/records.jsonl');analysis=load(e/'analysis.json')
    originals={str(p.relative_to(base)):sha(p) for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    results={'review':'RAX-M1-20261014-001','started_utc':datetime.now(timezone.utc).isoformat(),'scope':'RAX-B1 published benchmark; internal post-hoc review','checks':{}}
    def save(name,value):
        write_once(out/(name+'.json'),encoded(value));results['checks'][name]=value
        print(json.dumps({'check':name,'status':value.get('status','RECORDED')}),flush=True)
    for phase in ['development','test']:verify_complete(e/phase)
    coverage={phase:validate_row_coverage(c,load(e/phase/'episodes.json'),rows_at(e/phase/'records.jsonl'),phase) for phase in ['development','test']}
    result=reference.verify(e,'test');assert result['status']=='PASS'
    save('00_original_replay',{'status':'PASS','coverage':coverage,'full_reference':result,'primary_decisions':Counter(x['confirmatory_result'] for x in analysis['primary']['contrasts'])})

    # Shared streams are keyed by exact episode and purpose, NOT by unique observed values.
    identities=[];seed_values=[];phase_sets={};used_max=defaultdict(int)
    for phase in ['development','test']:
        ids=[]
        for si,s in enumerate(c['strata']):
            A=1 if s['kind']=='UNIDENTIFIABLE_CONTROL' else 2
            for rep in range(c[phase+'_replicates_per_stratum']):
                eid=f'{phase}:{si}:{rep}';ids.append(eid)
                for domain in ['acquisition','challenge']:
                    for action in range(A):
                        key=(phase,eid,domain,action);identities.append(key);seed_values.append(run.seed(c,*key))
                key=(phase,eid,'random_plan');identities.append(key);seed_values.append(run.seed(c,*key))
        phase_sets[phase]=set(ids)
    for r in rows:
        for action,n in enumerate(r['action_counts']):used_max[(r['episode_index'],action)]=max(used_max[(r['episode_index'],action)],n)
    primary=[r for r in rows if r['kind']=='IN_MODEL'];by_key={(r['episode_index'],r['budget'],r['policy']):r for r in rows}
    leakage_names=['inspect','__closure__','__globals__','getframe','challenge','holdout','truth','random','seed','open']
    planner_tree=ast.parse((base/'core.py').read_text());planner_fn=next(n for n in planner_tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_policy')
    referenced_names={n.id for n in ast.walk(planner_fn) if isinstance(n,ast.Name)};attributes={n.attr for n in ast.walk(planner_fn) if isinstance(n,ast.Attribute)}
    save('01_sampling_units',{'status':'PASS_WITH_SCOPE','development_test_episode_overlap':len(phase_sets['development']&phase_sets['test']),'seed_domains':len(identities),'distinct_seed_values':len(set(seed_values)),'seed_collision_count':len(seed_values)-len(set(seed_values)),'total_test_policy_rows':len(rows),'test_episodes':len(episodes),'primary_paired_episodes':len({r['episode_index'] for r in primary}),'primary_rows':len(primary),'rows_per_episode':dict(Counter(Counter(r['episode_index'] for r in rows).values())),'acquisition_observations_summed_over_runs':sum(r['acquired'] for r in rows),'distinct_acquisition_bank_positions_used':sum(used_max.values()),'distinct_challenge_positions_used':len(episodes)*128,'challenge_reuses_per_episode':12,'forbidden_introspection_or_data_names_used_by_planner':sorted((referenced_names|attributes)&set(leakage_names)),'scope':'Disjoint identifiers and deterministic stream replay are verified; statistical PRNG independence remains an assumption, not established by this count.'})

    def clone(tmp,name):
        dst=Path(tmp)/name;shutil.copytree(e,dst);return dst
    def rewrite_records(case,rs):
        (case/'test/records.jsonl').write_bytes(b''.join(encoded(r) for r in rs))
        meta=load(case/'test/COMPLETE.json')
        for name in meta['files']:
            path=case/'test'/name;meta['files'][name]={'bytes':path.stat().st_size,'sha256':sha(path)}
        meta['output_payload_bytes']=sum(v['bytes'] for name,v in meta['files'].items() if name!='RUN_STARTED.json')
        meta['online_cpu_seconds']=sum(r['cpu_ns']/1e9 for r in rs)
        (case/'test/COMPLETE.json').write_bytes(encoded(meta))
        return meta

    with tempfile.TemporaryDirectory(prefix='rax-m1-mutants-') as temp:
        # A negative Python index aliases the last episode while bypassing the positive-key seen set.
        case=clone(temp,'alias');rs=copy.deepcopy(rows)
        victim_i=next(i for i,r in enumerate(rs) if r['stratum']=='observational_only' and r['replicate']==0 and r['budget']==4 and r['policy']=='adaptive_eig')
        donor=next(r for r in rs if r['episode_index']==len(episodes)-1 and r['budget']==4 and r['policy']=='adaptive_eig')
        victim=rs[victim_i];replacement=copy.deepcopy(donor);replacement['episode_index']=-1;rs[victim_i]=replacement
        rewrite_records(case,rs);weak=reference.verify(case,'test');assert weak['status']=='PASS'
        (case/'test-reference.json').write_bytes(encoded(weak));mutated_analysis=analyze.analyze(case)
        strong=rejected(lambda:validate_row_coverage(c,episodes,rs,'test'));assert strong['rejected']
        changed_cells=[{'group':x['group'],'n':x['n'],'brier':x['brier_mean']} for x in mutated_analysis['all_cells'] if x['budget']==4 and x['policy']=='adaptive_eig' and x['group'].startswith('control:')]
        assert [x['mean_brier_difference'] for x in mutated_analysis['primary']['contrasts']]==[x['mean_brier_difference'] for x in analysis['primary']['contrasts']]
        save('02_negative_index_alias',{'status':'DEFECT_REPRODUCED','severity':'HIGH for validator acceptance of complete data; absent in published records','mutation':'Replace observational-only episode 0 / B4 / adaptive row with a copy of the last outside-model row, changing only its index to -1; recompute copied checksums and CPU total.','removed_record':victim,'inserted_record':replacement,'weak_reference':weak,'analysis_returned':mutated_analysis['status'],'changed_control_cells':changed_cells,'primary_mean_differences_unchanged':True,'hardened_guard':strong,'fixture_records_sha256':sha(case/'test/records.jsonl'),'fixture_complete_sha256':sha(case/'test/COMPLETE.json'),'original_negative_indices':sum(r['episode_index']<0 for r in rows),'note':'All checksum edits concern a synthetic copied fixture. This is a semantic validation flaw, not a bypass of an external signature.'})
        shutil.rmtree(case)

        # Existing unit test changes an unused local array, not a heldout source used by the planner.
        original=core.run_policy;hidden={'holdout':[0]*128};calls=[]
        def leaky(*args,**kwargs):
            r=original(*args,**kwargs);r['prediction']=[statistics.mean(hidden['holdout'])]*len(r['prediction']);calls.append(1);return r
        core.run_policy=leaky
        try:
            log=io.StringIO();suite=unittest.TestSuite([test_benchmark.BenchmarkGates('test_exact_budgets_and_holdout_isolation')]);unit=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
        finally:core.run_policy=original
        assert unit.wasSuccessful()
        def trial(fn,heldout):
            hidden['holdout']=heldout;count=[0]
            def measure(action):count[0]+=1;return int(count[0]%3!=0)
            return fn('adaptive_eig',core.table('1/10'),8,[4,4],[0,1]*4,measure)
        sensitive=trial(leaky,[0]*128)['prediction']!=trial(leaky,[1]*128)['prediction']
        clean_invariant=trial(original,[0]*128)==trial(original,[1]*128)
        case=clone(temp,'prediction_leak');rs=copy.deepcopy(rows);r=rs[0];ep=episodes[r['episode_index']];r['prediction']=[x/ep['challenge_n_per_action'] for x in ep['challenge_counts']]
        rewrite_records(case,rs);full_rejection=rejected(lambda:reference.verify(case,'test'));assert full_rejection['rejected'] and full_rejection['reason']=='prediction replay'
        save('03_ineffective_holdout_unit_test',{'status':'DEFECT_REPRODUCED','severity':'MEDIUM; full reference compensates for altered predictions in the supplied mutant','unit_test_passed_with_leaky_planner':unit.wasSuccessful(),'leaky_planner_calls_in_unit_test':48,'unit_log':log.getvalue(),'actual_hidden_holdout_intervention_detects_leak':sensitive,'clean_planner_passes_actual_intervention':clean_invariant,'whole_reference_rejects_leaked_prediction_fixture':full_rejection,'fixture_records_sha256':sha(case/'test/records.jsonl'),'mechanism':'unrelated_challenge is assigned but never passed to or read by the invoked planner; the test establishes repeatability for those calls, not holdout isolation.'})
        shutil.rmtree(case)

        # Inspect the ACTUAL acquisition callback, stopping before any observation is charged.
        case=clone(temp,'callback_probe');shutil.rmtree(case/'test');captured={}
        class ProbeFinished(Exception):pass
        def probe(policy,probabilities,budget,allocation,random_plan,measure):
            contents={name:cell.cell_contents for name,cell in zip(measure.__code__.co_freevars,measure.__closure__)}
            bank=contents['banks'];ei=contents['ei'];used=contents['used']
            captured.update({'free_variable_names':sorted(contents),'charged_before_read':sum(used),'episode_index':ei,'accessible_current_episode_outcomes':bank[ei].astype(int).tolist(),'accessible_potential_outcomes':int(bank[ei].size),'budget':budget})
            raise ProbeFinished()
        core.run_policy=probe
        try:
            try:run.acquire(case,'test')
            except ProbeFinished:pass
        finally:core.run_policy=original
        assert captured['charged_before_read']==0 and captured['accessible_potential_outcomes']==64
        np.testing.assert_array_equal(captured['accessible_current_episode_outcomes'],np.load(e/'test/acquisition.npy',allow_pickle=False)[0])
        save('04_callback_future_data',{'status':'EXPOSURE_REPRODUCED','severity':'MEDIUM for extension to untrusted/replaced planners; no such access found in current core.run_policy','probe':captured,'probe_produced_complete_campaign':(case/'test/COMPLETE.json').exists(),'interpretation':'The cooperative callback API is not an isolation boundary. Same-process introspection exposes unacquired potential outcomes. This does not show that the published planner accessed them.','correction':'For untrusted planners, use a separately controlled measurement service/process with no bank, seed or truth accessible to the planner; trace replay remains useful but does not certify isolation.'})
        shutil.rmtree(case)

        # Presence of an existing test is not checked by freeze() itself.
        case=clone(temp,'freeze_after_test');(case/'freeze.json').unlink()
        inspected=int(np.load(case/'test/challenge.npy',allow_pickle=False)[0,0,0]);stream=io.StringIO()
        with contextlib.redirect_stdout(stream):run.freeze(case)
        f=load(case/'freeze.json');later_rejection=rejected(lambda:reference.verify(case,'test'));strict=rejected(lambda:freeze_preflight(case))
        assert f['test_outcomes_inspected'] is False and later_rejection['rejected'] and strict['rejected']
        save('05_freeze_attestation',{'status':'LIMIT_REPRODUCED','severity':'LOW phase-local guard weakness; existing reference chronology check rejects this fixture','existing_test_was_read_before_freeze':True,'observed_first_bit':inspected,'freeze_reported_test_outcomes_inspected':f['test_outcomes_inspected'],'freeze_returned_success':True,'reference_rejection':later_rejection,'supplemental_preflight_rejection':strict,'original_freeze_before_test':load(e/'freeze.json')['created_utc']<load(e/'test/RUN_STARTED.json')['started_utc'],'interpretation':'The Boolean is an attestation, not measured blindness. Even absence of visible files cannot exclude prior external calculation with the public deterministic seed.'})

    # Exact dependent-data constructions: no Monte Carlo or selective choice of seeds.
    N=512;radius=math.sqrt(math.log(2/.05)/(2*N));gate=core.binomial_rejection_mask(64,F(1,2),1,120)
    assert gate[0] and gate[-1] and radius<.5
    iid_reject=sum(F(math.comb(64,k),2**64) for k,reject in enumerate(gate) if reject)
    oldN=analysis['primary']['n_independent_in_model_episodes'];family_radius=math.sqrt(2*math.log(16/.05)/oldN)
    epi_ids=[ep['index'] for ep in episodes if ep['kind']=='IN_MODEL'];d=np.array([by_key[(i,4,'adaptive_eig')]['brier']-by_key[(i,4,'fixed_optimal')]['brier'] for i in epi_ids]);dup=np.repeat(d,12)
    naive_se=float(d.std(ddof=1)/math.sqrt(len(d)));dup_se=float(dup.std(ddof=1)/math.sqrt(len(dup)))
    save('06_dependence_counterexamples',{'status':'EXACT_COUNTEREXAMPLES','original_primary_episode_count_correct':oldN==4608,'same_difference_repeated_12_times':{'original_n':len(d),'duplicated_rows':len(dup),'mean_unchanged':float(dup.mean()-d.mean()),'unstratified_naive_se_original':naive_se,'incorrect_duplicate_se':dup_se,'artificial_precision_factor':naive_se/dup_se,'note':'SE demonstration only; B1 uses stratified paired SE and does NOT make this duplication mistake.'},'perfect_cluster_pseudoreplication':{'model':'Z ~ Bernoulli(1/2); X1=...=X512=Z','marginal_mean':.5,'rows':512,'independent_units':1,'incorrect_iid_95_hoeffding_radius':radius,'actual_coverage_of_wrong_interval':0.0,'exact_reason':'The sample mean is always 0 or 1, each at distance 0.5 from the true mean, while the interval radius is smaller than 0.5.'},'dependent_binomial':{'model':'For each action, Y1=...=Y64=Z with Z~Bernoulli(1/2). Across actions Z can be independent.','true_class':'common_cause p=(1/2,1/2)','per_action_nominal_alpha':1/120,'iid_exact_false_rejection_probability':as_fraction(iid_reject),'dependent_exact_false_rejection_probability':1.0,'extreme_binomial_p_value':str(F(1,2**63)),'scope':'Same Bernoulli marginals, different dependence; not a flaw shown in the actual B1 PRNG data.'},'valid_B1_hoeffding_family_radius':family_radius,'incorrect_radius_using_all_67584_rows':math.sqrt(2*math.log(16/.05)/67584),'bonferroni_requires_independent_contrasts':False})

    # Selection on the evaluation sample creates a favorable conditional Brier score.
    n=16;true_p=F(1,2);q=F(9,10);reject_mask=core.binomial_rejection_mask(n,q,1,120)
    probs=[F(math.comb(n,k),2**n) for k in range(n+1)];scores=[q*q-2*q*F(k,n)+F(k,n) for k in range(n+1)]
    accepted=[k for k,reject in enumerate(reject_mask) if not reject];accept_prob=sum(probs[k] for k in accepted);unconditional=sum(p*s for p,s in zip(probs,scores));conditional=sum(probs[k]*scores[k] for k in accepted)/accept_prob
    assert conditional<unconditional
    filtered=[]
    for budget in c['budgets']:
        for policy in c['policies']:
            rs=[r for r in primary if r['budget']==budget and r['policy']==policy];kept=[r for r in rs if not r['selected_model_rejected']]
            filtered.append({'budget':budget,'policy':policy,'all_n':len(rs),'kept_n':len(kept),'all_brier':statistics.mean(r['brier'] for r in rs),'hypothetical_filtered_brier':statistics.mean(r['brier'] for r in kept)})
    save('07_holdout_selection_bias',{'status':'EXACT_COUNTEREXAMPLE','model':{'n':n,'true_p':str(true_p),'prediction_q':str(q),'filter':'keep the same heldout sample only if exact binomial test against q does not reject at .05/6'},'accepted_success_counts':accepted,'acceptance_probability':as_fraction(accept_prob),'unconditional_brier':as_fraction(unconditional),'conditional_same_sample_brier':as_fraction(conditional),'apparent_improvement_from_selection':as_fraction(unconditional-conditional),'fresh_independent_evaluation_expected_brier':as_fraction(unconditional),'B1_hypothetical_filter_diagnostic':filtered,'original_B1_did_filter':False,'interpretation':'Performance and candidate-falsification gates share the same heldout observations. They are held out from acquisition, but not mutually independent corroborations. B1 retains rejected episodes and does not apply this selection.'})

    # Source-backed claim matrix, not new significance tests or a physical validation.
    claim_checks=[
      {'claim':'All 67,584 rows are independent trials','verdict':'UNSUPPORTED if said','reason':'5,632 episodes with twelve paired policy/budget rows each; the primary contrast uses 4,608 in-model episodes.'},
      {'claim':'The original primary paired sample size and Bonferroni handling are correct','verdict':'SUPPORTED WITH ASSUMPTIONS','reason':'Episode count is correct; Bonferroni does not require independence between the eight contrasts. Independence between generated episodes is assumed.'},
      {'claim':'The published data-leak unit test proves isolation','verdict':'NOT ESTABLISHED','reason':'Injected holdout-dependent predictions pass that unit test; the separate full replay rejects the tested altered prediction.'},
      {'claim':'The complete-reference PASS guarantees exact Cartesian cell coverage','verdict':'FALSE FOR CURRENT VERIFIER','reason':'The negative-index alias mutant passes and changes control cell counts to 511 and 513.'},
      {'claim':'Adaptive planning was confirmed superior','verdict':'UNSUPPORTED','reason':'All eight prespecified simultaneous intervals include zero; published final conclusion correctly remains inconclusive.'},
      {'claim':'Equal measurement budgets imply equal total computational cost','verdict':'UNSUPPORTED','reason':'B1 fixes measurement counts and upper caps. Random-plan and data-bank generation are outside the online timing window.'},
      {'claim':'Independent implementation equals independent data or external replication','verdict':'UNSUPPORTED','reason':'Reference computation uses the same synthetic evidence and PRNG specification and was written by the same author.'},
      {'claim':'Freeze metadata proves no earlier test inspection','verdict':'NOT ESTABLISHED','reason':'The flag is a self-attestation; source publication discloses no external preregistration or blind review.'},
      {'claim':'The review invalidates the eight original numerical primary contrasts','verdict':'NO EVIDENCE FOR THIS','reason':'Original coverage and full replay pass. Defects were reproduced in synthetic mutants, not found in the original evidence.'},
    ]
    save('08_claims',{'status':'CLAIMS_BOUNDED','matrix':claim_checks,'current_artifacts_already_disclose':['synthetic control only','all eight confirmatory decisions inconclusive','not RAX-U2','not physical evidence','not external/blind review','runtime limits and timing boundaries','PRNG independence assumed'],'required_corrections':['Scope the holdout-unit-test PASS to repeatability/budget checks until replaced.','Add strict index range/type and exact episode-budget-policy coverage validation.','Describe callback hiding as a cooperative API property; use a separate trust boundary for external planners.','Treat test_outcomes_inspected as an attestation and reject known post-test freezes.','Continue to report paired episode counts, shared holdout use and all rejected episodes.']})
    for name,digest in originals.items():assert sha(base/name)==digest,('original modified',name)
    results.update({'status':'COMPLETED_WITH_METHOD_FINDINGS','finished_utc':datetime.now(timezone.utc).isoformat(),'original_files_unchanged':len(originals),'original_primary_decisions_changed':False,'external_or_blind_review':False,'corrective_guards_are_supplemental':True,'audit_script_sha256':sha(__file__),'guard_script_sha256':sha(HERE/'hardened_checks.py')})
    write_once(out/'METHOD_REVIEW.json',encoded(results));print(json.dumps({'status':results['status'],'checks':len(results['checks']),'original_files_unchanged':len(originals)},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,default=HERE.parent/'measurement_plan_benchmark');p.add_argument('--output',type=Path,required=True);args=p.parse_args();main(args.baseline,args.output)
