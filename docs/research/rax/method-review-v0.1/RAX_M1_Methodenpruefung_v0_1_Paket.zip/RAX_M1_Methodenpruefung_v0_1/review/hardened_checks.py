"""Supplemental guards for RAX-M1. Frozen RAX-B1 sources are unchanged.
These checks strengthen record coverage and obvious phase-order checks; they
are NOT an isolation sandbox or proof that a person never inspected test data.
"""
from itertools import product
from pathlib import Path


def validate_row_coverage(contract,episodes,rows,phase):
    repeats=contract[phase+'_replicates_per_stratum'];N=repeats*len(contract['strata'])
    if len(episodes)!=N:raise ValueError('episode count')
    expected=set(product(range(N),contract['budgets'],contract['policies']));actual=set()
    for r in rows:
        i=r.get('episode_index')
        if type(i) is not int or not 0<=i<N:raise ValueError('episode_index must be an integer in [0,N)')
        e=episodes[i];si,rep=divmod(i,repeats);s=contract['strata'][si]
        if e['index']!=i or e['id']!=f'{phase}:{si}:{rep}':raise ValueError('episode identity')
        if r['episode_id']!=e['id'] or r['stratum']!=s['id'] or r['kind']!=s['kind'] or r['replicate']!=rep:raise ValueError('canonical row identity')
        if type(r['budget']) is not int:raise ValueError('budget type')
        key=(i,r['budget'],r['policy'])
        if key not in expected:raise ValueError('unexpected policy/budget cell')
        if key in actual:raise ValueError('duplicate canonical cell')
        actual.add(key)
    if actual!=expected:raise ValueError('missing policy/budget cells')
    return {'status':'PASS','episodes':N,'exact_cartesian_cells':len(actual),'all_indices_canonical':True}


def freeze_preflight(output):
    output=Path(output)
    if any((output/n).exists() for n in ['test','test-reference.json','analysis.json']):
        raise ValueError('test artifacts already exist; cannot attest a pre-test freeze')
    return {'status':'PASS','scope':'only visible artifact absence; not proof of blindness'}
