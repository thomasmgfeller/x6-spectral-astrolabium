# RAX-M1 Methodenprüfung v0.1

Prüfgegenstand: der veröffentlichte RAX-B1-Benchmark am GitHub-Commit
`564f694378c8429e40b51e67c6fd437b5a6c8a99`, einschliesslich der im ZIP enthaltenen
36 Benchmark-, Daten- und Prüfdateien. Die Originaldateien wurden nicht geändert.
Dies ist eine interne nachträgliche Methodenprüfung, keine externe Blindprüfung.

## Ergebnis

- M1: Der Referenzprüfer akzeptiert einen negativen Episodenindex als Alias der
  letzten Episode. In einer synthetisch veränderten Kopie fehlen dadurch eine
  Kontrollzeile und eine andere wird doppelt verwendet. Referenz und Analyse
  melden dennoch PASS/COMPLETE; Kontrollzellen enthalten 511 bzw. 513 statt 512
  Zeilen. Die Originaldaten haben vollständige kanonische Abdeckung.
- M2: Der bisherige Holdout-Isolationstest verändert eine unbenutzte Variable.
  Ein absichtlich holdoutabhängiger Planer besteht diesen Einzeltest. Die
  vollständige separate Referenz erkennt die getestete Vorhersage-Manipulation.
- M3: Durch Python-Introspektion auf den tatsächlichen Mess-Callback lassen sich
  64 potentielle Beobachtungen vor der ersten verbuchten Messung lesen. Der
  eingefrorene Planer nutzt diesen Zugriff nicht; die API ist keine Sandbox für
  fremde Planer. Ein auf Quellen gehashter Lauf ist kein Schutz gegen beliebige
  Laufzeitänderungen im gleichen Prozess.
- M4: freeze() schreibt die Selbstauskunft test_outcomes_inspected=false auch bei
  bereits vorhandenen und eingesehenen Testdateien. Die vollständige Referenz
  weist diesen Versuch später wegen falscher Zeitreihenfolge zurück. Metadaten
  beweisen keine Blindheit; der öffentliche Seed erlaubt Vorabberechnungen.

Die Hauptauswertung verwendet korrekt 4.608 gepaarte Episoden je Kontrast.
Bonferroni verlangt keine Unabhängigkeit zwischen den acht Kontrasten. Die
Unabhängigkeit zwischen Episoden bzw. innerhalb binomialer Messreihen bleibt
eine Annahme des Generatormodells. Die Rechenbeispiele zeigen exakt, wie falsche
Annahmen scheitern; sie sind keine behaupteten Fehler in den Originaldaten.

Alle ursprünglichen acht bestätigenden Überlegenheitsentscheidungen bleiben
INCONCLUSIVE. Kein Nachweis physikalischer Gültigkeit oder ausgeführtes RAX-U2.

## Reproduktion im Forschungscheckout

```bash
python experimental/method_review/audit.py --output experimental/method_review/evidence/new-review
python experimental/method_review/verify_examples.py experimental/method_review/evidence/new-review
```

Der Ausgabepfad muss neu sein. audit.py prüft zunächst die unveränderten
Originaldaten. Alle Manipulationen geschehen danach in temporären KOPIEN, deren
Prüfsummen bewusst neu erstellt werden. Das testet semantische Validierung und
behauptet keinen Angriff auf eine signierte Veröffentlichung. Die Kopien werden
nach Erfassung der Belege entfernt; die Rezepte, ersetzten Einzelzeilen und
Dateidigests sind vollständig gespeichert und jederzeit regenerierbar.

`hardened_checks.py` enthält ergänzende Prüfungen für Indexbereich/-typ,
kanonische Identität, exakte Episode/Budget/Plan-Abdeckung und offensichtliche
Verstösse gegen die Freeze-Reihenfolge. Sie bestehen die Originaldaten und
weisen die konstruierte Index-Manipulation zurück. Sechs gezielte Testmethoden
prüfen die Zusatzregeln. Sie ersetzen keine Sandbox oder externe Präregistrierung.

`verify_examples.py` rechnet die statistischen Beispiele separat mit rationaler
Arithmetik und SciPy-Gates nach; es importiert weder audit.py noch den ursprünglichen
Planer/Binomialprüfer. Gleicher Autor, keine unabhängige Person.

Im Lieferpaket startet `reproduce.py` denselben Ablauf nach gesicherter Entpackung
des unveränderten veröffentlichten B1-Archivs. Python 3.12.14, NumPy 2.3.5,
SciPy 1.17.0. Laufzeiten und Zeitstempel können variieren, die Befunde und exakten
Werte nicht. Dies ist keine neue bestätigende Benchmark-Kampagne.
