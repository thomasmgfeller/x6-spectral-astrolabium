from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
expected=set(m['files'])|{'MANIFEST.json'}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==expected, ('file inventory mismatch', sorted(actual-expected), sorted(expected-actual))
for name,info in m['files'].items():
    p=root/name
    assert p.is_file() and not p.is_symlink(), name
    data=p.read_bytes()
    assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256'], name
print('PASS:',len(m['files']),'files; every byte count and SHA-256 verified')
