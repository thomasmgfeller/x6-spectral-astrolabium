#!/usr/bin/env python3
"""Independent count-likelihood replay. Does not import planner or acquisition code.
Fractions for Bayes weights; outcome enumeration for information gain; SciPy for
fixed allocations and binomial tests. Same Python PRNG is regenerated, not certified.
"""
import argparse
from datetime import datetime,timezone
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import random
import time
import numpy as np
from scipy.stats import binom,binomtest
from storage import write_once,encoded,verify_complete

HERE=Path(__file__).resolve().parent

def load(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(ok,msg):
    if not ok:raise ValueError(msg)
def close(a,b,msg,tol=5e-12):check(np.allclose(a,b,atol=tol,rtol=tol,equal_nan=False),msg)
def H(weights):return -sum(float(x)*math.log2(float(x)) for x in weights if x)
def probabilities(eps,obs):
    high=1-F(eps)
    return ((high,),) if obs else ((high,F(1,2)),(F(1,2),high),(F(1,2),F(1,2)))

@lru_cache(None)
def posterior(eps,obs,counts):
    p=probabilities(eps,obs)
    likelihoods=[math.prod(row[a]**counts[2*a+1]*(1-row[a])**(counts[2*a]-counts[2*a+1]) for a in range(len(row))) for row in p]
    total=sum(likelihoods)
    check(total>0,'impossible candidate likelihood')
    return tuple(x/total for x in likelihoods)

@lru_cache(None)
def decision(eps,obs,counts):
    p=probabilities(eps,obs);w=posterior(eps,obs,counts);gains=[]
    for a in range(len(p[0])):
        expected=0.
        for y in (0,1):
            joint=[weight*(row[a] if y else 1-row[a]) for weight,row in zip(w,p)]
            mass=sum(joint)
            if mass:expected+=float(mass)*H([x/mass for x in joint])
        gains.append(max(0.,H(w)-expected))
    best=max(gains)
    if best<=1e-12:return sum(counts[::2])%len(p[0])
    return next(a for a,v in enumerate(gains) if best-v<=1e-12)


def verify_designs(contract,designs):
    checked=0
    for key,entry in designs.items():
        eps,ob,b=key.split(':');obs=bool(int(ob));b=int(b);p=np.array(probabilities(eps,obs),dtype=float)
        if obs:expected=[0.];allocation=[b]
        else:
            expected=[]
            for nx in range(b+1):
                ny=b-nx
                joint=np.array([np.outer(binom.pmf(np.arange(nx+1),nx,row[0]),binom.pmf(np.arange(ny+1),ny,row[1]))/3 for row in p])
                mass=joint.sum(axis=0)
                post=np.divide(joint,mass,out=np.zeros_like(joint),where=mass>0)
                logs=np.zeros_like(post);np.log2(post,out=logs,where=post>0)
                expected.append(float((-joint*logs).sum()))
            low=min(expected);best=min((i for i,e in enumerate(expected) if e-low<=1e-12),key=lambda i:(abs(2*i-b),i));allocation=[best,b-best]
        close([v['entropy'] for v in entry['all_allocations']],expected,'fixed entropy objective '+key)
        check(entry['allocation']==allocation,'fixed allocation optimum '+key)
        check(0<=entry['offline_cpu_seconds']<=contract['limits']['offline_design_seconds_per_regime_budget'],'offline CPU budget')
        checked+=len(expected)
    check(len(designs)==16,'design count')
    return checked


def draw(contract,phase,eid,domain,action=None):
    parts=[str(contract['root_seed']),contract['campaign'],phase,eid,domain]
    if action is not None:parts.append(str(action))
    return random.Random(int.from_bytes(hashlib.sha256(':'.join(parts).encode()).digest(),'big'))


def validate_metadata(status,c,expected_n,expected_rows):
    check(status['episodes']==expected_n and status['policy_budget_runs']==expected_rows,'completion counts')
    for key,limit in [('wall_seconds',c['limits']['campaign_wall_seconds_per_partition']),('peak_rss_kib',c['limits']['process_peak_rss_mib']*1024),('output_payload_bytes',c['limits']['partition_bytes'])]:
        check(isinstance(status[key],(float,int)) and math.isfinite(status[key]) and 0<=status[key]<=limit,'resource metadata: '+key)
    check(math.isfinite(status['online_cpu_seconds']) and status['online_cpu_seconds']>=0,'online total metadata')
    check(status['fsync_readback_each_file'] is True and status['power_loss_tested'] is False,'storage scope')


def verify(out,phase):
    began=time.monotonic();out=Path(out);folder=out/phase;c=load(out/'contract.json');designs=load(out/'designs.json')
    status=verify_complete(folder);prepared=load(out/'PREPARED.json')
    for name,expected in prepared['source_hashes'].items():check(digest(HERE/name)==expected,'source hash '+name)
    started=load(folder/'RUN_STARTED.json')
    check(started['contract_sha256']==digest(out/'contract.json'),'contract pin')
    check(started['source_hashes']==prepared['source_hashes'],'run source pin')
    check(started['phase']==phase and status['phase']==phase,'phase metadata')
    if phase=='test':
        frozen=load(out/'freeze.json')
        check(frozen['source_hashes']==prepared['source_hashes'],'freeze source pin')
        for name,d in frozen['bindings'].items():check(digest(out/name)==d,'freeze binding '+name)
        check(frozen['created_utc']<started['started_utc'],'freeze precedes test')
        check(frozen['test_outcomes_inspected'] is False,'test preread assertion')
        verify_complete(out/'development')
    checked_designs=verify_designs(c,designs)
    episodes=load(folder/'episodes.json');rows=[json.loads(line) for line in (folder/'records.jsonl').read_text().splitlines()]
    bank=np.load(folder/'acquisition.npy',allow_pickle=False);challenge=np.load(folder/'challenge.npy',allow_pickle=False);randoms=np.load(folder/'random_plans.npy',allow_pickle=False)
    reps=c[phase+'_replicates_per_stratum'];N=reps*len(c['strata']);R=N*len(c['policies'])*len(c['budgets']);B=max(c['budgets'])
    validate_metadata(status,c,N,R);check(len(episodes)==N and len(rows)==R,'raw counts')
    for a,shape in [(bank,(N,2,B)),(challenge,(N,2,128)),(randoms,(N,B))]:check(a.shape==shape and a.dtype==np.uint8,'array type/shape')
    masks={};step_count=0;seen=set();total_cpu=0;stratum_by_id={s['id']:s for s in c['strata']}
    for ei,episode in enumerate(episodes):
        si,rep=divmod(ei,reps);s=c['strata'][si];eid=f'{phase}:{si}:{rep}';obs=s['kind']=='UNIDENTIFIABLE_CONTROL';p=probabilities(s['noise'],obs);A=len(p[0]);nh=128//A
        actual=(F(1,5),F(1,5)) if s['kind']=='OUT_OF_MODEL' else p[s['truth']]
        check(episode['id']==eid and episode['index']==ei and episode['stratum']==s['id'] and episode['truth']==s['truth'] and episode['kind']==s['kind'],'episode identity')
        check(episode['true_probabilities']==list(map(str,actual)),'truth metadata')
        for domain,arr,n in [('acquisition',bank,B),('challenge',challenge,nh)]:
            for action,prob in enumerate(actual):
                rng=draw(c,phase,eid,domain,action)
                expected=[int(rng.randrange(prob.denominator)<prob.numerator) for _ in range(n)]
                check(np.array_equal(arr[ei,action,:n],expected),'random stream mismatch')
                check(not np.any(arr[ei,action,n:]),'nonzero padding')
            check(not np.any(arr[ei,A:]),'unused action padding')
        rng=draw(c,phase,eid,'random_plan');check(np.array_equal(randoms[ei],[rng.randrange(A) for _ in range(B)]),'random action stream')
        counts=[int(challenge[ei,a,:nh].sum()) for a in range(A)]
        survivors=[]
        for h,row in enumerate(p):
            rejected=False
            for a,prob in enumerate(row):
                key=(nh,prob,len(p)*A)
                if key not in masks:masks[key]=[binomtest(k,nh,float(prob)).pvalue<=.05/(len(p)*A) for k in range(nh+1)]
                rejected|=masks[key][counts[a]]
            if not rejected:survivors.append(h)
        check(episode['challenge_counts']==counts and episode['challenge_n_per_action']==nh,'challenge allocation')
        check(episode['survivors']==survivors and episode['model_set_inadequate']==(not survivors),'candidate falsification gate')
    for r in rows:
        ei=r['episode_index'];s=stratum_by_id[r['stratum']];ep=episodes[ei];obs=s['kind']=='UNIDENTIFIABLE_CONTROL';p=probabilities(s['noise'],obs);A=len(p[0]);b=r['budget'];policy=r['policy'];eps=s['noise']
        key=(ei,b,policy);check(key not in seen,'duplicate row');seen.add(key)
        check(policy in c['policies'] and b in c['budgets'],'unknown cell')
        check(r['episode_id']==ep['id'] and ep['stratum']==s['id'] and r['kind']==s['kind'] and r['replicate']==ei%reps,'record identity')
        check(r['acquired']==b and r['holdout_budget']==128 and len(r['actions'])==b and len(r['observations'])==b,'measurement budget')
        check(isinstance(r['cpu_ns'],int) and 0<=r['cpu_ns']<=c['limits']['online_cpu_seconds_per_policy_run']*1e9,'online CPU budget');total_cpu+=r['cpu_ns']/1e9
        allocation=designs[f'{eps}:{int(obs)}:{b}']['allocation']
        if A==1:fixed=[0]*b
        else:fixed=[a for _ in range(min(allocation)) for a in [0,1]]+[0]*max(0,allocation[0]-allocation[1])+[1]*max(0,allocation[1]-allocation[0])
        counts=[0]*(2*A)
        for t,(action,outcome) in enumerate(zip(r['actions'],r['observations'])):
            a=int(action);y=int(outcome)
            expected=decision(eps,obs,tuple(counts)) if policy=='adaptive_eig' else fixed[t] if policy=='fixed_optimal' else int(randoms[ei,t])
            check(a==expected,'planner action mismatch '+str(key)+' step '+str(t))
            check(y==int(bank[ei,a,counts[2*a]]),'outcome replay')
            counts[2*a]+=1;counts[2*a+1]+=y;step_count+=1
        w=posterior(eps,obs,tuple(counts));q=[float(sum(w[h]*p[h][a] for h in range(len(p)))) for a in range(A)]
        close(r['posterior'],list(map(float,w)),'posterior replay');close(r['prediction'],q,'prediction replay');close(r['entropy_bits'],H(w),'entropy')
        check(r['map_class']==next(i for i,x in enumerate(w) if float(max(w)-x)<=1e-12),'MAP rule')
        check(r['action_counts']==counts[::2],'action allocation')
        nh=ep['challenge_n_per_action'];ys=challenge[ei,:A,:nh].astype(float);qa=np.array(q)[:,None]
        close(r['brier'],float(np.mean((qa-ys)**2)),'Brier score')
        actual=[float(F(v)) for v in ep['true_probabilities']];close(r['truth_probability_mse'],np.mean((np.array(q)-actual)**2),'truth MSE')
        clipped=np.clip(qa,1e-12,1-1e-12);complement=np.clip(1-qa,1e-12,1-1e-12)
        close(r['holdout_log_loss'],float(np.mean(-ys*np.log(clipped)-(1-ys)*np.log(complement))),'log loss')
        check(r['correct']==(int(r['map_class']==s['truth']) if s['kind']=='IN_MODEL' else None),'accuracy')
        check(r['selected_model_rejected']==(r['map_class'] not in ep['survivors']) and r['model_set_inadequate']==ep['model_set_inadequate'],'row gate')
    close(total_cpu,status['online_cpu_seconds'],'total CPU',tol=1e-8)
    return {'status':'PASS','phase':phase,'checked_episodes':N,'checked_policy_budget_runs':R,'checked_acquired_observations':step_count,'checked_fixed_allocations':checked_designs,'all_rows_checked':True,'all_rng_banks_regenerated':True,'holdout_gate_method':'SciPy exact binomial, separately implemented','posterior_method':'rational likelihood from sufficient counts','adaptive_method':'enumerated expected posterior entropy','fixed_design_method':'SciPy binomial outer products','source_hashes':prepared['source_hashes'],'partition_complete_sha256':digest(folder/'COMPLETE.json'),'wall_seconds':time.monotonic()-began,'created_utc':datetime.now(timezone.utc).isoformat(),'independent_implementation':True,'independent_person_or_blind_review':False,'prng_independence_certified':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('evidence',type=Path);parser.add_argument('phase',choices=['development','test']);args=parser.parse_args()
    result=verify(args.evidence,args.phase);write_once(args.evidence/(args.phase+'-reference.json'),encoded(result));print(json.dumps(result,indent=2))
