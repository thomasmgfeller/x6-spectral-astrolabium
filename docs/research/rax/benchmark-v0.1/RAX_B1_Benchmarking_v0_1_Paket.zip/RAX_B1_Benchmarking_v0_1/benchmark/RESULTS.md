# RAX-B1 v0.1: completed benchmark

The single frozen test campaign compared adaptive greedy EIG, optimized fixed
allocation and uniform random plans at budgets 4, 8, 16 and 32. Every plan used
the exact acquisition budget and the same 128 separately generated heldout
observations per episode. Development and test streams were disjoint.

| Budget | Adaptive Brier | Fixed optimal Brier | Random Brier |
|---:|---:|---:|---:|
| 4 | 0.2130062814 | 0.2175033241 | 0.2177865955 |
| 8 | 0.2054484410 | 0.2090621260 | 0.2093989798 |
| 16 | 0.2017144807 | 0.2030945241 | 0.2034268823 |
| 32 | 0.1991932553 | 0.1999204242 | 0.2000214635 |

Each entry pools 4,608 paired episodes, equally weighted over the nine in-model
strata. Lower is better. ALL EIGHT prespecified simultaneous Hoeffding intervals
include zero: confirmatory superiority is INCONCLUSIVE. Secondary approximate
Bonferroni normal intervals favor adaptive planning, but do not replace the
primary criterion. No test seeds, strata or runs were dropped.

The outside-model control was flagged in all 512 episodes despite posterior
concentration on a wrong candidate. Observation-only mechanisms were quotiented
into one predictive class; zero entropy does not identify their causal direction.

The test includes 5,632 episodes, 67,584 policy/budget runs and 1,013,760 acquired
observations counted across those runs. Shared/potential bank entries are not
additional measurements. All raw observations, action traces, posterior weights,
metrics and candidate gates are included. All 12 pretest gates, all-row reference
replay and the separate 204-cell / eight-contrast aggregation audit passed.

CPU timings are diagnostics on a shared host. Online measurements include policy
execution, updates and callbacks; random-plan and outcome-bank generation are
outside this timing window and were not separately timed. Fixed-design search
has a separately reported 0.463 CPU-s cost. There is no complete total-compute
ranking. Every configured upper cap was respected.

No physical validation, RAX-U2 execution, external preregistration or independent
personnel/blind review is claimed. Source was fixed before development and test
was frozen before acquisition. Old U1 archive truncation remains unexplained.
Controlled file fault tests and hash readback do not certify power-loss safety.
A temporary PDF-rendering PNG was found truncated during delivery QA, regenerated
and visually checked; primary evidence hash verification passed. See delivery-QA.

The PDF contains the complete 132 stratum/policy/budget cells and the statistical
interpretation. analysis.json contains 204 full-precision group/policy/budget cells,
all primary contrasts, resource metrics, fixed-design objectives and all gates.
The extra verify_analysis.py and build_report.py were written after the test for
report verification and formatting; they do not change any frozen source or test.
