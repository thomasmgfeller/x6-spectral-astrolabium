#!/usr/bin/env python3
"""Frozen all-cell reporting; no excluded seeds, runs or post-hoc best budget."""
import argparse
from collections import defaultdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from scipy.stats import norm
from storage import encoded,write_once,verify_complete


def mean(xs):return float(np.mean(xs))
def summarize(rows):
    cpu=[r['cpu_ns']/1e6 for r in rows]
    result={'n':len(rows),'brier_mean':mean([r['brier'] for r in rows]),'truth_mse_mean':mean([r['truth_probability_mse'] for r in rows]),'log_loss_mean':mean([r['holdout_log_loss'] for r in rows]),'entropy_bits_mean':mean([r['entropy_bits'] for r in rows]),'cpu_ms_mean':mean(cpu),'cpu_ms_median':float(np.median(cpu)),'cpu_ms_p95':float(np.quantile(cpu,.95)),'cpu_seconds_total':sum(cpu)/1000,'action0_fraction_mean':mean([r['action_counts'][0]/r['budget'] for r in rows]),'selected_model_rejection_rate':mean([r['selected_model_rejected'] for r in rows])}
    result['class_accuracy']=mean([r['correct'] for r in rows]) if all(r['correct'] is not None for r in rows) else None
    return result


def analyze(out):
    out=Path(out);c=json.loads((out/'contract.json').read_text());complete=verify_complete(out/'test')
    ref=json.loads((out/'test-reference.json').read_text())
    if ref['status']!='PASS' or ref['partition_complete_sha256']!=hashlib.sha256((out/'test/COMPLETE.json').read_bytes()).hexdigest():raise ValueError('missing/stale full reference')
    rows=[json.loads(l) for l in (out/'test/records.jsonl').read_text().splitlines()];episodes=json.loads((out/'test/episodes.json').read_text())
    groups=defaultdict(list);by_id={s['id']:s for s in c['strata']}
    for r in rows:
        levels=['stratum:'+r['stratum']]
        if r['kind']=='IN_MODEL':levels+=['in_model','noise:'+by_id[r['stratum']]['noise']]
        else:levels+=['control:'+r['stratum']]
        for group in levels:groups[(group,r['budget'],r['policy'])].append(r)
    cells=[dict(group=k[0],budget=k[1],policy=k[2],**summarize(rs)) for k,rs in sorted(groups.items())]
    indexed={(r['episode_index'],r['budget'],r['policy']):r for r in rows};contrasts=[];alpha=c['alpha'];M=c['primary_family_size'];z=float(norm.ppf(1-alpha/(2*M)))
    eligible=[ep for ep in episodes if ep['kind']=='IN_MODEL']
    for b in c['budgets']:
        for comparison in ['fixed_optimal','random_uniform']:
            differences=[];stratum_differences=defaultdict(list)
            for ep in eligible:
                d=indexed[(ep['index'],b,'adaptive_eig')]['brier']-indexed[(ep['index'],b,comparison)]['brier'];differences.append(d);stratum_differences[ep['stratum']].append(d)
            N=len(differences);d=mean(differences);radius=math.sqrt(2*math.log(2*M/alpha)/N);lo,hi=max(-1,d-radius),min(1,d+radius)
            K=len(stratum_differences);se=math.sqrt(sum(float(np.var(ds,ddof=1))/len(ds) for ds in stratum_differences.values())/(K*K))
            approx=[d-z*se,d+z*se]
            contrasts.append({'budget':b,'comparison':'adaptive_eig minus '+comparison,'n_paired_episodes':N,'mean_brier_difference':d,'simultaneous_hoeffding_interval':[lo,hi],'confirmatory_result':'ADAPTIVE_BETTER' if hi<0 else 'ADAPTIVE_WORSE' if lo>0 else 'INCONCLUSIVE','approximate_bonferroni_normal_interval':approx,'approximate_interval_role':'secondary diagnostic; not finite-sample confirmatory','stratified_standard_error':se,'descriptive_stratum_differences':{k:mean(v) for k,v in sorted(stratum_differences.items())}})
    gates=[]
    for s in c['strata']:
        es=[ep for ep in episodes if ep['stratum']==s['id']]
        gates.append({'stratum':s['id'],'kind':s['kind'],'n_unique_episodes':len(es),'model_set_inadequate_count':sum(ep['model_set_inadequate'] for ep in es),'model_set_inadequate_rate':mean([ep['model_set_inadequate'] for ep in es]),'true_class_rejected_count':sum(ep['truth'] not in ep['survivors'] for ep in es) if s['kind']=='IN_MODEL' else None,'mean_surviving_classes':mean([len(ep['survivors']) for ep in es]),'alpha_scope':'0.05 Bonferroni over candidate/action tests within each episode; not campaign-wide'})
    return {'schema':'rax.b1.analysis/1','campaign':c['campaign'],'created_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE','source_freeze_sha256':hashlib.sha256((out/'freeze.json').read_bytes()).hexdigest(),'test_complete_sha256':hashlib.sha256((out/'test/COMPLETE.json').read_bytes()).hexdigest(),'test_reference_sha256':hashlib.sha256((out/'test-reference.json').read_bytes()).hexdigest(),'primary':{'metric':c['primary_metric'],'n_independent_in_model_episodes':len(eligible),'family_size':M,'familywise_alpha':alpha,'confirmatory_interval':c['confirmatory_interval'],'scope':'equally weighted nine declared finite synthetic strata; independent PRNG streams assumed','contrasts':contrasts},'all_cells':cells,'heldout_model_checks':gates,'resources':complete,'fixed_designs':json.loads((out/'designs.json').read_text()),'reporting':{'all_strata_included':True,'all_budgets_included':True,'all_policies_included':True,'discarded_episodes':0,'early_stopping':False,'test_campaign_runs':1,'external_preregistration':False,'independent_external_review':False,'physical_validation':False,'RAX_U2_executed':False,'storage_power_loss_qualified':False}}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('evidence',type=Path);args=parser.parse_args();result=analyze(args.evidence)
    write_once(args.evidence/'analysis.json',encoded(result))
    print(json.dumps({'status':result['status'],'cells':len(result['all_cells']),'primary':result['primary']},indent=2))
