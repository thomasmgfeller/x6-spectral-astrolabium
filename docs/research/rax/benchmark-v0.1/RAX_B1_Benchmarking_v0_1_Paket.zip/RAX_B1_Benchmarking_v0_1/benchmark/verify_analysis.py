#!/usr/bin/env python3
"""Post-freeze reporting audit using standard-library aggregation.
Does not change the frozen analyses or add statistical tests.
"""
import hashlib,json,math,statistics
from pathlib import Path
import sys
from storage import encoded,write_once

p=Path(sys.argv[1]);a=json.loads((p/'analysis.json').read_text());c=json.loads((p/'contract.json').read_text());rows=[json.loads(l) for l in (p/'test/records.jsonl').read_text().splitlines()]
strata={s['id']:s for s in c['strata']}
def equal(x,y):
    if not math.isclose(x,y,rel_tol=1e-11,abs_tol=1e-12):raise ValueError((x,y))
def groupmatch(r,g):
    if g=='in_model':return r['kind']=='IN_MODEL'
    kind,v=g.split(':',1)
    return (r['kind']=='IN_MODEL' and strata[r['stratum']]['noise']==v) if kind=='noise' else r['stratum']==v
for cell in a['all_cells']:
    rs=[r for r in rows if r['budget']==cell['budget'] and r['policy']==cell['policy'] and groupmatch(r,cell['group'])]
    assert len(rs)==cell['n']
    for output,key in [('brier_mean','brier'),('truth_mse_mean','truth_probability_mse'),('entropy_bits_mean','entropy_bits'),('log_loss_mean','holdout_log_loss'),('selected_model_rejection_rate','selected_model_rejected')]:equal(cell[output],statistics.mean(r[key] for r in rs))
    if cell['class_accuracy'] is not None:equal(cell['class_accuracy'],statistics.mean(r['correct'] for r in rs))
    cpu=sorted(r['cpu_ns']/1e6 for r in rs);pos=(len(cpu)-1)*.95;i=int(pos);frac=pos-i
    equal(cell['cpu_ms_median'],statistics.median(cpu));equal(cell['cpu_ms_mean'],statistics.mean(cpu));equal(cell['cpu_ms_p95'],cpu[i]*(1-frac)+cpu[min(i+1,len(cpu)-1)]*frac)
    equal(cell['cpu_seconds_total'],math.fsum(cpu)/1000);equal(cell['action0_fraction_mean'],statistics.mean(r['action_counts'][0]/r['budget'] for r in rs))
idx={(r['episode_index'],r['budget'],r['policy']):r for r in rows}
for item in a['primary']['contrasts']:
    base=item['comparison'].split(' minus ')[1];ds={}
    for s in c['strata']:
        if s['kind']!='IN_MODEL':continue
        rs=[r for r in rows if r['stratum']==s['id'] and r['budget']==item['budget'] and r['policy']=='adaptive_eig']
        ds[s['id']]=[r['brier']-idx[(r['episode_index'],r['budget'],base)]['brier'] for r in rs]
        equal(statistics.mean(ds[s['id']]),item['descriptive_stratum_differences'][s['id']])
    values=[x for v in ds.values() for x in v];d=statistics.mean(values);equal(d,item['mean_brier_difference'])
    rad=math.sqrt(2*math.log(2*8/.05)/len(values))
    for actual,expected in zip(item['simultaneous_hoeffding_interval'],[d-rad,d+rad]):equal(actual,expected)
    se=math.sqrt(math.fsum(statistics.variance(v)/len(v) for v in ds.values())/81);z=statistics.NormalDist().inv_cdf(1-.05/16)
    for actual,expected in zip(item['approximate_bonferroni_normal_interval'],[d-z*se,d+z*se]):equal(actual,expected)
    assert item['confirmatory_result']=='INCONCLUSIVE'
result={'status':'PASS','all_aggregate_cells_checked':len(a['all_cells']),'all_primary_contrasts_checked':len(a['primary']['contrasts']),'method':'standard-library means, variance, interpolated quantiles and normal quantile','analysis_sha256':hashlib.sha256((p/'analysis.json').read_bytes()).hexdigest(),'verification_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'created_after_test':True,'changes_to_frozen_analysis':False,'external_review':False}
write_once(p/'aggregation-check.json',encoded(result));print(json.dumps(result,indent=2))
