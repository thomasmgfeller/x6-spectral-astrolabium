"""Fail-closed, exclusive durable publication. Not a power-loss certificate."""
import hashlib
import json
import os
from pathlib import Path
import tempfile


def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def write_once(path,data,fault=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix='.pending-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            if f.write(data)!=len(data):raise OSError('short write')
            f.flush();os.fsync(f.fileno())
        if fault=='before_publish':raise OSError('injected failure before publication')
        # Hard-link publication is atomic and refuses an existing destination.
        os.link(temp,path)
        os.unlink(temp)
        dirfd=os.open(path.parent,os.O_DIRECTORY)
        try:os.fsync(dirfd)
        finally:os.close(dirfd)
        if fault=='after_publish':raise OSError('injected failure before acceptance')
        saved=path.read_bytes()
        if len(saved)!=len(data) or sha(saved)!=sha(data):raise OSError('readback mismatch')
        return {'sha256':sha(saved),'bytes':len(saved)}
    finally:
        if os.path.exists(temp):os.unlink(temp)


def verify_complete(folder):
    folder=Path(folder)
    record=json.loads((folder/'COMPLETE.json').read_text())
    if record['status']!='COMPLETE':raise ValueError('not complete')
    for name,v in record['files'].items():
        if Path(name).name!=name:raise ValueError('unsafe evidence path')
        p=folder/name
        if p.is_symlink() or not p.is_file():raise ValueError('missing/unsafe evidence')
        data=p.read_bytes()
        if len(data)!=v['bytes'] or sha(data)!=v['sha256']:raise ValueError('evidence digest mismatch: '+name)
    return record
