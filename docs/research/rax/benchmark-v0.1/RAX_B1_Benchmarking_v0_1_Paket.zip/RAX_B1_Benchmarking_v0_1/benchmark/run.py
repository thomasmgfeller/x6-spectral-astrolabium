#!/usr/bin/env python3
"""Explicit prepare -> development -> source freeze -> single test acquisition."""
import argparse
from datetime import datetime,timezone
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import platform
import random
import resource
import subprocess
import time

import numpy as np
import core
from storage import write_once,encoded,sha,verify_complete

HERE=Path(__file__).resolve().parent
SOURCE_NAMES=['core.py','storage.py','run.py','reference.py','analyze.py','test_benchmark.py','contract.json']
def now():return datetime.now(timezone.utc).isoformat()
def load(p):return json.loads(Path(p).read_text())
def seed(c,*parts):return int.from_bytes(hashlib.sha256((':'.join([str(c['root_seed']),c['campaign'],*map(str,parts)])).encode()).digest(),'big')
def source_hashes():return {n:sha((HERE/n).read_bytes()) for n in SOURCE_NAMES}
def npbytes(a):
    b=io.BytesIO();np.save(b,a,allow_pickle=False);return b.getvalue()


def prepare(out):
    c=load(HERE/'contract.json');out=Path(out);out.mkdir(exist_ok=False,parents=True)
    design={}
    for eps,obs in [(x,False) for x in ('0','1/10','1/4')]+[('1/10',True)]:
        for b in c['budgets']:
            key=f'{eps}:{int(obs)}:{b}';start=time.process_time()
            design[key]=core.fixed_design(tuple(tuple(float(x) for x in row) for row in core.table(eps,obs)),b)
            design[key]['offline_cpu_seconds']=time.process_time()-start
            if design[key]['offline_cpu_seconds']>c['limits']['offline_design_seconds_per_regime_budget']:raise ValueError('offline budget')
    write_once(out/'contract.json',encoded(c));write_once(out/'designs.json',encoded(design))
    write_once(out/'PREPARED.json',encoded({'created_utc':now(),'source_hashes':source_hashes(),'python':platform.python_version(),'numpy':np.__version__,'external_preregistration':False}))
    print(json.dumps({'status':'PREPARED','designs':len(design),'output':str(out)}))


def freeze(out):
    out=Path(out);c=load(out/'contract.json')
    if load(out/'PREPARED.json')['source_hashes']!=source_hashes():raise ValueError('source changed since prepare')
    verify_complete(out/'development')
    reference=load(out/'development-reference.json')
    if reference['status']!='PASS':raise ValueError('development reference failed')
    if load(out/'technical-gate.json')['status']!='PASS':raise ValueError('technical gate failed')
    record={'schema':'rax.b1.freeze/1','created_utc':now(),'source_hashes':source_hashes(),
            'bindings':{n:sha((out/n).read_bytes()) for n in ['contract.json','designs.json','PREPARED.json','development/COMPLETE.json','development-reference.json','technical-gate.json']},
            'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=HERE,text=True).strip(),
            'external_preregistration':False,'test_outcomes_inspected':False,'development_tuning':'NONE; policies and thresholds unchanged'}
    write_once(out/'freeze.json',encoded(record));print(json.dumps({'status':'FROZEN','source_commit':record['source_commit']}))


def truth_probs(stratum,p):
    if stratum['kind']=='OUT_OF_MODEL':return (Fraction(1,5),Fraction(1,5))
    return p[stratum['truth']]


def generate(c,phase,episode,domain,probs,n):
    out=np.zeros((2,n),dtype=np.uint8)
    for a,p in enumerate(probs):
        rng=random.Random(seed(c,phase,episode,domain,a))
        out[a]=[rng.randrange(p.denominator)<p.numerator for _ in range(n)]
    return out


def acquire(out,phase):
    out=Path(out);c=load(out/'contract.json');design=load(out/'designs.json')
    if load(out/'PREPARED.json')['source_hashes']!=source_hashes():raise ValueError('source changed since prepare')
    if phase=='test':
        frozen=load(out/'freeze.json')
        if frozen['source_hashes']!=source_hashes():raise ValueError('source changed after freeze')
        for name,digest in frozen['bindings'].items():
            if sha((out/name).read_bytes())!=digest:raise ValueError('frozen artifact changed')
    folder=out/phase;folder.mkdir(exist_ok=False)
    write_once(folder/'RUN_STARTED.json',encoded({'phase':phase,'started_utc':now(),'contract_sha256':sha((out/'contract.json').read_bytes()),'source_hashes':source_hashes()}))
    count=c[phase+'_replicates_per_stratum'];N=count*len(c['strata']);B=max(c['budgets'])
    banks=np.zeros((N,2,B),dtype=np.uint8);holdouts=np.zeros((N,2,128),dtype=np.uint8);randoms=np.zeros((N,B),dtype=np.uint8)
    rows=[];episodes=[];start=time.monotonic();pid_order=list(c['policies'])
    masks={};run_cpu=0.0
    for si,s in enumerate(c['strata']):
        p=core.table(s['noise'],s['kind']=='UNIDENTIFIABLE_CONTROL');A=len(p[0]);actual=truth_probs(s,p);nh=128//A
        for h,row in enumerate(p):
            for a,prob in enumerate(row):masks[(s['id'],h,a)]=core.binomial_rejection_mask(nh,prob,1,20*len(p)*A)
        for rep in range(count):
            if time.monotonic()-start>c['limits']['campaign_wall_seconds_per_partition']:raise TimeoutError('partition budget')
            ei=si*count+rep;eid=f'{phase}:{si}:{rep}'
            banks[ei]=generate(c,phase,eid,'acquisition',actual,B)
            rng=random.Random(seed(c,phase,eid,'random_plan'))
            randoms[ei]=[rng.randrange(A) for _ in range(B)]
            predicted=[]
            # Rotate policy execution order to reduce systematic timing order effects.
            for budget in c['budgets']:
                allocation=design[f"{s['noise']}:{int(A==1)}:{budget}"]['allocation']
                order=pid_order[ei%3:]+pid_order[:ei%3]
                for policy in order:
                    used=[0]*A
                    def measure(a):
                        if not 0<=a<A or sum(used)>=budget:raise ValueError('measurement budget')
                        y=int(banks[ei,a,used[a]]);used[a]+=1;return y
                    begin=time.process_time_ns()
                    record=core.run_policy(policy,p,budget,allocation,randoms[ei],measure)
                    cpu=time.process_time_ns()-begin;run_cpu+=cpu/1e9
                    if cpu/1e9>c['limits']['online_cpu_seconds_per_policy_run']:raise TimeoutError('online policy budget')
                    if sum(used)!=budget:raise ValueError('unequal budget')
                    record.update({'episode_index':ei,'episode_id':eid,'stratum':s['id'],'kind':s['kind'],'replicate':rep,'budget':budget,'policy':policy,'acquired':sum(used),'holdout_budget':128,'cpu_ns':cpu})
                    predicted.append(record)
            # Predictions for every policy and budget are fixed before generating challenge data.
            holdouts[ei,:,:nh]=generate(c,phase,eid,'challenge',actual,nh)
            counts=[int(holdouts[ei,a,:nh].sum()) for a in range(A)]
            survivors=[h for h in range(len(p)) if not any(masks[(s['id'],h,a)][counts[a]] for a in range(A))]
            episodes.append({'index':ei,'id':eid,'stratum':s['id'],'kind':s['kind'],'truth':s['truth'],'true_probabilities':list(map(str,actual)),'challenge_counts':counts,'challenge_n_per_action':nh,'survivors':survivors,'model_set_inadequate':not survivors})
            for r in predicted:
                q=r['prediction'];means=[v/nh for v in counts]
                r['brier']=sum(qi*qi-2*qi*y+y for qi,y in zip(q,means))/A
                r['truth_probability_mse']=sum((qi-float(pi))**2 for qi,pi in zip(q,actual))/A
                r['holdout_log_loss']=sum(-y*math.log(max(1e-12,min(1-1e-12,qi)))-(1-y)*math.log(max(1e-12,min(1-1e-12,1-qi))) for qi,y in zip(q,means))/A
                r['correct']=int(r['map_class']==s['truth']) if s['kind']=='IN_MODEL' else None
                r['selected_model_rejected']=r['map_class'] not in survivors
                r['model_set_inadequate']=not survivors
                rows.append(r)
        print(json.dumps({'phase':phase,'completed_stratum':s['id'],'episodes':(si+1)*count}),flush=True)
    peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if peak>c['limits']['process_peak_rss_mib']*1024:raise MemoryError('RSS budget')
    payloads={'acquisition.npy':npbytes(banks),'challenge.npy':npbytes(holdouts),'random_plans.npy':npbytes(randoms),
              'episodes.json':encoded(episodes),'records.jsonl':b''.join(encoded(r) for r in rows)}
    total=sum(map(len,payloads.values()))
    if total>c['limits']['partition_bytes']:raise ValueError('partition output budget')
    files={'RUN_STARTED.json':{'sha256':sha((folder/'RUN_STARTED.json').read_bytes()),'bytes':(folder/'RUN_STARTED.json').stat().st_size}}
    for name,data in payloads.items():files[name]=write_once(folder/name,data)
    status={'status':'COMPLETE','phase':phase,'finished_utc':now(),'episodes':N,'policy_budget_runs':len(rows),'files':files,'wall_seconds':time.monotonic()-start,'online_cpu_seconds':run_cpu,'peak_rss_kib':peak,'output_payload_bytes':total,'fsync_readback_each_file':True,'power_loss_tested':False}
    if status['wall_seconds']>c['limits']['campaign_wall_seconds_per_partition']:raise TimeoutError('partition completion budget')
    write_once(folder/'COMPLETE.json',encoded(status));verify_complete(folder)
    print(json.dumps({k:v for k,v in status.items() if k!='files'},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','development','freeze','test']);p.add_argument('output',type=Path);a=p.parse_args()
    if a.command=='prepare':prepare(a.output)
    elif a.command=='freeze':freeze(a.output)
    else:acquire(a.output,a.command)
