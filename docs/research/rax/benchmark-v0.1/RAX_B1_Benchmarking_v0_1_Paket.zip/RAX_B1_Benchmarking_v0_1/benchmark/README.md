# RAX-B1: finite synthetic measurement-plan benchmark

Comparison of greedy adaptive expected information gain, exhaustively optimized
fixed allocation and uniform random action plans. This is a synthetic X6 control
extension, not RAX-U2, a physics experiment or a general causal discovery claim.
The contract is fixed before the first development acquisition and source-hashed
before one heldout test campaign. No external preregistration or blind review.

Requirements: Python 3.12, NumPy 2.3.5, SciPy 1.17.0. Linux for RSS units and fsync.
From this directory, choose a NEW output directory; commands refuse reuse:

```bash
python run.py prepare evidence/new-campaign
python test_benchmark.py --gate evidence/new-campaign/technical-gate.json
python run.py development evidence/new-campaign
python reference.py evidence/new-campaign development
python run.py freeze evidence/new-campaign
python run.py test evidence/new-campaign
python reference.py evidence/new-campaign test
python analyze.py evidence/new-campaign
```

Freeze uses git HEAD for provenance. The supplied ZIP includes exact source and
raw evidence; from outside a git checkout replay with `reference.py`, or initialize
a local git repository and commit the source before generating a fresh campaign.
CPU times, process peak RSS and UTC timestamps vary; action, observation, posterior
and score records are reproducible for the fixed contract and Python PRNG version.

## Controls and fairness

The source control (commit 1a02c482d59a42d554337fb83e0f6d6e6d84b516,
experimental/neutral_discovery/discovery.py) supplies three binary probability
mechanisms. The extension adds known symmetric event-readout noise and sequential
one-observation EIG. Adaptive planning is greedy, not globally optimal. All three
policies use the same two informative interventions and uniform class prior. The
uninformative observation is not mixed into the random baseline. Fixed plans
minimize prior-averaged posterior entropy over EVERY integer action allocation.

All policies spend exactly B acquisition observations (4,8,16,32), then are scored
on 128 balanced heldout observations generated only after every prediction for
that episode is fixed. Development (32 per stratum) and test (512 per stratum)
use disjoint SHA-256-derived seed namespaces. Potential outcome banks and heldout
samples are paired across policies and budgets. Future bank entries are hidden
from planner callbacks; holdout/truth never enter the planner API. The pre-generated
banks contain unused potential outcomes: these are not acquired measurements.
Challenge array padding is zero and is not generated or scored. No early stopping.

Observation-only control quotients all three indistinguishable mechanisms into
one predictive class; its zero entropy does NOT mean mechanism identification.
Outside-model control uses p=(.2,.2), absent from all three candidates. Independent
heldout exact binomial tests reject candidates at .05/(classes*actions), with one
fixed look. The familywise bound applies within EACH episode, not the campaign.

Primary endpoint: equal-action mean heldout Brier score, equally averaged across
nine in-model strata. Eight adaptive-minus-baseline contrasts are protected by
simultaneous distribution-free Hoeffding intervals under independent episodes.
Bonferroni stratified normal intervals are secondary approximations. All strata,
policies, budgets and raw rows remain included. Known-truth MSE is an auxiliary
simulation metric, not used for planning. Random plans use a separate RNG stream.

Computational limits are equal upper caps, not equal realized CPU consumption;
plan-search preprocessing and online policy CPU are separately reported. Runtime
includes posterior updates and measurement callbacks on the same host. Original
candidate construction is common and is not separately charged.

## Evidence and limits

Each partition is published once with exclusive links, file fsync, directory
fsync, length/hash readback and a final COMPLETE record. Failure-injection tests
cover interrupted publication, missing/truncated/corrupted evidence and resource
metadata. This does not qualify power-loss safety or diagnose the older U1 archive
truncation. A hash manifest and ZIP integrity checks accompany delivery.

`reference.py` imports neither core.py nor run.py. It recomputes rational Bayes
weights from counts, enumerates future outcomes for EIG, independently evaluates
fixed allocations using SciPy binomial probabilities, regenerates all PRNG banks,
replays every action and score, and verifies heldout binomial gates using SciPy.
This is implementation independence by the same author, not independent personnel.
The statistical interpretation assumes PRNG-separated streams behave independently;
no cryptographic or physical randomness certificate is claimed.

`analysis.json` contains every group/policy/budget result, all eight primary
contrasts, descriptive stratum differences, all holdout gates and resource details.
`records.jsonl` contains every policy run, including complete action/outcome trace.
`episodes.json` gives truth, holdout counts and candidate gate outcomes.
