"""Finite planner benchmark, derived from X6's three-mechanism control.
No true class, future data or holdout is passed to a planner.
"""
from fractions import Fraction
from itertools import product
import math


def table(noise, observational=False):
    if observational:
        # Quotient observationally identical mechanisms into one predictive class.
        return ((Fraction(1)-Fraction(noise),),)
    p = Fraction(1)-Fraction(noise)
    return ((p,Fraction(1,2)),(Fraction(1,2),p),(Fraction(1,2),Fraction(1,2)))


def entropy(w):
    return -sum(x*math.log2(x) for x in w if x > 0)


def update(w, probabilities, action, y):
    v = [x*(p[action] if y else 1-p[action]) for x,p in zip(w,probabilities)]
    total = sum(v)
    if not total:
        raise ValueError('zero probability under every candidate')
    return tuple(x/total for x in v)


def choose(w, p, step):
    # Binary channel identity I(C;Y)=H(Y)-E_C H(Y|C).
    gains = []
    for a in range(len(p[0])):
        q = sum(x*row[a] for x,row in zip(w,p))
        gains.append(max(0.,entropy((q,1-q))-sum(x*entropy((row[a],1-row[a])) for x,row in zip(w,p))))
    best = max(gains)
    if best <= 1e-12:
        return step % len(p[0])
    return next(a for a,g in enumerate(gains) if abs(g-best) <= 1e-12)


def expected_fixed_entropy(probabilities, budget, nx):
    if len(probabilities[0]) == 1:
        return 0.0
    expected = 0.0
    for kx in range(nx+1):
        for ky in range(budget-nx+1):
            weights = []
            for px,py in probabilities:
                likelihood = (math.comb(nx,kx)*px**kx*(1-px)**(nx-kx)
                              *math.comb(budget-nx,ky)*py**ky*(1-py)**(budget-nx-ky))
                weights.append(likelihood/len(probabilities))
            mass = sum(weights)
            if mass:
                expected += mass*entropy([v/mass for v in weights])
    return expected


def fixed_design(p,budget):
    if len(p[0]) == 1:
        return {'allocation':[budget], 'expected_entropy_bits':0.0, 'all_allocations':[{'n0':budget,'entropy':0.0}]}
    entries = [{'n0':i,'entropy':expected_fixed_entropy(p,budget,i)} for i in range(budget+1)]
    low = min(x['entropy'] for x in entries)
    best = min((x for x in entries if abs(x['entropy']-low)<=1e-12),key=lambda x:(abs(2*x['n0']-budget),x['n0']))
    return {'allocation':[best['n0'],budget-best['n0']], 'expected_entropy_bits':best['entropy'], 'all_allocations':entries}


def fixed_sequence(allocation):
    if len(allocation)==1:
        return [0]*allocation[0]
    # Interleave two exchangeable action blocks, then append any remainder.
    a,b=allocation
    return [x for _ in range(min(a,b)) for x in (0,1)]+[0]*max(0,a-b)+[1]*max(0,b-a)


def run_policy(policy, probabilities, budget, allocation, random_plan, measure):
    if policy not in ('adaptive_eig','fixed_optimal','random_uniform'):
        raise ValueError('unknown policy')
    p=tuple(tuple(float(x) for x in row) for row in probabilities)
    w=(1/len(p),)*len(p)
    fixed=fixed_sequence(allocation)
    actions=[];observations=[]
    for t in range(budget):
        a=choose(w,p,t) if policy=='adaptive_eig' else fixed[t] if policy=='fixed_optimal' else int(random_plan[t])
        y=int(measure(a))
        w=update(w,p,a,y)
        actions.append(a);observations.append(y)
    pred=[sum(wi*row[a] for wi,row in zip(w,p)) for a in range(len(p[0]))]
    return {'posterior':list(w),'prediction':pred,'entropy_bits':entropy(w),
            'map_class':next(i for i in range(len(w)) if max(w)-w[i]<=1e-12),'actions':''.join(map(str,actions)),
            'observations':''.join(map(str,observations)), 'action_counts':[actions.count(a) for a in range(len(p[0]))]}


def binomial_rejection_mask(n,p,alpha_num=1,alpha_den=120):
    # Exact probability-order two-sided binomial test. Default .05 / 6.
    p=Fraction(p); a,d=p.numerator,p.denominator
    masses=[math.comb(n,k)*a**k*(d-a)**(n-k) for k in range(n+1)]
    return [sum(m for m in masses if m<=observed)*alpha_den <= d**n*alpha_num for observed in masses]
