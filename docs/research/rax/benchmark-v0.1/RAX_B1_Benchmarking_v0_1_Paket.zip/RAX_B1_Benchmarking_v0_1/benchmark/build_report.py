#!/usr/bin/env python3
"""Post-analysis German report, directly populated from frozen benchmark evidence."""
from pathlib import Path
import hashlib,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1] if HERE.name=='measurement_plan_benchmark' else HERE.parent;E=HERE/'evidence/campaign-v0.1';OUT=ROOT/'output';OUT.mkdir(exist_ok=True);(OUT/'figures').mkdir(exist_ok=True)
a=json.loads((E/'analysis.json').read_text());c=json.loads((E/'contract.json').read_text());freeze=json.loads((E/'freeze.json').read_text());ref=json.loads((E/'test-reference.json').read_text());gate=json.loads((E/'technical-gate.json').read_text())
F='/usr/share/fonts/truetype/dejavu/';pdfmetrics.registerFont(TTFont('DejaVu',F+'DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DejaVu-Bold',F+'DejaVuSans-Bold.ttf'));pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='DejaVu',boldItalic='DejaVu-Bold')
INK=colors.HexColor('#142c41');BLUE=colors.HexColor('#166a87');PALE=colors.HexColor('#edf4f7');GRAY=colors.HexColor('#526575');LINE=colors.HexColor('#d5e0e6')
S=getSampleStyleSheet()
S.add(ParagraphStyle(name='TitleX',fontName='DejaVu-Bold',fontSize=25,leading=30,textColor=INK,spaceAfter=13))
S.add(ParagraphStyle(name='Sub',fontName='DejaVu',fontSize=11,leading=16,textColor=GRAY,spaceAfter=15))
S.add(ParagraphStyle(name='H',fontName='DejaVu-Bold',fontSize=15,leading=20,textColor=INK,spaceBefore=8,spaceAfter=10))
S.add(ParagraphStyle(name='Hsmall',fontName='DejaVu-Bold',fontSize=10,leading=14,textColor=BLUE,spaceBefore=9,spaceAfter=6))
S.add(ParagraphStyle(name='BodyX',fontName='DejaVu',fontSize=9,leading=13.3,textColor=INK,spaceAfter=9))
S.add(ParagraphStyle(name='SmallX',fontName='DejaVu',fontSize=7.5,leading=10.6,textColor=GRAY,spaceAfter=7))
S.add(ParagraphStyle(name='Cell',fontName='DejaVu',fontSize=7.3,leading=9.5,textColor=INK))
S.add(ParagraphStyle(name='CellSmall',fontName='DejaVu',fontSize=6.8,leading=8.5,textColor=INK))
S.add(ParagraphStyle(name='CodeX',fontName='DejaVu',fontSize=7.1,leading=10.4,textColor=INK,spaceAfter=8))
flow=[]
def P(text,style='BodyX'):return Paragraph(text,S[style])
def add(text,style='BodyX'):flow.append(P(text,style))
def section(t):add(t,'H')
def page(t,kicker=None):
    flow.append(PageBreak())
    if kicker:add(kicker,'SmallX')
    section(t)
def table(data,widths=None,size=7.3,leading=9.5):
    wrapped=[[P(('<font color="#ffffff"><b>'+str(v)+'</b></font>') if i==0 else str(v),'CellSmall' if size<7 else 'Cell') for v in row] for i,row in enumerate(data)]
    t=Table(wrapped,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('TEXTCOLOR',(0,0),(-1,0),colors.white),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LINEBELOW',(0,0),(-1,0),.4,INK),('LINEBELOW',(0,-1),(-1,-1),.4,LINE)]))
    flow.append(t);flow.append(Spacer(1,9));return t
policies=c['policies'];names={'adaptive_eig':'Adaptiv','fixed_optimal':'Fest optimal','random_uniform':'Zufällig'}
short={'adaptive_eig':'Adaptiv','fixed_optimal':'Fest','random_uniform':'Zufall'}
def cell(group,b,p):return next(x for x in a['all_cells'] if x['group']==group and x['budget']==b and x['policy']==p)
def num(x,n=5):return f'{x:.{n}f}'.replace('.',',')
def pct(x):return num(100*x,1)+' %'
def ci(x):return '['+num(x[0],5)+'; '+num(x[1],5)+']'

# Figure: observed score trajectory; inferential intervals have their own table.
fig,ax=plt.subplots(figsize=(7.2,2.8),layout='constrained')
for p,color,marker in zip(policies,['#146e8e','#b15c31','#777888'],['o','s','^']):
    ax.plot(c['budgets'],[cell('in_model',b,p)['brier_mean'] for b in c['budgets']],label=names[p],color=color,marker=marker,lw=1.8,ms=5)
ax.set_xscale('log',base=2);ax.set_xticks(c['budgets'],[str(x) for x in c['budgets']]);ax.set_xlabel('Erworbene Messungen je Plan');ax.set_ylabel('Mittlerer Prüf-Brier-Score');ax.set_ylim(.195,.222);ax.grid(axis='y',color='#e1e6ea');ax.spines[['top','right']].set_visible(False);ax.legend(frameon=False,ncols=3,loc='upper right',fontsize=9);fig.savefig(OUT/'figures/brier_by_budget.png',dpi=200);plt.close(fig)

add('RAX-B1 | BENCHMARKING','SmallX')
add('Messpläne im Vergleich','TitleX')
add('Adaptive, feste und zufällige Planung<br/>Synthetischer X6-Kontrollversuch · Version 0.1 · 14. Oktober 2026','Sub')
add('<b>Ergebnis:</b> Adaptive Pläne erreichen bei allen vier Budgets die niedrigsten mittleren Prüf-Fehler. Die vorab festgelegte, verteilungsfreie Absicherung bleibt in allen acht Vergleichen <b>unentschieden</b>. Das Ergebnis rechtfertigt deshalb keine bestätigte allgemeine Überlegenheit.')
table([['Messbudget B','Adaptiv','Fest optimal','Zufällig']]+[[b]+[num(cell('in_model',b,p)['brier_mean']) for p in policies] for b in c['budgets']],[110,132,132,133])
add('Prüf-Brier-Score: kleiner ist besser. Pro Tabellenwert 4.608 gepaarte Episoden aus neun gleich gewichteten Modell-/Rauschbedingungen. Beide Kontrollfälle sind separat ausgewiesen.','SmallX')
flow.append(Image(str(OUT/'figures/brier_by_budget.png'),width=507,height=197))
add('<b>Umfang:</b> 5.632 Testepisoden, 67.584 Plan-/Budgetläufe und 1.013.760 verwendete Akquisitionsbeobachtungen. Zusätzlich 352 Entwicklungsepisoden. Pro Testepisode 128 getrennte Prüfbeobachtungen; diese werden für alle zwölf Plan-/Budgetkombinationen gemeinsam verwendet.')
add('<b>Prüfstatus:</b> 12 technische Tests, vollständige separate Nachrechnung aller Testläufe und Abgleich aller 204 Berichtszellen bestanden. Keine ausgeschlossenen Episoden, keine nachträgliche Auswahl eines günstigen Budgets.')
add('Die Evidenz gilt für diesen endlichen synthetischen Kontrollversuch. RAX-U2 wurde nicht ausgeführt; physikalische Validierung und externe Blindprüfung stehen nicht hinter diesen Ergebnissen.','SmallX')

page('Versuchsvertrag und gleiche Budgets','01 / DESIGN')
add('Die drei Kandidaten übernehmen die binären Vorhersagen des vorhandenen X6-Kontrollmodells. C0 steht für X→Y, C1 für Y→X, C2 für eine gemeinsame Ursache. Bei bekanntem symmetrischem Leserauschen ε ergeben sich folgende Ereigniswahrscheinlichkeiten:')
table([['Kandidat','do(X=1): Y=1','do(Y=1): X=1'],['C0: X→Y','1 - ε','1/2'],['C1: Y→X','1/2','1 - ε'],['C2: gemeinsame Ursache','1/2','1/2']],[217,145,145])
add('Die Hauptauswertung kombiniert ε = 0; 0,10; 0,25 mit jeder der drei wahren Klassen: neun Strata mit je 512 Testwiederholungen. Der Klassenprior ist jeweils gleichverteilt. Die Szenarien und das Rauschen sind bekannt; die wahre Klasse wird dem Planer nicht übergeben.')
table([['Plan','Vorab festgelegte Regel'],['Adaptiv','Wählt nach jeder Beobachtung den grössten erwarteten Informationsgewinn für genau eine nächste Messung. Greedy-Regel, kein globales Mehrschrittoptimum.'],['Fest optimal','Minimiert die vorab erwartete Posterior-Entropie durch vollständige Suche aller ganzzahligen Verteilungen (n0, B-n0). In allen zwölf Hauptkonfigurationen ist B/2 + B/2 optimal.'],['Zufällig','Wählt beide informativen Aktionen unabhängig und gleichverteilt. Die Zufallsfolge ist unabhängig von den Messresultaten.']],[105,402])
add('Die nicht unterscheidende Beobachtungsaktion wird nur im separaten Kontrollfall eingesetzt. Dadurch wird der Zufallsplan nicht durch nutzlose Aktionen im gemeinsamen Hauptkatalog künstlich geschwächt.')
table([['Budget / Trennung','Verbindliche Umsetzung'],['Akquisition','Jeder Plan verbraucht genau B = 4, 8, 16 oder 32 Beobachtungen. Kein Frühstopp; Kosten je Beobachtung = 1.'],['Prüfung','128 zusätzliche Beobachtungen: 64 je Intervention; im Beobachtungskontrollfall 128 für die einzige Aktion. Gemeinsame Prüfmenge pro Episode.'],['Paarung','Identische potentielle Ergebnisfolgen je Aktion für alle Pläne und Budgets. Ein Plan sieht nur die Ergebnisse seiner tatsächlich angeforderten Messungen.'],['Datentrennung','Getrennte Seed-Domänen für Entwicklung, Test, Akquisition, Prüfung und Zufallsplan. Prüfwerte werden erst nach Fixierung sämtlicher Vorhersagen einer Episode erzeugt.'],['Einfrieren','Quellstand vor Entwicklung versioniert; Testfreigabe nach Entwicklung und Nachrechnung, vor der ersten Testakquisition. Keine externe Präregistrierung.']],[105,402])
add('Rechenbudgets sind gleiche Obergrenzen: 1 s Online-CPU je Planlauf, 30 s Offline-Design je Konfiguration, 600 s je Akquisitionspartition, 1 GiB Prozess-RSS und 128 MiB Ausgabedaten. Tatsächlicher CPU-Verbrauch ist unterschiedlich und wird separat berichtet.','SmallX')

page('Unsicherheit und Entscheidungsregel','02 / PRIMÄRE AUSWERTUNG')
add('Primärwert ist der mittlere Brier-Score auf den getrennten Prüfdaten: (q - y)², gleich über die verfügbaren Aktionen gewichtet. Die acht Kontraste sind „Adaptiv minus Fest“ und „Adaptiv minus Zufällig“ bei vier Budgets. Negative Werte sprechen beobachtet für Adaptiv.')
add('Vorab wurde eine gemeinsame Fehlerwahrscheinlichkeit von höchstens 5 % über diese acht Kontraste festgelegt. Für unabhängige Episoden und gepaarte Differenzen in [-1,1] verwendet die Bestätigungsregel Hoeffding-Intervalle mit Radius √(2 ln(2·8/0,05)/4.608) = <b>0,050036</b>. Die einzelnen Intervalle sind bewusst konservativ; Null liegt in allen acht Intervallen.')
data=[['B','Vergleich','Mittlere Differenz','Bestätigendes Intervall','Approximatives Intervall']]
for x in a['primary']['contrasts']:
    base=x['comparison'].split(' minus ')[1];data.append([x['budget'],'A - '+short[base],num(x['mean_brier_difference']),ci(x['simultaneous_hoeffding_interval']),ci(x['approximate_bonferroni_normal_interval'])])
table(data,[24,61,90,166,166])
add('Bestätigende Intervalle: simultane Hoeffding-Absicherung. Rechte Spalte: Bonferroni-korrigierte Normalapproximation mit gepaarter, nach Strata berechneter Varianz. Diese engere Näherung ist vorab als sekundäre Diagnose definiert und ersetzt die Bestätigungsregel nicht.','SmallX')
add('Alle sekundären Näherungsintervalle liegen unter null. Das ist ein konsistenter Hinweis auf einen Vorteil innerhalb dieses Versuchs. Es ist kein Grund, die vorab festgelegte Hauptentscheidung nachträglich aufzuwerten. Grössere Bestätigungsstichproben oder eine vorab begründete schärfere Schranke wären eine neue Kampagne.')
add('Die beobachtete Fehlerreduktion gegenüber dem festen Plan beträgt '+', '.join(pct(1-cell('in_model',b,'adaptive_eig')['brier_mean']/cell('in_model',b,'fixed_optimal')['brier_mean']) for b in c['budgets'])+' für B = 4, 8, 16, 32. Relativwerte sind rein beschreibend.')
section('Weitere Resultate im Modell')
table([['B','Klassentreffer A / F / Z','Entropie A / F / Z (Bit)','Wahrheits-MSE A / F / Z']]+[[b,' / '.join(num(100*cell('in_model',b,p)['class_accuracy'],1) for p in policies),' / '.join(num(cell('in_model',b,p)['entropy_bits_mean'],3) for p in policies),' / '.join(num(cell('in_model',b,p)['truth_mse_mean'],5) for p in policies)] for b in c['budgets']],[25,155,157,170])
add('A = Adaptiv, F = Fest optimal, Z = Zufällig. Klassentreffer in Prozent, nur bei wahrem Kandidaten im Modell. Wahrheits-MSE nutzt die bekannten Simulationswahrscheinlichkeiten ausschliesslich zur Auswertung. MAP-Gleichstände bis 10⁻¹² werden zugunsten der kleinsten Klassen-ID aufgelöst; Aktionengleichstände ebenfalls. Dadurch sind einzelne Klassen nicht symmetrisch behandelt.','SmallX')

page('Technische Prüfung und Rechenaufwand','03 / NACHRECHNUNG')
table([['Prüfung','Resultat / Umfang'],['Vorab-Gates','12/12 bestanden: Bayes-/Informationsrechnung, vollständiges Festdesign, Messbudgets, getrennte Seed-Domänen, exakte Binomialtests, unbekannte Plan-ID, Speicherfehler und Ressourcengrenzen.'],['Entwicklung','352 Episoden, 4.224 Planläufe und 63.360 verwendete Messungen vollständig separat nachgerechnet. Keine Anpassung von Regeln oder Schwellen.'],['Test','5.632 Episoden, 67.584 Planläufe und 1.013.760 verwendete Messungen vollständig separat nachgerechnet.'],['Rechenwege','Posterior aus rationalen Zähldaten-Likelihoods; EIG durch Ergebnisenumeration; Festdesign aus SciPy-Binomialprodukten; Prüf-Gates mit SciPy-Binomialtests.'],['Bericht','204 aggregierte Zellen und acht Hauptkontraste mit separater Standardbibliotheksrechnung geprüft. Diese Berichtsprüfung entstand nach dem Test und änderte keine Analyse.']],[105,402])
add('„Separat“ bezeichnet einen zweiten Implementierungsweg desselben Autors. Es gab keine unabhängige Person und keine Blindprüfung. Alle Zufallsbanken wurden mit denselben festgelegten Python-PRNG-Regeln regeneriert; das ist keine Zertifizierung physikalischer oder kryptografischer Unabhängigkeit.')
section('Gemessene Online-CPU je Planlauf')
table([['B','Plan','Mittel (ms)','Median (ms)','95%-Quantil (ms)']]+[[b,names[p],num(cell('in_model',b,p)['cpu_ms_mean'],4),num(cell('in_model',b,p)['cpu_ms_median'],4),num(cell('in_model',b,p)['cpu_ms_p95'],4)] for b in c['budgets'] for p in policies],[26,118,110,115,138])
add('Diese Zeiten sind Diagnostik auf einem gemeinsam genutzten Host, keine belastbare Hardware-Rangfolge. Sie umfassen Plan-Ausführung, Posterior-Update und Mess-Callback. Die Vorab-Erzeugung der Zufallspläne und Ergebnisbanken liegt ausserhalb dieses Zeitfensters; ihr Aufwand wurde nicht separat gemessen. Daher ist keine vollständige Gesamtkosten-Rangfolge ableitbar.','SmallX')
add('Exhaustive Festdesign-Vorbereitung: <b>'+num(sum(d['offline_cpu_seconds'] for d in a['fixed_designs'].values()),3)+' CPU-s</b> für 16 Konfigurationen und 196 geprüfte Verteilungen. Testakquisition: '+num(a['resources']['wall_seconds'],3)+' s Wandzeit, '+num(a['resources']['online_cpu_seconds'],3)+' s Online-CPU, '+num(a['resources']['peak_rss_kib']/1024,1)+' MiB Prozessmaximum. Die anschliessende Vollnachrechnung benötigte '+num(ref['wall_seconds'],3)+' s Wandzeit. Alle festgelegten Grenzen eingehalten.','SmallX')

# Complete 132-stratum-cell metric tables, 3 pages + controls.
for eps,title in [('0','Ohne Leserauschen'),('1/10','10 % Leserauschen'),('1/4','25 % Leserauschen')]:
    page('Vollständige Modellresultate: '+title,'04 / ALLE STRATA')
    add('Je Zeile 512 Testepisoden. Brier und Log-Loss auf der getrennten Prüfmenge; kleinere Werte sind besser. MSE = Fehler zur bekannten Ereigniswahrscheinlichkeit. Treffer nur für die Klassenidentifikation. Online-CPU hier als Median.','SmallX')
    for h,label in enumerate(['C0: X→Y','C1: Y→X','C2: gemeinsame Ursache']):
        add(label,'Hsmall');group=f'stratum:noise{eps}_class{h}'
        data=[['B','Plan','Brier','Treffer %','Entropie','MSE','Log-Loss','Aktion 0 %','CPU ms']]
        for b in c['budgets']:
            for p in policies:
                x=cell(group,b,p);data.append([b,short[p],num(x['brier_mean']),num(100*x['class_accuracy'],1),num(x['entropy_bits_mean'],3),num(x['truth_mse_mean']),num(x['log_loss_mean'],4),num(100*x['action0_fraction_mean'],1),num(x['cpu_ms_median'],4)])
        t=table(data,[22,45,62,54,57,62,62,73,70],size=7.3)
        t.setStyle(TableStyle([('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    add('Alle 132 Stratum-/Budget-/Planzellen stehen zusätzlich mit voller Präzision und weiteren Zeit-/Gatewerten in analysis.json. Einzelne Strata können andere Rangfolgen zeigen als der gleich gewichtete Hauptvergleich.','SmallX')

page('Kontrollfälle und absolute Modellprüfung','05 / GRENZEN DES MODELLS')
add('<b>Nur Beobachtung:</b> Alle drei Mechanismen sind für die erlaubte Aktion ununterscheidbar und werden zu einer Vorhersageklasse zusammengefasst. Entropie null bedeutet hier keine Identifikation des kausalen Mechanismus. Alle drei Planer liefern identische Prüf-Scores; die Klassen-Trefferquote wird nicht definiert.')
add('<b>Ausserhalb des Modells:</b> Die wahre Wahrscheinlichkeit beträgt (0,2; 0,2), während kein Kandidat darunter liegt. Der Posterior konzentriert sich bei allen drei Plänen stark auf C2. Trotzdem verwirft die unabhängige Prüfmenge in <b>512/512 Episoden sämtliche Kandidaten</b>. Hohe innere Sicherheit ist damit kein Nachweis der Modellgültigkeit.')
for control,label in [('observational_only','Nur Beobachtung'),('outside_model','Wahrer Generator ausserhalb des Kandidatenmodells')]:
    add(label,'Hsmall');data=[['B','Plan','Brier','Entropie (Bit)','Wahrheits-MSE','Log-Loss']]
    for b in c['budgets']:
        for p in policies:
            x=cell('control:'+control,b,p);data.append([b,short[p],num(x['brier_mean'],6),num(x['entropy_bits_mean'],6),num(x['truth_mse_mean'],6),num(x['log_loss_mean'],5)])
    t=table(data,[26,65,102,107,109,98]);t.setStyle(TableStyle([('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
add('Pro Episode erfolgt genau ein zweiseitiger exakter Binomialtest je Kandidat/Aktion, mit Wahrscheinlichkeitsordnung und Bonferroni-Schwelle 0,05/(K·A). Ein Kandidat bleibt nur erhalten, wenn keine seiner Aktionen verworfen wird. Die Familiengrenze gilt innerhalb einer Episode, nicht gleichzeitig über die gesamte Kampagne.','SmallX')

page('Prüf-Gates, Herkunft und Reproduktion','06 / EVIDENZ')
table([['Stratum (je n = 512)','Alle Kandidaten verworfen','Wahre Klasse verworfen']]+[[g['stratum'],str(g['model_set_inadequate_count'])+' / 512','n. a.' if g['true_class_rejected_count'] is None else str(g['true_class_rejected_count'])+' / 512'] for g in a['heldout_model_checks']],[245,137,125])
add('Im Modell werden insgesamt 52/4.608 Episoden als ungeeignetes Kandidatenset markiert; die wahre Klasse wird 64/4.608-mal verworfen. Beim Beobachtungskontrollfall sind es 21/512. Das sind beobachtete Fehlalarmhäufigkeiten bei wiederholten Einzelprüfungen, kein Anspruch einer kampagnenweiten 5%-Grenze. Auch verworfene Episoden bleiben vollständig in der Leistungsanalyse.')
add('Provenienz','Hsmall')
add('Kampagne: '+c['campaign']+'<br/>Quellstand vor Akquisition: '+freeze['source_commit']+'<br/>Test-Freeze (UTC): '+freeze['created_utc']+'<br/>Baseline-Repository: github.com/thomasmgfeller/x6-spectral-astrolabium<br/>Referenzgenerator: Commit '+c['source_reference_commit']+'<br/>Referenzpfad: experimental/neutral_discovery/discovery.py','CodeX')
add('Python 3.12.14 · NumPy 2.3.5 · SciPy 1.17.0 · Linux x86_64. Der Root-Seed 2026101401 wird mit Kampagne, Partition, Episode, Datenzweck und Aktion über SHA-256 zu getrennten Python-Random-Seeds abgeleitet. Unabhängigkeit der so getrennten Ströme ist eine Modellannahme.')
add('Speichersicherung und offene Grenze','Hsmall')
add('Jede Datei wird exklusiv veröffentlicht, mit Datei-/Verzeichnis-fsync, Längen- und SHA-256-Rückleseprüfung. Erst nach vollständiger Ausgabe entsteht COMPLETE.json. Fehler vor oder nach Veröffentlichung, fehlende, verkürzte oder verfälschte Dateien sowie ungültige Ressourcenmetadaten wurden kontrolliert geprüft. Das qualifiziert keinen Stromausfalltest. Die Ursache der früheren U1-Archivverkürzung bleibt ungeklärt.')
add('Inhalt des Reproduktionspakets','Hsmall')
add('Das Paket enthält den vollständigen Bericht, alle acht eingefrorenen Quelldateien einschliesslich README, den Vertrag, sämtliche Entwicklungs- und Test-Rohdaten, alle Aktions-/Ergebnisfolgen, feste Designenumerationen, Freeze- und Abschlussprotokolle, getrennte Nachrechnungen, analysis.json mit 204 Zellen, die zusätzliche Berichtsprüfung, Abbildungs-/Berichtscode, Herkunftsnachweise und ein SHA-256-Dateiinventar. Zeitmessungen und UTC-Stempel variieren bei Wiederholung; die Messfolgen und Scores sind deterministisch reproduzierbar.')
add('Zur erneuten Prüfung im Paket: im Verzeichnis benchmark den Befehl <b>python -c &quot;import reference; print(reference.verify(\'evidence/campaign-v0.1\', \'test\'))&quot;</b> ausführen. Für eine neue Kampagne die Schritte in README.md mit einem neuen Zielverzeichnis ausführen. Vorhandene Evidenzdateien werden nicht überschrieben.','SmallX')

page('Einordnung und Quellen','07 / AUSSAGEGRENZEN')
add('Was dieser Benchmark trägt','Hsmall')
add('Ein vollständig nachvollziehbarer Vergleich dreier fest definierter Planungsregeln unter identischen Messkosten, gepaarten Ergebnisfolgen und unangetasteten Prüfdaten. Die feste Vergleichsregel wurde über sämtliche zulässigen Aufteilungen optimiert. Es wurden sämtliche Budgets und Bedingungen berichtet, einschliesslich fehlender Identifizierbarkeit und eines falschen Kandidatenmodells.')
add('Was die Zahlen nicht tragen','Hsmall')
add('Die acht primären Überlegenheitsentscheidungen bleiben unentschieden. Das bedeutet weder Gleichwertigkeit noch Widerlegung des beobachteten Vorteils. Greedy-EIG wird nicht als global optimale adaptive Strategie bezeichnet. Der Kandidatenraum ist klein, das Rauschen bekannt, die Beobachtungen binär und die Aktionskosten gleich. Verborgene Drift, unbekanntes Rauschen, teure Interventionen und physikalische Messsysteme sind nicht geprüft.')
add('Die Vorhersagegüte und die absolute Modellprüfung erfüllen unterschiedliche Aufgaben. Die Aussenmodell-Kontrolle zeigt, dass die Kandidaten intern fast sicher gewichtet werden können und dennoch allesamt falsch sind. Dieser Befund ist im Kontrollversuch direkt beobachtet; er ersetzt keine allgemeine Robustheitsanalyse.')
add('Methodischer Bezug','Hsmall')
add('[1] Huan, X.; Marzouk, Y. M. (2016). <i>Sequential Bayesian optimal experimental design via approximate dynamic programming.</i> arXiv:1604.08320. Einordnung von festen und myopischen Strategien gegenüber sequenzieller Optimierung.<br/><link href="https://arxiv.org/abs/1604.08320" color="#166a87">https://arxiv.org/abs/1604.08320</link>')
add('[2] Catanach, T. A.; Das, N. (2023). <i>Metrics for Bayesian Optimal Experiment Design under Model Misspecification.</i> arXiv:2304.07949. Methodischer Bezug für die getrennte Behandlung von Informationsgewinn und Modellabweichung.<br/><link href="https://arxiv.org/abs/2304.07949" color="#166a87">https://arxiv.org/abs/2304.07949</link>')
add('[3] Lüth, C.; Bungert, T.; Klein, L.; Jaeger, P. (2023). <i>Navigating the Pitfalls of Active Learning Evaluation: A Systematic Framework for Meaningful Performance Assessment.</i> NeurIPS 36. Bezug für explizite Vergleichsbedingungen und vollständige Auswertung; dessen Bildklassifikationsbenchmark wird hier nicht repliziert.<br/><link href="https://doi.org/10.52202/075280-0428" color="#166a87">https://doi.org/10.52202/075280-0428</link>')
add('Eigene Primärevidenz: contract.json, freeze.json, development/ und test/, development-reference.json, test-reference.json, technical-gate.json, analysis.json, aggregation-check.json. Alle Aussagen zu dieser Kampagne sind aus diesen Dateien abgeleitet. Die externe Literatur liefert den methodischen Bezug und keine Bestätigung der hier gemessenen Resultate.','SmallX')
add('Arbeitsstatus','Hsmall')
add('<b>Benchmarking abgeschlossen.</b> Der reproduzierbare synthetische Vergleich, getrennte Prüfdaten und vollständige Ergebnisberichte liegen vor. Eine stärkere statistische Bestätigung wäre ein neuer, vorab dimensionierter Versuch; RAX-U2 bleibt eine eigene Aufgabe.')

def footer(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(LINE);canvas.line(44,39,A4[0]-44,39);canvas.setFont('DejaVu',7);canvas.setFillColor(GRAY);canvas.drawString(44,26,'RAX-B1 · Benchmarking v0.1 · Synthetische Kontrolle');canvas.drawRightString(A4[0]-44,26,str(doc.page));canvas.restoreState()
path=OUT/'pdf/RAX_B1_Benchmarking_v0_1.pdf';path.parent.mkdir(parents=True,exist_ok=True)
doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=38,bottomMargin=50,title='RAX-B1 Benchmarking v0.1',author='RAX/X6 - Auswertung mit Codex',pageCompression=1)
doc.build(flow,onFirstPage=footer,onLaterPages=footer);print(path)
