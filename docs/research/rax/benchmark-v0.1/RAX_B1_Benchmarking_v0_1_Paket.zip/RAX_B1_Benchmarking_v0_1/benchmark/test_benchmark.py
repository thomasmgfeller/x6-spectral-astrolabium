#!/usr/bin/env python3
"""Behavioral and fault-injection gates before any heldout test outcomes."""
import io
import json
from pathlib import Path
import tempfile
import unittest
from fractions import Fraction as F
import numpy as np
from scipy.stats import binomtest
import core
import run
import reference
from storage import encoded,write_once,verify_complete

class BenchmarkGates(unittest.TestCase):
    def test_reference_mechanisms_and_noise(self):
        self.assertEqual(core.table('0'),((F(1),F(1,2)),(F(1,2),F(1)),(F(1,2),F(1,2))))
        self.assertEqual(core.table('1/4'),((F(3,4),F(1,2)),(F(1,2),F(3,4)),(F(1,2),F(1,2))))
        self.assertEqual(core.table('1/10',True),((F(9,10),),))

    def test_independent_posterior_and_information(self):
        for noise in ['0','1/10','1/4']:
            p=core.table(noise);w=(1/3,)*3;counts=[0]*4
            for t,(a,y) in enumerate([(0,1),(1,1),(0,1),(1,0),(0,1),(1,1)]):
                self.assertEqual(core.choose(w,p,t),reference.decision(noise,False,tuple(counts)))
                w=core.update(w,p,a,y);counts[2*a]+=1;counts[2*a+1]+=y
                np.testing.assert_allclose(w,list(map(float,reference.posterior(noise,False,tuple(counts)))),atol=1e-13)

    def test_full_fixed_allocation_reference(self):
        c=run.load(run.HERE/'contract.json');designs={}
        for eps,obs in [(x,False) for x in ['0','1/10','1/4']]+[('1/10',True)]:
            for b in c['budgets']:
                d=core.fixed_design(core.table(eps,obs),b);d['offline_cpu_seconds']=0;designs[f'{eps}:{int(obs)}:{b}']=d
        self.assertEqual(reference.verify_designs(c,designs),196)

    def test_exact_budgets_and_holdout_isolation(self):
        for obs in [False,True]:
            p=core.table('1/10',obs);A=len(p[0])
            for b in [4,8,16,32]:
                allocation=[b] if obs else [b//2,b//2]
                for policy in ['adaptive_eig','fixed_optimal','random_uniform']:
                    traces=[]
                    for unrelated_challenge in [np.zeros(128),np.ones(128)]:
                        calls=[]
                        def measure(a):calls.append(a);return int(len(calls)%3!=0)
                        r=core.run_policy(policy,p,b,allocation,[t%A for t in range(b)],measure)
                        self.assertEqual(len(calls),b);self.assertEqual(sum(r['action_counts']),b);traces.append(r)
                    self.assertEqual(traces[0],traces[1])

    def test_unknown_policy_rejected(self):
        with self.assertRaises(ValueError):core.run_policy('bad',core.table('0'),1,[1,0],[0],lambda a:1)

    def test_seed_domains_and_regeneration(self):
        c=run.load(run.HERE/'contract.json');domains=[run.seed(c,phase,'episode',domain,a) for phase in ['development','test'] for domain in ['acquisition','challenge','random_plan'] for a in [0,1]]
        self.assertEqual(len(set(domains)),len(domains))
        first=run.generate(c,'test','test:0:0','acquisition',(F(3,4),F(1,2)),32)
        second=run.generate(c,'test','test:0:0','acquisition',(F(3,4),F(1,2)),32)
        np.testing.assert_array_equal(first,second)

    def test_exact_binomial_reference(self):
        for n in [8,64,128]:
            for prob in [F(0),F(1,5),F(1,2),F(3,4),F(9,10),F(1)]:
                for den in [20,120]:
                    exact=core.binomial_rejection_mask(n,prob,1,den)
                    self.assertEqual(exact,[binomtest(k,n,float(prob)).pvalue<=1/den for k in range(n+1)])

    def test_write_once_readback_and_duplicate(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'raw';data=b'0123456789'*10000;meta=write_once(p,data)
            self.assertEqual(p.read_bytes(),data);self.assertEqual(meta['bytes'],len(data))
            with self.assertRaises(FileExistsError):write_once(p,b'replacement')
            self.assertEqual(p.read_bytes(),data)

    def test_before_publish_fault_is_incomplete(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'raw'
            with self.assertRaises(OSError):write_once(p,b'bytes',fault='before_publish')
            self.assertFalse(p.exists())
            with self.assertRaises(FileNotFoundError):verify_complete(tmp)

    def test_after_publish_fault_is_incomplete(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'raw'
            with self.assertRaises(OSError):write_once(p,b'bytes',fault='after_publish')
            self.assertEqual(p.read_bytes(),b'bytes')
            with self.assertRaises(FileNotFoundError):verify_complete(tmp)

    def test_corruption_missing_and_path_escape_rejected(self):
        for mode in ['truncated','corrupt','missing','escape']:
            with tempfile.TemporaryDirectory() as tmp:
                folder=Path(tmp);meta=write_once(folder/'raw',b'0123456789')
                write_once(folder/'COMPLETE.json',encoded({'status':'COMPLETE','files':{'raw':meta}}));verify_complete(folder)
                if mode=='truncated':(folder/'raw').write_bytes(b'012345678')
                if mode=='corrupt':(folder/'raw').write_bytes(b'012345678X')
                if mode=='missing':(folder/'raw').unlink()
                if mode=='escape':(folder/'COMPLETE.json').write_bytes(encoded({'status':'COMPLETE','files':{'../raw':meta}}))
                with self.assertRaises(ValueError):verify_complete(folder)

    def test_negative_and_excess_resource_metadata_rejected(self):
        c=run.load(run.HERE/'contract.json');valid={'episodes':1,'policy_budget_runs':12,'wall_seconds':1,'peak_rss_kib':1000,'output_payload_bytes':100,'online_cpu_seconds':.1,'fsync_readback_each_file':True,'power_loss_tested':False}
        reference.validate_metadata(valid,c,1,12)
        for key,value in [('wall_seconds',-1),('wall_seconds',601),('peak_rss_kib',1048577),('output_payload_bytes',134217729),('online_cpu_seconds',float('nan'))]:
            with self.assertRaises(ValueError):reference.validate_metadata(dict(valid,**{key:value}),c,1,12)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--gate',type=Path);args=parser.parse_args()
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BenchmarkGates))
    print(stream.getvalue(),end='')
    if args.gate:
        write_once(args.gate,encoded({'status':'PASS' if result.wasSuccessful() else 'FAIL','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'source_hashes':run.source_hashes(),'log':stream.getvalue(),'controlled_write_faults_only':True,'power_loss_tested':False,'created_utc':run.now()}))
    raise SystemExit(0 if result.wasSuccessful() else 1)
