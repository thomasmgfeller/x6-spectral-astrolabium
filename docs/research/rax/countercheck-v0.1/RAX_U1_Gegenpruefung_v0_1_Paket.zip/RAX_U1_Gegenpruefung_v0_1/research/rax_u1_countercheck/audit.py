#!/usr/bin/env python3
"""Post-hoc U1 countercheck. Does not import either original implementation.

Integer row representation and the matrix criterion PV=VUPV; vectorized raw
recount; Decimal intervals; binomial sums with a second, mode-recurrence route.
All probability calibrations assume the ideal independent Bernoulli model.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.stats import binom

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
U1 = ROOT / 'research/rax_u1'
EVIDENCE = U1 / 'evidence/qualification'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'duplicate JSON key')
            result[k] = v
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def metadata_gate(folder):
    c = read(folder / 'contract.json')
    a = read(folder / 'acquisition.json')
    elapsed, rss = a['elapsed_seconds'], a['peak_rss_kib']
    require(type(elapsed) in (int, float) and math.isfinite(elapsed)
            and 0 <= elapsed <= c['limits']['runtime_seconds'], 'runtime budget metadata')
    require(type(rss) is int and 0 <= rss <= 1024*c['limits']['address_space_mib'], 'memory budget metadata')
    require((folder/'trials.bin').stat().st_size == c['limits']['raw_bytes'], 'raw byte size')
    require(sha(folder/'trials.bin') == a['raw_sha256'], 'raw digest')
    total = sum(p.stat().st_size for p in folder.rglob('*') if p.is_file())
    require(total <= c['limits']['total_output_bytes'], 'archive output budget')
    return {'status': 'PASS', 'archive_bytes': total, 'elapsed_seconds': elapsed, 'peak_rss_kib': rss}


def integer_matrix(model, rates, lam, deviations=None):
    """Each row stores unreduced integer numerators and one denominator."""
    m = model['m']
    rows = []
    for i in range(2*m):
        a, index = divmod(i, m)
        r = Fraction(rates[a]) + (Fraction(lam)*model['h'][i] if deviations is None else deviations[i])
        require(0 < r < 1, 'interior row probability')
        blocks = [model['weights'][str(a)+str(b)][index] for b in range(2)]
        totals = [sum(w) for w in blocks]
        common = math.lcm(*totals)
        denominator = r.denominator*common
        row = []
        for b in range(2):
            numerator = r.numerator if a != b else r.denominator-r.numerator
            row.extend(numerator*w*(common//totals[b]) for w in blocks[b])
        require(all(type(v) is int and v >= 0 for v in row) and sum(row) == denominator, 'stochastic integer row')
        rows.append((row, denominator))
    return rows


def projection_check(rows, labels, rates=None):
    """Compute PV and Q=UPV, U uniform per block, then compare PV with VQ."""
    labels = np.array(labels)
    blocks = sorted(set(labels.tolist()))
    pv = [[Fraction(sum(w for w, label in zip(row, labels) if label == b), den)
           for b in blocks] for row, den in rows]
    q = [[sum(pv[i][b] for i in range(len(rows)) if labels[i] == a)
          / int(np.sum(labels == a)) for b in range(len(blocks))] for a in blocks]
    residual = max(abs(pv[i][b]-q[blocks.index(labels[i])][b])
                   for i in range(len(rows)) for b in range(len(blocks)))
    delta = max(max(pv[i][b] for i in range(len(rows)) if labels[i] == a)
                - min(pv[i][b] for i in range(len(rows)) if labels[i] == a)
                for a in blocks for b in range(len(blocks)))
    loss = None if rates is None else max(abs(pv[i][1-labels[i]]-Fraction(rates[labels[i]]))
                                         for i in range(len(rows)))
    return {'lumpable': residual == 0, 'matrix_residual': residual, 'delta': delta,
            'prediction_loss': loss, 'q': q, 'pv': pv}


def exact_matrices(models, c, report):
    cases = []
    relabelings = 0
    for case in report['cases']:
        model = next(m for m in models if m['id'] == case['model_id'])
        m = model['m']; rates = c['protocols'][case['protocol']]
        rows = integer_matrix(model, rates, case['lambda'])
        strings = [[str(Fraction(v, d)) for v in row] for row, d in rows]
        require(hashlib.sha256(canonical(strings)).hexdigest() == case['matrix_sha256'], 'full matrix digest')
        result = projection_check(rows, [i//m for i in range(2*m)], rates)
        require(result['lumpable'] == case['lumpable'], 'matrix criterion disagreement')
        require(str(result['delta']) == case['delta'] and str(result['prediction_loss']) == case['prediction_loss'], 'loss disagreement')
        require(result['matrix_residual'] == Fraction(case['lambda']), 'residual identity')
        # Deterministic permutations unrelated to the original reversal check.
        for multiplier, shift in ((1, 1), (3, 2), (5, 3), (7, 5)):
            order = [(multiplier*i+shift) % (2*m) for i in range(2*m)]
            moved = [([rows[i][0][j] for j in order], rows[i][1]) for i in order]
            transported = projection_check(moved, [i//m for i in order], rates)
            require(all(transported[k] == result[k] for k in ('lumpable', 'matrix_residual', 'delta', 'prediction_loss', 'q')), 'permutation invariance')
            relabelings += 1
        cases.append({'model_id': model['id'], 'protocol': case['protocol'], 'lambda': case['lambda'],
                      'lumpable': result['lumpable'], 'residual': str(result['matrix_residual'])})
    shifted = 0
    for model in models:
        for rates in c['protocols'].values():
            changed = [Fraction(rates[0])+Fraction(1, 10), Fraction(rates[1])]
            p = projection_check(integer_matrix(model, changed, 0), [i//model['m'] for i in range(2*model['m'])], rates)
            require(p['lumpable'] and p['prediction_loss'] == Fraction(1, 10), 'shifted negative control')
            shifted += 1
    return {'status': 'PASS', 'matrices': len(cases), 'lumpable': sum(x['lumpable'] for x in cases),
            'non_lumpable': sum(not x['lumpable'] for x in cases), 'permutations': relabelings,
            'shifted_controls': shifted, 'cases': cases}


def decision(counts, n=20000):
    with localcontext() as ctx:
        ctx.prec = 80
        d = Decimal
        b = (d(6400).ln()/d(2*n)).sqrt()
        ps = [d(int(k))/n for k in counts]
        centers = [d('0.35'), d('0.35'), d('0.45'), d('0.45')]
        intervals = [[max(d(0), p-b), min(d(1), p+b)] for p in ps]
        pred = [[max(d(0), abs(p-r)-b), min(d(1), abs(p-r)+b)] for p, r in zip(ps, centers)]
        block = [[max(d(0), abs(ps[j]-ps[j+1])-2*b), min(d(1), abs(ps[j]-ps[j+1])+2*b)] for j in (0, 2)]
        support = all(x[1] <= d('0.025') for x in pred) and all(x[1] <= d('0.05') for x in block)
        reject = any(x[0] > d('0.025') for x in pred) or any(x[0] > d('0.05') for x in block)
        status = 'APPROXIMATE_REDUCTION_SUPPORTED' if support else 'REDUCTION_REJECTED' if reject else 'INCONCLUSIVE'
        return {'status': status, 'p_hat': list(map(float, ps)),
                'probability_intervals': [[float(v) for v in x] for x in intervals],
                'prediction_bounds': [[float(v) for v in x] for x in pred],
                'block_bounds': [[float(v) for v in x] for x in block]}


def raw_recount(folder, models, c):
    raw = np.frombuffer((folder/'trials.bin').read_bytes(), dtype=np.uint8).reshape(160, 20000, 2)
    acquisition = read(folder/'acquisition.json')
    saved = read(folder/'assessment.json')
    counts = []
    for j, record in enumerate(acquisition['records']):
        model = next(x for x in models if x['id'] == record['model_id'])
        m = model['m']; a = record['a']
        x, y = raw[j, :, 0], raw[j, :, 1]
        require(np.all(x < 2*m) and np.all(y < 2*m), 'state bounds')
        require(np.all(x//m == a) and np.all(np.array(model['h'])[x] == record['h']), 'preparation')
        rows = integer_matrix(model, c['protocols']['e3'], record['lambda'])
        support = np.array([[v > 0 for v in w] for w, _ in rows])
        require(np.all(support[x, y]), 'operator support')
        count = int(np.count_nonzero(y//m != x//m))
        require(count == record['switches'], 'raw count mismatch')
        counts.append(count)
    results = [decision(counts[j:j+4]) for j in range(0, 160, 4)]
    max_error = 0.0
    for result, expected in zip(results, saved['configs']):
        require(result['status'] == expected['status'], 'statistical decision mismatch')
        for key in ('p_hat', 'probability_intervals', 'prediction_bounds', 'block_bounds'):
            err = float(np.max(np.abs(np.array(result[key])-np.array(expected[key]))))
            max_error = max(max_error, err)
            require(err <= 5e-15, 'interval mismatch')
    return {'status': 'PASS', 'transitions': int(raw.shape[0]*raw.shape[1]), 'cells': len(counts),
            'configurations': len(results), 'counts': dict(Counter(r['status'] for r in results)),
            'max_absolute_float_discrepancy': max_error, 'raw_sha256': sha(folder/'trials.bin')}


def recurrence_mass(n, p):
    """Independent of scipy's CDF/PMF. Normalize weights propagated from mode."""
    mode = int(math.floor((n+1)*p))
    weights = np.zeros(n+1)
    weights[mode] = 1.0
    for k in range(mode, 0, -1):
        weights[k-1] = weights[k]*k/(n-k+1)*(1-p)/p
    for k in range(mode, n):
        weights[k+1] = weights[k]*(n-k)/(k+1)*p/(1-p)
    weights /= math.fsum(weights)
    return weights


def calibrate(c):
    n = 20000; b = math.sqrt(math.log(6400)/(2*n))
    support_radius = .025-b; nonreject_radius = .025+b
    max_error = 0.0
    result = []
    cache = {}
    # Boundary and just-outside-boundary cases are diagnostics, not new qualification data.
    for lam in (0, .01, .025, .02500001, .05, .1):
        ps = [r+s*lam for r in (.35, .45) for s in (-1, 1)]
        support_probs, nonreject_probs, nonreject_failures, coverage_failure = [], [], [], []
        for r, p in zip((.35, .35, .45, .45), ps):
            weights = cache.setdefault(p, None)
            if weights is None:
                weights = cache[p] = recurrence_mass(n, p)
            for radius, target in ((support_radius, support_probs), (nonreject_radius, nonreject_probs)):
                lo = math.ceil(n*(r-radius)); hi = math.floor(n*(r+radius))
                lower = float(binom.cdf(lo-1, n, p)); upper = float(binom.sf(hi, n, p))
                value = max(0.0, 1-lower-upper)
                independent = math.fsum(weights[lo:hi+1])
                max_error = max(max_error, abs(value-independent))
                require(abs(value-independent) < 2e-12, 'binomial recurrence/CDF mismatch')
                target.append(independent)
                if target is nonreject_probs:
                    nonreject_failures.append(min(1.0, lower+upper))
            lo = math.ceil(n*(p-b)); hi = math.floor(n*(p+b))
            coverage_failure.append(float(binom.cdf(lo-1, n, p)+binom.sf(hi, n, p)))
        support = math.prod(support_probs)
        reject = -math.expm1(math.fsum(math.log1p(-x) for x in nonreject_failures)) if all(x < 1 for x in nonreject_failures) else 1.0
        inconclusive = max(0.0, math.prod(nonreject_probs)-support)
        result.append({'lambda': lam, 'support_probability': support, 'reject_probability': reject,
                       'log10_support_probability': sum(math.log10(x) for x in support_probs) if all(support_probs) else None,
                       'inconclusive_probability': inconclusive,
                       'coverage_failure_union_bound_for_8_models': 8*sum(coverage_failure),
                       'false_decision_probability_per_configuration': reject if lam <= .025 else support})
    return {'model': 'Ideal independent Bernoulli draws; analytical finite binomial sums, floating point evaluation',
            'original_decisions_changed': False, 'b': b, 'support_radius': support_radius,
            'nonrejection_radius': nonreject_radius, 'max_CDF_recurrence_absolute_difference': max_error,
            'decision_block_gate_redundant_given_prediction_gate': True,
            'original_160_cell_coverage_failure_union_bound': sum(r['coverage_failure_union_bound_for_8_models'] for r in result if r['lambda'] != .02500001),
            'by_lambda': result}


def counterexamples():
    # Alter the microscopic rates within each declared preparation half so that
    # its average is unchanged. This is outside the registered U1 model family.
    m = 4
    model = {'m': m, 'h': [-1,-1,1,1]*2,
             'weights': {str(a)+str(b): [[1]*m for _ in range(m)] for a in range(2) for b in range(2)}}
    deviations = [Fraction(-1,10), Fraction(1,10)]*4
    rates = ['7/20','9/20']
    rows = integer_matrix(model, rates, 0, deviations)
    checked = projection_check(rows, [i//m for i in range(2*m)], rates)
    means = [sum(checked['pv'][i][1-a] for i in range(2*m) if i//m == a and model['h'][i] == s)/2
             for a in range(2) for s in (-1, 1)]
    require(means == [Fraction(7,20)]*2+[Fraction(9,20)]*2, 'counterexample means')
    require(checked['delta'] == Fraction(1,5) and checked['prediction_loss'] == Fraction(1,10), 'counterexample residual')
    fixture = decision([int(p*20000) for p in means])
    require(fixture['status'] == 'APPROXIMATE_REDUCTION_SUPPORTED' and not checked['lumpable'], 'counterexample gate')
    constant = projection_check(rows, [0]*8)
    require(constant['lumpable'], 'one-block projection is always lumpable')
    return {'within_preparation_heterogeneity': {
                'scope': 'Adversarial model outside the frozen U1 family; not qualification evidence',
                'matrix': [[str(Fraction(x,d)) for x in row] for row,d in rows],
                'preparation_means': list(map(str, means)), 'exact_delta': str(checked['delta']),
                'exact_prediction_loss': str(checked['prediction_loss']),
                'mean_count_fixture_status': fixture['status'], 'strong_lumpability': checked['lumpable'],
                'implication': 'Four preparation means do not certify arbitrary microstate maxima; U2 needs richer held-out challenges.'},
            'constant_projection': {'one_block_lumpability': True,
                'original_switch_event_minimax_loss_e3_lambda0': '1/20',
                'next_original_block_event_minimax_loss_e3_lambda0': '1/10',
                'own_constant_label_loss': '0',
                'implication': 'Keep the measured event fixed across candidate reductions. Constant means poor prediction here, not failure of lumpability.'}}


def integrity(root, folder):
    manifest = read(root/'RAX_U1_SOURCE_MANIFEST.json')
    for path, digest in manifest['files'].items():
        require(sha(root/path) == digest, 'source manifest: '+path)
    freeze = read(folder/'freeze.json')
    for name, digest in freeze['sources'].items():
        require(sha(folder/'sources'/name) == digest, 'frozen source: '+name)
    original = read(folder/'recovery/recovery.json')
    raw, damaged = (folder/'trials.bin').read_bytes(), (folder/'recovery/observed-trials.bin').read_bytes()
    require(raw.startswith(damaged) and len(raw)-len(damaged) == 720000, 'recovery prefix')
    require(sha(folder/'trials.bin') == original['restored_sha256'], 'restored digest')
    require(sha(folder/'recovery/observed-trials.bin') == original['observed_sha256'], 'damaged digest')
    return {'manifest_files': len(manifest['files']), 'status': 'PASS',
            'restored_bytes': len(raw), 'damaged_bytes': len(damaged), 'missing_original_bytes': len(raw)-len(damaged),
            'damaged_prefix_confirmed': True, 'cause': 'UNKNOWN', 'acquisition_durability_qualified': False}


def run():
    c = read(EVIDENCE/'contract.json'); models = read(EVIDENCE/'models.json')
    return {'schema': 'rax.u1.countercheck/1', 'created_utc': datetime.now(timezone.utc).isoformat(),
            'scope': 'Internal post-hoc review; not external or blind replication; not RAX-U2',
            'environment': {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__},
            'input_commit': 'ee88a0ecfb74b9743eac8edc96c0374d65771437',
            'audit_source_sha256': sha(__file__), 'plan_sha256': sha(HERE/'plan.json'),
            'integrity': integrity(ROOT, EVIDENCE), 'resource_metadata': metadata_gate(EVIDENCE),
            'matrix_check': exact_matrices(models, c, read(EVIDENCE/'exact.json')),
            'raw_recount': raw_recount(EVIDENCE, models, c),
            'decision_calibration': calibrate(c), 'counterexamples': counterexamples(),
            'physical_claim_supported': False, 'external_review': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = run()
    with args.output.open('x') as f:
        json.dump(result, f, indent=2, allow_nan=False); f.write('\n')
    print(json.dumps({'status': 'COMPLETED', 'output': str(args.output), 'counts': result['raw_recount']['counts'],
                      'coverage_failure_union_bound': result['decision_calibration']['original_160_cell_coverage_failure_union_bound']}, indent=2))
