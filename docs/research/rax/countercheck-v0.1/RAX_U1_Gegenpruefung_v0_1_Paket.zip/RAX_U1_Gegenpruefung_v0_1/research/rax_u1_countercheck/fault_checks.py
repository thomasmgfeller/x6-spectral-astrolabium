#!/usr/bin/env python3
"""Adversarial probes against original validators; operate only on temp copies."""
from copy import deepcopy
import itertools
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile

import audit

# Import original code only in this explicitly separate differential harness.
sys.path.insert(0, str(audit.U1))
import u1
import reference


def rejects(fn):
    try:
        fn()
        return False
    except (ValueError, OSError, KeyError, TypeError, IndexError):
        return True


def put(path, value):
    path.write_text(json.dumps(value, sort_keys=True, separators=(',', ':'))+'\n')


def run():
    out = []
    models = audit.read(audit.EVIDENCE/'models.json')
    contract = audit.read(audit.EVIDENCE/'contract.json')
    with tempfile.TemporaryDirectory(prefix='rax-countercheck-') as temp:
        path = Path(temp)/'probe'
        shutil.copytree(audit.EVIDENCE, path)
        original_acquisition = (path/'acquisition.json').read_bytes()
        for field, value in [('elapsed_seconds',121),('peak_rss_kib',262145)]:
            acq = json.loads(original_acquisition); acq[field] = value; put(path/'acquisition.json', acq)
            primary = u1.evaluate(path)['validity']
            old_reference = reference.verify(path)['status']
            new_rejects = rejects(lambda: audit.metadata_gate(path))
            audit.require(primary == 'INVALID' and old_reference == 'PASS' and new_rejects, 'resource gap probe changed')
            out.append({'probe': field+'_exceeded', 'primary': primary, 'original_reference': old_reference,
                        'new_metadata_gate_rejects': new_rejects, 'finding': 'Original reference omits this resource validity check.'})
            (path/'acquisition.json').write_bytes(original_acquisition)
        original_raw = (path/'trials.bin').read_bytes()
        for name, data in [('one_byte_missing', original_raw[:-1]),
                           ('one_byte_modified',bytes([original_raw[0]^1])+original_raw[1:])]:
            (path/'trials.bin').write_bytes(data)
            primary = u1.evaluate(path)['validity']
            gate = rejects(lambda: audit.metadata_gate(path))
            audit.require(primary == 'INVALID' and gate, 'raw mutation gate')
            out.append({'probe': name, 'primary': primary, 'new_gate_rejects': gate})
            (path/'trials.bin').write_bytes(original_raw)
        acq = json.loads(original_acquisition); acq['records'][0]['switches'] += 1
        put(path/'acquisition.json', acq)
        primary = u1.evaluate(path)['validity']
        gate = rejects(lambda: audit.raw_recount(path,models,contract))
        audit.require(primary == 'INVALID' and gate, 'raw count mismatch gate')
        out.append({'probe':'count_changed','primary':primary,'new_recount_rejects':gate})
        (path/'acquisition.json').write_bytes(original_acquisition)
        report = audit.read(path/'assessment.json')
        report['configs'][0]['status'] = 'REDUCTION_REJECTED'
        put(path/'assessment.json', report)
        gate = rejects(lambda: audit.raw_recount(path,models,contract))
        audit.require(gate, 'saved decision mutation')
        out.append({'probe':'saved_decision_changed','new_recount_rejects':gate})
    # Probe integer thresholds on both sides of support and rejection boundaries.
    records = audit.read(audit.EVIDENCE/'acquisition.json')['records']
    b = math.sqrt(math.log(6400)/40000)
    probes = []
    for center in (.35,.45):
        candidates = set()
        for radius in (.025-b,.025+b):
            for sign in (-1,1):
                v = math.floor(20000*(center+sign*radius))
                candidates.update((v,v+1))
        probes.append(sorted(candidates))
    checked = 0
    for index in range(4):
        for k in probes[index//2]:
            counts = [7000,7000,9000,9000]; counts[index] = k
            changed = deepcopy(records)
            for i,v in enumerate(counts): changed[i]['switches'] = v
            p = u1.assess_counts(changed,contract)['configs'][0]
            q = audit.decision(counts)
            audit.require(p['status'] == q['status'], 'boundary status mismatch')
            checked += 1
    # All combinations of paired extremal count offsets exercise triangle-inequality redundancy.
    for counts in itertools.product(probes[0],probes[0],probes[1],probes[1]):
        result = audit.decision(counts)
        errors = [abs(k/20000-r) for k,r in zip(counts,(.35,.35,.45,.45))]
        simplified = 'APPROXIMATE_REDUCTION_SUPPORTED' if max(errors) <= .025-b else 'REDUCTION_REJECTED' if max(errors) > .025+b else 'INCONCLUSIVE'
        audit.require(result['status'] == simplified, 'redundancy boundary probe')
        checked += 1
    return {'schema':'rax.u1.countercheck-faults/1','status':'PASS_EXPECTED_FINDINGS_REPRODUCED',
            'original_evidence_modified':False,'fault_probes':out,'boundary_decisions_checked':checked,
            'reference_gap_is_campaign_error':False,
            'interpretation':'Original data obey budgets. The missing checks affect standalone reference acceptance of altered metadata.'}


if __name__ == '__main__':
    result = run()
    output = Path(sys.argv[1])
    with output.open('x') as f: json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result,indent=2))
