# RAX-U1 Gegenprüfung v0.1

**Ergebnis:** Die Mathematik und die 40 Auswertungsentscheidungen des eingefrorenen
synthetischen U1-Kontrollversuchs sind bestätigt. Die Erfassung ist wegen des
offenen Archivvorfalls weiterhin nicht uneingeschränkt qualifiziert. Dies ist
eine interne Gegenprüfung nach Kenntnis der Ergebnisse, kein externes oder
verblindetes Review und kein RAX-U2-Entdeckungslauf.

## Ausgeführt

- Alle 160 Übergangsmatrizen unabhängig als ganzzahlige Zeilen rekonstruiert;
  vollständige kanonische Matrix-Digests identisch. Matrixkriterium `PV = VUPV`:
  32 lumpbar, 128 nicht lumpbar. Weitere 640 transportierte Permutationen und
  32 verschobene Kontrollen geprüft.
- 3.200.000 gespeicherte Übergänge vektorisiert neu gezählt; 160 Zellzählungen,
  40 Entscheidungen und 80-stellige Dezimalintervalle bestätigt. Grösste
  absolute Abweichung zur gespeicherten Float-Auswertung: 1,12e-16 (aufgerundet).
- Das ursprüngliche vollständige Referenz-Replay erneut ausgeführt; alle
  6.400.000 Bytes identisch. Keine neuen Qualifikationsstichproben erzeugt.
- 25 ursprüngliche Tests erneut bestanden. Sechs neue Fehlerproben und 4.128
  Grenzentscheidungen ausgeführt; die unten beschriebenen Lücken reproduziert.
- Binomialwahrscheinlichkeiten für die feste Entscheidungsregel numerisch
  berechnet, mit separater Rekurrenz vom Verteilungsmodus gegengeprüft.

## Befunde mit Konsequenzen

1. **Ressourcenprüfung im alten Referenzprüfer unvollständig.** Eine temporäre
   Kopie mit `elapsed_seconds=121` oder `peak_rss_kib=262145` erhält dort PASS.
   Der Hauptprüfer liefert INVALID. `audit.metadata_gate` verwirft diese Kopien.
   Die Originaldaten halten die Grenzen ein; die 8/16/16 Entscheidungen ändern
   sich nicht. Eingefrorener Code und Originale bleiben unverändert.
2. **Präparationsmittelwerte sind ausserhalb U1 nicht ausreichend.** Das explizite
   8-Zustands-Gegenbeispiel besitzt Mittelwerte 0,35/0,35/0,45/0,45 und könnte
   damit eine reine Mittelwertprüfung bestehen. Tatsächlich sind die maximale
   Blockheterogenität 0,20 und der Vorhersagefehler 0,10. Der exakte Matrixprüfer
   verwirft die Reduktion. Die feste U1-Generatorfamilie enthält dieses Modell
   nicht; U2 braucht zusätzliche Präparationen/Mikrorealisationen und Horizonte.
3. **Entscheidungskriterien redundant.** Weil `delta_block=2*delta_prediction`
   und beide Präparationen eines Blocks denselben Referenzwert verwenden,
   impliziert das Vorhersagekriterium das Blockkriterium. Es ist keine zweite
   unabhängige Bestätigung. Algebraischer Nachweis im PDF.
4. **Beobachtbares festhalten.** Jede konstante Ein-Block-Projektion ist lumpbar.
   Sie scheitert hier an der Vorhersage des ursprünglichen Blockwechsel-Ereignisses
   (Minimaxverlust 0,05), nicht an der Lumpbarkeit. Beim Ereignis „nächster
   ursprünglicher Block ist 1“ wäre der konstante Minimaxverlust 0,10.
5. **Archivvorfall offen.** Das beschädigte Archiv ist weiterhin ein exaktes
   Präfix mit 720.000 fehlenden Bytes. Die Wiederherstellung passt zum vorher
   festgehaltenen Digest. Daraus folgt keine Erklärung des Verlusts und keine
   Qualifikation für unbeaufsichtigte dauerhafte Erfassung.

## Reproduktion

Vom Wurzelordner des Reproduktionspakets oder Repositorys, Linux/Python 3.12:

```sh
python3 -m pip install -r research/rax_u1_countercheck/requirements.txt
python3 research/rax_u1_countercheck/audit.py --output audit-reproduced.json
python3 research/rax_u1_countercheck/fault_checks.py faults-reproduced.json
python3 research/rax_u1/reference.py research/rax_u1/evidence/qualification
python3 -m unittest discover -s research/rax_u1/tests -v
```

Ausgabedateien müssen neu sein. Zeitstempel und Laufzeiten sind veränderlich;
Matrixbefunde, Digests, Zählungen und Entscheidungen müssen gleich bleiben.
Die Fehlerproben ändern nur temporäre Kopien. Binomialkalibrierung setzt das
ideale Modell unabhängiger Bernoulli-Versuche voraus. Eine einzelne feste
pseudozufällige Folge beweist diese Modellannahme nicht.

`audit.py` importiert weder `u1.py` noch `reference.py`. Der getrennte
Fehlerproben-Harness `fault_checks.py` importiert sie bewusst, um deren Verhalten
zu vergleichen. Der neue Prüfer nutzt NumPy/SciPy; das ursprüngliche Replay
benötigt nur die Python-Standardbibliothek. Die Kalibrierung ist kein neuer
Signifikanztest und ersetzt keine registrierte Entscheidung.

## Dateien und Herkunft

`evidence/audit-final.json`: unabhängige Mathematik, Rohzählung und Kalibrierung.
`evidence/fault-checks.json`: Fehlerproben und Grenzentscheidungen.
`evidence/reference-rerun.json`: erneutes vollständiges Original-Replay.
`evidence/provenance.json`: Bindung der vier eingefrorenen Quelldateien an den
Implementierungscommit vor der Erfassung und Prüfung des Git-Bundles.
`plan.json`: nach Kenntnis der Resultate formulierter Gegenprüfungsumfang.

Untersuchter lokaler Stand: `ee88a0ecfb74b9743eac8edc96c0374d65771437`.
Implementierung vor Erfassung: `a8b5da3221fbb58e883400bd73923b302fcac55a`.
Der öffentliche `main` stand zu Beginn dieser Gegenprüfung auf `270e224`;
ein öffentlicher RAX-U1-Zweig wurde nicht gefunden. Diese Gegenprüfung selbst
belegt keinen GitHub-Upload. Hashes und lokale Git-Historie sind keine externe
Präregistrierung, keine Signatur und kein manipulationssicheres Register.

## Nächstes Abnahmegate

Vor einer uneingeschränkten technischen Freigabe: dauerhafte Speicherung mit
versioniertem Schreibprotokoll, Flush/fsync, erneutem Öffnen und Hashvergleich
sowie Abbruch-/Kürzungs-/Neustarttests qualifizieren. Die konkrete Ursache des
alten Vorfalls bleibt bis zu einer tatsächlichen Diagnose UNKNOWN.
Die ergänzte Ressourcenprüfung in eine neue Runner-Version übernehmen;
eingefrorene historische Quellen nicht rückwirkend ändern.
Vor U2: feste Messereignisse, heterogene Präparationen, zurückgehaltene
Mikrorealisationen, Mehrschritthorizonte und eigenes Fehlerbudget registrieren.

## Methodische Quellen

- Tian & Kannan (2006), Theoreme 2.3 und 2.5:
  https://people.nmsu.edu/jtian/publications/2006-3.pdf
- Hoeffding (1963), DOI: https://doi.org/10.1080/01621459.1963.10500830
- SciPy, Binomialverteilung und CDF/SF:
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.binom.html

Die Konstruktion des Gegenbeispiels, die Redundanzableitung und die konkreten
Prüfresultate stammen aus dieser Gegenprüfung. Es wurde keine neue Physik und
keine unbekannte Universalitätsklasse nachgewiesen.
