# RAX-U1 — bekannte Markov-Reduktion und kontrollierte Verletzung

**Ausführbare synthetische Softwarekontrolle. Keine physische Messung und keine
Entdeckung einer unbekannten Universalitätsklasse.**

Dieses Paket implementiert RAX-U1 aus dem
[Forschungsprogramm v0.1](../../docs/research/rax/README.md), Seiten 5–7.
`contract.json` fixiert genau eine Qualifikationskampagne; die JSON-Schema-Datei
und die Laufzeitprüfung lassen in dieser Version keine anderen Profile zu.
Eine Änderung von Modellraum, Seed, Stichprobenumfang oder Toleranzen benötigt
eine neu ausgewiesene Version. Die Qualifikation ist kein lernendes Experiment.

**Ausgeführt:** [Ergebnisse und Archivvorfall](RESULTS.md). Die exakten Prüfungen
und das vollständige Referenz-Replay bestehen; 8 statistische Konfigurationen
stützen die Reduktion, 16 verwerfen sie, 16 bleiben unentschieden. Die Rohdaten
wurden nach einer Kürzung bytegleich rekonstruiert. Die Speicherursache bleibt
offen; eine störungsfreie Erfassung ist damit nicht abgenommen.

## Modell und exakte Kontrollen

- Acht Mikrorealisationen: Familien A/B, jeweils m=4,8,16,32 und 2m Zustände.
- A verwendet gerichtete Zyklen mit Selbstschleifen und Permutationen zwischen
  Blöcken; B verwendet dichte positive ganzzahlige Gewichte mit Zeilennormierung.
  Drei bzw. 2m positive Einträge je Übergangszeile trennen die Supportgraphen.
- Vier Protokolle e0–e3 und fünf Störwerte ergeben **160 vollständige
  Übergangsmatrizen**, die exakt geprüft werden. Dies ist eine andere Zählung
  als die zufällig ebenfalls 160 statistischen Messzellen unten.
- Bei lambda=0 ist die vorgegebene Projektion auf zwei Blöcke stark lumpbar.
  Bei jedem registrierten lambda>0 ist sie nicht stark lumpbar. Die exakte
  Blockheterogenität beträgt 2 lambda, der maximale Ein-Schritt-Vorhersageverlust
  gegenüber der ungestörten Reduktion lambda.
- Eine vollständige Umbenennung transportiert Matrix, Blocklabels und
  Präparationsmuster gemeinsam. Die Befunde bleiben invariant.
- Eine konstante Reduktion hat bei e3/lambda=0 mindestens 0,05 maximalen Fehler
  und verletzt die Vorhersagetoleranz 0,025. Der Prädiktor erhält ausschliesslich
  den reduzierten Zustand und das Protokoll, keine Mikrozustands-/Präparations-ID.
- 32 exakt geprüfte verschobene Kontrollvarianten (acht Basismodelle, vier
  Protokolle) erhöhen die erste Wechselrate um 0,10. Sie bleiben jeweils lumpbar,
  gehören aber nicht zur unveränderten Referenzdynamik. Sie zählen nicht zur
  statistischen Testfamilie und nicht als 32 unabhängige UV-Ensembles.

`u1.py` konstruiert die Matrizen mit `fractions.Fraction`. `reference.py`
importiert diesen Code nicht: Es rekonstruiert die Generatoren separat und
verwendet gekürzte ganzzahlige Zähler-/Nennerpaare sowie paarweise Differenzen.
Alle Einträge der 160 rekonstruierten Matrizen werden über kanonische Digests
mit der ersten Implementierung verglichen; die exakten Eigenschaften und
Negativkontrollen werden zusätzlich neu berechnet. Die Prüfung erfolgt intern
im selben Projekt, ohne externe Begutachtung.

## Feste statistische Qualifikation

Nur **e3** wird statistisch ausgewertet. Die Kombination aus zwei Familien,
vier Grössen, fünf Störwerten, zwei Ausgangsblöcken und zwei Präparationshälften
ergibt **160 Zellen mit je 20'000 frischen Ein-Schritt-Simulationen**, insgesamt
3'200'000 Übergänge. Die acht Basismodelle bleiben über die Störwerte identisch.

Die Rohdaten enthalten pro Versuch den initialen und finalen Mikrozustand als
zwei uint8-Werte. Der Simulator wählt einen initialen Zustand gleichverteilt
aus der registrierten Hälfte und zieht dann aus der vollständigen rationalen
Übergangszeile. Ganzzahlige kategoriale Ziehungen vermeiden Rundung der
Übergangswahrscheinlichkeiten. Ein Seed wird durch SHA-256 aus 104729 und der
registrierten Modell-/Zellkennung abgeleitet. RNG und Laufzeit sind festgelegt.

Die Hoeffding-Vereinigungsabschätzung verwendet alpha=0,05 über alle 160
Wahrscheinlichkeiten und b=sqrt(log(2*160/0,05)/(2*20000)). Die statistische
Aussage setzt unabhängige Bernoulli-Replikate des registrierten Modells voraus;
hier werden sie durch getrennte pseudorandomisierte Simulatorziehungen
realisiert. Sie ist bedingt auf die acht eingefrorenen Mikrorealisationen.

Entschieden wird je Familie/Grösse/Störwert, also für **40 Konfigurationen**:

| Status | Regel |
| --- | --- |
| `APPROXIMATE_REDUCTION_SUPPORTED` | Alle oberen Verlustgrenzen liegen innerhalb delta_block=0,05 und delta_prediction=0,025. |
| `REDUCTION_REJECTED` | Mindestens eine untere Verlustgrenze liegt strikt oberhalb ihrer Toleranz. |
| `INCONCLUSIVE` | Gültige Daten erlauben keine dieser Entscheidungen. |
| `INVALID` | Vertrag, Rohdaten, Stichprobenumfang, Zuordnung oder Pflichtdateien sind verletzt. |

Ein positiver Störwert kann exakte Lumpbarkeit verletzen und dennoch eine
hinreichend kleine approximative Reduktion erlauben. Ein unentschiedenes
Ergebnis wird nicht durch neue Seeds oder zusätzliche Stichproben beseitigt.
Die Fehlergrenze gilt nicht für beliebig viele Kampagnen. Der offene
Entdeckungsschritt RAX-U2 ist nicht Teil dieses Pakets.

## Ausführen und reproduzieren

Referenzumgebung: Linux, **Python 3.12**, keine Drittanbieter-Pythonpakete.
Alle folgenden Befehle werden im Repository-Stamm ausgeführt.

```sh
python3 -m unittest discover -s research/rax_u1/tests -v

# Neuer Ordner; enthält den Vertrag, die Modelle und eingefrorene Quellkopien.
python3 research/rax_u1/u1.py prepare /tmp/rax-u1-reproduction

# AP1-Abnahme vor den statistischen Ziehungen; obligatorisch für run.
python3 research/rax_u1/reference.py /tmp/rax-u1-reproduction --exact-only --output /tmp/rax-u1-reproduction/reference-exact.json

# Genau ein Erfassungsversuch pro Ordner; Wiederanlauf wird gesperrt.
python3 research/rax_u1/u1.py run /tmp/rax-u1-reproduction

# Zweiter Rechenweg, vollständiges Rohdaten-Replay und Decimal-Statistik.
python3 research/rax_u1/reference.py /tmp/rax-u1-reproduction --output /tmp/rax-u1-reproduction/reference-full.json
```

Eine Reproduktion mit denselben Seeds ist eine Wiederholung derselben
synthetischen Daten, keine zusätzliche unabhängige Stichprobe. Der zweite
Sampler verwendet lineare Subtraktion ganzzahliger Gewichte statt kumulativer
binärer Suche. Er muss alle 6'400'000 Rohbytes identisch reproduzieren. Seine
Intervallrechnung nutzt 60-stellige Decimal-Arithmetik; der Vergleich mit der
Float-Auswertung erlaubt höchstens 5e-15 absolute Abweichung. Statuswerte und
Zählungen müssen exakt übereinstimmen.

`u1.py evaluate ORDNER` berechnet den Befund erneut aus den vollständigen
gespeicherten Rohdaten. Das ist eine erneute Berechnung desselben festen
Auswertungszeitpunkts. Die handkonstruierten Test-Fixtures der Unittests sind
bewusst keine Zufallsdaten; die vollständige Seed-Prüfung muss sie zurückweisen.

## Herkunft, Budgets und Grenzen

`freeze.json` bindet Vertrag, Modelle, exakten Bericht und die vier notwendigen
Quelldateien vor der Erfassung. `run_started.json` wird exklusiv angelegt und
bleibt bei Abbruch bestehen. Fehlende oder verkürzte Aufnahmen liefern INVALID.
Pro Erfassung gelten 120 Sekunden Laufzeit, 256 MiB maximaler virtueller
Adressraum, exakt 6,4 MB Rohdaten und maximal 16 MiB Kampagnenausgabe. Die
Vorbereitung und Gegenprüfung sind eigene Schritte; der CI-Job ist auf zehn
Minuten begrenzt. Die Laufzeit-/Speichermessungen sind technische Beobachtungen.

Die Sperre ist lokal und dateibasiert. Ein Benutzer mit Schreibrechten kann
Dateien kopieren, ändern oder löschen; dies ist kein manipulationssicheres
Evidenzregister. Hashes und Zeitstempel beweisen weder Urheberschaft noch
externe Präregistrierung. Die Evidenz ist ausdrücklich `SYNTHETIC_CONTROL`;
eine physikalische Behauptung wird niemals als bestätigt ausgegeben.

Methodische Grundlagen und Quellen: Forschungsprogramm v0.1, insbesondere
Tian/Kannan (2006), DOI 10.1080/07362990600632045, zum Lumpbarkeitskriterium,
und Hoeffding (1963), DOI 10.1080/01621459.1963.10500830, zur festen Schranke.
Die konkrete Konstruktion, Fehlergrenzen und Ressourcenbudgets sind
deklarierte Entwurfsentscheidungen dieses Kontrollversuchs.
