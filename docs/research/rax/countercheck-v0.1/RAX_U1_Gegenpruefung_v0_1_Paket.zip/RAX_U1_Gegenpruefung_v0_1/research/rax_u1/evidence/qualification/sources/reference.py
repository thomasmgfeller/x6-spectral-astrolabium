#!/usr/bin/env python3
"""Separate U1 oracle: integer-pair arithmetic, linear categorical replay, Decimal statistics.

Does not import u1.py, its generator, sampler, summaries, or decision functions.
This is internal algorithmic cross-checking, not external peer review.
"""
import argparse
from collections import Counter
from datetime import datetime
from decimal import Decimal, localcontext
import hashlib
import json
from math import gcd, isfinite, lcm
from pathlib import Path
import random
import sys
import time

SIZES = (4, 8, 16, 32)
LAMBDAS = ("0", "1/100", "1/40", "1/20", "1/10")
RATES = {"e0": ("1/5", "3/10"), "e1": ("7/20", "3/10"),
         "e2": ("1/5", "9/20"), "e3": ("7/20", "9/20")}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def encode(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

def sha(x):
    return hashlib.sha256(x).hexdigest()

def pairs(items):
    result = {}
    for k, v in items:
        require(k not in result, "duplicate JSON key")
        result[k] = v
    return result

def read(path):
    require(path.is_file() and not path.is_symlink(), "missing or symlinked input: " + str(path))
    require(path.stat().st_size <= 2097152, "JSON too large")
    return json.loads(path.read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError("nonfinite JSON")))

def ratio(n, d=1):
    require(d != 0, "zero denominator")
    if d < 0:
        n, d = -n, -d
    g = gcd(n, d)
    return (n//g, d//g)

def q(s):
    fields = str(s).split("/")
    return ratio(int(fields[0]), int(fields[1]) if len(fields) == 2 else 1)

def add(x, y):
    return ratio(x[0]*y[1] + y[0]*x[1], x[1]*y[1])

def subtract(x, y):
    return add(x, (-y[0], y[1]))

def total(values):
    result = (0, 1)
    for value in values:
        result = add(result, value)
    return result

def biggest(values):
    best = values[0]
    for value in values[1:]:
        if value[0]*best[1] > best[0]*value[1]:
            best = value
    return best

def textq(x):
    return str(x[0]) if x[1] == 1 else f"{x[0]}/{x[1]}"

def seed(namespace):
    return int(hashlib.sha256(("104729:" + namespace).encode()).hexdigest(), 16)

def regenerate_model(family, m):
    rng = random.Random(seed(f"model:{family}:m{m}"))
    kernels = {}
    for source in (0, 1):
        for target in (0, 1):
            block = [[0]*m for _ in range(m)]
            if family == "B":
                for i in range(m):
                    for j in range(m):
                        block[i][j] = rng.randint(1, 9)
            elif source == target:
                for i in range(m):
                    choice = rng.randrange(3)
                    block[i][i] = (1, 1, 2)[choice]
                    block[i][(i+1) % m] = (2, 1, 1)[choice]
            else:
                order = list(range(m)); rng.shuffle(order)
                for i, target_index in enumerate(order):
                    block[i][target_index] = 1
            kernels[str(source) + str(target)] = block
    signs = []
    for _ in (0, 1):
        block_signs = [(-1 if i < m//2 else 1) for i in range(m)]
        rng.shuffle(block_signs); signs += block_signs
    return {"id": f"{family}:m{m}", "family": family, "m": m, "weights": kernels, "h": signs}

def operator(model, rates, perturbation):
    m = model["m"]
    result = []
    for state in range(2*m):
        a, i = divmod(state, m)
        r = add(q(rates[a]), ratio(q(perturbation)[0] * model["h"][state], q(perturbation)[1]))
        require(0 < r[0] < r[1], "non-interior switch probability")
        row = []
        for dest_block in (0, 1):
            weights = model["weights"][f"{a}{dest_block}"][i]
            block_numerator = r[0] if dest_block != a else r[1] - r[0]
            common_denominator = r[1] * sum(weights)
            row.extend(ratio(block_numerator * w, common_denominator) for w in weights)
        require(total(row) == (1, 1) and all(x[0] >= 0 for x in row), "not stochastic")
        require(sum(x[0] > 0 for x in row) == (3 if model["family"] == "A" else 2*m), "support separation")
        result.append(row)
    return result

def properties(matrix, labels, signs, rates):
    switch = [total(value for j, value in enumerate(row) if labels[j] != labels[i])
              for i, row in enumerate(matrix)]
    ranges, errors, preparation = [], [], {}
    for a in (0, 1):
        vals = [switch[i] for i in range(len(labels)) if labels[i] == a]
        # Compare every pair exactly; the production code uses max minus min.
        ranges.append(biggest([ratio(abs(subtract(x, y)[0]), subtract(x, y)[1]) for x in vals for y in vals]))
        errors += [ratio(abs(subtract(x, q(rates[a]))[0]), subtract(x, q(rates[a]))[1]) for x in vals]
        for sign in (-1, 1):
            chosen = [switch[i] for i in range(len(labels)) if labels[i] == a and signs[i] == sign]
            s = total(chosen)
            preparation[f"a{a}:h{sign}"] = textq(ratio(s[0], s[1]*len(chosen)))
    delta = biggest(ranges)
    return {"lumpable": delta[0] == 0, "delta": textq(delta), "prediction_loss": textq(biggest(errors)),
            "preparations": preparation,
            "row_support": sorted(set(sum(x[0] > 0 for x in row) for row in matrix))}

def exact_check(models, actual):
    expected_cases, shifted = [], []
    for model in models:
        m = model["m"]; labels = [i//m for i in range(2*m)]
        for protocol, rates in RATES.items():
            for li, lam in enumerate(LAMBDAS):
                matrix = operator(model, rates, lam)
                result = properties(matrix, labels, model["h"], rates)
                require(q(result["delta"]) == ratio(2*q(lam)[0], q(lam)[1]), "delta oracle")
                require(q(result["prediction_loss"]) == q(lam), "loss oracle")
                require(result["lumpable"] == (li == 0), "lumpability oracle")
                permutation = list(reversed(range(2*m)))
                changed = properties([[matrix[i][j] for j in permutation] for i in permutation],
                                     [labels[i] for i in permutation], [model["h"][i] for i in permutation], rates)
                require(changed == result, "transported invariants")
                result.update({"model_id": model["id"], "protocol": protocol, "lambda_index": li, "lambda": lam,
                               "relabeling_pass": True,
                               "matrix_sha256": sha(encode([[textq(x) for x in row] for row in matrix]))})
                expected_cases.append(result)
            shifted_rates = (textq(add(q(rates[0]), (1, 10))), rates[1])
            result = properties(operator(model, shifted_rates, "0"), labels, model["h"], rates)
            require(result["lumpable"] and result["prediction_loss"] == "1/10", "shift negative control")
            shifted.append({"model_id": model["id"], "protocol": protocol, "prediction_loss": "1/10"})
    # Any constant Bernoulli prediction q has max(|q-.35|, |q-.45|) >= .05.
    r0, r1 = map(q, RATES["e3"])
    difference = subtract(r1, r0)
    minimax = ratio(difference[0], 2*difference[1])
    require(minimax == (1, 20), "constant minimax")
    expected = {"schema": "rax.u1.exact/1", "evidence_kind": "SYNTHETIC_CONTROL", "status": "PASS",
                "cases": expected_cases, "shifted_controls": shifted,
                "constant_control": {"protocol": "e3", "lambda": "0", "minimax_loss": "1/20", "outcome": "REDUCTION_REJECTED"}}
    require(actual == expected, "exact report differs from independently reconstructed matrices or controls")
    return {"matrices": len(expected_cases), "lumpable": sum(c["lumpable"] for c in expected_cases),
            "not_lumpable": sum(not c["lumpable"] for c in expected_cases), "shift_controls": len(shifted),
            "relabeling_checks": len(expected_cases), "constant_control": "REJECTED"}

def rows_for_replay(matrix):
    rows = []
    for row in matrix:
        denominator = lcm(*(x[1] for x in row))
        weights = [x[0]*(denominator//x[1]) for x in row]
        require(sum(weights) == denominator, "integer row total")
        rows.append((weights, denominator))
    return rows

def replay_cell(model, lam, cid, a, sign, raw):
    rows = rows_for_replay(operator(model, RATES["e3"], lam))
    m = model["m"]
    preparation = [i for i in range(2*m) if i//m == a and model["h"][i] == sign]
    rng = random.Random(seed("cell:" + cid))
    count = 0
    for offset in range(0, len(raw), 2):
        initial = preparation[rng.randrange(len(preparation))]
        weights, denominator = rows[initial]
        target = rng.randrange(denominator)
        # Linear subtraction instead of cumulative lookup/binary search.
        final = 0
        while target >= weights[final]:
            target -= weights[final]
            final += 1
        require(raw[offset] == initial and raw[offset+1] == final, "seeded raw replay differs: " + cid)
        count += (final//m != a)
    return count

def decimal_assessment(records):
    with localcontext() as ctx:
        ctx.prec = 60
        D = Decimal
        b = (D(6400).ln()/D(40000)).sqrt()
        configs = []
        for start in range(0, 160, 4):
            cells = records[start:start+4]
            ps = [D(x["switches"])/D(20000) for x in cells]
            intervals = [[max(D(0), p-b), min(D(1), p+b)] for p in ps]
            blocks = []
            for j in (0, 2):
                separation = abs(ps[j]-ps[j+1])
                blocks.append([max(D(0), separation-2*b), min(D(1), separation+2*b)])
            predictions = []
            for cell, p in zip(cells, ps):
                loss = abs(p - (D("0.35") if cell["a"] == 0 else D("0.45")))
                predictions.append([max(D(0), loss-b), min(D(1), loss+b)])
            supported = all(x[1] <= D("0.05") for x in blocks) and all(x[1] <= D("0.025") for x in predictions)
            rejected = any(x[0] > D("0.05") for x in blocks) or any(x[0] > D("0.025") for x in predictions)
            decision = "APPROXIMATE_REDUCTION_SUPPORTED" if supported else "REDUCTION_REJECTED" if rejected else "INCONCLUSIVE"
            configs.append({"model_id": cells[0]["model_id"], "lambda": cells[0]["lambda"], "lambda_index": cells[0]["lambda_index"],
                            "status": decision, "cell_ids": [x["cell_id"] for x in cells], "p_hat": [float(p) for p in ps],
                            "probability_intervals": [[float(x) for x in v] for v in intervals],
                            "block_bounds": [[float(x) for x in v] for v in blocks],
                            "prediction_bounds": [[float(x) for x in v] for v in predictions]})
        return {"schema": "rax.u1.assessment/1", "validity": "VALID", "evidence_kind": "SYNTHETIC_CONTROL",
                "physical_claim_supported": False, "n_per_cell": 20000, "number_of_cells": 160,
                "b": float(b), "alpha": "1/20", "configs": configs,
                "counts": dict(sorted(Counter(x["status"] for x in configs).items()))}

def compare(actual, expected):
    if type(expected) is float:
        require(type(actual) in (int, float) and isfinite(actual) and abs(actual - expected) <= 5e-15, "numerical interval mismatch")
    elif isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), "report keys")
        for k in expected:
            compare(actual[k], expected[k])
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), "report length")
        for a, e in zip(actual, expected):
            compare(a, e)
    else:
        require(type(actual) is type(expected) and actual == expected, "report field mismatch")

def verify(folder, exact_only=False):
    began = time.monotonic()
    require(sys.version_info[:2] == (3, 12), "reference replay requires Python 3.12")
    folder = Path(folder)
    freeze, contract, models = (read(folder/name) for name in ("freeze.json", "contract.json", "models.json"))
    source_names = {"u1.py", "reference.py", "contract.json", "contract.schema.json"}
    require(set(freeze["sources"]) == source_names, "frozen source inventory")
    for name, expected in freeze["sources"].items():
        p = folder/"sources"/name
        require(p.is_file() and not p.is_symlink() and sha(p.read_bytes()) == expected, "frozen source hash")
    require(sha(Path(__file__).read_bytes()) == freeze["sources"]["reference.py"], "reference source version differs")
    require(contract == read(folder/"sources"/"contract.json"), "contract source mismatch")
    schema = read(folder/"sources"/"contract.schema.json")
    require(contract == schema["const"], "fixed schema mismatch")
    require(contract["seed"] == 104729 and contract["families"] == ["A", "B"] and contract["sizes"] == list(SIZES), "reference profile")
    require(contract["protocols"] == {k:list(v) for k,v in RATES.items()} and contract["lambdas"] == list(LAMBDAS), "reference rates")
    require((contract["n_per_cell"], contract["number_of_cells"], contract["alpha"], contract["delta_block"],
             contract["delta_prediction"], contract["statistical_protocol"], contract["evaluations"]) ==
            (20000, 160, "1/20", "1/20", "1/40", "e3", 1), "reference statistical contract")
    for name in ("contract", "models", "exact"):
        require(sha((folder/(name+".json")).read_bytes()) == freeze[name+"_sha256"], name + " binding")
    expected_models = [regenerate_model(f, m) for f in ("A", "B") for m in SIZES]
    require(encode(models) == encode(expected_models), "model regeneration mismatch")
    checked = exact_check(models, read(folder/"exact.json"))
    report = {"schema": "rax.u1.reference/1", "status": "PASS", "external_review": False,
              "freeze_sha256": sha((folder/"freeze.json").read_bytes()),
              "reference_source_sha256": sha(Path(__file__).read_bytes()),
              "evidence_kind": "SYNTHETIC_CONTROL", "exact": checked, "raw_replay": "NOT_REQUESTED"}
    if not exact_only:
        acquisition = read(folder/"acquisition.json")
        start = read(folder/"run_started.json")
        freeze_sha = sha((folder/"freeze.json").read_bytes())
        require(acquisition["schema"] == "rax.u1.acquisition/1" and acquisition["status"] == "COMPLETE", "acquisition status")
        require(acquisition["evidence_kind"] == "SYNTHETIC_CONTROL", "acquisition evidence class")
        require(acquisition["freeze_sha256"] == start["freeze_sha256"] == freeze_sha, "freeze identity")
        preflight = read(folder/"reference-exact.json")
        require(preflight["status"] == "PASS" and preflight["freeze_sha256"] == freeze_sha and
                preflight["reference_source_sha256"] == freeze["sources"]["reference.py"] and
                preflight["raw_replay"] == "NOT_REQUESTED", "preflight gate")
        require(start["preflight_reference_sha256"] == sha((folder/"reference-exact.json").read_bytes()), "preflight binding")
        require(acquisition["campaign_id"] == start["campaign_id"] == contract["campaign_id"], "campaign identity")
        require(datetime.fromisoformat(freeze["created_utc"]) <= datetime.fromisoformat(start["started_utc"]) <=
                datetime.fromisoformat(acquisition["completed_utc"]), "event ordering")
        path = folder/"trials.bin"
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == 6400000, "raw file")
        raw = path.read_bytes()
        require(acquisition["raw_sha256"] == sha(raw) and acquisition["raw_bytes"] == len(raw), "raw hash")
        actual_records = acquisition["records"]
        require(len(actual_records) == 160, "cell count")
        records, index = [], 0
        for model in models:
            for li, lam in enumerate(LAMBDAS):
                for a in (0, 1):
                    for sign in (-1, 1):
                        cid = f'{model["id"]}:l{li}:a{a}:h{sign}'
                        count = replay_cell(model, lam, cid, a, sign, raw[index*40000:(index+1)*40000])
                        record = {"cell_id": cid, "model_id": model["id"], "family": model["family"], "m": model["m"],
                                  "lambda_index": li, "lambda": lam, "a": a, "h": sign,
                                  "offset": index*40000, "n": 20000, "switches": count}
                        require(encode(actual_records[index]) == encode(record), "cell metadata/count mismatch")
                        records.append(record); index += 1
        expected = decimal_assessment(records)
        expected.update({"freeze_sha256": freeze_sha, "raw_sha256": sha(raw)})
        compare(read(folder/"assessment.json"), expected)
        report.update({"raw_replay": "BYTE_IDENTICAL", "raw_sha256": sha(raw), "trials": 3200000,
                       "statistical_cells": 160, "configurations": 40, "counts": expected["counts"],
                       "max_numeric_comparison_tolerance": 5e-15})
    report["elapsed_seconds"] = time.monotonic() - began
    return report

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("folder", type=Path)
    p.add_argument("--exact-only", action="store_true")
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    try:
        report = verify(args.folder, args.exact_only)
        if args.output:
            with args.output.open("xb") as f:
                f.write(encode(report) + b"\n")
        print(json.dumps(report, indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError, IndexError, OverflowError) as exc:
        print(json.dumps({"status": "FAIL", "reason": str(exc)}))
        return 1

if __name__ == "__main__":
    sys.exit(main())
