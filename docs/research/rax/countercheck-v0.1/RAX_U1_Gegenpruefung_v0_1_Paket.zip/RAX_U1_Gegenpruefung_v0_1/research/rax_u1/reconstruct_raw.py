#!/usr/bin/env python3
"""Reconstruct existing synthetic bytes; never acquire new evidence or overwrite files.

Added after the first archive integrity incident. Uses the frozen reference
operator and frozen seeds, and refuses output with a different acquisition hash.
The frozen reference checker remains the authority for the resulting archive.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random

import reference as ref


def reconstruct(folder, output):
    folder, output = Path(folder), Path(output)
    ref.verify(folder, exact_only=True)
    acquisition = ref.read(folder / "acquisition.json")
    models = ref.read(folder / "models.json")
    ref.require(len(acquisition["records"]) == 160, "acquisition inventory")
    raw = bytearray()
    index = 0
    for model in models:
        m = model["m"]
        for li, lam in enumerate(ref.LAMBDAS):
            rows = ref.rows_for_replay(ref.operator(model, ref.RATES["e3"], lam))
            for a in (0, 1):
                for sign in (-1, 1):
                    cid = f'{model["id"]}:l{li}:a{a}:h{sign}'
                    rng = random.Random(ref.seed("cell:" + cid))
                    preparation = [i for i in range(2*m) if i//m == a and model["h"][i] == sign]
                    count = 0
                    for _ in range(20000):
                        initial = preparation[rng.randrange(len(preparation))]
                        weights, denominator = rows[initial]
                        ticket = rng.randrange(denominator)
                        final = 0
                        while ticket >= weights[final]:
                            ticket -= weights[final]
                            final += 1
                        raw.extend((initial, final))
                        count += final//m != a
                    record = {"cell_id": cid, "model_id": model["id"], "family": model["family"], "m": m,
                              "lambda_index": li, "lambda": lam, "a": a, "h": sign,
                              "offset": index*40000, "n": 20000, "switches": count}
                    ref.require(ref.encode(record) == ref.encode(acquisition["records"][index]), "acquisition count/metadata differs")
                    index += 1
    digest = hashlib.sha256(raw).hexdigest()
    ref.require(len(raw) == acquisition["raw_bytes"] == 6400000, "reconstruction size")
    ref.require(digest == acquisition["raw_sha256"], "reconstruction differs from original acquisition hash")
    with output.open("xb") as f:
        ref.require(f.write(raw) == len(raw), "short write")
        f.flush()
        os.fsync(f.fileno())
    ref.require(output.stat().st_size == len(raw) and ref.sha(output.read_bytes()) == digest, "stored reconstruction differs")
    return {"status": "RECONSTRUCTED", "raw_bytes": len(raw), "sha256": digest,
            "all_160_counts_match": True, "new_statistical_evidence": False}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("folder", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    try:
        print(json.dumps(reconstruct(args.folder, args.output), indent=2))
    except (ValueError, OSError, KeyError, TypeError, IndexError) as exc:
        print(json.dumps({"status": "FAIL", "reason": str(exc)}))
        raise SystemExit(1)
