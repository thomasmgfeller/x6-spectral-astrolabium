#!/usr/bin/env python3
"""RAX-U1 fixed synthetic qualification; Python 3.12 standard library only."""
import argparse
import bisect
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import resource
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PROFILE = {
    "schema": "rax.u1.contract/1", "campaign_id": "RAX-U1-QUAL-0001",
    "evidence_kind": "SYNTHETIC_CONTROL", "seed": 104729,
    "families": ["A", "B"], "sizes": [4, 8, 16, 32],
    "protocols": {"e0": ["1/5", "3/10"], "e1": ["7/20", "3/10"],
                  "e2": ["1/5", "9/20"], "e3": ["7/20", "9/20"]},
    "lambdas": ["0", "1/100", "1/40", "1/20", "1/10"],
    "statistical_protocol": "e3", "n_per_cell": 20000, "number_of_cells": 160,
    "alpha": "1/20", "delta_block": "1/20", "delta_prediction": "1/40",
    "preparation_signs": [-1, 1], "evaluations": 1,
    "rng": "Python-3.12-random.Random-MT19937-randrange",
    "raw_format": "uint8 initial_state, uint8 final_state; cell-major; no header",
    "limits": {"runtime_seconds": 120, "address_space_mib": 256,
               "raw_bytes": 6400000, "total_output_bytes": 16777216},
    "programme_sha256": "1f76e77a5783802daee5034ee227d760270b0dd092bec070f26c9fbd4988ab28"
}
SOURCE_NAMES = ["u1.py", "reference.py", "contract.json", "contract.schema.json"]

class Invalid(ValueError):
    pass

def need(condition, message):
    if not condition:
        raise Invalid(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def object_pairs(pairs):
    d = {}
    for k, v in pairs:
        need(k not in d, "duplicate JSON key: " + k)
        d[k] = v
    return d

def read_json(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "missing or symlinked file: " + str(path))
    need(path.stat().st_size <= 2097152, "JSON size limit")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=object_pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(Invalid("non-finite JSON")))

def write_json(path, data):
    with Path(path).open("xb") as f:
        f.write(canonical(data) + b"\n")

def utc():
    return datetime.now(timezone.utc).isoformat()

def validate_contract(c):
    need(canonical(c) == canonical(PROFILE), "contract differs from fixed U1 profile")
    need(sys.version_info[:2] == (3, 12), "qualified runner requires Python 3.12")
    return c

def seed_for(root_seed, namespace):
    return int.from_bytes(hashlib.sha256(f"{root_seed}:{namespace}".encode()).digest(), "big")

def model_id(family, m):
    return f"{family}:m{m}"

def make_model(family, m, seed):
    need(family in ("A", "B") and m in PROFILE["sizes"], "unsupported model")
    rng = random.Random(seed_for(seed, "model:" + model_id(family, m)))
    weights = {}
    for a in range(2):
        for b in range(2):
            if family == "B":
                rows = [[rng.randrange(1, 10) for _ in range(m)] for _ in range(m)]
            elif a == b:
                rows = []
                for i in range(m):
                    left, right = rng.choice([(1, 2), (1, 1), (2, 1)])
                    row = [0] * m
                    row[i], row[(i + 1) % m] = left, right
                    rows.append(row)
            else:
                permutation = list(range(m))
                rng.shuffle(permutation)
                rows = [[int(j == permutation[i]) for j in range(m)] for i in range(m)]
            weights[f"{a}{b}"] = rows
    h = []
    for _ in range(2):
        half = [-1] * (m // 2) + [1] * (m // 2)
        rng.shuffle(half)
        h.extend(half)
    return {"id": model_id(family, m), "family": family, "m": m, "weights": weights, "h": h}

def validate_model(model):
    need(set(model) == {"id", "family", "m", "weights", "h"}, "model fields")
    family, m = model["family"], model["m"]
    need(family in ("A", "B") and type(m) is int and m in PROFILE["sizes"], "model domain")
    need(model["id"] == model_id(family, m), "model identity")
    h = model["h"]
    need(len(h) == 2 * m and all(type(x) is int and x in (-1, 1) for x in h), "h values")
    need(sum(h[:m]) == sum(h[m:]) == 0, "h must balance in each block")
    need(set(model["weights"]) == {"00", "01", "10", "11"}, "K blocks")
    for key, rows in model["weights"].items():
        need(len(rows) == m and all(len(row) == m for row in rows), "K shape")
        need(all(type(w) is int and 0 <= w <= 9 for row in rows for w in row), "K weights")
        if family == "B":
            need(all(w > 0 for row in rows for w in row), "B support")
        elif key[0] == key[1]:
            for i, row in enumerate(rows):
                need((row[i], row[(i + 1) % m]) in ((1, 2), (1, 1), (2, 1)), "A cycle weights")
                need(sum(w > 0 for w in row) == 2, "A cycle support")
        else:
            need(all(sum(row) == 1 for row in rows) and
                 all(sum(row[j] for row in rows) == 1 for j in range(m)), "A permutation")
    return model

def transition(model, rates, lam):
    validate_model(model)
    m = model["m"]
    matrix = []
    for a in range(2):
        for i in range(m):
            r = F(rates[a]) + F(lam) * model["h"][a * m + i]
            need(0 < r < 1, "invalid block switch probability")
            row = []
            for b in range(2):
                weights = model["weights"][f"{a}{b}"][i]
                mass = 1 - r if a == b else r
                row.extend(mass * F(w, sum(weights)) for w in weights)
            need(sum(row) == 1 and all(x >= 0 for x in row), "invalid transition row")
            matrix.append(row)
    return matrix

def predict(reduced_state, protocol):
    """No access to microstate, h, preparation ID or perturbation lambda."""
    rates = list(map(F, PROFILE["protocols"][protocol]))
    if reduced_state is None:
        return sum(rates) / 2
    need(type(reduced_state) is int and reduced_state in (0, 1), "reduced state")
    return rates[reduced_state]

def summarize(matrix, labels, h, rates):
    need(len(matrix) == len(labels) == len(h), "operator shape")
    switches = [sum(row[j] for j in range(len(labels)) if labels[j] != labels[i])
                for i, row in enumerate(matrix)]
    differences, errors, preparations = [], [], {}
    for a in range(2):
        values = [switches[i] for i in range(len(labels)) if labels[i] == a]
        differences.append(max(values) - min(values))
        errors.extend(abs(x - F(rates[a])) for x in values)
        for sign in (-1, 1):
            selected = [switches[i] for i in range(len(labels)) if labels[i] == a and h[i] == sign]
            preparations[f"a{a}:h{sign}"] = str(sum(selected) / len(selected))
    return {"lumpable": max(differences) == 0, "delta": str(max(differences)),
            "prediction_loss": str(max(errors)), "preparations": preparations,
            "row_support": sorted(set(sum(x > 0 for x in row) for row in matrix))}

def exact_report(models, contract):
    cases = []
    for model in models:
        m = model["m"]
        labels = [0] * m + [1] * m
        for e, rates in contract["protocols"].items():
            for li, lam in enumerate(contract["lambdas"]):
                matrix = transition(model, rates, lam)
                result = summarize(matrix, labels, model["h"], rates)
                need(F(result["delta"]) == 2 * F(lam), "exact delta identity failed")
                need(F(result["prediction_loss"]) == F(lam), "prediction identity failed")
                need(result["lumpable"] == (F(lam) == 0), "lumpability identity failed")
                permutation = list(reversed(range(2 * m)))
                transported = [[matrix[i][j] for j in permutation] for i in permutation]
                again = summarize(transported, [labels[i] for i in permutation],
                                  [model["h"][i] for i in permutation], rates)
                need(again == result, "relabeling failed")
                result.update({"model_id": model["id"], "protocol": e, "lambda_index": li,
                               "lambda": lam, "relabeling_pass": True,
                               "matrix_sha256": digest(canonical([[str(x) for x in row] for row in matrix]))})
                cases.append(result)
    shifted = []
    for model in models:
        m = model["m"]
        for e, rates in contract["protocols"].items():
            changed = [str(F(rates[0]) + F(1, 10)), rates[1]]
            result = summarize(transition(model, changed, "0"), [0] * m + [1] * m, model["h"], rates)
            need(result["lumpable"] and F(result["prediction_loss"]) == F(1, 10), "shift control")
            shifted.append({"model_id": model["id"], "protocol": e, "prediction_loss": "1/10"})
    constant_error = max(abs(predict(None, "e3") - predict(a, "e3")) for a in (0, 1))
    need(constant_error == F(1, 20) and constant_error > F(contract["delta_prediction"]), "constant control")
    return {"schema": "rax.u1.exact/1", "evidence_kind": "SYNTHETIC_CONTROL", "status": "PASS",
            "cases": cases, "shifted_controls": shifted,
            "constant_control": {"protocol": "e3", "lambda": "0", "minimax_loss": str(constant_error),
                                 "outcome": "REDUCTION_REJECTED"}}

def cell_specs(contract):
    for family in contract["families"]:
        for m in contract["sizes"]:
            for li, lam in enumerate(contract["lambdas"]):
                for a in range(2):
                    for sign in contract["preparation_signs"]:
                        cid = f"{family}:m{m}:l{li}:a{a}:h{sign}"
                        yield {"cell_id": cid, "model_id": model_id(family, m), "family": family,
                               "m": m, "lambda_index": li, "lambda": lam, "a": a, "h": sign}

def integer_rows(matrix):
    result = []
    for row in matrix:
        common = math.lcm(*(x.denominator for x in row))
        weights = [x.numerator * (common // x.denominator) for x in row]
        cumul, total = [], 0
        for weight in weights:
            total += weight
            cumul.append(total)
        result.append((cumul, total))
    return result

def sample_cell(model, spec, n, root_seed):
    rows = integer_rows(transition(model, PROFILE["protocols"]["e3"], spec["lambda"]))
    m, a, sign = spec["m"], spec["a"], spec["h"]
    selected = [i for i in range(a * m, (a + 1) * m) if model["h"][i] == sign]
    rng = random.Random(seed_for(root_seed, "cell:" + spec["cell_id"]))
    raw = bytearray(2 * n)
    switches = 0
    for k in range(n):
        initial = selected[rng.randrange(len(selected))]
        cumulative, total = rows[initial]
        final = bisect.bisect_right(cumulative, rng.randrange(total))
        raw[2*k], raw[2*k+1] = initial, final
        switches += (final // m != a)
    return bytes(raw), switches

def bounds_difference(left, right, error):
    return [max(0.0, abs(left - right) - error), min(1.0, abs(left - right) + error)]

def assess_counts(records, contract):
    specs = list(cell_specs(contract))
    need(len(records) == len(specs) == 160, "incomplete statistical family")
    for record, spec in zip(records, specs):
        need(all(type(record.get(k)) is type(v) and record[k] == v for k, v in spec.items()), "statistical cell identity")
        need(type(record.get("n")) is int and record["n"] == contract["n_per_cell"], "statistical sample count")
        need(type(record.get("switches")) is int and 0 <= record["switches"] <= record["n"], "statistical count domain")
    n, k = contract["n_per_cell"], contract["number_of_cells"]
    b = math.sqrt(math.log(2 * k / float(F(contract["alpha"]))) / (2*n))
    configs = []
    for offset in range(0, len(records), 4):
        cells = records[offset:offset+4]
        probabilities = [c["switches"] / n for c in cells]
        intervals = [[max(0.0, p - b), min(1.0, p + b)] for p in probabilities]
        block = [bounds_difference(probabilities[2*a], probabilities[2*a+1], 2*b) for a in range(2)]
        prediction = [bounds_difference(p, float(predict(c["a"], "e3")), b)
                      for p, c in zip(probabilities, cells)]
        limits = [(x, float(F(contract["delta_block"]))) for x in block]
        limits += [(x, float(F(contract["delta_prediction"]))) for x in prediction]
        if all(x[1] <= limit for x, limit in limits):
            decision = "APPROXIMATE_REDUCTION_SUPPORTED"
        elif any(x[0] > limit for x, limit in limits):
            decision = "REDUCTION_REJECTED"
        else:
            decision = "INCONCLUSIVE"
        configs.append({"model_id": cells[0]["model_id"], "lambda": cells[0]["lambda"],
                        "lambda_index": cells[0]["lambda_index"], "status": decision,
                        "cell_ids": [c["cell_id"] for c in cells], "p_hat": probabilities,
                        "probability_intervals": intervals, "block_bounds": block,
                        "prediction_bounds": prediction})
    return {"schema": "rax.u1.assessment/1", "validity": "VALID", "evidence_kind": "SYNTHETIC_CONTROL",
            "physical_claim_supported": False, "n_per_cell": n, "number_of_cells": k,
            "b": b, "alpha": contract["alpha"], "configs": configs,
            "counts": dict(sorted(Counter(x["status"] for x in configs).items()))}

def load_frozen(folder, check_current=False):
    folder = Path(folder)
    freeze = read_json(folder / "freeze.json")
    need(freeze["schema"] == "rax.u1.freeze/1" and freeze["status"] == "PREPARED", "freeze format")
    c = validate_contract(read_json(folder / "contract.json"))
    need(freeze["campaign_id"] == c["campaign_id"], "frozen campaign identity")
    need(freeze["contract_sha256"] == digest((folder / "contract.json").read_bytes()), "contract binding")
    need(freeze["models_sha256"] == digest((folder / "models.json").read_bytes()), "models binding")
    need(freeze["exact_sha256"] == digest((folder / "exact.json").read_bytes()), "exact report binding")
    need(set(freeze["sources"]) == set(SOURCE_NAMES), "source inventory")
    for name, sha in freeze["sources"].items():
        p = folder / "sources" / name
        need(p.is_file() and not p.is_symlink() and digest(p.read_bytes()) == sha, "frozen source binding")
        if check_current:
            need(digest((HERE / name).read_bytes()) == sha, "source changed after freeze")
    models = read_json(folder / "models.json")
    expected = [model_id(f, m) for f in c["families"] for m in c["sizes"]]
    need(isinstance(models, list) and [x["id"] for x in models] == expected, "model inventory")
    for model in models:
        validate_model(model)
    return freeze, c, models

def prepare(contract_path, output):
    contract = validate_contract(read_json(contract_path))
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "sources").mkdir()
    write_json(output / "contract.json", contract)
    models = [make_model(f, m, contract["seed"]) for f in contract["families"] for m in contract["sizes"]]
    write_json(output / "models.json", models)
    sources = {}
    for name in SOURCE_NAMES:
        content = (HERE / name).read_bytes()
        (output / "sources" / name).write_bytes(content)
        sources[name] = digest(content)
    exact = exact_report(models, contract)
    write_json(output / "exact.json", exact)
    try:
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=HERE, text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        commit = None
    freeze = {"schema": "rax.u1.freeze/1", "campaign_id": contract["campaign_id"], "created_utc": utc(),
              "contract_sha256": digest((output / "contract.json").read_bytes()),
              "models_sha256": digest((output / "models.json").read_bytes()),
              "exact_sha256": digest((output / "exact.json").read_bytes()),
              "sources": sources, "source_commit": commit,
              "environment": {"python": platform.python_version(), "platform": platform.platform()},
              "status": "PREPARED", "external_preregistration": False}
    write_json(output / "freeze.json", freeze)
    return {"status": "PREPARED", "exact_cases": len(exact["cases"]), "output": str(output)}

def acquire(folder):
    folder = Path(folder)
    freeze, c, models = load_frozen(folder, check_current=True)
    need(digest((folder / "exact.json").read_bytes()) == freeze["exact_sha256"], "exact report binding")
    need(not any((folder / name).exists() for name in ["run_started.json", "acquisition.json", "trials.bin", "assessment.json"]),
         "campaign already attempted; no second acquisition")
    preflight = read_json(folder / "reference-exact.json")
    need(preflight["status"] == "PASS" and preflight["raw_replay"] == "NOT_REQUESTED" and
         preflight["freeze_sha256"] == digest((folder / "freeze.json").read_bytes()) and
         preflight["reference_source_sha256"] == freeze["sources"]["reference.py"] and
         preflight["exact"]["matrices"] == 160 and preflight["exact"]["lumpable"] == 32 and
         preflight["exact"]["not_lumpable"] == 128, "independent exact preflight gate")
    need(sys.platform.startswith("linux"), "bounded acquisition requires Linux")
    limit = c["limits"]["address_space_mib"] * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    started = time.monotonic()
    write_json(folder / "run_started.json", {"started_utc": utc(), "campaign_id": c["campaign_id"],
                                           "preflight_reference_sha256": digest((folder / "reference-exact.json").read_bytes()),
                                           "freeze_sha256": digest((folder / "freeze.json").read_bytes())})
    by_id = {x["id"]: x for x in models}
    records, checksum, size = [], hashlib.sha256(), 0
    with (folder / "trials.bin").open("xb") as f:
        for spec in cell_specs(c):
            need(time.monotonic() - started <= c["limits"]["runtime_seconds"], "runtime budget exceeded; incomplete campaign")
            raw, count = sample_cell(by_id[spec["model_id"]], spec, c["n_per_cell"], c["seed"])
            f.write(raw); checksum.update(raw)
            records.append({**spec, "offset": size, "n": c["n_per_cell"], "switches": count})
            size += len(raw)
    elapsed = time.monotonic() - started
    need(size == c["limits"]["raw_bytes"] and elapsed <= c["limits"]["runtime_seconds"], "acquisition budget")
    acquisition = {"schema": "rax.u1.acquisition/1", "status": "COMPLETE", "evidence_kind": "SYNTHETIC_CONTROL",
                   "campaign_id": c["campaign_id"], "freeze_sha256": digest((folder / "freeze.json").read_bytes()),
                   "raw_sha256": checksum.hexdigest(), "raw_bytes": size, "records": records,
                   "completed_utc": utc(), "elapsed_seconds": elapsed,
                   "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    write_json(folder / "acquisition.json", acquisition)
    need(sum(x.stat().st_size for x in folder.rglob("*") if x.is_file()) <= c["limits"]["total_output_bytes"], "output budget")
    assessment = evaluate(folder)
    need(assessment["validity"] == "VALID", "acquisition failed validity gate")
    write_json(folder / "assessment.json", assessment)
    return {"status": "COMPLETE", "raw_sha256": checksum.hexdigest(), "trials": size//2,
            "elapsed_seconds": elapsed, "counts": assessment["counts"]}

def evaluate(folder):
    try:
        folder = Path(folder)
        freeze, c, models = load_frozen(folder)
        acquisition = read_json(folder / "acquisition.json")
        start = read_json(folder / "run_started.json")
        fh = digest((folder / "freeze.json").read_bytes())
        need(acquisition["schema"] == "rax.u1.acquisition/1" and acquisition["status"] == "COMPLETE", "incomplete acquisition")
        need(acquisition["evidence_kind"] == "SYNTHETIC_CONTROL", "evidence kind")
        need(acquisition["campaign_id"] == start["campaign_id"] == c["campaign_id"], "campaign binding")
        need(acquisition["freeze_sha256"] == start["freeze_sha256"] == fh, "freeze binding")
        need(start["preflight_reference_sha256"] == digest((folder / "reference-exact.json").read_bytes()), "preflight binding")
        need(datetime.fromisoformat(freeze["created_utc"]) <= datetime.fromisoformat(start["started_utc"]) <=
             datetime.fromisoformat(acquisition["completed_utc"]), "event ordering")
        need(type(acquisition["elapsed_seconds"]) in (int, float) and
             0 <= acquisition["elapsed_seconds"] <= c["limits"]["runtime_seconds"], "runtime budget record")
        need(type(acquisition["peak_rss_kib"]) is int and
             0 <= acquisition["peak_rss_kib"] <= 1024*c["limits"]["address_space_mib"], "memory budget record")
        path = folder / "trials.bin"
        need(path.is_file() and not path.is_symlink() and path.stat().st_size == c["limits"]["raw_bytes"], "raw size or path")
        raw = path.read_bytes()
        need(acquisition["raw_bytes"] == len(raw) and acquisition["raw_sha256"] == digest(raw), "raw binding")
        records = acquisition["records"]
        specs = list(cell_specs(c))
        need(len(records) == len(specs) == c["number_of_cells"], "cell inventory")
        by_id = {x["id"]: x for x in models}
        for index, (record, spec) in enumerate(zip(records, specs)):
            need(set(record) == set(spec) | {"offset", "n", "switches"}, "record fields")
            need(all(type(record[k]) is type(v) and record[k] == v for k, v in spec.items()), "cell identity or ordering")
            need(type(record["n"]) is int and record["n"] == c["n_per_cell"], "sample count")
            need(type(record["offset"]) is int and record["offset"] == 2 * index * c["n_per_cell"], "raw offset")
            need(type(record["switches"]) is int and 0 <= record["switches"] <= record["n"], "count domain")
            model = by_id[spec["model_id"]]
            m, a, sign = spec["m"], spec["a"], spec["h"]
            support = [[x > 0 for x in row] for row in transition(model, c["protocols"]["e3"], spec["lambda"])]
            count = 0
            for pos in range(record["offset"], record["offset"] + 2 * record["n"], 2):
                initial, final = raw[pos], raw[pos+1]
                need(initial < 2*m and final < 2*m, "state index")
                need(initial // m == a and model["h"][initial] == sign, "wrong preparation")
                need(support[initial][final], "transition outside support")
                count += (final // m != a)
            need(count == record["switches"], "count does not match raw transitions")
        result = assess_counts(records, c)
        result.update({"freeze_sha256": fh, "raw_sha256": acquisition["raw_sha256"]})
        return result
    except (Invalid, OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        return {"schema": "rax.u1.assessment/1", "validity": "INVALID", "reason": str(exc),
                "physical_claim_supported": False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare")
    prep.add_argument("output", type=Path)
    prep.add_argument("--contract", type=Path, default=HERE / "contract.json")
    for command in ("run", "evaluate"):
        commands.add_parser(command).add_argument("folder", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            result = prepare(args.contract, args.output)
        elif args.command == "run":
            result = acquire(args.folder)
        else:
            result = evaluate(args.folder)
        print(json.dumps(result, indent=2, allow_nan=False))
        return 2 if result.get("validity") == "INVALID" else 0
    except (Invalid, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "INVALID", "reason": str(exc)}))
        return 2

if __name__ == "__main__":
    sys.exit(main())
