# RAX-U1 — Ergebnis der ersten Qualifikation

**Ausgeführt am 14. Oktober 2026. Evidenzklasse: `SYNTHETIC_CONTROL`.**

Die bekannte Markov-Reduktion, ihre kontrollierte Verletzung und die festgelegte
statistische Auswertung sind implementiert und ausgeführt. Der separate Prüfer
bestätigt sämtliche Matrizen und alle 3'200'000 simulierten Übergänge.
**Das Rohdatenarchiv musste jedoch nach einer Kürzung bytegleich rekonstruiert
werden. Die Ursache ist offen; eine störungsfreie Speicherung ist nicht belegt.**

| Teilprüfung | Befund |
| --- | --- |
| AP1: exakte Modelle und Gegenkontrollen | `PASS`; zwei getrennte Rechenwege |
| AP2: Auswertung des wiederhergestellten Archivs | `VALID`; 40 Entscheidungen unter unveränderten Regeln |
| Vollständiges Referenz-Replay | `PASS`, `BYTE_IDENTICAL`; alle 6'400'000 Bytes und 160 Zählwerte stimmen überein |
| Archivintegrität beim ersten Nachprüfen | `INVALID`; 720'000 Bytes fehlten |
| Archiv nach dokumentierter Rekonstruktion | Ursprünglicher SHA-256 vollständig wiederhergestellt |
| Ursache und Dauerhaftigkeit der Speicherung | **Offen**; keine uneingeschränkte Abnahme der Erfassung |
| Physische Messung / externe Begutachtung | Nicht erfolgt |

## Exakte Kontrollen

Acht eingefrorene Mikrorealisationen aus zwei Familien, vier Protokolle und
fünf Störwerte ergeben 160 vollständige Übergangsmatrizen:

- **32 stark lumpbar:** alle Fälle mit lambda=0.
- **128 nicht stark lumpbar:** alle registrierten positiven Störwerte.
- Überall stimmen Blockheterogenität **2 lambda** und maximaler
  Vorhersageverlust **lambda** exakt mit der Konstruktion überein.
- **160 Umbenennungskontrollen** erhalten die Ergebnisse, wenn Matrix,
  Blocklabels und Präparationsmuster gemeinsam transportiert werden.
- **32 verschobene Kontrollvarianten** bleiben lumpbar, unterscheiden sich
  aber von der Referenzdynamik um 0,10 im maximalen Vorhersageverlust.
- Die **konstante Reduktion** wird verworfen: ihr minimaximaler Fehler 0,05
  übersteigt die festgelegte Vorhersagetoleranz 0,025.

Familie A hat drei positive Übergänge je Zeile, Familie B jeweils 2m. Ihre
Supportgraphen sind bei gleichem m somit nicht isomorph. Die gemeinsame
Zwei-Block-Dynamik bei lambda=0 ist absichtlich eingebaut. Sie ist keine
Entdeckung einer unbekannten Universalitätsklasse.

## Feste statistische Kampagne

`RAX-U1-QUAL-0001` verwendet ausschliesslich Protokoll e3, 160 Zellen mit je
20'000 unabhängigen Ein-Schritt-Versuchen im Simulatormodell. Der simultane
Hoeffding-Radius ist **b=0,014802071873007984** bei alpha=0,05. Die Toleranzen
bleiben delta_block=0,05 und delta_prediction=0,025.

| Störung lambda | Approximative Reduktion gestützt | Reduktion verworfen | Unentschieden |
| --- | ---: | ---: | ---: |
| 0 | 7 | 0 | 1 |
| 0,01 | 1 | 0 | 7 |
| 0,025 | 0 | 0 | 8 |
| 0,05 | 0 | 8 | 0 |
| 0,10 | 0 | 8 | 0 |
| **Gesamt** | **8** | **16** | **16** |

Jede Tabellenzeile enthält zwei Familien mit vier Grössen. Die Entscheidung
berücksichtigt beide Ausgangsblöcke und beide Präparationshälften gleichzeitig.
Die 160 statistischen Zellen sind nicht mit den 160 exakten Matrizen zu
verwechseln: Letztere umfassen zusätzlich die Protokolle e0–e2.

Bei lambda=0 bleibt B:m32 statistisch unentschieden: Eine obere Fehlergrenze
beträgt 0,027602071873007963 und liegt über 0,025. Der exakte Prüfer kennt
hier den wahren Fehler null; der Messadapter darf dieses Wissen nicht zur
Aufwertung seines statistischen Befunds verwenden. Bei lambda=0,01 wird nur
B:m4 gestützt. Es wurden weder Seeds gewechselt noch Stichproben ergänzt.

**Nutzen:** Der Versuch trennt exakte Reduzierbarkeit, hinreichend genaue
approximative Reduktion, nachgewiesene Verletzung und fehlende Entscheidung.
Insbesondere erzwingt die Methodik keinen positiven Befund, obwohl das
Kontrollmodell analytisch bekannt ist.

## Archivvorfall und Wiederherstellung

Der Erfassungsprozess protokollierte 6'400'000 Rohbytes und erzeugte seine
Auswertung. Bei der anschliessenden separaten Prüfung enthielt `trials.bin`
jedoch nur **5'680'000 Bytes**. Der primäre Prüfer gab `INVALID` aus; der
Referenzprüfer brach ab. Die erhaltene Folge war exakt ein Präfix der erwarteten
Folge. **Wodurch die letzten 720'000 Bytes verloren gingen, ist nicht geklärt.**

Das ursprüngliche verkürzte Archiv liegt unverändert unter
[`recovery/observed-trials.bin`](evidence/qualification/recovery/observed-trials.bin).
Der [Vorfallsbericht](evidence/qualification/recovery/recovery.json) hält den
Fehler, beide Hashes und die Wiederherstellung fest. Die frühere ungültige
[Auswertung](evidence/qualification/recovery/invalid-assessment.json) bleibt erhalten.

`reconstruct_raw.py` wurde **nach** dem Vorfall ergänzt. Es verwendet den
eingefrorenen Referenzoperator und dieselben Seeds. Vor dem Speichern müssen
alle 160 ursprünglichen Zählwerte sowie der bereits in `acquisition.json`
protokollierte vollständige SHA-256 übereinstimmen. Die rekonstruierten Bytes
wurden mit Flush/fsync gespeichert. Anschliessend bestanden der unveränderte
primäre Prüfer und der unveränderte vollständige Referenzprüfer.

Diese Wiederherstellung ist eine deterministische Reproduktion synthetischer
Daten, **keine neue unabhängige Stichprobe und kein Nachweis der ursprünglichen
Speicherdauerhaftigkeit**. Vertrag, vier eingefrorene Quelldateien, Seeds,
Erfassungsbericht und ursprüngliche statistische Auswertung blieben unverändert.
Das vollständige Archiv einschliesslich beschädigter Kopie bleibt unter 16 MiB.

## Herkunft und Reproduktion

Der lokale Implementierungscommit vor der Erfassung lautet
`a8b5da3221fbb58e883400bd73923b302fcac55a`.
Der interne Freeze ist keine externe Präregistrierung.
Der ursprüngliche Commit ist im [Git-Bundle](evidence/source-commit.bundle)
erhalten, aufbauend auf dem veröffentlichten Basiscommit
`270e224477997928a7779085355b868be355796b`. Die Veröffentlichung über die
GitHub-Schnittstelle erhält eine eigene Commit-ID. Diese ersetzt weder den
lokalen Freeze noch dessen unveränderte Quellkopien.

| Inhalt | SHA-256 |
| --- | --- |
| Vertrag | `ac55447cc18a31b7ce50c71638aaf850d2b77201ec47a479421d2464c474b932` |
| Freeze | `4312181820635b7db46792d4c05fb3811e041a05d3943a358fff37fcb263ddca` |
| Vollständige Rohfolge | `2bbe83bd28a46313a84a28a6d9bb589a44b2b3f607f01572b13ce1ada3ddccc0` |
| Verkürzte Rohfolge | `157dab8404971c49bf1d789827cb091f4af8af66e60f7638bc0cf1b8db42e504` |

Linux, Python 3.12; keine zusätzlichen Pythonpakete. Vom Repository-Stamm:

```sh
python3 -m unittest discover -s research/rax_u1/tests -v
python3 research/rax_u1/u1.py evaluate research/rax_u1/evidence/qualification
python3 research/rax_u1/reference.py research/rax_u1/evidence/qualification
python3 tests/python/verify_manifest.py
```

Diese Befehle prüfen bestehende Evidenz. Sie erfassen keine neuen Stichproben.
Der [Referenzbericht](evidence/qualification/reference-full.json) vergleicht
zusätzlich die Intervalle mit 60-stelliger Decimal-Arithmetik. Eine optionale
Rekonstruktion in eine **noch nicht vorhandene** Datei lautet:

```sh
python3 research/rax_u1/reconstruct_raw.py research/rax_u1/evidence/qualification /tmp/rax-u1-reconstructed.bin
```

Die 25 analytischen und adversarialen Softwaretests bestehen. Dazu gehören
falsche Präparationen, manipulierte Zählungen, fehlende Zellen, verkürzte
Rohdateien und plausible Rohdaten, die nicht dem Seed entsprechen. Die
[Testaufzeichnung](evidence/software-tests.txt) enthält die einzelnen Tests.
Der zusätzliche GitHub-Workflow prüft dasselbe Archiv ohne neue Ziehungen.

## Wissenschaftliche Grenze und nächstes Gate

RAX-U1 qualifiziert hier die mathematischen Kontrollen und die Auswertung eines
konstruierten Modells. Es liefert keinen physikalischen Destillationsrückstand,
keine emergente Geometrie, keine Lorentz-Symmetrie und keinen Singularitätsbefund.
Die Generatoren und die Projektion sind vorgegeben; es findet keine adaptive
Hypothesensuche statt. RAX-U2 und die späteren Arbeitspakete bleiben offen.

Vor einer unbeaufsichtigten Erfassung ist der Archivvorfall zu untersuchen und
ein versionierter Test für dauerhafte Speicherung zu bestehen. Das darf nicht
durch erneutes Ziehen bis zu günstigeren statistischen Ergebnissen ersetzt
werden. Die nächste wissenschaftliche Erweiterung bleibt U2 mit unbekannter
Reduktion, getrennten Prüfdaten und konkurrierenden Generatoren unter denselben
Evidenzregeln.
