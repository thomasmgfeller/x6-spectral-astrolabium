"""Analytical and adversarial controls. Hand-built fixtures are not qualification observations."""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import random
import shutil
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import u1
import reference

def counts_fixture():
    records = []
    for index, spec in enumerate(u1.cell_specs(u1.PROFILE)):
        probability = F(u1.PROFILE["protocols"]["e3"][spec["a"]]) + F(spec["lambda"]) * spec["h"]
        records.append({**spec, "offset": index*40000, "n": 20000, "switches": int(probability*20000)})
    return records

def replace_json(path, data):
    path.write_bytes(u1.canonical(data) + b"\n")

class AlgebraTests(unittest.TestCase):
    def test_all_base_models_match_second_generator(self):
        for family in ("A", "B"):
            for m in (4, 8, 16, 32):
                self.assertEqual(u1.make_model(family, m, 104729), reference.regenerate_model(family, m))

    def test_rational_operator_matches_integer_pair_reference(self):
        for family in ("A", "B"):
            model = u1.make_model(family, 4, 104729)
            for rates in u1.PROFILE["protocols"].values():
                for lam in u1.PROFILE["lambdas"]:
                    actual = u1.transition(model, rates, lam)
                    expected = reference.operator(model, rates, lam)
                    self.assertEqual([[str(x) for x in row] for row in actual],
                                     [[reference.textq(x) for x in row] for row in expected])

    def test_balanced_average_does_not_imply_lumpability(self):
        model = u1.make_model("B", 8, 104729)
        rates = u1.PROFILE["protocols"]["e3"]
        matrix = u1.transition(model, rates, "1/20")
        result = u1.summarize(matrix, [0]*8+[1]*8, model["h"], rates)
        self.assertFalse(result["lumpable"])
        self.assertEqual(result["delta"], "1/10")
        for a in (0, 1):
            averages = [F(result["preparations"][f"a{a}:h{s}"]) for s in (-1, 1)]
            self.assertEqual(sum(averages)/2, F(rates[a]))

    def test_arbitrary_relabel_transports_states_and_preparation(self):
        model = u1.make_model("A", 8, 104729)
        labels = [0]*8+[1]*8
        rates = u1.PROFILE["protocols"]["e3"]
        matrix = u1.transition(model, rates, "1/10")
        expected = u1.summarize(matrix, labels, model["h"], rates)
        order = list(range(16)); random.Random(31).shuffle(order)
        changed = [[matrix[i][j] for j in order] for i in order]
        self.assertEqual(u1.summarize(changed, [labels[i] for i in order], [model["h"][i] for i in order], rates), expected)
        self.assertNotEqual(u1.summarize(changed, [labels[i] for i in order], model["h"], rates), expected)

    def test_constant_reduction_fails_minimax_bound(self):
        self.assertEqual(u1.predict(None, "e3"), F(2, 5))
        self.assertEqual(max(abs(u1.predict(None, "e3")-u1.predict(a, "e3")) for a in (0,1)), F(1,20))
        with self.assertRaises(TypeError):
            u1.predict(None, "e3", preparation_id=1)

    def test_model_structure_rejects_unbalanced_and_invalid_weights(self):
        base = u1.make_model("A", 4, 104729)
        for mutation in ("h", "permutation", "zero", "boolean"):
            model = deepcopy(base)
            if mutation == "h": model["h"] = [1]*8
            elif mutation == "permutation": model["weights"]["01"][0] = model["weights"]["01"][1][:]
            elif mutation == "zero": model["weights"]["00"][0] = [0]*4
            else: model["weights"]["00"][0][0] = True
            with self.subTest(mutation=mutation), self.assertRaises(u1.Invalid):
                u1.transition(model, ["7/20", "9/20"], "0")

    def test_sampler_preserves_sparse_support_and_exact_replay(self):
        for family in ("A", "B"):
            model = u1.make_model(family, 4, 104729)
            spec = next(s for s in u1.cell_specs(u1.PROFILE) if s["family"] == family and s["lambda"] == "1/10")
            raw, count = u1.sample_cell(model, spec, 200, 104729)
            self.assertEqual(reference.replay_cell(model, spec["lambda"], spec["cell_id"], spec["a"], spec["h"], raw), count)

class StatisticsTests(unittest.TestCase):
    def test_all_decisions_against_decimal_oracle(self):
        records = counts_fixture()
        result = u1.assess_counts(records, u1.PROFILE)
        reference.compare(result, reference.decimal_assessment(records))
        self.assertEqual(result["counts"], {"APPROXIMATE_REDUCTION_SUPPORTED":16,"INCONCLUSIVE":8,"REDUCTION_REJECTED":16})

    def test_fixed_family_rejects_omission_duplicate_and_count_mutation(self):
        records = counts_fixture()
        cases = [records[:-1], [records[0]] + records[0:-1]]
        for key,value in [("n",19999),("switches",20001),("switches",True)]:
            changed=deepcopy(records); changed[0][key]=value; cases.append(changed)
        for changed in cases:
            with self.assertRaises(u1.Invalid): u1.assess_counts(changed,u1.PROFILE)

    def test_contract_cannot_relax_threshold_sample_size_or_seed(self):
        for key,value in [("alpha","1/2"),("n_per_cell",19999),("delta_prediction","1"),("seed",3),("extra",True)]:
            c=deepcopy(u1.PROFILE);c[key]=value
            with self.assertRaises(u1.Invalid):u1.validate_contract(c)

    def test_intervals_clip_and_do_not_accept_missing_evidence(self):
        self.assertEqual(u1.bounds_difference(0,1,.1),[.9,1])
        self.assertEqual(u1.bounds_difference(0,0,.1),[0,.1])
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(u1.evaluate(tmp)["validity"],"INVALID")

class EvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.base = Path(cls.temp.name)/"fixture"
        u1.prepare(HERE/"contract.json",cls.base)
        u1.write_json(cls.base/"reference-exact.json", reference.verify(cls.base, exact_only=True))
        cls.models = {x["id"]:x for x in u1.read_json(cls.base/"models.json")}
        records=counts_fixture(); raw=bytearray()
        # Deliberately ordered, non-random fixture for testing data validation only.
        # The separate seeded reference MUST reject it as qualification evidence.
        for record in records:
            model=cls.models[record["model_id"]];m=record["m"];a=record["a"]
            matrix=u1.transition(model,u1.PROFILE["protocols"]["e3"],record["lambda"])
            initial=next(i for i in range(2*m) if i//m==a and model["h"][i]==record["h"])
            stay=next(j for j in range(2*m) if j//m==a and matrix[initial][j]>0)
            switch=next(j for j in range(2*m) if j//m!=a and matrix[initial][j]>0)
            raw.extend(bytes((initial,switch))*record["switches"])
            raw.extend(bytes((initial,stay))*(20000-record["switches"]))
        (cls.base/"trials.bin").write_bytes(raw)
        fh=u1.digest((cls.base/"freeze.json").read_bytes())
        start={"campaign_id":u1.PROFILE["campaign_id"],"freeze_sha256":fh,"started_utc":u1.utc(),
               "preflight_reference_sha256":u1.digest((cls.base/"reference-exact.json").read_bytes())}
        u1.write_json(cls.base/"run_started.json",start)
        acq={"schema":"rax.u1.acquisition/1","status":"COMPLETE","evidence_kind":"SYNTHETIC_CONTROL",
             "campaign_id":u1.PROFILE["campaign_id"],"freeze_sha256":fh,"raw_sha256":u1.digest(raw),
             "raw_bytes":len(raw),"records":records,"completed_utc":u1.utc(),"elapsed_seconds":0,"peak_rss_kib":0}
        u1.write_json(cls.base/"acquisition.json",acq)
        u1.write_json(cls.base/"assessment.json",u1.evaluate(cls.base))

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def setUp(self):
        self.temp_case=tempfile.TemporaryDirectory()
        self.path=Path(self.temp_case.name)/"case"
        shutil.copytree(self.base,self.path)

    def tearDown(self):self.temp_case.cleanup()

    def test_valid_fixture_counts_recomputed(self):
        result=u1.evaluate(self.path)
        self.assertEqual(result["validity"],"VALID")
        self.assertFalse(result["physical_claim_supported"])

    def test_reference_checks_all_exact_cases(self):
        result=reference.verify(self.path,exact_only=True)
        self.assertEqual(result["exact"]["matrices"],160)
        self.assertEqual(result["exact"]["lumpable"],32)

    def test_plausible_fabricated_raw_fails_seeded_reference(self):
        with self.assertRaisesRegex(ValueError,"raw replay differs"):
            reference.verify(self.path)

    def test_repeated_acquisition_is_refused(self):
        with self.assertRaisesRegex(u1.Invalid,"already attempted"):
            u1.acquire(self.path)

    def test_missing_independent_preflight_blocks_acquisition(self):
        for name in ("run_started.json", "acquisition.json", "trials.bin", "assessment.json", "reference-exact.json"):
            (self.path/name).unlink()
        with self.assertRaises(u1.Invalid):
            u1.acquire(self.path)
        self.assertFalse((self.path/"run_started.json").exists())

    def test_truncated_raw_is_invalid(self):
        p=self.path/"trials.bin";p.write_bytes(p.read_bytes()[:-1])
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_missing_cell_is_invalid(self):
        p=self.path/"acquisition.json";d=u1.read_json(p);d["records"].pop();replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_wrong_counts_are_invalid_even_with_valid_raw_hash(self):
        p=self.path/"acquisition.json";d=u1.read_json(p);d["records"][0]["switches"]+=1;replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_wrong_preparation_is_invalid_after_rehash(self):
        p=self.path/"trials.bin";raw=bytearray(p.read_bytes());raw[0]=4;p.write_bytes(raw)
        p=self.path/"acquisition.json";d=u1.read_json(p);d["raw_sha256"]=u1.digest(raw);replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_duplicate_cells_are_invalid(self):
        p=self.path/"acquisition.json";d=u1.read_json(p);d["records"][1]=d["records"][0];replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_exact_report_tampering_invalidates_freeze(self):
        p=self.path/"exact.json";d=u1.read_json(p);d["cases"][0]["delta"]="1";replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_contract_tampering_is_invalid(self):
        p=self.path/"contract.json";d=u1.read_json(p);d["n_per_cell"]=100;replace_json(p,d)
        self.assertEqual(u1.evaluate(self.path)["validity"],"INVALID")

    def test_nan_and_duplicate_json_keys_rejected(self):
        p=self.path/"bad.json"
        for content in ('{"a":1,"a":2}','{"x":NaN}'):
            p.write_text(content)
            with self.assertRaises(ValueError):u1.read_json(p)

    def test_independent_oracle_detects_exact_report_error(self):
        models=list(self.models.values());report=u1.read_json(self.path/"exact.json")
        report["cases"][0]["matrix_sha256"]="0"*64
        with self.assertRaises(ValueError):reference.exact_check(models,report)

if __name__ == "__main__":unittest.main()
