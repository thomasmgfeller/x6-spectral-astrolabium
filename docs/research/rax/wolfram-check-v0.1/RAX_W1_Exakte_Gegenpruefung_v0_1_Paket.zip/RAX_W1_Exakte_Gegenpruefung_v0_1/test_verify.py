"""Falsification checks for the receipt auditor, no Wolfram calls."""
import copy
import unittest
import verify

class ReceiptAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.symbolic,cls.parts=verify.load_wolfram()

    def rejected(self,mutation):
        symbolic,parts=copy.deepcopy((self.symbolic,self.parts))
        mutation(symbolic,parts)
        with self.assertRaises((ValueError,KeyError)):
            verify.verify(symbolic,parts)

    def test_missing_case(self):
        self.rejected(lambda s,p:p[0]['cases'].pop())

    def test_duplicate_identity(self):
        self.rejected(lambda s,p:p[0]['cases'].__setitem__(1,copy.deepcopy(p[0]['cases'][0])))

    def test_forged_reduction(self):
        self.rejected(lambda s,p:p[0]['cases'][1].update(lumpable=True))

    def test_forged_matrix_digest(self):
        self.rejected(lambda s,p:p[1]['cases'][0].update(matrix_sha256='0'*64))

    def test_boolean_replaced_by_integer(self):
        self.rejected(lambda s,p:p[0]['cases'][0].update(stochastic=1))

    def test_changed_input_binding(self):
        self.rejected(lambda s,p:p[0].update(input_sha256='0'*64))

    def test_symbolic_not_executed_is_not_pass(self):
        self.rejected(lambda s,p:s.update(stochastic_on_domain='NOT_EXECUTED'))

    def test_shift_wrong_predictor_hidden(self):
        self.rejected(lambda s,p:p[1]['shift_controls'][0].update(prediction_loss='0'))

if __name__=='__main__':unittest.main()
