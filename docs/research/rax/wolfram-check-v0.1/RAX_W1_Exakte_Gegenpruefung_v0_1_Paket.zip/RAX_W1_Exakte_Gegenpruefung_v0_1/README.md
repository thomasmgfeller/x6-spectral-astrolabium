# RAX-W1 - exakte Gegenprüfung der endlichen Reduktionen v0.1

**Ergebnis: PASS_WITH_SCOPE_LIMITS.** Wolfram Language 15.0.1 hat die vorab
ausgewählten 44 endlichen U1-Matrizen separat aus den archivierten ganzzahligen
Gewichten aufgebaut. Alle Matrix-Hashes und exakten Eigenschaften stimmen mit
dem veröffentlichten U1-Bericht und beiden historischen Python-Rechenwegen
überein. Dies ist eine interne, nachträgliche Gegenprüfung mit einem anderen
Rechensystem; keine unabhängige personelle Begutachtung.

## Ausgeführter Umfang

| Prüfung | Ergebnis |
| --- | --- |
| Ausgewählte historische Matrizen | 44/44 exakt übereinstimmend |
| Dimensionen | 40 Matrizen mit 8 Zuständen; 4 mit 16 Zuständen |
| Stochastische Matrizen | 44/44 mit nichtnegativen rationalen Einträgen und Zeilensumme 1 |
| Exakte starke Reduktion zur vorgegebenen Partition | 10 gültig bei lambda=0; 34 erwartungsgemäss ungültig bei lambda>0 |
| Transportierte Zustandsumbenennung | 44/44 unveränderte Eigenschaften |
| Mehrschrittidentität bei lambda=0 | 20/20 Prüfungen für t=2,3 |
| Verschobene, weiterhin reduzierbare Kontrollen | 10/10: alter Prädiktor hat Fehler 1/10 |
| Ungültige stochastische Matrizen | 2/2 zurückgewiesen |
| Symbolische Aussagen | 7/7 Boolesche Aussagen bestätigt; zusätzlich exakte Minimax-Lösung |
| Manipulationsprüfungen des Abgleichs | 8/8 bestanden |

Die 44 Fälle sind **44 von 160 veröffentlichten exakten Matrixfällen**, keine
zufällige repräsentative Stichprobe. Auswahl: Familien A und B, m=4, alle vier
Protokolle und fünf Störstärken (40 Fälle); dazu m=8, Protokoll e3,
lambda in {0,1/10} (4 Fälle). Bei U1 ist m die Blockgrösse, die Gesamtzahl der
Zustände also 2m. Der Auswahlvertrag wurde vor dem ersten Wolfram-Aufruf
geschrieben und gehasht. Er ist keine externe Präregistrierung; die früheren
Ergebnisse waren bei seiner Erstellung bekannt.

## Mathematische Bedeutung

Für die Partition B0,B1 sei C die Indikatormatrix. Eine starke Markov-Reduktion
liegt genau dann vor, wenn eine 2x2-Matrix Q mit P C = C Q existiert.
Die Wolfram-Fassung konstruiert Q aus repräsentativen Zeilen und prüft alle
Zeilen. Der lokale lineare Abgleich verwendet dagegen Q_fit = C^T P C / m.
Beide Verfahren müssen das ursprüngliche Ergebnis reproduzieren.

Die archivierten Gewichte werden zeilenweise zu K_ab normiert. U1 verwendet
r_a(i)=p_a+lambda*h_i, wobei in jedem Block beide Vorzeichen vorkommen und
gleich häufig sind. Die inneren Blockmassen sind 1-r_a(i), die wechselnden
Blockmassen r_a(i). Die geprüfte symbolische Domäne lautet
0<p0,p1<1 und 0<=lambda<min(p0,1-p0,p1,1-p1). Darin gilt für diese Konstruktion:

- starke Reduktion zur vorgegebenen Partition genau für lambda=0;
- maximale Differenz der Wechselwahrscheinlichkeiten innerhalb eines Blocks
  delta=2*lambda;
- maximaler Fehler des unveränderten Wechselprädiktors p_a gleich lambda.

Die Voraussetzungen gehören zum Ergebnis. Wolfram verarbeitet dafür die
vier algebraischen Blockmassenzeilen für h=-1,+1. Die Ableitung dieser Zeilen
aus normierten K_ab ist eine kurze analytische Herleitung im PDF, keine
vollständige formale Verifikation beliebigen Programmcodes.

Aus P C=C Q folgt durch Induktion P^t C=C Q^t für ganzzahliges t>=1.
Die 20 ausgeführten Prüfungen für t=2,3 kontrollieren die konkreten Matrizen;
die allgemeine Folgerung ist die angegebene algebraische Identität.

## Reproduzierbare Gegenkontrollen

1. A:m4, e3, lambda=1/10: Mikro-Zustände 0 und 1 liegen beide in B0,
   haben aber Wechselwahrscheinlichkeiten 1/4 und 9/20. Ihre Differenz ist
   1/5. Die vorgegebene starke Reduktion scheitert.
2. Gleichgewichtete Mittelung über die Mikro-Zustände jedes Blocks ergibt
   trotzdem die ursprüngliche 2x2-Matrix Q. Das gilt in allen 34 gestörten
   Auswahlfällen. Passende Ein-Schritt-Mittelwerte sind daher kein Nachweis
   starker Reduzierbarkeit oder eines unverändert gültigen Mehrschrittmodells.
3. Bei lambda=0 wird p0 um 1/10 verschoben. Die starke Reduktion bleibt gültig;
   der alte Prädiktor ist dennoch falsch (maximaler Fehler 1/10).
4. Für einen konstanten Prädiktor x der Wechselwahrscheinlichkeit unter e3
   beträgt min_x max(|x-7/20|,|x-9/20|)=1/20, erreicht bei x=2/5.
   Das übersteigt die U1-Toleranz 1/40. Dies betrifft den Wechselindikator,
   nicht irgendeine beliebige Vorhersage des nächsten Zustands.
5. Eine Matrix mit falscher Zeilensumme und eine Matrix mit negativer
   Wahrscheinlichkeit trotz Zeilensumme 1 werden zurückgewiesen.

Diese Kontrollen stammen aus der bekannten U1-Konstruktion bzw. deren
offengelegten Erweiterungen. Sie sind keine neu entdeckte Universalitätsklasse.

## Offline prüfen

Python 3.12, nur Standardbibliothek; keine Installation, kein Netz und kein
Wolfram-Zugang für diese Nachprüfung der gespeicherten Belege nötig:

```sh
python3 -B verify_package.py
python3 -B verify.py
python3 -B -m unittest -v test_verify
```

Ein neuer Bericht kann mit `python3 -B verify.py --output ../new-verification.json`
geschrieben werden; eine bestehende Datei wird nicht überschrieben.
Die Offline-Prüfung liest die vollständigen gespeicherten Wolfram-Antworten,
entpackt die erklärte Feldstruktur und vergleicht alle 44 Fälle mit dem
historischen Original sowie zwei historischen Python-Implementierungen und
einem zusätzlichen rationalen Matrixabgleich. Sie führt Wolfram selbst nicht
erneut aus. Die symbolischen Antworten werden als aufgezeichnete Ergebnisse
geprüft; die Herleitungen stehen im Bericht.

## Wolfram erneut ausführen

Die drei Dateien sind eigenständig und benötigen keine Sitzungsvorgeschichte:

- `source/symbolic.wl`
- `source/finite-A.wl`
- `source/finite-B.wl`

Die endlichen Eingaben enthalten die archivierten Gewichte und Parameter,
aber keine erwarteten Resultate. Mit einem bereits verfügbaren, entsprechend
lizenzierten `wolframscript` und einem neuen Zielverzeichnis:

```sh
mkdir ../new-wolfram-run
wolframscript -code 'Print[Get["source/symbolic.wl"]]' > ../new-wolfram-run/symbolic.json
wolframscript -code 'Print[Get["source/finite-A.wl"]]' > ../new-wolfram-run/finite-A.json
wolframscript -code 'Print[Get["source/finite-B.wl"]]' > ../new-wolfram-run/finite-B.json
python3 -B verify.py --wolfram-json-dir ../new-wolfram-run
```

Alternativ können die drei WL-Texte einzeln in einem bestehenden Wolfram-Kern
ausgewertet werden. Dieser Auftrag hat den angebundenen Cloud-Auswerter genutzt,
keine lokale Wolfram-Installation. Die obige wolframscript-Befehlsfolge wurde
hier deshalb nicht separat ausgeführt. Alle Eingaben und Antworten sind enthalten.

`source/prepare_input.py` und `source/prepare_parts.py` erzeugen die Eingaben
deterministisch aus den mitgelieferten Baseline-Dateien; auf einer Arbeitskopie
ausführen. Sie enthalten keine Rechenresultate als Vorgaben für Wolfram.

## Ausführungsprotokoll und Budget

Vier Wolfram-Auswertungen mit jeweils maximal 45 Sekunden angefordert:

1. Symbolischer Auftrag: vollständige Antwort erhalten.
2. Alle 44 Fälle gemeinsam: Antwort nach 10.008 Zeichen mit Auslassung gekürzt;
   nicht als vollständiger Nachweis akzeptiert. Unverändert mitgeliefert.
3. Familie A, 22 Fälle: vollständige kompakte Ausgabe, erfolgreich geparst.
4. Familie B, 22 Fälle: vollständige kompakte Ausgabe, erfolgreich geparst.

Die Aufteilung änderte nur den Transport, nicht Fallauswahl oder Abnahmekriterien.
Die Rohantworten, Eingaben und Transportanpassung stehen unter `evidence/`.
Wolfram meldete Version 15.0.1 für Linux x86-64 (2. Juli 2026); der lokale
Abgleich verwendete Python 3.12.14. Laufzeiten sind kein Leistungsbenchmark.

Zusatzbudget: 0 CHF. Es wurde ausschliesslich die bestehende Anbindung verwendet;
keine kostenpflichtige Lizenz, Rechenleistung oder API wurde neu aktiviert.
Eine kontospezifische Abrechnung ist nicht einsehbar. Der kostenlose Cloud-Zugang
ist laut Wolfram auf begrenzte persönliche Nutzung beschränkt:
https://www.wolfram.com/artificial-intelligence/mcp/cloud/

## Herkunft und Grenzen

Baseline: Repository `thomasmgfeller/x6-spectral-astrolabium`, Commit
`a4641e00d9f699311e7105d0b5c94b7b356a5ab7`, veröffentlichtes U1-Gegenprüfungspaket.
Archiv-SHA-256:
`35bf1c48f6c0874c713ccdb2155e793536ab6a8bd69353095e0b54f70b7d03a8`.
Das vollständige alte Archiv wird nicht dupliziert; alle für W1 benötigten
Originaldateien sind unter `baseline/` bytegleich enthalten. Herkunft und
Einzelhashes stehen in `baseline/PROVENANCE.json`.

Nicht Bestandteil dieses Auftrags: erneute Erfassung oder Nachrechnung der
3,2 Millionen Übergänge, die 116 übrigen U1-Matrixfälle in Wolfram, B1-Statistik,
Behebung des alten Archivvorfalls, RAX-U2, physikalische Messungen, Kontinuumssätze
oder unabhängige personelle Begutachtung. W1 ändert weder die U1-Entscheidungen
8 gestützt / 16 verworfen / 16 unentschieden noch die acht unentschiedenen
B1-Hauptvergleiche. Gleiche Modellannahmen und dieselbe Aufgabeninterpretation
können trotz verschiedener Rechenkerne gemeinsame Fehler verursachen.

Das Ergebnis stärkt die exakte rechnerische Absicherung dieses begrenzten
U1-Teilbereichs. Es bescheinigt weder die gesamte Software noch eine neue Physik.
Hashes und gespeicherte Antworten sind keine Signaturen oder externe Attestierung.

Copyright 2026 Thomas Gfeller. Neue Projektquellen und Bericht: Apache-2.0,
siehe LICENSE. Historische Bestandteile behalten ihren Lizenzumfang unter
`baseline/LICENSE_SCOPE.md`. Wolfram-Kernel und proprietäre Bibliotheken werden
nicht mitgeliefert. Dieses Paket behauptet keine Begutachtung oder Empfehlung
durch Wolfram Research.

## Optionale Berichtserzeugung

`python3 source/create_report.py /neuer/pfad/bericht.pdf` erzeugt den Bericht
mit ReportLab 4.4.9 und DejaVu-Schriften unter `/usr/share/fonts/truetype/dejavu/`.
Dies ist für die wissenschaftliche Offline-Nachprüfung nicht erforderlich.
