#!/usr/bin/env python3
"""Exact local inventory check; hashes are not signatures."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
actual={p.relative_to(root).as_posix() for p in root.rglob('*')
        if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'}
expected=set(manifest['files'])
errors=[]
if actual!=expected:
    errors.append({'missing':sorted(expected-actual),'unlisted':sorted(actual-expected)})
for name,item in manifest['files'].items():
    path=root/name
    if not path.is_file() or path.is_symlink():
        errors.append({'invalid_file':name});continue
    data=path.read_bytes()
    if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
        errors.append({'digest_or_size':name})
print(json.dumps({'status':'PASS' if not errors else 'FAIL','files':len(expected),'errors':errors},indent=2))
raise SystemExit(bool(errors))
