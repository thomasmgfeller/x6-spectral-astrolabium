(* The embedded input contains archived integer weights and rational parameters,
   but no expected outputs. It is inserted by prepare_input.py. *)
ClearAll[parseQ,qstr,canonicalMatrix,build,indicator,maxabs,summary,one,shifted];
inputText = "{\"cases\":[{\"lambda\":\"0\",\"lambda_index\":0,\"model_id\":\"A:m4\",\"protocol\":\"e0\",\"rates\":[\"1/5\",\"3/10\"]},{\"lambda\":\"1/100\",\"lambda_index\":1,\"model_id\":\"A:m4\",\"protocol\":\"e0\",\"rates\":[\"1/5\",\"3/10\"]},{\"lambda\":\"1/40\",\"lambda_index\":2,\"model_id\":\"A:m4\",\"protocol\":\"e0\",\"rates\":[\"1/5\",\"3/10\"]},{\"lambda\":\"1/20\",\"lambda_index\":3,\"model_id\":\"A:m4\",\"protocol\":\"e0\",\"rates\":[\"1/5\",\"3/10\"]},{\"lambda\":\"1/10\",\"lambda_index\":4,\"model_id\":\"A:m4\",\"protocol\":\"e0\",\"rates\":[\"1/5\",\"3/10\"]},{\"lambda\":\"0\",\"lambda_index\":0,\"model_id\":\"A:m4\",\"protocol\":\"e1\",\"rates\":[\"7/20\",\"3/10\"]},{\"lambda\":\"1/100\",\"lambda_index\":1,\"model_id\":\"A:m4\",\"protocol\":\"e1\",\"rates\":[\"7/20\",\"3/10\"]},{\"lambda\":\"1/40\",\"lambda_index\":2,\"model_id\":\"A:m4\",\"protocol\":\"e1\",\"rates\":[\"7/20\",\"3/10\"]},{\"lambda\":\"1/20\",\"lambda_index\":3,\"model_id\":\"A:m4\",\"protocol\":\"e1\",\"rates\":[\"7/20\",\"3/10\"]},{\"lambda\":\"1/10\",\"lambda_index\":4,\"model_id\":\"A:m4\",\"protocol\":\"e1\",\"rates\":[\"7/20\",\"3/10\"]},{\"lambda\":\"0\",\"lambda_index\":0,\"model_id\":\"A:m4\",\"protocol\":\"e2\",\"rates\":[\"1/5\",\"9/20\"]},{\"lambda\":\"1/100\",\"lambda_index\":1,\"model_id\":\"A:m4\",\"protocol\":\"e2\",\"rates\":[\"1/5\",\"9/20\"]},{\"lambda\":\"1/40\",\"lambda_index\":2,\"model_id\":\"A:m4\",\"protocol\":\"e2\",\"rates\":[\"1/5\",\"9/20\"]},{\"lambda\":\"1/20\",\"lambda_index\":3,\"model_id\":\"A:m4\",\"protocol\":\"e2\",\"rates\":[\"1/5\",\"9/20\"]},{\"lambda\":\"1/10\",\"lambda_index\":4,\"model_id\":\"A:m4\",\"protocol\":\"e2\",\"rates\":[\"1/5\",\"9/20\"]},{\"lambda\":\"0\",\"lambda_index\":0,\"model_id\":\"A:m4\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"1/100\",\"lambda_index\":1,\"model_id\":\"A:m4\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"1/40\",\"lambda_index\":2,\"model_id\":\"A:m4\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"1/20\",\"lambda_index\":3,\"model_id\":\"A:m4\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"1/10\",\"lambda_index\":4,\"model_id\":\"A:m4\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"0\",\"lambda_index\":0,\"model_id\":\"A:m8\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]},{\"lambda\":\"1/10\",\"lambda_index\":4,\"model_id\":\"A:m8\",\"protocol\":\"e3\",\"rates\":[\"7/20\",\"9/20\"]}],\"models\":[{\"family\":\"A\",\"h\":[-1,1,1,-1,-1,1,-1,1],\"id\":\"A:m4\",\"m\":4,\"weights\":{\"00\":[[2,1,0,0],[0,2,1,0],[0,0,2,1],[1,0,0,2]],\"01\":[[0,1,0,0],[1,0,0,0],[0,0,0,1],[0,0,1,0]],\"10\":[[0,1,0,0],[1,0,0,0],[0,0,0,1],[0,0,1,0]],\"11\":[[2,1,0,0],[0,2,1,0],[0,0,2,1],[1,0,0,1]]}},{\"family\":\"A\",\"h\":[1,-1,-1,1,1,-1,1,-1,1,1,-1,1,-1,-1,1,-1],\"id\":\"A:m8\",\"m\":8,\"weights\":{\"00\":[[1,2,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,1,2,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,1,2,0],[0,0,0,0,0,0,2,1],[2,0,0,0,0,0,0,1]],\"01\":[[0,0,0,0,0,0,1,0],[0,0,0,1,0,0,0,0],[0,0,0,0,0,0,0,1],[0,0,0,0,1,0,0,0],[0,0,1,0,0,0,0,0],[0,1,0,0,0,0,0,0],[0,0,0,0,0,1,0,0],[1,0,0,0,0,0,0,0]],\"10\":[[0,0,0,0,0,0,0,1],[0,0,0,1,0,0,0,0],[0,0,0,0,1,0,0,0],[1,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[0,0,0,0,0,1,0,0],[0,0,1,0,0,0,0,0],[0,1,0,0,0,0,0,0]],\"11\":[[1,1,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,2,1,0,0,0,0],[0,0,0,1,2,0,0,0],[0,0,0,0,2,1,0,0],[0,0,0,0,0,1,2,0],[0,0,0,0,0,0,1,1],[1,0,0,0,0,0,0,1]]}}]}";
input = ImportString[inputText,"RawJSON"];
parseQ[s_String] := With[{parts=StringSplit[s,"/"]},
  If[Length[parts]==1,FromDigits[parts[[1]]],FromDigits[parts[[1]]]/FromDigits[parts[[2]]]]];
qstr[z_] := If[Denominator[z]==1,ToString[Numerator[z]],
  ToString[Numerator[z]]<>"/"<>ToString[Denominator[z]]];
canonicalMatrix[a_] := "["<>StringRiffle[
  ("["<>StringRiffle[("\""<>qstr[#]<>"\""&)/@# ,","]<>"]"&)/@a,","]<>"]";
build[model_,rates_,ell_] := Module[{m=model["m"],h=model["h"],w=model["weights"],r0,r1,k},
  k[key_] := (#/Total[#]&)/@w[key];
  r0=rates[[1]]+ell Take[h,m]; r1=rates[[2]]+ell Drop[h,m];
  ArrayFlatten[{{DiagonalMatrix[1-r0].k["00"],DiagonalMatrix[r0].k["01"]},
                {DiagonalMatrix[r1].k["10"],DiagonalMatrix[1-r1].k["11"]}}]];
indicator[labels_] := Table[Boole[labels[[i]]==b],{i,Length[labels]},{b,0,1}];
maxabs[a_] := Max[Abs[Flatten[a]]];
summary[p_,labels_,h_,rates_] := Module[{c=indicator[labels],n=Length[p],masses,q0,q,reps,diam,preps},
  masses=p.c; q0={{1-rates[[1]],rates[[1]]},{rates[[2]],1-rates[[2]]}};
  reps=First[First[Position[labels,#]]]& /@ {0,1}; q=masses[[reps]];
  diam=Max[Flatten[Table[If[labels[[i]]==labels[[j]],maxabs[masses[[i]]-masses[[j]]],0],{i,n},{j,n}]]];
  preps=Association[Flatten[Table[
    ("a"<>ToString[b]<>":h"<>ToString[s])->qstr[Mean[
      Table[If[labels[[i]]==b && h[[i]]==s,masses[[i,2-b]],Nothing],{i,n}]]],
    {b,0,1},{s,{-1,1}}]]];
  <|"stochastic"->TrueQ[And@@Thread[Flatten[p]>=0] && And@@(Total[#]==1& /@p)],
    "lumpable"->TrueQ[p.c==c.q],"delta"->qstr[diam],
    "prediction_loss"->qstr[maxabs[p.c-c.q0]],"preparations"->preps,
    "row_support"->Sort[DeleteDuplicates[Count[#,Except[0]]& /@p]]|>];
models=Association[(#["id"]->#)& /@input["models"]];
one[spec_] := Module[{model=models[spec["model_id"]],m,rates,ell,p,labels,h,c,q,s,perm,powers},
  m=model["m"]; h=model["h"]; rates=parseQ /@spec["rates"]; ell=parseQ[spec["lambda"]];
  p=build[model,rates,ell]; labels=Join[ConstantArray[0,m],ConstantArray[1,m]];
  c=indicator[labels]; q={{1-rates[[1]],rates[[1]]},{rates[[2]],1-rates[[2]]}};
  s=summary[p,labels,h,rates]; perm=RotateLeft[Range[2m]];
  powers=If[ell==0,Association[Table[ToString[t]->qstr[maxabs[MatrixPower[p,t].c-c.MatrixPower[q,t]]],{t,{2,3}}]],<||>];
  Join[KeyTake[spec,{"model_id","protocol","lambda","lambda_index"}],s,
    <|"matrix_sha256"->Hash[canonicalMatrix[p],"SHA256","HexString"],
      "intertwining_residual"->qstr[maxabs[p.c-c.q]],
      "relabeling_pass"->TrueQ[s==summary[p[[perm,perm]],labels[[perm]],h[[perm]],rates]],
      "balanced_average_equals_base_Q"->TrueQ[Transpose[c].p.c/m==q],
      "power_residuals"->powers|>]];
shifted[spec_] := Module[{model=models[spec["model_id"]],m,rates,p,labels,s},
  m=model["m"]; rates=parseQ /@spec["rates"];
  p=build[model,rates+{1/10,0},0]; labels=Join[ConstantArray[0,m],ConstantArray[1,m]];
  s=summary[p,labels,model["h"],rates];
  Join[KeyTake[spec,{"model_id","protocol"}],s,
    <|"matrix_sha256"->Hash[canonicalMatrix[p],"SHA256","HexString"]|>]];
finiteCases=one /@input["cases"];
shiftCases=shifted /@DeleteDuplicatesBy[input["cases"],{#["model_id"],#["protocol"]}&];
controlModel=models["A:m4"]; controlP=build[controlModel,{7/20,9/20},0];
badSum=controlP; badSum[[1,1]]+=1;
badNegative=controlP; badNegative[[1]]=Join[{-1,2},ConstantArray[0,Length[controlP]-2]];
labels=Join[ConstantArray[0,4],ConstantArray[1,4]];
result=<|"schema"->"rax.w1.finite/1","kernel_version"->$Version,
 "input_sha256"->Hash[inputText,"SHA256","HexString"],
 "sha256_abc"->Hash["abc","SHA256","HexString"],
 "cases"->finiteCases,"shift_controls"->shiftCases,
 "invalid_controls"-><|
   "wrong_row_sum_rejected"->Not[summary[badSum,labels,controlModel["h"],{7/20,9/20}]["stochastic"]],
   "negative_probability_rejected"->Not[summary[badNegative,labels,controlModel["h"],{7/20,9/20}]["stochastic"]],
   "negative_control_still_has_unit_row_sums"->TrueQ[And@@(Total[#]==1& /@badNegative)]|>|>;
(* Lossless field packing to stay below the connector's observed text cap. *)
caseFields={"model_id","protocol","lambda","lambda_index","stochastic","lumpable",
 "delta","prediction_loss","preparations","row_support","matrix_sha256",
 "intertwining_residual","relabeling_pass","balanced_average_equals_base_Q","power_residuals"};
shiftFields={"model_id","protocol","stochastic","lumpable","delta","prediction_loss",
 "preparations","row_support","matrix_sha256"};
pack[a_,fields_] := Lookup[a,fields]/. {
  x_Association :> Values[x]};
packed=<|"schema"->"rax.w1.finite-packed/1","kernel_version"->result["kernel_version"],
 "input_sha256"->result["input_sha256"],"sha256_abc"->result["sha256_abc"],
 "case_fields"->caseFields,"preparation_keys"->{"a0:h-1","a0:h1","a1:h-1","a1:h1"},
 "power_keys"->{"2","3"},
 "cases"->(pack[#,caseFields]& /@result["cases"]),
 "shift_fields"->shiftFields,"shift_controls"->(pack[#,shiftFields]& /@result["shift_controls"]),
 "invalid_controls"->result["invalid_controls"]|>;
ExportString[packed,"RawJSON","Compact"->True]
