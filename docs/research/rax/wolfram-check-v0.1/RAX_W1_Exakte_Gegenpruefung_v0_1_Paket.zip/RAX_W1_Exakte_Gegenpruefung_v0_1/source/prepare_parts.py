"""Split only transport, preserving the frozen scientific case selection."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'evidence/input.json').read_text())
base=(root/'source/finite-template.wl').read_text()
base=base.rsplit('ExportString[result,"RawJSON","Compact"->True]',1)[0]
compact=(root/'source/compact-output.wl').read_text()
parts=[]
for family in ('A','B'):
 obj={'models':[m for m in data['models'] if m['family']==family],
      'cases':[c for c in data['cases'] if c['model_id'].startswith(family+':')]}
 # Both calls use the same invalid-input control from A:m4.
 if family=='B': obj['models'].append(next(m for m in data['models'] if m['id']=='A:m4'))
 payload=json.dumps(obj,sort_keys=True,separators=(',',':'))
 (root/f'evidence/input-{family}.json').write_text(payload)
 (root/f'source/finite-{family}.wl').write_text(base.replace('INPUT_JSON_STRING',json.dumps(payload))+compact)
 parts.append({'family':family,'case_count':len(obj['cases']),'input_sha256':hashlib.sha256(payload.encode()).hexdigest()})
(root/'evidence/transport-adjustment.json').write_text(json.dumps({
 'reason':'First complete finite output was truncated by the connector at 10008 characters and could not be parsed.',
 'first_finite_response_status':'INCOMPLETE_TRANSPORT_NOT_ACCEPTED_AS_EVIDENCE',
 'change':'Same 44 cases split into families A and B; repeated field names packed losslessly into a declared ordered array.',
 'acceptance_criteria_unchanged':True,'parts':parts},indent=2)+'\n')
print(json.dumps(parts))
