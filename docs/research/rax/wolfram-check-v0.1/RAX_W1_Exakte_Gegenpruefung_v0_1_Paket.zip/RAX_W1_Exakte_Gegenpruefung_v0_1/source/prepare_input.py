"""Build the self-contained Wolfram input without importing any U1 implementation."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
contract = json.loads((ROOT / 'contract.json').read_text())
baseline = json.loads((ROOT / 'baseline/contract.json').read_text())
models = json.loads((ROOT / 'baseline/models.json').read_text())
cases = [{k: c[k] for k in ('model_id','protocol','lambda_index','lambda')}
         | {'rates': baseline['protocols'][c['protocol']]}
         for c in contract['selected_cases']]
model_ids = {c['model_id'] for c in cases}
data = {'models':[m for m in models if m['id'] in model_ids], 'cases':cases}
payload = json.dumps(data,sort_keys=True,separators=(',',':'))
(ROOT / 'evidence/input.json').write_text(payload)
template=(ROOT / 'source/finite-template.wl').read_text()
(ROOT / 'source/finite.wl').write_text(template.replace('INPUT_JSON_STRING',json.dumps(payload)))
print(json.dumps({'cases':len(cases),'models':len(data['models']),
                  'input_sha256':hashlib.sha256(payload.encode()).hexdigest()}))
