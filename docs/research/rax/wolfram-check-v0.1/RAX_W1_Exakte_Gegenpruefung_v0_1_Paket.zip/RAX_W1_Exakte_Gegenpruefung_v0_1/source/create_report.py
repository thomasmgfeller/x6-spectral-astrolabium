from pathlib import Path
import sys
import json
from xml.sax.saxutils import escape
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4

ROOT=Path(__file__).resolve().parents[1]
P=ROOT
result=json.loads((P/'evidence/verification.json').read_text())
assert result['status']=='PASS_WITH_SCOPE_LIMITS' and result['selected_matrices']==44
fonts=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('DV','DejaVuSans.ttf'),('DV-Bold','DejaVuSans-Bold.ttf'),('DVM','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(fonts/file)))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV',boldItalic='DV-Bold')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyR',fontName='DV',fontSize=9.4,leading=14,spaceAfter=8,textColor=colors.HexColor('#233044')))
styles.add(ParagraphStyle(name='TitleR',fontName='DV-Bold',fontSize=25,leading=31,spaceAfter=12,textColor=colors.HexColor('#102941')))
styles.add(ParagraphStyle(name='SubR',fontName='DV',fontSize=12,leading=17,spaceAfter=16,textColor=colors.HexColor('#406277')))
styles.add(ParagraphStyle(name='HeadR',fontName='DV-Bold',fontSize=13,leading=18,spaceBefore=10,spaceAfter=8,textColor=colors.HexColor('#102941')))
styles.add(ParagraphStyle(name='SmallR',fontName='DV',fontSize=8,leading=11.5,spaceAfter=6,textColor=colors.HexColor('#465467')))
styles.add(ParagraphStyle(name='MonoR',fontName='DVM',fontSize=8.4,leading=12,spaceAfter=9,textColor=colors.HexColor('#102941')))
styles.add(ParagraphStyle(name='CellR',fontName='DV',fontSize=8.5,leading=12,textColor=colors.HexColor('#233044')))

story=[]
def para(text,sty='BodyR'):story.append(Paragraph(text,styles[sty]))
def head(text):para(text,'HeadR')
def mono(text):para(escape(text).replace('\n','<br/>'),'MonoR')
def table(rows,widths):
    data=[[Paragraph(str(c),styles['CellR']) for c in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5eef4')),
       ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f4f7fa')]),
       ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),
       ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),
       ('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#9db4c5'))]))
    story.append(t);story.append(Spacer(1,10))
def page():story.append(PageBreak())

para('RAX-W1','TitleR')
para('Exakte Gegenprüfung der endlichen Reduktionen<br/>Ausgeführter Prüfbericht v0.1 | 14. Oktober 2026','SubR')
para('<b>Ergebnis: PASS_WITH_SCOPE_LIMITS.</b> Alle 44 ausgewählten U1-Matrizen wurden in Wolfram Language separat aus den veröffentlichten ganzzahligen Gewichten aufgebaut. Matrix-Hashes und exakte Eigenschaften stimmen mit den veröffentlichten Resultaten und beiden historischen Python-Rechenwegen überein.')
table([
 ['<b>Ausgeführt</b>','<b>Beobachtetes Ergebnis</b>'],
 ['Exakte Matrixfälle','44/44 Übereinstimmungen; 40 Matrizen mit 8 Zuständen, 4 mit 16 Zuständen'],
 ['Starke Reduzierbarkeit','10 gültige Reduktionen; 34 erwartete Verletzungen bei positiver Störstärke'],
 ['Zustandsumbenennung','44/44 transportierte Prüfungen bestanden'],
 ['Mehrschrittidentität','20/20 Prüfungen für t=2,3 bei Störstärke null'],
 ['Gegenkontrollen','10 verschobene Modelle; 2 ungültige Matrizen; konstanter Prädiktor und verdeckende Mittelung'],
 ['Symbolischer Teil','7 Boolesche Aussagen bestätigt; exakte Minimax-Lösung 1/20 bei Prognose 2/5'],
 ['Abgleichsprogramm','8/8 Manipulationsprüfungen bestanden']
],[165,334])
head('Was dieses Ergebnis trägt')
para('Die Prüfung stärkt die exakte rechnerische Absicherung des ausgewählten endlichen U1-Teilbereichs. Sie bestätigt auch, dass gültige Reduzierbarkeit und die Gültigkeit eines bestimmten Prädiktors getrennt geprüft werden müssen. In den ausgewählten Fällen wurde kein Widerspruch zum veröffentlichten U1-Bericht gefunden.')
head('Was offen bleibt')
para('Es handelt sich um eine interne, nachträgliche Gegenprüfung mit einem anderen Rechenkern. Externe personelle Begutachtung, neue Universalitätsklassen, allgemeine Kontinuumsaussagen und physikalische Validierung sind nicht erbracht. Die Auswahl deckt 44 der 160 historischen Matrixfälle ab; die 3,2 Millionen Übergänge wurden hier nicht erneut nachgerechnet.')
para('Auftrag und Auswertung: Thomas Gfeller / KI-gestützter Arbeitsprozess. Wolfram ist der eingesetzte Rechendienst; eine fachliche Begutachtung durch Wolfram Research wird nicht behauptet.','SmallR')

page()
para('1. Prüfvertrag und Mathematik','TitleR')
para('Die Auswahl wurde vor dem ersten Wolfram-Aufruf festgelegt: Familien A und B, Blockgrösse m=4, alle vier Protokolle und fünf Störstärken; zusätzlich m=8, Protokoll e3 und Störstärken 0 und 1/10. Die Gesamtzahl der Zustände beträgt 2m. Die historischen Resultate waren bekannt; dies ist keine externe Präregistrierung.')
head('Definition der geprüften Familie')
para('Die ganzzahligen Gewichte W<sub>ab</sub> werden zeilenweise zu stochastischen Kernen K<sub>ab</sub> normiert. Jeder Zustand trägt h<sub>i</sub> in {-1,+1}; beide Vorzeichen kommen in jedem Block gleich häufig vor. Die Wechselwahrscheinlichkeit lautet r<sub>a</sub>(i)=p<sub>a</sub>+λh<sub>i</sub>.')
mono('P[(a,i),(b,j)] = (1-r_a(i)) K_aa[i,j]   für b=a\nP[(a,i),(b,j)] = r_a(i) K_ab[i,j]       für b ungleich a')
para('Mit der Partitions-Indikatormatrix C liegt eine starke Markov-Reduktion genau dann vor, wenn P C=C Q für eine 2x2-Matrix Q gilt. Wolfram prüft dies anhand repräsentativer Blockzeilen und aller übrigen Zeilen. Der zusätzliche rationale Python-Abgleich verwendet Q<sub>fit</sub>=C<sup>T</sup>P C/m.')
head('Symbolisch bestätigte Bedingungen')
para('Domäne: 0&lt;p<sub>0</sub>,p<sub>1</sub>&lt;1 und 0≤λ&lt;min(p<sub>0</sub>,1-p<sub>0</sub>,p<sub>1</sub>,1-p<sub>1</sub>). Die vier Blockmassenzeilen für h=-1,+1 ergeben stochastische Übergänge. Gleichheit der beiden Zeilen je Block ist genau für λ=0 möglich. Der maximale Unterschied der Wechselwahrscheinlichkeiten innerhalb eines Blocks ist δ=2λ; der maximale Fehler des unveränderten Wechselprädiktors ist λ.')
table([
 ['<b>λ</b>','<b>Fälle</b>','<b>δ</b>','<b>Prognosefehler</b>','<b>Starke Reduktion</b>'],
 ['0','10','0','0','gültig'],['1/100','8','1/50','1/100','ungültig'],
 ['1/40','8','1/20','1/40','ungültig'],['1/20','8','1/10','1/20','ungültig'],
 ['1/10','10','1/5','1/10','ungültig']
],[64,53,64,137,181])
para('Analytischer Anschluss: Wegen der Zeilennormierung von K<sub>ab</sub> sind die Blockmassen 1-r<sub>a</sub>(i) und r<sub>a</sub>(i). Beide Vorzeichen erzwingen bei gleichen Blockmassen 2λ=0. Aus P C=C Q folgt durch Induktion P<sup>t</sup>C=C Q<sup>t</sup>. Die konkrete Software prüfte zusätzlich t=2,3 in allen zehn Nullstörungsfällen.','SmallR')

page()
para('2. Gegenbeispiele und Kontrollen','TitleR')
head('Ein korrekter Mittelwert kann eine falsche Reduktion verdecken')
para('Im veröffentlichten Modell A:m4, Protokoll e3 und λ=1/10 liegen die Mikro-Zustände 0 und 1 beide im Block B0. Dennoch unterscheiden sich ihre Wechselwahrscheinlichkeiten exakt:')
table([
 ['<b>Zustand (Index ab 0)</b>','<b>h</b>','<b>Wechselwahrscheinlichkeit</b>'],
 ['0','-1','7/20 - 1/10 = 1/4'],['1','+1','7/20 + 1/10 = 9/20']
],[200,54,245])
para('Die Differenz beträgt 1/5. Eine starke Reduktion zur vorgesehenen Partition ist daher unmöglich. Gleichgewichtete Mittelung über alle Mikro-Zustände jedes Blocks ergibt trotzdem die ursprüngliche Matrix Q. Dieses Verdecken tritt in allen 34 ausgewählten Fällen mit λ&gt;0 auf. Es ist eine Eigenschaft der konstruierten Kontrollfamilie, kein neu entdeckter empirischer Effekt.')
head('Eine gültige Reduktion kann den falschen Prädiktor haben')
para('In zehn Kontrollen bleibt λ=0, während p<sub>0</sub> um 1/10 erhöht wird. Die Matrizen bleiben stochastisch und stark reduzierbar. Der ursprüngliche Prädiktor weicht trotzdem um 1/10 ab. Die Prüfung erkennt diese Abweichung in allen zehn Fällen.')
head('Konstanter Wechselprädiktor')
mono('min_(0<=x<=1) max(|x-7/20|, |x-9/20|) = 1/20\nOptimum: x=2/5.   U1-Toleranz: 1/40.')
para('Wolfram berechnete Minimum und Optimierer exakt und bestätigte die untere Schranke für alle zulässigen x. Analytisch folgt sie aus der Dreiecksungleichung: Die Summe beider Abstände ist mindestens 1/10, also ihr Maximum mindestens 1/20. Das Mittel 2/5 erreicht die Schranke. Die Aussage betrifft die Wechselwahrscheinlichkeit.')
head('Fehlerhafte Eingaben und manipulierte Belege')
para('Eine falsche Zeilensumme sowie ein negativer Eintrag bei weiterhin korrekter Zeilensumme werden zurückgewiesen. Das Abgleichsprogramm wurde zusätzlich mit acht Manipulationen geprüft: fehlender Fall, doppelte Fallidentität, erfundene Reduzierbarkeit, falscher Matrix-Hash, Ganzzahl statt Boolesch, falsche Eingabebindung, NOT_EXECUTED statt bestanden und verschleierter Prognosefehler. Alle acht wurden erkannt.')
para('Die Negativkontrollen sind beabsichtigte Verletzungen. Ihr korrektes Erkennen zählt als bestandene Prüfung, nicht als Bestätigung der jeweils falschen Modellbehauptung.','SmallR')

page()
para('3. Nachvollziehbarkeit und Grenzen','TitleR')
head('Rechenwege und Originalbezug')
para('Wolfram bildet P mit normierten Blockmatrizen und Diagonalmatrizen der Wechselwahrscheinlichkeiten. Die historischen Python-Fassungen verwenden zeilenweisen Aufbau mit Fraction bzw. ganzzahligen Zähler-Nenner-Paaren. Die vollständigen 44 Matrix-Hashes stimmen mit dem historischen exact.json überein; nicht nur gerundete Kennzahlen. Eingaben, Quellcode und Antworten sind im Paket enthalten.')
para('Baseline: thomasmgfeller/x6-spectral-astrolabium<br/>Commit: a4641e00d9f699311e7105d0b5c94b7b356a5ab7<br/>Archiv: RAX_U1_Gegenpruefung_v0_1_Paket.zip','SmallR')
mono('SHA-256 des veröffentlichten U1-Archivs:\n35bf1c48f6c0874c713ccdb2155e793536a\nb6a8bd69353095e0b54f70b7d03a8')
para('Die hier umbrochene Prüfsumme ist in baseline/PROVENANCE.json vollständig maschinenlesbar enthalten. Die benötigten Baseline-Dateien wurden unverändert aus diesem Archiv übernommen. Hashes sind keine Signaturen.','SmallR')
head('Vier Wolfram-Aufrufe innerhalb des festgelegten Budgets')
para('1: Symbolischer Auftrag vollständig. 2: Gemeinsame Ausgabe der 44 Fälle bei der Übertragung nach 10.008 Zeichen gekürzt und als unvollständig verworfen. 3 und 4: Je 22 Fälle für A und B vollständig in einer kompakten, verlustfrei beschriebenen Feldstruktur übertragen. Fallauswahl und Abnahmekriterien blieben unverändert. Alle vier Antworten sind archiviert.')
para('Gemeldeter Wolfram-Kern: 15.0.1, Linux x86-64, 2. Juli 2026. Lokaler Abgleich: Python 3.12.14. Pro Aufruf waren höchstens 45 Sekunden angefordert. Zusatzbudget 0 CHF; ausschliesslich die bestehende Anbindung verwendet, keine kostenpflichtigen Dienste neu aktiviert. Eine kontospezifische Abrechnung ist nicht einsehbar.','SmallR')
head('Paket lokal prüfen')
mono('python3 -B verify_package.py\npython3 -B verify.py\npython3 -B -m unittest -v test_verify')
para('Diese Befehle prüfen gespeicherte Belege offline mit der Python-Standardbibliothek. Ein frischer Wolfram-Lauf ist davon getrennt: Die drei eigenständigen WL-Dateien und die genaue Anleitung stehen in README.md. Eine lokale wolframscript-Installation wurde hier nicht verwendet.')
head('Geltungsgrenzen')
para('Nicht geprüft: die übrigen 116 U1-Matrixfälle in Wolfram, die erneute statistische Erfassung, B1-Statistik, reale Messgeräte und allgemeine geometrische Aussagen. Der frühere Archivvorfall bleibt offen. U1: 8 gestützt / 16 verworfen / 16 unentschieden; B1: acht Hauptvergleiche unentschieden. Diese Entscheidungen werden durch W1 nicht geändert. Gemeinsame Modellannahmen können trotz verschiedener Rechenkerne gemeinsame Fehler verursachen.','SmallR')
para('Quellen: veröffentlichte U1-Dateien im Paket; Wolfram-Dokumentation zu Reduce und Resolve (reference.wolfram.com/language/ref/); Cloud-Zugang und Nutzung: wolfram.com/artificial-intelligence/mcp/cloud/. Copyright 2026 Thomas Gfeller, Apache-2.0 gemäss Paket-Lizenzumfang.','SmallR')

def footer(canvas,doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#c9d6df'));canvas.line(48,42,A4[0]-48,42)
    canvas.setFont('DV',7.5);canvas.setFillColor(colors.HexColor('#526476'))
    canvas.drawString(48,29,'RAX-W1 v0.1 | SYNTHETISCHE EXAKTE GEGENPRÜFUNG')
    canvas.drawRightString(A4[0]-48,29,f'{doc.page} / 4')
    canvas.restoreState()

output=Path(sys.argv[1]).resolve()
if output.exists(): raise FileExistsError(output)
doc=SimpleDocTemplate(str(output),pagesize=A4,rightMargin=48,leftMargin=48,
  topMargin=43,bottomMargin=55,title='RAX-W1 - Exakte Gegenprüfung der endlichen Reduktionen',author='Thomas Gfeller')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(output)
