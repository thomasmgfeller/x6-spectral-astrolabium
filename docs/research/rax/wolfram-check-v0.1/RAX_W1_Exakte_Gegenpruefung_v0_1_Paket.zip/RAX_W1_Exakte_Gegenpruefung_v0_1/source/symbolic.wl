(* RAX-W1: parameterized block-mass calculation, exact arithmetic only. *)
ClearAll[u, v, eps, x];
domain = 0 < u < 1 && 0 < v < 1 && 0 <= eps &&
  eps < u && eps < 1 - u && eps < v && eps < 1 - v;
blockRows = {{1-u+eps,u-eps},{1-u-eps,u+eps},
             {v-eps,1-v+eps},{v+eps,1-v-eps}};
lumpCondition = And @@ Join[Thread[blockRows[[1]] == blockRows[[2]]],
                            Thread[blockRows[[3]] == blockRows[[4]]]];
stochastic = (And @@ (Total[#] == 1 & /@ blockRows)) &&
             (And @@ Thread[Flatten[blockRows] >= 0]);
constant = Minimize[{Max[Abs[x-7/20],Abs[x-9/20]],0<=x<=1},x,Reals];
qstr[z_] := ToString[z,InputForm];
result = <|
 "schema"->"rax.w1.symbolic/1", "kernel_version"->$Version,
 "sha256_abc"->Hash["abc","SHA256","HexString"],
 "stochastic_on_domain"->Resolve[ForAll[{u,v,eps},Implies[domain,stochastic]],Reals],
 "lumpable_iff_epsilon_zero"->Resolve[ForAll[{u,v,eps},
   Implies[domain,Equivalent[lumpCondition,eps==0]]],Reals],
 "lumpability_reduction"->qstr[Reduce[lumpCondition,eps,Reals]],
 "diameter_equals_2_epsilon"->FullSimplify[
   Max[u-eps,u+eps]-Min[u-eps,u+eps]==2eps,Assumptions->domain],
 "prediction_loss_equals_epsilon"->FullSimplify[
   Max[Abs[eps],Abs[-eps]]==eps,Assumptions->domain],
 "balanced_average_masks_perturbation"->FullSimplify[
   (blockRows[[1]]+blockRows[[2]])/2=={1-u,u} &&
   (blockRows[[3]]+blockRows[[4]])/2=={v,1-v}],
 "constant_minimax"->qstr[constant[[1]]],
 "constant_optimizer"->qstr[x/.constant[[2]]],
 "constant_bound_for_all_predictions"->Resolve[ForAll[x,
   Implies[0<=x<=1,Max[Abs[x-7/20],Abs[x-9/20]]>=1/20]],Reals],
 "minimum_exceeds_U1_tolerance"->TrueQ[constant[[1]]>1/40],
 "scope"->"Finite block-mass family with both signs per block; no continuum or physical claim"
|>;
ExportString[result,"RawJSON","Compact"->True]
