(* Lossless field packing to stay below the connector's observed text cap. *)
caseFields={"model_id","protocol","lambda","lambda_index","stochastic","lumpable",
 "delta","prediction_loss","preparations","row_support","matrix_sha256",
 "intertwining_residual","relabeling_pass","balanced_average_equals_base_Q","power_residuals"};
shiftFields={"model_id","protocol","stochastic","lumpable","delta","prediction_loss",
 "preparations","row_support","matrix_sha256"};
pack[a_,fields_] := Lookup[a,fields]/. {
  x_Association :> Values[x]};
packed=<|"schema"->"rax.w1.finite-packed/1","kernel_version"->result["kernel_version"],
 "input_sha256"->result["input_sha256"],"sha256_abc"->result["sha256_abc"],
 "case_fields"->caseFields,"preparation_keys"->{"a0:h-1","a0:h1","a1:h-1","a1:h1"},
 "power_keys"->{"2","3"},
 "cases"->(pack[#,caseFields]& /@result["cases"]),
 "shift_fields"->shiftFields,"shift_controls"->(pack[#,shiftFields]& /@result["shift_controls"]),
 "invalid_controls"->result["invalid_controls"]|>;
ExportString[packed,"RawJSON","Compact"->True]
