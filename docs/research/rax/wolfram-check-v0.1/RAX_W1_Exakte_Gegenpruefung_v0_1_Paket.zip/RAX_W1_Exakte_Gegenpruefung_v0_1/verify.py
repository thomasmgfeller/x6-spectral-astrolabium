#!/usr/bin/env python3
"""Offline audit of Wolfram receipts against archived U1 algorithms and exact algebra.

This does not execute Wolfram. Use --wolfram-json-dir to audit fresh kernel output.
No third-party Python dependencies, network, installation, or paid API calls.
"""
import argparse
from collections import Counter
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
CASE_FIELDS = ['model_id','protocol','lambda','lambda_index','stochastic','lumpable',
 'delta','prediction_loss','preparations','row_support','matrix_sha256',
 'intertwining_residual','relabeling_pass','balanced_average_equals_base_Q','power_residuals']
SHIFT_FIELDS = ['model_id','protocol','stochastic','lumpable','delta','prediction_loss',
 'preparations','row_support','matrix_sha256']
PREP_KEYS = ['a0:h-1','a0:h1','a1:h-1','a1:h1']

def need(ok, message):
    if not ok: raise ValueError(message)

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def sha(data): return hashlib.sha256(data).hexdigest()

def distinct(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'duplicate JSON key: '+k); out[k]=v
    return out

def decode(text):
    return json.loads(text,object_pairs_hook=distinct,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))

def read(path): return decode(path.read_text())

def exact_equal(a,b,label):
    need(canonical(a)==canonical(b),label+' differs')

def unpack(obj):
    need(obj['schema']=='rax.w1.finite-packed/1','packed schema')
    exact_equal(obj['case_fields'],CASE_FIELDS,'case fields')
    exact_equal(obj['shift_fields'],SHIFT_FIELDS,'shift fields')
    exact_equal(obj['preparation_keys'],PREP_KEYS,'preparation keys')
    exact_equal(obj['power_keys'],['2','3'],'power keys')
    out={k:v for k,v in obj.items() if k not in ('case_fields','shift_fields','preparation_keys','power_keys')}
    for name,fields in [('cases',CASE_FIELDS),('shift_controls',SHIFT_FIELDS)]:
        records=[]
        for row in obj[name]:
            need(len(row)==len(fields),'packed row width')
            rec=dict(zip(fields,row))
            need(len(rec['preparations'])==4,'preparation count')
            rec['preparations']=dict(zip(PREP_KEYS,rec['preparations']))
            if 'power_residuals' in rec:
                vals=rec['power_residuals']; need(len(vals) in (0,2),'power count')
                rec['power_residuals']=dict(zip(['2','3'],vals))
            records.append(rec)
        out[name]=records
    return out

def receipt(part):
    raw=read(ROOT/f'evidence/wolfram-{part}-response.json')
    need(raw.get('isError') is False,'Wolfram error: '+part)
    texts=[c['text'] for c in raw['content'] if c['type']=='text']
    need(len(texts)==1 and texts[0].startswith('Out[1]= '),'unexpected response format')
    return decode(decode(texts[0].split('=',1)[1].strip()))

def load_wolfram(directory=None):
    get=(lambda name:read(directory/(name+'.json'))) if directory else receipt
    return get('symbolic'),[unpack(get('finite-'+family)) for family in ('A','B')]

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec); spec.loader.exec_module(obj); return obj

def mm(a,b):
    return [[sum((x*y for x,y in zip(row,col)),F(0)) for col in zip(*b)] for row in a]

def sub(a,b): return [[x-y for x,y in zip(r,s)] for r,s in zip(a,b)]
def norm(a): return max(abs(x) for row in a for x in row)
def transpose(a): return [list(x) for x in zip(*a)]
def matrix_hash(p): return sha(canonical([[str(x) for x in row] for row in p]))

def linear_properties(p,labels,h,rates):
    """Least-squares quotient C^T P C / m, exact; no stochastic assumption hidden."""
    m=labels.count(0); n=len(labels)
    c=[[F(label==b) for b in (0,1)] for label in labels]
    masses=mm(p,c)
    q_fit=[[x/m for x in row] for row in mm(transpose(c),masses)]
    q0=[[1-rates[0],rates[0]],[rates[1],1-rates[1]]]
    delta=max(abs(masses[i][b]-masses[j][b]) for i in range(n)
              for j in range(n) if labels[i]==labels[j] for b in (0,1))
    preps={}
    for a in (0,1):
        for sign in (-1,1):
            values=[masses[i][1-a] for i in range(n) if labels[i]==a and h[i]==sign]
            preps[f'a{a}:h{sign}']=str(sum(values,F(0))/len(values))
    return {'stochastic':all(sum(row,F(0))==1 and min(row)>=0 for row in p),
       'lumpable':norm(sub(masses,mm(c,q_fit)))==0,'delta':str(delta),
       'prediction_loss':str(norm(sub(masses,mm(c,q0)))),
       'preparations':preps,'row_support':sorted({sum(x!=0 for x in row) for row in p})},c,q0,q_fit

def verify(symbolic,parts):
    contract=read(ROOT/'contract.json'); freeze=read(ROOT/'evidence/contract-freeze.json')
    need(sha((ROOT/'contract.json').read_bytes())==freeze['contract_sha256'],'contract changed')
    provenance=read(ROOT/'baseline/PROVENANCE.json')
    for name,item in provenance['extracted_files'].items():
        data=(ROOT/'baseline'/name).read_bytes()
        need(len(data)==item['bytes'] and sha(data)==item['sha256'],'baseline differs: '+name)
    original=read(ROOT/'baseline/exact.json')
    baseline_contract=read(ROOT/'baseline/contract.json')
    models={m['id']:m for m in read(ROOT/'baseline/models.json')}
    prod=load_module('archived_u1',ROOT/'baseline/u1.py')
    ref=load_module('archived_reference',ROOT/'baseline/reference.py')
    expected_contract=[c for c in original['cases'] if c['model_id'].endswith(':m4') or
        (c['model_id'].endswith(':m8') and c['protocol']=='e3' and c['lambda'] in ('0','1/10'))]
    exact_equal(contract['selected_cases'],[{k:c[k] for k in ('model_id','protocol','lambda_index','lambda','matrix_sha256')} for c in expected_contract],'frozen case selection')
    expected_input={'models':[m for m in models.values() if m['id'] in {c['model_id'] for c in expected_contract}],
      'cases':[{k:c[k] for k in ('model_id','protocol','lambda_index','lambda')}|
         {'rates':baseline_contract['protocols'][c['protocol']]} for c in expected_contract]}
    exact_equal(read(ROOT/'evidence/input.json'),expected_input,'kernel input')
    actual=[]; actual_shifts=[]
    abc=hashlib.sha256(b'abc').hexdigest()
    for family,part in zip(('A','B'),parts):
        inp=read(ROOT/f'evidence/input-{family}.json')
        desired={'models':[m for m in expected_input['models'] if m['family']==family],
           'cases':[c for c in expected_input['cases'] if c['model_id'].startswith(family+':')]}
        if family=='B':desired['models'].append(models['A:m4'])
        exact_equal(inp,desired,'split input '+family)
        need(part['input_sha256']==sha((ROOT/f'evidence/input-{family}.json').read_bytes()),'kernel input digest '+family)
        need(part['sha256_abc']==abc,'SHA-256 implementation probe')
        need(len(part['cases'])==22,'incomplete family '+family)
        exact_equal(part['invalid_controls'],{'wrong_row_sum_rejected':True,
          'negative_probability_rejected':True,'negative_control_still_has_unit_row_sums':True},'invalid controls')
        actual.extend(part['cases']);actual_shifts.extend(part['shift_controls'])
    key=lambda c:(c['model_id'],c['protocol'],c['lambda_index'])
    need(len({key(c) for c in actual})==44,'duplicate or absent case')
    bykey={key(c):c for c in actual}
    need(set(bykey)=={key(c) for c in expected_contract},'case coverage')
    checked=[]; regenerated=set()
    for old in expected_contract:
        model=models[old['model_id']];m=model['m'];rates=list(map(F,baseline_contract['protocols'][old['protocol']]))
        if model['id'] not in regenerated:
            exact_equal(model,ref.regenerate_model(model['family'],m),'archived model generation')
            regenerated.add(model['id'])
        pairs=ref.operator(model,[str(x) for x in rates],old['lambda'])
        p=[[F(n,d) for n,d in row] for row in pairs]
        need(p==prod.transition(model,[str(x) for x in rates],old['lambda']),'two archived matrix constructors')
        need(matrix_hash(p)==old['matrix_sha256'],'original matrix digest')
        labels=[0]*m+[1]*m; h=model['h']
        s,c,q,q_fit=linear_properties(p,labels,h,rates)
        fields=('lumpable','delta','prediction_loss','preparations','row_support')
        old_fields={k:old[k] for k in fields}
        exact_equal({k:s[k] for k in fields},old_fields,'published summary')
        exact_equal(ref.properties(pairs,labels,h,[str(x) for x in rates]),old_fields,'archived reference summary')
        exact_equal(prod.summarize(p,labels,h,[str(x) for x in rates]),old_fields,'archived production summary')
        perm=list(range(1,2*m))+[0]
        ps=[[p[i][j] for j in perm] for i in perm]
        transported=linear_properties(ps,[labels[i] for i in perm],[h[i] for i in perm],rates)[0]
        powers={}
        if F(old['lambda'])==0:
            pp=p;qq=q
            for t in (2,3):
                pp=mm(pp,p);qq=mm(qq,q)
                powers[str(t)]=str(norm(sub(mm(pp,c),mm(c,qq))))
        expected={k:old[k] for k in ('model_id','protocol','lambda','lambda_index')}|s|{
          'matrix_sha256':matrix_hash(p),'intertwining_residual':str(norm(sub(mm(p,c),mm(c,q)))),
          'relabeling_pass':s==transported,'balanced_average_equals_base_Q':q_fit==q,
          'power_residuals':powers}
        exact_equal(bykey[key(old)],expected,'Wolfram case '+str(key(old)))
        checked.append(expected)
    shift_specs=list(dict.fromkeys((c['model_id'],c['protocol']) for c in expected_contract))
    need(len(actual_shifts)==len(shift_specs)==10,'shift count')
    shift_map={(c['model_id'],c['protocol']):c for c in actual_shifts}
    need(len(shift_map)==10,'duplicate shift')
    shifts=[]
    for modelid,protocol in shift_specs:
        model=models[modelid];m=model['m'];rates=list(map(F,baseline_contract['protocols'][protocol]))
        pairs=ref.operator(model,[str(rates[0]+F(1,10)),str(rates[1])],'0')
        p=[[F(n,d) for n,d in row] for row in pairs]
        s=linear_properties(p,[0]*m+[1]*m,model['h'],rates)[0]
        expected={'model_id':modelid,'protocol':protocol}|s|{'matrix_sha256':matrix_hash(p)}
        exact_equal(shift_map[(modelid,protocol)],expected,'shift control')
        need(s['lumpable'] and s['prediction_loss']=='1/10','shift scientific claim')
        shifts.append(expected)
    cp=prod.transition(models['A:m4'],['7/20','9/20'],'0')
    badsum=[row[:] for row in cp];badsum[0][0]+=1
    badneg=[row[:] for row in cp];badneg[0]=[F(-1),F(2)]+[F(0)]*6
    for bad in (badsum,badneg):
        need(not linear_properties(bad,[0]*4+[1]*4,models['A:m4']['h'],[F(7,20),F(9,20)])[0]['stochastic'],'local invalid control')
    need(all(sum(row)==1 for row in badneg),'negative control row sums')
    for field in ('stochastic_on_domain','lumpable_iff_epsilon_zero','diameter_equals_2_epsilon',
       'prediction_loss_equals_epsilon','balanced_average_masks_perturbation',
       'constant_bound_for_all_predictions','minimum_exceeds_U1_tolerance'):
        need(symbolic[field] is True,'symbolic check: '+field)
    need(symbolic['sha256_abc']==abc and F(symbolic['constant_minimax'])==F(1,20)
      and F(symbolic['constant_optimizer'])==F(2,5),'constant minimax')
    need(symbolic['lumpability_reduction'].replace(' ','')=='eps==0','symbolic reduction')
    return {'schema':'rax.w1.verification/1','status':'PASS_WITH_SCOPE_LIMITS',
      'external_review':False,'physical_validation':False,
      'selected_matrices':len(checked),'matrix_digest_matches':len(checked),
      'states_per_matrix':dict(Counter(str(2*models[c['model_id']]['m']) for c in checked)),
      'lumpable':sum(c['lumpable'] for c in checked),
      'not_lumpable':sum(not c['lumpable'] for c in checked),
      'relabeling_checks':sum(c['relabeling_pass'] for c in checked),
      'power_checks':sum(len(c['power_residuals']) for c in checked),
      'shift_controls':len(shifts),'invalid_matrix_controls':2,
      'positive_lambda_cases_masked_by_balanced_average':sum(not c['lumpable'] and c['balanced_average_equals_base_Q'] for c in checked),
      'symbolic_boolean_checks':7,'constant_minimax':'1/20','constant_optimizer':'2/5',
      'wolfram_versions':sorted({symbolic['kernel_version']}|{p['kernel_version'] for p in parts}),
      'local_python':platform.python_version(),'contract_sha256':freeze['contract_sha256'],
      'case_results':checked,'shift_results':shifts,
      'scope':'44/160 published exact matrices; no statistical acquisition replay; symbolic statements only for the specified finite family'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wolfram-json-dir',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=verify(*load_wolfram(args.wolfram_json_dir))
    if args.output:
        with args.output.open('x') as f: json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('case_results','shift_results')},indent=2))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps({'status':'FAIL','error':str(exc)}));sys.exit(1)
