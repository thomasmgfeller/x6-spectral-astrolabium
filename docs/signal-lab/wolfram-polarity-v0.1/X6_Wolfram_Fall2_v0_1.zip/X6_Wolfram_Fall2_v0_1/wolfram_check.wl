ClearAll["Global`*"];
n = 128; fs = 128; wp = 80; tolerance = 10^-50;
x = N[Table[Cos[2 Pi j/n], {j, 0, n - 1}], wp];
win = N[Table[(1 - Cos[2 Pi j/64])/2, {j, 0, 63}], wp];
factor = Table[If[k == 0 || k == 32, 1, 2], {k, 0, 32}]/(fs Total[win^2]);
segments[v_] := Fourier[(# - Mean[#]) win, FourierParameters -> {1, -1}] & /@ Partition[v, 64, 32];
fx = segments[x];
px = Take[Mean[Abs[#]^2 & /@ fx], 33] factor;
active = Select[Range[2, 33], px[[#]] >= Max[px]/1000 &];
num[v_] := If[v === Null, Null, N[v, 17]];
evaluate[label_, y_] := Module[{fy, py, c, mask, coh, phase, ci, pi, cw, pw, cm, pe, metrics},
 fy = segments[y];
 py = Take[Mean[Abs[#]^2 & /@ fy], 33] factor;
 c = Take[Mean[MapThread[Conjugate[#1] #2 &, {fx, fy}]], 33] factor;
 mask = MapThread[
   TrueQ[#1 > Max[px] 10^-12 && #2 > Max[py] 10^-12 &&
     #1 > Max[Max[px], Max[py]] 10^-24 &&
     #2 > Max[Max[px], Max[py]] 10^-24 && #1 #2 > 0] &, {px, py}];
 coh = Table[If[mask[[k]], Abs[c[[k]]]^2/(px[[k]] py[[k]]), Null], {k, 33}];
 phase = Table[If[mask[[k]] && TrueQ[Abs[c[[k]]] > 0], Arg[c[[k]]] 180/Pi, Null], {k, 33}];
 ci = Select[active, coh[[#]] =!= Null &];
 pi = Select[ci, TrueQ[coh[[#]] >= 4/5] && phase[[#]] =!= Null &];
 cw = Total[px[[ci]]]; pw = Total[px[[pi]]];
 cm = If[Length[ci] > 0, Total[px[[ci]] coh[[ci]]]/cw, Null];
 pe = If[Length[pi] > 0, Sqrt[Total[px[[pi]] phase[[pi]]^2]/pw], Null];
 metrics = <|"nrmse" -> Sqrt[Total[(y - x)^2]/Total[x^2]],
   "spectral_error" -> Total[Abs[py - px]]/Total[px],
   "coherence_mean" -> cm, "phase_error_deg" -> pe|>;
 <|"label" -> label, "metrics" -> metrics, "referencePSD" -> px, "outputPSD" -> py,
   "crossSpectrumReal" -> Re[c], "crossSpectrumImag" -> Im[c],
   "coherence" -> coh, "phaseDeg" -> phase,
   "activeReferenceBins" -> (active - 1), "eligibleBins" -> (Flatten[Position[mask, True]] - 1),
   "coherenceCoverage" -> cw/Total[px[[active]]], "phaseCoverage" -> pw/Total[px[[active]]]|>
];
cases = {evaluate["inverted", -x], evaluate["identity", x], evaluate["zero", ConstantArray[0, n]]};
z = a + I b;
assumptions = Element[{a, b}, Reals] && a^2 + b^2 > 0;
symbolic = <|
 "psd_ratio" -> FullSimplify[(-z) Conjugate[-z]/(z Conjugate[z]), assumptions],
 "coherence" -> FullSimplify[Abs[Conjugate[z] (-z)]^2/((z Conjugate[z]) ((-z) Conjugate[-z])), assumptions],
 "phase_deg" -> FullSimplify[180 Arg[Conjugate[z] (-z)]/Pi, assumptions],
 "nrmse" -> FullSimplify[Sqrt[4 e]/Sqrt[e], Element[e, Reals] && e > 0]|>;
expected = {{2, 0, 1, 180}, {0, 0, 1, 0}, {1, 1, Null, Null}};
checks = Flatten[Table[MapThread[
 If[#2 === Null, #1 === Null, TrueQ[Abs[#1 - #2] <= tolerance]] &,
 {Values[cases[[j]]["metrics"]], expected[[j]]}], {j, 3}]];
symbolicPass = And @@ MapThread[SameQ, {Values[symbolic], {1, 1, 180, 2}}];
detail = cases[[1]];
out = <|"schema" -> "x6.wolfram.polarity-check/1", "kernelVersion" -> $Version,
 "systemID" -> $SystemID, "workingPrecision" -> wp, "samples" -> n, "sampleRate" -> fs,
 "welchSegments" -> Length[fx], "nperseg" -> 64, "hop" -> 32,
 "symbolic" -> symbolic, "symbolicPass" -> symbolicPass,
 "metricChecks" -> checks, "allChecksPass" -> (And @@ checks && symbolicPass),
 "cases" -> Table[<|"label" -> cases[[j]]["label"],
    "metrics" -> Map[num, cases[[j]]["metrics"]],
    "activeReferenceBins" -> cases[[j]]["activeReferenceBins"],
    "eligibleBins" -> cases[[j]]["eligibleBins"],
    "coherenceCoverage" -> num[cases[[j]]["coherenceCoverage"]],
    "phaseCoverage" -> num[cases[[j]]["phaseCoverage"]]|>, {j, 3}],
 "invertedSpectrum" -> Association[Table[key -> (num /@ detail[key]),
   {key, {"referencePSD", "outputPSD", "crossSpectrumReal", "crossSpectrumImag", "coherence", "phaseDeg"}}]]|>;
ExportString[out, "RawJSON"]
