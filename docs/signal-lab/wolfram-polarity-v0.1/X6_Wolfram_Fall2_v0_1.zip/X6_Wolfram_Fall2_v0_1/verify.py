#!/usr/bin/env python3
"""Verify saved Wolfram evidence and optionally re-run pinned X6. No network."""
from pathlib import Path
import argparse, hashlib, json, math, re, subprocess
ROOT = Path(__file__).resolve().parent
KEYS = ("nrmse", "spectral_error", "coherence_mean", "phase_error_deg")
def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))
def require(ok, message):
    if not ok:
        raise AssertionError(message)
def unpack_wolfram(name):
    response = read(name)
    require(not response.get("isError", False), "Wolfram transport error")
    text = "\n".join(c["text"] for c in response["content"] if c["type"] == "text")
    encoded = re.sub(r"^Out\[\d+\]=\s*", "", text)
    body = json.loads(encoded)
    # Wolfram RawJSON emitted precision-bearing zero as 0.e-76.
    # Insert the missing decimal digit only; preserve the numerical value.
    normalized, count = re.subn(r"(\d)\.(?=[eE][+-]?\d)", r"\1.0", body)
    return json.loads(normalized), count
def check_local(local, wolfram, contract):
    cases = {c["label"]:c for c in local["cases"]}
    wc = {c["label"]:c for c in wolfram["cases"]}
    require(set(cases)==set(wc)==set(contract["expected"]), "Case coverage mismatch")
    metrics_count = 0
    for label, expected in contract["expected"].items():
        result = cases[label]["result"]
        for key in KEYS:
            e = expected[key]
            actual = result["metrics"][key]
            w = wc[label]["metrics"][key]
            if e is None:
                require(actual["value"] is None and actual["status"]=="UNDEFINED" and w is None,
                        f"{label}/{key}: undefined semantics lost")
            else:
                for value in (actual["value"],w):
                    require(isinstance(value,(int,float)) and math.isfinite(value),
                            f"{label}/{key}: non-finite")
                    require(abs(value-e)<=contract["tolerances"]["cross_engine_metrics_absolute"],
                            f"{label}/{key}: analytic expectation mismatch")
                require(abs(actual["value"]-w)<=contract["tolerances"]["cross_engine_metrics_absolute"],
                        f"{label}/{key}: cross-engine mismatch")
            metrics_count += 1
        if "x6_status" in expected:
            require(result["status"]==expected["x6_status"], f"{label}: not rejected")
        spectrum = result["spectrum"]
        require(spectrum["activeReferenceBins"]==wc[label]["activeReferenceBins"], "Active mask differs")
        eligible = [i for i,v in enumerate(spectrum["coherence"]) if v is not None]
        require(eligible==wc[label]["eligibleBins"], "Eligibility mask differs")
        require(spectrum["estimator"]["segments"]==3 and spectrum["estimator"]["nperseg"]==64, "Wrong Welch configuration")
    inv=cases["inverted"]["result"]["spectrum"]
    spectrum_max={}
    for key in ("referencePSD","outputPSD","crossSpectrumReal","crossSpectrumImag","coherence","phaseDeg"):
        a,b=inv[key],wolfram["invertedSpectrum"][key]
        require(len(a)==len(b)==33, "Spectrum length mismatch")
        errs=[]
        for x,y in zip(a,b):
            if x is None or y is None:
                require(x is None and y is None, "Spectrum null mismatch")
                continue
            require(math.isfinite(x) and math.isfinite(y), "Non-finite spectrum")
            err=abs((x-y+180)%360-180) if key=="phaseDeg" else abs(x-y)
            errs.append(err)
        limit=(contract["tolerances"]["phase_circular_difference_degrees"] if key=="phaseDeg"
               else contract["tolerances"]["cross_engine_metrics_absolute"] if key=="coherence"
               else contract["tolerances"]["cross_engine_PSD_CSD_absolute"])
        spectrum_max[key]=max(errs,default=0)
        require(spectrum_max[key]<=limit, key+" exceeds tolerance")
    return {"metric_comparisons":metrics_count, "spectrum_max_abs_differences":spectrum_max,
            "x6_case_statuses":{label:c["result"]["status"] for label,c in cases.items()}}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rerun",action="store_true",help="Also run Node.js on the pinned source; does not run Wolfram")
    args=parser.parse_args()
    contract=read("contract.json")
    for freeze in ("freeze.json","amendment_freeze.json"):
        for name,digest in read(freeze)["files"].items():
            require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest, "Frozen file changed: "+name)
    manifest=ROOT/"SHA256.json"
    if manifest.exists():
        inventory=read("SHA256.json")["files"]
        actual={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and p.name!="SHA256.json"}
        require(actual==set(inventory),"Package inventory coverage differs")
        for name,digest in inventory.items():
            require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,"Inventory mismatch: "+name)
    blob=(ROOT/"source/signal-lab-core.js").read_bytes()
    require(hashlib.sha1(b"blob "+str(len(blob)).encode()+b"\0"+blob).hexdigest()=="14990fa1dc8c4b28ff8f153e9fbec349c8af2f69",
            "Pinned Git blob changed")
    first,_=unpack_wolfram("wolfram_response_attempt1.json")
    require(first["allChecksPass"] is False and first["metricChecks"].count(False)==1
            and first["metricChecks"][9] is False,"Initial failed control was not preserved")
    w,normalizations=unpack_wolfram("wolfram_response_attempt2.json")
    require(w==read("wolfram_result.json"),"Parsed result differs from retained raw response")
    require(w["allChecksPass"] is True and w["symbolicPass"] is True
            and len(w["metricChecks"])==12 and all(v is True for v in w["metricChecks"]),
            "Wolfram did not pass every predeclared metric check")
    require(w["symbolic"]==contract["expected_symbolic"], "Symbolic result mismatch")
    saved=check_local(read("x6_result.json"),w,contract)
    result={"status":"PASS_WITH_SCOPE_LIMITS","symbolic_checks":4,"wolfram_metric_checks":12,
            "rawjson_zero_notation_normalizations":normalizations,"stored_x6":saved,
            "wolfram_reexecuted":False,"first_attempt_failure_retained":True}
    if args.rerun:
        fresh=json.loads(subprocess.check_output(["node","run_x6.cjs"],cwd=ROOT,text=True))
        result["fresh_x6"]=check_local(fresh,w,contract)
        result["fresh_node"]=fresh["node"]
    print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=="__main__":
    main()
