'use strict';
const fs = require('node:fs');
const path = require('node:path');
const core = require('./source/signal-lab-core.js');
const x = Array.from({length:128}, (_,n)=>Math.cos(2*Math.PI*n/128));
const inputs = {inverted:x.map(v=>-v), identity:x.slice(), zero:x.map(()=>0)};
const result = {schema:'x6.polarity-local-check/1', node:process.version, samples:128, sampleRate:128,
 source_commit:'90b74509f2b65de08a77de8a7057204834951fc2',
 reference:x, cases:Object.entries(inputs).map(([label,y])=>({label,candidate:y,result:core.evaluate(x,y,128)}))};
process.stdout.write(JSON.stringify(result,null,2)+'\n');
