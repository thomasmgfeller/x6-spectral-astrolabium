#!/usr/bin/env python3
"""Offline case-4 verifier. Standard library only; no network or Wolfram call."""
import hashlib
import json
import platform
import re
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

BASE = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_json(name):
    return json.loads((BASE / name).read_text(encoding="utf-8"))

def digest(name):
    return hashlib.sha256((BASE / name).read_bytes()).hexdigest()

def wolfram_decimal(value):
    match = re.fullmatch(r"([+-]?\d+(?:\.\d*)?)`80\.", value)
    require(match is not None, "Unexpected Wolfram decimal: " + value)
    return Decimal(match.group(1))

def verify():
    contract = read_json("contract.json")
    result = read_json("wolfram_result.json")
    raw = read_json("wolfram_response_final.json")
    require(not raw.get("isError", False), "Wolfram tool error")
    require(len(raw["content"]) == 1 and raw["content"][0]["type"] == "text",
            "Unexpected Wolfram response shape")
    text = raw["content"][0]["text"].strip()
    require(text.startswith("Out[1]= "), "Warning or unexpected Wolfram output")
    decoded = json.loads(json.loads(text[len("Out[1]= "):]))
    require(decoded == result, "Normalized result differs from raw response")
    first_text = "\n".join(block.get("text", "") for block in
                           read_json("wolfram_response_attempt1.json")["content"])
    require("N::meprec" in first_text, "Initial warned attempt missing")
    require(read_json("amendment.json")["initial_status"] == "INCONCLUSIVE",
            "Initial status must retain warning")

    for freeze_name in ("freeze.json", "amendment_freeze.json"):
        for name, expected_hash in read_json(freeze_name)["files"].items():
            require(digest(name) == expected_hash, "Freeze mismatch: " + name)

    manifest_path = BASE / "SHA256.json"
    manifest_checked = manifest_path.exists()
    if manifest_checked:
        manifest = read_json("SHA256.json")["files"]
        observed = {str(path.relative_to(BASE)) for path in BASE.rglob("*")
                    if path.is_file() and path.name != "SHA256.json"}
        require(observed == set(manifest), "Package inventory mismatch")
        for name, expected_hash in manifest.items():
            require(digest(name) == expected_hash, "Package hash mismatch: " + name)

    check_ids = contract["checks"]
    require(set(result["checks"]) == set(check_ids), "Check IDs differ")
    require(all(result["checks"][name] is True for name in check_ids),
            "A Wolfram assertion failed")
    require(result["allChecksPass"] is True, "Wolfram aggregate failed")
    require(result["workingPrecision"] == contract["wolfram_working_precision"] == 80,
            "Precision changed")

    alpha = Fraction(contract["alpha"])
    p0 = Fraction(contract["expected"]["coverage_test_p"])
    n = contract["independent_model"]["n"]
    require((alpha, p0, n) == (Fraction(1, 20), Fraction(1, 5), 20),
            "Reference-case parameters changed")
    require(Fraction(result["alpha_exact"]) == alpha and
            Fraction(result["p0_exact"]) == p0 and result["recorded_rows"] == n,
            "Wolfram parameters differ")
    bracket = contract["exact_bracket"]
    low = Fraction(int(bracket["lower_numerator"]), int(bracket["denominator"]))
    high = Fraction(int(bracket["upper_numerator"]), int(bracket["denominator"]))
    # Exact integer arithmetic, independent of Wolfram and decimal rounding.
    require(0 < low < high < 1, "Invalid bracket")
    require((1-low)**n > alpha > (1-high)**n, "Root bracketing failed")
    require(high-low == Fraction(1, 10**60), "Bracket width changed")
    correct_upper0 = 1-alpha
    require(high < p0 < correct_upper0, "Adversarial p not between bounds")
    iid_zero = (1-p0)**n
    clone_zero = 1-p0
    require(iid_zero < alpha < clone_zero, "Zero-event probabilities unexpected")

    events = []
    for b in (0, 1):
        probability = 1-p0 if b == 0 else p0
        # b=0 bound is proven below p0 by the exact bracket above.
        naive_covers = b == 1
        correct_upper = correct_upper0 if b == 0 else Fraction(1)
        events.append({
            "latent_failure": b,
            "recorded_failures": n*b,
            "probability_exact": str(probability),
            "naive_covers": naive_covers,
            "correct_covers": p0 <= correct_upper,
            "correct_upper_exact": str(correct_upper)
        })
    naive_coverage = sum((Fraction(e["probability_exact"]) for e in events
                          if e["naive_covers"]), Fraction(0))
    correct_coverage = sum((Fraction(e["probability_exact"]) for e in events
                            if e["correct_covers"]), Fraction(0))
    require(naive_coverage == Fraction(contract["expected"]["naive_clone_coverage"]),
            "Naive coverage differs")
    require(correct_coverage == Fraction(contract["expected"]["correct_clone_coverage"]),
            "Correct coverage differs")
    require(1-naive_coverage ==
            Fraction(contract["expected"]["naive_clone_false_exclusion"]),
            "False exclusion differs")
    require(len(result["clone_events"]) == 2, "Incomplete event enumeration")
    for local, saved in zip(events, result["clone_events"]):
        for key, value in local.items():
            require(saved[key] == value, "Event differs: " + key)
        expected_naive = result["exact"]["upper20"] if local["latent_failure"] == 0 else "1"
        require(saved["naive_upper_exact"] == expected_naive,
                "Naive event bound differs")

    rational_values = {
        "upper1": correct_upper0,
        "iid_zero_probability_at_p0": iid_zero,
        "clone_zero_probability_at_p0": clone_zero,
        "naive_coverage": naive_coverage,
        "correct_coverage": correct_coverage,
        "naive_false_exclusion": 1-naive_coverage,
    }
    require(set(result["exact"]) == {"upper20", *rational_values}, "Exact keys differ")
    for name, value in rational_values.items():
        require(Fraction(result["exact"][name]) == value, "Exact value differs: " + name)

    with localcontext() as ctx:
        ctx.prec = contract["python_decimal_precision"]
        decimal_alpha = Decimal(alpha.numerator)/Decimal(alpha.denominator)
        upper20 = Decimal(1)-(decimal_alpha.ln()/Decimal(n)).exp()
        decimal_values = {"upper20": upper20}
        decimal_values.update({
            name: Decimal(value.numerator)/Decimal(value.denominator)
            for name, value in rational_values.items()
        })
        require(Decimal(low.numerator)/Decimal(low.denominator) < upper20 <
                Decimal(high.numerator)/Decimal(high.denominator),
                "Independent decimal root outside exact bracket")
        require(set(result["decimal_input_form_80"]) == set(decimal_values),
                "Decimal keys differ")
        differences = {
            name: abs(value-wolfram_decimal(result["decimal_input_form_80"][name]))
            for name, value in decimal_values.items()
        }
        tolerance = Decimal(contract["cross_engine_absolute_tolerance"])
        require(tolerance == Decimal("1e-60"), "Tolerance changed")
        for name, difference in differences.items():
            require(difference <= tolerance, "Cross-engine mismatch: " + name)
        decimal_output = {name: str(value) for name, value in decimal_values.items()}
        differences_output = {name: str(value) for name, value in differences.items()}
        max_difference = str(max(differences.values()))

    return {
        "status": "PASS_WITH_SCOPE_LIMITS",
        "wolfram_checks_passed": len(check_ids),
        "cross_engine_quantities_passed": len(decimal_values),
        "exact_root_bracket_width": "1e-60",
        "absolute_tolerance": str(tolerance),
        "max_absolute_difference": max_difference,
        "absolute_differences": differences_output,
        "python_decimal_values": decimal_output,
        "python_clone_events": events,
        "original_attempt_status": "INCONCLUSIVE",
        "amended_wolfram_attempt_status": "PASS_NO_MESSAGES",
        "freeze_hashes_verified": True,
        "package_manifest_verified": manifest_checked,
        "python_version": platform.python_version(),
        "wolfram_kernel_reported": result["kernelVersion"],
        "wolfram_reexecuted_by_this_script": False,
        "scope": "Constructed statistical models only; no actual project dataset audited."
    }

if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, ensure_ascii=False))

