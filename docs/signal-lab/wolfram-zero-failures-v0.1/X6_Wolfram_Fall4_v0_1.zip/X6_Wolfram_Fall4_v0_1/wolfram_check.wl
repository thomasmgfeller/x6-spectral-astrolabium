ClearAll["Global`*"];
alpha = 1/20; n = 20; p0 = 1/5; wp = 80;
u20 = 1 - alpha^(1/n); u1 = 1 - alpha;
low = 139108340668265204895049462066595217417084190577582986985747/10^60;
high = 139108340668265204895049462066595217417084190577582986985748/10^60;
iidZero = FullSimplify[PDF[BinomialDistribution[n, p], 0], 0 <= p <= 1];
cloneZero = FullSimplify[Total[Table[PDF[BernoulliDistribution[p], b] Boole[n b == 0], {b, 0, 1}]], 0 <= p <= 1];
upper[nn_, kk_] := If[kk == nn, 1, If[kk == 0, 1 - alpha^(1/nn),
 InverseCDF[BetaDistribution[kk + 1, nn - kk], 1 - alpha]]];
events = Table[<|"latent_failure" -> b, "recorded_failures" -> n b,
 "probability" -> PDF[BernoulliDistribution[p0], b],
 "naive_upper" -> upper[n, n b], "correct_upper" -> upper[1, b],
 "naive_covers" -> TrueQ[p0 <= upper[n, n b]],
 "correct_covers" -> TrueQ[p0 <= upper[1, b]]|>, {b, 0, 1}];
naiveCoverage = Total[(#["probability"] Boole[#["naive_covers"]]) & /@ events];
correctCoverage = Total[(#["probability"] Boole[#["correct_covers"]]) & /@ events];
checks = <|
 "iid_zero_likelihood" -> TrueQ[FullSimplify[iidZero == (1 - p)^20, 0 <= p <= 1]],
 "clone_zero_likelihood" -> TrueQ[FullSimplify[cloneZero == 1 - p, 0 <= p <= 1]],
 "iid_bound_defining_equation" -> TrueQ[FullSimplify[(1 - u20)^20 == alpha]],
 "one_trial_upper_exact" -> SameQ[u1, 19/20],
 "beta_quantile_agrees" -> TrueQ[FullSimplify[InverseCDF[BetaDistribution[1, 20], 19/20] == u20]],
 "u20_in_rational_bracket" -> TrueQ[N[low, wp] < N[u20, wp] < N[high, wp]],
 "iid_zero_event_below_alpha_at_p0" -> TrueQ[(iidZero /. p -> p0) < alpha],
 "clone_zero_event_above_alpha_at_p0" -> TrueQ[(cloneZero /. p -> p0) > alpha],
 "naive_clone_coverage_exact" -> SameQ[naiveCoverage, 1/5],
 "correct_clone_coverage_exact" -> SameQ[correctCoverage, 1],
 "naive_false_exclusion_exact" -> SameQ[1 - naiveCoverage, 4/5],
 "p0_between_naive_and_correct_bounds" -> TrueQ[u20 < p0 < u1]|>;
exact[v_] := ToString[v, InputForm];
decimal[v_] := ToString[N[v, wp], InputForm];
quantities = <|"upper20" -> u20, "upper1" -> u1,
 "iid_zero_probability_at_p0" -> (iidZero /. p -> p0),
 "clone_zero_probability_at_p0" -> (cloneZero /. p -> p0),
 "naive_coverage" -> naiveCoverage, "correct_coverage" -> correctCoverage,
 "naive_false_exclusion" -> 1 - naiveCoverage|>;
out = <|"schema" -> "x6.wolfram.zero-failures-check/1",
 "kernelVersion" -> $Version, "systemID" -> $SystemID, "workingPrecision" -> wp,
 "alpha_exact" -> exact[alpha], "p0_exact" -> exact[p0], "recorded_rows" -> n,
 "iid_zero_likelihood" -> exact[iidZero], "clone_zero_likelihood" -> exact[cloneZero],
 "exact" -> Map[exact, quantities], "decimal_input_form_80" -> Map[decimal, quantities],
 "checks" -> checks, "allChecksPass" -> (And @@ Values[checks]),
 "clone_events" -> Table[<|"latent_failure" -> e["latent_failure"],
    "recorded_failures" -> e["recorded_failures"], "probability_exact" -> exact[e["probability"]],
    "naive_upper_exact" -> exact[e["naive_upper"]], "correct_upper_exact" -> exact[e["correct_upper"]],
    "naive_covers" -> e["naive_covers"], "correct_covers" -> e["correct_covers"]|>, {e, events}],
 "interpretation" -> "Finite statistical-model countercheck; no actual dataset audited. Confidence coverage is not a posterior probability."|>;
ExportString[out, "RawJSON"]
