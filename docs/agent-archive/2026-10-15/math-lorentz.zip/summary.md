# X6 bounded math agent: PASS

PASS describes execution/checks, not truth of hypotheses or mathematical novelty.

- lorentz_orders: LITERATURE_REPLICATION_EXACT_SMALL_ORDERS
- lorentz_propagator: FINITE_SIZE_NUMERICAL_COMPARISON
- mapping: FALSIFIED_EXACT_WITNESS
- perturbation: FALSIFIED_EXACT_WITNESS
- phase: NUMERICAL_COUNTEREXAMPLE

## Exact Lorentzian reference

| Elements | Orders | Spectral classes | With endpoint counts |
|---|---:|---:|---:|
| 3 | 5 | 4 | 5 |
| 4 | 16 | 14 | 16 |
| 5 | 63 | 53 | 63 |

## Numerical diamond comparison

Mean relative L2 error of the largest eight positive eigenvalues against the analytic spectrum; three samples per cell.

| Elements | Frozen reference | Independent comparison |
|---|---:|---:|
| 64 | 6.06% | 4.17% |
| 128 | 3.94% | 3.55% |

Small finite samples; no convergence rate or general spectral-density theorem inferred.

No physical validation or denoising superiority is claimed.
The searched families are deliberately small. See docs/MATH_AGENT.md.
