# Prüfbericht — 11. Oktober 2026

## Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| VHDL-2008 analysiert und elaboriert | bestanden mit GHDL 5.0.1 |
| VHDL-Simulation gegen Batch-Referenz | 23 Szenarien bestanden |
| Generische GHDL-Synthese des vollständigen photon_core | bestanden; Netlist in validation/generic_synthesis.log |
| Python-Kalibrierung und Exportadapter | 12 Tests bestanden |
| VHDL-Snapshots über Exportadapter zur Statistik | 22 Fälle bestanden; 7 ungültige oder leere Messungen korrekt gesperrt |

Die 23 Szenarien umfassen vier Kategorien und beide Fenstergrenzen, alle sechs
Kanalreihenfolgen bei Zeitgleichheit, fünf Fensterpaare, überlappende Trials,
Herald-Hold-off, leere Akquisition, H ausserhalb der Akquisitionszeit, mehrere
gemeinsam abgeschlossene Kontexte, Zeitstempel oberhalb 2^32, drei deterministische
Zufallsfälle, falsche Zeitreihenfolge, falsche Kalibrier-ID, Source-Error, volle
Trial- und History-Speicher, Zählersättigung und ungültige Konfiguration.

Jedes Szenario prüft ausserdem einen unveränderlichen Snapshot trotz weiterer
Eingangsaktivität sowie einen sauberen zweiten, leeren Lauf nach ACK. Dieser
zweite Lauf prüft auch das Löschen vorheriger Fehlerflags und Zähler.
Der 4-Bit-Sättigungstest prüft den parametrisierten Überlaufmechanismus;
es wurden nicht 2^64 physikalische Ereignisse erzeugt.

Bei den absichtlich fehlerhaften Erfassungs-/Pufferfällen werden die passende
Fehlermeldung und Snapshot-Eigenschaften geprüft. Ihre Teilzähler erhalten keine
wissenschaftliche Freigabe. Der Fall ungültiger Konfiguration wird nicht an die
Statistik weitergereicht; deshalb 22 statt 23 Integrationsfälle.

## Aufgetretener Werkzeugfehler

GHDL 2.0.0 bestand zunächst dieselben 23 Simulationsszenarien, brach aber bei der
Synthese intern in netlists-memories.adb ab. Das Fehlerprotokoll ist erhalten.
Mit GHDL 5.0.1 wurden Analyse, Elaboration, Simulation und Synthese erfolgreich
ausgeführt. Die GHDL-5-Bibliothek benötigt in der verwendeten lokalen Installation
den vhdl-Unterordner als Prefix; ein erster Aufruf mit falschem Prefix wurde
korrigiert. Der endgültige Versionsnachweis steht in validation/ghdl_version.txt.

## Nicht geprüft

Keine FPGA-Platine angeschlossen; kein DE10-Nano-Bitstream gebaut; keine Quartus-
Synthese, Platzierung, Ressourcenmessung, Timing Closure oder CDC-Prüfung am
Gesamtsystem. Keine echte Capture-/TDC-Kalibrierung, kein Pulsgenerator- oder
Kabelversuch, keine optische Messung, kein Einzelphotonen- oder Verschränkungsnachweis.
Die generische Synthese bestätigt Übersetzbarkeit durch diesen Synthesefrontend,
nicht die Taktfrequenz, Flächeneffizienz oder Boardtauglichkeit.

## Reproduktion

```bash
GHDL=ghdl python sim/run_tests.py
python -m unittest discover -s host -p 'test_host.py' -v
python host/run_integration.py
```

Für den letzten Befehl gelten zusätzlich die SciPy-Abhängigkeiten in
statistics_reference/requirements.txt. Der mitgelieferte frühere Statistik-
Prüfbericht mit 19 Tests ist klar von den aktuellen 12 Hosttests getrennt.
Die ursprüngliche Statistikimplementierung wurde unverändert übernommen.

Die maschinenlesbaren Ergebnisse stehen in simulation_results.json und
integration_results.json unter validation/. Sämtliche Eingaben sind synthetisch.
Der Byteinhalt der Paketdateien ist über SHA256SUMS.txt nachvollziehbar.
