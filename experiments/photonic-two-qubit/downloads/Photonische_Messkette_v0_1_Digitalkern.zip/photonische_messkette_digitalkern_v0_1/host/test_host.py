# SPDX-License-Identifier: MIT
import math
import unittest
from calibration import code_density,cable_swap
from export_snapshot import export_snapshot

class CalibrationTests(unittest.TestCase):
    def test_uniform_bins(self):
        r=code_density([100]*4,1000,'synthetic')
        self.assertEqual([b['width_ps'] for b in r['bins']],[250]*4)
        self.assertEqual([b['midpoint_ps'] for b in r['bins']],[125,375,625,875])
        self.assertFalse(r['hardware_validated'])
    def test_nonuniform_bins(self):
        r=code_density([100,200,300,400],1000,'synthetic')
        self.assertEqual([b['midpoint_ps'] for b in r['bins']],[50,200,450,800])
        self.assertAlmostEqual(sum(b['width_ps'] for b in r['bins']),1000)
    def test_missing_bin(self):
        self.assertEqual(code_density([0,100],1000,'x')['status'],'REVIEW_REQUIRED')
    def test_invalid_events(self):
        self.assertEqual(code_density([50,50],1000,'x',1)['status'],'REVIEW_REQUIRED')
    def test_bad_inputs(self):
        for c,t in (([],1000),([0,0],1000),([-1,3],1000),([1.0,2],1000),([1,2],math.nan)):
            with self.assertRaises(ValueError): code_density(c,t,'x')
    def test_cable_swap(self):
        r=cable_swap([110,120,130],[-90,-80,-70])
        self.assertEqual(r['differential_cable_delay_ps'],100)
        self.assertEqual(r['channel_offset_ps'],20)
        self.assertFalse(r['reference_uncertainty_included'])

class ExportTests(unittest.TestCase):
    def setUp(self):
        self.s={'transport_verified':True,'ready':True,'snapshot_id_before':'1','snapshot_id_after':'1',
                'counters':['0']*24,'start_ps':'1000000','stop_ps':'2000000','flags':0,'pending':'0',
                'data_kind':'synthetic','run_id':'test','firmware_id':'sim','config_id':'test',
                'calibration_id':'7','protocol_id':'test','prespecified_analysis':True}
    def test_category_mapping(self):
        self.s['counters'][:4]=['1','2','3','4']
        self.assertEqual(export_snapshot(self.s)['counts']['n10'],'3')
        self.assertEqual(export_snapshot(self.s)['counts']['n01'],'2')
    def test_mixed_snapshot(self):
        self.s['snapshot_id_after']='2'
        with self.assertRaises(ValueError): export_snapshot(self.s)
    def test_unverified_transport(self):
        self.s['transport_verified']=False
        with self.assertRaises(ValueError): export_snapshot(self.s)
    def test_overflow_propagates(self):
        self.s['flags']=1
        self.assertTrue(export_snapshot(self.s)['flags']['counter_overflow'])
    def test_uint64_exact(self):
        self.s['counters'][0]=str(2**64-1)
        self.assertEqual(export_snapshot(self.s)['counts']['n00'],str(2**64-1))
    def test_nonintegral_ns_rejected(self):
        self.s['stop_ps']='2000001'
        with self.assertRaises(ValueError): export_snapshot(self.s)

if __name__=='__main__': unittest.main(verbosity=2)
