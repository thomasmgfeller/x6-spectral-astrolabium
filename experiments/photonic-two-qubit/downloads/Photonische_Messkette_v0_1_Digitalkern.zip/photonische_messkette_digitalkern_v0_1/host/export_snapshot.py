#!/usr/bin/env python3
"""Translate an already verified shadow snapshot into the v0.1 statistics format.

This is an adapter, not a USB driver or a CRC implementation.
"""
# SPDX-License-Identifier: MIT
import argparse
import json
from pathlib import Path

def export_snapshot(s):
    if s.get('transport_verified') is not True or s.get('ready') is not True:
        raise ValueError('require verified complete transport frame and READY snapshot')
    if s['snapshot_id_before']!=s['snapshot_id_after']:
        raise ValueError('snapshot changed during readout')
    counts=s['counters']
    if len(counts)!=24: raise ValueError('expected 24 counters')
    def parse(value):
        if not isinstance(value,str) or not value.isascii() or not value.isdecimal():
            raise ValueError('counters and timestamps must be decimal strings')
        v=int(value)
        if not 0<=v<2**64: raise ValueError('value outside uint64 range')
        return v
    c=list(map(parse,counts)); start,stop=map(parse,(s['start_ps'],s['stop_ps']))
    if stop<=start or (stop-start)%1000: raise ValueError('v0.1 duration must be positive integer nanoseconds')
    flags=s['flags']
    if type(flags) is not int or not 0<=flags<2**32: raise ValueError('invalid flags')
    if flags & ~31: raise ValueError('unknown firmware flags')
    for key in ('snapshot_id_before','snapshot_id_after','pending'):
        parse(s[key])
    duration=str((stop-start)//1000)
    return {
      'schema':'photon-chain.raw.v0.1','data_kind':s['data_kind'],'run_id':s['run_id'],
      'firmware_id':s['firmware_id'],'config_id':s['config_id'],'calibration_id':s['calibration_id'],
      'protocol_id':s['protocol_id'],'counting_rule':'one-category-per-accepted-herald.v1',
      'stopping_rule':'prespecified-fixed-duration','prespecified_analysis':s['prespecified_analysis'],
      'snapshot':{'sequence_before':s['snapshot_id_before'],'sequence_after':s['snapshot_id_after']},
      'exposure':{'planned_ns':duration,'observed_ns':duration},
      # Hardware uses binary AB order: 00,01,10,11.
      'counts':{'n00':str(c[0]),'n10':str(c[2]),'n01':str(c[1]),'n11':str(c[3]),
                'h_raw':str(c[20]),'h_accepted':str(c[21]),'h_rejected_policy':str(c[22]),
                'h_pending':s['pending']},
      'flags':{'atomic_snapshot':True,'acquisition_complete':True,
               'counter_overflow':bool(flags&1),'event_loss':bool(flags&4) or c[23]>0,
               'capture_error':bool(flags&(2|16)),'config_changed':bool(flags&8)},
      'diagnostics':{'side_window_counts':counts[4:20],'capacity_rejections':str(c[23]),
                     'note':'Diagnostics are correlated; no iid test or background subtraction applied.'}}

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('input',type=Path)
    p.add_argument('--output',type=Path,required=True); args=p.parse_args()
    if args.input.resolve()==args.output.resolve(): raise ValueError('do not overwrite input')
    out=export_snapshot(json.loads(args.input.read_text()))
    args.output.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__': main()
