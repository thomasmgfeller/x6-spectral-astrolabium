#!/usr/bin/env python3
"""Code-density LUT and cable-swap estimates; not a hardware calibration claim."""
# SPDX-License-Identifier: MIT
import argparse
import json
import math
import statistics
from pathlib import Path

def code_density(counts, period_ps, calibration_id, invalid_events=0):
    if not counts or any(type(n) is not int or n<0 for n in counts):
        raise ValueError('counts must be nonnegative integers in ordered fine-time bins')
    if not math.isfinite(period_ps) or period_ps<=0 or sum(counts)==0:
        raise ValueError('positive period and nonempty sample required')
    if type(invalid_events) is not int or invalid_events<0:
        raise ValueError('invalid_events must be a nonnegative integer')
    n=sum(counts); m=len(counts); edge=0.0; bins=[]
    for i,k in enumerate(counts):
        p=k/n; width=period_ps*p
        bins.append({'bin':i,'count':str(k),'width_ps':width,'midpoint_ps':edge+width/2,
                     'sampling_se_ps':period_ps*math.sqrt(p*(1-p)/n),
                     'dnl_lsb':width/(period_ps/m)-1,
                     'inl_left_lsb':edge/(period_ps/m)-i})
        edge+=width
    issues=[]
    if invalid_events: issues.append('INVALID_CODES_PRESENT: selection bias not excluded')
    if any(k==0 for k in counts): issues.append('ZERO_BIN: insufficient sample or missing code')
    return {'schema':'photon-chain.calibration.v0.1','calibration_id':calibration_id,
            'hardware_validated':False,'status':'REVIEW_REQUIRED' if issues else 'CANDIDATE_ONLY',
            'period_ps':period_ps,'total_valid_events':str(n),'invalid_events':str(invalid_events),
            'issues':issues,'bins':bins,
            'assumptions':['Uniform phase density across exactly one clock period.',
                           'Bin order fixed by a validated decoder; no unmodelled selection.',
                           'SE excludes clock uncertainty, phase nonuniformity, drift and correlations.']}

def cable_swap(delta1_ps, delta2_ps):
    if len(delta1_ps)<2 or len(delta2_ps)<2:
        raise ValueError('at least two samples per cable arrangement')
    if any(not math.isfinite(x) for x in [*delta1_ps,*delta2_ps]):
        raise ValueError('finite delays required')
    mean1,mean2=statistics.mean(delta1_ps),statistics.mean(delta2_ps)
    sd1,sd2=statistics.stdev(delta1_ps),statistics.stdev(delta2_ps)
    se=0.5*math.sqrt(sd1**2/len(delta1_ps)+sd2**2/len(delta2_ps))
    return {'differential_cable_delay_ps':(mean1-mean2)/2,
            'channel_offset_ps':(mean1+mean2)/2,
            'sampling_se_of_each_estimate_ps':se,
            'pair_jitter_sd_arrangement1_ps':sd1,'pair_jitter_sd_arrangement2_ps':sd2,
            'reference_uncertainty_included':False,
            'note':'SE assumes independent samples and arrangements. No single-channel jitter inferred.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path); parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.input.resolve()==args.output.resolve(): raise ValueError('do not overwrite raw calibration data')
    r=json.loads(args.input.read_text())
    output=code_density(r['counts'],r['period_ps'],r['calibration_id'],r.get('invalid_events',0))
    if 'delta1_ps' in r: output['cable_swap']=cable_swap(r['delta1_ps'],r['delta2_ps'])
    args.output.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')

if __name__=='__main__': main()
