#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Check simulated VHDL snapshots through the existing statistical reference."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'statistics_reference'))
from export_snapshot import export_snapshot
from calibration import code_density,cable_swap
from photon_stats import analyze,InvalidRecord

def main():
    validation=ROOT/'validation'
    meta=json.loads((validation/'simulation_results.json').read_text())
    examples=ROOT/'examples'; examples.mkdir(exist_ok=True)
    rtl_hash=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((ROOT/'rtl').glob('*.vhd')))).hexdigest()
    results=[]
    for case in meta['cases']:
        if case['name']=='invalid_configuration': continue
        snap={'transport_verified':True,'ready':True,'snapshot_id_before':'1','snapshot_id_after':'1',
          'counters':list(map(str,case['observed_counts'])),'start_ps':str(case['start']),
          'stop_ps':str(case['stop']),'flags':case['flags'],'pending':'0','data_kind':'synthetic',
          'run_id':case['name'],'firmware_id':'ghdl-rtl-sha256:'+rtl_hash,
          'config_id':'reference-default-with-case-generics','calibration_id':'00000007',
          'protocol_id':'simulation-only.v0.1','prespecified_analysis':True}
        raw=export_snapshot(snap)
        expected_invalid=bool(case['flags']) or case['observed_counts'][21]==0
        try:
            result=analyze(raw)
            if expected_invalid: raise AssertionError('invalid or empty run not rejected')
        except InvalidRecord as exc:
            if not expected_invalid: raise
            result={'status':'INVALID_INPUT','error':str(exc),'physical_quantum_claim':'NOT_ASSESSED'}
        results.append({'case':case['name'],'status':result['status'],'expected_invalid':expected_invalid})
        if case['name']=='categories_and_boundaries':
            for name,obj in [('snapshot_simulated',snap),('raw_simulated',raw),('statistics_simulated',result)]:
                (examples/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
    cal={'data_kind':'synthetic','calibration_id':'SYNTHETIC_ONLY','period_ps':10000,
         'counts':[1000,1500,2000,2500,3000],'invalid_events':0,
         'delta1_ps':[5100,5110,5090,5105,5095],'delta2_ps':[-4900,-4910,-4890,-4905,-4895]}
    (examples/'calibration_synthetic.json').write_text(json.dumps(cal,indent=2)+'\n')
    output=code_density(cal['counts'],cal['period_ps'],cal['calibration_id'])
    output['cable_swap']=cable_swap(cal['delta1_ps'],cal['delta2_ps'])
    (examples/'calibration_candidate.json').write_text(json.dumps(output,indent=2)+'\n')
    (validation/'integration_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'integration_cases':len(results),
       'invalid_or_empty_rejected':sum(x['expected_invalid'] for x in results),'status':'PASS'}))

if __name__=='__main__': main()
