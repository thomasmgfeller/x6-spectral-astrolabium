-- SPDX-License-Identifier: MIT
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use work.photon_pkg.all;
entity tb_photon_core is
  generic (STIMULUS : string := "case.stim"; EXPECTED : string := "case.expected";
    CHECK_COUNTS : boolean := true; TRIAL_DEPTH : positive := 8;
    HISTORY_DEPTH : positive := 64; COUNTER_WIDTH : positive := 64;
    HOLD_OFF_PS : natural := 100000);
end;
architecture test of tb_photon_core is
  signal clk : std_logic := '0';
  signal reset,start,in_valid,in_ready,source_error,ack,busy,ready : std_logic := '0';
  signal cfg_start,cfg_stop,ts : u64 := (others=>'0');
  signal cal,item_cal,data : word32 := (others=>'0');
  signal kind : unsigned(1 downto 0) := KIND_H;
  signal addr : unsigned(11 downto 0) := (others=>'0');
begin
  clk<=not clk after 5 ns;
  dut: entity work.photon_core
    generic map(TRIAL_DEPTH=>TRIAL_DEPTH,HISTORY_DEPTH=>HISTORY_DEPTH,
      COUNTER_WIDTH=>COUNTER_WIDTH,HOLD_OFF_PS=>HOLD_OFF_PS)
    port map(clk=>clk,reset=>reset,start=>start,cfg_start_ps=>cfg_start,
      cfg_stop_ps=>cfg_stop,cfg_calibration_id=>cal,in_valid=>in_valid,
      in_ready=>in_ready,in_kind=>kind,in_time_ps=>ts,in_calibration_id=>item_cal,
      source_error=>source_error,snapshot_ack=>ack,busy=>busy,snapshot_ready=>ready,
      read_address=>addr,read_data=>data);
  process
    file input_file,expected_file : text;
    variable l : line;
    variable start_v,stop_v,stamp_v,expected_count,actual_count : std_logic_vector(63 downto 0);
    variable cal_v,expected_flags,low_word : word32;
    variable code : integer;
    variable frozen : u64_array(0 to N_COUNTERS-1);
    procedure tick is
    begin wait until rising_edge(clk); wait for 1 ns; end;
    procedure read_word(a : natural; variable r : out word32) is
    begin addr<=to_unsigned(a,12); wait for 1 ns; r:=data; end;
    procedure read_counter(i : natural; variable r : out std_logic_vector(63 downto 0)) is
      variable lo,hi : word32;
    begin read_word(16#100#+8*i,lo); read_word(16#104#+8*i,hi); r:=hi&lo; end;
    procedure send_event(k : integer; t : std_logic_vector(63 downto 0); c : word32) is
      variable loops : natural:=0;
    begin
      while in_ready/='1' loop
        tick; loops:=loops+1; assert loops<100 report "input timeout" severity failure;
      end loop;
      kind<=to_unsigned(k,2); ts<=unsigned(t); item_cal<=c; in_valid<='1';
      tick; in_valid<='0';
    end;
    procedure await_snapshot is
      variable loops : natural:=0;
    begin
      while ready/='1' loop
        tick; loops:=loops+1; assert loops<1000 report "snapshot timeout" severity failure;
      end loop;
    end;
  begin
    reset<='1'; tick; tick; reset<='0'; tick;
    file_open(input_file,STIMULUS,read_mode);
    readline(input_file,l); hread(l,start_v); hread(l,stop_v); hread(l,cal_v);
    cfg_start<=unsigned(start_v); cfg_stop<=unsigned(stop_v); cal<=cal_v;
    start<='1'; tick; start<='0';
    while not endfile(input_file) loop
      readline(input_file,l); read(l,code);
      if code=4 then source_error<='1'; tick; source_error<='0';
      else hread(l,stamp_v); hread(l,cal_v); send_event(code,stamp_v,cal_v); end if;
    end loop;
    file_close(input_file); await_snapshot;
    file_open(expected_file,EXPECTED,read_mode);
    readline(expected_file,l); hread(l,expected_flags);
    read_word(16#00C#,low_word);
    assert low_word=expected_flags report "unexpected flags " & to_hstring(low_word) severity failure;
    read_word(16#010#,low_word); assert low_word=x"00000001" severity failure;
    read_word(16#030#,low_word); assert low_word=x"00000000" report "pending trials" severity failure;
    for i in 0 to N_COUNTERS-1 loop
      readline(expected_file,l); hread(l,expected_count); read_counter(i,actual_count);
      frozen(i):=unsigned(actual_count);
      if CHECK_COUNTS then
        assert actual_count=expected_count report "counter " & integer'image(i) &
          " got " & to_hstring(actual_count) & " expected " & to_hstring(expected_count) severity failure;
      end if;
      report "COUNTER " & integer'image(i) & " " & to_hstring(actual_count);
    end loop;
    file_close(expected_file);
    start<='1'; in_valid<='1'; source_error<='1'; cfg_stop<=U64_MAX;
    for j in 1 to 3 loop tick; end loop;
    assert ready='1' and in_ready='0' severity failure;
    for i in 0 to N_COUNTERS-1 loop
      read_counter(i,actual_count);
      assert unsigned(actual_count)=frozen(i) report "snapshot changed" severity failure;
    end loop;
    read_word(16#00C#,low_word); assert low_word=expected_flags severity failure;
    start<='0'; in_valid<='0'; source_error<='0'; ack<='1'; tick; ack<='0'; tick;
    assert ready='0' and busy='0' severity failure;
    -- Clean empty second run detects stale flags/counts, including after overflow.
    cfg_start<=to_unsigned(1000000,64); cfg_stop<=to_unsigned(2000000,64); cal<=x"00000007";
    start<='1'; tick; start<='0';
    send_event(3,std_logic_vector(to_unsigned(2201000,64)),x"00000007"); await_snapshot;
    read_word(16#00C#,low_word); assert low_word=x"00000000" report "stale error" severity failure;
    read_word(16#010#,low_word); assert low_word=x"00000002" report "snapshot sequence" severity failure;
    for i in 0 to N_COUNTERS-1 loop
      read_counter(i,actual_count); assert unsigned(actual_count)=0 report "stale count" severity failure;
    end loop;
    report "PASS: " & STIMULUS severity note;
    std.env.stop; wait;
  end process;
end architecture;
