#!/usr/bin/env python3
"""Generate independent batch-oracle vectors and simulate the actual VHDL."""
# SPDX-License-Identifier: MIT
import json
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'
LOGS=ROOT/'validation'
OFFSETS=(0,-200000,-100000,100000,200000)

def oracle(events,start,stop,holdoff=100000):
    """Batch query over complete time lists, independent of RTL storage/pipeline."""
    hs=[t for k,t,c in events if k==0 and start<=t<stop]
    accepted=[]
    for t in hs:
        if not accepted or t-accepted[-1]>=holdoff: accepted.append(t)
    aa=[t for k,t,c in events if k==1]
    bb=[t for k,t,c in events if k==2]
    counts=[0]*24
    for h in accepted:
        for w,offset in enumerate(OFFSETS):
            a=any(h+offset-1000<=t<h+offset+1000 for t in aa)
            b=any(h+offset-1000<=t<h+offset+1000 for t in bb)
            counts[4*w+2*int(a)+int(b)]+=1
    counts[20:24]=[len(hs),len(accepted),len(hs)-len(accepted),0]
    return counts

def generate():
    cases=[]
    def add(name,events,start=1000000,stop=10000000,flags=0,check=True,**generics):
        events=list(events)
        events.append((3,stop+201000,7))
        expected=oracle(events,start,stop,generics.get('HOLD_OFF_PS',100000)) if check else [0]*24
        width=generics.get('COUNTER_WIDTH',64)
        expected=[min(x,(1<<width)-1) for x in expected]
        cases.append(dict(name=name,events=events,start=start,stop=stop,flags=flags,
                          check=check,generics=generics,expected=expected))
    e=[]
    for h,kinds in [(1000000,[(1,-1000),(2,1000)]),(2000000,[(2,-1000),(1,1000)]),
                    (3000000,[(1,-900),(2,900)]),(4000000,[])]:
        e.append((0,h,7)); e.extend((k,h+d,7) for k,d in kinds)
    add('categories_and_boundaries',sorted(e,key=lambda x:x[1]))
    import itertools
    for order in itertools.permutations((0,1,2)):
        add('tie_'+''.join(map(str,order)),[(k,1000000,7) for k in order])
    e=[(0,1000000+i*100000,7) for i in range(5)]
    e += [(1,799000,7),(2,801000,7),(1,900000,7),(2,1100000,7),(1,1200000,7),
          (2,1400999,7),(1,1601000,7)]
    add('overlapping_trials_and_side_windows',sorted(e,key=lambda x:x[1]))
    add('herald_holdoff',[(0,1000000,7),(0,1099999,7),(0,1100000,7),(0,1100000,7)])
    add('empty',[])
    add('outside_acquisition',[(0,999999,7),(0,1000000,7),(0,9999999,7),(0,10000000,7)])
    add('multiple_contexts_close_together',[(0,1000000,7),(0,1100000,7),(0,1200000,7)])
    base=1<<40
    add('large_timestamp',[(1,base+999100,7),(0,base+1000000,7),(2,base+1000900,7)],
        start=base+1000000,stop=base+10000000)
    rng=random.Random(104729)
    for seed in range(3):
        e=[(0,1000000+i*175123,7) for i in range(40)]
        e += [(rng.choice((1,2)),rng.randrange(799000,8500000),7) for _ in range(300)]
        # Insert deliberate near-herald hits, not only uniformly sparse noise.
        e += [(rng.choice((1,2)),1000000+i*175123+rng.randrange(-1001,1002),7) for i in range(40)]
        add(f'random_{seed}',sorted(e,key=lambda x:x[1]))
    add('out_of_order',[(0,1000000,7),(1,999999,7)],flags=2,check=False)
    add('wrong_calibration',[(0,1000000,8)],flags=8,check=False)
    add('source_error',[(4,0,7),(0,1000000,7)],flags=4,check=False)
    add('trial_capacity',[(0,1000000,7),(0,1100000,7)],flags=4,check=False,TRIAL_DEPTH=1)
    add('history_capacity',[(1,999001,7),(1,999002,7),(2,999003,7),(0,1000000,7)],
        flags=4,check=False,HISTORY_DEPTH=2)
    add('counter_saturation',[(0,1000000+i*300000,7) for i in range(20)],
        flags=1,COUNTER_WIDTH=4)
    add('invalid_configuration',[],start=1000000,stop=1000000,flags=16,check=False)
    cases[-1]['events']=[]
    return cases

def run():
    ghdl=os.environ.get('GHDL') or shutil.which('ghdl')
    if not ghdl: raise SystemExit('GHDL not found; set GHDL to executable path')
    BUILD.mkdir(exist_ok=True); LOGS.mkdir(exist_ok=True)
    version=subprocess.run([ghdl,'--version'],check=True,capture_output=True,text=True).stdout
    (LOGS/'ghdl_version.txt').write_text(version)
    commands=[]
    def command(args,name):
        p=subprocess.run([ghdl,*args],cwd=BUILD,capture_output=True,text=True,timeout=60)
        (LOGS/(name+'.log')).write_text(p.stdout+p.stderr)
        commands.append({'name':name,'arguments':args,'returncode':p.returncode})
        if p.returncode: raise RuntimeError(name+' failed:\n'+p.stdout+p.stderr)
        return p.stdout+p.stderr
    command(['-a','--std=08',*[str(ROOT/p) for p in ('rtl/photon_pkg.vhd','rtl/saturating_counter.vhd',
      'rtl/photon_core.vhd','sim/tb_photon_core.vhd')]],'analyze')
    command(['-e','--std=08','tb_photon_core'],'elaborate')
    cases=generate()
    for c in cases:
        stim=BUILD/(c['name']+'.stim'); expected=BUILD/(c['name']+'.expected')
        stim.write_text(f"{c['start']:016X} {c['stop']:016X} 00000007\n"+''.join(
            '4\n' if k==4 else f'{k} {t:016X} {cal:08X}\n' for k,t,cal in c['events']))
        expected.write_text(f"{c['flags']:08X}\n"+''.join(f'{v:016X}\n' for v in c['expected']))
        args=['-r','--std=08','tb_photon_core',f'-gSTIMULUS={stim}',f'-gEXPECTED={expected}',
              f"-gCHECK_COUNTS={str(c['check']).lower()}"]
        args += [f'-g{k}={v}' for k,v in c['generics'].items()]
        args += ['--assert-level=error','--stop-time=2ms']
        log=command(args,c['name'])
        if 'PASS:' not in log: raise RuntimeError('No completion marker: '+c['name'])
        observed=[None]*24
        for index,value in re.findall(r'COUNTER (\d+) ([0-9A-F]+)',log): observed[int(index)]=int(value,16)
        c['observed_counts']=observed
        print('PASS',c['name'],flush=True)
    (LOGS/'simulation_results.json').write_text(json.dumps({'hardware_tested':False,
        'cases':cases,'commands':commands},indent=2)+'\n')
    # Front-end synthesis check only; no technology mapping or timing guarantee.
    netlist=command(['--synth','--std=08','photon_core'],'generic_synthesis')
    (LOGS/'simulation_results.json').write_text(json.dumps({'hardware_tested':False,
        'synthesis_status':'PASS','cases':cases,'commands':commands},indent=2)+'\n')
    print(f'{len(cases)} scenarios PASS; generic synthesis PASS')

if __name__=='__main__': run()
