-- SPDX-License-Identifier: MIT
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity saturating_counter is
  generic (WIDTH : positive := 64);
  port (clk, reset, clear, increment : in std_logic;
        value : out unsigned(WIDTH-1 downto 0);
        overflow : out std_logic);
end entity;

architecture rtl of saturating_counter is
  signal q : unsigned(WIDTH-1 downto 0) := (others=>'0');
  signal ov : std_logic := '0';
begin
  value <= q;
  overflow <= ov;
  process(clk)
  begin
    if rising_edge(clk) then
      if reset='1' or clear='1' then
        q <= (others=>'0'); ov<='0';
      elsif increment='1' then
        if q=(q'range=>'1') then ov<='1'; else q<=q+1; end if;
      end if;
    end if;
  end process;
end architecture;
