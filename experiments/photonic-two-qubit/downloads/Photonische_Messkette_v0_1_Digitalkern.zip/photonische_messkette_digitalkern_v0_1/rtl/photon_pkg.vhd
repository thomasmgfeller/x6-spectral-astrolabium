-- SPDX-License-Identifier: MIT
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package photon_pkg is
  subtype u64 is unsigned(63 downto 0);
  subtype word32 is std_logic_vector(31 downto 0);
  type u64_array is array(natural range <>) of u64;
  type integer_array is array(natural range <>) of integer;
  constant N_WINDOWS : positive := 5;
  constant N_COUNTERS : positive := 24;
  -- Main, -200 ns, -100 ns, +100 ns, +200 ns; time unit 1 ps.
  constant WINDOW_OFFSETS : integer_array(0 to 4) := (0,-200000,-100000,100000,200000);
  constant KIND_H : unsigned(1 downto 0) := "00";
  constant KIND_A : unsigned(1 downto 0) := "01";
  constant KIND_B : unsigned(1 downto 0) := "10";
  constant KIND_WATERMARK : unsigned(1 downto 0) := "11";
  constant U64_MAX : u64 := (others=>'1');
  function hit_in_window(e, h : u64; lo, hi : integer) return boolean;
  function maximum(a,b : integer) return integer;
  function minimum(a,b : integer) return integer;
end package;

package body photon_pkg is
  function hit_in_window(e, h : u64; lo, hi : integer) return boolean is
    variable d : signed(64 downto 0);
  begin
    d := signed('0' & e)-signed('0' & h);
    return d >= to_signed(lo,65) and d < to_signed(hi,65);
  end;
  function maximum(a,b : integer) return integer is
  begin if a>b then return a; else return b; end if; end;
  function minimum(a,b : integer) return integer is
  begin if a<b then return a; else return b; end if; end;
end package body;
