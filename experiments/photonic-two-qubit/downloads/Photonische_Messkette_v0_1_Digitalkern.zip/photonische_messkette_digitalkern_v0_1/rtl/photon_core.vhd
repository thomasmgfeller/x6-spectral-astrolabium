-- SPDX-License-Identifier: MIT
-- Synchronous event-domain reference core. No detector pulse capture or TDC.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.photon_pkg.all;

entity photon_core is
  generic (
    TRIAL_DEPTH : positive := 8;
    HISTORY_DEPTH : positive := 64;
    A_LO_PS : integer := -1000; A_HI_PS : integer := 1000;
    B_LO_PS : integer := -1000; B_HI_PS : integer := 1000;
    HOLD_OFF_PS : natural := 100000;
    COUNTER_WIDTH : positive := 64
  );
  port (
    clk, reset : in std_logic;
    start : in std_logic;
    cfg_start_ps, cfg_stop_ps : in u64;
    cfg_calibration_id : in word32;
    in_valid : in std_logic;
    in_ready : out std_logic;
    in_kind : in unsigned(1 downto 0);
    in_time_ps : in u64;
    in_calibration_id : in word32;
    source_error : in std_logic;
    snapshot_ack : in std_logic;
    busy, snapshot_ready : out std_logic;
    read_address : in unsigned(11 downto 0);
    read_data : out word32
  );
end entity;

architecture rtl of photon_core is
  constant LOOKBACK : natural := maximum(0,200000-minimum(A_LO_PS,B_LO_PS));
  constant LOOKAHEAD : natural := maximum(0,200000+maximum(A_HI_PS,B_HI_PS));
  type state_t is (IDLE, INITIALIZE, GET_ITEM, CLOSE_TRIALS, APPLY_ITEM, PUBLISH, READY);
  signal state : state_t := IDLE;
  type hit_row is array(0 to N_WINDOWS-1) of std_logic;
  type hit_matrix is array(0 to TRIAL_DEPTH-1) of hit_row;
  signal trial_valid : std_logic_vector(0 to TRIAL_DEPTH-1) := (others=>'0');
  signal trial_time : u64_array(0 to TRIAL_DEPTH-1);
  signal a_hits,b_hits : hit_matrix;
  signal hist_valid : std_logic_vector(0 to HISTORY_DEPTH-1) := (others=>'0');
  signal hist_time : u64_array(0 to HISTORY_DEPTH-1);
  signal hist_is_a : std_logic_vector(0 to HISTORY_DEPTH-1);
  signal scan : natural range 0 to TRIAL_DEPTH-1 := 0;
  signal item_time,last_time,run_start,run_stop,last_h : u64 := (others=>'0');
  signal item_kind : unsigned(1 downto 0) := KIND_WATERMARK;
  signal cal_id : word32 := (others=>'0');
  signal have_h : std_logic := '0';
  signal bad_config : std_logic := '0';
  signal pending : natural range 0 to TRIAL_DEPTH := 0;
  signal flags : word32 := (others=>'0');
  signal increments,overflows : std_logic_vector(0 to N_COUNTERS-1) := (others=>'0');
  signal clear_counts : std_logic := '0';
  signal counts,shadow : u64_array(0 to N_COUNTERS-1);
  signal snapshot_id : u64 := (others=>'0');
  signal shadow_flags,shadow_cal : word32 := (others=>'0');
  signal shadow_start,shadow_stop : u64 := (others=>'0');
  signal shadow_pending : u64 := (others=>'0');
begin
  assert COUNTER_WIDTH<=64 report "COUNTER_WIDTH > 64" severity failure;
  assert A_LO_PS<A_HI_PS and B_LO_PS<B_HI_PS report "empty window" severity failure;
  in_ready <= '1' when state=GET_ITEM else '0';
  snapshot_ready <= '1' when state=READY else '0';
  busy <= '0' when state=IDLE or state=READY else '1';

  gen_counters: for i in 0 to N_COUNTERS-1 generate
    signal small_count : unsigned(COUNTER_WIDTH-1 downto 0);
  begin
    c: entity work.saturating_counter
      generic map(WIDTH=>COUNTER_WIDTH)
      port map(clk=>clk,reset=>reset,clear=>clear_counts,
               increment=>increments(i),value=>small_count,overflow=>overflows(i));
    counts(i)<=resize(small_count,64);
  end generate;

  -- All run data below are in the core clock domain. The host adapter must
  -- provide its own CDC and transport framing; read_data is combinational.
  process(all)
    variable addr,idx,half : natural;
  begin
    addr:=to_integer(read_address); read_data<=(others=>'0');
    case addr is
      when 16#000# => read_data<=x"50484F54"; -- PHOT
      when 16#004# => read_data<=x"00010000";
      when 16#008# =>
        if state=READY then read_data(0)<='1'; end if;
        if state/=IDLE and state/=READY then read_data(1)<='1'; end if;
      when 16#00C# => read_data<=shadow_flags;
      when 16#010# => read_data<=std_logic_vector(snapshot_id(31 downto 0));
      when 16#014# => read_data<=std_logic_vector(snapshot_id(63 downto 32));
      when 16#018# => read_data<=shadow_cal;
      when 16#020# => read_data<=std_logic_vector(shadow_start(31 downto 0));
      when 16#024# => read_data<=std_logic_vector(shadow_start(63 downto 32));
      when 16#028# => read_data<=std_logic_vector(shadow_stop(31 downto 0));
      when 16#02C# => read_data<=std_logic_vector(shadow_stop(63 downto 32));
      when 16#030# => read_data<=std_logic_vector(shadow_pending(31 downto 0));
      when 16#034# => read_data<=std_logic_vector(shadow_pending(63 downto 32));
      when 16#038# => read_data<=std_logic_vector(to_unsigned(LOOKBACK,32));
      when 16#03C# => read_data<=std_logic_vector(to_unsigned(LOOKAHEAD,32));
      when others =>
        if addr>=16#100# and addr<16#100#+8*N_COUNTERS and addr mod 4=0 then
          idx:=(addr-16#100#)/8; half:=((addr-16#100#) mod 8)/4;
          if half=0 then read_data<=std_logic_vector(shadow(idx)(31 downto 0));
          else read_data<=std_logic_vector(shadow(idx)(63 downto 32)); end if;
        end if;
    end case;
  end process;

  process(clk)
    variable slot,history_slot,cat : integer;
    variable valid_history : std_logic_vector(0 to HISTORY_DEPTH-1);
    variable f : word32;
  begin
    if rising_edge(clk) then
      increments<=(others=>'0'); clear_counts<='0';
      if reset='1' then
        state<=IDLE; flags<=(others=>'0');
        trial_valid<=(others=>'0'); hist_valid<=(others=>'0');
        pending<=0; have_h<='0'; snapshot_id<=(others=>'0');
        shadow_flags<=(others=>'0'); shadow_cal<=(others=>'0');
        shadow_start<=(others=>'0'); shadow_stop<=(others=>'0'); shadow_pending<=(others=>'0');
        for i in shadow'range loop shadow(i)<=(others=>'0'); end loop;
      else
        f:=flags;
        if state/=IDLE and state/=READY then
          if source_error='1' then f(2):='1'; end if;
          if start='1' or snapshot_ack='1' then f(4):='1'; end if;
        end if;
        for i in overflows'range loop
          if overflows(i)='1' and state/=IDLE and state/=INITIALIZE and state/=READY then f(0):='1'; end if;
        end loop;
        case state is
          when IDLE =>
            if start='1' then
              f:=(others=>'0');
              clear_counts<='1'; trial_valid<=(others=>'0'); hist_valid<=(others=>'0');
              pending<=0; have_h<='0'; cal_id<=cfg_calibration_id;
              run_start<=cfg_start_ps; run_stop<=cfg_stop_ps;
              if cfg_start_ps<to_unsigned(LOOKBACK,64) or cfg_stop_ps<=cfg_start_ps
                 or cfg_stop_ps>U64_MAX-to_unsigned(LOOKAHEAD,64) then
                f(4):='1'; bad_config<='1';
              else
                last_time<=cfg_start_ps-to_unsigned(LOOKBACK,64); bad_config<='0';
              end if;
              state<=INITIALIZE;
              if source_error='1' then f(2):='1'; end if;
            end if;
          when INITIALIZE =>
            if bad_config='1' then state<=PUBLISH; else state<=GET_ITEM; end if;
          when GET_ITEM =>
            if in_valid='1' then
              if in_time_ps<last_time then
                f(1):='1'; -- drop out-of-order item; run is invalid
              elsif in_calibration_id/=cal_id then
                f(3):='1'; -- incompatible calibration; run is invalid
              else
                item_time<=in_time_ps; item_kind<=in_kind; last_time<=in_time_ps;
                scan<=0; state<=CLOSE_TRIALS;
              end if;
            end if;
          when CLOSE_TRIALS =>
            if trial_valid(scan)='1' and
               item_time>=trial_time(scan)+to_unsigned(LOOKAHEAD,64) then
              for w in 0 to N_WINDOWS-1 loop
                cat:=0;
                if a_hits(scan)(w)='1' then cat:=cat+2; end if;
                if b_hits(scan)(w)='1' then cat:=cat+1; end if;
                increments(4*w+cat)<='1';
              end loop;
              trial_valid(scan)<='0'; pending<=pending-1;
            end if;
            if scan=TRIAL_DEPTH-1 then state<=APPLY_ITEM; else scan<=scan+1; end if;
          when APPLY_ITEM =>
            valid_history:=hist_valid;
            for j in 0 to HISTORY_DEPTH-1 loop
              if hist_valid(j)='1' and item_time>=to_unsigned(LOOKBACK,64) then
                if hist_time(j)<item_time-to_unsigned(LOOKBACK,64) then valid_history(j):='0'; end if;
              end if;
            end loop;
            hist_valid<=valid_history;
            if item_kind=KIND_A or item_kind=KIND_B then
              for i in 0 to TRIAL_DEPTH-1 loop
                if trial_valid(i)='1' then
                  for w in 0 to N_WINDOWS-1 loop
                    if item_kind=KIND_A and hit_in_window(item_time,trial_time(i),
                         WINDOW_OFFSETS(w)+A_LO_PS,WINDOW_OFFSETS(w)+A_HI_PS) then
                      a_hits(i)(w)<='1';
                    elsif item_kind=KIND_B and hit_in_window(item_time,trial_time(i),
                         WINDOW_OFFSETS(w)+B_LO_PS,WINDOW_OFFSETS(w)+B_HI_PS) then
                      b_hits(i)(w)<='1';
                    end if;
                  end loop;
                end if;
              end loop;
              history_slot:=-1;
              for j in 0 to HISTORY_DEPTH-1 loop
                if valid_history(j)='0' and history_slot=-1 then history_slot:=j; end if;
              end loop;
              if history_slot=-1 then f(2):='1';
              else
                hist_valid(history_slot)<='1'; hist_time(history_slot)<=item_time;
                if item_kind=KIND_A then hist_is_a(history_slot)<='1';
                else hist_is_a(history_slot)<='0'; end if;
              end if;
            elsif item_kind=KIND_H and item_time>=run_start and item_time<run_stop then
              increments(20)<='1';
              if have_h='1' and item_time-last_h<to_unsigned(HOLD_OFF_PS,64) then
                increments(22)<='1';
              else
                slot:=-1;
                for i in 0 to TRIAL_DEPTH-1 loop
                  if trial_valid(i)='0' and slot=-1 then slot:=i; end if;
                end loop;
                if slot=-1 then increments(23)<='1'; f(2):='1';
                else
                  increments(21)<='1'; pending<=pending+1;
                  trial_valid(slot)<='1'; trial_time(slot)<=item_time;
                  have_h<='1'; last_h<=item_time;
                  for w in 0 to N_WINDOWS-1 loop
                    a_hits(slot)(w)<='0'; b_hits(slot)(w)<='0';
                    for j in 0 to HISTORY_DEPTH-1 loop
                      if valid_history(j)='1' then
                        if hist_is_a(j)='1' and hit_in_window(hist_time(j),item_time,
                            WINDOW_OFFSETS(w)+A_LO_PS,WINDOW_OFFSETS(w)+A_HI_PS) then
                          a_hits(slot)(w)<='1';
                        elsif hist_is_a(j)='0' and hit_in_window(hist_time(j),item_time,
                            WINDOW_OFFSETS(w)+B_LO_PS,WINDOW_OFFSETS(w)+B_HI_PS) then
                          b_hits(slot)(w)<='1';
                        end if;
                      end if;
                    end loop;
                  end loop;
                end if;
              end if;
            end if;
            if item_kind=KIND_WATERMARK and item_time>=run_stop+to_unsigned(LOOKAHEAD,64) then
              if pending/=0 then f(4):='1'; end if;
              state<=PUBLISH;
            else state<=GET_ITEM; end if;
          when PUBLISH =>
            -- Counter increments issued during CLOSE_TRIALS have settled.
            shadow<=counts; shadow_flags<=f; shadow_cal<=cal_id;
            shadow_start<=run_start; shadow_stop<=run_stop;
            shadow_pending<=to_unsigned(pending,64);
            if snapshot_id=U64_MAX then shadow_flags(4)<='1';
            else snapshot_id<=snapshot_id+1; end if;
            state<=READY;
          when READY =>
            -- Shadow bank is immutable until ACK, including erroneous commands.
            if snapshot_ack='1' then state<=IDLE; end if;
        end case;
        flags<=f;
      end if;
    end if;
  end process;
end architecture;
