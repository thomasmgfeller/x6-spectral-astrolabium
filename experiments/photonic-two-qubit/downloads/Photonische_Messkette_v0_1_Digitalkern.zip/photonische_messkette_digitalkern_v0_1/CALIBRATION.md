# Kalibrierprotokoll K0.1 — noch an Hardware auszuführen

## Messgrössen und Aufbau

Für jeden Eingang werden Binbreiten, Zeitstempeloffset, differenzielle
Nichtlinearität und Einzelereignisstreuung ermittelt. Die FPGA-Taktperiode und
die Referenzverzögerung erhalten eigene Unsicherheiten. Formatauflösung,
mittlere Binbreite, systematischer Fehler und Jitter werden getrennt berichtet.

Benötigt: geeignetes FPGA-Board mit fertig implementiertem Erfassungsfrontend,
Pulsgenerator mit definierten Pegeln/Flanken und einstellbarer Phase/Pulsbreite,
passender Splitter/Abschluss, charakterisierte kurze und lange Kabelwege,
Temperatur- und Versorgungsmessung sowie ein geeignetes Referenzmessgerät für
die elektrische Verzögerung. Die nominale Kabellänge allein ist keine Zeitreferenz.
Pegel, Eingangsgrenzen, Reflektionen und Trigger-Time-Walk werden vorab geprüft.

## K1 — Erfassungsfunktion

Pulse über mindestens eine gesamte FPGA-Taktperiode phasenverschieben. Für
festgelegte Pulsbreiten und Raten Sollzahl gegen erfasste Ereignisse vergleichen.
Verluste, Duplikate, ungültige Codes und Mehrfachtreffer getrennt erfassen.
Insbesondere schmale Pulse und die ungünstigste Phase prüfen. Der Generator-
Zähler beziehungsweise eine unabhängige Referenz liefert die Sollzahl.
Null beobachtete Fehler sind mit einer oberen binomialen Fehlergrenze anzugeben,
nicht als Beweis einer Fehlerwahrscheinlichkeit von null.

## K2 — Code-Density-Kalibrierung

Vorbedingung: gleichmässige Phasenbelegung über genau eine Taktperiode T und
validierte Binreihenfolge des konkreten Decoders. Asynchronität allein genügt
nicht; rationale Frequenzverhältnisse oder Kopplung können die Belegung verzerren.
Entweder kontrollierter Phasensweep oder eine begründet gleichverteilte Quelle.
Rohcodes und verworfene Codes bleiben erhalten. Kalibrier- und Validierungsdaten
werden in vorab getrennten Messungen gewonnen.

Für N_i Treffer und N=sum(N_i):

```
w_i = T * N_i / N
t_i = sum(w_j for j < i) + w_i / 2
DNL_i = w_i / (T/M) - 1
INL_left_i = sum(w_j for j < i)/(T/M) - i
```

M ist die Anzahl der geordneten Bins. Die gemeldete Stichproben-Standardabweichung
von w_i ist T*sqrt(p_i*(1-p_i)/N). Sie beinhaltet keine Taktunsicherheit,
Phasenverzerrung, Drift oder Ereignisabhängigkeit. Binbreiten sind untereinander
korreliert. Null belegte Bins und ungültige Codes blockieren automatische
Übernahme; ein leeres Bin kann unzureichende Statistik oder ein fehlender Code sein.

## K3 — Kabeltausch

Dieselbe Flanke wird auf zwei Eingänge verteilt. Erste Anordnung:
Delta1 = Offset + d. Nach Tausch der beiden Kabelwege:
Delta2 = Offset - d. Somit d=(mean(Delta1)-mean(Delta2))/2 und
Offset=(mean(Delta1)+mean(Delta2))/2.

Splitterausgänge und andere Pfade bleiben definiert; Änderungen werden als
zusätzliche Beiträge erfasst. Kabeltemperatur, Steckerwiederholbarkeit,
Flankenform und Bezugsebene werden protokolliert. Für unabhängige Stichproben
ist die Standardunsicherheit des Mittelwertanteils jeweils
0.5*sqrt(s1^2/N1+s2^2/N2). Gemeinsame Drift oder Korrelation verlangt ein anderes
Kovarianzmodell. Das Werkzeug ergänzt keine unbekannte Referenzunsicherheit.

Die Streuung der Zeitdifferenz ist eine Paargrösse. Sie darf nur bei begründeter
Gleichheit und Unabhängigkeit der Kanaljitter durch sqrt(2) auf einen Kanal
umgerechnet werden. Gemeinsamer Generatorjitter kann sich in der Differenz
aufheben und ist dadurch nicht separat charakterisiert.

## K4 — Unabhängige Validierung

Mehrere andere charakterisierte Verzögerungen prüfen, auch über eine
Taktperiodengrenze. Für jede Einstellung Offsetfehler, Quantile und Standard-
abweichung einzelner Ereignisdifferenzen angeben. Ein kleiner Fehler des
Mittelwerts darf grosse Einzelereignisstreuung nicht verdecken.

Vorläufiges Projektbudget für den systematischen Restfehler mit expandierter
Referenz-/Kalibrierunsicherheit: abs(bias)+U95_systematic <= W_min/10.
Bei W_min=2000 ps entspricht das 200 ps. Das ist eine vorgeschlagene Anforderung,
kein Messergebnis. Erfassungsausfall, Jitter und Fensterfehlklassifikation erhalten
separate Grenzwerte aus dem Experimentfehlerbudget; ihre noch offenen Werte
verhindern eine vollständige physikalische Freigabe.

## K5 — Fenster und Betriebspunkte

Für A und B jeweils Ereignisse direkt vor/auf/nach der unteren und oberen
Fenstergrenze einsetzen, im Hauptfenster und allen Seitenfenstern. Gleichzeitige
H/A/B-Ereignisse, die bekannte nichtgemeinsame Pulsüberlappung, Mehrfachtreffer
und überlappende Trials testen. Histogramme der Fehlzuordnung als Funktion des
Abstands zur Fenstergrenze speichern; Hardwarejitter verbreitert diese Übergänge.

K1/K4/K5 über den vorgesehenen Temperatur-, Spannungs- und Ratenbereich wiederholen.
Der Gültigkeitsbereich ist mit Messwerten und Messunsicherheiten einzufrieren.
Jeder neue FPGA-Build beziehungsweise jede Platzierungs-/Routingänderung wird
zunächst als neue Kalibrieridentität behandelt, sofern kein Übertragungsnachweis
vorliegt. Ausserhalb des validierten Bereichs wird der Lauf gesperrt/ungültig.

## Persistente Messunterlagen

Board-ID, FPGA-Typ, Bitstream-Hash, Decoder-Version, Taktreferenz, Eingangspegel,
Pulsbreite, Rate, Referenzgeräte/Kalibrierscheine, Kabelkonfiguration, Temperatur,
Versorgung, Rohhistogramme, verworfene Ereignisse, LUT, Unsicherheitsbudget und
unabhängige Validierungsdaten gemeinsam versionieren. Eine 32-Bit-Kalibrier-ID
im Kern ist ein Lookup-Schlüssel; die vollständigen Artefakte liegen beim Host.

Ohne echte Messungen bleiben alle mitgelieferten Kalibrierdateien synthetisch.
