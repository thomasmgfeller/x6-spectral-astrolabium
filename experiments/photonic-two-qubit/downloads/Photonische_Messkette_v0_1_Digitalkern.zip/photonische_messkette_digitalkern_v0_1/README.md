# Photonische Messkette v0.1 — digitaler Referenzkern

Stand: 11. Oktober 2026. MIT-Lizenz, siehe LICENSE.

Dieses Paket ergänzt die zuvor erstellte statistische Auswertung um vollständigen
VHDL-2008-Quellcode für den **synchronen Ereigniskern**, Simulationstests,
Kalibrierwerkzeuge, einen Snapshot-Registerplan und eine Host-Formatbrücke.
Der Kern verarbeitet bereits kalibrierte, zeitlich sortierte Ereignisse.
Er enthält keinen Carry-Chain-TDC, keine analoge Detektoreingangsstufe, keine
USB-Schnittstelle und keinen CDC-Adapter. Eine Syntheseprüfung ersetzt weder
Quartus Place-and-Route noch Timing Closure oder Messungen am DE10-Nano.

## Ausführen

```bash
GHDL=ghdl python sim/run_tests.py
cd host
python -m unittest -v test_host
python calibration.py ../examples/calibration_synthetic.json --output calibration_result.json
```

GHDL muss installiert sein. Der Testlauf nutzt VHDL-2008. Die tatsächlich verwendete
Version und Resultate liegen unter `validation/`. Simulator-Binärdateien sind nicht
Teil dieses Pakets. Die Host-Kalibrier- und Exportwerkzeuge verwenden nur die
Python-Standardbibliothek. Die beigefügte statistische Referenz benötigt SciPy;
deren Versionsbindungen und frühere Tests stehen unter `statistics_reference/`.

`sim/run_tests.py` generiert die Stimuli deterministisch. Das Batch-Referenzmodell
sucht die Treffer in vollständigen Ereignislisten; es bildet nicht die RTL-FIFO-
oder Zustandsmaschinen-Implementierung nach. Zufallsfälle verwenden Seed 104729.
Für bewusst ungültige Kapazitäts-/Erfassungsfälle wird das Fehlerflag geprüft,
nicht die wissenschaftliche Verwendbarkeit der anschliessenden Teilzähler.

## Ereignisvertrag

Alle Core-Ports gehören zur selben Taktdomäne. Ein Element wird nur an einer
steigenden Flanke mit `in_valid=1 AND in_ready=1` übernommen. Der Produzent hält
Art, Zeitstempel und Kalibrier-ID unter Rückstau stabil. Kann er physikalische
Ereignisse nicht puffern, muss er `source_error` setzen. Ein detektornaher FIFO
mit Überlauferkennung ist ausserhalb dieses Kerns erforderlich.

- `in_kind`: 0=H, 1=A, 2=B, 3=Watermark.
- `in_time_ps`: unsigned 64 Bit, gemeinsame Epoche und **Formatauflösung 1 ps**.
  Das ist keine Behauptung einer physikalischen Genauigkeit von 1 ps.
- Alle Zeitstempel sind monoton nicht fallend; gleiche Zeitstempel dürfen in
  beliebiger Kanalreihenfolge eintreffen. Ein vorgelagerter Merge muss diese
  Ordnung herstellen. Getrennte, unabhängig verzögerte Kanal-FIFOs genügen nicht.
- Eine Watermark T erklärt verbindlich, dass kein später geliefertes Ereignis
  einen Zeitstempel kleiner als T hat. Sie erzeugt keinen Detektortreffer.
- Die Kalibrier-ID bleibt während Vorlauf, Akquisition und Nachlauf konstant.
- Zeitstempelumlauf ist innerhalb eines Laufs unzulässig. Die Epoche muss so
  gewählt sein, dass Vor- und Nachlauf ohne Unter-/Überlauf darstellbar sind.

Der Core-START friert Startzeit, Stopzeit und Kalibrier-ID ein. Die Herald-
Akquisition ist `[start, stop)`. Ereignisse werden ab `start - LOOKBACK` geliefert;
der vorgelagerte Erfassungsblock muss diesen Vorlauf vollständig bereitstellen.
H-Ereignisse ausserhalb der Akquisition werden ignoriert, A/B bleiben für Vor-
und Nachlauf aktiv. Der Core kann verschwiegene Lücken im Ereignisstrom nicht
selbst erkennen.

Eine abschliessende Watermark mindestens `stop + LOOKAHEAD` beendet den Lauf.
Bei Stille muss der Produzent weiterhin eine korrekte Watermark liefern. Ohne
diese Information gibt es absichtlich keinen vermeintlich vollständigen Snapshot.
Watchdog und physische Abschaltung sind separate Systemfunktionen.

## Fenster, Vorgeschichte und Trials

Standard: A und B jeweils `[-1000,+1000)` ps um H. Untere Grenze inklusive,
obere Grenze exklusive. Dazu vier identische Fensterpaare mit gemeinsamen
Offsets -200000, -100000, +100000 und +200000 ps. Der Hauptzähler ist Offset 0.
Die Fenstergrenzen sind VHDL-Generics; diese Version ändert sie nicht zur Laufzeit.

Default LOOKBACK=201000 ps und LOOKAHEAD=201000 ps. Eine begrenzte History hält
A/B-Ereignisse, die ein zukünftiger Herald noch benötigen könnte. Nur eindeutig
zu alte Einträge werden verworfen. Ein voller History-Speicher setzt ein
ungültigmachendes Verlustflag. Positive Fenster werden in mehreren gleichzeitig
offenen Trial-Slots erfasst. Der Standard hat 8 Slots und 64 History-Einträge.

Der H-only-Hold-off ist standardmässig 100000 ps und nicht verlängernd:
H wird verworfen, wenn sein Abstand zum letzten **akzeptierten** H kleiner als
der Hold-off ist. Ein verworfener H verlängert ihn nicht. Die Kapazität eines
Trial-Slots ist kein zusätzlicher erlaubter Selektionsmechanismus: ein Mangel
setzt ein Verlustflag und wird gesondert gezählt. H-Hold-off ist keine physische
Quenching-Funktion und kein Beweis statistischer Unabhängigkeit.

Pro Fensterpaar und akzeptiertem Herald wird genau eine Kategorie gezählt.
Alle fünf Fensterpaare werden nach Ablauf des spätesten Fensters gemeinsam
abgeschlossen. Das vergrössert die Latenz, verändert aber nicht die Fenster.
Mehrfachtreffer im selben Kanal erzeugen weiterhin nur ein Hit-Flag. Die Daten
enthalten keine automatische Hintergrundsubtraktion und keinen iid-Test.

Die Kategorien haben im Registerarray binäre AB-Reihenfolge:

| Index innerhalb eines Fensterpaars | Kategorie |
|---|---|
| 0 | n00 |
| 1 | n01, nur B |
| 2 | n10, nur A |
| 3 | n11, beide |

Der Host-Adapter berücksichtigt diese Reihenfolge ausdrücklich. n11 ist eine
Klickkoinzidenz und kann Dunkelereignisse, Nachpulse oder andere Artefakte enthalten.

## Durchsatz und Implementierungsgrenzen

Der Kern ist eine mehrtaktige, endliche Referenzimplementierung. Pro angenommenem
Element werden TRIAL_DEPTH Slots nacheinander geschlossen und danach das Element
angewendet. Der ideale Annahmeabstand beträgt TRIAL_DEPTH+2 Core-Takte; beim
Standard somit 10 Takte. 100 MHz würden rechnerisch höchstens 10 Mio. Elemente/s
ermöglichen, **falls** eine spätere Implementierung diesen Takt erreicht.
Diese Frequenz wurde nicht auf Hardware nachgewiesen. Watermarks verbrauchen
ebenfalls Durchsatz. Komparatoren für History und offene Fenster können relevante
Flächen- und Timingkosten verursachen. Puffergrösse und Maximalrate müssen vor
einer Board-Freigabe gemeinsam dimensioniert werden.

Die Saturating-Counter-Instanzen sind standardmässig 64 Bit breit. Für einen
gezielten Überlauftest werden sie auf 4 Bit parametrisiert. Ein Überlaufversuch
sättigt den Wert und setzt ein dauerhaftes Fehlerflag; er wird nicht verborgen.
Alle Zähler und Lauf-Flags werden beim nächsten gültigen START neu initialisiert.

## Snapshot und Register

Nach der End-Watermark schliesst der Kern alle offenen Trials, lässt die
Counter-Pipeline auslaufen und kopiert Zähler und Metadaten atomar in eine
Shadow-Bank. READY bleibt bis ACK gesetzt. Änderungen an Eingangsereignissen,
Konfigurationsports oder START verändern einen fertigen Snapshot nicht.
Erst nach ACK kann ein neuer Lauf gestartet werden. ACK und neuer START werden
nicht auf derselben Taktflanke kombiniert. Reset verwirft Lauf und Snapshot.

Der Leseport hat 12 Bit Byteadresse und liefert kombinatorisch 32 Bit innerhalb
der Core-Taktdomäne. Nicht definierte/unalignierte Adressen liefern null.
64-Bit-Werte: Low-Word an der niedrigeren Adresse. Das legt keine UART-/USB-
Byteordnung fest; der spätere Transportadapter muss sie separat spezifizieren.

| Adresse | Inhalt |
|---|---|
| 0x000 | Magic 0x50484F54 (PHOT) |
| 0x004 | Registerversion 0x00010000 |
| 0x008 | Live-Status: Bit 0 READY, Bit 1 BUSY |
| 0x00C | eingefrorene Fehlerflags |
| 0x010 / 0x014 | Snapshot-ID, low/high |
| 0x018 | Kalibrier-ID |
| 0x020 / 0x024 | Startzeit ps, low/high |
| 0x028 / 0x02C | Stopzeit ps, low/high |
| 0x030 / 0x034 | offene Trials beim Snapshot, regulär null |
| 0x038 / 0x03C | LOOKBACK / LOOKAHEAD in ps |
| 0x100 + 8*i | Low-Word von Zähler i |
| 0x104 + 8*i | High-Word von Zähler i |

| Zählerindex i | Inhalt |
|---|---|
| 0..3 | Hauptfenster, AB=00/01/10/11 |
| 4..7 | -200 ns |
| 8..11 | -100 ns |
| 12..15 | +100 ns |
| 16..19 | +200 ns |
| 20 | H_raw innerhalb `[start,stop)` |
| 21 | H_accepted |
| 22 | H_rejected_policy |
| 23 | H_rejected_capacity, macht Lauf ungültig |

| Fehlerbit | Bedeutung |
|---|---|
| 0 | Zählerüberlauf |
| 1 | nichtmonotone Zeitstempel |
| 2 | Source-Error, History-Überlauf oder fehlender Trial-Slot |
| 3 | falsche Kalibrier-ID |
| 4 | ungültige Konfiguration/Steuerung oder interne Abschlussinkonsistenz |

Alle Fehlerbits machen die physikalische Auswertung des Laufs ungültig. Flags
sind kein automatischer Nachweis, dass nicht gemeldete Hardwarefehler fehlen.
Ein Transportadapter muss READY und Snapshot-ID vor/nach dem Lesen prüfen,
CRC/Frame-Länge verifizieren und erst dann ACK geben. SHA-256 einer Datei kann
Herkunft und Übertragungsintegrität nicht allein beweisen.

## Host-Brücke zur Statistik

`host/export_snapshot.py` übersetzt einen vollständig gelesenen Snapshot in
`photon-chain.raw.v0.1`. Es implementiert keinen physischen Transport. Das Feld
`transport_verified` ist eine Verpflichtung des aufrufenden Adapters.
Der Adapter erhält ausserdem Build-ID, Config-ID, Protocol-ID und die deklarierte
Vorabfestlegung. Diese Angaben kann er nicht aus den Zählern rekonstruieren.
Zähler und Zeitstempel sind Dezimalstrings, damit 64 Bit beim JSON-Transport
erhalten bleiben. Für das bisherige Statistikformat muss die Akquisitionsdauer
eine ganzzahlige Nanosekundenzahl ergeben. ps-genaue beliebige Dauern würden
eine neue Version dieses Formats benötigen.

`examples/snapshot_simulated.json`, `examples/raw_simulated.json` und
`examples/statistics_simulated.json` zeigen die Ende-zu-Ende-Übergabe tatsächlicher
VHDL-Simulationsergebnisse an die bestehende statistische Referenz. Diese Dateien
bleiben ausdrücklich synthetische Daten.

## Kalibrierung

Das konkrete Messverfahren und seine Abnahmestufen stehen in CALIBRATION.md.
`host/calibration.py` erzeugt eine Kandidaten-LUT aus einem Code-Density-
Histogramm und berechnet die Kabeltausch-Schätzung. Es behauptet auch bei
fehlerfreien synthetischen Daten niemals `hardware_validated=true`.

## Quellen und Status

- GHDL-Aufrufe: https://ghdl.github.io/ghdl/using/InvokingGHDL.html
- Carry-Chain-Erfassung und Kalibrierung auf Cyclone V:
  https://arxiv.org/abs/2109.03026
- TDC-Kalibrierverfahren:
  https://pmc.ncbi.nlm.nih.gov/articles/PMC10007395/
- Statistik-Hintergrund und Annahmen: siehe `statistics_reference/README.md`.

Die Quellen dienen zur Einordnung; sie validieren diesen neuen Kern nicht.
Massgeblich für ausgeführte Prüfungen sind VALIDATION.md und die beigefügten Logs.
