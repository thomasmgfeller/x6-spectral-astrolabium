"""Small-angle feedforward around nominal pose; closed-loop observation required.
Positive turns = screw advances into contact, viewed from screw head.
Translations requested at carrier centre (0,125,18) in the fixed jig frame.
Example: python3 src/adjust.py --pitch 0.02 --dz 0
"""
import argparse,json,math
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
for axis in ('dx','dy','dz'):p.add_argument('--'+axis,type=float,default=0,help='mm at carrier centre')
for axis in ('pitch','roll','yaw'):p.add_argument('--'+axis,type=float,default=0,help='degrees about X, Y, Z respectively')
a=p.parse_args();w=np.radians([a.pitch,a.roll,a.yaw]);target=np.array([a.dx,a.dy,a.dz])
v=target-np.cross(w,np.array([0,125,-8]))
q=np.r_[v,w]
A=np.array([[0,0,1,-40,60,0],[0,0,1,-40,-60,0],[0,0,1,40,-20,0],[0,1,0,0,0,-60],[0,1,0,0,0,60],[1,0,0,0,0,0]],float)
delta=A@q
within=bool(np.all(np.abs(v)<=np.array([1,1,.5])+1e-12) and np.all(abs(w)<=math.radians(.2)+1e-12))
print(json.dumps({'model':'first-order prediction, not measured movement','within_nominal_pose_box':within,
 'warning':'Apply small increments and observe beam and bond gap. Do not adjust during gel/full cure.',
 'turns_M4x0_7':dict(zip(['Z1','Z2','Z3','Y1','Y2','X'],(delta/.7).tolist())),
 'actuator_delta_mm':delta.tolist(),'stage_translation_mm':v.tolist()},indent=2))
raise SystemExit(0 if within else 2)
