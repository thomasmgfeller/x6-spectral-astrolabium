"""Generate the German fabrication manual and 1:1 drill templates."""
from pathlib import Path
import json,math
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle

ROOT=Path(__file__).resolve().parents[1]
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('D',FONT));pdfmetrics.registerFont(TTFont('DB',BOLD))
INK=colors.HexColor('#142a3b');MUTED=colors.HexColor('#496170');ACCENT=colors.HexColor('#bd571c');PALE=colors.HexColor('#edf3f6')
styles={
 'body':ParagraphStyle('body',fontName='D',fontSize=9.2,leading=13.5,textColor=INK,spaceAfter=6),
 'small':ParagraphStyle('small',fontName='D',fontSize=7.8,leading=11,textColor=MUTED),
 'cell':ParagraphStyle('cell',fontName='D',fontSize=8,leading=11,textColor=INK),
 'head':ParagraphStyle('head',fontName='DB',fontSize=8,leading=11,textColor=colors.white)}
out=ROOT/'JIG_F1_Bauanleitung.pdf';c=canvas.Canvas(str(out),pagesize=A4)
c.setTitle('JIG-F1 v0.1 - Wiederverwendbarer FabLab-Justierjig');c.setAuthor('Projektentwicklung mit Thomas Gfeller')
page_no=0;W,H=A4
def page(title,subtitle='',size=A4):
 global page_no,W,H
 if page_no:c.showPage()
 c.setPageSize(size);W,H=size;page_no+=1
 c.setFillColor(INK);c.rect(0,H-9*mm,W,9*mm,fill=1,stroke=0)
 c.setFont('DB',8);c.setFillColor(colors.white);c.drawString(16*mm,H-6*mm,'JIG-F1 / FABLAB EDITION / v0.1')
 c.setFillColor(INK);c.setFont('DB',20);c.drawString(16*mm,H-24*mm,title)
 if subtitle:para(subtitle,H/mm-34,style='small')
 c.setStrokeColor(colors.HexColor('#cbd6dd'));c.line(16*mm,13*mm,W-16*mm,13*mm)
 c.setFont('D',7);c.setFillColor(MUTED);c.drawString(16*mm,8*mm,'11.10.2026 | Konstruktionsprototyp - physisch noch ungeprüft')
 c.drawRightString(W-16*mm,8*mm,str(page_no))
 return H/mm-43
def para(text,top,x=16,width=178,style='body'):
 p=Paragraph(text,styles[style]);_,h=p.wrap(width*mm,1000)
 p.drawOn(c,x*mm,top*mm-h);return top-h/mm-3
def heading(text,top,x=16):
 c.setFont('DB',11);c.setFillColor(ACCENT);c.drawString(x*mm,top*mm,text);return top-7
def table(rows,widths,top,x=16):
 data=[[Paragraph(str(v),styles['head' if i==0 else 'cell']) for v in row] for i,row in enumerate(rows)]
 t=Table(data,colWidths=[v*mm for v in widths],hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#cbd6dd'))]))
 _,h=t.wrapOn(c,W,H);t.drawOn(c,x*mm,top*mm-h);return top-h/mm-5
def bullet(text,top):return para('• '+text,top)
def note(text,top):
 p=Paragraph(text,styles['body']);_,h=p.wrap(168*mm,1000)
 c.setFillColor(PALE);c.roundRect(16*mm,(top-5)*mm-h,178*mm,h+9*mm,3*mm,fill=1,stroke=0)
 p.drawOn(c,21*mm,top*mm-h);return top-h/mm-12

y=page('Der wiederverwendbare Jig','Metallmechanik aus Flachmaterial und Normteilen; kleine Druckteile als Bedienhilfen.')
c.drawImage(str(ROOT/'drawings/assembly.png'),13*mm,126*mm,width=184*mm,height=126*mm,preserveAspectRatio=True,anchor='c')
y=119
y=table([['Entwurfsmerkmal','Festlegung'],['Grundplatte / Platzbedarf','240 × 220 × 8 mm / ungefähr 260 × 250 × 100 mm mit Bedienelementen'],['Optikträger','Referenz 20 × 20 × 20 mm; Nutzlast bis 50 g als Auslegungsziel'],['Feinbewegung am Tisch','X/Y ±1 mm; Z ±0,5 mm; drei Winkel je ±0,2° als Entwurfsbereich'],['Herstellung','Sägen, Bohren, Feilen, acht M3-Gewinde; 3D-Druck optional für Knöpfe/Mutternhalter'],['Materialbudget','Eigene Planungsschätzung: 90-180 CHF; Werkzeuge, Arbeitszeit und FabLab-Gebühren separat']],[48,130],y)
y=para('Die Vorrichtung hält den <b>Metallträger</b> während Justage und Härtung. Zwei Schrauben und eine abziehbare Gabel ersetzen das direkte Greifen empfindlicher optischer Flächen. Eine fertige Quelle, ein Klebeverfahren und eine Mikroradian-Spezifikation werden damit noch nicht freigegeben.',y)

y=page('Mechanik und Achsen','Koordinatenursprung: Mitte der Grundplatte auf deren Unterseite; alle Maße in mm.')
y=para('Die blaue Tischplatte steht auf drei gerundeten M4-Stellschrauben. Ihr Eigengewicht und ein Stahlgewicht halten diese Kontakte geschlossen. Zwei weitere Schrauben wirken von hinten in +Y, eine von links in +X. Drei Stahl-Zugfedern ziehen gegen diese Seitenanschläge. Es gibt keine gleitenden Schienen und keine Klemmung nach der Feinjustage.',y)
y=table([['Kontakt','Kontaktpunkt X / Y / Z','Wirkung'],['Z1 / Z2','(-60 / -40 / 22), (60 / -40 / 22)','Höhe und Neigung'],['Z3','(20 / 40 / 22)','Höhe und Neigung; seitlich versetzt'],['Y1 / Y2','(-60 / -61 / 26), (60 / -61 / 26)','Y und Drehung um Z'],['X','(-81 / 0 / 26)','X'],['Fangbolzen','(-60 / -20), (60 / -20), (40 / 50)','Nur Anschlag; im Betrieb kontaktfrei']],[32,87,59],y)
y=heading('Sechs Freiheitsgrade, kein ideal reibungsfreies Lager',y)
y=para('Das lineare Kontaktmodell hat Rang 6. Haftreibung und elastische Kontakte koppeln die realen Bewegungen. Justieren erfolgt daher mit optischer Rückmeldung. Ein auf einer Gewindeflanke vorgespannter Anschlag vermindert Umkehrspiel; er beseitigt weder Reibung noch Kriechen.',y)
y=para('Ein Stahlgewicht von rund 190 g sitzt auf der hinteren Tischhälfte. Die drei Zugfedern müssen über den benutzten Weg jeweils 0,8-1,2 N Zug aufbringen. Vorgesehene Ösenabstände: X etwa 40 mm, Y je 45 mm. Federlänge und Vorspannung am realen Teil messen. Keine Gummibänder.',y)
y=note('<b>Nur waagrecht verwenden.</b> Die Z-Vorspannung beruht auf Schwerkraft. Fangbolzen verhindern das Abheben bei einem Missgriff; sie machen den Jig nicht transportsicher. Beim Tragen keine Optik einspannen.',y)

y=page('Teile zum Herstellen','STEP enthält Einzelteile und eine Baugruppe. Gedruckte Teile sind keine tragenden Präzisionsführungen.')
y=table([['ID / Anzahl','Rohteil / Maße','Arbeit'],['P01 / 1','Aluminiumplatte 240 × 220 × 8','Ablängen; Durchgangsbohrungen'],['P02 / 1','Aluminiumplatte 160 × 120 × 6','Bohren; sechs Bohrungen Ø2,5 als M3-Gewinde'],['P03 / 1','Aluflach 40 × 8, Länge 80','Sechs Durchgangsbohrungen'],['P04 / 1','Alublech 36 × 70 × 3','Zwei Langlöcher, zwei vorn offene Schlitze'],['P05 / 1','Stahlflach 100 × 30 × 8','Zwei Bohrungen; Gewicht ca. 190 g'],['P06 / 3','Aluwinkel 25 × 25 × 3, Länge 30','Zwei Fuß-, drei Stirnbohrungen'],['P07 / 3','Stahlplättchen 20 × 20 × 1','Zwei Durchgangsbohrungen; Kontaktfläche glatt'],['P08 / 3','Stahlwinkel 10 × 10 × 1, Länge 25','Zwei Bohrungen; alternativ im Schraubstock kanten'],['D01 / 6','Mutternhalter, ca. 30 × 14 × 5','FDM-Druck; Sechskanttasche ggf. nachfeilen'],['D02 / 6','Drehknopf Ø28 × 8','FDM-Druck; alternativ gekaufter Rändelknopf']],[30,78,70],y)
y=para('Die acht M3-Gewinde sind sechs Befestigungen für die Kontaktplättchen und zwei Bohrungen im Referenzträger. Sie lassen sich mit einem Handgewindebohrer herstellen. CNC-Fräse, Drehbank, Schweißen und Schleifen auf Präzisionsmaschinen sind für diesen Prototyp nicht erforderlich.',y)
y=para('Kontaktplättchen nicht aufkleben: M3×6 von unten in P02 einschrauben. Die Schrauben dürfen nicht oben aus P02 herausragen. Die seitlichen Stahlwinkel werden mit M3-Schrauben und Muttern mechanisch befestigt.',y)

y=page('Normteile und Beschaffung','Längen am tatsächlich gekauften Profil und Schraubenkopf nachprüfen; keine Bestellung ausgelöst.')
y=table([['Menge','Teil','Verwendung'],['6','M4×40, Regelgewinde 0,7; Kopf SW7','Steller; Spitzen verrunden und glätten'],['6','M4-Sechskantmutter, etwa SW7 × 3,2','Feststehendes Gewinde; D01 verhindert Mitdrehen'],['3','Stahl-Zugfeder mit Ösen','0,8-1,2 N im ganzen Arbeitsbereich'],['3','Metall-Distanzfuß M6, Höhe 50','Dreipunktaufstellung; Schrauben M6×16 passend dazu'],['3','M3-Gewindestange/-schraube, ca. 40','Fangbolzen; Ø12-Scheiben, Muttern und Gegenmuttern'],['6','M3-Ösenanker oder Schraube mit Scheiben','Federenden; Ösenzentrum bei Z≈34'],['2','M3×20 Flanschkopfschraube, Kopf Ø≥6,8','Träger halten; ohne lose Unterlegscheibe am Kopf'],['2','Metallhülse Ø6 / Ø3,2, Länge 9','Zwischen Träger und Gabel; gleiche Länge'],['6','M3×6','Kontaktplättchen P07 an P02'],['6 + 6','M3×20 + M3×12','Mutternhalter unten / an Seitenwinkeln'],['6','M3×12 mit Muttern','Seitliche Kontaktwinkel P08'],['14','M4×20 mit Muttern und Scheiben','Arm 4, Gabel 2, Ballast 2, Fußwinkel 6'],['Vorrat','M3/M4-Muttern, Scheiben, Gegenmuttern','Anker/Fangbolzen/Reserven; mindestens je 30']],[16,86,76],y)
y=para('Die CAD-Baugruppe vereinfacht Schrauben, Muttern, Gewinde und Federn; nicht jede Befestigung ist als Einzelkörper dargestellt. Die Tabelle und der Trockenaufbau bestimmen die reale Montagereihenfolge. Scheiben und Muttern müssen frei bleiben.',y,style='small')

y=page('Werkstattablauf','Hilfsmittel: Schraubstock, Metallsäge, Feilen, Körner, Messschieber, Bohrmaschine/Bohrständer und M3-Handgewindebohrer.')
for title,text in [
 ('1. Material und Schablonen','Aluminium als ausreichend ebenen Zuschnitt beschaffen. Bohrschablonen ohne Seitenanpassung ausdrucken; den 100-mm-Balken nachmessen. Unebene Platten, Grat und verzogene Winkel vor Montage korrigieren. Eine Schablone erzeugt keine Präzisionspassung.'),
 ('2. Bohren und Langlöcher','Ankörnen, zunächst klein vorbohren, auf angegebenen Durchmesser aufbohren. P04: Enden bohren, Stege aussägen und feilen. P06-Winkel getrennt an Fuß und Steg bohren. Teile zum Bohren einspannen. Kanten leicht entgraten.'),
 ('3. Kontakte vorbereiten','M4-Spitzen im Schraubstock rund feilen und mit feinem Schleifmittel glätten. Nicht spitz lassen. Das CAD zeigt eine idealisierte Rundung. Wenn diese Ausführung ruckelt oder eindrückt, zunächst auf passende Kugeldruckschrauben umrüsten. Kurze Katalogschrauben ersetzen M4×40 nicht ohne neuen Adapter.'),
 ('4. Mutternhalter','Jede M4-Mutter liegt direkt auf Metall. D01 hält nur den Sechskant gegen Verdrehen. Die Tasche darf die Mutter nicht vom Metall abheben und ihr Gewinde nicht verkanten. Die M3-Halteschrauben halten D01, nicht die Stellschraube. Keine Gegenmutter nach der Justage festziehen.'),
 ('5. Druckteile','D01 mit Taschenseite nach oben drucken; D02 mit großer Flachseite unten. Startwert: 0,2-mm-Schichten, vier Wände, 40 % Füllung. Erst je ein Teil probedrucken und die Passung am realen Normteil prüfen. PLA/PETG bleibt außerhalb des axialen metallischen Lastpfads.'),
 ('6. Fertigungsniveau','Zielwerte: Lochpositionen ±0,3 mm, Außenkonturen ±0,5 mm. Fangbohrungen und Schlitze großzügig frei halten. Trägerbohrungen und Gabelschlitze als Paar anpassen. Die Kontaktflächen müssen sauber, gratfrei und ohne fühlbare Kerben sein; eine behauptete optische Ebenheit ist nicht erforderlich.')]:
 y=heading(title,y);y=para(text,y)

y=page('Montage und Optikanschluss','Erst einen Metall-Dummy einsetzen. Den fertigen Sagnac nicht als mechanische Probemontage verwenden.')
for text in [
 'Grundplatte auf drei 50-mm-Füße stellen und auf einer steifen gemeinsamen Unterlage befestigen. Seitliche Winkel und sechs Mutternhalter montieren. Die Schrauben dürfen sich leicht bewegen, ihre Muttern nicht.',
 'Drei P07-Plättchen unter P02 schrauben; P08-Kontaktwinkel anbringen. P02 auf die Z-Steller setzen. Nominal liegt ihre Unterseite bei Z=23, die Oberseite bei Z=29. Fangbolzen durch Ø8-Bohrungen führen; Unterkante Fangscheibe bei Z=31. Weder Scheibe noch Schaft dürfen P02 berühren.',
 'Arm, Ballast und Gabel anschrauben. Die M4-Gabelbolzen liegen global bei X=±11 / Y=85. Gabel im Ausgangszustand von Y=70 bis 140; die Langlöcher erlauben anschließend mindestens 25 mm Rückzug.',
 'Federn einhängen und ihre Arbeitskraft prüfen. Die Federösen sollen etwa auf Höhe Z=34 liegen. Kontakte vor und nach Betätigung jeder Schraube auf sicheren Sitz prüfen.',
 'Trägeradapter: zwei M3-Gewinde oben, Abstand 12 mm, mindestens 9 mm nutzbares Gewinde, Bohrtiefe 11 mm. Zwei gleiche 9-mm-Hülsen und zwei M3×20-Flanschkopfschrauben verbinden den Träger mit der Gabel. Nominaler Gewindeeingriff 8 mm. Keine Schraube darf im Sackloch aufsetzen.',
 'Träger nur so fest anziehen, dass er verdrehsicher hält. Er besitzt eigene Aufnahmen für Spiegel/PBS; der Jig berührt keine beschichtete Fläche. Die konkreten Optikaufnahmen bleiben vom vorhandenen Bauteil abhängig.'
 ]:y=bullet(text,y)
y=note('Referenzmaß: Träger 20 × 20 × 20 mm, Zentrum X=0 / Y=125 / Z=18. Seine Unterseite liegt nominal bei Z=8, also 58 mm über der Aufstellfläche (Fußhöhe 50 mm). Dieses CAD-Maß ist ein Trockenmaß ohne Klebespalt. Modulunterlage und Spalt werden am realen Aufbau eingestellt.',y)
y=para('Der seitlich versetzte Z3-Steller lässt um X=0 einen hinteren Durchblick frei. Trotzdem müssen alle Pump-, Signal-, Idler- und UV-Wege mit dem tatsächlichen Optikträger geprüft werden. Ein massiver Dummy ist keine PBS-Fassung. Für hohe oder breite Träger braucht es eine angepasste Gabel beziehungsweise Hülsenlänge.',y)

y=page('Justieren, härten, freigeben','Die Ablösebewegung ist konstruiert; ihre Auswirkung auf den Strahl wird gemessen.')
for title,text in [
 ('A. Trocken justieren','Grobausrichtung über die Lage des gesamten Jigs und die Modulunterlage vornehmen, danach beide befestigen. Den Feinbereich mittig nutzen. Jede Achse mit optischer Rückmeldung prüfen; kleine Änderungen und Setzzeit. Vor dem Kleben mindestens 0,5 mm Aufwärtsreserve lassen.'),
 ('B. Klebeprozess','Nur ein zuvor geprüfter, geometrisch zugänglicher Klebeprozess wird eingesetzt. Spiegelträger ausrichten und Jig während Vor- und Endhärtung in derselben Lage lassen. In der Gelphase nicht nachstellen. UV-Wärme, Bauteiltemperatur und Position protokollieren; nach Ende zur Ausgangstemperatur zurückkehren lassen.'),
 ('C. Halteschrauben entspannen','Nach bestätigter vollständiger Härtung beide M3-Flanschkopfschrauben abwechselnd um insgesamt zwei Umdrehungen lösen. Das schafft nominal 1 mm Kopffreiraum; rund 7 mm Gewindeeingriff verbleiben. Gegenhalten am vorgesehenen Metallträger, ohne die Optik zu belasten. Schon diesen Schritt separat messen.'),
 ('D. Gabel freistellen','Alle drei Z-Steller gleich weit anheben: nominal 0,3 mm = 0,429 Umdrehungen bei M4×0,7. In kleinen gleichen Teilbewegungen arbeiten. Gabelunterseite und Distanzhülsen sowie Gabeloberseite und Schraubenköpfe müssen sichtbar frei sein. Bei Kontakt oder Strahlbewegung stoppen und Ursache klären.'),
 ('E. Gabel abziehen','Erst jetzt die beiden M4-Gabelbefestigungen lösen und die Gabel mindestens 25 mm nach hinten in -Y schieben. Die vorn offenen Schlitze verlassen die Halteschrauben. Hülsen und Schrauben verbleiben zunächst am Träger. Den ganzen Jig erst entfernen, wenn die Gabel vollständig frei ist.'),
 ('F. Nachmessen','Unmittelbar danach und nach einer festgelegten Wartezeit die Strahllage prüfen. Entfernen der verbliebenen Handhabungsschrauben/Hülsen ist ein eigener Messschritt. Erst die Messwerte zeigen, ob die Lastübertragung die optische Toleranz einhält.')]:
 y=heading(title,y);y=para(text,y)

y=page('Einstellrechnung und Grenzen','Rechnung im Kleinstwinkelmodell; keine Auflösungs- oder Genauigkeitsgarantie.')
y=para('M4×0,7 bewegt die Schraubenspitze ideal um 0,7 mm pro Umdrehung. Ein Drehwinkel von 1° entspricht 1,94 µm. Über einen 120-mm-Hebel ergibt das 16,2 µrad, über 80 mm 24,3 µrad. Haftreibung, Spitzenform und Gewindefehler können diese kleinen Bewegungen überdecken.',y)
y=table([['Bedienung','Erste Näherung'],['Alle Z-Steller gleich','Z-Verschiebung des Tischs'],['Y1 und Y2 gleich','Y-Verschiebung'],['Y1 / Y2 gegensinnig','Drehung um Z; Abstand 120 mm'],['Z3 gegen hintere Z-Steller','Drehung um X; wirksamer Abstand 80 mm'],['Z1 / Z2 gegensinnig','Drehung um Y, gekoppelt mit Z3'],['Nur X','X-Verschiebung']],[65,113],y)
y=para('Mit r = (0, 125, -8) mm vom Tischbezugspunkt zum Trägerzentrum gilt: <b>Δp = Δt + ω × r</b>. Ein Winkelwechsel verschiebt daher auch den Träger. Das beiliegende <b>src/adjust.py</b> berechnet die sechs Schraubenumdrehungen für eine gewünschte kleine Trägerbewegung; danach immer optisch nachführen.',y)
y=heading('Was tatsächlich gerechnet wurde',y)
checks=json.loads((ROOT/'validation/analytic_checks.json').read_text())
minreaction=min(min(v['contact_forces_N']) for v in checks['static_load_cases'])
y=para(f'Kontaktmatrix Rang 6. An allen 64 Ecken des vorgesehenen kleinen Lagebereichs bleiben die modellierten Fangbolzen frei, mit zusätzlich 0,3 mm Fertigungsreserve. 16 statische Lastfälle mit angenommenen Bauteilmassen liefern positive Kontaktkräfte (Minimum {minreaction:.2f} N). Dies prüft weder dynamische Stöße noch Reibung oder thermische Drift.',y)
y=para('Eine einfache Balkenrechnung für die Gabel ergibt bei 50 g Zusatzlast rund 0,46 µm elastische Durchbiegung des idealisierten 25-mm-Überhangs. Schraubverbindungen, Schlitze, Träger und Tisch sind darin nicht enthalten. Die Zahl ist daher keine Gesamtsteifigkeit und kein Entlastungsfehler.',y)
y=note('Wenn die gemessene Stellbarkeit nicht genügt: zuerst Spitzen/Kontakte verbessern; anschließend betroffene Achsen mit passenden Fein- oder Differentialstellern und neuem Adapter ausrüsten. Als Marktbeispiel existieren Differentialsteller mit 25 µm/Umdrehung. Ihr Gewinde passt nicht automatisch in diese M4-Muttern.',y)

y=page('Prüfung vor dem ersten Verkleben','Messblatt und Grenzwerte zuerst festlegen, anschließend Daten aufnehmen.')
y=table([['Prüfung','Durchführung / Kriterium'],['Sitz und Spielfreiheit','Dummy bis 50 g; sämtliche Kontakte bleiben im Arbeitsbereich geschlossen. Fangbolzen sind frei. Keine losen Muttern und keine Schraubenspitze im Loch.'],['Stellbarkeit','Je Achse fünf kleine gleiche Schritte in beide Richtungen; Strahllage und Schraubenwinkel protokollieren. Sprünge, Totgang und Übersprechen sichtbar machen.'],['Zeitdrift','Referenzspiegel und Jig-Dummy 30 Minuten bei stabiler Temperatur beobachten; keine Härtung.'],['Bedienwiederholung','Zehn Anfahrten desselben Sollpunkts aus derselben Richtung; Rohwerte behalten.'],['Übergabe / Ablösen','Dummy auf separater Unterlage halten; Schraubenlösen, Anheben und Abziehen getrennt beobachten. Erst danach mit Probeklebung wiederholen.'],['Optische Freigabe','Jig-Drift plus Messunsicherheit und Übergabefehler müssen im zuvor gemessenen Toleranzbudget der echten Quelle liegen.']],[45,133],y)
y=para('Vorgeschlagene reine Screening-Ziele: höchstens 20 µrad Winkeldrift in 30 Minuten und höchstens 50 µrad Wiederanfahrstreuung als maximale Abweichung vom Ausgangswert. Diese selbst gewählten Ziele sind keine Sagnac-Spezifikation. Wenn das Quellenbudget enger ist, gelten die engeren Werte.',y)
y=para('Bei festem Strahlversatz gilt im einfachen Reflexionsaufbau Δx ≈ 2LΔθ. Bei L=1 m entsprechen 20 µrad ungefähr 40 µm Punktverschiebung. Eine einzelne Kamera-/PSD-Ebene trennt Winkel und Versatz nicht. Für diesen Screeninglauf die tatsächliche Punktstabilität berichten; Winkelaussagen benötigen zusätzliche Kalibrierung oder zwei Messebenen.',y)
y=heading('UV-Zugang bleibt eine Eigenschaft der Klebestelle',y)
y=para('Der Jig schafft seitlichen Zugang, macht aber eine verdeckte Metall-Metall-Fuge nicht UV-härtbar. NOA61 nennt 350-380 nm und 3 J/cm²; das ersetzt keinen Nachweis der Dosis in der ganzen Fuge. Handlampenzeit nicht pauschal auf 10 Sekunden setzen. Unterbaugruppen separat qualifizieren; das bestehende Spiegelprotokoll bleibt maßgeblich.',y)

y=page('Kosten und Fertigungsauftrag','Schweizer Rahmen, ohne Kauf oder Reservierung. Preise recherchiert am 11.10.2026.')
y=table([['Position','Eigene Materialschätzung'],['Aluplatten, Flachmaterial, Winkel, Stahlgewicht','35-70 CHF'],['Schrauben, Hülsen, Füße und passende Federn','30-55 CHF'],['Kontaktmaterial und kleine Druckteile','15-35 CHF'],['Reserve / Kleinteile','10-20 CHF'],['Planungsrahmen insgesamt','90-180 CHF, ohne Werkzeug, Arbeitszeit, Versand und Maschinen-/Kursgebühren']],[110,68],y)
y=para('Als Größenordnung nennt FabLab Bern 36 CHF pro Stunde ohne Jahreskarte; Maschinen erfordern Einführungskurse. Für bestimmte Maschinen gibt es eigene zeitabhängige Tarife. Deshalb Zuschnitte beschaffen und Sägen/Bohren möglichst außerhalb bezahlter Maschinenzeit vorbereiten. Die Materialschätzung ist kein eingeholtes Angebot.',y)
y=heading('So kann das FabLab den Auftrag lesen',y)
y=para('„Bitte P01-P05 und P07 als einfache Metallteile nach beigefügten STEP-Dateien und Bohrschablonen herstellen; P06 aus Winkelprofil bohren; P08 aus Stahlwinkel oder gekantetem Blech. D01/D02 zunächst je einmal zur Passprobe drucken. Keine optische Oberflächenbearbeitung. Bitte die Material- und Maschinenkosten vorab getrennt angeben.“',y)
y=heading('Quellen und Abgrenzung',y)
for text in [
 'Norland NOA61, Herstellerdatenblatt: norlandproducts.com/wp-content/uploads/2025/02/Norland-Products-NOA-61-TDS.pdf',
 'Ganter GN 605: ganternorm.com, Produkt „Ball Point Screws GN 605“. M4-Kugelvarianten existieren; die recherchierten kurzen Längen sind kein direkter M4×40-Ersatz.',
 'Thorlabs: thorlabs.com/quarter-inch--80-fine-hex-adjusters (Beispiel Differentialverstellung; proprietäre Gewinde/Buchsen separat prüfen).',
 'FabLab Bern, veröffentlichte Tarife: fablab-bern.ch/preise/ sowie fablab-bern.ch/angebot-2/. Kurse, Material und Eigenleistung getrennt kalkulieren.',
 'Alle Geometrien und Rechnungen dieses Pakets sind eigene Entwürfe. CAD-Gültigkeit, rechnerische Kontaktfreiheit und Rangprüfung ersetzen keine Bau- und Messprüfung.'
 ]:y=para(text,y,style='small')

PARTS=json.loads((ROOT/'cad/parts.json').read_text())
def drill_template(name,cx,cy):
 p=PARTS[name];w,h=p['width'],p['depth'];c.setStrokeColor(INK);c.setLineWidth(.4)
 c.rect((cx-w/2)*mm,(cy-h/2)*mm,w*mm,h*mm)
 c.setFont('DB',8);c.drawString((cx-w/2)*mm,(cy+h/2+4)*mm,f'{name} | {w} × {h} × {p["thickness"]} mm')
 for x,y,d in p.get('holes',[]):
    xx,yy=(cx+x)*mm,(cy+y)*mm;c.circle(xx,yy,d*mm/2)
    c.setLineWidth(.2);c.line(xx-2*mm,yy,xx+2*mm,yy);c.line(xx,yy-2*mm,xx,yy+2*mm)
    c.setFont('D',5.5);c.drawString(xx+2.2*mm,yy+1.5*mm,str(d))
 for x,y0,y1,d in p.get('slots',[]):
    c.roundRect((cx+x-d/2)*mm,(cy+y0-d/2)*mm,d*mm,(y1-y0+d)*mm,d*mm/2)
 for x,y0,d in p.get('open_slots',[]):
    c.setStrokeColor(colors.white);c.setLineWidth(1);c.line((cx+x-d/2)*mm,(cy+h/2)*mm,(cx+x+d/2)*mm,(cy+h/2)*mm)
    c.setStrokeColor(INK);c.setLineWidth(.4)
    c.line((cx+x-d/2)*mm,(cy+y0)*mm,(cx+x-d/2)*mm,(cy+h/2)*mm)
    c.line((cx+x+d/2)*mm,(cy+y0)*mm,(cx+x+d/2)*mm,(cy+h/2)*mm)
    c.arc((cx+x-d/2)*mm,(cy+y0-d/2)*mm,(cx+x+d/2)*mm,(cy+y0+d/2)*mm,startAng=180,extent=180)
 c.setFont('D',6);c.setFillColor(MUTED);c.drawString((cx-w/2)*mm,(cy-h/2-4)*mm,'Zahlen an Kreisen: Bohrdurchmesser; Maße in mm.')
def scale_bar(x,y):
 c.setStrokeColor(INK);c.setLineWidth(1);c.line(x*mm,y*mm,(x+100)*mm,y*mm)
 for a in range(0,101,10):c.line((x+a)*mm,(y-1.5)*mm,(x+a)*mm,(y+1.5)*mm)
 c.setFont('DB',8);c.setFillColor(INK);c.drawString(x*mm,(y+4)*mm,'Kontrollmaß 100 mm - Druck 100 %, keine Anpassung')
y=page('Grundplatte P01 - 1:1','A3 quer. Umriss 240 × 220 mm. Schablone mit der tatsächlich gemessenen Druckskalierung prüfen.',landscape(A3))
drill_template('P01_base',140,135);scale_bar(277,40)
para('<b>Bohrbild P01</b><br/><br/>Alle Bohrungen durchgehend.<br/><br/>Ø4,5: M4-Durchgang.<br/>Ø3,3: M3-Durchgang.<br/>Ø6,5: M6-Füße.<br/><br/>Keine Gewinde in P01.<br/><br/>Bezug: Mitte der Platte.<br/>+Y zeigt nach oben, zur Optik.<br/><br/>Die Grundplatte ist kein optischer Referenzspiegel. Sie muss sich stabil auf drei Füßen abstützen und mit der Modulunterlage steif verbunden sein.',218,x=277,width=125)
y=page('Tischplatte und Arm - 1:1','A4 hoch. P02: sechs Ø2,5-Bohrungen anschließend M3×0,5 schneiden; alle übrigen Durchgang.')
drill_template('P02_moving',105,174);drill_template('P03_arm',50,65)
para('<b>P03</b><br/>Alle sechs Bohrungen Ø4,5 durch.<br/><br/>Vier Bohrungen befestigen den Arm auf P02.<br/>Die beiden vorderen halten P04.<br/><br/>+Y zeigt jeweils nach oben.<br/>P03-Mittelpunkt später bei Y=60.',97,x=83,width=107)
scale_bar(85,27)
y=page('Gabel und Kleinteile - 1:1','A4 hoch. Vor dem Verkleben den kompletten Rückzug der Gabel am Dummy ausprobieren.')
drill_template('P04_release_fork',43,204)
para('<b>P04</b><br/>Zwei geschlossene Langlöcher: Breite 4,5; Kreiszentren Y=-27 und +8.<br/><br/>Offene Schlitze: Breite 4,2; X=±6; unteres Halbkreiszentrum Y=15. Nach +Y offen.<br/><br/>Lokaler Nullpunkt: Plattenmitte.<br/>Scharfe Kanten entfernen.',241,x=72,width=121)
drill_template('P05_ballast',72,137);drill_template('P07_pad',165,137)
para('<b>P06: 3 Stück</b><br/>Winkel 25×25×3, Länge 30. Fußlöcher X=±8, Abstand 13 von der inneren Stegfläche; Ø4,5. Steglöcher auf Höhe 18 über der Unterseite: X=0 Ø4,5; X=±10 Ø3,3.<br/><br/><b>P08: 3 Stück</b><br/>Winkel 10×10×1, Länge 25. Löcher im oberen Schenkel: X=±8, Abstand 4,5 von der Plattenkante nach innen; Ø3,3. Senkrechter Schenkel außen, von 9 mm unter bis 1 mm über der Tischoberseite.<br/><br/>P06/P08: Maße und STEP verwenden; Winkel sind hier nicht als abwickelbare Laserteile dargestellt. Biegeradius am realen Profil berücksichtigen.',111)
scale_bar(16,24)
c.save()
print(json.dumps({'pdf':str(out),'pages':page_no}))
