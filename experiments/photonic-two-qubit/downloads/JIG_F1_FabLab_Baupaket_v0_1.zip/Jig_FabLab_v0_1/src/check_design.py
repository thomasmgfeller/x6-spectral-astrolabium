"""Analytic design checks, not physical validation. Units: mm, N, rad."""
from pathlib import Path
import itertools,json,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
A=np.array([[0,0,1,-40,60,0],[0,0,1,-40,-60,0],[0,0,1,40,-20,0],
            [0,1,0,0,0,-60],[0,1,0,0,0,60],[1,0,0,0,0,0]],float)
assert np.linalg.matrix_rank(A)==6
limits=np.array([1,1,.5,*([math.radians(.2)]*3)])
max_stroke=np.zeros(6);max_catch_radial=0.;max_lift=0.
catch=np.array([[-60,-20,3],[60,-20,3],[40,50,3]])
for signs in itertools.product([-1,1],repeat=6):
    q=limits*np.array(signs);max_stroke=np.maximum(max_stroke,abs(A@q))
    for r in catch:
        displacement=q[:3]+np.cross(q[3:],r)
        max_catch_radial=max(max_catch_radial,float(np.linalg.norm(displacement[:2])))
        max_lift=max(max_lift,abs(float(displacement[2])))
assert np.all(max_stroke<1.5)
assert max_catch_radial+.3<2.5 # 8 mm hole minus 3 mm rod, tolerance reserve
assert max_lift+.3<2 # washer 2 mm above nominal plate
# Conservative contact load model: zero friction, applied point masses and springs.
# Forces at spring anchors Z=34, contacts Z=26 -> 8 mm moment arm.
loads=[]
for payload in (0,.05):
 for fx,fl,fr in itertools.product((.8,1.2),repeat=3):
    F=np.array([-fx,-fl-fr,-(.31+.19+.08+.03+payload)*9.81,8*(fl+fr),-8*fx,35*fx+30*(fl-fr)],float)
    for m,y in [(.19,-25),(.08,60),(.03,105),(payload,125)]:F[3]-=m*9.81*y
    reaction=np.linalg.solve(A.T,-F);assert np.all(reaction>.2)
    loads.append({'payload_kg':payload,'spring_N':[fx,fl,fr],'contact_forces_N':reaction.tolist()})
# Simple beam estimate, only incremental deflection from 50 g payload on fork.
P=.05*9.81;E=69000;b=36;t=3;L=25;I=b*t**3/12
beam=P*L**3/(3*E*I)
out={'status':'PASS_ANALYTIC_CHECKS_ONLY','contact_matrix_rank':6,'contact_matrix':A.tolist(),
 'pose_box_mm_rad':limits.tolist(),'corner_samples':64,'max_actuator_travel_mm':max_stroke.tolist(),
 'max_catch_radial_mm':max_catch_radial,'catch_radial_clearance_mm':2.5,
 'max_catch_lift_mm':max_lift,'catch_axial_clearance_mm':2,
 'reserved_manufacturing_error_mm':.3,'static_load_cases':loads,
 'fork_incremental_tip_deflection_um':beam*1000,
 'scope':'Small-angle rigid-body model; no friction, thermal drift, bearing indentation, joints or manufacturing variation model. No FEA or hardware verification.'}
(ROOT/'validation'/'analytic_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
