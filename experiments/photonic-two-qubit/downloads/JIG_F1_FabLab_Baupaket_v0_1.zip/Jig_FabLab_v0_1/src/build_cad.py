"""JIG-F1: own parametric prototype geometry; units mm. CadQuery 2.7.
Run from package root: python3 src/build_cad.py
Threads/springs/commodity fasteners in the assembly are schematic.
Manufacturing dimensions: parts.json and drawing PDF; not render pixels.
"""
from pathlib import Path
import json, math
import cadquery as cq
import ezdxf

ROOT = Path(__file__).resolve().parents[1]
for d in ['cad','drawings','print','validation']:(ROOT/d).mkdir(exist_ok=True)
parts = {}
def plate(name,w,h,t,holes=(),slots=(),open_slots=()):
    s=cq.Workplane('XY').box(w,h,t,centered=(True,True,False))
    for x,y,d in holes:
        s=s.cut(cq.Workplane('XY').center(x,y).circle(d/2).extrude(t+2).translate((0,0,-1)))
    for x,y0,y1,d in slots:
        cut=cq.Workplane('XY').center(x,(y0+y1)/2).slot2D(y1-y0+d,d,90).extrude(t+2).translate((0,0,-1))
        s=s.cut(cut)
    for x,y0,d in open_slots:
        cut=cq.Workplane('XY').center(x,y0).circle(d/2).extrude(t+2).translate((0,0,-1))
        rect=cq.Workplane('XY').box(d,h/2-y0+2,t+2,centered=(True,False,False)).translate((x,y0,-1))
        s=s.cut(cut.union(rect))
    parts[name]={'width':w,'depth':h,'thickness':t,'holes':list(holes),'slots':list(slots),'open_slots':list(open_slots),'origin':'centre XY, underside Z=0','material':'Aluminium unless noted'}
    return s
Z=[(-60,-40),(60,-40),(20,40)]
GUIDE=[(-60,-20),(60,-20),(40,50)]
MOBILE_ANCHOR=[(-70,35),(-30,-50),(30,-50)]
FIXED_ANCHOR=[(-110,35),(-30,-95),(30,-95)]
baseholes=[(x,y,4.5) for x,y in Z]
baseholes += [(x+dx,y,3.3) for x,y in Z for dx in (-10,10)]
baseholes += [(x,y,3.3) for x,y in GUIDE+FIXED_ANCHOR]
baseholes += [(x,y,6.5) for x,y in [(-105,-95),(105,-95),(0,95)]]
baseholes += [(x+dx,-88,4.5) for x in (-60,60) for dx in (-8,8)]
baseholes += [(-108,y,4.5) for y in (-8,8)]
base=plate('P01_base',240,220,8,baseholes)
mobileholes=[(x,y,8) for x,y in GUIDE]+[(x,y,3.3) for x,y in MOBILE_ANCHOR]
mobileholes += [(x+dx,y,2.5) for x,y in Z for dx in (-7,7)]
mobileholes += [(x+dx,-55.5,3.3) for x in (-60,60) for dx in (-8,8)]
mobileholes += [(-75.5,y,3.3) for y in (-8,8)]
mobileholes += [(x,y,4.5) for x in (-12,12) for y in (25,45)]
mobileholes += [(-35,-25,4.5),(35,-25,4.5)]
mobile=plate('P02_moving',160,120,6,mobileholes)
parts['P02_moving']['note']='Six diameter-2.5 pilot holes for pad fasteners: tap M3x0.5 through. Use M3x6 from below, no protrusion above plate.'
# Arm local Y=0 at global Y=60; fork local Y=0 at global Y=105.
arm=plate('P03_arm',40,80,8,[(x,y-60,4.5) for x in (-12,12) for y in (25,45)]+[(-11,25,4.5),(11,25,4.5)])
fork=plate('P04_release_fork',36,70,3,slots=[(-11,-27,8,4.5),(11,-27,8,4.5)],open_slots=[(-6,15,4.2),(6,15,4.2)])
ballast=plate('P05_ballast',100,30,8,[(-35,0,4.5),(35,0,4.5)])
parts['P05_ballast']['material']='Steel; ballast, not aluminium'
pad=plate('P07_pad',20,20,1,[(-7,0,3.3),(7,0,3.3)])
parts['P07_pad']['material']='Steel contact strip; inspect indentation; no adhesive'
# Fixed bracket: inner vertical face Y=0; underside Z=0.
br=cq.Workplane('XY').box(30,25,3,centered=(True,False,False)).translate((0,-25,0))
br=br.union(cq.Workplane('XY').box(30,3,25,centered=(True,False,False)).translate((0,-3,0)))
for x in (-8,8): br=br.cut(cq.Workplane('XY').center(x,-13).circle(2.25).extrude(5).translate((0,0,-1)))
for x,d in [(0,4.5),(-10,3.3),(10,3.3)]:
    br=br.cut(cq.Workplane('XZ').center(x,18).circle(d/2).extrude(6,both=True))
parts['P06_angle']={'material':'Aluminium angle 25 x 25 x 3, cut length 30','quantity':3,'base_holes':[[-8,-13,4.5],[8,-13,4.5]],'upright_holes':[[-10,18,3.3],[0,18,4.5],[10,18,3.3]],'origin':'upright inner face Y=0; underside Z=0'}
# Moving steel edge shoe. Horizontal flange Z=0..1, vertical leg Z=-9..1.
shoe=cq.Workplane('XY').box(25,10,1,centered=(True,False,False)).translate((0,-1,0))
shoe=shoe.union(cq.Workplane('XY').box(25,1,10,centered=(True,False,False)).translate((0,-1,-9)))
for x in (-8,8):shoe=shoe.cut(cq.Workplane('XY').center(x,4.5).circle(1.65).extrude(3).translate((0,0,-1)))
parts['P08_edge_shoe']={'material':'Steel angle 10 x 10 x 1, cut length 25; alternatively bend in vise','quantity':3,'top_holes':[[-8,4.5,3.3],[8,4.5,3.3]],'origin':'outer plate edge Y=0; plate top Z=0'}
# Printed nut keeper: axial screw load goes directly from steel nut into metal.
keeper=plate('D01_nut_keeper',30,14,5,[(-10,0,3.3),(10,0,3.3),(0,0,4.6)])
keeper=keeper.cut(cq.Workplane('XY').polygon(6,7.4/math.cos(math.pi/6)).extrude(3.4))
parts['D01_nut_keeper']['material']='PLA/PETG; antirotation only; print pocket upward'
knob=cq.Workplane('XY').circle(14).extrude(8)
knob=knob.cut(cq.Workplane('XY').polygon(6,7.3/math.cos(math.pi/6)).extrude(4).translate((0,0,4)))
knob=knob.cut(cq.Workplane('XY').circle(2.25).extrude(10))
parts['D02_knob']={'material':'PLA/PETG, knob only','diameter':28,'height':8,'head_socket_AF':7.3,'quantity':6,'note':'M4 hex head; adapt pocket to actual head; optional glue only inside knob'}
carrier=plate('REF_carrier',20,20,20)
for x in (-6,6): carrier=carrier.cut(cq.Workplane('XY').center(x,0).circle(1.25).extrude(12).translate((0,0,9)))
parts['REF_carrier']['note']='Reference only: two M3x0.5 blind tapped holes, 11 mm drill depth, >=9 mm useful thread. M3x20 flange-head screws engage 8 mm. Actual optic cell not designed here.'
shapes={'P01_base':base,'P02_moving':mobile,'P03_arm':arm,'P04_release_fork':fork,'P05_ballast':ballast,'P06_angle':br,'P07_pad':pad,'P08_edge_shoe':shoe,'D01_nut_keeper':keeper,'D02_knob':knob,'REF_carrier':carrier}
for name,s in shapes.items():
    cq.exporters.export(s,str(ROOT/'cad'/f'{name}.step'))
    if name.startswith('D'):cq.exporters.export(s,str(ROOT/'print'/f'{name}.stl'),tolerance=.08,angularTolerance=.1)
    if name in parts and 'width' in parts[name] and name!='REF_carrier':
        # Exact planar sections export all hole/slot boundaries; excludes keeper pocket.
        w,h,t=parts[name]['width'],parts[name]['depth'],parts[name]['thickness']
        doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace()
        m.add_lwpolyline([(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)],close=True)
        for x,y,d in parts[name]['holes']:m.add_circle((x,y),d/2)
        for x,y0,y1,d in parts[name]['slots']:
            r=d/2;m.add_line((x-r,y0),(x-r,y1));m.add_line((x+r,y0),(x+r,y1));m.add_arc((x,y0),r,180,360);m.add_arc((x,y1),r,0,180)
        # Open slots are represented as separate machining features on layer SLOTS;
        # the rectangle is a stock outline, not a ready-to-laser closed contour.
        for x,y0,d in parts[name]['open_slots']:
            r=d/2;m.add_line((x-r,y0),(x-r,h/2),dxfattribs={'layer':'SLOTS'});m.add_line((x+r,y0),(x+r,h/2),dxfattribs={'layer':'SLOTS'});m.add_arc((x,y0),r,180,360,dxfattribs={'layer':'SLOTS'})
        doc.saveas(ROOT/'drawings'/f'{name}.dxf')
assembly=cq.Assembly(name='JIG_F1_v01')
render=[]
def add(name,shape,color,pos=(0,0,0),rot=0):
    s=shape.rotate((0,0,0),(0,0,1),rot).translate(pos)
    assembly.add(s,name=name,color=cq.Color(*color));render.append((name,s,color))
AL=(.67,.73,.77);BLUE=(.18,.37,.53);STEEL=(.3,.33,.36);ORANGE=(.93,.48,.17);GREEN=(.23,.55,.43)
add('base',base,AL);add('moving',mobile,BLUE,(0,0,23));add('arm',arm,AL,(0,60,29));add('release_fork',fork,ORANGE,(0,105,37));add('ballast',ballast,STEEL,(0,-25,29))
add('carrier_REFERENCE',carrier,GREEN,(0,125,8))
for i,(x,y) in enumerate(Z):
    add(f'pad_{i}',pad,STEEL,(x,y,22));add(f'nut_keeper_Z{i+1}',keeper,ORANGE,(x,y,8))
    add(f'Z{i+1}_shaft',cq.Workplane('XY').circle(2).extrude(38.5).union(cq.Workplane('XY').sphere(1.5).translate((0,0,38.5))),STEEL,(x,y,-18))
    add(f'Z{i+1}_knob',knob,ORANGE,(x,y,-26))
    add(f'Z{i+1}_nut',cq.Workplane('XY').polygon(6,7/math.cos(math.pi/6)).extrude(3.2).cut(cq.Workplane('XY').circle(2).extrude(4)),STEEL,(x,y,8))
for i,x in enumerate((-60,60)):
    add(f'Y{i+1}_fixed',br,AL,(x,-75,8));add(f'Y{i+1}_shoe',shoe,STEEL,(x,-60,29))
    # Local +Z mapped to +Y; keeper pocket against bracket inner face.
    add(f'Y{i+1}_keeper',keeper.rotate((0,0,0),(1,0,0),-90),ORANGE,(x,-75,26))
    sh=cq.Workplane('XY').circle(2).extrude(38.5).union(cq.Workplane('XY').sphere(1.5).translate((0,0,38.5)))
    add(f'Y{i+1}_shaft',sh.rotate((0,0,0),(1,0,0),-90),STEEL,(x,-101,26))
    add(f'Y{i+1}_knob',knob.rotate((0,0,0),(1,0,0),-90),ORANGE,(x,-109,26))
add('X_fixed',br,AL,(-95,0,8),-90);add('X_shoe',shoe,STEEL,(-80,0,29),-90)
add('X_keeper',keeper.rotate((0,0,0),(1,0,0),-90).rotate((0,0,0),(0,0,1),-90),ORANGE,(-95,0,26))
sh=cq.Workplane('XY').circle(2).extrude(38.5).union(cq.Workplane('XY').sphere(1.5).translate((0,0,38.5)))
add('X_shaft',sh.rotate((0,0,0),(0,1,0),90),STEEL,(-121,0,26))
add('X_knob',knob.rotate((0,0,0),(0,1,0),90),ORANGE,(-129,0,26))
for i,(x,y) in enumerate([(-105,-95),(105,-95),(0,95)]):add(f'foot_{i}',cq.Workplane('XY').circle(7).extrude(50),STEEL,(x,y,-50))
for i,(x,y) in enumerate(GUIDE):
    add(f'catch_rod_{i}',cq.Workplane('XY').circle(1.5).extrude(35),STEEL,(x,y,0))
    add(f'catch_washer_{i}',cq.Workplane('XY').circle(6).circle(1.7).extrude(1),STEEL,(x,y,31))
for i,(x,y) in enumerate(FIXED_ANCHOR+MOBILE_ANCHOR):
    z=8 if i<3 else 29
    add(f'spring_anchor_{i}',cq.Workplane('XY').circle(1.5).extrude(34-z),STEEL,(x,y,z))
for i,(a,b) in enumerate(zip(FIXED_ANCHOR,MOBILE_ANCHOR)):
    # Schematic straight spring envelope, not a spring manufacturing file.
    ax,ay=a;bx,by=b;dx,dy=bx-ax,by-ay;L=math.hypot(dx,dy)
    env=cq.Workplane('XY').circle(2).extrude(L).rotate((0,0,0),(0,1,0),90).rotate((0,0,0),(0,0,1),math.degrees(math.atan2(dy,dx)))
    add(f'spring_envelope_{i}',env,GREEN,(ax,ay,34))
for x in (-6,6):
    add(f'spacer_{x}',cq.Workplane('XY').circle(3).circle(1.6).extrude(9),STEEL,(x,125,28))
    screw=cq.Workplane('XY').circle(1.5).extrude(20).union(cq.Workplane('XY').circle(3.5).extrude(2).translate((0,0,20)))
    add(f'handling_screw_{x}',screw,STEEL,(x,125,20))
assembly.export(str(ROOT/'cad'/'JIG_F1_assembly.step'))
# Nominal positive-volume intersections of physical solids. Threaded engagement
# is intentional, spring envelopes are only schematic and excluded.
collisions=[]
for i,(n,a,c) in enumerate(render):
    if 'spring_envelope' in n:continue
    for m,b,d in render[i+1:]:
        if 'spring_envelope' in m:continue
        if 'carrier_REFERENCE' in (n,m) and (n.startswith('handling_screw') or m.startswith('handling_screw')):continue
        ba,bb=a.val().BoundingBox(),b.val().BoundingBox()
        overlap=all(min(getattr(ba,k+'max'),getattr(bb,k+'max'))-max(getattr(ba,k+'min'),getattr(bb,k+'min'))>1e-5 for k in 'xyz')
        if overlap:
            v=a.val().intersect(b.val()).Volume()
            if v>1e-5:collisions.append({'a':n,'b':m,'volume_mm3':v})
(ROOT/'validation'/'nominal_collisions.json').write_text(json.dumps({'unexpected':collisions,'exclusions':['schematic spring envelopes','intentional carrier screw thread engagement'],'scope':'nominal modeled solids only; omitted commodity fasteners require workshop dry fit'},indent=2)+'\n')
assert not collisions,collisions
# Test the proposed straight fork withdrawal after 1 mm head lift and 0.3 mm
# equal Z lift. Includes simplified M4 mounting shafts inside the long slots.
obstacles=[(n,s.translate((0,0,1)) if n.startswith('handling_screw') else s)
           for n,s,color in render if n=='carrier_REFERENCE' or n.startswith('spacer_') or n.startswith('handling_screw')]
for x in (-11,11):obstacles.append((f'fork_mount_{x}',cq.Workplane('XY').circle(2).extrude(20).translate((x,85,27))))
release_hits=[]
for j in range(51):
    moved=fork.translate((0,105-j*.5,37.3))
    for n,s in obstacles:
        volume=moved.val().intersect(s.val()).Volume()
        if volume>1e-5:release_hits.append({'withdrawal_mm':j*.5,'obstacle':n,'volume_mm3':volume})
(ROOT/'validation'/'release_checks.json').write_text(json.dumps({'samples':51,'path_mm':25,'Z_lift_mm':.3,'head_lift_mm':1,'intersections':release_hits,'scope':'nominal geometric sample check; no friction/elasticity or curing model'},indent=2)+'\n')
assert not release_hits,release_hits
(ROOT/'cad'/'parts.json').write_text(json.dumps(parts,indent=2,ensure_ascii=False)+'\n')
validation={n:{'valid':s.val().isValid(),'volume_mm3':round(s.val().Volume(),3),'solids':len(s.solids().vals())} for n,s in shapes.items()}
assert all(x['valid'] and x['volume_mm3']>0 and x['solids']==1 for x in validation.values())
(ROOT/'validation'/'cad_solids.json').write_text(json.dumps(validation,indent=2)+'\n')
# Deterministic orthographic software rasterizer: true per-pixel depth buffer.
# Does not need an X server or GPU. Images come directly from CAD triangles.
import numpy as np
from PIL import Image
for view,eye in [('assembly',(330,460,330)),('rear',(-350,-420,320))]:
    direction=np.array(eye,dtype=float)-np.array([0,10,5]);direction/=np.linalg.norm(direction)
    right=np.cross(direction,[0,0,1]);right/=np.linalg.norm(right);up=np.cross(right,direction)
    tris=[];cols=[]
    for n,s,color in render:
        vs,fs=s.val().tessellate(.18,.16)
        vertices=np.array([(v.x,v.y,v.z) for v in vs])
        for face in fs:
            triangle=vertices[list(face)];normal=np.cross(triangle[1]-triangle[0],triangle[2]-triangle[0]);normal/=max(np.linalg.norm(normal),1e-12)
            shade=.7+.3*max(0,float(normal@np.array([.3,.2,.933])))
            projected=np.stack([triangle@right,triangle@up,triangle@direction],axis=1)
            tris.append(projected);cols.append(np.array(color)*shade*255)
    tris=np.array(tris);width,height=1500,1080
    lo=tris[:,:,:2].min(axis=(0,1));hi=tris[:,:,:2].max(axis=(0,1));mid=(lo+hi)/2
    scale=min((width-120)/(hi[0]-lo[0]),(height-120)/(hi[1]-lo[1]))
    tris[:,:,0]=(tris[:,:,0]-mid[0])*scale+width/2
    tris[:,:,1]=height/2-(tris[:,:,1]-mid[1])*scale
    pixels=np.full((height,width,3),[244,248,251],dtype=np.uint8);depth=np.full((height,width),-np.inf)
    for tri,color in zip(tris,cols):
        xmin=max(0,int(np.floor(tri[:,0].min())));xmax=min(width-1,int(np.ceil(tri[:,0].max())))
        ymin=max(0,int(np.floor(tri[:,1].min())));ymax=min(height-1,int(np.ceil(tri[:,1].max())))
        if xmin>xmax or ymin>ymax:continue
        x,y=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5)
        a,b,d=tri;den=(b[1]-d[1])*(a[0]-d[0])+(d[0]-b[0])*(a[1]-d[1])
        if abs(den)<1e-10:continue
        wa=((b[1]-d[1])*(x-d[0])+(d[0]-b[0])*(y-d[1]))/den
        wb=((d[1]-a[1])*(x-d[0])+(a[0]-d[0])*(y-d[1]))/den;wc=1-wa-wb
        z=wa*a[2]+wb*b[2]+wc*d[2]
        section=depth[ymin:ymax+1,xmin:xmax+1]
        mask=(wa>=-1e-9)&(wb>=-1e-9)&(wc>=-1e-9)&(z>section)
        section[mask]=z[mask];pixels[ymin:ymax+1,xmin:xmax+1][mask]=color.astype(np.uint8)
    Image.fromarray(pixels).save(ROOT/'drawings'/f'{view}.png')
print(json.dumps({'parts':len(shapes),'assembly_components':len(render),'all_solids_valid':True}))
