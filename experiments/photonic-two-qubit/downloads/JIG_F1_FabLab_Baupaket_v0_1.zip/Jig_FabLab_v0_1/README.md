# JIG-F1 v0.1 - wiederverwendbarer Justierjig

Stand 11.10.2026. Eigener Konstruktionsentwurf für einen ersten Werkstattprototyp.
Noch nicht gefertigt, vermessen oder für einen Sagnac freigegeben.

Zuerst `JIG_F1_Bauanleitung.pdf` lesen. Sie enthält Stückliste, Montage,
Ablösefolge, Prüfplan sowie A3-/A4-Bohrschablonen in 1:1.

## Fertigung ohne Präzisionsmaschinen

- Aluminium-Zuschnitte, drei Winkelprofile und ein Stahlgewicht.
- Metallsäge, Schraubstock, Bohrständer/Bohrmaschine, Feilen und M3-Handgewindebohrer.
- Sechs Knöpfe und sechs Mutternhalter aus dem FabLab-Drucker oder entsprechende
  Eigenbau-/Kaufteile. Gedruckte Teile bilden keine Präzisionsführung.
- CNC ist optional; ein üblicher Holz-/Acryl-CO2-Laser schneidet diese
  Aluminiumplatten nicht. DXF-Dateien sind Bohr-/Bearbeitungsvorlagen, keine
  fertigen CAM-Jobs. Offene Gabelschlitze liegen als Bearbeitungsmerkmale vor.

## Enthalten

- `cad/JIG_F1_assembly.step`: Baugruppe, 58 modellierte Komponenten, Normteile teils vereinfacht.
- `cad/*.step`: elf Einzelteil-/Referenzgeometrien; `parts.json` mit Bohrbildern.
- `drawings/*.dxf`: ebene Umrisse und Bearbeitungsmerkmale in mm.
- `print/*.stl`: D01-Mutternhalter und D02-Knopf, jeweils sechsmal benötigt.
- `src/build_cad.py`: editierbare CAD-Quelle (CadQuery 2.7, ezdxf, NumPy, Pillow).
- `src/check_design.py`: Rang, Arbeitsbereich und statische Lastfälle (NumPy).
- `src/adjust.py`: erste Näherung der Schraubenbewegungen (NumPy).
- `src/build_manual.py`: reproduzierbare PDF-Erstellung (ReportLab, DejaVu-Fonts).
- `validation/*.json`: ausgeführte geometrische/rechnerische Prüfungen.
- `docs/qualification_template.json`: leeres Messprotokoll; keine erfundenen Messwerte.

## Schnittstelle und Geltungsbereich

Referenzträger: 20 x 20 x 20 mm, zwei M3-Gewinde oben im Abstand 12 mm.
Zwei 9-mm-Metallhülsen und zwei M3x20-Flanschkopfschrauben halten ihn an einer
36 x 70 x 3-mm-Alugabel. Diese wird nach der Härtung freigestellt und 25 mm
nach hinten abgezogen. Die Gewinde sitzen im Metallträger, niemals im Glas.
Andere Träger, ein PBS, Kristallhalter oder deren optische Fassungen sind
separat anzupassen; der Dummy stellt keine optische Fassung dar.

Der Jig braucht seitlich Platz und einen freien Zugang zur Montageoberseite.
Die tatsächlichen Strahlen einschließlich aller PBS-Ports sowie UV-Zugänge
müssen im Trockenaufbau geprüft werden. Ein Prüfstand mit versperrtem Pump-/
Signal-/Idlerweg darf nicht als bereits justierbarer Sagnac bezeichnet werden.

Vorgesehener kleiner Lagebereich des Tischs: X/Y ±1 mm, Z ±0,5 mm,
drei Winkel je ±0,2 Grad. Nutzlast bis 50 g ist ein Auslegungsziel.
Diese Angaben sind keine gemessene Genauigkeit, Wiederholbarkeit oder Traglast.
M4x0,7 ist eine günstige Anfangslösung. Eine spätere Umrüstung auf genauere
Steller kann nach der Stellbarkeitsmessung erforderlich sein.

## Reproduzieren

Im Paketverzeichnis ausführen:

```bash
python3 src/build_cad.py
python3 src/check_design.py
python3 src/adjust.py --pitch 0.02 --dz 0
python3 src/build_manual.py
```

CAD-Gewinde und Federkörper sind vereinfacht. Grüne Stäbe im Bild zeigen nur
Federhüllen. Die orange Gabel ist aus Aluminium; ihre Farbe ist kein Materialcode.
Fehlende handelsübliche Befestiger werden nach Stückliste eingesetzt.

## Ergebnisstatus

- Elf erzeugte Einzelkörper geometrisch gültig, jeweils ein zusammenhängender Körper.
- Keine unerwarteten Volumenüberschneidungen zwischen den nominal modellierten
  Körpern; Ausnahmen und nicht modellierte Normteile stehen im Prüfbericht.
- Der vorgeschlagene Gabelrückzug wurde an 51 Positionen geometrisch geprüft.
- Kontaktmatrix Rang 6; 64 Arbeitsbereichsecken und 16 statische Lastfälle geprüft.
- Keine FEM, keine vollständige Toleranzrechnung, keine physische Prüfung.
- Normteilpassung, Reibung, Spitzenverschleiß, thermische Drift und Lastübergabe
  sind reale Abnahmepunkte.

Das vorgeschlagene Materialbudget 90-180 CHF ist eine eigene Planungsschätzung.
FabLab-Zeit, Einführungskurse, Werkzeuge, Optik, Klebstoff und Messmittel sind
nicht enthalten. Es wurde nichts bestellt oder reserviert.

Lizenz für eigene CAD-/Code-/Dokumentationsanteile: MIT (siehe LICENSE).
Produktnamen identifizieren Vergleichsprodukte; fremde Hersteller-CAD wurden
nicht in diese Konstruktion kopiert.
