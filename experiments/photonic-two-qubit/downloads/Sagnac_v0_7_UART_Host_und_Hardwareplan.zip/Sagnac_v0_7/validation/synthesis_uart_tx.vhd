library ieee;
use ieee.std_logic_1164.all;
entity uart_tx is
  generic (
    CLKS_PER_BIT: positive := 50
  );
  port (
    clk, reset: in std_logic;
    byte_valid: in std_logic;
    byte_ready: out std_logic;
    byte_data: in std_logic_vector (7 downto 0);
    tx: out std_logic
  );
end entity;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture rtl of uart_tx is
  signal wrap_clk: std_logic;
  signal wrap_reset: std_logic;
  signal wrap_byte_valid: std_logic;
  subtype typwrap_byte_data is std_logic_vector (7 downto 0);
  signal wrap_byte_data: typwrap_byte_data;
  signal wrap_byte_ready: std_logic;
  signal wrap_tx: std_logic;
  signal active : std_logic;
  signal frame : std_logic_vector (9 downto 0);
  signal bit_index : std_logic_vector (3 downto 0);
  signal tick : std_logic_vector (5 downto 0);
  signal n6_o : std_logic;
  signal n9_o : std_logic;
  signal n14_o : std_logic;
  signal n16_o : std_logic_vector (8 downto 0);
  signal n18_o : std_logic_vector (9 downto 0);
  signal n20_o : std_logic;
  signal n21_o : std_logic_vector (9 downto 0);
  signal n23_o : std_logic_vector (3 downto 0);
  signal n25_o : std_logic_vector (5 downto 0);
  signal n26_o : std_logic_vector (31 downto 0);
  signal n28_o : std_logic;
  signal n29_o : std_logic_vector (31 downto 0);
  signal n31_o : std_logic;
  signal n32_o : std_logic_vector (31 downto 0);
  signal n34_o : std_logic_vector (31 downto 0);
  signal n35_o : std_logic_vector (3 downto 0);
  signal n37_o : std_logic;
  signal n39_o : std_logic_vector (3 downto 0);
  signal n40_o : std_logic_vector (31 downto 0);
  signal n42_o : std_logic_vector (31 downto 0);
  signal n43_o : std_logic_vector (5 downto 0);
  signal n44_o : std_logic;
  signal n45_o : std_logic_vector (3 downto 0);
  signal n47_o : std_logic_vector (5 downto 0);
  signal n48_o : std_logic;
  signal n49_o : std_logic;
  signal n50_o : std_logic_vector (3 downto 0);
  signal n51_o : std_logic_vector (5 downto 0);
  signal n53_o : std_logic;
  signal n55_o : std_logic_vector (9 downto 0);
  signal n57_o : std_logic_vector (3 downto 0);
  signal n59_o : std_logic_vector (5 downto 0);
  signal n65_q : std_logic := '0';
  signal n66_q : std_logic_vector (9 downto 0) := "1111111111";
  signal n67_q : std_logic_vector (3 downto 0) := "0000";
  signal n68_q : std_logic_vector (5 downto 0) := "000000";
  signal n69_o : std_logic;
  signal n70_o : std_logic;
  signal n71_o : std_logic;
  signal n72_o : std_logic;
  signal n73_o : std_logic;
  signal n74_o : std_logic;
  signal n75_o : std_logic;
  signal n76_o : std_logic;
  signal n77_o : std_logic;
  signal n78_o : std_logic;
  signal n79_o : std_logic_vector (1 downto 0);
  signal n80_o : std_logic;
  signal n81_o : std_logic_vector (1 downto 0);
  signal n82_o : std_logic;
  signal n83_o : std_logic;
  signal n84_o : std_logic;
  signal n85_o : std_logic;
  signal n86_o : std_logic;
  signal n87_o : std_logic;
  signal n88_o : std_logic;
begin
  wrap_clk <= clk;
  wrap_reset <= reset;
  wrap_byte_valid <= byte_valid;
  wrap_byte_data <= typwrap_byte_data(byte_data);
  byte_ready <= wrap_byte_ready;
  tx <= wrap_tx;
  wrap_byte_ready <= n6_o;
  wrap_tx <= n9_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:12:10
  active <= n65_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:13:10
  frame <= n66_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:14:10
  bit_index <= n67_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:15:10
  tick <= n68_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:17:15
  n6_o <= not active;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:24
  n9_o <= '1' when active = '0' else n88_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:19
  n14_o <= not active;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:26:22
  n16_o <= '1' & wrap_byte_data;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:26:34
  n18_o <= n16_o & '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n20_o <= active when wrap_byte_valid = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n21_o <= frame when n49_o = '0' else n18_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n23_o <= bit_index when wrap_byte_valid = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n25_o <= tick when wrap_byte_valid = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:17
  n26_o <= "00000000000000000000000000" & tick;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:17
  n28_o <= '1' when n26_o = "00000000000000000000000000110001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:21
  n29_o <= "0000000000000000000000000000" & bit_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:21
  n31_o <= '1' when n29_o = "00000000000000000000000000001001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:34
  n32_o <= "0000000000000000000000000000" & bit_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:34
  n34_o <= std_logic_vector (unsigned (n32_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:25
  n35_o <= n34_o (3 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n37_o <= active when n44_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:9
  n39_o <= n35_o when n31_o = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:22
  n40_o <= "00000000000000000000000000" & tick;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:22
  n42_o <= std_logic_vector (unsigned (n40_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:18
  n43_o <= n42_o (5 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n44_o <= n28_o and n31_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n45_o <= bit_index when n28_o = '0' else n39_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n47_o <= n43_o when n28_o = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n48_o <= n37_o when n14_o = '0' else n20_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n49_o <= n14_o and wrap_byte_valid;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n50_o <= n45_o when n14_o = '0' else n23_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n51_o <= n47_o when n14_o = '0' else n25_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n53_o <= n48_o when wrap_reset = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n55_o <= n21_o when wrap_reset = '0' else "1111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n57_o <= n50_o when wrap_reset = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n59_o <= n51_o when wrap_reset = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n65_q <= n53_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n66_q <= n55_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n67_q <= n57_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n68_q <= n59_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:9:53
  n69_o <= frame (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:8:35
  n70_o <= frame (1);
  n71_o <= frame (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:19:3
  n72_o <= frame (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  n73_o <= frame (4);
  n74_o <= frame (5);
  n75_o <= frame (6);
  n76_o <= frame (7);
  n77_o <= frame (8);
  n78_o <= frame (9);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n79_o <= bit_index (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  with n79_o select n80_o <=
    n69_o when "00",
    n70_o when "01",
    n71_o when "10",
    n72_o when "11",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n81_o <= bit_index (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  with n81_o select n82_o <=
    n73_o when "00",
    n74_o when "01",
    n75_o when "10",
    n76_o when "11",
    'X' when others;
  n83_o <= bit_index (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n84_o <= n77_o when n83_o = '0' else n78_o;
  n85_o <= bit_index (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n86_o <= n80_o when n85_o = '0' else n82_o;
  n87_o <= bit_index (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n88_o <= n86_o when n87_o = '0' else n84_o;
end rtl;
