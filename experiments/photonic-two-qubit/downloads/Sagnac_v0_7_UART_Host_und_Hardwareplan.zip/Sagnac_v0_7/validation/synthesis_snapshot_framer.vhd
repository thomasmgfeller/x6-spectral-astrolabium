library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.sagnac_pkg.all;
entity snapshot_framer is
  port (
    clk, reset: in std_logic;
    send_valid: in std_logic;
    send_ready: out std_logic;
    counts_in: in counter_array;
    flags_in: in std_logic_vector (7 downto 0);
    setting_in: in unsigned (1 downto 0);
    calibration_in: in std_logic_vector (31 downto 0);
    start_in, stop_in, width_in, sequence_in: in u64;
    byte_valid: out std_logic;
    byte_ready: in std_logic;
    byte_data: out std_logic_vector (7 downto 0)
  );
end entity;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture rtl of snapshot_framer is
  signal wrap_clk: std_logic;
  signal wrap_reset: std_logic;
  signal wrap_send_valid: std_logic;
  subtype typwrap_counts_in is std_logic_vector (1535 downto 0);
  signal wrap_counts_in: typwrap_counts_in;
  subtype typwrap_flags_in is std_logic_vector (7 downto 0);
  signal wrap_flags_in: typwrap_flags_in;
  subtype typwrap_setting_in is std_logic_vector (1 downto 0);
  signal wrap_setting_in: typwrap_setting_in;
  subtype typwrap_calibration_in is std_logic_vector (31 downto 0);
  signal wrap_calibration_in: typwrap_calibration_in;
  subtype typwrap_start_in is std_logic_vector (63 downto 0);
  signal wrap_start_in: typwrap_start_in;
  subtype typwrap_stop_in is std_logic_vector (63 downto 0);
  signal wrap_stop_in: typwrap_stop_in;
  subtype typwrap_width_in is std_logic_vector (63 downto 0);
  signal wrap_width_in: typwrap_width_in;
  subtype typwrap_sequence_in is std_logic_vector (63 downto 0);
  signal wrap_sequence_in: typwrap_sequence_in;
  signal wrap_byte_ready: std_logic;
  signal wrap_send_ready: std_logic;
  signal wrap_byte_valid: std_logic;
  subtype typwrap_byte_data is std_logic_vector (7 downto 0);
  signal wrap_byte_data: typwrap_byte_data;
  signal state : std_logic_vector (1 downto 0);
  signal c : std_logic_vector (1535 downto 0);
  signal f : std_logic_vector (7 downto 0);
  signal s : std_logic_vector (1 downto 0);
  signal cal : std_logic_vector (31 downto 0);
  signal first : std_logic_vector (63 downto 0);
  signal last : std_logic_vector (63 downto 0);
  signal width : std_logic_vector (63 downto 0);
  signal seq : std_logic_vector (63 downto 0);
  signal index : std_logic_vector (7 downto 0);
  signal crc_index : std_logic_vector (1 downto 0);
  signal crc : std_logic_vector (31 downto 0);
  signal octet : std_logic_vector (7 downto 0);
  signal n9_o : std_logic;
  signal n10_o : std_logic;
  signal n14_o : std_logic;
  signal n15_o : std_logic;
  signal n20_o : std_logic;
  signal n22_o : std_logic_vector (31 downto 0);
  signal n23_o : std_logic_vector (30 downto 0);
  signal n28_o : std_logic_vector (31 downto 0);
  signal n30_o : std_logic_vector (31 downto 0);
  signal n31_o : std_logic_vector (30 downto 0);
  signal n32_o : std_logic_vector (31 downto 0);
  signal n33_o : std_logic_vector (7 downto 0);
  signal n35_o : std_logic;
  signal n36_o : std_logic_vector (31 downto 0);
  signal n38_o : std_logic;
  signal n39_o : std_logic_vector (31 downto 0);
  signal n41_o : std_logic_vector (31 downto 0);
  signal n42_o : std_logic_vector (2 downto 0);
  signal n44_o : std_logic_vector (2 downto 0);
  signal n50_o : std_logic_vector (31 downto 0);
  signal n52_o : std_logic;
  signal n53_o : std_logic_vector (31 downto 0);
  signal n55_o : std_logic;
  signal n56_o : std_logic_vector (7 downto 0);
  signal n57_o : std_logic_vector (31 downto 0);
  signal n59_o : std_logic;
  signal n60_o : std_logic_vector (31 downto 0);
  signal n62_o : std_logic;
  signal n63_o : std_logic_vector (31 downto 0);
  signal n65_o : std_logic;
  signal n67_o : std_logic_vector (31 downto 0);
  signal n69_o : std_logic_vector (31 downto 0);
  signal n70_o : std_logic_vector (30 downto 0);
  signal n75_o : std_logic_vector (31 downto 0);
  signal n77_o : std_logic_vector (31 downto 0);
  signal n78_o : std_logic_vector (30 downto 0);
  signal n79_o : std_logic_vector (31 downto 0);
  signal n80_o : std_logic_vector (7 downto 0);
  signal n81_o : std_logic_vector (31 downto 0);
  signal n83_o : std_logic;
  signal n85_o : std_logic_vector (31 downto 0);
  signal n87_o : std_logic_vector (31 downto 0);
  signal n88_o : std_logic_vector (30 downto 0);
  signal n93_o : std_logic_vector (31 downto 0);
  signal n95_o : std_logic_vector (31 downto 0);
  signal n96_o : std_logic_vector (30 downto 0);
  signal n97_o : std_logic_vector (63 downto 0);
  signal n98_o : std_logic_vector (7 downto 0);
  signal n99_o : std_logic_vector (31 downto 0);
  signal n101_o : std_logic;
  signal n103_o : std_logic_vector (31 downto 0);
  signal n105_o : std_logic_vector (31 downto 0);
  signal n106_o : std_logic_vector (30 downto 0);
  signal n111_o : std_logic_vector (31 downto 0);
  signal n113_o : std_logic_vector (31 downto 0);
  signal n114_o : std_logic_vector (30 downto 0);
  signal n115_o : std_logic_vector (63 downto 0);
  signal n116_o : std_logic_vector (7 downto 0);
  signal n117_o : std_logic_vector (31 downto 0);
  signal n119_o : std_logic;
  signal n121_o : std_logic_vector (31 downto 0);
  signal n123_o : std_logic_vector (31 downto 0);
  signal n124_o : std_logic_vector (30 downto 0);
  signal n129_o : std_logic_vector (31 downto 0);
  signal n131_o : std_logic_vector (31 downto 0);
  signal n132_o : std_logic_vector (30 downto 0);
  signal n133_o : std_logic_vector (63 downto 0);
  signal n134_o : std_logic_vector (7 downto 0);
  signal n135_o : std_logic_vector (31 downto 0);
  signal n137_o : std_logic;
  signal n139_o : std_logic_vector (31 downto 0);
  signal n141_o : std_logic_vector (31 downto 0);
  signal n142_o : std_logic_vector (30 downto 0);
  signal n147_o : std_logic_vector (31 downto 0);
  signal n149_o : std_logic_vector (31 downto 0);
  signal n150_o : std_logic_vector (30 downto 0);
  signal n151_o : std_logic_vector (63 downto 0);
  signal n152_o : std_logic_vector (7 downto 0);
  signal n154_o : std_logic_vector (31 downto 0);
  signal n156_o : std_logic_vector (31 downto 0);
  signal n158_o : std_logic_vector (31 downto 0);
  signal n159_o : std_logic_vector (4 downto 0);
  signal n161_o : std_logic_vector (4 downto 0);
  signal n164_o : std_logic_vector (31 downto 0);
  signal n166_o : std_logic_vector (31 downto 0);
  signal n167_o : std_logic_vector (2 downto 0);
  signal n169_o : std_logic_vector (30 downto 0);
  signal n174_o : std_logic_vector (31 downto 0);
  signal n176_o : std_logic_vector (31 downto 0);
  signal n177_o : std_logic_vector (30 downto 0);
  signal n178_o : std_logic_vector (63 downto 0);
  signal n179_o : std_logic_vector (7 downto 0);
  signal n180_o : std_logic_vector (7 downto 0);
  signal n181_o : std_logic_vector (7 downto 0);
  signal n182_o : std_logic_vector (7 downto 0);
  signal n183_o : std_logic_vector (7 downto 0);
  signal n184_o : std_logic_vector (7 downto 0);
  signal n186_o : std_logic_vector (7 downto 0);
  signal n187_o : std_logic_vector (7 downto 0);
  signal n188_o : std_logic_vector (7 downto 0);
  signal n190_o : std_logic_vector (7 downto 0);
  signal n191_o : std_logic_vector (7 downto 0);
  signal n193_o : std_logic_vector (7 downto 0);
  signal n194_o : std_logic_vector (7 downto 0);
  signal n201_o : std_logic_vector (1 downto 0);
  signal n202_o : std_logic_vector (1535 downto 0);
  signal n203_o : std_logic_vector (7 downto 0);
  signal n204_o : std_logic_vector (1 downto 0);
  signal n205_o : std_logic_vector (31 downto 0);
  signal n206_o : std_logic_vector (63 downto 0);
  signal n207_o : std_logic_vector (63 downto 0);
  signal n208_o : std_logic_vector (63 downto 0);
  signal n209_o : std_logic_vector (63 downto 0);
  signal n211_o : std_logic_vector (7 downto 0);
  signal n213_o : std_logic_vector (31 downto 0);
  signal n215_o : std_logic;
  signal n221_o : std_logic_vector (31 downto 0);
  signal n222_o : std_logic_vector (31 downto 0);
  signal n223_o : std_logic;
  signal n225_o : std_logic_vector (31 downto 0);
  signal n227_o : std_logic_vector (31 downto 0);
  signal n229_o : std_logic_vector (31 downto 0);
  signal n230_o : std_logic_vector (31 downto 0);
  signal n231_o : std_logic;
  signal n233_o : std_logic_vector (31 downto 0);
  signal n235_o : std_logic_vector (31 downto 0);
  signal n237_o : std_logic_vector (31 downto 0);
  signal n238_o : std_logic_vector (31 downto 0);
  signal n239_o : std_logic;
  signal n241_o : std_logic_vector (31 downto 0);
  signal n243_o : std_logic_vector (31 downto 0);
  signal n245_o : std_logic_vector (31 downto 0);
  signal n246_o : std_logic_vector (31 downto 0);
  signal n247_o : std_logic;
  signal n249_o : std_logic_vector (31 downto 0);
  signal n251_o : std_logic_vector (31 downto 0);
  signal n253_o : std_logic_vector (31 downto 0);
  signal n254_o : std_logic_vector (31 downto 0);
  signal n255_o : std_logic;
  signal n257_o : std_logic_vector (31 downto 0);
  signal n259_o : std_logic_vector (31 downto 0);
  signal n261_o : std_logic_vector (31 downto 0);
  signal n262_o : std_logic_vector (31 downto 0);
  signal n263_o : std_logic;
  signal n265_o : std_logic_vector (31 downto 0);
  signal n267_o : std_logic_vector (31 downto 0);
  signal n269_o : std_logic_vector (31 downto 0);
  signal n270_o : std_logic_vector (31 downto 0);
  signal n271_o : std_logic;
  signal n273_o : std_logic_vector (31 downto 0);
  signal n275_o : std_logic_vector (31 downto 0);
  signal n277_o : std_logic_vector (31 downto 0);
  signal n278_o : std_logic_vector (31 downto 0);
  signal n279_o : std_logic;
  signal n281_o : std_logic_vector (31 downto 0);
  signal n283_o : std_logic_vector (31 downto 0);
  signal n285_o : std_logic_vector (31 downto 0);
  signal n286_o : std_logic_vector (31 downto 0);
  signal n287_o : std_logic_vector (31 downto 0);
  signal n289_o : std_logic;
  signal n290_o : std_logic_vector (31 downto 0);
  signal n292_o : std_logic_vector (31 downto 0);
  signal n293_o : std_logic_vector (7 downto 0);
  signal n295_o : std_logic_vector (1 downto 0);
  signal n296_o : std_logic_vector (7 downto 0);
  signal n298_o : std_logic_vector (1 downto 0);
  signal n299_o : std_logic;
  signal n300_o : std_logic_vector (7 downto 0);
  signal n301_o : std_logic;
  signal n302_o : std_logic_vector (31 downto 0);
  signal n304_o : std_logic;
  signal n305_o : std_logic_vector (31 downto 0);
  signal n307_o : std_logic;
  signal n308_o : std_logic_vector (31 downto 0);
  signal n310_o : std_logic_vector (31 downto 0);
  signal n311_o : std_logic_vector (1 downto 0);
  signal n313_o : std_logic_vector (1 downto 0);
  signal n314_o : std_logic_vector (1 downto 0);
  signal n315_o : std_logic;
  signal n316_o : std_logic_vector (1 downto 0);
  signal n318_o : std_logic;
  signal n319_o : std_logic_vector (2 downto 0);
  signal n321_o : std_logic_vector (1 downto 0);
  signal n323_o : std_logic_vector (1535 downto 0);
  signal n325_o : std_logic_vector (7 downto 0);
  signal n327_o : std_logic_vector (1 downto 0);
  signal n329_o : std_logic_vector (31 downto 0);
  signal n331_o : std_logic_vector (63 downto 0);
  signal n333_o : std_logic_vector (63 downto 0);
  signal n335_o : std_logic_vector (63 downto 0);
  signal n337_o : std_logic_vector (63 downto 0);
  signal n339_o : std_logic_vector (7 downto 0);
  signal n341_o : std_logic_vector (1 downto 0);
  signal n343_o : std_logic_vector (31 downto 0);
  signal n345_o : std_logic_vector (1 downto 0);
  signal n346_o : std_logic_vector (1535 downto 0);
  signal n347_o : std_logic_vector (7 downto 0);
  signal n348_o : std_logic_vector (1 downto 0);
  signal n349_o : std_logic_vector (31 downto 0);
  signal n350_o : std_logic_vector (63 downto 0);
  signal n351_o : std_logic_vector (63 downto 0);
  signal n352_o : std_logic_vector (63 downto 0);
  signal n353_o : std_logic_vector (63 downto 0);
  signal n355_o : std_logic_vector (7 downto 0);
  signal n357_o : std_logic_vector (1 downto 0);
  signal n359_o : std_logic_vector (31 downto 0);
  signal n373_q : std_logic_vector (1 downto 0) := "00";
  signal n374_q : std_logic_vector (1535 downto 0);
  signal n375_q : std_logic_vector (7 downto 0);
  signal n376_q : std_logic_vector (1 downto 0);
  signal n377_q : std_logic_vector (31 downto 0);
  signal n378_q : std_logic_vector (63 downto 0);
  signal n379_q : std_logic_vector (63 downto 0);
  signal n380_q : std_logic_vector (63 downto 0);
  signal n381_q : std_logic_vector (63 downto 0);
  signal n382_q : std_logic_vector (7 downto 0) := "00000000";
  signal n383_q : std_logic_vector (1 downto 0) := "00";
  signal n384_q : std_logic_vector (31 downto 0) := "11111111111111111111111111111111";
  signal n386_data : std_logic_vector (7 downto 0);
  signal n387_o : std_logic_vector (63 downto 0);
  signal n388_o : std_logic_vector (63 downto 0);
  signal n389_o : std_logic_vector (63 downto 0);
  signal n390_o : std_logic_vector (63 downto 0);
  signal n391_o : std_logic_vector (63 downto 0);
  signal n392_o : std_logic_vector (63 downto 0);
  signal n393_o : std_logic_vector (63 downto 0);
  signal n394_o : std_logic_vector (63 downto 0);
  signal n395_o : std_logic_vector (63 downto 0);
  signal n396_o : std_logic_vector (63 downto 0);
  signal n397_o : std_logic_vector (63 downto 0);
  signal n398_o : std_logic_vector (63 downto 0);
  signal n399_o : std_logic_vector (63 downto 0);
  signal n400_o : std_logic_vector (63 downto 0);
  signal n401_o : std_logic_vector (63 downto 0);
  signal n402_o : std_logic_vector (63 downto 0);
  signal n403_o : std_logic_vector (63 downto 0);
  signal n404_o : std_logic_vector (63 downto 0);
  signal n405_o : std_logic_vector (63 downto 0);
  signal n406_o : std_logic_vector (63 downto 0);
  signal n407_o : std_logic_vector (63 downto 0);
  signal n408_o : std_logic_vector (63 downto 0);
  signal n409_o : std_logic_vector (63 downto 0);
  signal n410_o : std_logic_vector (63 downto 0);
  signal n411_o : std_logic_vector (1 downto 0);
  signal n412_o : std_logic_vector (63 downto 0);
  signal n413_o : std_logic_vector (1 downto 0);
  signal n414_o : std_logic_vector (63 downto 0);
  signal n415_o : std_logic_vector (1 downto 0);
  signal n416_o : std_logic_vector (63 downto 0);
  signal n417_o : std_logic_vector (1 downto 0);
  signal n418_o : std_logic_vector (63 downto 0);
  signal n419_o : std_logic_vector (1 downto 0);
  signal n420_o : std_logic_vector (63 downto 0);
  signal n421_o : std_logic_vector (1 downto 0);
  signal n422_o : std_logic_vector (63 downto 0);
  signal n423_o : std_logic_vector (1 downto 0);
  signal n424_o : std_logic_vector (63 downto 0);
  signal n425_o : std_logic;
  signal n426_o : std_logic_vector (63 downto 0);
  signal n427_o : std_logic;
  signal n428_o : std_logic_vector (63 downto 0);
begin
  wrap_clk <= clk;
  wrap_reset <= reset;
  wrap_send_valid <= send_valid;
  wrap_counts_in (63 downto 0) <= std_logic_vector(counts_in ( 0));
  wrap_counts_in (127 downto 64) <= std_logic_vector(counts_in ( 1));
  wrap_counts_in (191 downto 128) <= std_logic_vector(counts_in ( 2));
  wrap_counts_in (255 downto 192) <= std_logic_vector(counts_in ( 3));
  wrap_counts_in (319 downto 256) <= std_logic_vector(counts_in ( 4));
  wrap_counts_in (383 downto 320) <= std_logic_vector(counts_in ( 5));
  wrap_counts_in (447 downto 384) <= std_logic_vector(counts_in ( 6));
  wrap_counts_in (511 downto 448) <= std_logic_vector(counts_in ( 7));
  wrap_counts_in (575 downto 512) <= std_logic_vector(counts_in ( 8));
  wrap_counts_in (639 downto 576) <= std_logic_vector(counts_in ( 9));
  wrap_counts_in (703 downto 640) <= std_logic_vector(counts_in ( 10));
  wrap_counts_in (767 downto 704) <= std_logic_vector(counts_in ( 11));
  wrap_counts_in (831 downto 768) <= std_logic_vector(counts_in ( 12));
  wrap_counts_in (895 downto 832) <= std_logic_vector(counts_in ( 13));
  wrap_counts_in (959 downto 896) <= std_logic_vector(counts_in ( 14));
  wrap_counts_in (1023 downto 960) <= std_logic_vector(counts_in ( 15));
  wrap_counts_in (1087 downto 1024) <= std_logic_vector(counts_in ( 16));
  wrap_counts_in (1151 downto 1088) <= std_logic_vector(counts_in ( 17));
  wrap_counts_in (1215 downto 1152) <= std_logic_vector(counts_in ( 18));
  wrap_counts_in (1279 downto 1216) <= std_logic_vector(counts_in ( 19));
  wrap_counts_in (1343 downto 1280) <= std_logic_vector(counts_in ( 20));
  wrap_counts_in (1407 downto 1344) <= std_logic_vector(counts_in ( 21));
  wrap_counts_in (1471 downto 1408) <= std_logic_vector(counts_in ( 22));
  wrap_counts_in (1535 downto 1472) <= std_logic_vector(counts_in ( 23));
  wrap_flags_in <= typwrap_flags_in(flags_in);
  wrap_setting_in <= typwrap_setting_in(setting_in);
  wrap_calibration_in <= typwrap_calibration_in(calibration_in);
  wrap_start_in <= typwrap_start_in(start_in);
  wrap_stop_in <= typwrap_stop_in(stop_in);
  wrap_width_in <= typwrap_width_in(width_in);
  wrap_sequence_in <= typwrap_sequence_in(sequence_in);
  wrap_byte_ready <= byte_ready;
  send_ready <= wrap_send_ready;
  byte_valid <= wrap_byte_valid;
  byte_data <= std_ulogic_vector(wrap_byte_data);
  wrap_send_ready <= n10_o;
  wrap_byte_valid <= n15_o;
  wrap_byte_data <= octet;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:20:10
  state <= n373_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:21:10
  c <= n374_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:22:10
  f <= n375_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:23:10
  s <= n376_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:24:10
  cal <= n377_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:10
  first <= n378_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:16
  last <= n379_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:21
  width <= n380_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:27
  seq <= n381_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:26:10
  index <= n382_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:27:10
  crc_index <= n383_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:28:10
  crc <= n384_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:29:10
  octet <= n194_o; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:44:29
  n9_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:44:19
  n10_o <= '0' when n9_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:45:29
  n14_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:45:19
  n15_o <= '1' when n14_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:13
  n20_o <= '1' when state = "10" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:44
  n22_o <= not crc;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:52
  n23_o <= "00000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n28_o <= "0" & n23_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n30_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n28_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n31_o <= n30_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n32_o <= std_logic_vector (shift_right (unsigned (n22_o), to_integer(unsigned (n31_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n33_o <= n32_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:50:16
  n35_o <= '1' when state = "01" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:15
  n36_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:15
  n38_o <= '1' when signed (n36_o) < signed'("00000000000000000000000000001000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  n39_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  n41_o <= std_logic_vector (unsigned (n39_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n42_o <= n41_o (2 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n44_o <= std_logic_vector (unsigned'("000") - unsigned (n42_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:18
  n50_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:18
  n52_o <= '1' when n50_o = "00000000000000000000000000001000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:18
  n53_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:18
  n55_o <= '1' when n53_o = "00000000000000000000000000001001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:50
  n56_o <= "000000" & s;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:18
  n57_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:18
  n59_o <= '1' when n57_o = "00000000000000000000000000001010" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:18
  n60_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:18
  n62_o <= '1' when n60_o = "00000000000000000000000000001011" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:18
  n63_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:18
  n65_o <= '1' when signed (n63_o) < signed'("00000000000000000000000000010000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:61
  n67_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:61
  n69_o <= std_logic_vector (unsigned (n67_o) - unsigned'("00000000000000000000000000001100"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:56
  n70_o <= n69_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n75_o <= "0" & n70_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n77_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n75_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n78_o <= n77_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n79_o <= std_logic_vector (shift_right (unsigned (cal), to_integer(unsigned (n78_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n80_o <= n79_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:18
  n81_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:18
  n83_o <= '1' when signed (n81_o) < signed'("00000000000000000000000000011000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:53
  n85_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:53
  n87_o <= std_logic_vector (unsigned (n85_o) - unsigned'("00000000000000000000000000010000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:48
  n88_o <= n87_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n93_o <= "0" & n88_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n95_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n93_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n96_o <= n95_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n97_o <= std_logic_vector (shift_right (unsigned (first), to_integer(unsigned (n96_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n98_o <= n97_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:18
  n99_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:18
  n101_o <= '1' when signed (n99_o) < signed'("00000000000000000000000000100000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:52
  n103_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:52
  n105_o <= std_logic_vector (unsigned (n103_o) - unsigned'("00000000000000000000000000011000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:47
  n106_o <= n105_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n111_o <= "0" & n106_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n113_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n111_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n114_o <= n113_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n115_o <= std_logic_vector (shift_right (unsigned (last), to_integer(unsigned (n114_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n116_o <= n115_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:18
  n117_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:18
  n119_o <= '1' when signed (n117_o) < signed'("00000000000000000000000000101000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:53
  n121_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:53
  n123_o <= std_logic_vector (unsigned (n121_o) - unsigned'("00000000000000000000000000100000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:48
  n124_o <= n123_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n129_o <= "0" & n124_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n131_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n129_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n132_o <= n131_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n133_o <= std_logic_vector (shift_right (unsigned (width), to_integer(unsigned (n132_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n134_o <= n133_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:18
  n135_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:18
  n137_o <= '1' when signed (n135_o) < signed'("00000000000000000000000000110000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:51
  n139_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:51
  n141_o <= std_logic_vector (unsigned (n139_o) - unsigned'("00000000000000000000000000101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:46
  n142_o <= n141_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n147_o <= "0" & n142_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n149_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n147_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n150_o <= n149_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n151_o <= std_logic_vector (shift_right (unsigned (seq), to_integer(unsigned (n150_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n152_o <= n151_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:35
  n154_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:35
  n156_o <= std_logic_vector (unsigned (n154_o) - unsigned'("00000000000000000000000000110000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:39
  n158_o <= std_logic_vector (signed (n156_o) / signed'("00000000000000000000000000001000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n159_o <= n158_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n161_o <= std_logic_vector (unsigned'("10111") - unsigned (n159_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:49
  n164_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:49
  n166_o <= std_logic_vector (unsigned (n164_o) - unsigned'("00000000000000000000000000110000"));
  n167_o <= n166_o (2 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:43
  n169_o <= "0000000000000000000000000000" & n167_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n174_o <= "0" & n169_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n176_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n174_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n177_o <= n176_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n178_o <= std_logic_vector (shift_right (unsigned (n428_o), to_integer(unsigned (n177_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n179_o <= n178_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:7
  n180_o <= n179_o when n137_o = '0' else n152_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:7
  n181_o <= n180_o when n119_o = '0' else n134_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:7
  n182_o <= n181_o when n101_o = '0' else n116_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:7
  n183_o <= n182_o when n83_o = '0' else n98_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:7
  n184_o <= n183_o when n65_o = '0' else n80_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:7
  n186_o <= n184_o when n62_o = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:7
  n187_o <= n186_o when n59_o = '0' else f;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:7
  n188_o <= n187_o when n55_o = '0' else n56_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:7
  n190_o <= n188_o when n52_o = '0' else "00000111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:7
  n191_o <= n190_o when n38_o = '0' else n386_data;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:50:5
  n193_o <= "00000000" when n35_o = '0' else n191_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:5
  n194_o <= n193_o when n20_o = '0' else n33_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n201_o <= state when wrap_send_valid = '0' else "01";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n202_o <= c when wrap_send_valid = '0' else wrap_counts_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n203_o <= f when wrap_send_valid = '0' else wrap_flags_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n204_o <= s when wrap_send_valid = '0' else wrap_setting_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n205_o <= cal when wrap_send_valid = '0' else wrap_calibration_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n206_o <= first when wrap_send_valid = '0' else wrap_start_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n207_o <= last when wrap_send_valid = '0' else wrap_stop_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n208_o <= width when wrap_send_valid = '0' else wrap_width_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n209_o <= seq when wrap_send_valid = '0' else wrap_sequence_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n211_o <= index when wrap_send_valid = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n213_o <= crc when wrap_send_valid = '0' else "11111111111111111111111111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:72:11
  n215_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:56
  n221_o <= "000000000000000000000000" & octet;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:52
  n222_o <= crc xor n221_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n223_o <= n222_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n225_o <= std_logic_vector (shift_right (unsigned (n222_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n227_o <= n225_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n229_o <= std_logic_vector (shift_right (unsigned (n222_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n230_o <= n229_o when n223_o = '0' else n227_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n231_o <= n230_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n233_o <= std_logic_vector (shift_right (unsigned (n230_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n235_o <= n233_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n237_o <= std_logic_vector (shift_right (unsigned (n230_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n238_o <= n237_o when n231_o = '0' else n235_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n239_o <= n238_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n241_o <= std_logic_vector (shift_right (unsigned (n238_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n243_o <= n241_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n245_o <= std_logic_vector (shift_right (unsigned (n238_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n246_o <= n245_o when n239_o = '0' else n243_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n247_o <= n246_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n249_o <= std_logic_vector (shift_right (unsigned (n246_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n251_o <= n249_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n253_o <= std_logic_vector (shift_right (unsigned (n246_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n254_o <= n253_o when n247_o = '0' else n251_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n255_o <= n254_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n257_o <= std_logic_vector (shift_right (unsigned (n254_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n259_o <= n257_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n261_o <= std_logic_vector (shift_right (unsigned (n254_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n262_o <= n261_o when n255_o = '0' else n259_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n263_o <= n262_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n265_o <= std_logic_vector (shift_right (unsigned (n262_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n267_o <= n265_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n269_o <= std_logic_vector (shift_right (unsigned (n262_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n270_o <= n269_o when n263_o = '0' else n267_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n271_o <= n270_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n273_o <= std_logic_vector (shift_right (unsigned (n270_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n275_o <= n273_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n277_o <= std_logic_vector (shift_right (unsigned (n270_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n278_o <= n277_o when n271_o = '0' else n275_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n279_o <= n278_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n281_o <= std_logic_vector (shift_right (unsigned (n278_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n283_o <= n281_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n285_o <= std_logic_vector (shift_right (unsigned (n278_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n286_o <= n285_o when n279_o = '0' else n283_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:23
  n287_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:23
  n289_o <= '1' when n287_o = "00000000000000000000000011101111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:32
  n290_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:32
  n292_o <= std_logic_vector (unsigned (n290_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:27
  n293_o <= n292_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n295_o <= state when n299_o = '0' else "10";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:15
  n296_o <= n293_o when n289_o = '0' else index;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n298_o <= crc_index when n301_o = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n299_o <= wrap_byte_ready and n289_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n300_o <= index when wrap_byte_ready = '0' else n296_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n301_o <= wrap_byte_ready and n289_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n302_o <= crc when wrap_byte_ready = '0' else n286_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:78:11
  n304_o <= '1' when state = "01" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:27
  n305_o <= "000000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:27
  n307_o <= '1' when n305_o = "00000000000000000000000000000011" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:40
  n308_o <= "000000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:40
  n310_o <= std_logic_vector (unsigned (n308_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:31
  n311_o <= n310_o (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n313_o <= state when n315_o = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:15
  n314_o <= n311_o when n307_o = '0' else crc_index;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n315_o <= wrap_byte_ready and n307_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n316_o <= crc_index when wrap_byte_ready = '0' else n314_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:84:11
  n318_o <= '1' when state = "10" else '0';
  n319_o <= n318_o & n304_o & n215_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n321_o <=
    n313_o when "100",
    n295_o when "010",
    n201_o when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n323_o <=
    c when "100",
    c when "010",
    n202_o when "001",
    (1535 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n325_o <=
    f when "100",
    f when "010",
    n203_o when "001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n327_o <=
    s when "100",
    s when "010",
    n204_o when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n329_o <=
    cal when "100",
    cal when "010",
    n205_o when "001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n331_o <=
    first when "100",
    first when "010",
    n206_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n333_o <=
    last when "100",
    last when "010",
    n207_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n335_o <=
    width when "100",
    width when "010",
    n208_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n337_o <=
    seq when "100",
    seq when "010",
    n209_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n339_o <=
    index when "100",
    n300_o when "010",
    n211_o when "001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n341_o <=
    n316_o when "100",
    n298_o when "010",
    crc_index when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n319_o select n343_o <=
    crc when "100",
    n302_o when "010",
    n213_o when "001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n345_o <= n321_o when wrap_reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n346_o <= n323_o when wrap_reset = '0' else c;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n347_o <= n325_o when wrap_reset = '0' else f;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n348_o <= n327_o when wrap_reset = '0' else s;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n349_o <= n329_o when wrap_reset = '0' else cal;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n350_o <= n331_o when wrap_reset = '0' else first;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n351_o <= n333_o when wrap_reset = '0' else last;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n352_o <= n335_o when wrap_reset = '0' else width;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n353_o <= n337_o when wrap_reset = '0' else seq;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n355_o <= n339_o when wrap_reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n357_o <= n341_o when wrap_reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n359_o <= n343_o when wrap_reset = '0' else "11111111111111111111111111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n373_q <= n345_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n374_q <= n346_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n375_q <= n347_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n376_q <= n348_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n377_q <= n349_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n378_q <= n350_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n379_q <= n351_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n380_q <= n352_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n381_q <= n353_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n382_q <= n355_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n383_q <= n357_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n384_q <= n359_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:16:8
  process (n44_o) is
    type n385_type is array (0 to 7)
      of std_logic_vector (7 downto 0);
    variable n385 : n385_type :=
      (7 => "01010011",
       6 => "01000111",
       5 => "01001110",
       4 => "01000011",
       3 => "01110110",
       2 => "00110000",
       1 => "00110000",
       0 => "00110111");
  begin
    n386_data <= n385(to_integer (unsigned (n44_o)));
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n387_o <= c (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:15:8
  n388_o <= c (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:9:35
  n389_o <= c (191 downto 128);
  n390_o <= c (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:14
  n391_o <= c (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n392_o <= c (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n393_o <= c (447 downto 384);
  n394_o <= c (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n395_o <= c (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:65:3
  n396_o <= c (639 downto 576);
  n397_o <= c (703 downto 640);
  n398_o <= c (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n399_o <= c (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n400_o <= c (895 downto 832);
  n401_o <= c (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n402_o <= c (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:54
  n403_o <= c (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n404_o <= c (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n405_o <= c (1215 downto 1152);
  n406_o <= c (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n407_o <= c (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n408_o <= c (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n409_o <= c (1471 downto 1408);
  n410_o <= c (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n411_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n411_o select n412_o <=
    n387_o when "00",
    n388_o when "01",
    n389_o when "10",
    n390_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n413_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n413_o select n414_o <=
    n391_o when "00",
    n392_o when "01",
    n393_o when "10",
    n394_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n415_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n415_o select n416_o <=
    n395_o when "00",
    n396_o when "01",
    n397_o when "10",
    n398_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n417_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n417_o select n418_o <=
    n399_o when "00",
    n400_o when "01",
    n401_o when "10",
    n402_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n419_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n419_o select n420_o <=
    n403_o when "00",
    n404_o when "01",
    n405_o when "10",
    n406_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n421_o <= n161_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n421_o select n422_o <=
    n407_o when "00",
    n408_o when "01",
    n409_o when "10",
    n410_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n423_o <= n161_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n423_o select n424_o <=
    n412_o when "00",
    n414_o when "01",
    n416_o when "10",
    n418_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:69
  n425_o <= n161_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n426_o <= n420_o when n425_o = '0' else n422_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n427_o <= n161_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n428_o <= n424_o when n427_o = '0' else n426_o;
end rtl;
