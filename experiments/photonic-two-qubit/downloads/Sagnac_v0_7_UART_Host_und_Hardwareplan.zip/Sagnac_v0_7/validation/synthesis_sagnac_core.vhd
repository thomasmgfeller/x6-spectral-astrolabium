library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.sagnac_pkg.all;
entity sagnac_core is
  generic (
    WINDOW_PS: positive := 1000;
    COUNTER_BITS: positive := 64
  );
  port (
    clk, reset, start: in std_logic;
    cfg_start_ps, cfg_stop_ps: in u64;
    cfg_calibration_id: in std_logic_vector (31 downto 0);
    cfg_setting: in unsigned (1 downto 0);
    in_valid: in std_logic;
    in_ready: out std_logic;
    in_kind: in unsigned (2 downto 0);
    in_time_ps: in u64;
    in_calibration_id: in std_logic_vector (31 downto 0);
    source_error: in std_logic;
    snapshot_ready: out std_logic;
    snapshot_counts: out counter_array;
    snapshot_flags: out std_logic_vector (7 downto 0);
    snapshot_start_ps, snapshot_stop_ps: out u64;
    snapshot_calibration_id: out std_logic_vector (31 downto 0);
    snapshot_setting: out unsigned (1 downto 0)
  );
end entity;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture rtl of sagnac_core is
  signal wrap_clk: std_logic;
  signal wrap_reset: std_logic;
  signal wrap_start: std_logic;
  subtype typwrap_cfg_start_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_start_ps: typwrap_cfg_start_ps;
  subtype typwrap_cfg_stop_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_stop_ps: typwrap_cfg_stop_ps;
  subtype typwrap_cfg_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_cfg_calibration_id: typwrap_cfg_calibration_id;
  subtype typwrap_cfg_setting is std_logic_vector (1 downto 0);
  signal wrap_cfg_setting: typwrap_cfg_setting;
  signal wrap_in_valid: std_logic;
  subtype typwrap_in_kind is std_logic_vector (2 downto 0);
  signal wrap_in_kind: typwrap_in_kind;
  subtype typwrap_in_time_ps is std_logic_vector (63 downto 0);
  signal wrap_in_time_ps: typwrap_in_time_ps;
  subtype typwrap_in_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_in_calibration_id: typwrap_in_calibration_id;
  signal wrap_source_error: std_logic;
  signal wrap_in_ready: std_logic;
  signal wrap_snapshot_ready: std_logic;
  subtype typwrap_snapshot_counts is std_logic_vector (1535 downto 0);
  signal wrap_snapshot_counts: typwrap_snapshot_counts;
  subtype typwrap_snapshot_flags is std_logic_vector (7 downto 0);
  signal wrap_snapshot_flags: typwrap_snapshot_flags;
  subtype typwrap_snapshot_start_ps is std_logic_vector (63 downto 0);
  signal wrap_snapshot_start_ps: typwrap_snapshot_start_ps;
  subtype typwrap_snapshot_stop_ps is std_logic_vector (63 downto 0);
  signal wrap_snapshot_stop_ps: typwrap_snapshot_stop_ps;
  subtype typwrap_snapshot_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_snapshot_calibration_id: typwrap_snapshot_calibration_id;
  subtype typwrap_snapshot_setting is std_logic_vector (1 downto 0);
  signal wrap_snapshot_setting: typwrap_snapshot_setting;
  signal state : std_logic_vector (2 downto 0);
  signal counts : std_logic_vector (1535 downto 0);
  signal shadow : std_logic_vector (1535 downto 0);
  signal flags : std_logic_vector (7 downto 0);
  signal shadow_flags : std_logic_vector (7 downto 0);
  signal run_start : std_logic_vector (63 downto 0);
  signal run_stop : std_logic_vector (63 downto 0);
  signal bin_start : std_logic_vector (63 downto 0);
  signal bin_end : std_logic_vector (63 downto 0);
  signal last_time : std_logic_vector (63 downto 0);
  signal item_time : std_logic_vector (63 downto 0);
  signal item_kind : std_logic_vector (2 downto 0);
  signal mask : std_logic_vector (3 downto 0);
  signal repeated : std_logic;
  signal calibration : std_logic_vector (31 downto 0);
  signal setting : std_logic_vector (1 downto 0);
  signal n26_o : std_logic;
  signal n27_o : std_logic;
  signal n31_o : std_logic;
  signal n32_o : std_logic;
  signal n44_o : std_logic;
  signal n46_o : std_logic;
  signal n47_o : std_logic;
  signal n49_o : std_logic;
  signal n50_o : std_logic;
  signal n52_o : std_logic;
  signal n53_o : std_logic;
  signal n55_o : std_logic;
  signal n57_o : std_logic;
  signal n60_o : std_logic;
  constant n61_o : std_logic_vector (7 downto 0) := "00000000";
  signal n63_o : std_logic_vector (1 downto 0);
  signal n64_o : std_logic;
  signal n66_o : std_logic_vector (63 downto 0);
  signal n68_o : std_logic_vector (63 downto 0);
  signal n70_o : std_logic;
  signal n73_o : std_logic_vector (63 downto 0);
  signal n76_o : std_logic_vector (2 downto 0);
  signal n77_o : std_logic_vector (63 downto 0);
  signal n78_o : std_logic;
  signal n79_o : std_logic;
  signal n81_o : std_logic_vector (2 downto 0);
  signal n82_o : std_logic_vector (63 downto 0);
  signal n83_o : std_logic;
  signal n84_o : std_logic_vector (2 downto 0);
  signal n85_o : std_logic;
  signal n86_o : std_logic_vector (2 downto 0);
  signal n87_o : std_logic_vector (63 downto 0);
  signal n88_o : std_logic_vector (63 downto 0);
  signal n89_o : std_logic_vector (63 downto 0);
  signal n90_o : std_logic_vector (63 downto 0);
  signal n91_o : std_logic_vector (63 downto 0);
  signal n93_o : std_logic_vector (3 downto 0);
  signal n95_o : std_logic;
  signal n96_o : std_logic_vector (31 downto 0);
  signal n97_o : std_logic_vector (1 downto 0);
  signal n99_o : std_logic_vector (1535 downto 0);
  signal n100_o : std_logic_vector (7 downto 0);
  signal n101_o : std_logic_vector (1 downto 0);
  signal n102_o : std_logic_vector (2 downto 0);
  signal n103_o : std_logic;
  signal n104_o : std_logic_vector (7 downto 0);
  signal n105_o : std_logic_vector (7 downto 0);
  signal n107_o : std_logic;
  signal n109_o : std_logic;
  signal n111_o : std_logic;
  signal n113_o : std_logic;
  signal n116_o : std_logic_vector (2 downto 0);
  signal n117_o : std_logic_vector (63 downto 0);
  signal n118_o : std_logic_vector (63 downto 0);
  signal n119_o : std_logic_vector (2 downto 0);
  signal n120_o : std_logic;
  signal n121_o : std_logic;
  signal n122_o : std_logic_vector (2 downto 0);
  signal n123_o : std_logic_vector (63 downto 0);
  signal n124_o : std_logic_vector (63 downto 0);
  signal n125_o : std_logic_vector (2 downto 0);
  signal n126_o : std_logic;
  signal n127_o : std_logic;
  signal n128_o : std_logic;
  signal n129_o : std_logic;
  signal n130_o : std_logic_vector (2 downto 0);
  signal n131_o : std_logic_vector (63 downto 0);
  signal n132_o : std_logic_vector (63 downto 0);
  signal n133_o : std_logic_vector (2 downto 0);
  signal n134_o : std_logic;
  signal n135_o : std_logic;
  signal n136_o : std_logic;
  signal n137_o : std_logic;
  signal n138_o : std_logic;
  signal n139_o : std_logic;
  signal n140_o : std_logic_vector (2 downto 0);
  signal n141_o : std_logic_vector (63 downto 0);
  signal n142_o : std_logic_vector (63 downto 0);
  signal n143_o : std_logic_vector (2 downto 0);
  signal n144_o : std_logic;
  signal n145_o : std_logic;
  signal n146_o : std_logic;
  signal n147_o : std_logic;
  signal n149_o : std_logic;
  signal n151_o : std_logic;
  signal n152_o : std_logic;
  signal n153_o : std_logic;
  signal n154_o : std_logic;
  signal n156_o : std_logic;
  signal n157_o : std_logic;
  signal n158_o : std_logic_vector (63 downto 0);
  signal n159_o : std_logic_vector (63 downto 0);
  signal n161_o : std_logic_vector (63 downto 0);
  signal n163_o : std_logic_vector (1 downto 0);
  signal n164_o : std_logic_vector (2 downto 0);
  signal n165_o : std_logic;
  signal n166_o : std_logic_vector (7 downto 0);
  signal n169_o : std_logic_vector (63 downto 0);
  signal n171_o : std_logic_vector (63 downto 0);
  signal n172_o : std_logic;
  signal n175_o : std_logic_vector (63 downto 0);
  signal n176_o : std_logic_vector (63 downto 0);
  signal n177_o : std_logic_vector (63 downto 0);
  signal n178_o : std_logic;
  signal n179_o : std_logic;
  signal n180_o : std_logic_vector (1471 downto 0);
  signal n181_o : std_logic_vector (1535 downto 0);
  signal n182_o : std_logic_vector (6 downto 0);
  signal n183_o : std_logic_vector (7 downto 0);
  signal n187_o : std_logic_vector (63 downto 0);
  signal n189_o : std_logic_vector (63 downto 0);
  signal n190_o : std_logic;
  signal n193_o : std_logic_vector (63 downto 0);
  signal n194_o : std_logic_vector (63 downto 0);
  signal n195_o : std_logic_vector (63 downto 0);
  signal n196_o : std_logic;
  signal n197_o : std_logic;
  signal n198_o : std_logic_vector (447 downto 0);
  signal n199_o : std_logic_vector (1023 downto 0);
  signal n200_o : std_logic_vector (1535 downto 0);
  signal n201_o : std_logic_vector (6 downto 0);
  signal n202_o : std_logic_vector (7 downto 0);
  signal n203_o : std_logic_vector (127 downto 0);
  signal n205_o : std_logic_vector (127 downto 0);
  signal n206_o : std_logic_vector (127 downto 0);
  signal n207_o : std_logic_vector (63 downto 0);
  signal n208_o : std_logic_vector (63 downto 0);
  signal n209_o : std_logic;
  signal n211_o : std_logic_vector (63 downto 0);
  signal n212_o : std_logic_vector (63 downto 0);
  signal n215_o : std_logic_vector (1 downto 0);
  signal n216_o : std_logic_vector (2 downto 0);
  signal n217_o : std_logic;
  signal n218_o : std_logic_vector (7 downto 0);
  signal n221_o : std_logic_vector (4 downto 0);
  signal n223_o : std_logic_vector (4 downto 0);
  signal n227_o : std_logic;
  signal n229_o : std_logic_vector (4 downto 0);
  signal n231_o : std_logic_vector (4 downto 0);
  signal n233_o : std_logic_vector (4 downto 0);
  signal n235_o : std_logic_vector (4 downto 0);
  signal n239_o : std_logic_vector (63 downto 0);
  signal n241_o : std_logic_vector (1535 downto 0);
  signal n242_o : std_logic;
  signal n243_o : std_logic;
  signal n244_o : std_logic_vector (6 downto 0);
  signal n245_o : std_logic_vector (7 downto 0);
  signal n249_o : std_logic_vector (63 downto 0);
  signal n251_o : std_logic;
  signal n253_o : std_logic_vector (63 downto 0);
  signal n255_o : std_logic_vector (63 downto 0);
  signal n256_o : std_logic_vector (63 downto 0);
  signal n257_o : std_logic_vector (63 downto 0);
  signal n258_o : std_logic_vector (63 downto 0);
  signal n259_o : std_logic_vector (63 downto 0);
  signal n260_o : std_logic;
  signal n261_o : std_logic;
  signal n262_o : std_logic_vector (447 downto 0);
  signal n263_o : std_logic_vector (447 downto 0);
  signal n264_o : std_logic_vector (447 downto 0);
  signal n265_o : std_logic_vector (1023 downto 0);
  signal n266_o : std_logic_vector (1023 downto 0);
  signal n267_o : std_logic_vector (1023 downto 0);
  signal n268_o : std_logic_vector (1535 downto 0);
  signal n269_o : std_logic_vector (6 downto 0);
  signal n270_o : std_logic_vector (7 downto 0);
  signal n274_o : std_logic_vector (63 downto 0);
  signal n276_o : std_logic;
  signal n278_o : std_logic_vector (63 downto 0);
  signal n280_o : std_logic_vector (63 downto 0);
  signal n281_o : std_logic_vector (63 downto 0);
  signal n282_o : std_logic_vector (63 downto 0);
  signal n283_o : std_logic;
  signal n284_o : std_logic;
  signal n285_o : std_logic_vector (383 downto 0);
  signal n286_o : std_logic_vector (1087 downto 0);
  signal n287_o : std_logic_vector (1535 downto 0);
  signal n288_o : std_logic_vector (6 downto 0);
  signal n289_o : std_logic_vector (7 downto 0);
  signal n290_o : std_logic_vector (1535 downto 0);
  signal n291_o : std_logic_vector (7 downto 0);
  signal n292_o : std_logic_vector (1 downto 0);
  signal n294_o : std_logic;
  signal n295_o : std_logic_vector (1 downto 0);
  signal n297_o : std_logic;
  signal n298_o : std_logic;
  signal n302_o : std_logic_vector (63 downto 0);
  signal n304_o : std_logic;
  signal n306_o : std_logic_vector (63 downto 0);
  signal n308_o : std_logic_vector (63 downto 0);
  signal n309_o : std_logic_vector (63 downto 0);
  signal n310_o : std_logic_vector (63 downto 0);
  signal n311_o : std_logic_vector (63 downto 0);
  signal n312_o : std_logic_vector (63 downto 0);
  signal n313_o : std_logic;
  signal n314_o : std_logic;
  signal n315_o : std_logic;
  signal n316_o : std_logic;
  signal n317_o : std_logic_vector (1471 downto 0);
  signal n318_o : std_logic_vector (1471 downto 0);
  signal n319_o : std_logic_vector (1471 downto 0);
  signal n320_o : std_logic_vector (1535 downto 0);
  signal n321_o : std_logic_vector (6 downto 0);
  signal n322_o : std_logic_vector (6 downto 0);
  signal n323_o : std_logic_vector (6 downto 0);
  signal n324_o : std_logic_vector (7 downto 0);
  signal n325_o : std_logic_vector (1535 downto 0);
  signal n326_o : std_logic_vector (7 downto 0);
  signal n327_o : std_logic;
  signal n329_o : std_logic_vector (63 downto 0);
  signal n330_o : std_logic_vector (63 downto 0);
  signal n331_o : std_logic_vector (63 downto 0);
  signal n332_o : std_logic_vector (63 downto 0);
  signal n333_o : std_logic_vector (1535 downto 0);
  signal n334_o : std_logic_vector (7 downto 0);
  signal n339_o : std_logic_vector (2 downto 0);
  signal n340_o : std_logic_vector (63 downto 0);
  signal n341_o : std_logic_vector (63 downto 0);
  signal n343_o : std_logic_vector (3 downto 0);
  signal n345_o : std_logic;
  signal n346_o : std_logic_vector (1535 downto 0);
  signal n347_o : std_logic_vector (1 downto 0);
  signal n348_o : std_logic_vector (2 downto 0);
  signal n349_o : std_logic;
  signal n350_o : std_logic_vector (7 downto 0);
  signal n351_o : std_logic_vector (7 downto 0);
  signal n356_o : std_logic;
  signal n358_o : std_logic;
  signal n359_o : std_logic;
  signal n362_o : std_logic_vector (2 downto 0);
  signal n364_o : std_logic;
  signal n365_o : std_logic;
  signal n366_o : std_logic;
  signal n369_o : std_logic_vector (31 downto 0);
  signal n371_o : std_logic_vector (31 downto 0);
  signal n372_o : std_logic_vector (30 downto 0);
  signal n373_o : std_logic_vector (1 downto 0);
  signal n374_o : std_logic_vector (2 downto 0);
  signal n375_o : std_logic;
  signal n376_o : std_logic_vector (7 downto 0);
  signal n379_o : std_logic_vector (4 downto 0);
  signal n381_o : std_logic_vector (4 downto 0);
  signal n385_o : std_logic;
  signal n387_o : std_logic_vector (4 downto 0);
  signal n389_o : std_logic_vector (4 downto 0);
  signal n391_o : std_logic_vector (4 downto 0);
  signal n393_o : std_logic_vector (4 downto 0);
  signal n397_o : std_logic_vector (63 downto 0);
  signal n399_o : std_logic_vector (1535 downto 0);
  signal n400_o : std_logic;
  signal n401_o : std_logic;
  signal n402_o : std_logic_vector (6 downto 0);
  signal n403_o : std_logic_vector (7 downto 0);
  signal n404_o : std_logic_vector (1 downto 0);
  signal n410_o : std_logic_vector (63 downto 0);
  signal n412_o : std_logic;
  signal n414_o : std_logic_vector (63 downto 0);
  signal n416_o : std_logic_vector (63 downto 0);
  signal n417_o : std_logic_vector (63 downto 0);
  signal n418_o : std_logic_vector (63 downto 0);
  signal n419_o : std_logic_vector (63 downto 0);
  signal n420_o : std_logic_vector (63 downto 0);
  signal n421_o : std_logic;
  signal n422_o : std_logic;
  signal n423_o : std_logic_vector (63 downto 0);
  signal n424_o : std_logic_vector (63 downto 0);
  signal n425_o : std_logic_vector (63 downto 0);
  signal n426_o : std_logic_vector (1407 downto 0);
  signal n427_o : std_logic_vector (1407 downto 0);
  signal n428_o : std_logic_vector (1407 downto 0);
  signal n429_o : std_logic_vector (1535 downto 0);
  signal n430_o : std_logic_vector (6 downto 0);
  signal n431_o : std_logic_vector (7 downto 0);
  signal n433_o : std_logic;
  signal n434_o : std_logic_vector (1535 downto 0);
  signal n435_o : std_logic_vector (7 downto 0);
  signal n436_o : std_logic_vector (1 downto 0);
  signal n440_o : std_logic_vector (3 downto 0);
  signal n441_o : std_logic;
  signal n442_o : std_logic_vector (1535 downto 0);
  signal n443_o : std_logic_vector (4 downto 0);
  signal n444_o : std_logic_vector (1 downto 0);
  signal n445_o : std_logic_vector (1 downto 0);
  signal n446_o : std_logic_vector (4 downto 0);
  signal n447_o : std_logic_vector (4 downto 0);
  signal n448_o : std_logic;
  signal n449_o : std_logic;
  signal n450_o : std_logic_vector (1 downto 0);
  signal n451_o : std_logic;
  signal n452_o : std_logic_vector (1 downto 0);
  signal n453_o : std_logic_vector (1 downto 0);
  signal n455_o : std_logic_vector (2 downto 0);
  signal n456_o : std_logic_vector (3 downto 0);
  signal n457_o : std_logic;
  signal n458_o : std_logic_vector (1535 downto 0);
  signal n459_o : std_logic_vector (7 downto 0);
  signal n460_o : std_logic_vector (1 downto 0);
  signal n461_o : std_logic_vector (2 downto 0);
  signal n462_o : std_logic;
  signal n463_o : std_logic_vector (7 downto 0);
  signal n464_o : std_logic_vector (7 downto 0);
  signal n467_o : std_logic;
  signal n468_o : std_logic_vector (1 downto 0);
  signal n469_o : std_logic_vector (2 downto 0);
  signal n470_o : std_logic;
  signal n471_o : std_logic_vector (7 downto 0);
  signal n473_o : std_logic;
  signal n475_o : std_logic;
  signal n476_o : std_logic_vector (5 downto 0);
  signal n479_o : std_logic_vector (2 downto 0);
  signal n481_o : std_logic_vector (1535 downto 0);
  signal n483_o : std_logic_vector (7 downto 0);
  signal n485_o : std_logic_vector (63 downto 0);
  signal n487_o : std_logic_vector (63 downto 0);
  signal n489_o : std_logic_vector (63 downto 0);
  signal n491_o : std_logic_vector (63 downto 0);
  signal n493_o : std_logic_vector (63 downto 0);
  signal n495_o : std_logic_vector (63 downto 0);
  signal n497_o : std_logic_vector (2 downto 0);
  signal n499_o : std_logic_vector (3 downto 0);
  signal n501_o : std_logic;
  signal n503_o : std_logic_vector (31 downto 0);
  signal n505_o : std_logic_vector (1 downto 0);
  signal n507_o : std_logic_vector (1535 downto 0);
  signal n508_o : std_logic;
  signal n509_o : std_logic;
  signal n510_o : std_logic;
  signal n511_o : std_logic;
  signal n513_o : std_logic;
  signal n514_o : std_logic;
  signal n515_o : std_logic;
  signal n516_o : std_logic;
  signal n517_o : std_logic;
  signal n519_o : std_logic;
  signal n520_o : std_logic;
  signal n521_o : std_logic;
  signal n522_o : std_logic;
  signal n524_o : std_logic;
  signal n525_o : std_logic;
  signal n526_o : std_logic;
  signal n527_o : std_logic;
  signal n528_o : std_logic;
  signal n530_o : std_logic;
  signal n531_o : std_logic;
  signal n532_o : std_logic;
  signal n533_o : std_logic;
  signal n534_o : std_logic;
  signal n536_o : std_logic;
  signal n537_o : std_logic;
  signal n538_o : std_logic;
  signal n539_o : std_logic;
  signal n540_o : std_logic;
  signal n542_o : std_logic;
  signal n543_o : std_logic_vector (1 downto 0);
  signal n544_o : std_logic_vector (1 downto 0);
  signal n545_o : std_logic_vector (1 downto 0);
  signal n546_o : std_logic;
  signal n547_o : std_logic_vector (1 downto 0);
  signal n549_o : std_logic_vector (1 downto 0);
  signal n559_o : std_logic_vector (2 downto 0);
  signal n561_o : std_logic_vector (1535 downto 0);
  signal n563_o : std_logic_vector (7 downto 0);
  signal n565_o : std_logic_vector (63 downto 0);
  signal n567_o : std_logic_vector (63 downto 0);
  signal n569_o : std_logic_vector (63 downto 0);
  signal n571_o : std_logic_vector (63 downto 0);
  signal n573_o : std_logic_vector (63 downto 0);
  signal n575_o : std_logic_vector (63 downto 0);
  signal n577_o : std_logic_vector (2 downto 0);
  signal n579_o : std_logic_vector (3 downto 0);
  signal n581_o : std_logic;
  signal n583_o : std_logic_vector (31 downto 0);
  signal n585_o : std_logic_vector (1 downto 0);
  signal n587_o : std_logic_vector (1535 downto 0);
  signal n588_o : std_logic_vector (7 downto 0);
  signal n590_o : std_logic_vector (7 downto 0);
  signal n618_q : std_logic_vector (2 downto 0) := "000";
  signal n619_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n620_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n621_q : std_logic_vector (7 downto 0) := "00000000";
  signal n622_q : std_logic_vector (7 downto 0) := "00000000";
  signal n623_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n624_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n625_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n626_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n627_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n628_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n629_q : std_logic_vector (2 downto 0) := "000";
  signal n630_q : std_logic_vector (3 downto 0) := "0000";
  signal n631_q : std_logic := '0';
  signal n632_q : std_logic_vector (31 downto 0) := "00000000000000000000000000000000";
  signal n633_q : std_logic_vector (1 downto 0) := "00";
  signal n638_o : std_logic_vector (63 downto 0);
  signal n639_o : std_logic_vector (63 downto 0);
  signal n640_o : std_logic_vector (63 downto 0);
  signal n641_o : std_logic_vector (63 downto 0);
  signal n642_o : std_logic_vector (63 downto 0);
  signal n643_o : std_logic_vector (63 downto 0);
  signal n644_o : std_logic_vector (63 downto 0);
  signal n645_o : std_logic_vector (63 downto 0);
  signal n646_o : std_logic_vector (63 downto 0);
  signal n647_o : std_logic_vector (63 downto 0);
  signal n648_o : std_logic_vector (63 downto 0);
  signal n649_o : std_logic_vector (63 downto 0);
  signal n650_o : std_logic_vector (63 downto 0);
  signal n651_o : std_logic_vector (63 downto 0);
  signal n652_o : std_logic_vector (63 downto 0);
  signal n653_o : std_logic_vector (63 downto 0);
  signal n654_o : std_logic_vector (63 downto 0);
  signal n655_o : std_logic_vector (63 downto 0);
  signal n656_o : std_logic_vector (63 downto 0);
  signal n657_o : std_logic_vector (63 downto 0);
  signal n658_o : std_logic_vector (63 downto 0);
  signal n659_o : std_logic_vector (63 downto 0);
  signal n660_o : std_logic_vector (63 downto 0);
  signal n661_o : std_logic_vector (63 downto 0);
  signal n662_o : std_logic_vector (1 downto 0);
  signal n663_o : std_logic_vector (63 downto 0);
  signal n664_o : std_logic_vector (1 downto 0);
  signal n665_o : std_logic_vector (63 downto 0);
  signal n666_o : std_logic_vector (1 downto 0);
  signal n667_o : std_logic_vector (63 downto 0);
  signal n668_o : std_logic_vector (1 downto 0);
  signal n669_o : std_logic_vector (63 downto 0);
  signal n670_o : std_logic_vector (1 downto 0);
  signal n671_o : std_logic_vector (63 downto 0);
  signal n672_o : std_logic_vector (1 downto 0);
  signal n673_o : std_logic_vector (63 downto 0);
  signal n674_o : std_logic_vector (1 downto 0);
  signal n675_o : std_logic_vector (63 downto 0);
  signal n676_o : std_logic;
  signal n677_o : std_logic_vector (63 downto 0);
  signal n678_o : std_logic;
  signal n679_o : std_logic_vector (63 downto 0);
  signal n680_o : std_logic_vector (63 downto 0);
  signal n681_o : std_logic_vector (63 downto 0);
  signal n682_o : std_logic_vector (63 downto 0);
  signal n683_o : std_logic_vector (63 downto 0);
  signal n684_o : std_logic_vector (63 downto 0);
  signal n685_o : std_logic_vector (63 downto 0);
  signal n686_o : std_logic_vector (63 downto 0);
  signal n687_o : std_logic_vector (63 downto 0);
  signal n688_o : std_logic_vector (63 downto 0);
  signal n689_o : std_logic_vector (63 downto 0);
  signal n690_o : std_logic_vector (63 downto 0);
  signal n691_o : std_logic_vector (63 downto 0);
  signal n692_o : std_logic_vector (63 downto 0);
  signal n693_o : std_logic_vector (63 downto 0);
  signal n694_o : std_logic_vector (63 downto 0);
  signal n695_o : std_logic_vector (63 downto 0);
  signal n696_o : std_logic_vector (63 downto 0);
  signal n697_o : std_logic_vector (63 downto 0);
  signal n698_o : std_logic_vector (63 downto 0);
  signal n699_o : std_logic_vector (63 downto 0);
  signal n700_o : std_logic_vector (63 downto 0);
  signal n701_o : std_logic_vector (63 downto 0);
  signal n702_o : std_logic_vector (63 downto 0);
  signal n703_o : std_logic_vector (63 downto 0);
  signal n704_o : std_logic_vector (1 downto 0);
  signal n705_o : std_logic_vector (63 downto 0);
  signal n706_o : std_logic_vector (1 downto 0);
  signal n707_o : std_logic_vector (63 downto 0);
  signal n708_o : std_logic_vector (1 downto 0);
  signal n709_o : std_logic_vector (63 downto 0);
  signal n710_o : std_logic_vector (1 downto 0);
  signal n711_o : std_logic_vector (63 downto 0);
  signal n712_o : std_logic_vector (1 downto 0);
  signal n713_o : std_logic_vector (63 downto 0);
  signal n714_o : std_logic_vector (1 downto 0);
  signal n715_o : std_logic_vector (63 downto 0);
  signal n716_o : std_logic_vector (1 downto 0);
  signal n717_o : std_logic_vector (63 downto 0);
  signal n718_o : std_logic;
  signal n719_o : std_logic_vector (63 downto 0);
  signal n720_o : std_logic;
  signal n721_o : std_logic_vector (63 downto 0);
  signal n722_o : std_logic;
  signal n723_o : std_logic;
  signal n724_o : std_logic;
  signal n725_o : std_logic;
  signal n726_o : std_logic;
  signal n727_o : std_logic;
  signal n728_o : std_logic;
  signal n729_o : std_logic;
  signal n730_o : std_logic;
  signal n731_o : std_logic;
  signal n732_o : std_logic;
  signal n733_o : std_logic;
  signal n734_o : std_logic;
  signal n735_o : std_logic;
  signal n736_o : std_logic;
  signal n737_o : std_logic;
  signal n738_o : std_logic;
  signal n739_o : std_logic;
  signal n740_o : std_logic;
  signal n741_o : std_logic;
  signal n742_o : std_logic;
  signal n743_o : std_logic;
  signal n744_o : std_logic;
  signal n745_o : std_logic;
  signal n746_o : std_logic;
  signal n747_o : std_logic;
  signal n748_o : std_logic;
  signal n749_o : std_logic;
  signal n750_o : std_logic;
  signal n751_o : std_logic;
  signal n752_o : std_logic;
  signal n753_o : std_logic;
  signal n754_o : std_logic;
  signal n755_o : std_logic;
  signal n756_o : std_logic;
  signal n757_o : std_logic;
  signal n758_o : std_logic;
  signal n759_o : std_logic;
  signal n760_o : std_logic;
  signal n761_o : std_logic;
  signal n762_o : std_logic;
  signal n763_o : std_logic;
  signal n764_o : std_logic;
  signal n765_o : std_logic;
  signal n766_o : std_logic;
  signal n767_o : std_logic;
  signal n768_o : std_logic;
  signal n769_o : std_logic;
  signal n770_o : std_logic;
  signal n771_o : std_logic;
  signal n772_o : std_logic;
  signal n773_o : std_logic;
  signal n774_o : std_logic;
  signal n775_o : std_logic;
  signal n776_o : std_logic;
  signal n777_o : std_logic_vector (63 downto 0);
  signal n778_o : std_logic_vector (63 downto 0);
  signal n779_o : std_logic_vector (63 downto 0);
  signal n780_o : std_logic_vector (63 downto 0);
  signal n781_o : std_logic_vector (63 downto 0);
  signal n782_o : std_logic_vector (63 downto 0);
  signal n783_o : std_logic_vector (63 downto 0);
  signal n784_o : std_logic_vector (63 downto 0);
  signal n785_o : std_logic_vector (63 downto 0);
  signal n786_o : std_logic_vector (63 downto 0);
  signal n787_o : std_logic_vector (63 downto 0);
  signal n788_o : std_logic_vector (63 downto 0);
  signal n789_o : std_logic_vector (63 downto 0);
  signal n790_o : std_logic_vector (63 downto 0);
  signal n791_o : std_logic_vector (63 downto 0);
  signal n792_o : std_logic_vector (63 downto 0);
  signal n793_o : std_logic_vector (63 downto 0);
  signal n794_o : std_logic_vector (63 downto 0);
  signal n795_o : std_logic_vector (63 downto 0);
  signal n796_o : std_logic_vector (63 downto 0);
  signal n797_o : std_logic_vector (63 downto 0);
  signal n798_o : std_logic_vector (63 downto 0);
  signal n799_o : std_logic_vector (63 downto 0);
  signal n800_o : std_logic_vector (63 downto 0);
  signal n801_o : std_logic_vector (63 downto 0);
  signal n802_o : std_logic_vector (63 downto 0);
  signal n803_o : std_logic_vector (63 downto 0);
  signal n804_o : std_logic_vector (63 downto 0);
  signal n805_o : std_logic_vector (63 downto 0);
  signal n806_o : std_logic_vector (63 downto 0);
  signal n807_o : std_logic_vector (63 downto 0);
  signal n808_o : std_logic_vector (63 downto 0);
  signal n809_o : std_logic_vector (63 downto 0);
  signal n810_o : std_logic_vector (63 downto 0);
  signal n811_o : std_logic_vector (63 downto 0);
  signal n812_o : std_logic_vector (63 downto 0);
  signal n813_o : std_logic_vector (63 downto 0);
  signal n814_o : std_logic_vector (63 downto 0);
  signal n815_o : std_logic_vector (63 downto 0);
  signal n816_o : std_logic_vector (63 downto 0);
  signal n817_o : std_logic_vector (63 downto 0);
  signal n818_o : std_logic_vector (63 downto 0);
  signal n819_o : std_logic_vector (63 downto 0);
  signal n820_o : std_logic_vector (63 downto 0);
  signal n821_o : std_logic_vector (63 downto 0);
  signal n822_o : std_logic_vector (63 downto 0);
  signal n823_o : std_logic_vector (63 downto 0);
  signal n824_o : std_logic_vector (63 downto 0);
  signal n825_o : std_logic_vector (1535 downto 0);
  signal n826_o : std_logic_vector (63 downto 0);
  signal n827_o : std_logic_vector (63 downto 0);
  signal n828_o : std_logic_vector (63 downto 0);
  signal n829_o : std_logic_vector (63 downto 0);
  signal n830_o : std_logic_vector (63 downto 0);
  signal n831_o : std_logic_vector (63 downto 0);
  signal n832_o : std_logic_vector (63 downto 0);
  signal n833_o : std_logic_vector (63 downto 0);
  signal n834_o : std_logic_vector (63 downto 0);
  signal n835_o : std_logic_vector (63 downto 0);
  signal n836_o : std_logic_vector (63 downto 0);
  signal n837_o : std_logic_vector (63 downto 0);
  signal n838_o : std_logic_vector (63 downto 0);
  signal n839_o : std_logic_vector (63 downto 0);
  signal n840_o : std_logic_vector (63 downto 0);
  signal n841_o : std_logic_vector (63 downto 0);
  signal n842_o : std_logic_vector (63 downto 0);
  signal n843_o : std_logic_vector (63 downto 0);
  signal n844_o : std_logic_vector (63 downto 0);
  signal n845_o : std_logic_vector (63 downto 0);
  signal n846_o : std_logic_vector (63 downto 0);
  signal n847_o : std_logic_vector (63 downto 0);
  signal n848_o : std_logic_vector (63 downto 0);
  signal n849_o : std_logic_vector (63 downto 0);
  signal n850_o : std_logic_vector (1 downto 0);
  signal n851_o : std_logic_vector (63 downto 0);
  signal n852_o : std_logic_vector (1 downto 0);
  signal n853_o : std_logic_vector (63 downto 0);
  signal n854_o : std_logic_vector (1 downto 0);
  signal n855_o : std_logic_vector (63 downto 0);
  signal n856_o : std_logic_vector (1 downto 0);
  signal n857_o : std_logic_vector (63 downto 0);
  signal n858_o : std_logic_vector (1 downto 0);
  signal n859_o : std_logic_vector (63 downto 0);
  signal n860_o : std_logic_vector (1 downto 0);
  signal n861_o : std_logic_vector (63 downto 0);
  signal n862_o : std_logic_vector (1 downto 0);
  signal n863_o : std_logic_vector (63 downto 0);
  signal n864_o : std_logic;
  signal n865_o : std_logic_vector (63 downto 0);
  signal n866_o : std_logic;
  signal n867_o : std_logic_vector (63 downto 0);
  signal n868_o : std_logic_vector (63 downto 0);
  signal n869_o : std_logic_vector (63 downto 0);
  signal n870_o : std_logic_vector (63 downto 0);
  signal n871_o : std_logic_vector (63 downto 0);
  signal n872_o : std_logic_vector (63 downto 0);
  signal n873_o : std_logic_vector (63 downto 0);
  signal n874_o : std_logic_vector (63 downto 0);
  signal n875_o : std_logic_vector (63 downto 0);
  signal n876_o : std_logic_vector (63 downto 0);
  signal n877_o : std_logic_vector (63 downto 0);
  signal n878_o : std_logic_vector (63 downto 0);
  signal n879_o : std_logic_vector (63 downto 0);
  signal n880_o : std_logic_vector (63 downto 0);
  signal n881_o : std_logic_vector (63 downto 0);
  signal n882_o : std_logic_vector (63 downto 0);
  signal n883_o : std_logic_vector (63 downto 0);
  signal n884_o : std_logic_vector (63 downto 0);
  signal n885_o : std_logic_vector (63 downto 0);
  signal n886_o : std_logic_vector (63 downto 0);
  signal n887_o : std_logic_vector (63 downto 0);
  signal n888_o : std_logic_vector (63 downto 0);
  signal n889_o : std_logic_vector (63 downto 0);
  signal n890_o : std_logic_vector (63 downto 0);
  signal n891_o : std_logic_vector (63 downto 0);
  signal n892_o : std_logic_vector (1 downto 0);
  signal n893_o : std_logic_vector (63 downto 0);
  signal n894_o : std_logic_vector (1 downto 0);
  signal n895_o : std_logic_vector (63 downto 0);
  signal n896_o : std_logic_vector (1 downto 0);
  signal n897_o : std_logic_vector (63 downto 0);
  signal n898_o : std_logic_vector (1 downto 0);
  signal n899_o : std_logic_vector (63 downto 0);
  signal n900_o : std_logic_vector (1 downto 0);
  signal n901_o : std_logic_vector (63 downto 0);
  signal n902_o : std_logic_vector (1 downto 0);
  signal n903_o : std_logic_vector (63 downto 0);
  signal n904_o : std_logic_vector (1 downto 0);
  signal n905_o : std_logic_vector (63 downto 0);
  signal n906_o : std_logic;
  signal n907_o : std_logic_vector (63 downto 0);
  signal n908_o : std_logic;
  signal n909_o : std_logic_vector (63 downto 0);
  signal n910_o : std_logic;
  signal n911_o : std_logic;
  signal n912_o : std_logic;
  signal n913_o : std_logic;
  signal n914_o : std_logic;
  signal n915_o : std_logic;
  signal n916_o : std_logic;
  signal n917_o : std_logic;
  signal n918_o : std_logic;
  signal n919_o : std_logic;
  signal n920_o : std_logic;
  signal n921_o : std_logic;
  signal n922_o : std_logic;
  signal n923_o : std_logic;
  signal n924_o : std_logic;
  signal n925_o : std_logic;
  signal n926_o : std_logic;
  signal n927_o : std_logic;
  signal n928_o : std_logic;
  signal n929_o : std_logic;
  signal n930_o : std_logic;
  signal n931_o : std_logic;
  signal n932_o : std_logic;
  signal n933_o : std_logic;
  signal n934_o : std_logic;
  signal n935_o : std_logic;
  signal n936_o : std_logic;
  signal n937_o : std_logic;
  signal n938_o : std_logic;
  signal n939_o : std_logic;
  signal n940_o : std_logic;
  signal n941_o : std_logic;
  signal n942_o : std_logic;
  signal n943_o : std_logic;
  signal n944_o : std_logic;
  signal n945_o : std_logic;
  signal n946_o : std_logic;
  signal n947_o : std_logic;
  signal n948_o : std_logic;
  signal n949_o : std_logic;
  signal n950_o : std_logic;
  signal n951_o : std_logic;
  signal n952_o : std_logic;
  signal n953_o : std_logic;
  signal n954_o : std_logic;
  signal n955_o : std_logic;
  signal n956_o : std_logic;
  signal n957_o : std_logic;
  signal n958_o : std_logic;
  signal n959_o : std_logic;
  signal n960_o : std_logic;
  signal n961_o : std_logic;
  signal n962_o : std_logic;
  signal n963_o : std_logic;
  signal n964_o : std_logic;
  signal n965_o : std_logic_vector (63 downto 0);
  signal n966_o : std_logic_vector (63 downto 0);
  signal n967_o : std_logic_vector (63 downto 0);
  signal n968_o : std_logic_vector (63 downto 0);
  signal n969_o : std_logic_vector (63 downto 0);
  signal n970_o : std_logic_vector (63 downto 0);
  signal n971_o : std_logic_vector (63 downto 0);
  signal n972_o : std_logic_vector (63 downto 0);
  signal n973_o : std_logic_vector (63 downto 0);
  signal n974_o : std_logic_vector (63 downto 0);
  signal n975_o : std_logic_vector (63 downto 0);
  signal n976_o : std_logic_vector (63 downto 0);
  signal n977_o : std_logic_vector (63 downto 0);
  signal n978_o : std_logic_vector (63 downto 0);
  signal n979_o : std_logic_vector (63 downto 0);
  signal n980_o : std_logic_vector (63 downto 0);
  signal n981_o : std_logic_vector (63 downto 0);
  signal n982_o : std_logic_vector (63 downto 0);
  signal n983_o : std_logic_vector (63 downto 0);
  signal n984_o : std_logic_vector (63 downto 0);
  signal n985_o : std_logic_vector (63 downto 0);
  signal n986_o : std_logic_vector (63 downto 0);
  signal n987_o : std_logic_vector (63 downto 0);
  signal n988_o : std_logic_vector (63 downto 0);
  signal n989_o : std_logic_vector (63 downto 0);
  signal n990_o : std_logic_vector (63 downto 0);
  signal n991_o : std_logic_vector (63 downto 0);
  signal n992_o : std_logic_vector (63 downto 0);
  signal n993_o : std_logic_vector (63 downto 0);
  signal n994_o : std_logic_vector (63 downto 0);
  signal n995_o : std_logic_vector (63 downto 0);
  signal n996_o : std_logic_vector (63 downto 0);
  signal n997_o : std_logic_vector (63 downto 0);
  signal n998_o : std_logic_vector (63 downto 0);
  signal n999_o : std_logic_vector (63 downto 0);
  signal n1000_o : std_logic_vector (63 downto 0);
  signal n1001_o : std_logic_vector (63 downto 0);
  signal n1002_o : std_logic_vector (63 downto 0);
  signal n1003_o : std_logic_vector (63 downto 0);
  signal n1004_o : std_logic_vector (63 downto 0);
  signal n1005_o : std_logic_vector (63 downto 0);
  signal n1006_o : std_logic_vector (63 downto 0);
  signal n1007_o : std_logic_vector (63 downto 0);
  signal n1008_o : std_logic_vector (63 downto 0);
  signal n1009_o : std_logic_vector (63 downto 0);
  signal n1010_o : std_logic_vector (63 downto 0);
  signal n1011_o : std_logic_vector (63 downto 0);
  signal n1012_o : std_logic_vector (63 downto 0);
  signal n1013_o : std_logic_vector (1535 downto 0);
  signal n1014_o : std_logic;
  signal n1015_o : std_logic;
  signal n1016_o : std_logic;
  signal n1017_o : std_logic;
  signal n1018_o : std_logic_vector (1 downto 0);
  signal n1019_o : std_logic;
  signal n1020_o : std_logic;
  signal n1021_o : std_logic;
  signal n1022_o : std_logic;
  signal n1023_o : std_logic;
  signal n1024_o : std_logic;
  signal n1025_o : std_logic;
  signal n1026_o : std_logic;
  signal n1027_o : std_logic;
  signal n1028_o : std_logic;
  signal n1029_o : std_logic;
  signal n1030_o : std_logic;
  signal n1031_o : std_logic;
  signal n1032_o : std_logic;
  signal n1033_o : std_logic;
  signal n1034_o : std_logic;
  signal n1035_o : std_logic;
  signal n1036_o : std_logic_vector (3 downto 0);
begin
  wrap_clk <= clk;
  wrap_reset <= reset;
  wrap_start <= start;
  wrap_cfg_start_ps <= typwrap_cfg_start_ps(cfg_start_ps);
  wrap_cfg_stop_ps <= typwrap_cfg_stop_ps(cfg_stop_ps);
  wrap_cfg_calibration_id <= typwrap_cfg_calibration_id(cfg_calibration_id);
  wrap_cfg_setting <= typwrap_cfg_setting(cfg_setting);
  wrap_in_valid <= in_valid;
  wrap_in_kind <= typwrap_in_kind(in_kind);
  wrap_in_time_ps <= typwrap_in_time_ps(in_time_ps);
  wrap_in_calibration_id <= typwrap_in_calibration_id(in_calibration_id);
  wrap_source_error <= source_error;
  in_ready <= wrap_in_ready;
  snapshot_ready <= wrap_snapshot_ready;
  snapshot_counts ( 0) <= unresolved_unsigned(wrap_snapshot_counts (63 downto 0));
  snapshot_counts ( 1) <= unresolved_unsigned(wrap_snapshot_counts (127 downto 64));
  snapshot_counts ( 2) <= unresolved_unsigned(wrap_snapshot_counts (191 downto 128));
  snapshot_counts ( 3) <= unresolved_unsigned(wrap_snapshot_counts (255 downto 192));
  snapshot_counts ( 4) <= unresolved_unsigned(wrap_snapshot_counts (319 downto 256));
  snapshot_counts ( 5) <= unresolved_unsigned(wrap_snapshot_counts (383 downto 320));
  snapshot_counts ( 6) <= unresolved_unsigned(wrap_snapshot_counts (447 downto 384));
  snapshot_counts ( 7) <= unresolved_unsigned(wrap_snapshot_counts (511 downto 448));
  snapshot_counts ( 8) <= unresolved_unsigned(wrap_snapshot_counts (575 downto 512));
  snapshot_counts ( 9) <= unresolved_unsigned(wrap_snapshot_counts (639 downto 576));
  snapshot_counts ( 10) <= unresolved_unsigned(wrap_snapshot_counts (703 downto 640));
  snapshot_counts ( 11) <= unresolved_unsigned(wrap_snapshot_counts (767 downto 704));
  snapshot_counts ( 12) <= unresolved_unsigned(wrap_snapshot_counts (831 downto 768));
  snapshot_counts ( 13) <= unresolved_unsigned(wrap_snapshot_counts (895 downto 832));
  snapshot_counts ( 14) <= unresolved_unsigned(wrap_snapshot_counts (959 downto 896));
  snapshot_counts ( 15) <= unresolved_unsigned(wrap_snapshot_counts (1023 downto 960));
  snapshot_counts ( 16) <= unresolved_unsigned(wrap_snapshot_counts (1087 downto 1024));
  snapshot_counts ( 17) <= unresolved_unsigned(wrap_snapshot_counts (1151 downto 1088));
  snapshot_counts ( 18) <= unresolved_unsigned(wrap_snapshot_counts (1215 downto 1152));
  snapshot_counts ( 19) <= unresolved_unsigned(wrap_snapshot_counts (1279 downto 1216));
  snapshot_counts ( 20) <= unresolved_unsigned(wrap_snapshot_counts (1343 downto 1280));
  snapshot_counts ( 21) <= unresolved_unsigned(wrap_snapshot_counts (1407 downto 1344));
  snapshot_counts ( 22) <= unresolved_unsigned(wrap_snapshot_counts (1471 downto 1408));
  snapshot_counts ( 23) <= unresolved_unsigned(wrap_snapshot_counts (1535 downto 1472));
  snapshot_flags <= std_ulogic_vector(wrap_snapshot_flags);
  snapshot_start_ps <= unresolved_unsigned(wrap_snapshot_start_ps);
  snapshot_stop_ps <= unresolved_unsigned(wrap_snapshot_stop_ps);
  snapshot_calibration_id <= std_ulogic_vector(wrap_snapshot_calibration_id);
  snapshot_setting <= unresolved_unsigned(wrap_snapshot_setting);
  wrap_in_ready <= n27_o;
  wrap_snapshot_ready <= n32_o;
  wrap_snapshot_counts <= shadow;
  wrap_snapshot_flags <= shadow_flags;
  wrap_snapshot_start_ps <= run_start;
  wrap_snapshot_stop_ps <= run_stop;
  wrap_snapshot_calibration_id <= calibration;
  wrap_snapshot_setting <= setting;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:31:10
  state <= n618_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:32:10
  counts <= n619_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:32:18
  shadow <= n620_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:33:10
  flags <= n621_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:33:17
  shadow_flags <= n622_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:10
  run_start <= n623_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:21
  run_stop <= n624_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:31
  bin_start <= n625_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:42
  bin_end <= n626_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:51
  last_time <= n627_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:62
  item_time <= n628_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:35:10
  item_kind <= n629_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:36:10
  mask <= n630_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:37:10
  repeated <= n631_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:38:10
  calibration <= n632_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:39:10
  setting <= n633_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:44:29
  n26_o <= '1' when state = "001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:44:19
  n27_o <= '0' when n26_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:45:35
  n31_o <= '1' when state = "101" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:45:25
  n32_o <= '0' when n31_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:17
  n44_o <= '1' when state /= "000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:33
  n46_o <= '1' when state /= "101" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:24
  n47_o <= n44_o and n46_o;
  n49_o <= flags (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n50_o <= n49_o when n55_o = '0' else '1';
  n52_o <= flags (6);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n53_o <= n52_o when n57_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n55_o <= n47_o and wrap_source_error;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n57_o <= n47_o and wrap_start;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:97:15
  n60_o <= '0' when wrap_source_error = '0' else '1';
  n63_o <= n61_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:29
  n64_o <= '1' when unsigned (wrap_cfg_stop_ps) <= unsigned (wrap_cfg_start_ps) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:33
  n66_o <= std_logic_vector (unsigned (wrap_cfg_stop_ps) - unsigned (wrap_cfg_start_ps));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:48
  n68_o <= std_logic_vector (unsigned (n66_o) mod unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:54
  n70_o <= '1' when n68_o /= "0000000000000000000000000000000000000000000000000000000000000000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:103:38
  n73_o <= std_logic_vector (unsigned (wrap_cfg_start_ps) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n76_o <= "001" when n70_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n77_o <= n73_o when n70_o = '0' else bin_end;
  n78_o <= n61_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n79_o <= n78_o when n70_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n81_o <= n76_o when n64_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n82_o <= n77_o when n64_o = '0' else bin_end;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n83_o <= n79_o when n64_o = '0' else '1';
  n84_o <= n61_o (7 downto 5);
  n85_o <= n61_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n86_o <= state when wrap_start = '0' else n81_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n87_o <= run_start when wrap_start = '0' else wrap_cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n88_o <= run_stop when wrap_start = '0' else wrap_cfg_stop_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n89_o <= bin_start when wrap_start = '0' else wrap_cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n90_o <= bin_end when wrap_start = '0' else n82_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n91_o <= last_time when wrap_start = '0' else wrap_cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n93_o <= mask when wrap_start = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n95_o <= repeated when wrap_start = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n96_o <= calibration when wrap_start = '0' else wrap_cfg_calibration_id;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n97_o <= setting when wrap_start = '0' else wrap_cfg_setting;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n99_o <= counts when wrap_start = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n100_o <= n84_o & n83_o & n85_o & n60_o & n63_o;
  n101_o <= flags (1 downto 0);
  n102_o <= flags (5 downto 3);
  n103_o <= flags (7);
  n104_o <= n103_o & n53_o & n102_o & n50_o & n101_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n105_o <= n104_o when wrap_start = '0' else n100_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:90:11
  n107_o <= '1' when state = "000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:25
  n109_o <= '1' when unsigned (wrap_in_kind) > unsigned'("100") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:38
  n111_o <= '1' when wrap_in_calibration_id /= calibration else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:31
  n113_o <= '1' when unsigned (wrap_in_time_ps) < unsigned (last_time) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n116_o <= "010" when n113_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n117_o <= wrap_in_time_ps when n113_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n118_o <= wrap_in_time_ps when n113_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n119_o <= wrap_in_kind when n113_o = '0' else item_kind;
  n120_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n121_o <= n120_o when n113_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n122_o <= n116_o when n111_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n123_o <= n117_o when n111_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n124_o <= n118_o when n111_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n125_o <= n119_o when n111_o = '0' else item_kind;
  n126_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n127_o <= n121_o when n111_o = '0' else n126_o;
  n128_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n129_o <= n128_o when n111_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n130_o <= n122_o when n109_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n131_o <= n123_o when n109_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n132_o <= n124_o when n109_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n133_o <= n125_o when n109_o = '0' else item_kind;
  n134_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n135_o <= n127_o when n109_o = '0' else n134_o;
  n136_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n137_o <= n129_o when n109_o = '0' else n136_o;
  n138_o <= flags (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n139_o <= n138_o when n149_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n140_o <= state when wrap_in_valid = '0' else n130_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n141_o <= last_time when wrap_in_valid = '0' else n131_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n142_o <= item_time when wrap_in_valid = '0' else n132_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n143_o <= item_kind when wrap_in_valid = '0' else n133_o;
  n144_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n145_o <= n144_o when wrap_in_valid = '0' else n135_o;
  n146_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n147_o <= n146_o when wrap_in_valid = '0' else n137_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n149_o <= wrap_in_valid and n109_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:106:11
  n151_o <= '1' when state = "001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:25
  n152_o <= '1' when unsigned (bin_start) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:48
  n153_o <= '1' when unsigned (item_time) >= unsigned (bin_end) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:35
  n154_o <= n152_o and n153_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:22
  n156_o <= '1' when mask = "0000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:122:28
  n157_o <= '1' when unsigned (item_time) > unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:122:17
  n158_o <= item_time when n157_o = '0' else run_stop;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:123:38
  n159_o <= std_logic_vector (unsigned (n158_o) - unsigned (bin_start));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:123:49
  n161_o <= std_logic_vector (unsigned (n159_o) / unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  n163_o <= flags (1 downto 0);
  n164_o <= flags (5 downto 3);
  n165_o <= flags (7);
  n166_o <= n165_o & n53_o & n164_o & n50_o & n163_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:31
  n169_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:22
  n171_o <= std_logic_vector (unsigned'("1111111111111111111111111111111111111111111111111111111111111111") - unsigned (n169_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:16
  n172_o <= '1' when unsigned (n161_o) > unsigned (n171_o) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:33
  n175_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:36
  n176_o <= std_logic_vector (unsigned (n175_o) + unsigned (n161_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n177_o <= n176_o when n172_o = '0' else "1111111111111111111111111111111111111111111111111111111111111111";
  n178_o <= n166_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n179_o <= n178_o when n172_o = '0' else '1';
  n180_o <= counts (1471 downto 0);
  n181_o <= n177_o & n180_o;
  n182_o <= n166_o (7 downto 1);
  n183_o <= n182_o & n179_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:31
  n187_o <= n181_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:22
  n189_o <= std_logic_vector (unsigned'("1111111111111111111111111111111111111111111111111111111111111111") - unsigned (n187_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:16
  n190_o <= '1' when unsigned (n161_o) > unsigned (n189_o) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:33
  n193_o <= n181_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:36
  n194_o <= std_logic_vector (unsigned (n193_o) + unsigned (n161_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n195_o <= n194_o when n190_o = '0' else "1111111111111111111111111111111111111111111111111111111111111111";
  n196_o <= n183_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n197_o <= n196_o when n190_o = '0' else '1';
  n198_o <= n181_o (447 downto 0);
  n199_o <= n181_o (1535 downto 512);
  n200_o <= n199_o & n195_o & n198_o;
  n201_o <= n183_o (7 downto 1);
  n202_o <= n201_o & n197_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n203_o <= "0000000000000000000000000000000000000000000000000000000000000000" & n161_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n205_o <= "0000000000000000000000000000000000000000000000000000000000000000" & "0000000000000000000000000000000000000000000000000000001111101000";  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n206_o <= std_logic_vector (resize (signed (n203_o) * signed (n205_o), 128));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:37
  n207_o <= n206_o (63 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:36
  n208_o <= std_logic_vector (unsigned (bin_start) + unsigned (n207_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:28
  n209_o <= '1' when unsigned (n208_o) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:60
  n211_o <= std_logic_vector (unsigned (n208_o) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:17
  n212_o <= bin_end when n209_o = '0' else n211_o;
  n215_o <= flags (1 downto 0);
  n216_o <= flags (5 downto 3);
  n217_o <= flags (7);
  n218_o <= n217_o & n53_o & n216_o & n50_o & n215_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n221_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n223_o <= std_logic_vector (unsigned'("10111") - unsigned (n221_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n227_o <= '1' when n679_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n229_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n231_o <= std_logic_vector (unsigned'("10111") - unsigned (n229_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n233_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n235_o <= std_logic_vector (unsigned'("10111") - unsigned (n233_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n239_o <= std_logic_vector (unsigned (n721_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n241_o <= n825_o when n227_o = '0' else counts;
  n242_o <= n218_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n243_o <= n242_o when n227_o = '0' else '1';
  n244_o <= n218_o (7 downto 1);
  n245_o <= n244_o & n243_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n249_o <= n241_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n251_o <= '1' when n249_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n253_o <= n241_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n255_o <= std_logic_vector (unsigned (n253_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n256_o <= counts (511 downto 448);
  n257_o <= n825_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n258_o <= n257_o when n227_o = '0' else n256_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n259_o <= n255_o when n251_o = '0' else n258_o;
  n260_o <= n245_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n261_o <= n260_o when n251_o = '0' else '1';
  n262_o <= counts (447 downto 0);
  n263_o <= n825_o (447 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n264_o <= n263_o when n227_o = '0' else n262_o;
  n265_o <= counts (1535 downto 512);
  n266_o <= n825_o (1535 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n267_o <= n266_o when n227_o = '0' else n265_o;
  n268_o <= n267_o & n259_o & n264_o;
  n269_o <= n245_o (7 downto 1);
  n270_o <= n269_o & n261_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n274_o <= n268_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n276_o <= '1' when n274_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n278_o <= n268_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n280_o <= std_logic_vector (unsigned (n278_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n281_o <= n268_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n282_o <= n280_o when n276_o = '0' else n281_o;
  n283_o <= n270_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n284_o <= n283_o when n276_o = '0' else '1';
  n285_o <= n268_o (383 downto 0);
  n286_o <= n268_o (1535 downto 448);
  n287_o <= n286_o & n282_o & n285_o;
  n288_o <= n270_o (7 downto 1);
  n289_o <= n288_o & n284_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n290_o <= n268_o when repeated = '0' else n287_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n291_o <= n270_o when repeated = '0' else n289_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:24
  n292_o <= mask (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:36
  n294_o <= '1' when n292_o = "11" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:49
  n295_o <= mask (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:61
  n297_o <= '1' when n295_o = "11" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:42
  n298_o <= n294_o or n297_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n302_o <= n290_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n304_o <= '1' when n302_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n306_o <= n290_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n308_o <= std_logic_vector (unsigned (n306_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n309_o <= n287_o (63 downto 0);
  n310_o <= n268_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n311_o <= n310_o when repeated = '0' else n309_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n312_o <= n308_o when n304_o = '0' else n311_o;
  n313_o <= n289_o (0);
  n314_o <= n270_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n315_o <= n314_o when repeated = '0' else n313_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n316_o <= n315_o when n304_o = '0' else '1';
  n317_o <= n287_o (1535 downto 64);
  n318_o <= n268_o (1535 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n319_o <= n318_o when repeated = '0' else n317_o;
  n320_o <= n319_o & n312_o;
  n321_o <= n289_o (7 downto 1);
  n322_o <= n270_o (7 downto 1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n323_o <= n322_o when repeated = '0' else n321_o;
  n324_o <= n323_o & n316_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:17
  n325_o <= n290_o when n298_o = '0' else n320_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:17
  n326_o <= n291_o when n298_o = '0' else n324_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:27
  n327_o <= '1' when unsigned (bin_end) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:58
  n329_o <= std_logic_vector (unsigned (bin_end) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:17
  n330_o <= bin_end when n327_o = '0' else n329_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n331_o <= bin_end when n156_o = '0' else n208_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n332_o <= n330_o when n156_o = '0' else n212_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n333_o <= n325_o when n156_o = '0' else n200_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n334_o <= n326_o when n156_o = '0' else n202_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n339_o <= "011" when n154_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n340_o <= bin_start when n154_o = '0' else n331_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n341_o <= bin_end when n154_o = '0' else n332_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n343_o <= mask when n154_o = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n345_o <= repeated when n154_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n346_o <= counts when n154_o = '0' else n333_o;
  n347_o <= flags (1 downto 0);
  n348_o <= flags (5 downto 3);
  n349_o <= flags (7);
  n350_o <= n349_o & n53_o & n348_o & n50_o & n347_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n351_o <= n350_o when n154_o = '0' else n334_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:116:11
  n356_o <= '1' when state = "010" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:25
  n358_o <= '1' when item_kind = "100" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:142:27
  n359_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:142:15
  n362_o <= "001" when n359_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:27
  n364_o <= '1' when unsigned (item_time) < unsigned (run_start) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:50
  n365_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:38
  n366_o <= n364_o or n365_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:31
  n369_o <= "00000000000000000000000000000" & item_kind;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:31
  n371_o <= std_logic_vector (unsigned'("00000000000000000000000000010010") + unsigned (n369_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:29
  n372_o <= n371_o (30 downto 0);  --  trunc
  n373_o <= flags (1 downto 0);
  n374_o <= flags (5 downto 3);
  n375_o <= flags (7);
  n376_o <= n375_o & n53_o & n374_o & n50_o & n373_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n379_o <= n372_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n381_o <= std_logic_vector (unsigned'("10111") - unsigned (n379_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n385_o <= '1' when n867_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n387_o <= n372_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n389_o <= std_logic_vector (unsigned'("10111") - unsigned (n387_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n391_o <= n372_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n393_o <= std_logic_vector (unsigned'("10111") - unsigned (n391_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n397_o <= std_logic_vector (unsigned (n909_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n399_o <= n1013_o when n385_o = '0' else counts;
  n400_o <= n376_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n401_o <= n400_o when n385_o = '0' else '1';
  n402_o <= n376_o (7 downto 1);
  n403_o <= n402_o & n401_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  n404_o <= item_kind (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n410_o <= n399_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n412_o <= '1' when n410_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n414_o <= n399_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n416_o <= std_logic_vector (unsigned (n414_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n417_o <= counts (127 downto 64);
  n418_o <= n1013_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n419_o <= n418_o when n385_o = '0' else n417_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n420_o <= n416_o when n412_o = '0' else n419_o;
  n421_o <= n403_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n422_o <= n421_o when n412_o = '0' else '1';
  n423_o <= counts (63 downto 0);
  n424_o <= n1013_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n425_o <= n424_o when n385_o = '0' else n423_o;
  n426_o <= counts (1535 downto 128);
  n427_o <= n1013_o (1535 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n428_o <= n427_o when n385_o = '0' else n426_o;
  n429_o <= n428_o & n420_o & n425_o;
  n430_o <= n403_o (7 downto 1);
  n431_o <= n430_o & n422_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n433_o <= repeated when n1019_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n434_o <= n399_o when n1019_o = '0' else n429_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n435_o <= n403_o when n1019_o = '0' else n431_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:21
  n436_o <= item_kind (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n440_o <= n1036_o when n366_o = '0' else mask;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n441_o <= n433_o when n366_o = '0' else repeated;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n442_o <= n434_o when n366_o = '0' else counts;
  n443_o <= n435_o (4 downto 0);
  n444_o <= flags (1 downto 0);
  n445_o <= flags (4 downto 3);
  n446_o <= n445_o & n50_o & n444_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n447_o <= n443_o when n366_o = '0' else n446_o;
  n448_o <= n435_o (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n449_o <= n448_o when n366_o = '0' else '1';
  n450_o <= n435_o (7 downto 6);
  n451_o <= flags (7);
  n452_o <= n451_o & n53_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n453_o <= n450_o when n366_o = '0' else n452_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n455_o <= "001" when n358_o = '0' else n362_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n456_o <= n440_o when n358_o = '0' else mask;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n457_o <= n441_o when n358_o = '0' else repeated;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n458_o <= n442_o when n358_o = '0' else counts;
  n459_o <= n453_o & n449_o & n447_o;
  n460_o <= flags (1 downto 0);
  n461_o <= flags (5 downto 3);
  n462_o <= flags (7);
  n463_o <= n462_o & n53_o & n461_o & n50_o & n460_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n464_o <= n459_o when n358_o = '0' else n463_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:140:11
  n467_o <= '1' when state = "011" else '0';
  n468_o <= flags (1 downto 0);
  n469_o <= flags (5 downto 3);
  n470_o <= flags (7);
  n471_o <= n470_o & n53_o & n469_o & n50_o & n468_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:156:11
  n473_o <= '1' when state = "100" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:158:11
  n475_o <= '1' when state = "101" else '0';
  n476_o <= n475_o & n473_o & n467_o & n356_o & n151_o & n107_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n479_o <=
    state when "100000",
    "101" when "010000",
    n455_o when "001000",
    n339_o when "000100",
    n140_o when "000010",
    n86_o when "000001",
    "XXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n481_o <=
    shadow when "100000",
    counts when "010000",
    shadow when "001000",
    shadow when "000100",
    shadow when "000010",
    shadow when "000001",
    (1535 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n483_o <=
    shadow_flags when "100000",
    n471_o when "010000",
    shadow_flags when "001000",
    shadow_flags when "000100",
    shadow_flags when "000010",
    shadow_flags when "000001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n485_o <=
    run_start when "100000",
    run_start when "010000",
    run_start when "001000",
    run_start when "000100",
    run_start when "000010",
    n87_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n487_o <=
    run_stop when "100000",
    run_stop when "010000",
    run_stop when "001000",
    run_stop when "000100",
    run_stop when "000010",
    n88_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n489_o <=
    bin_start when "100000",
    bin_start when "010000",
    bin_start when "001000",
    n340_o when "000100",
    bin_start when "000010",
    n89_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n491_o <=
    bin_end when "100000",
    bin_end when "010000",
    bin_end when "001000",
    n341_o when "000100",
    bin_end when "000010",
    n90_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n493_o <=
    last_time when "100000",
    last_time when "010000",
    last_time when "001000",
    last_time when "000100",
    n141_o when "000010",
    n91_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n495_o <=
    item_time when "100000",
    item_time when "010000",
    item_time when "001000",
    item_time when "000100",
    n142_o when "000010",
    item_time when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n497_o <=
    item_kind when "100000",
    item_kind when "010000",
    item_kind when "001000",
    item_kind when "000100",
    n143_o when "000010",
    item_kind when "000001",
    "XXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n499_o <=
    mask when "100000",
    mask when "010000",
    n456_o when "001000",
    n343_o when "000100",
    mask when "000010",
    n93_o when "000001",
    "XXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n501_o <=
    repeated when "100000",
    repeated when "010000",
    n457_o when "001000",
    n345_o when "000100",
    repeated when "000010",
    n95_o when "000001",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n503_o <=
    calibration when "100000",
    calibration when "010000",
    calibration when "001000",
    calibration when "000100",
    calibration when "000010",
    n96_o when "000001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n505_o <=
    setting when "100000",
    setting when "010000",
    setting when "001000",
    setting when "000100",
    setting when "000010",
    n97_o when "000001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n507_o <=
    counts when "100000",
    counts when "010000",
    n458_o when "001000",
    n346_o when "000100",
    counts when "000010",
    n99_o when "000001",
    (1535 downto 0 => 'X') when others;
  n508_o <= n105_o (0);
  n509_o <= n351_o (0);
  n510_o <= n464_o (0);
  n511_o <= flags (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n513_o <=
    n511_o when "100000",
    n511_o when "010000",
    n510_o when "001000",
    n509_o when "000100",
    n511_o when "000010",
    n508_o when "000001",
    'X' when others;
  n514_o <= n105_o (1);
  n515_o <= n351_o (1);
  n516_o <= n464_o (1);
  n517_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n519_o <=
    n517_o when "100000",
    n517_o when "010000",
    n516_o when "001000",
    n515_o when "000100",
    n145_o when "000010",
    n514_o when "000001",
    'X' when others;
  n520_o <= n105_o (2);
  n521_o <= n351_o (2);
  n522_o <= n464_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n524_o <=
    n50_o when "100000",
    n50_o when "010000",
    n522_o when "001000",
    n521_o when "000100",
    n50_o when "000010",
    n520_o when "000001",
    'X' when others;
  n525_o <= n105_o (3);
  n526_o <= n351_o (3);
  n527_o <= n464_o (3);
  n528_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n530_o <=
    n528_o when "100000",
    n528_o when "010000",
    n527_o when "001000",
    n526_o when "000100",
    n147_o when "000010",
    n525_o when "000001",
    'X' when others;
  n531_o <= n105_o (4);
  n532_o <= n351_o (4);
  n533_o <= n464_o (4);
  n534_o <= flags (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n536_o <=
    n534_o when "100000",
    n534_o when "010000",
    n533_o when "001000",
    n532_o when "000100",
    n534_o when "000010",
    n531_o when "000001",
    'X' when others;
  n537_o <= n105_o (5);
  n538_o <= n351_o (5);
  n539_o <= n464_o (5);
  n540_o <= flags (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n542_o <=
    n540_o when "100000",
    n540_o when "010000",
    n539_o when "001000",
    n538_o when "000100",
    n139_o when "000010",
    n537_o when "000001",
    'X' when others;
  n543_o <= n105_o (7 downto 6);
  n544_o <= n351_o (7 downto 6);
  n545_o <= n464_o (7 downto 6);
  n546_o <= flags (7);
  n547_o <= n546_o & n53_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n476_o select n549_o <=
    n547_o when "100000",
    n547_o when "010000",
    n545_o when "001000",
    n544_o when "000100",
    n547_o when "000010",
    n543_o when "000001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n559_o <= n479_o when wrap_reset = '0' else "000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n561_o <= n481_o when wrap_reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n563_o <= n483_o when wrap_reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n565_o <= n485_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n567_o <= n487_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n569_o <= n489_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n571_o <= n491_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n573_o <= n493_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n575_o <= n495_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n577_o <= n497_o when wrap_reset = '0' else "000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n579_o <= n499_o when wrap_reset = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n581_o <= n501_o when wrap_reset = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n583_o <= n503_o when wrap_reset = '0' else "00000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n585_o <= n505_o when wrap_reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n587_o <= n507_o when wrap_reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n588_o <= n549_o & n542_o & n536_o & n530_o & n524_o & n519_o & n513_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n590_o <= n588_o when wrap_reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n618_q <= n559_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n619_q <= n587_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n620_q <= n561_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n621_q <= n590_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n622_q <= n563_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n623_q <= n565_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n624_q <= n567_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n625_q <= n569_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n626_q <= n571_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n627_q <= n573_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n628_q <= n575_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n629_q <= n577_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n630_q <= n579_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n631_q <= n581_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n632_q <= n583_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n633_q <= n585_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:25:5
  n638_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:24:5
  n639_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:23:24
  n640_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:23:5
  n641_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:22:5
  n642_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:21:5
  n643_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:20:5
  n644_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:15:30
  n645_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n646_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n647_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n648_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n649_o <= counts (767 downto 704);
  n650_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n651_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n652_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n653_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n654_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n655_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n656_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n657_o <= counts (1279 downto 1216);
  n658_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n659_o <= counts (1407 downto 1344);
  n660_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n661_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n662_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n662_o select n663_o <=
    n638_o when "00",
    n639_o when "01",
    n640_o when "10",
    n641_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n664_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n664_o select n665_o <=
    n642_o when "00",
    n643_o when "01",
    n644_o when "10",
    n645_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n666_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n666_o select n667_o <=
    n646_o when "00",
    n647_o when "01",
    n648_o when "10",
    n649_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n668_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n668_o select n669_o <=
    n650_o when "00",
    n651_o when "01",
    n652_o when "10",
    n653_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n670_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n670_o select n671_o <=
    n654_o when "00",
    n655_o when "01",
    n656_o when "10",
    n657_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n672_o <= n223_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n672_o select n673_o <=
    n658_o when "00",
    n659_o when "01",
    n660_o when "10",
    n661_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n674_o <= n223_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n674_o select n675_o <=
    n663_o when "00",
    n665_o when "01",
    n667_o when "10",
    n669_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n676_o <= n223_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n677_o <= n671_o when n676_o = '0' else n673_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n678_o <= n223_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n679_o <= n675_o when n678_o = '0' else n677_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:19
  n680_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n681_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n682_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n683_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n684_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n685_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n686_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:129:29
  n687_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n688_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n689_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n690_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n691_o <= counts (767 downto 704);
  n692_o <= counts (831 downto 768);
  n693_o <= counts (895 downto 832);
  n694_o <= counts (959 downto 896);
  n695_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:53:3
  n696_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:36
  n697_o <= counts (1151 downto 1088);
  n698_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:24
  n699_o <= counts (1279 downto 1216);
  n700_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:14
  n701_o <= counts (1407 downto 1344);
  n702_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:56:14
  n703_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n704_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n704_o select n705_o <=
    n680_o when "00",
    n681_o when "01",
    n682_o when "10",
    n683_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n706_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n706_o select n707_o <=
    n684_o when "00",
    n685_o when "01",
    n686_o when "10",
    n687_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n708_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n708_o select n709_o <=
    n688_o when "00",
    n689_o when "01",
    n690_o when "10",
    n691_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n710_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n710_o select n711_o <=
    n692_o when "00",
    n693_o when "01",
    n694_o when "10",
    n695_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n712_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n712_o select n713_o <=
    n696_o when "00",
    n697_o when "01",
    n698_o when "10",
    n699_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n714_o <= n235_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n714_o select n715_o <=
    n700_o when "00",
    n701_o when "01",
    n702_o when "10",
    n703_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n716_o <= n235_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n716_o select n717_o <=
    n705_o when "00",
    n707_o when "01",
    n709_o when "10",
    n711_o when "11",
    (63 downto 0 => 'X') when others;
  n718_o <= n235_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n719_o <= n713_o when n718_o = '0' else n715_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n720_o <= n235_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n721_o <= n717_o when n720_o = '0' else n719_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n722_o <= n231_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n723_o <= not n722_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n724_o <= n231_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n725_o <= not n724_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n726_o <= n723_o and n725_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n727_o <= n723_o and n724_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n728_o <= n722_o and n725_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n729_o <= n231_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n730_o <= not n729_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n731_o <= n726_o and n730_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n732_o <= n726_o and n729_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n733_o <= n727_o and n730_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n734_o <= n727_o and n729_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n735_o <= n728_o and n730_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n736_o <= n728_o and n729_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n737_o <= n231_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n738_o <= not n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n739_o <= n731_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n740_o <= n731_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n741_o <= n732_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n742_o <= n732_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n743_o <= n733_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n744_o <= n733_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n745_o <= n734_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n746_o <= n734_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n747_o <= n735_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n748_o <= n735_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n749_o <= n736_o and n738_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n750_o <= n736_o and n737_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n751_o <= n231_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n752_o <= not n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n753_o <= n739_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n754_o <= n739_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n755_o <= n740_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n756_o <= n740_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n757_o <= n741_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n758_o <= n741_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n759_o <= n742_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n760_o <= n742_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n761_o <= n743_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n762_o <= n743_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n763_o <= n744_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n764_o <= n744_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n765_o <= n745_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n766_o <= n745_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n767_o <= n746_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n768_o <= n746_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n769_o <= n747_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n770_o <= n747_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n771_o <= n748_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n772_o <= n748_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n773_o <= n749_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n774_o <= n749_o and n751_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n775_o <= n750_o and n752_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n776_o <= n750_o and n751_o;
  n777_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n778_o <= n777_o when n753_o = '0' else n239_o;
  n779_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n780_o <= n779_o when n754_o = '0' else n239_o;
  n781_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n782_o <= n781_o when n755_o = '0' else n239_o;
  n783_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n784_o <= n783_o when n756_o = '0' else n239_o;
  n785_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n786_o <= n785_o when n757_o = '0' else n239_o;
  n787_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n788_o <= n787_o when n758_o = '0' else n239_o;
  n789_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n790_o <= n789_o when n759_o = '0' else n239_o;
  n791_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n792_o <= n791_o when n760_o = '0' else n239_o;
  n793_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n794_o <= n793_o when n761_o = '0' else n239_o;
  n795_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n796_o <= n795_o when n762_o = '0' else n239_o;
  n797_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n798_o <= n797_o when n763_o = '0' else n239_o;
  n799_o <= counts (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n800_o <= n799_o when n764_o = '0' else n239_o;
  n801_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n802_o <= n801_o when n765_o = '0' else n239_o;
  n803_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n804_o <= n803_o when n766_o = '0' else n239_o;
  n805_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n806_o <= n805_o when n767_o = '0' else n239_o;
  n807_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n808_o <= n807_o when n768_o = '0' else n239_o;
  n809_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n810_o <= n809_o when n769_o = '0' else n239_o;
  n811_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n812_o <= n811_o when n770_o = '0' else n239_o;
  n813_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n814_o <= n813_o when n771_o = '0' else n239_o;
  n815_o <= counts (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n816_o <= n815_o when n772_o = '0' else n239_o;
  n817_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n818_o <= n817_o when n773_o = '0' else n239_o;
  n819_o <= counts (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n820_o <= n819_o when n774_o = '0' else n239_o;
  n821_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n822_o <= n821_o when n775_o = '0' else n239_o;
  n823_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n824_o <= n823_o when n776_o = '0' else n239_o;
  n825_o <= n824_o & n822_o & n820_o & n818_o & n816_o & n814_o & n812_o & n810_o & n808_o & n806_o & n804_o & n802_o & n800_o & n798_o & n796_o & n794_o & n792_o & n790_o & n788_o & n786_o & n784_o & n782_o & n780_o & n778_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:21
  n826_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n827_o <= counts (127 downto 64);
  n828_o <= counts (191 downto 128);
  n829_o <= counts (255 downto 192);
  n830_o <= counts (319 downto 256);
  n831_o <= counts (383 downto 320);
  n832_o <= counts (447 downto 384);
  n833_o <= counts (511 downto 448);
  n834_o <= counts (575 downto 512);
  n835_o <= counts (639 downto 576);
  n836_o <= counts (703 downto 640);
  n837_o <= counts (767 downto 704);
  n838_o <= counts (831 downto 768);
  n839_o <= counts (895 downto 832);
  n840_o <= counts (959 downto 896);
  n841_o <= counts (1023 downto 960);
  n842_o <= counts (1087 downto 1024);
  n843_o <= counts (1151 downto 1088);
  n844_o <= counts (1215 downto 1152);
  n845_o <= counts (1279 downto 1216);
  n846_o <= counts (1343 downto 1280);
  n847_o <= counts (1407 downto 1344);
  n848_o <= counts (1471 downto 1408);
  n849_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n850_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n850_o select n851_o <=
    n826_o when "00",
    n827_o when "01",
    n828_o when "10",
    n829_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n852_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n852_o select n853_o <=
    n830_o when "00",
    n831_o when "01",
    n832_o when "10",
    n833_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n854_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n854_o select n855_o <=
    n834_o when "00",
    n835_o when "01",
    n836_o when "10",
    n837_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n856_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n856_o select n857_o <=
    n838_o when "00",
    n839_o when "01",
    n840_o when "10",
    n841_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n858_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n858_o select n859_o <=
    n842_o when "00",
    n843_o when "01",
    n844_o when "10",
    n845_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n860_o <= n381_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n860_o select n861_o <=
    n846_o when "00",
    n847_o when "01",
    n848_o when "10",
    n849_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n862_o <= n381_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n862_o select n863_o <=
    n851_o when "00",
    n853_o when "01",
    n855_o when "10",
    n857_o when "11",
    (63 downto 0 => 'X') when others;
  n864_o <= n381_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n865_o <= n859_o when n864_o = '0' else n861_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n866_o <= n381_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n867_o <= n863_o when n866_o = '0' else n865_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:19
  n868_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n869_o <= counts (127 downto 64);
  n870_o <= counts (191 downto 128);
  n871_o <= counts (255 downto 192);
  n872_o <= counts (319 downto 256);
  n873_o <= counts (383 downto 320);
  n874_o <= counts (447 downto 384);
  n875_o <= counts (511 downto 448);
  n876_o <= counts (575 downto 512);
  n877_o <= counts (639 downto 576);
  n878_o <= counts (703 downto 640);
  n879_o <= counts (767 downto 704);
  n880_o <= counts (831 downto 768);
  n881_o <= counts (895 downto 832);
  n882_o <= counts (959 downto 896);
  n883_o <= counts (1023 downto 960);
  n884_o <= counts (1087 downto 1024);
  n885_o <= counts (1151 downto 1088);
  n886_o <= counts (1215 downto 1152);
  n887_o <= counts (1279 downto 1216);
  n888_o <= counts (1343 downto 1280);
  n889_o <= counts (1407 downto 1344);
  n890_o <= counts (1471 downto 1408);
  n891_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n892_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n892_o select n893_o <=
    n868_o when "00",
    n869_o when "01",
    n870_o when "10",
    n871_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n894_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n894_o select n895_o <=
    n872_o when "00",
    n873_o when "01",
    n874_o when "10",
    n875_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n896_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n896_o select n897_o <=
    n876_o when "00",
    n877_o when "01",
    n878_o when "10",
    n879_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n898_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n898_o select n899_o <=
    n880_o when "00",
    n881_o when "01",
    n882_o when "10",
    n883_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n900_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n900_o select n901_o <=
    n884_o when "00",
    n885_o when "01",
    n886_o when "10",
    n887_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n902_o <= n393_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n902_o select n903_o <=
    n888_o when "00",
    n889_o when "01",
    n890_o when "10",
    n891_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n904_o <= n393_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n904_o select n905_o <=
    n893_o when "00",
    n895_o when "01",
    n897_o when "10",
    n899_o when "11",
    (63 downto 0 => 'X') when others;
  n906_o <= n393_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n907_o <= n901_o when n906_o = '0' else n903_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n908_o <= n393_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n909_o <= n905_o when n908_o = '0' else n907_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n910_o <= n389_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n911_o <= not n910_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n912_o <= n389_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n913_o <= not n912_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n914_o <= n911_o and n913_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n915_o <= n911_o and n912_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n916_o <= n910_o and n913_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n917_o <= n389_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n918_o <= not n917_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n919_o <= n914_o and n918_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n920_o <= n914_o and n917_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n921_o <= n915_o and n918_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n922_o <= n915_o and n917_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n923_o <= n916_o and n918_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n924_o <= n916_o and n917_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n925_o <= n389_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n926_o <= not n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n927_o <= n919_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n928_o <= n919_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n929_o <= n920_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n930_o <= n920_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n931_o <= n921_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n932_o <= n921_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n933_o <= n922_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n934_o <= n922_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n935_o <= n923_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n936_o <= n923_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n937_o <= n924_o and n926_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n938_o <= n924_o and n925_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n939_o <= n389_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n940_o <= not n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n941_o <= n927_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n942_o <= n927_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n943_o <= n928_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n944_o <= n928_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n945_o <= n929_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n946_o <= n929_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n947_o <= n930_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n948_o <= n930_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n949_o <= n931_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n950_o <= n931_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n951_o <= n932_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n952_o <= n932_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n953_o <= n933_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n954_o <= n933_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n955_o <= n934_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n956_o <= n934_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n957_o <= n935_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n958_o <= n935_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n959_o <= n936_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n960_o <= n936_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n961_o <= n937_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n962_o <= n937_o and n939_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n963_o <= n938_o and n940_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n964_o <= n938_o and n939_o;
  n965_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n966_o <= n965_o when n941_o = '0' else n397_o;
  n967_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n968_o <= n967_o when n942_o = '0' else n397_o;
  n969_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n970_o <= n969_o when n943_o = '0' else n397_o;
  n971_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n972_o <= n971_o when n944_o = '0' else n397_o;
  n973_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n974_o <= n973_o when n945_o = '0' else n397_o;
  n975_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n976_o <= n975_o when n946_o = '0' else n397_o;
  n977_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n978_o <= n977_o when n947_o = '0' else n397_o;
  n979_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n980_o <= n979_o when n948_o = '0' else n397_o;
  n981_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n982_o <= n981_o when n949_o = '0' else n397_o;
  n983_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n984_o <= n983_o when n950_o = '0' else n397_o;
  n985_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n986_o <= n985_o when n951_o = '0' else n397_o;
  n987_o <= counts (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n988_o <= n987_o when n952_o = '0' else n397_o;
  n989_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n990_o <= n989_o when n953_o = '0' else n397_o;
  n991_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n992_o <= n991_o when n954_o = '0' else n397_o;
  n993_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n994_o <= n993_o when n955_o = '0' else n397_o;
  n995_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n996_o <= n995_o when n956_o = '0' else n397_o;
  n997_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n998_o <= n997_o when n957_o = '0' else n397_o;
  n999_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1000_o <= n999_o when n958_o = '0' else n397_o;
  n1001_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1002_o <= n1001_o when n959_o = '0' else n397_o;
  n1003_o <= counts (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1004_o <= n1003_o when n960_o = '0' else n397_o;
  n1005_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1006_o <= n1005_o when n961_o = '0' else n397_o;
  n1007_o <= counts (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1008_o <= n1007_o when n962_o = '0' else n397_o;
  n1009_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1010_o <= n1009_o when n963_o = '0' else n397_o;
  n1011_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1012_o <= n1011_o when n964_o = '0' else n397_o;
  n1013_o <= n1012_o & n1010_o & n1008_o & n1006_o & n1004_o & n1002_o & n1000_o & n998_o & n996_o & n994_o & n992_o & n990_o & n988_o & n986_o & n984_o & n982_o & n980_o & n978_o & n976_o & n974_o & n972_o & n970_o & n968_o & n966_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:21
  n1014_o <= mask (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1015_o <= mask (1);
  n1016_o <= mask (2);
  n1017_o <= mask (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  n1018_o <= n404_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  with n1018_o select n1019_o <=
    n1014_o when "00",
    n1015_o when "01",
    n1016_o when "10",
    n1017_o when "11",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1020_o <= n436_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1021_o <= not n1020_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1022_o <= n436_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1023_o <= not n1022_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1024_o <= n1021_o and n1023_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1025_o <= n1021_o and n1022_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1026_o <= n1020_o and n1023_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1027_o <= n1020_o and n1022_o;
  n1028_o <= mask (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1029_o <= n1028_o when n1024_o = '0' else '1';
  n1030_o <= mask (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1031_o <= n1030_o when n1025_o = '0' else '1';
  n1032_o <= mask (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1033_o <= n1032_o when n1026_o = '0' else '1';
  n1034_o <= mask (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1035_o <= n1034_o when n1027_o = '0' else '1';
  n1036_o <= n1035_o & n1033_o & n1031_o & n1029_o;
end rtl;
