library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.sagnac_pkg.all;
entity sagnac_uart_top is
  generic (
    WINDOW_PS: positive := 1000;
    CLKS_PER_BIT: positive := 50
  );
  port (
    clk, reset, start: in std_logic;
    cfg_start_ps, cfg_stop_ps, cfg_sequence: in u64;
    cfg_calibration_id: in std_logic_vector (31 downto 0);
    cfg_setting: in unsigned (1 downto 0);
    in_valid: in std_logic;
    in_ready: out std_logic;
    in_kind: in unsigned (2 downto 0);
    in_time_ps: in u64;
    in_calibration_id: in std_logic_vector (31 downto 0);
    source_error: in std_logic;
    tx: out std_logic;
    run_complete, transmit_complete: out std_logic
  );
end entity;
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity uart_tx_50 is
  port (
    clk : in std_logic;
    reset : in std_logic;
    byte_valid : in std_logic;
    byte_data : in std_logic_vector (7 downto 0);
    byte_ready : out std_logic;
    tx : out std_logic);
end entity uart_tx_50;

architecture rtl of uart_tx_50 is
  signal active : std_logic;
  signal frame : std_logic_vector (9 downto 0);
  signal bit_index : std_logic_vector (3 downto 0);
  signal tick : std_logic_vector (5 downto 0);
  signal n1528_o : std_logic;
  signal n1531_o : std_logic;
  signal n1536_o : std_logic;
  signal n1538_o : std_logic_vector (8 downto 0);
  signal n1540_o : std_logic_vector (9 downto 0);
  signal n1542_o : std_logic;
  signal n1543_o : std_logic_vector (9 downto 0);
  signal n1545_o : std_logic_vector (3 downto 0);
  signal n1547_o : std_logic_vector (5 downto 0);
  signal n1548_o : std_logic_vector (31 downto 0);
  signal n1550_o : std_logic;
  signal n1551_o : std_logic_vector (31 downto 0);
  signal n1553_o : std_logic;
  signal n1554_o : std_logic_vector (31 downto 0);
  signal n1556_o : std_logic_vector (31 downto 0);
  signal n1557_o : std_logic_vector (3 downto 0);
  signal n1559_o : std_logic;
  signal n1561_o : std_logic_vector (3 downto 0);
  signal n1562_o : std_logic_vector (31 downto 0);
  signal n1564_o : std_logic_vector (31 downto 0);
  signal n1565_o : std_logic_vector (5 downto 0);
  signal n1566_o : std_logic;
  signal n1567_o : std_logic_vector (3 downto 0);
  signal n1569_o : std_logic_vector (5 downto 0);
  signal n1570_o : std_logic;
  signal n1571_o : std_logic;
  signal n1572_o : std_logic_vector (3 downto 0);
  signal n1573_o : std_logic_vector (5 downto 0);
  signal n1575_o : std_logic;
  signal n1577_o : std_logic_vector (9 downto 0);
  signal n1579_o : std_logic_vector (3 downto 0);
  signal n1581_o : std_logic_vector (5 downto 0);
  signal n1587_q : std_logic := '0';
  signal n1588_q : std_logic_vector (9 downto 0) := "1111111111";
  signal n1589_q : std_logic_vector (3 downto 0) := "0000";
  signal n1590_q : std_logic_vector (5 downto 0) := "000000";
  signal n1591_o : std_logic;
  signal n1592_o : std_logic;
  signal n1593_o : std_logic;
  signal n1594_o : std_logic;
  signal n1595_o : std_logic;
  signal n1596_o : std_logic;
  signal n1597_o : std_logic;
  signal n1598_o : std_logic;
  signal n1599_o : std_logic;
  signal n1600_o : std_logic;
  signal n1601_o : std_logic_vector (1 downto 0);
  signal n1602_o : std_logic;
  signal n1603_o : std_logic_vector (1 downto 0);
  signal n1604_o : std_logic;
  signal n1605_o : std_logic;
  signal n1606_o : std_logic;
  signal n1607_o : std_logic;
  signal n1608_o : std_logic;
  signal n1609_o : std_logic;
  signal n1610_o : std_logic;
begin
  byte_ready <= n1528_o;
  tx <= n1531_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:12:10
  active <= n1587_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:13:10
  frame <= n1588_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:14:10
  bit_index <= n1589_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:15:10
  tick <= n1590_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:17:15
  n1528_o <= not active;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:24
  n1531_o <= '1' when active = '0' else n1610_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:19
  n1536_o <= not active;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:26:22
  n1538_o <= '1' & byte_data;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:26:34
  n1540_o <= n1538_o & '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n1542_o <= active when byte_valid = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n1543_o <= frame when n1571_o = '0' else n1540_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n1545_o <= bit_index when byte_valid = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:25:9
  n1547_o <= tick when byte_valid = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:17
  n1548_o <= "00000000000000000000000000" & tick;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:17
  n1550_o <= '1' when n1548_o = "00000000000000000000000000110001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:21
  n1551_o <= "0000000000000000000000000000" & bit_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:21
  n1553_o <= '1' when n1551_o = "00000000000000000000000000001001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:34
  n1554_o <= "0000000000000000000000000000" & bit_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:34
  n1556_o <= std_logic_vector (unsigned (n1554_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:31:25
  n1557_o <= n1556_o (3 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n1559_o <= active when n1566_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:30:9
  n1561_o <= n1557_o when n1553_o = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:22
  n1562_o <= "00000000000000000000000000" & tick;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:22
  n1564_o <= std_logic_vector (unsigned (n1562_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:32:18
  n1565_o <= n1564_o (5 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n1566_o <= n1550_o and n1553_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n1567_o <= bit_index when n1550_o = '0' else n1561_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:28:7
  n1569_o <= n1565_o when n1550_o = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n1570_o <= n1559_o when n1536_o = '0' else n1542_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n1571_o <= n1536_o and byte_valid;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n1572_o <= n1567_o when n1536_o = '0' else n1545_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:24:7
  n1573_o <= n1569_o when n1536_o = '0' else n1547_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n1575_o <= n1570_o when reset = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n1577_o <= n1543_o when reset = '0' else "1111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n1579_o <= n1572_o when reset = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:22:7
  n1581_o <= n1573_o when reset = '0' else "000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1587_q <= n1575_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1588_q <= n1577_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1589_q <= n1579_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1590_q <= n1581_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:9:53
  n1591_o <= frame (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:8:35
  n1592_o <= frame (1);
  n1593_o <= frame (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:19:3
  n1594_o <= frame (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:21:5
  n1595_o <= frame (4);
  n1596_o <= frame (5);
  n1597_o <= frame (6);
  n1598_o <= frame (7);
  n1599_o <= frame (8);
  n1600_o <= frame (9);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n1601_o <= bit_index (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  with n1601_o select n1602_o <=
    n1591_o when "00",
    n1592_o when "01",
    n1593_o when "10",
    n1594_o when "11",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n1603_o <= bit_index (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  with n1603_o select n1604_o <=
    n1595_o when "00",
    n1596_o when "01",
    n1597_o when "10",
    n1598_o when "11",
    'X' when others;
  n1605_o <= bit_index (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n1606_o <= n1599_o when n1605_o = '0' else n1600_o;
  n1607_o <= bit_index (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n1608_o <= n1602_o when n1607_o = '0' else n1604_o;
  n1609_o <= bit_index (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/uart_tx.vhd:18:12
  n1610_o <= n1608_o when n1609_o = '0' else n1606_o;
end rtl;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity snapshot_framer is
  port (
    clk : in std_logic;
    reset : in std_logic;
    send_valid : in std_logic;
    counts_in : in std_logic_vector (1535 downto 0);
    flags_in : in std_logic_vector (7 downto 0);
    setting_in : in std_logic_vector (1 downto 0);
    calibration_in : in std_logic_vector (31 downto 0);
    start_in : in std_logic_vector (63 downto 0);
    stop_in : in std_logic_vector (63 downto 0);
    width_in : in std_logic_vector (63 downto 0);
    sequence_in : in std_logic_vector (63 downto 0);
    byte_ready : in std_logic;
    send_ready : out std_logic;
    byte_valid : out std_logic;
    byte_data : out std_logic_vector (7 downto 0));
end entity snapshot_framer;

architecture rtl of snapshot_framer is
  signal state : std_logic_vector (1 downto 0);
  signal c : std_logic_vector (1535 downto 0);
  signal f : std_logic_vector (7 downto 0);
  signal s : std_logic_vector (1 downto 0);
  signal cal : std_logic_vector (31 downto 0);
  signal first : std_logic_vector (63 downto 0);
  signal last : std_logic_vector (63 downto 0);
  signal width : std_logic_vector (63 downto 0);
  signal seq : std_logic_vector (63 downto 0);
  signal index : std_logic_vector (7 downto 0);
  signal crc_index : std_logic_vector (1 downto 0);
  signal crc : std_logic_vector (31 downto 0);
  signal octet : std_logic_vector (7 downto 0);
  signal n1102_o : std_logic;
  signal n1103_o : std_logic;
  signal n1107_o : std_logic;
  signal n1108_o : std_logic;
  signal n1113_o : std_logic;
  signal n1115_o : std_logic_vector (31 downto 0);
  signal n1116_o : std_logic_vector (30 downto 0);
  signal n1121_o : std_logic_vector (31 downto 0);
  signal n1123_o : std_logic_vector (31 downto 0);
  signal n1124_o : std_logic_vector (30 downto 0);
  signal n1125_o : std_logic_vector (31 downto 0);
  signal n1126_o : std_logic_vector (7 downto 0);
  signal n1128_o : std_logic;
  signal n1129_o : std_logic_vector (31 downto 0);
  signal n1131_o : std_logic;
  signal n1132_o : std_logic_vector (31 downto 0);
  signal n1134_o : std_logic_vector (31 downto 0);
  signal n1135_o : std_logic_vector (2 downto 0);
  signal n1137_o : std_logic_vector (2 downto 0);
  signal n1143_o : std_logic_vector (31 downto 0);
  signal n1145_o : std_logic;
  signal n1146_o : std_logic_vector (31 downto 0);
  signal n1148_o : std_logic;
  signal n1149_o : std_logic_vector (7 downto 0);
  signal n1150_o : std_logic_vector (31 downto 0);
  signal n1152_o : std_logic;
  signal n1153_o : std_logic_vector (31 downto 0);
  signal n1155_o : std_logic;
  signal n1156_o : std_logic_vector (31 downto 0);
  signal n1158_o : std_logic;
  signal n1160_o : std_logic_vector (31 downto 0);
  signal n1162_o : std_logic_vector (31 downto 0);
  signal n1163_o : std_logic_vector (30 downto 0);
  signal n1168_o : std_logic_vector (31 downto 0);
  signal n1170_o : std_logic_vector (31 downto 0);
  signal n1171_o : std_logic_vector (30 downto 0);
  signal n1172_o : std_logic_vector (31 downto 0);
  signal n1173_o : std_logic_vector (7 downto 0);
  signal n1174_o : std_logic_vector (31 downto 0);
  signal n1176_o : std_logic;
  signal n1178_o : std_logic_vector (31 downto 0);
  signal n1180_o : std_logic_vector (31 downto 0);
  signal n1181_o : std_logic_vector (30 downto 0);
  signal n1186_o : std_logic_vector (31 downto 0);
  signal n1188_o : std_logic_vector (31 downto 0);
  signal n1189_o : std_logic_vector (30 downto 0);
  signal n1190_o : std_logic_vector (63 downto 0);
  signal n1191_o : std_logic_vector (7 downto 0);
  signal n1192_o : std_logic_vector (31 downto 0);
  signal n1194_o : std_logic;
  signal n1196_o : std_logic_vector (31 downto 0);
  signal n1198_o : std_logic_vector (31 downto 0);
  signal n1199_o : std_logic_vector (30 downto 0);
  signal n1204_o : std_logic_vector (31 downto 0);
  signal n1206_o : std_logic_vector (31 downto 0);
  signal n1207_o : std_logic_vector (30 downto 0);
  signal n1208_o : std_logic_vector (63 downto 0);
  signal n1209_o : std_logic_vector (7 downto 0);
  signal n1210_o : std_logic_vector (31 downto 0);
  signal n1212_o : std_logic;
  signal n1214_o : std_logic_vector (31 downto 0);
  signal n1216_o : std_logic_vector (31 downto 0);
  signal n1217_o : std_logic_vector (30 downto 0);
  signal n1222_o : std_logic_vector (31 downto 0);
  signal n1224_o : std_logic_vector (31 downto 0);
  signal n1225_o : std_logic_vector (30 downto 0);
  signal n1226_o : std_logic_vector (63 downto 0);
  signal n1227_o : std_logic_vector (7 downto 0);
  signal n1228_o : std_logic_vector (31 downto 0);
  signal n1230_o : std_logic;
  signal n1232_o : std_logic_vector (31 downto 0);
  signal n1234_o : std_logic_vector (31 downto 0);
  signal n1235_o : std_logic_vector (30 downto 0);
  signal n1240_o : std_logic_vector (31 downto 0);
  signal n1242_o : std_logic_vector (31 downto 0);
  signal n1243_o : std_logic_vector (30 downto 0);
  signal n1244_o : std_logic_vector (63 downto 0);
  signal n1245_o : std_logic_vector (7 downto 0);
  signal n1247_o : std_logic_vector (31 downto 0);
  signal n1249_o : std_logic_vector (31 downto 0);
  signal n1251_o : std_logic_vector (31 downto 0);
  signal n1252_o : std_logic_vector (4 downto 0);
  signal n1254_o : std_logic_vector (4 downto 0);
  signal n1257_o : std_logic_vector (31 downto 0);
  signal n1259_o : std_logic_vector (31 downto 0);
  signal n1260_o : std_logic_vector (2 downto 0);
  signal n1262_o : std_logic_vector (30 downto 0);
  signal n1267_o : std_logic_vector (31 downto 0);
  signal n1269_o : std_logic_vector (31 downto 0);
  signal n1270_o : std_logic_vector (30 downto 0);
  signal n1271_o : std_logic_vector (63 downto 0);
  signal n1272_o : std_logic_vector (7 downto 0);
  signal n1273_o : std_logic_vector (7 downto 0);
  signal n1274_o : std_logic_vector (7 downto 0);
  signal n1275_o : std_logic_vector (7 downto 0);
  signal n1276_o : std_logic_vector (7 downto 0);
  signal n1277_o : std_logic_vector (7 downto 0);
  signal n1279_o : std_logic_vector (7 downto 0);
  signal n1280_o : std_logic_vector (7 downto 0);
  signal n1281_o : std_logic_vector (7 downto 0);
  signal n1283_o : std_logic_vector (7 downto 0);
  signal n1284_o : std_logic_vector (7 downto 0);
  signal n1286_o : std_logic_vector (7 downto 0);
  signal n1287_o : std_logic_vector (7 downto 0);
  signal n1294_o : std_logic_vector (1 downto 0);
  signal n1295_o : std_logic_vector (1535 downto 0);
  signal n1296_o : std_logic_vector (7 downto 0);
  signal n1297_o : std_logic_vector (1 downto 0);
  signal n1298_o : std_logic_vector (31 downto 0);
  signal n1299_o : std_logic_vector (63 downto 0);
  signal n1300_o : std_logic_vector (63 downto 0);
  signal n1301_o : std_logic_vector (63 downto 0);
  signal n1302_o : std_logic_vector (63 downto 0);
  signal n1304_o : std_logic_vector (7 downto 0);
  signal n1306_o : std_logic_vector (31 downto 0);
  signal n1308_o : std_logic;
  signal n1314_o : std_logic_vector (31 downto 0);
  signal n1315_o : std_logic_vector (31 downto 0);
  signal n1316_o : std_logic;
  signal n1318_o : std_logic_vector (31 downto 0);
  signal n1320_o : std_logic_vector (31 downto 0);
  signal n1322_o : std_logic_vector (31 downto 0);
  signal n1323_o : std_logic_vector (31 downto 0);
  signal n1324_o : std_logic;
  signal n1326_o : std_logic_vector (31 downto 0);
  signal n1328_o : std_logic_vector (31 downto 0);
  signal n1330_o : std_logic_vector (31 downto 0);
  signal n1331_o : std_logic_vector (31 downto 0);
  signal n1332_o : std_logic;
  signal n1334_o : std_logic_vector (31 downto 0);
  signal n1336_o : std_logic_vector (31 downto 0);
  signal n1338_o : std_logic_vector (31 downto 0);
  signal n1339_o : std_logic_vector (31 downto 0);
  signal n1340_o : std_logic;
  signal n1342_o : std_logic_vector (31 downto 0);
  signal n1344_o : std_logic_vector (31 downto 0);
  signal n1346_o : std_logic_vector (31 downto 0);
  signal n1347_o : std_logic_vector (31 downto 0);
  signal n1348_o : std_logic;
  signal n1350_o : std_logic_vector (31 downto 0);
  signal n1352_o : std_logic_vector (31 downto 0);
  signal n1354_o : std_logic_vector (31 downto 0);
  signal n1355_o : std_logic_vector (31 downto 0);
  signal n1356_o : std_logic;
  signal n1358_o : std_logic_vector (31 downto 0);
  signal n1360_o : std_logic_vector (31 downto 0);
  signal n1362_o : std_logic_vector (31 downto 0);
  signal n1363_o : std_logic_vector (31 downto 0);
  signal n1364_o : std_logic;
  signal n1366_o : std_logic_vector (31 downto 0);
  signal n1368_o : std_logic_vector (31 downto 0);
  signal n1370_o : std_logic_vector (31 downto 0);
  signal n1371_o : std_logic_vector (31 downto 0);
  signal n1372_o : std_logic;
  signal n1374_o : std_logic_vector (31 downto 0);
  signal n1376_o : std_logic_vector (31 downto 0);
  signal n1378_o : std_logic_vector (31 downto 0);
  signal n1379_o : std_logic_vector (31 downto 0);
  signal n1380_o : std_logic_vector (31 downto 0);
  signal n1382_o : std_logic;
  signal n1383_o : std_logic_vector (31 downto 0);
  signal n1385_o : std_logic_vector (31 downto 0);
  signal n1386_o : std_logic_vector (7 downto 0);
  signal n1388_o : std_logic_vector (1 downto 0);
  signal n1389_o : std_logic_vector (7 downto 0);
  signal n1391_o : std_logic_vector (1 downto 0);
  signal n1392_o : std_logic;
  signal n1393_o : std_logic_vector (7 downto 0);
  signal n1394_o : std_logic;
  signal n1395_o : std_logic_vector (31 downto 0);
  signal n1397_o : std_logic;
  signal n1398_o : std_logic_vector (31 downto 0);
  signal n1400_o : std_logic;
  signal n1401_o : std_logic_vector (31 downto 0);
  signal n1403_o : std_logic_vector (31 downto 0);
  signal n1404_o : std_logic_vector (1 downto 0);
  signal n1406_o : std_logic_vector (1 downto 0);
  signal n1407_o : std_logic_vector (1 downto 0);
  signal n1408_o : std_logic;
  signal n1409_o : std_logic_vector (1 downto 0);
  signal n1411_o : std_logic;
  signal n1412_o : std_logic_vector (2 downto 0);
  signal n1414_o : std_logic_vector (1 downto 0);
  signal n1416_o : std_logic_vector (1535 downto 0);
  signal n1418_o : std_logic_vector (7 downto 0);
  signal n1420_o : std_logic_vector (1 downto 0);
  signal n1422_o : std_logic_vector (31 downto 0);
  signal n1424_o : std_logic_vector (63 downto 0);
  signal n1426_o : std_logic_vector (63 downto 0);
  signal n1428_o : std_logic_vector (63 downto 0);
  signal n1430_o : std_logic_vector (63 downto 0);
  signal n1432_o : std_logic_vector (7 downto 0);
  signal n1434_o : std_logic_vector (1 downto 0);
  signal n1436_o : std_logic_vector (31 downto 0);
  signal n1438_o : std_logic_vector (1 downto 0);
  signal n1439_o : std_logic_vector (1535 downto 0);
  signal n1440_o : std_logic_vector (7 downto 0);
  signal n1441_o : std_logic_vector (1 downto 0);
  signal n1442_o : std_logic_vector (31 downto 0);
  signal n1443_o : std_logic_vector (63 downto 0);
  signal n1444_o : std_logic_vector (63 downto 0);
  signal n1445_o : std_logic_vector (63 downto 0);
  signal n1446_o : std_logic_vector (63 downto 0);
  signal n1448_o : std_logic_vector (7 downto 0);
  signal n1450_o : std_logic_vector (1 downto 0);
  signal n1452_o : std_logic_vector (31 downto 0);
  signal n1466_q : std_logic_vector (1 downto 0) := "00";
  signal n1467_q : std_logic_vector (1535 downto 0);
  signal n1468_q : std_logic_vector (7 downto 0);
  signal n1469_q : std_logic_vector (1 downto 0);
  signal n1470_q : std_logic_vector (31 downto 0);
  signal n1471_q : std_logic_vector (63 downto 0);
  signal n1472_q : std_logic_vector (63 downto 0);
  signal n1473_q : std_logic_vector (63 downto 0);
  signal n1474_q : std_logic_vector (63 downto 0);
  signal n1475_q : std_logic_vector (7 downto 0) := "00000000";
  signal n1476_q : std_logic_vector (1 downto 0) := "00";
  signal n1477_q : std_logic_vector (31 downto 0) := "11111111111111111111111111111111";
  signal n1479_data : std_logic_vector (7 downto 0);
  signal n1480_o : std_logic_vector (63 downto 0);
  signal n1481_o : std_logic_vector (63 downto 0);
  signal n1482_o : std_logic_vector (63 downto 0);
  signal n1483_o : std_logic_vector (63 downto 0);
  signal n1484_o : std_logic_vector (63 downto 0);
  signal n1485_o : std_logic_vector (63 downto 0);
  signal n1486_o : std_logic_vector (63 downto 0);
  signal n1487_o : std_logic_vector (63 downto 0);
  signal n1488_o : std_logic_vector (63 downto 0);
  signal n1489_o : std_logic_vector (63 downto 0);
  signal n1490_o : std_logic_vector (63 downto 0);
  signal n1491_o : std_logic_vector (63 downto 0);
  signal n1492_o : std_logic_vector (63 downto 0);
  signal n1493_o : std_logic_vector (63 downto 0);
  signal n1494_o : std_logic_vector (63 downto 0);
  signal n1495_o : std_logic_vector (63 downto 0);
  signal n1496_o : std_logic_vector (63 downto 0);
  signal n1497_o : std_logic_vector (63 downto 0);
  signal n1498_o : std_logic_vector (63 downto 0);
  signal n1499_o : std_logic_vector (63 downto 0);
  signal n1500_o : std_logic_vector (63 downto 0);
  signal n1501_o : std_logic_vector (63 downto 0);
  signal n1502_o : std_logic_vector (63 downto 0);
  signal n1503_o : std_logic_vector (63 downto 0);
  signal n1504_o : std_logic_vector (1 downto 0);
  signal n1505_o : std_logic_vector (63 downto 0);
  signal n1506_o : std_logic_vector (1 downto 0);
  signal n1507_o : std_logic_vector (63 downto 0);
  signal n1508_o : std_logic_vector (1 downto 0);
  signal n1509_o : std_logic_vector (63 downto 0);
  signal n1510_o : std_logic_vector (1 downto 0);
  signal n1511_o : std_logic_vector (63 downto 0);
  signal n1512_o : std_logic_vector (1 downto 0);
  signal n1513_o : std_logic_vector (63 downto 0);
  signal n1514_o : std_logic_vector (1 downto 0);
  signal n1515_o : std_logic_vector (63 downto 0);
  signal n1516_o : std_logic_vector (1 downto 0);
  signal n1517_o : std_logic_vector (63 downto 0);
  signal n1518_o : std_logic;
  signal n1519_o : std_logic_vector (63 downto 0);
  signal n1520_o : std_logic;
  signal n1521_o : std_logic_vector (63 downto 0);
begin
  send_ready <= n1103_o;
  byte_valid <= n1108_o;
  byte_data <= octet;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:20:10
  state <= n1466_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:21:10
  c <= n1467_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:22:10
  f <= n1468_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:23:10
  s <= n1469_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:24:10
  cal <= n1470_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:10
  first <= n1471_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:16
  last <= n1472_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:21
  width <= n1473_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:25:27
  seq <= n1474_q; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:26:10
  index <= n1475_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:27:10
  crc_index <= n1476_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:28:10
  crc <= n1477_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:29:10
  octet <= n1287_o; -- (signal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:44:29
  n1102_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:44:19
  n1103_o <= '0' when n1102_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:45:29
  n1107_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:45:19
  n1108_o <= '1' when n1107_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:13
  n1113_o <= '1' when state = "10" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:44
  n1115_o <= not crc;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:52
  n1116_o <= "00000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1121_o <= "0" & n1116_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1123_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1121_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1124_o <= n1123_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1125_o <= std_logic_vector (shift_right (unsigned (n1115_o), to_integer(unsigned (n1124_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1126_o <= n1125_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:50:16
  n1128_o <= '1' when state = "01" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:15
  n1129_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:15
  n1131_o <= '1' when signed (n1129_o) < signed'("00000000000000000000000000001000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  n1132_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  n1134_o <= std_logic_vector (unsigned (n1132_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n1135_o <= n1134_o (2 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n1137_o <= std_logic_vector (unsigned'("000") - unsigned (n1135_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:18
  n1143_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:18
  n1145_o <= '1' when n1143_o = "00000000000000000000000000001000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:18
  n1146_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:18
  n1148_o <= '1' when n1146_o = "00000000000000000000000000001001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:50
  n1149_o <= "000000" & s;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:18
  n1150_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:18
  n1152_o <= '1' when n1150_o = "00000000000000000000000000001010" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:18
  n1153_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:18
  n1155_o <= '1' when n1153_o = "00000000000000000000000000001011" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:18
  n1156_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:18
  n1158_o <= '1' when signed (n1156_o) < signed'("00000000000000000000000000010000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:61
  n1160_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:61
  n1162_o <= std_logic_vector (unsigned (n1160_o) - unsigned'("00000000000000000000000000001100"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:56
  n1163_o <= n1162_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1168_o <= "0" & n1163_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1170_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1168_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1171_o <= n1170_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1172_o <= std_logic_vector (shift_right (unsigned (cal), to_integer(unsigned (n1171_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1173_o <= n1172_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:18
  n1174_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:18
  n1176_o <= '1' when signed (n1174_o) < signed'("00000000000000000000000000011000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:53
  n1178_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:53
  n1180_o <= std_logic_vector (unsigned (n1178_o) - unsigned'("00000000000000000000000000010000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:48
  n1181_o <= n1180_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1186_o <= "0" & n1181_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1188_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1186_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1189_o <= n1188_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1190_o <= std_logic_vector (shift_right (unsigned (first), to_integer(unsigned (n1189_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1191_o <= n1190_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:18
  n1192_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:18
  n1194_o <= '1' when signed (n1192_o) < signed'("00000000000000000000000000100000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:52
  n1196_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:52
  n1198_o <= std_logic_vector (unsigned (n1196_o) - unsigned'("00000000000000000000000000011000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:47
  n1199_o <= n1198_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1204_o <= "0" & n1199_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1206_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1204_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1207_o <= n1206_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1208_o <= std_logic_vector (shift_right (unsigned (last), to_integer(unsigned (n1207_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1209_o <= n1208_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:18
  n1210_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:18
  n1212_o <= '1' when signed (n1210_o) < signed'("00000000000000000000000000101000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:53
  n1214_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:53
  n1216_o <= std_logic_vector (unsigned (n1214_o) - unsigned'("00000000000000000000000000100000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:48
  n1217_o <= n1216_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1222_o <= "0" & n1217_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1224_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1222_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1225_o <= n1224_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1226_o <= std_logic_vector (shift_right (unsigned (width), to_integer(unsigned (n1225_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1227_o <= n1226_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:18
  n1228_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:18
  n1230_o <= '1' when signed (n1228_o) < signed'("00000000000000000000000000110000") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:51
  n1232_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:51
  n1234_o <= std_logic_vector (unsigned (n1232_o) - unsigned'("00000000000000000000000000101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:46
  n1235_o <= n1234_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1240_o <= "0" & n1235_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1242_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1240_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1243_o <= n1242_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1244_o <= std_logic_vector (shift_right (unsigned (seq), to_integer(unsigned (n1243_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1245_o <= n1244_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:35
  n1247_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:35
  n1249_o <= std_logic_vector (unsigned (n1247_o) - unsigned'("00000000000000000000000000110000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:39
  n1251_o <= std_logic_vector (signed (n1249_o) / signed'("00000000000000000000000000001000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1252_o <= n1251_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1254_o <= std_logic_vector (unsigned'("10111") - unsigned (n1252_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:49
  n1257_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:49
  n1259_o <= std_logic_vector (unsigned (n1257_o) - unsigned'("00000000000000000000000000110000"));
  n1260_o <= n1259_o (2 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:43
  n1262_o <= "0000000000000000000000000000" & n1260_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1267_o <= "0" & n1262_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:55
  n1269_o <= std_logic_vector (resize (signed'("00000000000000000000000000001000") * signed (n1267_o), 32));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:54
  n1270_o <= n1269_o (30 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:40
  n1271_o <= std_logic_vector (shift_right (unsigned (n1521_o), to_integer(unsigned (n1270_o))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:42:33
  n1272_o <= n1271_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:60:7
  n1273_o <= n1272_o when n1230_o = '0' else n1245_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:59:7
  n1274_o <= n1273_o when n1212_o = '0' else n1227_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:58:7
  n1275_o <= n1274_o when n1194_o = '0' else n1209_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:57:7
  n1276_o <= n1275_o when n1176_o = '0' else n1191_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:56:7
  n1277_o <= n1276_o when n1158_o = '0' else n1173_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:55:7
  n1279_o <= n1277_o when n1155_o = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:54:7
  n1280_o <= n1279_o when n1152_o = '0' else f;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:53:7
  n1281_o <= n1280_o when n1148_o = '0' else n1149_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:52:7
  n1283_o <= n1281_o when n1145_o = '0' else "00000111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:7
  n1284_o <= n1283_o when n1131_o = '0' else n1479_data;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:50:5
  n1286_o <= "00000000" when n1128_o = '0' else n1284_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:49:5
  n1287_o <= n1286_o when n1113_o = '0' else n1126_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1294_o <= state when send_valid = '0' else "01";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1295_o <= c when send_valid = '0' else counts_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1296_o <= f when send_valid = '0' else flags_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1297_o <= s when send_valid = '0' else setting_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1298_o <= cal when send_valid = '0' else calibration_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1299_o <= first when send_valid = '0' else start_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1300_o <= last when send_valid = '0' else stop_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1301_o <= width when send_valid = '0' else width_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1302_o <= seq when send_valid = '0' else sequence_in;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1304_o <= index when send_valid = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:73:13
  n1306_o <= crc when send_valid = '0' else "11111111111111111111111111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:72:11
  n1308_o <= '1' when state = "00" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:56
  n1314_o <= "000000000000000000000000" & octet;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:52
  n1315_o <= crc xor n1314_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1316_o <= n1315_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1318_o <= std_logic_vector (shift_right (unsigned (n1315_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1320_o <= n1318_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1322_o <= std_logic_vector (shift_right (unsigned (n1315_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1323_o <= n1322_o when n1316_o = '0' else n1320_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1324_o <= n1323_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1326_o <= std_logic_vector (shift_right (unsigned (n1323_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1328_o <= n1326_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1330_o <= std_logic_vector (shift_right (unsigned (n1323_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1331_o <= n1330_o when n1324_o = '0' else n1328_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1332_o <= n1331_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1334_o <= std_logic_vector (shift_right (unsigned (n1331_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1336_o <= n1334_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1338_o <= std_logic_vector (shift_right (unsigned (n1331_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1339_o <= n1338_o when n1332_o = '0' else n1336_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1340_o <= n1339_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1342_o <= std_logic_vector (shift_right (unsigned (n1339_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1344_o <= n1342_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1346_o <= std_logic_vector (shift_right (unsigned (n1339_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1347_o <= n1346_o when n1340_o = '0' else n1344_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1348_o <= n1347_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1350_o <= std_logic_vector (shift_right (unsigned (n1347_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1352_o <= n1350_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1354_o <= std_logic_vector (shift_right (unsigned (n1347_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1355_o <= n1354_o when n1348_o = '0' else n1352_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1356_o <= n1355_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1358_o <= std_logic_vector (shift_right (unsigned (n1355_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1360_o <= n1358_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1362_o <= std_logic_vector (shift_right (unsigned (n1355_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1363_o <= n1362_o when n1356_o = '0' else n1360_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1364_o <= n1363_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1366_o <= std_logic_vector (shift_right (unsigned (n1363_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1368_o <= n1366_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1370_o <= std_logic_vector (shift_right (unsigned (n1363_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1371_o <= n1370_o when n1364_o = '0' else n1368_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:11
  n1372_o <= n1371_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:27
  n1374_o <= std_logic_vector (shift_right (unsigned (n1371_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:44
  n1376_o <= n1374_o xor "11101101101110001000001100100000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:37:15
  n1378_o <= std_logic_vector (shift_right (unsigned (n1371_o), to_integer(unsigned'("0000000000000000000000000000001"))));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:36:7
  n1379_o <= n1378_o when n1372_o = '0' else n1376_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:23
  n1380_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:23
  n1382_o <= '1' when n1380_o = "00000000000000000000000011101111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:32
  n1383_o <= "000000000000000000000000" & index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:32
  n1385_o <= std_logic_vector (unsigned (n1383_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:82:27
  n1386_o <= n1385_o (7 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1388_o <= state when n1392_o = '0' else "10";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:81:15
  n1389_o <= n1386_o when n1382_o = '0' else index;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1391_o <= crc_index when n1394_o = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1392_o <= byte_ready and n1382_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1393_o <= index when byte_ready = '0' else n1389_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1394_o <= byte_ready and n1382_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:79:13
  n1395_o <= crc when byte_ready = '0' else n1379_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:78:11
  n1397_o <= '1' when state = "01" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:27
  n1398_o <= "000000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:27
  n1400_o <= '1' when n1398_o = "00000000000000000000000000000011" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:40
  n1401_o <= "000000000000000000000000000000" & crc_index;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:40
  n1403_o <= std_logic_vector (unsigned (n1401_o) + unsigned'("00000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:87:31
  n1404_o <= n1403_o (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n1406_o <= state when n1408_o = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:86:15
  n1407_o <= n1404_o when n1400_o = '0' else crc_index;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n1408_o <= byte_ready and n1400_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:85:13
  n1409_o <= crc_index when byte_ready = '0' else n1407_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:84:11
  n1411_o <= '1' when state = "10" else '0';
  n1412_o <= n1411_o & n1397_o & n1308_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1414_o <=
    n1406_o when "100",
    n1388_o when "010",
    n1294_o when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1416_o <=
    c when "100",
    c when "010",
    n1295_o when "001",
    (1535 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1418_o <=
    f when "100",
    f when "010",
    n1296_o when "001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1420_o <=
    s when "100",
    s when "010",
    n1297_o when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1422_o <=
    cal when "100",
    cal when "010",
    n1298_o when "001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1424_o <=
    first when "100",
    first when "010",
    n1299_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1426_o <=
    last when "100",
    last when "010",
    n1300_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1428_o <=
    width when "100",
    width when "010",
    n1301_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1430_o <=
    seq when "100",
    seq when "010",
    n1302_o when "001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1432_o <=
    index when "100",
    n1393_o when "010",
    n1304_o when "001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1434_o <=
    n1409_o when "100",
    n1391_o when "010",
    crc_index when "001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:71:9
  with n1412_o select n1436_o <=
    crc when "100",
    n1395_o when "010",
    n1306_o when "001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1438_o <= n1414_o when reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1439_o <= n1416_o when reset = '0' else c;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1440_o <= n1418_o when reset = '0' else f;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1441_o <= n1420_o when reset = '0' else s;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1442_o <= n1422_o when reset = '0' else cal;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1443_o <= n1424_o when reset = '0' else first;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1444_o <= n1426_o when reset = '0' else last;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1445_o <= n1428_o when reset = '0' else width;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1446_o <= n1430_o when reset = '0' else seq;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1448_o <= n1432_o when reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1450_o <= n1434_o when reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:68:7
  n1452_o <= n1436_o when reset = '0' else "11111111111111111111111111111111";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1466_q <= n1438_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1467_q <= n1439_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1468_q <= n1440_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1469_q <= n1441_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1470_q <= n1442_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1471_q <= n1443_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1472_q <= n1444_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1473_q <= n1445_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1474_q <= n1446_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1475_q <= n1448_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1476_q <= n1450_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:67:5
  process (clk)
  begin
    if rising_edge (clk) then
      n1477_q <= n1452_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:16:8
  process (n1137_o) is
    type n1478_type is array (0 to 7)
      of std_logic_vector (7 downto 0);
    variable n1478 : n1478_type :=
      (7 => "01010011",
       6 => "01000111",
       5 => "01001110",
       4 => "01000011",
       3 => "01110110",
       2 => "00110000",
       1 => "00110000",
       0 => "00110111");
  begin
    n1479_data <= n1478(to_integer (unsigned (n1137_o)));
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:84
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:78
  n1480_o <= c (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:15:8
  n1481_o <= c (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:9:35
  n1482_o <= c (191 downto 128);
  n1483_o <= c (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:33:14
  n1484_o <= c (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n1485_o <= c (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n1486_o <= c (447 downto 384);
  n1487_o <= c (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:31:12
  n1488_o <= c (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:65:3
  n1489_o <= c (639 downto 576);
  n1490_o <= c (703 downto 640);
  n1491_o <= c (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1492_o <= c (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1493_o <= c (895 downto 832);
  n1494_o <= c (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1495_o <= c (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:54
  n1496_o <= c (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1497_o <= c (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1498_o <= c (1215 downto 1152);
  n1499_o <= c (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1500_o <= c (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1501_o <= c (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:41:12
  n1502_o <= c (1471 downto 1408);
  n1503_o <= c (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1504_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1504_o select n1505_o <=
    n1480_o when "00",
    n1481_o when "01",
    n1482_o when "10",
    n1483_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1506_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1506_o select n1507_o <=
    n1484_o when "00",
    n1485_o when "01",
    n1486_o when "10",
    n1487_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1508_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1508_o select n1509_o <=
    n1488_o when "00",
    n1489_o when "01",
    n1490_o when "10",
    n1491_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1510_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1510_o select n1511_o <=
    n1492_o when "00",
    n1493_o when "01",
    n1494_o when "10",
    n1495_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1512_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1512_o select n1513_o <=
    n1496_o when "00",
    n1497_o when "01",
    n1498_o when "10",
    n1499_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1514_o <= n1254_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1514_o select n1515_o <=
    n1500_o when "00",
    n1501_o when "01",
    n1502_o when "10",
    n1503_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1516_o <= n1254_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  with n1516_o select n1517_o <=
    n1505_o when "00",
    n1507_o when "01",
    n1509_o when "10",
    n1511_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:51:69
  n1518_o <= n1254_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1519_o <= n1513_o when n1518_o = '0' else n1515_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1520_o <= n1254_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/snapshot_framer.vhd:61:28
  n1521_o <= n1517_o when n1520_o = '0' else n1519_o;
end rtl;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity sagnac_core_1000_64 is
  port (
    clk : in std_logic;
    reset : in std_logic;
    start : in std_logic;
    cfg_start_ps : in std_logic_vector (63 downto 0);
    cfg_stop_ps : in std_logic_vector (63 downto 0);
    cfg_calibration_id : in std_logic_vector (31 downto 0);
    cfg_setting : in std_logic_vector (1 downto 0);
    in_valid : in std_logic;
    in_kind : in std_logic_vector (2 downto 0);
    in_time_ps : in std_logic_vector (63 downto 0);
    in_calibration_id : in std_logic_vector (31 downto 0);
    source_error : in std_logic;
    in_ready : out std_logic;
    snapshot_ready : out std_logic;
    snapshot_counts : out std_logic_vector (1535 downto 0);
    snapshot_flags : out std_logic_vector (7 downto 0);
    snapshot_start_ps : out std_logic_vector (63 downto 0);
    snapshot_stop_ps : out std_logic_vector (63 downto 0);
    snapshot_calibration_id : out std_logic_vector (31 downto 0);
    snapshot_setting : out std_logic_vector (1 downto 0));
end entity sagnac_core_1000_64;

architecture rtl of sagnac_core_1000_64 is
  signal state : std_logic_vector (2 downto 0);
  signal counts : std_logic_vector (1535 downto 0);
  signal shadow : std_logic_vector (1535 downto 0);
  signal flags : std_logic_vector (7 downto 0);
  signal shadow_flags : std_logic_vector (7 downto 0);
  signal run_start : std_logic_vector (63 downto 0);
  signal run_stop : std_logic_vector (63 downto 0);
  signal bin_start : std_logic_vector (63 downto 0);
  signal bin_end : std_logic_vector (63 downto 0);
  signal last_time : std_logic_vector (63 downto 0);
  signal item_time : std_logic_vector (63 downto 0);
  signal item_kind : std_logic_vector (2 downto 0);
  signal mask : std_logic_vector (3 downto 0);
  signal repeated : std_logic;
  signal calibration : std_logic_vector (31 downto 0);
  signal setting : std_logic_vector (1 downto 0);
  signal n82_o : std_logic;
  signal n83_o : std_logic;
  signal n87_o : std_logic;
  signal n88_o : std_logic;
  signal n100_o : std_logic;
  signal n102_o : std_logic;
  signal n103_o : std_logic;
  signal n105_o : std_logic;
  signal n106_o : std_logic;
  signal n108_o : std_logic;
  signal n109_o : std_logic;
  signal n111_o : std_logic;
  signal n113_o : std_logic;
  signal n116_o : std_logic;
  constant n117_o : std_logic_vector (7 downto 0) := "00000000";
  signal n119_o : std_logic_vector (1 downto 0);
  signal n120_o : std_logic;
  signal n122_o : std_logic_vector (63 downto 0);
  signal n124_o : std_logic_vector (63 downto 0);
  signal n126_o : std_logic;
  signal n129_o : std_logic_vector (63 downto 0);
  signal n132_o : std_logic_vector (2 downto 0);
  signal n133_o : std_logic_vector (63 downto 0);
  signal n134_o : std_logic;
  signal n135_o : std_logic;
  signal n137_o : std_logic_vector (2 downto 0);
  signal n138_o : std_logic_vector (63 downto 0);
  signal n139_o : std_logic;
  signal n140_o : std_logic_vector (2 downto 0);
  signal n141_o : std_logic;
  signal n142_o : std_logic_vector (2 downto 0);
  signal n143_o : std_logic_vector (63 downto 0);
  signal n144_o : std_logic_vector (63 downto 0);
  signal n145_o : std_logic_vector (63 downto 0);
  signal n146_o : std_logic_vector (63 downto 0);
  signal n147_o : std_logic_vector (63 downto 0);
  signal n149_o : std_logic_vector (3 downto 0);
  signal n151_o : std_logic;
  signal n152_o : std_logic_vector (31 downto 0);
  signal n153_o : std_logic_vector (1 downto 0);
  signal n155_o : std_logic_vector (1535 downto 0);
  signal n156_o : std_logic_vector (7 downto 0);
  signal n157_o : std_logic_vector (1 downto 0);
  signal n158_o : std_logic_vector (2 downto 0);
  signal n159_o : std_logic;
  signal n160_o : std_logic_vector (7 downto 0);
  signal n161_o : std_logic_vector (7 downto 0);
  signal n163_o : std_logic;
  signal n165_o : std_logic;
  signal n167_o : std_logic;
  signal n169_o : std_logic;
  signal n172_o : std_logic_vector (2 downto 0);
  signal n173_o : std_logic_vector (63 downto 0);
  signal n174_o : std_logic_vector (63 downto 0);
  signal n175_o : std_logic_vector (2 downto 0);
  signal n176_o : std_logic;
  signal n177_o : std_logic;
  signal n178_o : std_logic_vector (2 downto 0);
  signal n179_o : std_logic_vector (63 downto 0);
  signal n180_o : std_logic_vector (63 downto 0);
  signal n181_o : std_logic_vector (2 downto 0);
  signal n182_o : std_logic;
  signal n183_o : std_logic;
  signal n184_o : std_logic;
  signal n185_o : std_logic;
  signal n186_o : std_logic_vector (2 downto 0);
  signal n187_o : std_logic_vector (63 downto 0);
  signal n188_o : std_logic_vector (63 downto 0);
  signal n189_o : std_logic_vector (2 downto 0);
  signal n190_o : std_logic;
  signal n191_o : std_logic;
  signal n192_o : std_logic;
  signal n193_o : std_logic;
  signal n194_o : std_logic;
  signal n195_o : std_logic;
  signal n196_o : std_logic_vector (2 downto 0);
  signal n197_o : std_logic_vector (63 downto 0);
  signal n198_o : std_logic_vector (63 downto 0);
  signal n199_o : std_logic_vector (2 downto 0);
  signal n200_o : std_logic;
  signal n201_o : std_logic;
  signal n202_o : std_logic;
  signal n203_o : std_logic;
  signal n205_o : std_logic;
  signal n207_o : std_logic;
  signal n208_o : std_logic;
  signal n209_o : std_logic;
  signal n210_o : std_logic;
  signal n212_o : std_logic;
  signal n213_o : std_logic;
  signal n214_o : std_logic_vector (63 downto 0);
  signal n215_o : std_logic_vector (63 downto 0);
  signal n217_o : std_logic_vector (63 downto 0);
  signal n219_o : std_logic_vector (1 downto 0);
  signal n220_o : std_logic_vector (2 downto 0);
  signal n221_o : std_logic;
  signal n222_o : std_logic_vector (7 downto 0);
  signal n225_o : std_logic_vector (63 downto 0);
  signal n227_o : std_logic_vector (63 downto 0);
  signal n228_o : std_logic;
  signal n231_o : std_logic_vector (63 downto 0);
  signal n232_o : std_logic_vector (63 downto 0);
  signal n233_o : std_logic_vector (63 downto 0);
  signal n234_o : std_logic;
  signal n235_o : std_logic;
  signal n236_o : std_logic_vector (1471 downto 0);
  signal n237_o : std_logic_vector (1535 downto 0);
  signal n238_o : std_logic_vector (6 downto 0);
  signal n239_o : std_logic_vector (7 downto 0);
  signal n243_o : std_logic_vector (63 downto 0);
  signal n245_o : std_logic_vector (63 downto 0);
  signal n246_o : std_logic;
  signal n249_o : std_logic_vector (63 downto 0);
  signal n250_o : std_logic_vector (63 downto 0);
  signal n251_o : std_logic_vector (63 downto 0);
  signal n252_o : std_logic;
  signal n253_o : std_logic;
  signal n254_o : std_logic_vector (447 downto 0);
  signal n255_o : std_logic_vector (1023 downto 0);
  signal n256_o : std_logic_vector (1535 downto 0);
  signal n257_o : std_logic_vector (6 downto 0);
  signal n258_o : std_logic_vector (7 downto 0);
  signal n259_o : std_logic_vector (127 downto 0);
  signal n261_o : std_logic_vector (127 downto 0);
  signal n262_o : std_logic_vector (127 downto 0);
  signal n263_o : std_logic_vector (63 downto 0);
  signal n264_o : std_logic_vector (63 downto 0);
  signal n265_o : std_logic;
  signal n267_o : std_logic_vector (63 downto 0);
  signal n268_o : std_logic_vector (63 downto 0);
  signal n271_o : std_logic_vector (1 downto 0);
  signal n272_o : std_logic_vector (2 downto 0);
  signal n273_o : std_logic;
  signal n274_o : std_logic_vector (7 downto 0);
  signal n277_o : std_logic_vector (4 downto 0);
  signal n279_o : std_logic_vector (4 downto 0);
  signal n283_o : std_logic;
  signal n285_o : std_logic_vector (4 downto 0);
  signal n287_o : std_logic_vector (4 downto 0);
  signal n289_o : std_logic_vector (4 downto 0);
  signal n291_o : std_logic_vector (4 downto 0);
  signal n295_o : std_logic_vector (63 downto 0);
  signal n297_o : std_logic_vector (1535 downto 0);
  signal n298_o : std_logic;
  signal n299_o : std_logic;
  signal n300_o : std_logic_vector (6 downto 0);
  signal n301_o : std_logic_vector (7 downto 0);
  signal n305_o : std_logic_vector (63 downto 0);
  signal n307_o : std_logic;
  signal n309_o : std_logic_vector (63 downto 0);
  signal n311_o : std_logic_vector (63 downto 0);
  signal n312_o : std_logic_vector (63 downto 0);
  signal n313_o : std_logic_vector (63 downto 0);
  signal n314_o : std_logic_vector (63 downto 0);
  signal n315_o : std_logic_vector (63 downto 0);
  signal n316_o : std_logic;
  signal n317_o : std_logic;
  signal n318_o : std_logic_vector (447 downto 0);
  signal n319_o : std_logic_vector (447 downto 0);
  signal n320_o : std_logic_vector (447 downto 0);
  signal n321_o : std_logic_vector (1023 downto 0);
  signal n322_o : std_logic_vector (1023 downto 0);
  signal n323_o : std_logic_vector (1023 downto 0);
  signal n324_o : std_logic_vector (1535 downto 0);
  signal n325_o : std_logic_vector (6 downto 0);
  signal n326_o : std_logic_vector (7 downto 0);
  signal n330_o : std_logic_vector (63 downto 0);
  signal n332_o : std_logic;
  signal n334_o : std_logic_vector (63 downto 0);
  signal n336_o : std_logic_vector (63 downto 0);
  signal n337_o : std_logic_vector (63 downto 0);
  signal n338_o : std_logic_vector (63 downto 0);
  signal n339_o : std_logic;
  signal n340_o : std_logic;
  signal n341_o : std_logic_vector (383 downto 0);
  signal n342_o : std_logic_vector (1087 downto 0);
  signal n343_o : std_logic_vector (1535 downto 0);
  signal n344_o : std_logic_vector (6 downto 0);
  signal n345_o : std_logic_vector (7 downto 0);
  signal n346_o : std_logic_vector (1535 downto 0);
  signal n347_o : std_logic_vector (7 downto 0);
  signal n348_o : std_logic_vector (1 downto 0);
  signal n350_o : std_logic;
  signal n351_o : std_logic_vector (1 downto 0);
  signal n353_o : std_logic;
  signal n354_o : std_logic;
  signal n358_o : std_logic_vector (63 downto 0);
  signal n360_o : std_logic;
  signal n362_o : std_logic_vector (63 downto 0);
  signal n364_o : std_logic_vector (63 downto 0);
  signal n365_o : std_logic_vector (63 downto 0);
  signal n366_o : std_logic_vector (63 downto 0);
  signal n367_o : std_logic_vector (63 downto 0);
  signal n368_o : std_logic_vector (63 downto 0);
  signal n369_o : std_logic;
  signal n370_o : std_logic;
  signal n371_o : std_logic;
  signal n372_o : std_logic;
  signal n373_o : std_logic_vector (1471 downto 0);
  signal n374_o : std_logic_vector (1471 downto 0);
  signal n375_o : std_logic_vector (1471 downto 0);
  signal n376_o : std_logic_vector (1535 downto 0);
  signal n377_o : std_logic_vector (6 downto 0);
  signal n378_o : std_logic_vector (6 downto 0);
  signal n379_o : std_logic_vector (6 downto 0);
  signal n380_o : std_logic_vector (7 downto 0);
  signal n381_o : std_logic_vector (1535 downto 0);
  signal n382_o : std_logic_vector (7 downto 0);
  signal n383_o : std_logic;
  signal n385_o : std_logic_vector (63 downto 0);
  signal n386_o : std_logic_vector (63 downto 0);
  signal n387_o : std_logic_vector (63 downto 0);
  signal n388_o : std_logic_vector (63 downto 0);
  signal n389_o : std_logic_vector (1535 downto 0);
  signal n390_o : std_logic_vector (7 downto 0);
  signal n395_o : std_logic_vector (2 downto 0);
  signal n396_o : std_logic_vector (63 downto 0);
  signal n397_o : std_logic_vector (63 downto 0);
  signal n399_o : std_logic_vector (3 downto 0);
  signal n401_o : std_logic;
  signal n402_o : std_logic_vector (1535 downto 0);
  signal n403_o : std_logic_vector (1 downto 0);
  signal n404_o : std_logic_vector (2 downto 0);
  signal n405_o : std_logic;
  signal n406_o : std_logic_vector (7 downto 0);
  signal n407_o : std_logic_vector (7 downto 0);
  signal n412_o : std_logic;
  signal n414_o : std_logic;
  signal n415_o : std_logic;
  signal n418_o : std_logic_vector (2 downto 0);
  signal n420_o : std_logic;
  signal n421_o : std_logic;
  signal n422_o : std_logic;
  signal n425_o : std_logic_vector (31 downto 0);
  signal n427_o : std_logic_vector (31 downto 0);
  signal n428_o : std_logic_vector (30 downto 0);
  signal n429_o : std_logic_vector (1 downto 0);
  signal n430_o : std_logic_vector (2 downto 0);
  signal n431_o : std_logic;
  signal n432_o : std_logic_vector (7 downto 0);
  signal n435_o : std_logic_vector (4 downto 0);
  signal n437_o : std_logic_vector (4 downto 0);
  signal n441_o : std_logic;
  signal n443_o : std_logic_vector (4 downto 0);
  signal n445_o : std_logic_vector (4 downto 0);
  signal n447_o : std_logic_vector (4 downto 0);
  signal n449_o : std_logic_vector (4 downto 0);
  signal n453_o : std_logic_vector (63 downto 0);
  signal n455_o : std_logic_vector (1535 downto 0);
  signal n456_o : std_logic;
  signal n457_o : std_logic;
  signal n458_o : std_logic_vector (6 downto 0);
  signal n459_o : std_logic_vector (7 downto 0);
  signal n460_o : std_logic_vector (1 downto 0);
  signal n466_o : std_logic_vector (63 downto 0);
  signal n468_o : std_logic;
  signal n470_o : std_logic_vector (63 downto 0);
  signal n472_o : std_logic_vector (63 downto 0);
  signal n473_o : std_logic_vector (63 downto 0);
  signal n474_o : std_logic_vector (63 downto 0);
  signal n475_o : std_logic_vector (63 downto 0);
  signal n476_o : std_logic_vector (63 downto 0);
  signal n477_o : std_logic;
  signal n478_o : std_logic;
  signal n479_o : std_logic_vector (63 downto 0);
  signal n480_o : std_logic_vector (63 downto 0);
  signal n481_o : std_logic_vector (63 downto 0);
  signal n482_o : std_logic_vector (1407 downto 0);
  signal n483_o : std_logic_vector (1407 downto 0);
  signal n484_o : std_logic_vector (1407 downto 0);
  signal n485_o : std_logic_vector (1535 downto 0);
  signal n486_o : std_logic_vector (6 downto 0);
  signal n487_o : std_logic_vector (7 downto 0);
  signal n489_o : std_logic;
  signal n490_o : std_logic_vector (1535 downto 0);
  signal n491_o : std_logic_vector (7 downto 0);
  signal n492_o : std_logic_vector (1 downto 0);
  signal n496_o : std_logic_vector (3 downto 0);
  signal n497_o : std_logic;
  signal n498_o : std_logic_vector (1535 downto 0);
  signal n499_o : std_logic_vector (4 downto 0);
  signal n500_o : std_logic_vector (1 downto 0);
  signal n501_o : std_logic_vector (1 downto 0);
  signal n502_o : std_logic_vector (4 downto 0);
  signal n503_o : std_logic_vector (4 downto 0);
  signal n504_o : std_logic;
  signal n505_o : std_logic;
  signal n506_o : std_logic_vector (1 downto 0);
  signal n507_o : std_logic;
  signal n508_o : std_logic_vector (1 downto 0);
  signal n509_o : std_logic_vector (1 downto 0);
  signal n511_o : std_logic_vector (2 downto 0);
  signal n512_o : std_logic_vector (3 downto 0);
  signal n513_o : std_logic;
  signal n514_o : std_logic_vector (1535 downto 0);
  signal n515_o : std_logic_vector (7 downto 0);
  signal n516_o : std_logic_vector (1 downto 0);
  signal n517_o : std_logic_vector (2 downto 0);
  signal n518_o : std_logic;
  signal n519_o : std_logic_vector (7 downto 0);
  signal n520_o : std_logic_vector (7 downto 0);
  signal n523_o : std_logic;
  signal n524_o : std_logic_vector (1 downto 0);
  signal n525_o : std_logic_vector (2 downto 0);
  signal n526_o : std_logic;
  signal n527_o : std_logic_vector (7 downto 0);
  signal n529_o : std_logic;
  signal n531_o : std_logic;
  signal n532_o : std_logic_vector (5 downto 0);
  signal n535_o : std_logic_vector (2 downto 0);
  signal n537_o : std_logic_vector (1535 downto 0);
  signal n539_o : std_logic_vector (7 downto 0);
  signal n541_o : std_logic_vector (63 downto 0);
  signal n543_o : std_logic_vector (63 downto 0);
  signal n545_o : std_logic_vector (63 downto 0);
  signal n547_o : std_logic_vector (63 downto 0);
  signal n549_o : std_logic_vector (63 downto 0);
  signal n551_o : std_logic_vector (63 downto 0);
  signal n553_o : std_logic_vector (2 downto 0);
  signal n555_o : std_logic_vector (3 downto 0);
  signal n557_o : std_logic;
  signal n559_o : std_logic_vector (31 downto 0);
  signal n561_o : std_logic_vector (1 downto 0);
  signal n563_o : std_logic_vector (1535 downto 0);
  signal n564_o : std_logic;
  signal n565_o : std_logic;
  signal n566_o : std_logic;
  signal n567_o : std_logic;
  signal n569_o : std_logic;
  signal n570_o : std_logic;
  signal n571_o : std_logic;
  signal n572_o : std_logic;
  signal n573_o : std_logic;
  signal n575_o : std_logic;
  signal n576_o : std_logic;
  signal n577_o : std_logic;
  signal n578_o : std_logic;
  signal n580_o : std_logic;
  signal n581_o : std_logic;
  signal n582_o : std_logic;
  signal n583_o : std_logic;
  signal n584_o : std_logic;
  signal n586_o : std_logic;
  signal n587_o : std_logic;
  signal n588_o : std_logic;
  signal n589_o : std_logic;
  signal n590_o : std_logic;
  signal n592_o : std_logic;
  signal n593_o : std_logic;
  signal n594_o : std_logic;
  signal n595_o : std_logic;
  signal n596_o : std_logic;
  signal n598_o : std_logic;
  signal n599_o : std_logic_vector (1 downto 0);
  signal n600_o : std_logic_vector (1 downto 0);
  signal n601_o : std_logic_vector (1 downto 0);
  signal n602_o : std_logic;
  signal n603_o : std_logic_vector (1 downto 0);
  signal n605_o : std_logic_vector (1 downto 0);
  signal n615_o : std_logic_vector (2 downto 0);
  signal n617_o : std_logic_vector (1535 downto 0);
  signal n619_o : std_logic_vector (7 downto 0);
  signal n621_o : std_logic_vector (63 downto 0);
  signal n623_o : std_logic_vector (63 downto 0);
  signal n625_o : std_logic_vector (63 downto 0);
  signal n627_o : std_logic_vector (63 downto 0);
  signal n629_o : std_logic_vector (63 downto 0);
  signal n631_o : std_logic_vector (63 downto 0);
  signal n633_o : std_logic_vector (2 downto 0);
  signal n635_o : std_logic_vector (3 downto 0);
  signal n637_o : std_logic;
  signal n639_o : std_logic_vector (31 downto 0);
  signal n641_o : std_logic_vector (1 downto 0);
  signal n643_o : std_logic_vector (1535 downto 0);
  signal n644_o : std_logic_vector (7 downto 0);
  signal n646_o : std_logic_vector (7 downto 0);
  signal n674_q : std_logic_vector (2 downto 0) := "000";
  signal n675_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n676_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n677_q : std_logic_vector (7 downto 0) := "00000000";
  signal n678_q : std_logic_vector (7 downto 0) := "00000000";
  signal n679_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n680_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n681_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n682_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n683_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n684_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n685_q : std_logic_vector (2 downto 0) := "000";
  signal n686_q : std_logic_vector (3 downto 0) := "0000";
  signal n687_q : std_logic := '0';
  signal n688_q : std_logic_vector (31 downto 0) := "00000000000000000000000000000000";
  signal n689_q : std_logic_vector (1 downto 0) := "00";
  signal n694_o : std_logic_vector (63 downto 0);
  signal n695_o : std_logic_vector (63 downto 0);
  signal n696_o : std_logic_vector (63 downto 0);
  signal n697_o : std_logic_vector (63 downto 0);
  signal n698_o : std_logic_vector (63 downto 0);
  signal n699_o : std_logic_vector (63 downto 0);
  signal n700_o : std_logic_vector (63 downto 0);
  signal n701_o : std_logic_vector (63 downto 0);
  signal n702_o : std_logic_vector (63 downto 0);
  signal n703_o : std_logic_vector (63 downto 0);
  signal n704_o : std_logic_vector (63 downto 0);
  signal n705_o : std_logic_vector (63 downto 0);
  signal n706_o : std_logic_vector (63 downto 0);
  signal n707_o : std_logic_vector (63 downto 0);
  signal n708_o : std_logic_vector (63 downto 0);
  signal n709_o : std_logic_vector (63 downto 0);
  signal n710_o : std_logic_vector (63 downto 0);
  signal n711_o : std_logic_vector (63 downto 0);
  signal n712_o : std_logic_vector (63 downto 0);
  signal n713_o : std_logic_vector (63 downto 0);
  signal n714_o : std_logic_vector (63 downto 0);
  signal n715_o : std_logic_vector (63 downto 0);
  signal n716_o : std_logic_vector (63 downto 0);
  signal n717_o : std_logic_vector (63 downto 0);
  signal n718_o : std_logic_vector (1 downto 0);
  signal n719_o : std_logic_vector (63 downto 0);
  signal n720_o : std_logic_vector (1 downto 0);
  signal n721_o : std_logic_vector (63 downto 0);
  signal n722_o : std_logic_vector (1 downto 0);
  signal n723_o : std_logic_vector (63 downto 0);
  signal n724_o : std_logic_vector (1 downto 0);
  signal n725_o : std_logic_vector (63 downto 0);
  signal n726_o : std_logic_vector (1 downto 0);
  signal n727_o : std_logic_vector (63 downto 0);
  signal n728_o : std_logic_vector (1 downto 0);
  signal n729_o : std_logic_vector (63 downto 0);
  signal n730_o : std_logic_vector (1 downto 0);
  signal n731_o : std_logic_vector (63 downto 0);
  signal n732_o : std_logic;
  signal n733_o : std_logic_vector (63 downto 0);
  signal n734_o : std_logic;
  signal n735_o : std_logic_vector (63 downto 0);
  signal n736_o : std_logic_vector (63 downto 0);
  signal n737_o : std_logic_vector (63 downto 0);
  signal n738_o : std_logic_vector (63 downto 0);
  signal n739_o : std_logic_vector (63 downto 0);
  signal n740_o : std_logic_vector (63 downto 0);
  signal n741_o : std_logic_vector (63 downto 0);
  signal n742_o : std_logic_vector (63 downto 0);
  signal n743_o : std_logic_vector (63 downto 0);
  signal n744_o : std_logic_vector (63 downto 0);
  signal n745_o : std_logic_vector (63 downto 0);
  signal n746_o : std_logic_vector (63 downto 0);
  signal n747_o : std_logic_vector (63 downto 0);
  signal n748_o : std_logic_vector (63 downto 0);
  signal n749_o : std_logic_vector (63 downto 0);
  signal n750_o : std_logic_vector (63 downto 0);
  signal n751_o : std_logic_vector (63 downto 0);
  signal n752_o : std_logic_vector (63 downto 0);
  signal n753_o : std_logic_vector (63 downto 0);
  signal n754_o : std_logic_vector (63 downto 0);
  signal n755_o : std_logic_vector (63 downto 0);
  signal n756_o : std_logic_vector (63 downto 0);
  signal n757_o : std_logic_vector (63 downto 0);
  signal n758_o : std_logic_vector (63 downto 0);
  signal n759_o : std_logic_vector (63 downto 0);
  signal n760_o : std_logic_vector (1 downto 0);
  signal n761_o : std_logic_vector (63 downto 0);
  signal n762_o : std_logic_vector (1 downto 0);
  signal n763_o : std_logic_vector (63 downto 0);
  signal n764_o : std_logic_vector (1 downto 0);
  signal n765_o : std_logic_vector (63 downto 0);
  signal n766_o : std_logic_vector (1 downto 0);
  signal n767_o : std_logic_vector (63 downto 0);
  signal n768_o : std_logic_vector (1 downto 0);
  signal n769_o : std_logic_vector (63 downto 0);
  signal n770_o : std_logic_vector (1 downto 0);
  signal n771_o : std_logic_vector (63 downto 0);
  signal n772_o : std_logic_vector (1 downto 0);
  signal n773_o : std_logic_vector (63 downto 0);
  signal n774_o : std_logic;
  signal n775_o : std_logic_vector (63 downto 0);
  signal n776_o : std_logic;
  signal n777_o : std_logic_vector (63 downto 0);
  signal n778_o : std_logic;
  signal n779_o : std_logic;
  signal n780_o : std_logic;
  signal n781_o : std_logic;
  signal n782_o : std_logic;
  signal n783_o : std_logic;
  signal n784_o : std_logic;
  signal n785_o : std_logic;
  signal n786_o : std_logic;
  signal n787_o : std_logic;
  signal n788_o : std_logic;
  signal n789_o : std_logic;
  signal n790_o : std_logic;
  signal n791_o : std_logic;
  signal n792_o : std_logic;
  signal n793_o : std_logic;
  signal n794_o : std_logic;
  signal n795_o : std_logic;
  signal n796_o : std_logic;
  signal n797_o : std_logic;
  signal n798_o : std_logic;
  signal n799_o : std_logic;
  signal n800_o : std_logic;
  signal n801_o : std_logic;
  signal n802_o : std_logic;
  signal n803_o : std_logic;
  signal n804_o : std_logic;
  signal n805_o : std_logic;
  signal n806_o : std_logic;
  signal n807_o : std_logic;
  signal n808_o : std_logic;
  signal n809_o : std_logic;
  signal n810_o : std_logic;
  signal n811_o : std_logic;
  signal n812_o : std_logic;
  signal n813_o : std_logic;
  signal n814_o : std_logic;
  signal n815_o : std_logic;
  signal n816_o : std_logic;
  signal n817_o : std_logic;
  signal n818_o : std_logic;
  signal n819_o : std_logic;
  signal n820_o : std_logic;
  signal n821_o : std_logic;
  signal n822_o : std_logic;
  signal n823_o : std_logic;
  signal n824_o : std_logic;
  signal n825_o : std_logic;
  signal n826_o : std_logic;
  signal n827_o : std_logic;
  signal n828_o : std_logic;
  signal n829_o : std_logic;
  signal n830_o : std_logic;
  signal n831_o : std_logic;
  signal n832_o : std_logic;
  signal n833_o : std_logic_vector (63 downto 0);
  signal n834_o : std_logic_vector (63 downto 0);
  signal n835_o : std_logic_vector (63 downto 0);
  signal n836_o : std_logic_vector (63 downto 0);
  signal n837_o : std_logic_vector (63 downto 0);
  signal n838_o : std_logic_vector (63 downto 0);
  signal n839_o : std_logic_vector (63 downto 0);
  signal n840_o : std_logic_vector (63 downto 0);
  signal n841_o : std_logic_vector (63 downto 0);
  signal n842_o : std_logic_vector (63 downto 0);
  signal n843_o : std_logic_vector (63 downto 0);
  signal n844_o : std_logic_vector (63 downto 0);
  signal n845_o : std_logic_vector (63 downto 0);
  signal n846_o : std_logic_vector (63 downto 0);
  signal n847_o : std_logic_vector (63 downto 0);
  signal n848_o : std_logic_vector (63 downto 0);
  signal n849_o : std_logic_vector (63 downto 0);
  signal n850_o : std_logic_vector (63 downto 0);
  signal n851_o : std_logic_vector (63 downto 0);
  signal n852_o : std_logic_vector (63 downto 0);
  signal n853_o : std_logic_vector (63 downto 0);
  signal n854_o : std_logic_vector (63 downto 0);
  signal n855_o : std_logic_vector (63 downto 0);
  signal n856_o : std_logic_vector (63 downto 0);
  signal n857_o : std_logic_vector (63 downto 0);
  signal n858_o : std_logic_vector (63 downto 0);
  signal n859_o : std_logic_vector (63 downto 0);
  signal n860_o : std_logic_vector (63 downto 0);
  signal n861_o : std_logic_vector (63 downto 0);
  signal n862_o : std_logic_vector (63 downto 0);
  signal n863_o : std_logic_vector (63 downto 0);
  signal n864_o : std_logic_vector (63 downto 0);
  signal n865_o : std_logic_vector (63 downto 0);
  signal n866_o : std_logic_vector (63 downto 0);
  signal n867_o : std_logic_vector (63 downto 0);
  signal n868_o : std_logic_vector (63 downto 0);
  signal n869_o : std_logic_vector (63 downto 0);
  signal n870_o : std_logic_vector (63 downto 0);
  signal n871_o : std_logic_vector (63 downto 0);
  signal n872_o : std_logic_vector (63 downto 0);
  signal n873_o : std_logic_vector (63 downto 0);
  signal n874_o : std_logic_vector (63 downto 0);
  signal n875_o : std_logic_vector (63 downto 0);
  signal n876_o : std_logic_vector (63 downto 0);
  signal n877_o : std_logic_vector (63 downto 0);
  signal n878_o : std_logic_vector (63 downto 0);
  signal n879_o : std_logic_vector (63 downto 0);
  signal n880_o : std_logic_vector (63 downto 0);
  signal n881_o : std_logic_vector (1535 downto 0);
  signal n882_o : std_logic_vector (63 downto 0);
  signal n883_o : std_logic_vector (63 downto 0);
  signal n884_o : std_logic_vector (63 downto 0);
  signal n885_o : std_logic_vector (63 downto 0);
  signal n886_o : std_logic_vector (63 downto 0);
  signal n887_o : std_logic_vector (63 downto 0);
  signal n888_o : std_logic_vector (63 downto 0);
  signal n889_o : std_logic_vector (63 downto 0);
  signal n890_o : std_logic_vector (63 downto 0);
  signal n891_o : std_logic_vector (63 downto 0);
  signal n892_o : std_logic_vector (63 downto 0);
  signal n893_o : std_logic_vector (63 downto 0);
  signal n894_o : std_logic_vector (63 downto 0);
  signal n895_o : std_logic_vector (63 downto 0);
  signal n896_o : std_logic_vector (63 downto 0);
  signal n897_o : std_logic_vector (63 downto 0);
  signal n898_o : std_logic_vector (63 downto 0);
  signal n899_o : std_logic_vector (63 downto 0);
  signal n900_o : std_logic_vector (63 downto 0);
  signal n901_o : std_logic_vector (63 downto 0);
  signal n902_o : std_logic_vector (63 downto 0);
  signal n903_o : std_logic_vector (63 downto 0);
  signal n904_o : std_logic_vector (63 downto 0);
  signal n905_o : std_logic_vector (63 downto 0);
  signal n906_o : std_logic_vector (1 downto 0);
  signal n907_o : std_logic_vector (63 downto 0);
  signal n908_o : std_logic_vector (1 downto 0);
  signal n909_o : std_logic_vector (63 downto 0);
  signal n910_o : std_logic_vector (1 downto 0);
  signal n911_o : std_logic_vector (63 downto 0);
  signal n912_o : std_logic_vector (1 downto 0);
  signal n913_o : std_logic_vector (63 downto 0);
  signal n914_o : std_logic_vector (1 downto 0);
  signal n915_o : std_logic_vector (63 downto 0);
  signal n916_o : std_logic_vector (1 downto 0);
  signal n917_o : std_logic_vector (63 downto 0);
  signal n918_o : std_logic_vector (1 downto 0);
  signal n919_o : std_logic_vector (63 downto 0);
  signal n920_o : std_logic;
  signal n921_o : std_logic_vector (63 downto 0);
  signal n922_o : std_logic;
  signal n923_o : std_logic_vector (63 downto 0);
  signal n924_o : std_logic_vector (63 downto 0);
  signal n925_o : std_logic_vector (63 downto 0);
  signal n926_o : std_logic_vector (63 downto 0);
  signal n927_o : std_logic_vector (63 downto 0);
  signal n928_o : std_logic_vector (63 downto 0);
  signal n929_o : std_logic_vector (63 downto 0);
  signal n930_o : std_logic_vector (63 downto 0);
  signal n931_o : std_logic_vector (63 downto 0);
  signal n932_o : std_logic_vector (63 downto 0);
  signal n933_o : std_logic_vector (63 downto 0);
  signal n934_o : std_logic_vector (63 downto 0);
  signal n935_o : std_logic_vector (63 downto 0);
  signal n936_o : std_logic_vector (63 downto 0);
  signal n937_o : std_logic_vector (63 downto 0);
  signal n938_o : std_logic_vector (63 downto 0);
  signal n939_o : std_logic_vector (63 downto 0);
  signal n940_o : std_logic_vector (63 downto 0);
  signal n941_o : std_logic_vector (63 downto 0);
  signal n942_o : std_logic_vector (63 downto 0);
  signal n943_o : std_logic_vector (63 downto 0);
  signal n944_o : std_logic_vector (63 downto 0);
  signal n945_o : std_logic_vector (63 downto 0);
  signal n946_o : std_logic_vector (63 downto 0);
  signal n947_o : std_logic_vector (63 downto 0);
  signal n948_o : std_logic_vector (1 downto 0);
  signal n949_o : std_logic_vector (63 downto 0);
  signal n950_o : std_logic_vector (1 downto 0);
  signal n951_o : std_logic_vector (63 downto 0);
  signal n952_o : std_logic_vector (1 downto 0);
  signal n953_o : std_logic_vector (63 downto 0);
  signal n954_o : std_logic_vector (1 downto 0);
  signal n955_o : std_logic_vector (63 downto 0);
  signal n956_o : std_logic_vector (1 downto 0);
  signal n957_o : std_logic_vector (63 downto 0);
  signal n958_o : std_logic_vector (1 downto 0);
  signal n959_o : std_logic_vector (63 downto 0);
  signal n960_o : std_logic_vector (1 downto 0);
  signal n961_o : std_logic_vector (63 downto 0);
  signal n962_o : std_logic;
  signal n963_o : std_logic_vector (63 downto 0);
  signal n964_o : std_logic;
  signal n965_o : std_logic_vector (63 downto 0);
  signal n966_o : std_logic;
  signal n967_o : std_logic;
  signal n968_o : std_logic;
  signal n969_o : std_logic;
  signal n970_o : std_logic;
  signal n971_o : std_logic;
  signal n972_o : std_logic;
  signal n973_o : std_logic;
  signal n974_o : std_logic;
  signal n975_o : std_logic;
  signal n976_o : std_logic;
  signal n977_o : std_logic;
  signal n978_o : std_logic;
  signal n979_o : std_logic;
  signal n980_o : std_logic;
  signal n981_o : std_logic;
  signal n982_o : std_logic;
  signal n983_o : std_logic;
  signal n984_o : std_logic;
  signal n985_o : std_logic;
  signal n986_o : std_logic;
  signal n987_o : std_logic;
  signal n988_o : std_logic;
  signal n989_o : std_logic;
  signal n990_o : std_logic;
  signal n991_o : std_logic;
  signal n992_o : std_logic;
  signal n993_o : std_logic;
  signal n994_o : std_logic;
  signal n995_o : std_logic;
  signal n996_o : std_logic;
  signal n997_o : std_logic;
  signal n998_o : std_logic;
  signal n999_o : std_logic;
  signal n1000_o : std_logic;
  signal n1001_o : std_logic;
  signal n1002_o : std_logic;
  signal n1003_o : std_logic;
  signal n1004_o : std_logic;
  signal n1005_o : std_logic;
  signal n1006_o : std_logic;
  signal n1007_o : std_logic;
  signal n1008_o : std_logic;
  signal n1009_o : std_logic;
  signal n1010_o : std_logic;
  signal n1011_o : std_logic;
  signal n1012_o : std_logic;
  signal n1013_o : std_logic;
  signal n1014_o : std_logic;
  signal n1015_o : std_logic;
  signal n1016_o : std_logic;
  signal n1017_o : std_logic;
  signal n1018_o : std_logic;
  signal n1019_o : std_logic;
  signal n1020_o : std_logic;
  signal n1021_o : std_logic_vector (63 downto 0);
  signal n1022_o : std_logic_vector (63 downto 0);
  signal n1023_o : std_logic_vector (63 downto 0);
  signal n1024_o : std_logic_vector (63 downto 0);
  signal n1025_o : std_logic_vector (63 downto 0);
  signal n1026_o : std_logic_vector (63 downto 0);
  signal n1027_o : std_logic_vector (63 downto 0);
  signal n1028_o : std_logic_vector (63 downto 0);
  signal n1029_o : std_logic_vector (63 downto 0);
  signal n1030_o : std_logic_vector (63 downto 0);
  signal n1031_o : std_logic_vector (63 downto 0);
  signal n1032_o : std_logic_vector (63 downto 0);
  signal n1033_o : std_logic_vector (63 downto 0);
  signal n1034_o : std_logic_vector (63 downto 0);
  signal n1035_o : std_logic_vector (63 downto 0);
  signal n1036_o : std_logic_vector (63 downto 0);
  signal n1037_o : std_logic_vector (63 downto 0);
  signal n1038_o : std_logic_vector (63 downto 0);
  signal n1039_o : std_logic_vector (63 downto 0);
  signal n1040_o : std_logic_vector (63 downto 0);
  signal n1041_o : std_logic_vector (63 downto 0);
  signal n1042_o : std_logic_vector (63 downto 0);
  signal n1043_o : std_logic_vector (63 downto 0);
  signal n1044_o : std_logic_vector (63 downto 0);
  signal n1045_o : std_logic_vector (63 downto 0);
  signal n1046_o : std_logic_vector (63 downto 0);
  signal n1047_o : std_logic_vector (63 downto 0);
  signal n1048_o : std_logic_vector (63 downto 0);
  signal n1049_o : std_logic_vector (63 downto 0);
  signal n1050_o : std_logic_vector (63 downto 0);
  signal n1051_o : std_logic_vector (63 downto 0);
  signal n1052_o : std_logic_vector (63 downto 0);
  signal n1053_o : std_logic_vector (63 downto 0);
  signal n1054_o : std_logic_vector (63 downto 0);
  signal n1055_o : std_logic_vector (63 downto 0);
  signal n1056_o : std_logic_vector (63 downto 0);
  signal n1057_o : std_logic_vector (63 downto 0);
  signal n1058_o : std_logic_vector (63 downto 0);
  signal n1059_o : std_logic_vector (63 downto 0);
  signal n1060_o : std_logic_vector (63 downto 0);
  signal n1061_o : std_logic_vector (63 downto 0);
  signal n1062_o : std_logic_vector (63 downto 0);
  signal n1063_o : std_logic_vector (63 downto 0);
  signal n1064_o : std_logic_vector (63 downto 0);
  signal n1065_o : std_logic_vector (63 downto 0);
  signal n1066_o : std_logic_vector (63 downto 0);
  signal n1067_o : std_logic_vector (63 downto 0);
  signal n1068_o : std_logic_vector (63 downto 0);
  signal n1069_o : std_logic_vector (1535 downto 0);
  signal n1070_o : std_logic;
  signal n1071_o : std_logic;
  signal n1072_o : std_logic;
  signal n1073_o : std_logic;
  signal n1074_o : std_logic_vector (1 downto 0);
  signal n1075_o : std_logic;
  signal n1076_o : std_logic;
  signal n1077_o : std_logic;
  signal n1078_o : std_logic;
  signal n1079_o : std_logic;
  signal n1080_o : std_logic;
  signal n1081_o : std_logic;
  signal n1082_o : std_logic;
  signal n1083_o : std_logic;
  signal n1084_o : std_logic;
  signal n1085_o : std_logic;
  signal n1086_o : std_logic;
  signal n1087_o : std_logic;
  signal n1088_o : std_logic;
  signal n1089_o : std_logic;
  signal n1090_o : std_logic;
  signal n1091_o : std_logic;
  signal n1092_o : std_logic_vector (3 downto 0);
begin
  in_ready <= n83_o;
  snapshot_ready <= n88_o;
  snapshot_counts <= shadow;
  snapshot_flags <= shadow_flags;
  snapshot_start_ps <= run_start;
  snapshot_stop_ps <= run_stop;
  snapshot_calibration_id <= calibration;
  snapshot_setting <= setting;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:31:10
  state <= n674_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:32:10
  counts <= n675_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:32:18
  shadow <= n676_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:33:10
  flags <= n677_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:33:17
  shadow_flags <= n678_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:10
  run_start <= n679_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:21
  run_stop <= n680_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:31
  bin_start <= n681_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:42
  bin_end <= n682_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:51
  last_time <= n683_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:34:62
  item_time <= n684_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:35:10
  item_kind <= n685_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:36:10
  mask <= n686_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:37:10
  repeated <= n687_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:38:10
  calibration <= n688_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:39:10
  setting <= n689_q; -- (isignal)
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:44:29
  n82_o <= '1' when state = "001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:44:19
  n83_o <= '0' when n82_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:45:35
  n87_o <= '1' when state = "101" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:45:25
  n88_o <= '0' when n87_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:17
  n100_o <= '1' when state /= "000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:33
  n102_o <= '1' when state /= "101" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:24
  n103_o <= n100_o and n102_o;
  n105_o <= flags (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n106_o <= n105_o when n111_o = '0' else '1';
  n108_o <= flags (6);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n109_o <= n108_o when n113_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n111_o <= n103_o and source_error;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:85:9
  n113_o <= n103_o and start;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:97:15
  n116_o <= '0' when source_error = '0' else '1';
  n119_o <= n117_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:29
  n120_o <= '1' when unsigned (cfg_stop_ps) <= unsigned (cfg_start_ps) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:33
  n122_o <= std_logic_vector (unsigned (cfg_stop_ps) - unsigned (cfg_start_ps));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:48
  n124_o <= std_logic_vector (unsigned (n122_o) mod unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:54
  n126_o <= '1' when n124_o /= "0000000000000000000000000000000000000000000000000000000000000000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:103:38
  n129_o <= std_logic_vector (unsigned (cfg_start_ps) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n132_o <= "001" when n126_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n133_o <= n129_o when n126_o = '0' else bin_end;
  n134_o <= n117_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:100:15
  n135_o <= n134_o when n126_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n137_o <= n132_o when n120_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n138_o <= n133_o when n120_o = '0' else bin_end;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:98:15
  n139_o <= n135_o when n120_o = '0' else '1';
  n140_o <= n117_o (7 downto 5);
  n141_o <= n117_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n142_o <= state when start = '0' else n137_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n143_o <= run_start when start = '0' else cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n144_o <= run_stop when start = '0' else cfg_stop_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n145_o <= bin_start when start = '0' else cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n146_o <= bin_end when start = '0' else n138_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n147_o <= last_time when start = '0' else cfg_start_ps;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n149_o <= mask when start = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n151_o <= repeated when start = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n152_o <= calibration when start = '0' else cfg_calibration_id;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n153_o <= setting when start = '0' else cfg_setting;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n155_o <= counts when start = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n156_o <= n140_o & n139_o & n141_o & n116_o & n119_o;
  n157_o <= flags (1 downto 0);
  n158_o <= flags (5 downto 3);
  n159_o <= flags (7);
  n160_o <= n159_o & n109_o & n158_o & n106_o & n157_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:91:13
  n161_o <= n160_o when start = '0' else n156_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:90:11
  n163_o <= '1' when state = "000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:25
  n165_o <= '1' when unsigned (in_kind) > unsigned'("100") else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:38
  n167_o <= '1' when in_calibration_id /= calibration else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:31
  n169_o <= '1' when unsigned (in_time_ps) < unsigned (last_time) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n172_o <= "010" when n169_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n173_o <= in_time_ps when n169_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n174_o <= in_time_ps when n169_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n175_o <= in_kind when n169_o = '0' else item_kind;
  n176_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:110:15
  n177_o <= n176_o when n169_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n178_o <= n172_o when n167_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n179_o <= n173_o when n167_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n180_o <= n174_o when n167_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n181_o <= n175_o when n167_o = '0' else item_kind;
  n182_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n183_o <= n177_o when n167_o = '0' else n182_o;
  n184_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:109:15
  n185_o <= n184_o when n167_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n186_o <= n178_o when n165_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n187_o <= n179_o when n165_o = '0' else last_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n188_o <= n180_o when n165_o = '0' else item_time;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n189_o <= n181_o when n165_o = '0' else item_kind;
  n190_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n191_o <= n183_o when n165_o = '0' else n190_o;
  n192_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:108:15
  n193_o <= n185_o when n165_o = '0' else n192_o;
  n194_o <= flags (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n195_o <= n194_o when n205_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n196_o <= state when in_valid = '0' else n186_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n197_o <= last_time when in_valid = '0' else n187_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n198_o <= item_time when in_valid = '0' else n188_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n199_o <= item_kind when in_valid = '0' else n189_o;
  n200_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n201_o <= n200_o when in_valid = '0' else n191_o;
  n202_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n203_o <= n202_o when in_valid = '0' else n193_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:107:13
  n205_o <= in_valid and n165_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:106:11
  n207_o <= '1' when state = "001" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:25
  n208_o <= '1' when unsigned (bin_start) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:48
  n209_o <= '1' when unsigned (item_time) >= unsigned (bin_end) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:35
  n210_o <= n208_o and n209_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:22
  n212_o <= '1' when mask = "0000" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:122:28
  n213_o <= '1' when unsigned (item_time) > unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:122:17
  n214_o <= item_time when n213_o = '0' else run_stop;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:123:38
  n215_o <= std_logic_vector (unsigned (n214_o) - unsigned (bin_start));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:123:49
  n217_o <= std_logic_vector (unsigned (n215_o) / unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  n219_o <= flags (1 downto 0);
  n220_o <= flags (5 downto 3);
  n221_o <= flags (7);
  n222_o <= n221_o & n109_o & n220_o & n106_o & n219_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:31
  n225_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:22
  n227_o <= std_logic_vector (unsigned'("1111111111111111111111111111111111111111111111111111111111111111") - unsigned (n225_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:16
  n228_o <= '1' when unsigned (n217_o) > unsigned (n227_o) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:33
  n231_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:36
  n232_o <= std_logic_vector (unsigned (n231_o) + unsigned (n217_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n233_o <= n232_o when n228_o = '0' else "1111111111111111111111111111111111111111111111111111111111111111";
  n234_o <= n222_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n235_o <= n234_o when n228_o = '0' else '1';
  n236_o <= counts (1471 downto 0);
  n237_o <= n233_o & n236_o;
  n238_o <= n222_o (7 downto 1);
  n239_o <= n238_o & n235_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:31
  n243_o <= n237_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:22
  n245_o <= std_logic_vector (unsigned'("1111111111111111111111111111111111111111111111111111111111111111") - unsigned (n243_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:16
  n246_o <= '1' when unsigned (n217_o) > unsigned (n245_o) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:33
  n249_o <= n237_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:64:36
  n250_o <= std_logic_vector (unsigned (n249_o) + unsigned (n217_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n251_o <= n250_o when n246_o = '0' else "1111111111111111111111111111111111111111111111111111111111111111";
  n252_o <= n239_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:62:7
  n253_o <= n252_o when n246_o = '0' else '1';
  n254_o <= n237_o (447 downto 0);
  n255_o <= n237_o (1535 downto 512);
  n256_o <= n255_o & n251_o & n254_o;
  n257_o <= n239_o (7 downto 1);
  n258_o <= n257_o & n253_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n259_o <= "0000000000000000000000000000000000000000000000000000000000000000" & n217_o;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n261_o <= "0000000000000000000000000000000000000000000000000000000000000000" & "0000000000000000000000000000000000000000000000000000001111101000";  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:54
  n262_o <= std_logic_vector (resize (signed (n259_o) * signed (n261_o), 128));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:37
  n263_o <= n262_o (63 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:125:36
  n264_o <= std_logic_vector (unsigned (bin_start) + unsigned (n263_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:28
  n265_o <= '1' when unsigned (n264_o) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:60
  n267_o <= std_logic_vector (unsigned (n264_o) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:127:17
  n268_o <= bin_end when n265_o = '0' else n267_o;
  n271_o <= flags (1 downto 0);
  n272_o <= flags (5 downto 3);
  n273_o <= flags (7);
  n274_o <= n273_o & n109_o & n272_o & n106_o & n271_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n277_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n279_o <= std_logic_vector (unsigned'("10111") - unsigned (n277_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n283_o <= '1' when n735_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n285_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n287_o <= std_logic_vector (unsigned'("10111") - unsigned (n285_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n289_o <= "0" & mask;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n291_o <= std_logic_vector (unsigned'("10111") - unsigned (n289_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n295_o <= std_logic_vector (unsigned (n777_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n297_o <= n881_o when n283_o = '0' else counts;
  n298_o <= n274_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n299_o <= n298_o when n283_o = '0' else '1';
  n300_o <= n274_o (7 downto 1);
  n301_o <= n300_o & n299_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n305_o <= n297_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n307_o <= '1' when n305_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n309_o <= n297_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n311_o <= std_logic_vector (unsigned (n309_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n312_o <= counts (511 downto 448);
  n313_o <= n881_o (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n314_o <= n313_o when n283_o = '0' else n312_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n315_o <= n311_o when n307_o = '0' else n314_o;
  n316_o <= n301_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n317_o <= n316_o when n307_o = '0' else '1';
  n318_o <= counts (447 downto 0);
  n319_o <= n881_o (447 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n320_o <= n319_o when n283_o = '0' else n318_o;
  n321_o <= counts (1535 downto 512);
  n322_o <= n881_o (1535 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n323_o <= n322_o when n283_o = '0' else n321_o;
  n324_o <= n323_o & n315_o & n320_o;
  n325_o <= n301_o (7 downto 1);
  n326_o <= n325_o & n317_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n330_o <= n324_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n332_o <= '1' when n330_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n334_o <= n324_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n336_o <= std_logic_vector (unsigned (n334_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n337_o <= n324_o (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n338_o <= n336_o when n332_o = '0' else n337_o;
  n339_o <= n326_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n340_o <= n339_o when n332_o = '0' else '1';
  n341_o <= n324_o (383 downto 0);
  n342_o <= n324_o (1535 downto 448);
  n343_o <= n342_o & n338_o & n341_o;
  n344_o <= n326_o (7 downto 1);
  n345_o <= n344_o & n340_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n346_o <= n324_o when repeated = '0' else n343_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n347_o <= n326_o when repeated = '0' else n345_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:24
  n348_o <= mask (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:36
  n350_o <= '1' when n348_o = "11" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:49
  n351_o <= mask (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:61
  n353_o <= '1' when n351_o = "11" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:42
  n354_o <= n350_o or n353_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n358_o <= n346_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n360_o <= '1' when n358_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n362_o <= n346_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n364_o <= std_logic_vector (unsigned (n362_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n365_o <= n343_o (63 downto 0);
  n366_o <= n324_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n367_o <= n366_o when repeated = '0' else n365_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n368_o <= n364_o when n360_o = '0' else n367_o;
  n369_o <= n345_o (0);
  n370_o <= n326_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n371_o <= n370_o when repeated = '0' else n369_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n372_o <= n371_o when n360_o = '0' else '1';
  n373_o <= n343_o (1535 downto 64);
  n374_o <= n324_o (1535 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n375_o <= n374_o when repeated = '0' else n373_o;
  n376_o <= n375_o & n368_o;
  n377_o <= n345_o (7 downto 1);
  n378_o <= n326_o (7 downto 1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:131:17
  n379_o <= n378_o when repeated = '0' else n377_o;
  n380_o <= n379_o & n372_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:17
  n381_o <= n346_o when n354_o = '0' else n376_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:132:17
  n382_o <= n347_o when n354_o = '0' else n380_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:27
  n383_o <= '1' when unsigned (bin_end) < unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:58
  n385_o <= std_logic_vector (unsigned (bin_end) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:136:17
  n386_o <= bin_end when n383_o = '0' else n385_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n387_o <= bin_end when n212_o = '0' else n264_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n388_o <= n386_o when n212_o = '0' else n268_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n389_o <= n381_o when n212_o = '0' else n256_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:118:15
  n390_o <= n382_o when n212_o = '0' else n258_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n395_o <= "011" when n210_o = '0' else state;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n396_o <= bin_start when n210_o = '0' else n387_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n397_o <= bin_end when n210_o = '0' else n388_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n399_o <= mask when n210_o = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n401_o <= repeated when n210_o = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n402_o <= counts when n210_o = '0' else n389_o;
  n403_o <= flags (1 downto 0);
  n404_o <= flags (5 downto 3);
  n405_o <= flags (7);
  n406_o <= n405_o & n109_o & n404_o & n106_o & n403_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n407_o <= n406_o when n210_o = '0' else n390_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:116:11
  n412_o <= '1' when state = "010" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:25
  n414_o <= '1' when item_kind = "100" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:142:27
  n415_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:142:15
  n418_o <= "001" when n415_o = '0' else "100";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:27
  n420_o <= '1' when unsigned (item_time) < unsigned (run_start) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:50
  n421_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:38
  n422_o <= n420_o or n421_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:31
  n425_o <= "00000000000000000000000000000" & item_kind;  --  uext
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:31
  n427_o <= std_logic_vector (unsigned'("00000000000000000000000000010010") + unsigned (n425_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:148:29
  n428_o <= n427_o (30 downto 0);  --  trunc
  n429_o <= flags (1 downto 0);
  n430_o <= flags (5 downto 3);
  n431_o <= flags (7);
  n432_o <= n431_o & n109_o & n430_o & n106_o & n429_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n435_o <= n428_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n437_o <= std_logic_vector (unsigned'("10111") - unsigned (n435_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n441_o <= '1' when n923_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n443_o <= n428_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:20
  n445_o <= std_logic_vector (unsigned'("10111") - unsigned (n443_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n447_o <= n428_o (4 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n449_o <= std_logic_vector (unsigned'("10111") - unsigned (n447_o));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n453_o <= std_logic_vector (unsigned (n965_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n455_o <= n1069_o when n441_o = '0' else counts;
  n456_o <= n432_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n457_o <= n456_o when n441_o = '0' else '1';
  n458_o <= n432_o (7 downto 1);
  n459_o <= n458_o & n457_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  n460_o <= item_kind (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n466_o <= n455_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:21
  n468_o <= '1' when n466_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n470_o <= n455_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:36
  n472_o <= std_logic_vector (unsigned (n470_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n473_o <= counts (127 downto 64);
  n474_o <= n1069_o (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n475_o <= n474_o when n441_o = '0' else n473_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n476_o <= n472_o when n468_o = '0' else n475_o;
  n477_o <= n459_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n478_o <= n477_o when n468_o = '0' else '1';
  n479_o <= counts (63 downto 0);
  n480_o <= n1069_o (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n481_o <= n480_o when n441_o = '0' else n479_o;
  n482_o <= counts (1535 downto 128);
  n483_o <= n1069_o (1535 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:7
  n484_o <= n483_o when n441_o = '0' else n482_o;
  n485_o <= n484_o & n476_o & n481_o;
  n486_o <= n459_o (7 downto 1);
  n487_o <= n486_o & n478_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n489_o <= repeated when n1075_o = '0' else '1';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n490_o <= n455_o when n1075_o = '0' else n485_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:17
  n491_o <= n459_o when n1075_o = '0' else n487_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:21
  n492_o <= item_kind (1 downto 0);  --  trunc
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n496_o <= n1092_o when n422_o = '0' else mask;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n497_o <= n489_o when n422_o = '0' else repeated;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n498_o <= n490_o when n422_o = '0' else counts;
  n499_o <= n491_o (4 downto 0);
  n500_o <= flags (1 downto 0);
  n501_o <= flags (4 downto 3);
  n502_o <= n501_o & n106_o & n500_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n503_o <= n499_o when n422_o = '0' else n502_o;
  n504_o <= n491_o (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n505_o <= n504_o when n422_o = '0' else '1';
  n506_o <= n491_o (7 downto 6);
  n507_o <= flags (7);
  n508_o <= n507_o & n109_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:146:15
  n509_o <= n506_o when n422_o = '0' else n508_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n511_o <= "001" when n414_o = '0' else n418_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n512_o <= n496_o when n414_o = '0' else mask;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n513_o <= n497_o when n414_o = '0' else repeated;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n514_o <= n498_o when n414_o = '0' else counts;
  n515_o <= n509_o & n505_o & n503_o;
  n516_o <= flags (1 downto 0);
  n517_o <= flags (5 downto 3);
  n518_o <= flags (7);
  n519_o <= n518_o & n109_o & n517_o & n106_o & n516_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:141:13
  n520_o <= n515_o when n414_o = '0' else n519_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:140:11
  n523_o <= '1' when state = "011" else '0';
  n524_o <= flags (1 downto 0);
  n525_o <= flags (5 downto 3);
  n526_o <= flags (7);
  n527_o <= n526_o & n109_o & n525_o & n106_o & n524_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:156:11
  n529_o <= '1' when state = "100" else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:158:11
  n531_o <= '1' when state = "101" else '0';
  n532_o <= n531_o & n529_o & n523_o & n412_o & n207_o & n163_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n535_o <=
    state when "100000",
    "101" when "010000",
    n511_o when "001000",
    n395_o when "000100",
    n196_o when "000010",
    n142_o when "000001",
    "XXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n537_o <=
    shadow when "100000",
    counts when "010000",
    shadow when "001000",
    shadow when "000100",
    shadow when "000010",
    shadow when "000001",
    (1535 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n539_o <=
    shadow_flags when "100000",
    n527_o when "010000",
    shadow_flags when "001000",
    shadow_flags when "000100",
    shadow_flags when "000010",
    shadow_flags when "000001",
    "XXXXXXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n541_o <=
    run_start when "100000",
    run_start when "010000",
    run_start when "001000",
    run_start when "000100",
    run_start when "000010",
    n143_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n543_o <=
    run_stop when "100000",
    run_stop when "010000",
    run_stop when "001000",
    run_stop when "000100",
    run_stop when "000010",
    n144_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n545_o <=
    bin_start when "100000",
    bin_start when "010000",
    bin_start when "001000",
    n396_o when "000100",
    bin_start when "000010",
    n145_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n547_o <=
    bin_end when "100000",
    bin_end when "010000",
    bin_end when "001000",
    n397_o when "000100",
    bin_end when "000010",
    n146_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n549_o <=
    last_time when "100000",
    last_time when "010000",
    last_time when "001000",
    last_time when "000100",
    n197_o when "000010",
    n147_o when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n551_o <=
    item_time when "100000",
    item_time when "010000",
    item_time when "001000",
    item_time when "000100",
    n198_o when "000010",
    item_time when "000001",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n553_o <=
    item_kind when "100000",
    item_kind when "010000",
    item_kind when "001000",
    item_kind when "000100",
    n199_o when "000010",
    item_kind when "000001",
    "XXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n555_o <=
    mask when "100000",
    mask when "010000",
    n512_o when "001000",
    n399_o when "000100",
    mask when "000010",
    n149_o when "000001",
    "XXXX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n557_o <=
    repeated when "100000",
    repeated when "010000",
    n513_o when "001000",
    n401_o when "000100",
    repeated when "000010",
    n151_o when "000001",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n559_o <=
    calibration when "100000",
    calibration when "010000",
    calibration when "001000",
    calibration when "000100",
    calibration when "000010",
    n152_o when "000001",
    (31 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n561_o <=
    setting when "100000",
    setting when "010000",
    setting when "001000",
    setting when "000100",
    setting when "000010",
    n153_o when "000001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n563_o <=
    counts when "100000",
    counts when "010000",
    n514_o when "001000",
    n402_o when "000100",
    counts when "000010",
    n155_o when "000001",
    (1535 downto 0 => 'X') when others;
  n564_o <= n161_o (0);
  n565_o <= n407_o (0);
  n566_o <= n520_o (0);
  n567_o <= flags (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n569_o <=
    n567_o when "100000",
    n567_o when "010000",
    n566_o when "001000",
    n565_o when "000100",
    n567_o when "000010",
    n564_o when "000001",
    'X' when others;
  n570_o <= n161_o (1);
  n571_o <= n407_o (1);
  n572_o <= n520_o (1);
  n573_o <= flags (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n575_o <=
    n573_o when "100000",
    n573_o when "010000",
    n572_o when "001000",
    n571_o when "000100",
    n201_o when "000010",
    n570_o when "000001",
    'X' when others;
  n576_o <= n161_o (2);
  n577_o <= n407_o (2);
  n578_o <= n520_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n580_o <=
    n106_o when "100000",
    n106_o when "010000",
    n578_o when "001000",
    n577_o when "000100",
    n106_o when "000010",
    n576_o when "000001",
    'X' when others;
  n581_o <= n161_o (3);
  n582_o <= n407_o (3);
  n583_o <= n520_o (3);
  n584_o <= flags (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n586_o <=
    n584_o when "100000",
    n584_o when "010000",
    n583_o when "001000",
    n582_o when "000100",
    n203_o when "000010",
    n581_o when "000001",
    'X' when others;
  n587_o <= n161_o (4);
  n588_o <= n407_o (4);
  n589_o <= n520_o (4);
  n590_o <= flags (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n592_o <=
    n590_o when "100000",
    n590_o when "010000",
    n589_o when "001000",
    n588_o when "000100",
    n590_o when "000010",
    n587_o when "000001",
    'X' when others;
  n593_o <= n161_o (5);
  n594_o <= n407_o (5);
  n595_o <= n520_o (5);
  n596_o <= flags (5);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n598_o <=
    n596_o when "100000",
    n596_o when "010000",
    n595_o when "001000",
    n594_o when "000100",
    n195_o when "000010",
    n593_o when "000001",
    'X' when others;
  n599_o <= n161_o (7 downto 6);
  n600_o <= n407_o (7 downto 6);
  n601_o <= n520_o (7 downto 6);
  n602_o <= flags (7);
  n603_o <= n602_o & n109_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  with n532_o select n605_o <=
    n603_o when "100000",
    n603_o when "010000",
    n601_o when "001000",
    n600_o when "000100",
    n603_o when "000010",
    n599_o when "000001",
    "XX" when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n615_o <= n535_o when reset = '0' else "000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n617_o <= n537_o when reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n619_o <= n539_o when reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n621_o <= n541_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n623_o <= n543_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n625_o <= n545_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n627_o <= n547_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n629_o <= n549_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n631_o <= n551_o when reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n633_o <= n553_o when reset = '0' else "000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n635_o <= n555_o when reset = '0' else "0000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n637_o <= n557_o when reset = '0' else '0';
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n639_o <= n559_o when reset = '0' else "00000000000000000000000000000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n641_o <= n561_o when reset = '0' else "00";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n643_o <= n563_o when reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n644_o <= n605_o & n598_o & n592_o & n586_o & n580_o & n575_o & n569_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n646_o <= n644_o when reset = '0' else "00000000";
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n674_q <= n615_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n675_q <= n643_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n676_q <= n617_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n677_q <= n646_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n678_q <= n619_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n679_q <= n621_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n680_q <= n623_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n681_q <= n625_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n682_q <= n627_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n683_q <= n629_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n684_q <= n631_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n685_q <= n633_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n686_q <= n635_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n687_q <= n637_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n688_q <= n639_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  process (clk)
  begin
    if rising_edge (clk) then
      n689_q <= n641_o;
    end if;
  end process;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:25:5
  n694_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:24:5
  n695_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:23:24
  n696_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:23:5
  n697_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:22:5
  n698_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:21:5
  n699_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:20:5
  n700_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:15:30
  n701_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n702_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n703_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n704_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n705_o <= counts (767 downto 704);
  n706_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n707_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:74:5
  n708_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n709_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n710_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n711_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:76:7
  n712_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n713_o <= counts (1279 downto 1216);
  n714_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n715_o <= counts (1407 downto 1344);
  n716_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:89:9
  n717_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n718_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n718_o select n719_o <=
    n694_o when "00",
    n695_o when "01",
    n696_o when "10",
    n697_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n720_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n720_o select n721_o <=
    n698_o when "00",
    n699_o when "01",
    n700_o when "10",
    n701_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n722_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n722_o select n723_o <=
    n702_o when "00",
    n703_o when "01",
    n704_o when "10",
    n705_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n724_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n724_o select n725_o <=
    n706_o when "00",
    n707_o when "01",
    n708_o when "10",
    n709_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n726_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n726_o select n727_o <=
    n710_o when "00",
    n711_o when "01",
    n712_o when "10",
    n713_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n728_o <= n279_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n728_o select n729_o <=
    n714_o when "00",
    n715_o when "01",
    n716_o when "10",
    n717_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n730_o <= n279_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n730_o select n731_o <=
    n719_o when "00",
    n721_o when "01",
    n723_o when "10",
    n725_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:117:13
  n732_o <= n279_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n733_o <= n727_o when n732_o = '0' else n729_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n734_o <= n279_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n735_o <= n731_o when n734_o = '0' else n733_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:19
  n736_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n737_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n738_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n739_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n740_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n741_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:66:15
  n742_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:129:29
  n743_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n744_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n745_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n746_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:58:15
  n747_o <= counts (767 downto 704);
  n748_o <= counts (831 downto 768);
  n749_o <= counts (895 downto 832);
  n750_o <= counts (959 downto 896);
  n751_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:53:3
  n752_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:36
  n753_o <= counts (1151 downto 1088);
  n754_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:24
  n755_o <= counts (1279 downto 1216);
  n756_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:57:14
  n757_o <= counts (1407 downto 1344);
  n758_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:56:14
  n759_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n760_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n760_o select n761_o <=
    n736_o when "00",
    n737_o when "01",
    n738_o when "10",
    n739_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n762_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n762_o select n763_o <=
    n740_o when "00",
    n741_o when "01",
    n742_o when "10",
    n743_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n764_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n764_o select n765_o <=
    n744_o when "00",
    n745_o when "01",
    n746_o when "10",
    n747_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n766_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n766_o select n767_o <=
    n748_o when "00",
    n749_o when "01",
    n750_o when "10",
    n751_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n768_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n768_o select n769_o <=
    n752_o when "00",
    n753_o when "01",
    n754_o when "10",
    n755_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n770_o <= n291_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n770_o select n771_o <=
    n756_o when "00",
    n757_o when "01",
    n758_o when "10",
    n759_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n772_o <= n291_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n772_o select n773_o <=
    n761_o when "00",
    n763_o when "01",
    n765_o when "10",
    n767_o when "11",
    (63 downto 0 => 'X') when others;
  n774_o <= n291_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n775_o <= n769_o when n774_o = '0' else n771_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n776_o <= n291_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n777_o <= n773_o when n776_o = '0' else n775_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n778_o <= n287_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n779_o <= not n778_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n780_o <= n287_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n781_o <= not n780_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n782_o <= n779_o and n781_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n783_o <= n779_o and n780_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n784_o <= n778_o and n781_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n785_o <= n287_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n786_o <= not n785_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n787_o <= n782_o and n786_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n788_o <= n782_o and n785_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n789_o <= n783_o and n786_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n790_o <= n783_o and n785_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n791_o <= n784_o and n786_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n792_o <= n784_o and n785_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n793_o <= n287_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n794_o <= not n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n795_o <= n787_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n796_o <= n787_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n797_o <= n788_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n798_o <= n788_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n799_o <= n789_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n800_o <= n789_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n801_o <= n790_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n802_o <= n790_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n803_o <= n791_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n804_o <= n791_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n805_o <= n792_o and n794_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n806_o <= n792_o and n793_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n807_o <= n287_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n808_o <= not n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n809_o <= n795_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n810_o <= n795_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n811_o <= n796_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n812_o <= n796_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n813_o <= n797_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n814_o <= n797_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n815_o <= n798_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n816_o <= n798_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n817_o <= n799_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n818_o <= n799_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n819_o <= n800_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n820_o <= n800_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n821_o <= n801_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n822_o <= n801_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n823_o <= n802_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n824_o <= n802_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n825_o <= n803_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n826_o <= n803_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n827_o <= n804_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n828_o <= n804_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n829_o <= n805_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n830_o <= n805_o and n807_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n831_o <= n806_o and n808_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n832_o <= n806_o and n807_o;
  n833_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n834_o <= n833_o when n809_o = '0' else n295_o;
  n835_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n836_o <= n835_o when n810_o = '0' else n295_o;
  n837_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n838_o <= n837_o when n811_o = '0' else n295_o;
  n839_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n840_o <= n839_o when n812_o = '0' else n295_o;
  n841_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n842_o <= n841_o when n813_o = '0' else n295_o;
  n843_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n844_o <= n843_o when n814_o = '0' else n295_o;
  n845_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n846_o <= n845_o when n815_o = '0' else n295_o;
  n847_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n848_o <= n847_o when n816_o = '0' else n295_o;
  n849_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n850_o <= n849_o when n817_o = '0' else n295_o;
  n851_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n852_o <= n851_o when n818_o = '0' else n295_o;
  n853_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n854_o <= n853_o when n819_o = '0' else n295_o;
  n855_o <= counts (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n856_o <= n855_o when n820_o = '0' else n295_o;
  n857_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n858_o <= n857_o when n821_o = '0' else n295_o;
  n859_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n860_o <= n859_o when n822_o = '0' else n295_o;
  n861_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n862_o <= n861_o when n823_o = '0' else n295_o;
  n863_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n864_o <= n863_o when n824_o = '0' else n295_o;
  n865_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n866_o <= n865_o when n825_o = '0' else n295_o;
  n867_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n868_o <= n867_o when n826_o = '0' else n295_o;
  n869_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n870_o <= n869_o when n827_o = '0' else n295_o;
  n871_o <= counts (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n872_o <= n871_o when n828_o = '0' else n295_o;
  n873_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n874_o <= n873_o when n829_o = '0' else n295_o;
  n875_o <= counts (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n876_o <= n875_o when n830_o = '0' else n295_o;
  n877_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n878_o <= n877_o when n831_o = '0' else n295_o;
  n879_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n880_o <= n879_o when n832_o = '0' else n295_o;
  n881_o <= n880_o & n878_o & n876_o & n874_o & n872_o & n870_o & n868_o & n866_o & n864_o & n862_o & n860_o & n858_o & n856_o & n854_o & n852_o & n850_o & n848_o & n846_o & n844_o & n842_o & n840_o & n838_o & n836_o & n834_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:21
  n882_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n883_o <= counts (127 downto 64);
  n884_o <= counts (191 downto 128);
  n885_o <= counts (255 downto 192);
  n886_o <= counts (319 downto 256);
  n887_o <= counts (383 downto 320);
  n888_o <= counts (447 downto 384);
  n889_o <= counts (511 downto 448);
  n890_o <= counts (575 downto 512);
  n891_o <= counts (639 downto 576);
  n892_o <= counts (703 downto 640);
  n893_o <= counts (767 downto 704);
  n894_o <= counts (831 downto 768);
  n895_o <= counts (895 downto 832);
  n896_o <= counts (959 downto 896);
  n897_o <= counts (1023 downto 960);
  n898_o <= counts (1087 downto 1024);
  n899_o <= counts (1151 downto 1088);
  n900_o <= counts (1215 downto 1152);
  n901_o <= counts (1279 downto 1216);
  n902_o <= counts (1343 downto 1280);
  n903_o <= counts (1407 downto 1344);
  n904_o <= counts (1471 downto 1408);
  n905_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n906_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n906_o select n907_o <=
    n882_o when "00",
    n883_o when "01",
    n884_o when "10",
    n885_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n908_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n908_o select n909_o <=
    n886_o when "00",
    n887_o when "01",
    n888_o when "10",
    n889_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n910_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n910_o select n911_o <=
    n890_o when "00",
    n891_o when "01",
    n892_o when "10",
    n893_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n912_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n912_o select n913_o <=
    n894_o when "00",
    n895_o when "01",
    n896_o when "10",
    n897_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n914_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n914_o select n915_o <=
    n898_o when "00",
    n899_o when "01",
    n900_o when "10",
    n901_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n916_o <= n437_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n916_o select n917_o <=
    n902_o when "00",
    n903_o when "01",
    n904_o when "10",
    n905_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n918_o <= n437_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  with n918_o select n919_o <=
    n907_o when "00",
    n909_o when "01",
    n911_o when "10",
    n913_o when "11",
    (63 downto 0 => 'X') when others;
  n920_o <= n437_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n921_o <= n915_o when n920_o = '0' else n917_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n922_o <= n437_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n923_o <= n919_o when n922_o = '0' else n921_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:19
  n924_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:70:18
  n925_o <= counts (127 downto 64);
  n926_o <= counts (191 downto 128);
  n927_o <= counts (255 downto 192);
  n928_o <= counts (319 downto 256);
  n929_o <= counts (383 downto 320);
  n930_o <= counts (447 downto 384);
  n931_o <= counts (511 downto 448);
  n932_o <= counts (575 downto 512);
  n933_o <= counts (639 downto 576);
  n934_o <= counts (703 downto 640);
  n935_o <= counts (767 downto 704);
  n936_o <= counts (831 downto 768);
  n937_o <= counts (895 downto 832);
  n938_o <= counts (959 downto 896);
  n939_o <= counts (1023 downto 960);
  n940_o <= counts (1087 downto 1024);
  n941_o <= counts (1151 downto 1088);
  n942_o <= counts (1215 downto 1152);
  n943_o <= counts (1279 downto 1216);
  n944_o <= counts (1343 downto 1280);
  n945_o <= counts (1407 downto 1344);
  n946_o <= counts (1471 downto 1408);
  n947_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n948_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n948_o select n949_o <=
    n924_o when "00",
    n925_o when "01",
    n926_o when "10",
    n927_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n950_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n950_o select n951_o <=
    n928_o when "00",
    n929_o when "01",
    n930_o when "10",
    n931_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n952_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n952_o select n953_o <=
    n932_o when "00",
    n933_o when "01",
    n934_o when "10",
    n935_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n954_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n954_o select n955_o <=
    n936_o when "00",
    n937_o when "01",
    n938_o when "10",
    n939_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n956_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n956_o select n957_o <=
    n940_o when "00",
    n941_o when "01",
    n942_o when "10",
    n943_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n958_o <= n449_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n958_o select n959_o <=
    n944_o when "00",
    n945_o when "01",
    n946_o when "10",
    n947_o when "11",
    (63 downto 0 => 'X') when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n960_o <= n449_o (3 downto 2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  with n960_o select n961_o <=
    n949_o when "00",
    n951_o when "01",
    n953_o when "10",
    n955_o when "11",
    (63 downto 0 => 'X') when others;
  n962_o <= n449_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n963_o <= n957_o when n962_o = '0' else n959_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n964_o <= n449_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:33
  n965_o <= n961_o when n964_o = '0' else n963_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n966_o <= n445_o (4);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n967_o <= not n966_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n968_o <= n445_o (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n969_o <= not n968_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n970_o <= n967_o and n969_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n971_o <= n967_o and n968_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n972_o <= n966_o and n969_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n973_o <= n445_o (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n974_o <= not n973_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n975_o <= n970_o and n974_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n976_o <= n970_o and n973_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n977_o <= n971_o and n974_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n978_o <= n971_o and n973_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n979_o <= n972_o and n974_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n980_o <= n972_o and n973_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n981_o <= n445_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n982_o <= not n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n983_o <= n975_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n984_o <= n975_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n985_o <= n976_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n986_o <= n976_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n987_o <= n977_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n988_o <= n977_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n989_o <= n978_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n990_o <= n978_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n991_o <= n979_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n992_o <= n979_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n993_o <= n980_o and n982_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n994_o <= n980_o and n981_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n995_o <= n445_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n996_o <= not n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n997_o <= n983_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n998_o <= n983_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n999_o <= n984_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1000_o <= n984_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1001_o <= n985_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1002_o <= n985_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1003_o <= n986_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1004_o <= n986_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1005_o <= n987_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1006_o <= n987_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1007_o <= n988_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1008_o <= n988_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1009_o <= n989_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1010_o <= n989_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1011_o <= n990_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1012_o <= n990_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1013_o <= n991_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1014_o <= n991_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1015_o <= n992_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1016_o <= n992_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1017_o <= n993_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1018_o <= n993_o and n995_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1019_o <= n994_o and n996_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1020_o <= n994_o and n995_o;
  n1021_o <= counts (63 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1022_o <= n1021_o when n997_o = '0' else n453_o;
  n1023_o <= counts (127 downto 64);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1024_o <= n1023_o when n998_o = '0' else n453_o;
  n1025_o <= counts (191 downto 128);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1026_o <= n1025_o when n999_o = '0' else n453_o;
  n1027_o <= counts (255 downto 192);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1028_o <= n1027_o when n1000_o = '0' else n453_o;
  n1029_o <= counts (319 downto 256);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1030_o <= n1029_o when n1001_o = '0' else n453_o;
  n1031_o <= counts (383 downto 320);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1032_o <= n1031_o when n1002_o = '0' else n453_o;
  n1033_o <= counts (447 downto 384);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1034_o <= n1033_o when n1003_o = '0' else n453_o;
  n1035_o <= counts (511 downto 448);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1036_o <= n1035_o when n1004_o = '0' else n453_o;
  n1037_o <= counts (575 downto 512);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1038_o <= n1037_o when n1005_o = '0' else n453_o;
  n1039_o <= counts (639 downto 576);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1040_o <= n1039_o when n1006_o = '0' else n453_o;
  n1041_o <= counts (703 downto 640);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1042_o <= n1041_o when n1007_o = '0' else n453_o;
  n1043_o <= counts (767 downto 704);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1044_o <= n1043_o when n1008_o = '0' else n453_o;
  n1045_o <= counts (831 downto 768);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1046_o <= n1045_o when n1009_o = '0' else n453_o;
  n1047_o <= counts (895 downto 832);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1048_o <= n1047_o when n1010_o = '0' else n453_o;
  n1049_o <= counts (959 downto 896);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1050_o <= n1049_o when n1011_o = '0' else n453_o;
  n1051_o <= counts (1023 downto 960);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1052_o <= n1051_o when n1012_o = '0' else n453_o;
  n1053_o <= counts (1087 downto 1024);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1054_o <= n1053_o when n1013_o = '0' else n453_o;
  n1055_o <= counts (1151 downto 1088);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1056_o <= n1055_o when n1014_o = '0' else n453_o;
  n1057_o <= counts (1215 downto 1152);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1058_o <= n1057_o when n1015_o = '0' else n453_o;
  n1059_o <= counts (1279 downto 1216);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1060_o <= n1059_o when n1016_o = '0' else n453_o;
  n1061_o <= counts (1343 downto 1280);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1062_o <= n1061_o when n1017_o = '0' else n453_o;
  n1063_o <= counts (1407 downto 1344);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1064_o <= n1063_o when n1018_o = '0' else n453_o;
  n1065_o <= counts (1471 downto 1408);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1066_o <= n1065_o when n1019_o = '0' else n453_o;
  n1067_o <= counts (1535 downto 1472);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1068_o <= n1067_o when n1020_o = '0' else n453_o;
  n1069_o <= n1068_o & n1066_o & n1064_o & n1062_o & n1060_o & n1058_o & n1056_o & n1054_o & n1052_o & n1050_o & n1048_o & n1046_o & n1044_o & n1042_o & n1040_o & n1038_o & n1036_o & n1034_o & n1032_o & n1030_o & n1028_o & n1026_o & n1024_o & n1022_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:21
  n1070_o <= mask (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:71:12
  n1071_o <= mask (1);
  n1072_o <= mask (2);
  n1073_o <= mask (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  n1074_o <= n460_o (1 downto 0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:149:24
  with n1074_o select n1075_o <=
    n1070_o when "00",
    n1071_o when "01",
    n1072_o when "10",
    n1073_o when "11",
    'X' when others;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1076_o <= n492_o (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1077_o <= not n1076_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1078_o <= n492_o (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1079_o <= not n1078_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1080_o <= n1077_o and n1079_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1081_o <= n1077_o and n1078_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1082_o <= n1076_o and n1079_o;
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1083_o <= n1076_o and n1078_o;
  n1084_o <= mask (0);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1085_o <= n1084_o when n1080_o = '0' else '1';
  n1086_o <= mask (1);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1087_o <= n1086_o when n1081_o = '0' else '1';
  n1088_o <= mask (2);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1089_o <= n1088_o when n1082_o = '0' else '1';
  n1090_o <= mask (3);
  -- /workspace/scratch/2d720f476673/Sagnac_v0_7/rtl/sagnac_core.vhd:152:17
  n1091_o <= n1090_o when n1083_o = '0' else '1';
  n1092_o <= n1091_o & n1089_o & n1087_o & n1085_o;
end rtl;


library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture rtl of sagnac_uart_top is
  signal wrap_clk: std_logic;
  signal wrap_reset: std_logic;
  signal wrap_start: std_logic;
  subtype typwrap_cfg_start_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_start_ps: typwrap_cfg_start_ps;
  subtype typwrap_cfg_stop_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_stop_ps: typwrap_cfg_stop_ps;
  subtype typwrap_cfg_sequence is std_logic_vector (63 downto 0);
  signal wrap_cfg_sequence: typwrap_cfg_sequence;
  subtype typwrap_cfg_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_cfg_calibration_id: typwrap_cfg_calibration_id;
  subtype typwrap_cfg_setting is std_logic_vector (1 downto 0);
  signal wrap_cfg_setting: typwrap_cfg_setting;
  signal wrap_in_valid: std_logic;
  subtype typwrap_in_kind is std_logic_vector (2 downto 0);
  signal wrap_in_kind: typwrap_in_kind;
  subtype typwrap_in_time_ps is std_logic_vector (63 downto 0);
  signal wrap_in_time_ps: typwrap_in_time_ps;
  subtype typwrap_in_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_in_calibration_id: typwrap_in_calibration_id;
  signal wrap_source_error: std_logic;
  signal wrap_in_ready: std_logic;
  signal wrap_tx: std_logic;
  signal wrap_run_complete: std_logic;
  signal wrap_transmit_complete: std_logic;
  signal counters : std_logic_vector (1535 downto 0);
  signal flags : std_logic_vector (7 downto 0);
  signal b : std_logic_vector (7 downto 0);
  signal setting : std_logic_vector (1 downto 0);
  signal cal : std_logic_vector (31 downto 0);
  signal first : std_logic_vector (63 downto 0);
  signal last : std_logic_vector (63 downto 0);
  signal seq : std_logic_vector (63 downto 0);
  signal snap_ready : std_logic;
  signal request : std_logic;
  signal accept : std_logic;
  signal valid : std_logic;
  signal ready : std_logic;
  signal sent : std_logic;
  signal started : std_logic;
  signal core_in_ready : std_logic;
  signal core_snapshot_ready : std_logic;
  signal core_snapshot_counts : std_logic_vector (1535 downto 0);
  signal core_snapshot_flags : std_logic_vector (7 downto 0);
  signal core_snapshot_start_ps : std_logic_vector (63 downto 0);
  signal core_snapshot_stop_ps : std_logic_vector (63 downto 0);
  signal core_snapshot_calibration_id : std_logic_vector (31 downto 0);
  signal core_snapshot_setting : std_logic_vector (1 downto 0);
  signal n22_o : std_logic;
  signal n23_o : std_logic;
  signal framer_send_ready : std_logic;
  signal framer_byte_valid : std_logic;
  signal framer_byte_data : std_logic_vector (7 downto 0);
  constant n25_o : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000001111101000";
  signal serial_byte_ready : std_logic;
  signal serial_tx : std_logic;
  signal n30_o : std_logic;
  signal n31_o : std_logic;
  signal n35_o : std_logic;
  signal n36_o : std_logic;
  signal n37_o : std_logic_vector (63 downto 0);
  signal n39_o : std_logic;
  signal n40_o : std_logic;
  signal n42_o : std_logic;
  signal n44_o : std_logic_vector (63 downto 0);
  signal n46_o : std_logic;
  signal n48_o : std_logic;
  signal n53_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n54_q : std_logic := '0';
  signal n55_q : std_logic := '0';
begin
  wrap_clk <= clk;
  wrap_reset <= reset;
  wrap_start <= start;
  wrap_cfg_start_ps <= typwrap_cfg_start_ps(cfg_start_ps);
  wrap_cfg_stop_ps <= typwrap_cfg_stop_ps(cfg_stop_ps);
  wrap_cfg_sequence <= typwrap_cfg_sequence(cfg_sequence);
  wrap_cfg_calibration_id <= typwrap_cfg_calibration_id(cfg_calibration_id);
  wrap_cfg_setting <= typwrap_cfg_setting(cfg_setting);
  wrap_in_valid <= in_valid;
  wrap_in_kind <= typwrap_in_kind(in_kind);
  wrap_in_time_ps <= typwrap_in_time_ps(in_time_ps);
  wrap_in_calibration_id <= typwrap_in_calibration_id(in_calibration_id);
  wrap_source_error <= source_error;
  in_ready <= wrap_in_ready;
  tx <= wrap_tx;
  run_complete <= wrap_run_complete;
  transmit_complete <= wrap_transmit_complete;
  wrap_in_ready <= core_in_ready;
  wrap_tx <= serial_tx;
  wrap_run_complete <= snap_ready;
  wrap_transmit_complete <= n31_o;
  -- rtl/sagnac_uart_top.vhd:20:10
  counters <= core_snapshot_counts; -- (signal)
  -- rtl/sagnac_uart_top.vhd:21:10
  flags <= core_snapshot_flags; -- (signal)
  -- rtl/sagnac_uart_top.vhd:21:16
  b <= framer_byte_data; -- (signal)
  -- rtl/sagnac_uart_top.vhd:22:10
  setting <= core_snapshot_setting; -- (signal)
  -- rtl/sagnac_uart_top.vhd:23:10
  cal <= core_snapshot_calibration_id; -- (signal)
  -- rtl/sagnac_uart_top.vhd:24:10
  first <= core_snapshot_start_ps; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:24:16
  last <= core_snapshot_stop_ps; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:24:21
  seq <= n53_q; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:10
  snap_ready <= core_snapshot_ready; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:21
  request <= n23_o; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:29
  accept <= framer_send_ready; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:36
  valid <= framer_byte_valid; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:42
  ready <= serial_byte_ready; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:48
  sent <= n54_q; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:25:53
  started <= n55_q; -- (isignal)
  -- rtl/sagnac_uart_top.vhd:27:3
  core : entity work.sagnac_core_1000_64 port map (
    clk => wrap_clk,
    reset => wrap_reset,
    start => wrap_start,
    cfg_start_ps => wrap_cfg_start_ps,
    cfg_stop_ps => wrap_cfg_stop_ps,
    cfg_calibration_id => wrap_cfg_calibration_id,
    cfg_setting => wrap_cfg_setting,
    in_valid => wrap_in_valid,
    in_kind => wrap_in_kind,
    in_time_ps => wrap_in_time_ps,
    in_calibration_id => wrap_in_calibration_id,
    source_error => wrap_source_error,
    in_ready => core_in_ready,
    snapshot_ready => core_snapshot_ready,
    snapshot_counts => core_snapshot_counts,
    snapshot_flags => core_snapshot_flags,
    snapshot_start_ps => core_snapshot_start_ps,
    snapshot_stop_ps => core_snapshot_stop_ps,
    snapshot_calibration_id => core_snapshot_calibration_id,
    snapshot_setting => core_snapshot_setting);
  -- rtl/sagnac_uart_top.vhd:35:27
  n22_o <= not sent;
  -- rtl/sagnac_uart_top.vhd:35:23
  n23_o <= snap_ready and n22_o;
  -- rtl/sagnac_uart_top.vhd:36:3
  framer : entity work.snapshot_framer port map (
    clk => wrap_clk,
    reset => wrap_reset,
    send_valid => request,
    counts_in => counters,
    flags_in => flags,
    setting_in => setting,
    calibration_in => cal,
    start_in => first,
    stop_in => last,
    width_in => n25_o,
    sequence_in => seq,
    byte_ready => ready,
    send_ready => framer_send_ready,
    byte_valid => framer_byte_valid,
    byte_data => framer_byte_data);
  -- rtl/sagnac_uart_top.vhd:41:3
  serial : entity work.uart_tx_50 port map (
    clk => wrap_clk,
    reset => wrap_reset,
    byte_valid => valid,
    byte_data => b,
    byte_ready => serial_byte_ready,
    tx => serial_tx);
  -- rtl/sagnac_uart_top.vhd:45:27
  n30_o <= sent and accept;
  -- rtl/sagnac_uart_top.vhd:45:38
  n31_o <= n30_o and ready;
  -- rtl/sagnac_uart_top.vhd:51:33
  n35_o <= not started;
  -- rtl/sagnac_uart_top.vhd:51:22
  n36_o <= wrap_start and n35_o;
  -- rtl/sagnac_uart_top.vhd:51:9
  n37_o <= seq when n36_o = '0' else wrap_cfg_sequence;
  -- rtl/sagnac_uart_top.vhd:51:9
  n39_o <= started when n36_o = '0' else '1';
  -- rtl/sagnac_uart_top.vhd:52:24
  n40_o <= request and accept;
  -- rtl/sagnac_uart_top.vhd:52:9
  n42_o <= sent when n40_o = '0' else '1';
  -- rtl/sagnac_uart_top.vhd:49:7
  n44_o <= n37_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_uart_top.vhd:49:7
  n46_o <= n42_o when wrap_reset = '0' else '0';
  -- rtl/sagnac_uart_top.vhd:49:7
  n48_o <= n39_o when wrap_reset = '0' else '0';
  -- rtl/sagnac_uart_top.vhd:48:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n53_q <= n44_o;
    end if;
  end process;
  -- rtl/sagnac_uart_top.vhd:48:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n54_q <= n46_o;
    end if;
  end process;
  -- rtl/sagnac_uart_top.vhd:48:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n55_q <= n48_o;
    end if;
  end process;
end rtl;
