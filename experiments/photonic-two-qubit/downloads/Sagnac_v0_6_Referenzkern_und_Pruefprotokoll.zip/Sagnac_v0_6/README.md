# Sagnac-Messkette v0.6 – ausführbare Forschungsreferenz

Stand: 11. Oktober 2026. Status: digital simuliert und generisch synthetisiert;
keine FPGA-Board-Abnahme, keine physische Quantenquelle oder Klebung qualifiziert.

Dieses Paket setzt den Übergang von der bisherigen H/A/B-Herald-Messkette zu
vier Polarisationsdetektoren ausdrücklich als **neuen Betriebsmodus** um.
Es ersetzt die H/A/B-Referenz v0.1 nicht. Deren Quellcode wurde zur Abgrenzung
geprüft; der neue Kern und seine Tests sind eigenständige Dateien.

## Ergebnis dieses Arbeitsstands

- 24 RTL-Szenarien mit GHDL ausgeführt, darunter ein erwarteter Timeout ohne
  End-Watermark; bei allen abschliessenden Fällen alle 24 Zähler und Fehlerflags
  mit einem unabhängigen Batch-Modell verglichen.
- Acht Python-Testmethoden mit zusätzlichen Unterfällen bestanden.
- Vollständige Kette: synthetische Zeitstempel → VHDL → eingefrorene Zähler →
  JSON → Python-Auswertung. Ein fehlerhafter RTL-Snapshot wird vom CLI verworfen.
- GHDL-Synthese des Standardkerns erfolgreich; keine FPGA-spezifische Flächen-,
  Takt-, Pin-, Leistungs- oder Timing-Aussage.
- Synthetisches Singulett-Beispiel mit unabhängigem Detektorverlust:
  S_cond = −2.8253650438389006; S_all = −1.4125. Die bedingte Auswertung erfüllt
  das definierte Modellkriterium; die Auswertung aller Zeitfenster erfüllt es nicht.
  **Diese Zahlen sind ausschließlich Software-Prüfdaten.**

## Ausführen

Benötigt: Python 3.10 oder neuer (nur Standardbibliothek) und GHDL mit VHDL-2008.
GHDL ist eine externe freie Software; Simulator-Binaries sind nicht enthalten.
Getestete Version: `validation/ghdl_version.txt`.

```bash
python3 sim/run_tests.py --ghdl ghdl
python3 -m unittest discover -s host -p 'test_*.py' -v
python3 host/analyze.py examples/synthetic_chsh_snapshots.json --output analysis.json
```

Alternativ verweist die Umgebungsvariable `GHDL` auf das Simulatorprogramm.
Tests erzeugen `build/` und aktualisieren die synthetischen Beispiele und Logs.
Die mitgelieferten Validierungsdateien dokumentieren den ausgeführten Lauf.
Ein erfolgreicher CLI-Exitcode 0 bedeutet valide Datenstruktur und berechnete
Diagnostik, **keine physische Freigabe**. Fehlerhafte Daten erzeugen Exitcode 2.

## Was der neue Kern zählt

Vier Eingänge A+, A−, B+, B− erhalten gemeinsame, vorab festgelegte Zeitfenster.
Der Kern speichert alle 16 Anwesenheitsmuster, einschließlich Leerklickfenstern
und beidseitigen Porttreffern. Neun eindeutige lokale Ausgangskombinationen
werden erst in Python abgeleitet. Wiederholte Klicks desselben Kanals bleiben
separate Diagnostik; sie heißen nicht automatisch Afterpulsing.

Die Standard-Fensterbreite von 1000 ps ist ein **synthetischer Testparameter**.
Sie ist weder aus einer realen Detektorkalibrierung abgeleitet noch als Bauwert
freigegeben. Auch das 1-ps-Zahlenformat ist keine Behauptung einer 1-ps-Auflösung.

## Dokumente

- `docs/INTERFACE.md`: Zeitbasis, Fenster, Handshake, Zähler, Fehlerflags und Migration.
- `docs/METROLOGY.md`: Rohdaten, CHSH-Konvention, Auswahlannahmen, Statistik.
- `docs/MIRROR_TEST.md`: durchführbarer Strahlstabilitätstest mit Referenzmessung.
- `docs/NEXT_GATE.md`: noch benötigte Hardwaredaten und nächste Freigaben.
- `docs/SOURCES.md`: Primärquellen und Bezug zum früheren v0.1-Stand.
- `validation/test_summary.json`: tatsächlich ausgeführte Szenarien.
- `examples/mirror_run_template.json`: unausgefüllte Vorlage, keine Messdaten.

## Grenzen

Nicht enthalten sind TDC, Detektorpulserfassung, Analogelektronik, Merge-FIFO,
hardwareseitige Zeitsynchronisation, CDC, USB/SPI-Protokoll, Motorsteuerung,
physisch kalibrierte Messwinkel oder ein vollständiger Quantencomputer.
Ein endlicher Testlauf ist kein Formalbeweis. Der HDL-Kern kann verschwiegene
Verluste vor seiner Schnittstelle nicht erkennen. Das Prüfkörperprotokoll wurde
ausgearbeitet, aber hier nicht mit realer Hardware durchgeführt.

Lizenz für den neu erstellten Code: MIT, siehe `LICENSE`.
