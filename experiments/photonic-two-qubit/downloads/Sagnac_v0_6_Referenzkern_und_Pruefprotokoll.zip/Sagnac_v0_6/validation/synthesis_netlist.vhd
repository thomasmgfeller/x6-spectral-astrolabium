library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.sagnac_pkg.all;
entity sagnac_core is
  generic (
    WINDOW_PS: positive := 1000;
    COUNTER_BITS: positive := 64
  );
  port (
    clk, reset, start: in std_logic;
    cfg_start_ps, cfg_stop_ps: in u64;
    cfg_calibration_id: in std_logic_vector (31 downto 0);
    cfg_setting: in unsigned (1 downto 0);
    in_valid: in std_logic;
    in_ready: out std_logic;
    in_kind: in unsigned (2 downto 0);
    in_time_ps: in u64;
    in_calibration_id: in std_logic_vector (31 downto 0);
    source_error: in std_logic;
    snapshot_ready: out std_logic;
    snapshot_counts: out counter_array;
    snapshot_flags: out std_logic_vector (7 downto 0);
    snapshot_start_ps, snapshot_stop_ps: out u64;
    snapshot_calibration_id: out std_logic_vector (31 downto 0);
    snapshot_setting: out unsigned (1 downto 0)
  );
end entity;

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

architecture rtl of sagnac_core is
  signal wrap_clk: std_logic;
  signal wrap_reset: std_logic;
  signal wrap_start: std_logic;
  subtype typwrap_cfg_start_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_start_ps: typwrap_cfg_start_ps;
  subtype typwrap_cfg_stop_ps is std_logic_vector (63 downto 0);
  signal wrap_cfg_stop_ps: typwrap_cfg_stop_ps;
  subtype typwrap_cfg_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_cfg_calibration_id: typwrap_cfg_calibration_id;
  subtype typwrap_cfg_setting is std_logic_vector (1 downto 0);
  signal wrap_cfg_setting: typwrap_cfg_setting;
  signal wrap_in_valid: std_logic;
  subtype typwrap_in_kind is std_logic_vector (2 downto 0);
  signal wrap_in_kind: typwrap_in_kind;
  subtype typwrap_in_time_ps is std_logic_vector (63 downto 0);
  signal wrap_in_time_ps: typwrap_in_time_ps;
  subtype typwrap_in_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_in_calibration_id: typwrap_in_calibration_id;
  signal wrap_source_error: std_logic;
  signal wrap_in_ready: std_logic;
  signal wrap_snapshot_ready: std_logic;
  subtype typwrap_snapshot_counts is std_logic_vector (1535 downto 0);
  signal wrap_snapshot_counts: typwrap_snapshot_counts;
  subtype typwrap_snapshot_flags is std_logic_vector (7 downto 0);
  signal wrap_snapshot_flags: typwrap_snapshot_flags;
  subtype typwrap_snapshot_start_ps is std_logic_vector (63 downto 0);
  signal wrap_snapshot_start_ps: typwrap_snapshot_start_ps;
  subtype typwrap_snapshot_stop_ps is std_logic_vector (63 downto 0);
  signal wrap_snapshot_stop_ps: typwrap_snapshot_stop_ps;
  subtype typwrap_snapshot_calibration_id is std_logic_vector (31 downto 0);
  signal wrap_snapshot_calibration_id: typwrap_snapshot_calibration_id;
  subtype typwrap_snapshot_setting is std_logic_vector (1 downto 0);
  signal wrap_snapshot_setting: typwrap_snapshot_setting;
  signal state : std_logic_vector (2 downto 0);
  signal counts : std_logic_vector (1535 downto 0);
  signal shadow : std_logic_vector (1535 downto 0);
  signal flags : std_logic_vector (7 downto 0);
  signal shadow_flags : std_logic_vector (7 downto 0);
  signal run_start : std_logic_vector (63 downto 0);
  signal run_stop : std_logic_vector (63 downto 0);
  signal bin_start : std_logic_vector (63 downto 0);
  signal bin_end : std_logic_vector (63 downto 0);
  signal last_time : std_logic_vector (63 downto 0);
  signal item_time : std_logic_vector (63 downto 0);
  signal item_kind : std_logic_vector (2 downto 0);
  signal mask : std_logic_vector (3 downto 0);
  signal repeated : std_logic;
  signal calibration : std_logic_vector (31 downto 0);
  signal setting : std_logic_vector (1 downto 0);
  signal n26_o : std_logic;
  signal n27_o : std_logic;
  signal n31_o : std_logic;
  signal n32_o : std_logic;
  signal n41_o : std_logic;
  signal n43_o : std_logic;
  signal n44_o : std_logic;
  signal n46_o : std_logic;
  signal n47_o : std_logic;
  signal n49_o : std_logic;
  signal n50_o : std_logic;
  signal n52_o : std_logic;
  signal n54_o : std_logic;
  signal n57_o : std_logic;
  constant n58_o : std_logic_vector (7 downto 0) := "00000000";
  signal n60_o : std_logic_vector (1 downto 0);
  signal n61_o : std_logic;
  signal n63_o : std_logic_vector (63 downto 0);
  signal n65_o : std_logic_vector (63 downto 0);
  signal n67_o : std_logic;
  signal n70_o : std_logic_vector (63 downto 0);
  signal n73_o : std_logic_vector (2 downto 0);
  signal n74_o : std_logic_vector (63 downto 0);
  signal n75_o : std_logic;
  signal n76_o : std_logic;
  signal n78_o : std_logic_vector (2 downto 0);
  signal n79_o : std_logic_vector (63 downto 0);
  signal n80_o : std_logic;
  signal n81_o : std_logic_vector (2 downto 0);
  signal n82_o : std_logic;
  signal n83_o : std_logic_vector (2 downto 0);
  signal n84_o : std_logic_vector (63 downto 0);
  signal n85_o : std_logic_vector (63 downto 0);
  signal n86_o : std_logic_vector (63 downto 0);
  signal n87_o : std_logic_vector (63 downto 0);
  signal n88_o : std_logic_vector (63 downto 0);
  signal n90_o : std_logic_vector (3 downto 0);
  signal n92_o : std_logic;
  signal n93_o : std_logic_vector (31 downto 0);
  signal n94_o : std_logic_vector (1 downto 0);
  signal n96_o : std_logic_vector (1535 downto 0);
  signal n97_o : std_logic_vector (7 downto 0);
  signal n98_o : std_logic_vector (1 downto 0);
  signal n99_o : std_logic_vector (2 downto 0);
  signal n100_o : std_logic;
  signal n101_o : std_logic_vector (7 downto 0);
  signal n102_o : std_logic_vector (7 downto 0);
  signal n104_o : std_logic;
  signal n106_o : std_logic;
  signal n108_o : std_logic;
  signal n110_o : std_logic;
  signal n113_o : std_logic_vector (2 downto 0);
  signal n114_o : std_logic_vector (63 downto 0);
  signal n115_o : std_logic_vector (63 downto 0);
  signal n116_o : std_logic_vector (2 downto 0);
  signal n117_o : std_logic;
  signal n118_o : std_logic;
  signal n119_o : std_logic_vector (2 downto 0);
  signal n120_o : std_logic_vector (63 downto 0);
  signal n121_o : std_logic_vector (63 downto 0);
  signal n122_o : std_logic_vector (2 downto 0);
  signal n123_o : std_logic;
  signal n124_o : std_logic;
  signal n125_o : std_logic;
  signal n126_o : std_logic;
  signal n127_o : std_logic_vector (2 downto 0);
  signal n128_o : std_logic_vector (63 downto 0);
  signal n129_o : std_logic_vector (63 downto 0);
  signal n130_o : std_logic_vector (2 downto 0);
  signal n131_o : std_logic;
  signal n132_o : std_logic;
  signal n133_o : std_logic;
  signal n134_o : std_logic;
  signal n135_o : std_logic;
  signal n136_o : std_logic;
  signal n137_o : std_logic_vector (2 downto 0);
  signal n138_o : std_logic_vector (63 downto 0);
  signal n139_o : std_logic_vector (63 downto 0);
  signal n140_o : std_logic_vector (2 downto 0);
  signal n141_o : std_logic;
  signal n142_o : std_logic;
  signal n143_o : std_logic;
  signal n144_o : std_logic;
  signal n146_o : std_logic;
  signal n148_o : std_logic;
  signal n149_o : std_logic;
  signal n150_o : std_logic;
  signal n151_o : std_logic;
  signal n154_o : std_logic_vector (1 downto 0);
  signal n155_o : std_logic_vector (2 downto 0);
  signal n156_o : std_logic;
  signal n157_o : std_logic_vector (7 downto 0);
  signal n160_o : std_logic_vector (4 downto 0);
  signal n162_o : std_logic_vector (4 downto 0);
  signal n166_o : std_logic;
  signal n168_o : std_logic_vector (4 downto 0);
  signal n170_o : std_logic_vector (4 downto 0);
  signal n172_o : std_logic_vector (4 downto 0);
  signal n174_o : std_logic_vector (4 downto 0);
  signal n178_o : std_logic_vector (63 downto 0);
  signal n180_o : std_logic_vector (1535 downto 0);
  signal n181_o : std_logic;
  signal n182_o : std_logic;
  signal n183_o : std_logic_vector (6 downto 0);
  signal n184_o : std_logic_vector (7 downto 0);
  signal n188_o : std_logic_vector (63 downto 0);
  signal n190_o : std_logic;
  signal n192_o : std_logic_vector (63 downto 0);
  signal n194_o : std_logic_vector (63 downto 0);
  signal n195_o : std_logic_vector (63 downto 0);
  signal n196_o : std_logic_vector (63 downto 0);
  signal n197_o : std_logic_vector (63 downto 0);
  signal n198_o : std_logic_vector (63 downto 0);
  signal n199_o : std_logic;
  signal n200_o : std_logic;
  signal n201_o : std_logic_vector (447 downto 0);
  signal n202_o : std_logic_vector (447 downto 0);
  signal n203_o : std_logic_vector (447 downto 0);
  signal n204_o : std_logic_vector (1023 downto 0);
  signal n205_o : std_logic_vector (1023 downto 0);
  signal n206_o : std_logic_vector (1023 downto 0);
  signal n207_o : std_logic_vector (1535 downto 0);
  signal n208_o : std_logic_vector (6 downto 0);
  signal n209_o : std_logic_vector (7 downto 0);
  signal n213_o : std_logic_vector (63 downto 0);
  signal n215_o : std_logic;
  signal n217_o : std_logic_vector (63 downto 0);
  signal n219_o : std_logic_vector (63 downto 0);
  signal n220_o : std_logic_vector (63 downto 0);
  signal n221_o : std_logic_vector (63 downto 0);
  signal n222_o : std_logic;
  signal n223_o : std_logic;
  signal n224_o : std_logic_vector (383 downto 0);
  signal n225_o : std_logic_vector (1087 downto 0);
  signal n226_o : std_logic_vector (1535 downto 0);
  signal n227_o : std_logic_vector (6 downto 0);
  signal n228_o : std_logic_vector (7 downto 0);
  signal n229_o : std_logic_vector (1535 downto 0);
  signal n230_o : std_logic_vector (7 downto 0);
  signal n231_o : std_logic_vector (1 downto 0);
  signal n233_o : std_logic;
  signal n234_o : std_logic_vector (1 downto 0);
  signal n236_o : std_logic;
  signal n237_o : std_logic;
  signal n241_o : std_logic_vector (63 downto 0);
  signal n243_o : std_logic;
  signal n245_o : std_logic_vector (63 downto 0);
  signal n247_o : std_logic_vector (63 downto 0);
  signal n248_o : std_logic_vector (63 downto 0);
  signal n249_o : std_logic_vector (63 downto 0);
  signal n250_o : std_logic_vector (63 downto 0);
  signal n251_o : std_logic_vector (63 downto 0);
  signal n252_o : std_logic;
  signal n253_o : std_logic;
  signal n254_o : std_logic;
  signal n255_o : std_logic;
  signal n256_o : std_logic_vector (1471 downto 0);
  signal n257_o : std_logic_vector (1471 downto 0);
  signal n258_o : std_logic_vector (1471 downto 0);
  signal n259_o : std_logic_vector (1535 downto 0);
  signal n260_o : std_logic_vector (6 downto 0);
  signal n261_o : std_logic_vector (6 downto 0);
  signal n262_o : std_logic_vector (6 downto 0);
  signal n263_o : std_logic_vector (7 downto 0);
  signal n264_o : std_logic_vector (1535 downto 0);
  signal n265_o : std_logic_vector (7 downto 0);
  signal n266_o : std_logic;
  signal n268_o : std_logic_vector (63 downto 0);
  signal n269_o : std_logic_vector (63 downto 0);
  signal n271_o : std_logic_vector (2 downto 0);
  signal n272_o : std_logic_vector (63 downto 0);
  signal n273_o : std_logic;
  signal n275_o : std_logic_vector (3 downto 0);
  signal n277_o : std_logic;
  signal n278_o : std_logic_vector (1535 downto 0);
  signal n279_o : std_logic_vector (1 downto 0);
  signal n280_o : std_logic_vector (2 downto 0);
  signal n281_o : std_logic;
  signal n282_o : std_logic_vector (7 downto 0);
  signal n283_o : std_logic_vector (7 downto 0);
  signal n285_o : std_logic;
  signal n287_o : std_logic;
  signal n288_o : std_logic;
  signal n291_o : std_logic_vector (2 downto 0);
  signal n293_o : std_logic;
  signal n294_o : std_logic;
  signal n295_o : std_logic;
  signal n298_o : std_logic_vector (31 downto 0);
  signal n300_o : std_logic_vector (31 downto 0);
  signal n301_o : std_logic_vector (30 downto 0);
  signal n302_o : std_logic_vector (1 downto 0);
  signal n303_o : std_logic_vector (2 downto 0);
  signal n304_o : std_logic;
  signal n305_o : std_logic_vector (7 downto 0);
  signal n308_o : std_logic_vector (4 downto 0);
  signal n310_o : std_logic_vector (4 downto 0);
  signal n314_o : std_logic;
  signal n316_o : std_logic_vector (4 downto 0);
  signal n318_o : std_logic_vector (4 downto 0);
  signal n320_o : std_logic_vector (4 downto 0);
  signal n322_o : std_logic_vector (4 downto 0);
  signal n326_o : std_logic_vector (63 downto 0);
  signal n328_o : std_logic_vector (1535 downto 0);
  signal n329_o : std_logic;
  signal n330_o : std_logic;
  signal n331_o : std_logic_vector (6 downto 0);
  signal n332_o : std_logic_vector (7 downto 0);
  signal n333_o : std_logic_vector (1 downto 0);
  signal n339_o : std_logic_vector (63 downto 0);
  signal n341_o : std_logic;
  signal n343_o : std_logic_vector (63 downto 0);
  signal n345_o : std_logic_vector (63 downto 0);
  signal n346_o : std_logic_vector (63 downto 0);
  signal n347_o : std_logic_vector (63 downto 0);
  signal n348_o : std_logic_vector (63 downto 0);
  signal n349_o : std_logic_vector (63 downto 0);
  signal n350_o : std_logic;
  signal n351_o : std_logic;
  signal n352_o : std_logic_vector (63 downto 0);
  signal n353_o : std_logic_vector (63 downto 0);
  signal n354_o : std_logic_vector (63 downto 0);
  signal n355_o : std_logic_vector (1407 downto 0);
  signal n356_o : std_logic_vector (1407 downto 0);
  signal n357_o : std_logic_vector (1407 downto 0);
  signal n358_o : std_logic_vector (1535 downto 0);
  signal n359_o : std_logic_vector (6 downto 0);
  signal n360_o : std_logic_vector (7 downto 0);
  signal n362_o : std_logic;
  signal n363_o : std_logic_vector (1535 downto 0);
  signal n364_o : std_logic_vector (7 downto 0);
  signal n365_o : std_logic_vector (1 downto 0);
  signal n369_o : std_logic_vector (3 downto 0);
  signal n370_o : std_logic;
  signal n371_o : std_logic_vector (1535 downto 0);
  signal n372_o : std_logic_vector (4 downto 0);
  signal n373_o : std_logic_vector (1 downto 0);
  signal n374_o : std_logic_vector (1 downto 0);
  signal n375_o : std_logic_vector (4 downto 0);
  signal n376_o : std_logic_vector (4 downto 0);
  signal n377_o : std_logic;
  signal n378_o : std_logic;
  signal n379_o : std_logic_vector (1 downto 0);
  signal n380_o : std_logic;
  signal n381_o : std_logic_vector (1 downto 0);
  signal n382_o : std_logic_vector (1 downto 0);
  signal n384_o : std_logic_vector (2 downto 0);
  signal n385_o : std_logic_vector (3 downto 0);
  signal n386_o : std_logic;
  signal n387_o : std_logic_vector (1535 downto 0);
  signal n388_o : std_logic_vector (7 downto 0);
  signal n389_o : std_logic_vector (1 downto 0);
  signal n390_o : std_logic_vector (2 downto 0);
  signal n391_o : std_logic;
  signal n392_o : std_logic_vector (7 downto 0);
  signal n393_o : std_logic_vector (7 downto 0);
  signal n396_o : std_logic;
  signal n397_o : std_logic_vector (1 downto 0);
  signal n398_o : std_logic_vector (2 downto 0);
  signal n399_o : std_logic;
  signal n400_o : std_logic_vector (7 downto 0);
  signal n402_o : std_logic;
  signal n404_o : std_logic;
  signal n405_o : std_logic_vector (5 downto 0);
  signal n408_o : std_logic_vector (2 downto 0);
  signal n410_o : std_logic_vector (1535 downto 0);
  signal n412_o : std_logic_vector (7 downto 0);
  signal n414_o : std_logic_vector (63 downto 0);
  signal n416_o : std_logic_vector (63 downto 0);
  signal n418_o : std_logic_vector (63 downto 0);
  signal n420_o : std_logic_vector (63 downto 0);
  signal n422_o : std_logic_vector (63 downto 0);
  signal n424_o : std_logic_vector (63 downto 0);
  signal n426_o : std_logic_vector (2 downto 0);
  signal n428_o : std_logic_vector (3 downto 0);
  signal n430_o : std_logic;
  signal n432_o : std_logic_vector (31 downto 0);
  signal n434_o : std_logic_vector (1 downto 0);
  signal n436_o : std_logic_vector (1535 downto 0);
  signal n437_o : std_logic;
  signal n438_o : std_logic;
  signal n439_o : std_logic;
  signal n440_o : std_logic;
  signal n442_o : std_logic;
  signal n443_o : std_logic;
  signal n444_o : std_logic;
  signal n445_o : std_logic;
  signal n446_o : std_logic;
  signal n448_o : std_logic;
  signal n449_o : std_logic;
  signal n450_o : std_logic;
  signal n451_o : std_logic;
  signal n453_o : std_logic;
  signal n454_o : std_logic;
  signal n455_o : std_logic;
  signal n456_o : std_logic;
  signal n457_o : std_logic;
  signal n459_o : std_logic;
  signal n460_o : std_logic;
  signal n461_o : std_logic;
  signal n462_o : std_logic;
  signal n463_o : std_logic;
  signal n465_o : std_logic;
  signal n466_o : std_logic;
  signal n467_o : std_logic;
  signal n468_o : std_logic;
  signal n469_o : std_logic;
  signal n471_o : std_logic;
  signal n472_o : std_logic_vector (1 downto 0);
  signal n473_o : std_logic_vector (1 downto 0);
  signal n474_o : std_logic_vector (1 downto 0);
  signal n475_o : std_logic;
  signal n476_o : std_logic_vector (1 downto 0);
  signal n478_o : std_logic_vector (1 downto 0);
  signal n482_o : std_logic_vector (2 downto 0);
  signal n484_o : std_logic_vector (1535 downto 0);
  signal n486_o : std_logic_vector (7 downto 0);
  signal n488_o : std_logic_vector (63 downto 0);
  signal n490_o : std_logic_vector (63 downto 0);
  signal n492_o : std_logic_vector (63 downto 0);
  signal n494_o : std_logic_vector (63 downto 0);
  signal n496_o : std_logic_vector (63 downto 0);
  signal n498_o : std_logic_vector (63 downto 0);
  signal n500_o : std_logic_vector (2 downto 0);
  signal n502_o : std_logic_vector (3 downto 0);
  signal n504_o : std_logic;
  signal n506_o : std_logic_vector (31 downto 0);
  signal n508_o : std_logic_vector (1 downto 0);
  signal n510_o : std_logic_vector (1535 downto 0);
  signal n511_o : std_logic_vector (7 downto 0);
  signal n513_o : std_logic_vector (7 downto 0);
  signal n535_q : std_logic_vector (2 downto 0) := "000";
  signal n536_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n537_q : std_logic_vector (1535 downto 0) := "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  signal n538_q : std_logic_vector (7 downto 0) := "00000000";
  signal n539_q : std_logic_vector (7 downto 0) := "00000000";
  signal n540_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n541_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n542_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n543_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n544_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n545_q : std_logic_vector (63 downto 0) := "0000000000000000000000000000000000000000000000000000000000000000";
  signal n546_q : std_logic_vector (2 downto 0) := "000";
  signal n547_q : std_logic_vector (3 downto 0) := "0000";
  signal n548_q : std_logic := '0';
  signal n549_q : std_logic_vector (31 downto 0) := "00000000000000000000000000000000";
  signal n550_q : std_logic_vector (1 downto 0) := "00";
  signal n552_o : std_logic_vector (63 downto 0);
  signal n553_o : std_logic_vector (63 downto 0);
  signal n554_o : std_logic_vector (63 downto 0);
  signal n555_o : std_logic_vector (63 downto 0);
  signal n556_o : std_logic_vector (63 downto 0);
  signal n557_o : std_logic_vector (63 downto 0);
  signal n558_o : std_logic_vector (63 downto 0);
  signal n559_o : std_logic_vector (63 downto 0);
  signal n560_o : std_logic_vector (63 downto 0);
  signal n561_o : std_logic_vector (63 downto 0);
  signal n562_o : std_logic_vector (63 downto 0);
  signal n563_o : std_logic_vector (63 downto 0);
  signal n564_o : std_logic_vector (63 downto 0);
  signal n565_o : std_logic_vector (63 downto 0);
  signal n566_o : std_logic_vector (63 downto 0);
  signal n567_o : std_logic_vector (63 downto 0);
  signal n568_o : std_logic_vector (63 downto 0);
  signal n569_o : std_logic_vector (63 downto 0);
  signal n570_o : std_logic_vector (63 downto 0);
  signal n571_o : std_logic_vector (63 downto 0);
  signal n572_o : std_logic_vector (63 downto 0);
  signal n573_o : std_logic_vector (63 downto 0);
  signal n574_o : std_logic_vector (63 downto 0);
  signal n575_o : std_logic_vector (63 downto 0);
  signal n576_o : std_logic_vector (1 downto 0);
  signal n577_o : std_logic_vector (63 downto 0);
  signal n578_o : std_logic_vector (1 downto 0);
  signal n579_o : std_logic_vector (63 downto 0);
  signal n580_o : std_logic_vector (1 downto 0);
  signal n581_o : std_logic_vector (63 downto 0);
  signal n582_o : std_logic_vector (1 downto 0);
  signal n583_o : std_logic_vector (63 downto 0);
  signal n584_o : std_logic_vector (1 downto 0);
  signal n585_o : std_logic_vector (63 downto 0);
  signal n586_o : std_logic_vector (1 downto 0);
  signal n587_o : std_logic_vector (63 downto 0);
  signal n588_o : std_logic_vector (1 downto 0);
  signal n589_o : std_logic_vector (63 downto 0);
  signal n590_o : std_logic;
  signal n591_o : std_logic_vector (63 downto 0);
  signal n592_o : std_logic;
  signal n593_o : std_logic_vector (63 downto 0);
  signal n594_o : std_logic_vector (63 downto 0);
  signal n595_o : std_logic_vector (63 downto 0);
  signal n596_o : std_logic_vector (63 downto 0);
  signal n597_o : std_logic_vector (63 downto 0);
  signal n598_o : std_logic_vector (63 downto 0);
  signal n599_o : std_logic_vector (63 downto 0);
  signal n600_o : std_logic_vector (63 downto 0);
  signal n601_o : std_logic_vector (63 downto 0);
  signal n602_o : std_logic_vector (63 downto 0);
  signal n603_o : std_logic_vector (63 downto 0);
  signal n604_o : std_logic_vector (63 downto 0);
  signal n605_o : std_logic_vector (63 downto 0);
  signal n606_o : std_logic_vector (63 downto 0);
  signal n607_o : std_logic_vector (63 downto 0);
  signal n608_o : std_logic_vector (63 downto 0);
  signal n609_o : std_logic_vector (63 downto 0);
  signal n610_o : std_logic_vector (63 downto 0);
  signal n611_o : std_logic_vector (63 downto 0);
  signal n612_o : std_logic_vector (63 downto 0);
  signal n613_o : std_logic_vector (63 downto 0);
  signal n614_o : std_logic_vector (63 downto 0);
  signal n615_o : std_logic_vector (63 downto 0);
  signal n616_o : std_logic_vector (63 downto 0);
  signal n617_o : std_logic_vector (63 downto 0);
  signal n618_o : std_logic_vector (1 downto 0);
  signal n619_o : std_logic_vector (63 downto 0);
  signal n620_o : std_logic_vector (1 downto 0);
  signal n621_o : std_logic_vector (63 downto 0);
  signal n622_o : std_logic_vector (1 downto 0);
  signal n623_o : std_logic_vector (63 downto 0);
  signal n624_o : std_logic_vector (1 downto 0);
  signal n625_o : std_logic_vector (63 downto 0);
  signal n626_o : std_logic_vector (1 downto 0);
  signal n627_o : std_logic_vector (63 downto 0);
  signal n628_o : std_logic_vector (1 downto 0);
  signal n629_o : std_logic_vector (63 downto 0);
  signal n630_o : std_logic_vector (1 downto 0);
  signal n631_o : std_logic_vector (63 downto 0);
  signal n632_o : std_logic;
  signal n633_o : std_logic_vector (63 downto 0);
  signal n634_o : std_logic;
  signal n635_o : std_logic_vector (63 downto 0);
  signal n636_o : std_logic;
  signal n637_o : std_logic;
  signal n638_o : std_logic;
  signal n639_o : std_logic;
  signal n640_o : std_logic;
  signal n641_o : std_logic;
  signal n642_o : std_logic;
  signal n643_o : std_logic;
  signal n644_o : std_logic;
  signal n645_o : std_logic;
  signal n646_o : std_logic;
  signal n647_o : std_logic;
  signal n648_o : std_logic;
  signal n649_o : std_logic;
  signal n650_o : std_logic;
  signal n651_o : std_logic;
  signal n652_o : std_logic;
  signal n653_o : std_logic;
  signal n654_o : std_logic;
  signal n655_o : std_logic;
  signal n656_o : std_logic;
  signal n657_o : std_logic;
  signal n658_o : std_logic;
  signal n659_o : std_logic;
  signal n660_o : std_logic;
  signal n661_o : std_logic;
  signal n662_o : std_logic;
  signal n663_o : std_logic;
  signal n664_o : std_logic;
  signal n665_o : std_logic;
  signal n666_o : std_logic;
  signal n667_o : std_logic;
  signal n668_o : std_logic;
  signal n669_o : std_logic;
  signal n670_o : std_logic;
  signal n671_o : std_logic;
  signal n672_o : std_logic;
  signal n673_o : std_logic;
  signal n674_o : std_logic;
  signal n675_o : std_logic;
  signal n676_o : std_logic;
  signal n677_o : std_logic;
  signal n678_o : std_logic;
  signal n679_o : std_logic;
  signal n680_o : std_logic;
  signal n681_o : std_logic;
  signal n682_o : std_logic;
  signal n683_o : std_logic;
  signal n684_o : std_logic;
  signal n685_o : std_logic;
  signal n686_o : std_logic;
  signal n687_o : std_logic;
  signal n688_o : std_logic;
  signal n689_o : std_logic;
  signal n690_o : std_logic;
  signal n691_o : std_logic_vector (63 downto 0);
  signal n692_o : std_logic_vector (63 downto 0);
  signal n693_o : std_logic_vector (63 downto 0);
  signal n694_o : std_logic_vector (63 downto 0);
  signal n695_o : std_logic_vector (63 downto 0);
  signal n696_o : std_logic_vector (63 downto 0);
  signal n697_o : std_logic_vector (63 downto 0);
  signal n698_o : std_logic_vector (63 downto 0);
  signal n699_o : std_logic_vector (63 downto 0);
  signal n700_o : std_logic_vector (63 downto 0);
  signal n701_o : std_logic_vector (63 downto 0);
  signal n702_o : std_logic_vector (63 downto 0);
  signal n703_o : std_logic_vector (63 downto 0);
  signal n704_o : std_logic_vector (63 downto 0);
  signal n705_o : std_logic_vector (63 downto 0);
  signal n706_o : std_logic_vector (63 downto 0);
  signal n707_o : std_logic_vector (63 downto 0);
  signal n708_o : std_logic_vector (63 downto 0);
  signal n709_o : std_logic_vector (63 downto 0);
  signal n710_o : std_logic_vector (63 downto 0);
  signal n711_o : std_logic_vector (63 downto 0);
  signal n712_o : std_logic_vector (63 downto 0);
  signal n713_o : std_logic_vector (63 downto 0);
  signal n714_o : std_logic_vector (63 downto 0);
  signal n715_o : std_logic_vector (63 downto 0);
  signal n716_o : std_logic_vector (63 downto 0);
  signal n717_o : std_logic_vector (63 downto 0);
  signal n718_o : std_logic_vector (63 downto 0);
  signal n719_o : std_logic_vector (63 downto 0);
  signal n720_o : std_logic_vector (63 downto 0);
  signal n721_o : std_logic_vector (63 downto 0);
  signal n722_o : std_logic_vector (63 downto 0);
  signal n723_o : std_logic_vector (63 downto 0);
  signal n724_o : std_logic_vector (63 downto 0);
  signal n725_o : std_logic_vector (63 downto 0);
  signal n726_o : std_logic_vector (63 downto 0);
  signal n727_o : std_logic_vector (63 downto 0);
  signal n728_o : std_logic_vector (63 downto 0);
  signal n729_o : std_logic_vector (63 downto 0);
  signal n730_o : std_logic_vector (63 downto 0);
  signal n731_o : std_logic_vector (63 downto 0);
  signal n732_o : std_logic_vector (63 downto 0);
  signal n733_o : std_logic_vector (63 downto 0);
  signal n734_o : std_logic_vector (63 downto 0);
  signal n735_o : std_logic_vector (63 downto 0);
  signal n736_o : std_logic_vector (63 downto 0);
  signal n737_o : std_logic_vector (63 downto 0);
  signal n738_o : std_logic_vector (63 downto 0);
  signal n739_o : std_logic_vector (1535 downto 0);
  signal n740_o : std_logic_vector (63 downto 0);
  signal n741_o : std_logic_vector (63 downto 0);
  signal n742_o : std_logic_vector (63 downto 0);
  signal n743_o : std_logic_vector (63 downto 0);
  signal n744_o : std_logic_vector (63 downto 0);
  signal n745_o : std_logic_vector (63 downto 0);
  signal n746_o : std_logic_vector (63 downto 0);
  signal n747_o : std_logic_vector (63 downto 0);
  signal n748_o : std_logic_vector (63 downto 0);
  signal n749_o : std_logic_vector (63 downto 0);
  signal n750_o : std_logic_vector (63 downto 0);
  signal n751_o : std_logic_vector (63 downto 0);
  signal n752_o : std_logic_vector (63 downto 0);
  signal n753_o : std_logic_vector (63 downto 0);
  signal n754_o : std_logic_vector (63 downto 0);
  signal n755_o : std_logic_vector (63 downto 0);
  signal n756_o : std_logic_vector (63 downto 0);
  signal n757_o : std_logic_vector (63 downto 0);
  signal n758_o : std_logic_vector (63 downto 0);
  signal n759_o : std_logic_vector (63 downto 0);
  signal n760_o : std_logic_vector (63 downto 0);
  signal n761_o : std_logic_vector (63 downto 0);
  signal n762_o : std_logic_vector (63 downto 0);
  signal n763_o : std_logic_vector (63 downto 0);
  signal n764_o : std_logic_vector (1 downto 0);
  signal n765_o : std_logic_vector (63 downto 0);
  signal n766_o : std_logic_vector (1 downto 0);
  signal n767_o : std_logic_vector (63 downto 0);
  signal n768_o : std_logic_vector (1 downto 0);
  signal n769_o : std_logic_vector (63 downto 0);
  signal n770_o : std_logic_vector (1 downto 0);
  signal n771_o : std_logic_vector (63 downto 0);
  signal n772_o : std_logic_vector (1 downto 0);
  signal n773_o : std_logic_vector (63 downto 0);
  signal n774_o : std_logic_vector (1 downto 0);
  signal n775_o : std_logic_vector (63 downto 0);
  signal n776_o : std_logic_vector (1 downto 0);
  signal n777_o : std_logic_vector (63 downto 0);
  signal n778_o : std_logic;
  signal n779_o : std_logic_vector (63 downto 0);
  signal n780_o : std_logic;
  signal n781_o : std_logic_vector (63 downto 0);
  signal n782_o : std_logic_vector (63 downto 0);
  signal n783_o : std_logic_vector (63 downto 0);
  signal n784_o : std_logic_vector (63 downto 0);
  signal n785_o : std_logic_vector (63 downto 0);
  signal n786_o : std_logic_vector (63 downto 0);
  signal n787_o : std_logic_vector (63 downto 0);
  signal n788_o : std_logic_vector (63 downto 0);
  signal n789_o : std_logic_vector (63 downto 0);
  signal n790_o : std_logic_vector (63 downto 0);
  signal n791_o : std_logic_vector (63 downto 0);
  signal n792_o : std_logic_vector (63 downto 0);
  signal n793_o : std_logic_vector (63 downto 0);
  signal n794_o : std_logic_vector (63 downto 0);
  signal n795_o : std_logic_vector (63 downto 0);
  signal n796_o : std_logic_vector (63 downto 0);
  signal n797_o : std_logic_vector (63 downto 0);
  signal n798_o : std_logic_vector (63 downto 0);
  signal n799_o : std_logic_vector (63 downto 0);
  signal n800_o : std_logic_vector (63 downto 0);
  signal n801_o : std_logic_vector (63 downto 0);
  signal n802_o : std_logic_vector (63 downto 0);
  signal n803_o : std_logic_vector (63 downto 0);
  signal n804_o : std_logic_vector (63 downto 0);
  signal n805_o : std_logic_vector (63 downto 0);
  signal n806_o : std_logic_vector (1 downto 0);
  signal n807_o : std_logic_vector (63 downto 0);
  signal n808_o : std_logic_vector (1 downto 0);
  signal n809_o : std_logic_vector (63 downto 0);
  signal n810_o : std_logic_vector (1 downto 0);
  signal n811_o : std_logic_vector (63 downto 0);
  signal n812_o : std_logic_vector (1 downto 0);
  signal n813_o : std_logic_vector (63 downto 0);
  signal n814_o : std_logic_vector (1 downto 0);
  signal n815_o : std_logic_vector (63 downto 0);
  signal n816_o : std_logic_vector (1 downto 0);
  signal n817_o : std_logic_vector (63 downto 0);
  signal n818_o : std_logic_vector (1 downto 0);
  signal n819_o : std_logic_vector (63 downto 0);
  signal n820_o : std_logic;
  signal n821_o : std_logic_vector (63 downto 0);
  signal n822_o : std_logic;
  signal n823_o : std_logic_vector (63 downto 0);
  signal n824_o : std_logic;
  signal n825_o : std_logic;
  signal n826_o : std_logic;
  signal n827_o : std_logic;
  signal n828_o : std_logic;
  signal n829_o : std_logic;
  signal n830_o : std_logic;
  signal n831_o : std_logic;
  signal n832_o : std_logic;
  signal n833_o : std_logic;
  signal n834_o : std_logic;
  signal n835_o : std_logic;
  signal n836_o : std_logic;
  signal n837_o : std_logic;
  signal n838_o : std_logic;
  signal n839_o : std_logic;
  signal n840_o : std_logic;
  signal n841_o : std_logic;
  signal n842_o : std_logic;
  signal n843_o : std_logic;
  signal n844_o : std_logic;
  signal n845_o : std_logic;
  signal n846_o : std_logic;
  signal n847_o : std_logic;
  signal n848_o : std_logic;
  signal n849_o : std_logic;
  signal n850_o : std_logic;
  signal n851_o : std_logic;
  signal n852_o : std_logic;
  signal n853_o : std_logic;
  signal n854_o : std_logic;
  signal n855_o : std_logic;
  signal n856_o : std_logic;
  signal n857_o : std_logic;
  signal n858_o : std_logic;
  signal n859_o : std_logic;
  signal n860_o : std_logic;
  signal n861_o : std_logic;
  signal n862_o : std_logic;
  signal n863_o : std_logic;
  signal n864_o : std_logic;
  signal n865_o : std_logic;
  signal n866_o : std_logic;
  signal n867_o : std_logic;
  signal n868_o : std_logic;
  signal n869_o : std_logic;
  signal n870_o : std_logic;
  signal n871_o : std_logic;
  signal n872_o : std_logic;
  signal n873_o : std_logic;
  signal n874_o : std_logic;
  signal n875_o : std_logic;
  signal n876_o : std_logic;
  signal n877_o : std_logic;
  signal n878_o : std_logic;
  signal n879_o : std_logic_vector (63 downto 0);
  signal n880_o : std_logic_vector (63 downto 0);
  signal n881_o : std_logic_vector (63 downto 0);
  signal n882_o : std_logic_vector (63 downto 0);
  signal n883_o : std_logic_vector (63 downto 0);
  signal n884_o : std_logic_vector (63 downto 0);
  signal n885_o : std_logic_vector (63 downto 0);
  signal n886_o : std_logic_vector (63 downto 0);
  signal n887_o : std_logic_vector (63 downto 0);
  signal n888_o : std_logic_vector (63 downto 0);
  signal n889_o : std_logic_vector (63 downto 0);
  signal n890_o : std_logic_vector (63 downto 0);
  signal n891_o : std_logic_vector (63 downto 0);
  signal n892_o : std_logic_vector (63 downto 0);
  signal n893_o : std_logic_vector (63 downto 0);
  signal n894_o : std_logic_vector (63 downto 0);
  signal n895_o : std_logic_vector (63 downto 0);
  signal n896_o : std_logic_vector (63 downto 0);
  signal n897_o : std_logic_vector (63 downto 0);
  signal n898_o : std_logic_vector (63 downto 0);
  signal n899_o : std_logic_vector (63 downto 0);
  signal n900_o : std_logic_vector (63 downto 0);
  signal n901_o : std_logic_vector (63 downto 0);
  signal n902_o : std_logic_vector (63 downto 0);
  signal n903_o : std_logic_vector (63 downto 0);
  signal n904_o : std_logic_vector (63 downto 0);
  signal n905_o : std_logic_vector (63 downto 0);
  signal n906_o : std_logic_vector (63 downto 0);
  signal n907_o : std_logic_vector (63 downto 0);
  signal n908_o : std_logic_vector (63 downto 0);
  signal n909_o : std_logic_vector (63 downto 0);
  signal n910_o : std_logic_vector (63 downto 0);
  signal n911_o : std_logic_vector (63 downto 0);
  signal n912_o : std_logic_vector (63 downto 0);
  signal n913_o : std_logic_vector (63 downto 0);
  signal n914_o : std_logic_vector (63 downto 0);
  signal n915_o : std_logic_vector (63 downto 0);
  signal n916_o : std_logic_vector (63 downto 0);
  signal n917_o : std_logic_vector (63 downto 0);
  signal n918_o : std_logic_vector (63 downto 0);
  signal n919_o : std_logic_vector (63 downto 0);
  signal n920_o : std_logic_vector (63 downto 0);
  signal n921_o : std_logic_vector (63 downto 0);
  signal n922_o : std_logic_vector (63 downto 0);
  signal n923_o : std_logic_vector (63 downto 0);
  signal n924_o : std_logic_vector (63 downto 0);
  signal n925_o : std_logic_vector (63 downto 0);
  signal n926_o : std_logic_vector (63 downto 0);
  signal n927_o : std_logic_vector (1535 downto 0);
  signal n928_o : std_logic;
  signal n929_o : std_logic;
  signal n930_o : std_logic;
  signal n931_o : std_logic;
  signal n932_o : std_logic_vector (1 downto 0);
  signal n933_o : std_logic;
  signal n934_o : std_logic;
  signal n935_o : std_logic;
  signal n936_o : std_logic;
  signal n937_o : std_logic;
  signal n938_o : std_logic;
  signal n939_o : std_logic;
  signal n940_o : std_logic;
  signal n941_o : std_logic;
  signal n942_o : std_logic;
  signal n943_o : std_logic;
  signal n944_o : std_logic;
  signal n945_o : std_logic;
  signal n946_o : std_logic;
  signal n947_o : std_logic;
  signal n948_o : std_logic;
  signal n949_o : std_logic;
  signal n950_o : std_logic_vector (3 downto 0);
begin
  wrap_clk <= clk;
  wrap_reset <= reset;
  wrap_start <= start;
  wrap_cfg_start_ps <= typwrap_cfg_start_ps(cfg_start_ps);
  wrap_cfg_stop_ps <= typwrap_cfg_stop_ps(cfg_stop_ps);
  wrap_cfg_calibration_id <= typwrap_cfg_calibration_id(cfg_calibration_id);
  wrap_cfg_setting <= typwrap_cfg_setting(cfg_setting);
  wrap_in_valid <= in_valid;
  wrap_in_kind <= typwrap_in_kind(in_kind);
  wrap_in_time_ps <= typwrap_in_time_ps(in_time_ps);
  wrap_in_calibration_id <= typwrap_in_calibration_id(in_calibration_id);
  wrap_source_error <= source_error;
  in_ready <= wrap_in_ready;
  snapshot_ready <= wrap_snapshot_ready;
  snapshot_counts ( 0) <= unresolved_unsigned(wrap_snapshot_counts (63 downto 0));
  snapshot_counts ( 1) <= unresolved_unsigned(wrap_snapshot_counts (127 downto 64));
  snapshot_counts ( 2) <= unresolved_unsigned(wrap_snapshot_counts (191 downto 128));
  snapshot_counts ( 3) <= unresolved_unsigned(wrap_snapshot_counts (255 downto 192));
  snapshot_counts ( 4) <= unresolved_unsigned(wrap_snapshot_counts (319 downto 256));
  snapshot_counts ( 5) <= unresolved_unsigned(wrap_snapshot_counts (383 downto 320));
  snapshot_counts ( 6) <= unresolved_unsigned(wrap_snapshot_counts (447 downto 384));
  snapshot_counts ( 7) <= unresolved_unsigned(wrap_snapshot_counts (511 downto 448));
  snapshot_counts ( 8) <= unresolved_unsigned(wrap_snapshot_counts (575 downto 512));
  snapshot_counts ( 9) <= unresolved_unsigned(wrap_snapshot_counts (639 downto 576));
  snapshot_counts ( 10) <= unresolved_unsigned(wrap_snapshot_counts (703 downto 640));
  snapshot_counts ( 11) <= unresolved_unsigned(wrap_snapshot_counts (767 downto 704));
  snapshot_counts ( 12) <= unresolved_unsigned(wrap_snapshot_counts (831 downto 768));
  snapshot_counts ( 13) <= unresolved_unsigned(wrap_snapshot_counts (895 downto 832));
  snapshot_counts ( 14) <= unresolved_unsigned(wrap_snapshot_counts (959 downto 896));
  snapshot_counts ( 15) <= unresolved_unsigned(wrap_snapshot_counts (1023 downto 960));
  snapshot_counts ( 16) <= unresolved_unsigned(wrap_snapshot_counts (1087 downto 1024));
  snapshot_counts ( 17) <= unresolved_unsigned(wrap_snapshot_counts (1151 downto 1088));
  snapshot_counts ( 18) <= unresolved_unsigned(wrap_snapshot_counts (1215 downto 1152));
  snapshot_counts ( 19) <= unresolved_unsigned(wrap_snapshot_counts (1279 downto 1216));
  snapshot_counts ( 20) <= unresolved_unsigned(wrap_snapshot_counts (1343 downto 1280));
  snapshot_counts ( 21) <= unresolved_unsigned(wrap_snapshot_counts (1407 downto 1344));
  snapshot_counts ( 22) <= unresolved_unsigned(wrap_snapshot_counts (1471 downto 1408));
  snapshot_counts ( 23) <= unresolved_unsigned(wrap_snapshot_counts (1535 downto 1472));
  snapshot_flags <= std_ulogic_vector(wrap_snapshot_flags);
  snapshot_start_ps <= unresolved_unsigned(wrap_snapshot_start_ps);
  snapshot_stop_ps <= unresolved_unsigned(wrap_snapshot_stop_ps);
  snapshot_calibration_id <= std_ulogic_vector(wrap_snapshot_calibration_id);
  snapshot_setting <= unresolved_unsigned(wrap_snapshot_setting);
  wrap_in_ready <= n27_o;
  wrap_snapshot_ready <= n32_o;
  wrap_snapshot_counts <= shadow;
  wrap_snapshot_flags <= shadow_flags;
  wrap_snapshot_start_ps <= run_start;
  wrap_snapshot_stop_ps <= run_stop;
  wrap_snapshot_calibration_id <= calibration;
  wrap_snapshot_setting <= setting;
  -- rtl/sagnac_core.vhd:31:10
  state <= n535_q; -- (isignal)
  -- rtl/sagnac_core.vhd:32:10
  counts <= n536_q; -- (isignal)
  -- rtl/sagnac_core.vhd:32:18
  shadow <= n537_q; -- (isignal)
  -- rtl/sagnac_core.vhd:33:10
  flags <= n538_q; -- (isignal)
  -- rtl/sagnac_core.vhd:33:17
  shadow_flags <= n539_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:10
  run_start <= n540_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:21
  run_stop <= n541_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:31
  bin_start <= n542_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:42
  bin_end <= n543_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:51
  last_time <= n544_q; -- (isignal)
  -- rtl/sagnac_core.vhd:34:62
  item_time <= n545_q; -- (isignal)
  -- rtl/sagnac_core.vhd:35:10
  item_kind <= n546_q; -- (isignal)
  -- rtl/sagnac_core.vhd:36:10
  mask <= n547_q; -- (isignal)
  -- rtl/sagnac_core.vhd:37:10
  repeated <= n548_q; -- (isignal)
  -- rtl/sagnac_core.vhd:38:10
  calibration <= n549_q; -- (isignal)
  -- rtl/sagnac_core.vhd:39:10
  setting <= n550_q; -- (isignal)
  -- rtl/sagnac_core.vhd:44:29
  n26_o <= '1' when state = "001" else '0';
  -- rtl/sagnac_core.vhd:44:19
  n27_o <= '0' when n26_o = '0' else '1';
  -- rtl/sagnac_core.vhd:45:35
  n31_o <= '1' when state = "101" else '0';
  -- rtl/sagnac_core.vhd:45:25
  n32_o <= '0' when n31_o = '0' else '1';
  -- rtl/sagnac_core.vhd:76:17
  n41_o <= '1' when state /= "000" else '0';
  -- rtl/sagnac_core.vhd:76:33
  n43_o <= '1' when state /= "101" else '0';
  -- rtl/sagnac_core.vhd:76:24
  n44_o <= n41_o and n43_o;
  n46_o <= flags (2);
  -- rtl/sagnac_core.vhd:76:9
  n47_o <= n46_o when n52_o = '0' else '1';
  n49_o <= flags (6);
  -- rtl/sagnac_core.vhd:76:9
  n50_o <= n49_o when n54_o = '0' else '1';
  -- rtl/sagnac_core.vhd:76:9
  n52_o <= n44_o and wrap_source_error;
  -- rtl/sagnac_core.vhd:76:9
  n54_o <= n44_o and wrap_start;
  -- rtl/sagnac_core.vhd:88:15
  n57_o <= '0' when wrap_source_error = '0' else '1';
  n60_o <= n58_o (1 downto 0);
  -- rtl/sagnac_core.vhd:89:29
  n61_o <= '1' when unsigned (wrap_cfg_stop_ps) <= unsigned (wrap_cfg_start_ps) else '0';
  -- rtl/sagnac_core.vhd:91:33
  n63_o <= std_logic_vector (unsigned (wrap_cfg_stop_ps) - unsigned (wrap_cfg_start_ps));
  -- rtl/sagnac_core.vhd:91:48
  n65_o <= std_logic_vector (unsigned (n63_o) mod unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- rtl/sagnac_core.vhd:91:54
  n67_o <= '1' when n65_o /= "0000000000000000000000000000000000000000000000000000000000000000" else '0';
  -- rtl/sagnac_core.vhd:94:38
  n70_o <= std_logic_vector (unsigned (wrap_cfg_start_ps) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- rtl/sagnac_core.vhd:91:15
  n73_o <= "001" when n67_o = '0' else "100";
  -- rtl/sagnac_core.vhd:91:15
  n74_o <= n70_o when n67_o = '0' else bin_end;
  n75_o <= n58_o (4);
  -- rtl/sagnac_core.vhd:91:15
  n76_o <= n75_o when n67_o = '0' else '1';
  -- rtl/sagnac_core.vhd:89:15
  n78_o <= n73_o when n61_o = '0' else "100";
  -- rtl/sagnac_core.vhd:89:15
  n79_o <= n74_o when n61_o = '0' else bin_end;
  -- rtl/sagnac_core.vhd:89:15
  n80_o <= n76_o when n61_o = '0' else '1';
  n81_o <= n58_o (7 downto 5);
  n82_o <= n58_o (3);
  -- rtl/sagnac_core.vhd:82:13
  n83_o <= state when wrap_start = '0' else n78_o;
  -- rtl/sagnac_core.vhd:82:13
  n84_o <= run_start when wrap_start = '0' else wrap_cfg_start_ps;
  -- rtl/sagnac_core.vhd:82:13
  n85_o <= run_stop when wrap_start = '0' else wrap_cfg_stop_ps;
  -- rtl/sagnac_core.vhd:82:13
  n86_o <= bin_start when wrap_start = '0' else wrap_cfg_start_ps;
  -- rtl/sagnac_core.vhd:82:13
  n87_o <= bin_end when wrap_start = '0' else n79_o;
  -- rtl/sagnac_core.vhd:82:13
  n88_o <= last_time when wrap_start = '0' else wrap_cfg_start_ps;
  -- rtl/sagnac_core.vhd:82:13
  n90_o <= mask when wrap_start = '0' else "0000";
  -- rtl/sagnac_core.vhd:82:13
  n92_o <= repeated when wrap_start = '0' else '0';
  -- rtl/sagnac_core.vhd:82:13
  n93_o <= calibration when wrap_start = '0' else wrap_cfg_calibration_id;
  -- rtl/sagnac_core.vhd:82:13
  n94_o <= setting when wrap_start = '0' else wrap_cfg_setting;
  -- rtl/sagnac_core.vhd:82:13
  n96_o <= counts when wrap_start = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n97_o <= n81_o & n80_o & n82_o & n57_o & n60_o;
  n98_o <= flags (1 downto 0);
  n99_o <= flags (5 downto 3);
  n100_o <= flags (7);
  n101_o <= n100_o & n50_o & n99_o & n47_o & n98_o;
  -- rtl/sagnac_core.vhd:82:13
  n102_o <= n101_o when wrap_start = '0' else n97_o;
  -- rtl/sagnac_core.vhd:81:11
  n104_o <= '1' when state = "000" else '0';
  -- rtl/sagnac_core.vhd:99:25
  n106_o <= '1' when unsigned (wrap_in_kind) > unsigned'("100") else '0';
  -- rtl/sagnac_core.vhd:100:38
  n108_o <= '1' when wrap_in_calibration_id /= calibration else '0';
  -- rtl/sagnac_core.vhd:101:31
  n110_o <= '1' when unsigned (wrap_in_time_ps) < unsigned (last_time) else '0';
  -- rtl/sagnac_core.vhd:101:15
  n113_o <= "010" when n110_o = '0' else state;
  -- rtl/sagnac_core.vhd:101:15
  n114_o <= wrap_in_time_ps when n110_o = '0' else last_time;
  -- rtl/sagnac_core.vhd:101:15
  n115_o <= wrap_in_time_ps when n110_o = '0' else item_time;
  -- rtl/sagnac_core.vhd:101:15
  n116_o <= wrap_in_kind when n110_o = '0' else item_kind;
  n117_o <= flags (1);
  -- rtl/sagnac_core.vhd:101:15
  n118_o <= n117_o when n110_o = '0' else '1';
  -- rtl/sagnac_core.vhd:100:15
  n119_o <= n113_o when n108_o = '0' else state;
  -- rtl/sagnac_core.vhd:100:15
  n120_o <= n114_o when n108_o = '0' else last_time;
  -- rtl/sagnac_core.vhd:100:15
  n121_o <= n115_o when n108_o = '0' else item_time;
  -- rtl/sagnac_core.vhd:100:15
  n122_o <= n116_o when n108_o = '0' else item_kind;
  n123_o <= flags (1);
  -- rtl/sagnac_core.vhd:100:15
  n124_o <= n118_o when n108_o = '0' else n123_o;
  n125_o <= flags (3);
  -- rtl/sagnac_core.vhd:100:15
  n126_o <= n125_o when n108_o = '0' else '1';
  -- rtl/sagnac_core.vhd:99:15
  n127_o <= n119_o when n106_o = '0' else state;
  -- rtl/sagnac_core.vhd:99:15
  n128_o <= n120_o when n106_o = '0' else last_time;
  -- rtl/sagnac_core.vhd:99:15
  n129_o <= n121_o when n106_o = '0' else item_time;
  -- rtl/sagnac_core.vhd:99:15
  n130_o <= n122_o when n106_o = '0' else item_kind;
  n131_o <= flags (1);
  -- rtl/sagnac_core.vhd:99:15
  n132_o <= n124_o when n106_o = '0' else n131_o;
  n133_o <= flags (3);
  -- rtl/sagnac_core.vhd:99:15
  n134_o <= n126_o when n106_o = '0' else n133_o;
  n135_o <= flags (5);
  -- rtl/sagnac_core.vhd:98:13
  n136_o <= n135_o when n146_o = '0' else '1';
  -- rtl/sagnac_core.vhd:98:13
  n137_o <= state when wrap_in_valid = '0' else n127_o;
  -- rtl/sagnac_core.vhd:98:13
  n138_o <= last_time when wrap_in_valid = '0' else n128_o;
  -- rtl/sagnac_core.vhd:98:13
  n139_o <= item_time when wrap_in_valid = '0' else n129_o;
  -- rtl/sagnac_core.vhd:98:13
  n140_o <= item_kind when wrap_in_valid = '0' else n130_o;
  n141_o <= flags (1);
  -- rtl/sagnac_core.vhd:98:13
  n142_o <= n141_o when wrap_in_valid = '0' else n132_o;
  n143_o <= flags (3);
  -- rtl/sagnac_core.vhd:98:13
  n144_o <= n143_o when wrap_in_valid = '0' else n134_o;
  -- rtl/sagnac_core.vhd:98:13
  n146_o <= wrap_in_valid and n106_o;
  -- rtl/sagnac_core.vhd:97:11
  n148_o <= '1' when state = "001" else '0';
  -- rtl/sagnac_core.vhd:108:25
  n149_o <= '1' when unsigned (bin_start) < unsigned (run_stop) else '0';
  -- rtl/sagnac_core.vhd:108:48
  n150_o <= '1' when unsigned (item_time) >= unsigned (bin_end) else '0';
  -- rtl/sagnac_core.vhd:108:35
  n151_o <= n149_o and n150_o;
  n154_o <= flags (1 downto 0);
  n155_o <= flags (5 downto 3);
  n156_o <= flags (7);
  n157_o <= n156_o & n50_o & n155_o & n47_o & n154_o;
  -- rtl/sagnac_core.vhd:61:18
  n160_o <= "0" & mask;  --  uext
  -- rtl/sagnac_core.vhd:61:18
  n162_o <= std_logic_vector (unsigned'("10111") - unsigned (n160_o));
  -- rtl/sagnac_core.vhd:61:21
  n166_o <= '1' when n593_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:20
  n168_o <= "0" & mask;  --  uext
  -- rtl/sagnac_core.vhd:62:20
  n170_o <= std_logic_vector (unsigned'("10111") - unsigned (n168_o));
  -- rtl/sagnac_core.vhd:62:33
  n172_o <= "0" & mask;  --  uext
  -- rtl/sagnac_core.vhd:62:33
  n174_o <= std_logic_vector (unsigned'("10111") - unsigned (n172_o));
  -- rtl/sagnac_core.vhd:62:36
  n178_o <= std_logic_vector (unsigned (n635_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- rtl/sagnac_core.vhd:61:7
  n180_o <= n739_o when n166_o = '0' else counts;
  n181_o <= n157_o (0);
  -- rtl/sagnac_core.vhd:61:7
  n182_o <= n181_o when n166_o = '0' else '1';
  n183_o <= n157_o (7 downto 1);
  n184_o <= n183_o & n182_o;
  -- rtl/sagnac_core.vhd:61:18
  n188_o <= n180_o (511 downto 448);
  -- rtl/sagnac_core.vhd:61:21
  n190_o <= '1' when n188_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:33
  n192_o <= n180_o (511 downto 448);
  -- rtl/sagnac_core.vhd:62:36
  n194_o <= std_logic_vector (unsigned (n192_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n195_o <= counts (511 downto 448);
  n196_o <= n739_o (511 downto 448);
  -- rtl/sagnac_core.vhd:61:7
  n197_o <= n196_o when n166_o = '0' else n195_o;
  -- rtl/sagnac_core.vhd:61:7
  n198_o <= n194_o when n190_o = '0' else n197_o;
  n199_o <= n184_o (0);
  -- rtl/sagnac_core.vhd:61:7
  n200_o <= n199_o when n190_o = '0' else '1';
  n201_o <= counts (447 downto 0);
  n202_o <= n739_o (447 downto 0);
  -- rtl/sagnac_core.vhd:61:7
  n203_o <= n202_o when n166_o = '0' else n201_o;
  n204_o <= counts (1535 downto 512);
  n205_o <= n739_o (1535 downto 512);
  -- rtl/sagnac_core.vhd:61:7
  n206_o <= n205_o when n166_o = '0' else n204_o;
  n207_o <= n206_o & n198_o & n203_o;
  n208_o <= n184_o (7 downto 1);
  n209_o <= n208_o & n200_o;
  -- rtl/sagnac_core.vhd:61:18
  n213_o <= n207_o (447 downto 384);
  -- rtl/sagnac_core.vhd:61:21
  n215_o <= '1' when n213_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:33
  n217_o <= n207_o (447 downto 384);
  -- rtl/sagnac_core.vhd:62:36
  n219_o <= std_logic_vector (unsigned (n217_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n220_o <= n207_o (447 downto 384);
  -- rtl/sagnac_core.vhd:61:7
  n221_o <= n219_o when n215_o = '0' else n220_o;
  n222_o <= n209_o (0);
  -- rtl/sagnac_core.vhd:61:7
  n223_o <= n222_o when n215_o = '0' else '1';
  n224_o <= n207_o (383 downto 0);
  n225_o <= n207_o (1535 downto 448);
  n226_o <= n225_o & n221_o & n224_o;
  n227_o <= n209_o (7 downto 1);
  n228_o <= n227_o & n223_o;
  -- rtl/sagnac_core.vhd:111:15
  n229_o <= n207_o when repeated = '0' else n226_o;
  -- rtl/sagnac_core.vhd:111:15
  n230_o <= n209_o when repeated = '0' else n228_o;
  -- rtl/sagnac_core.vhd:112:22
  n231_o <= mask (1 downto 0);
  -- rtl/sagnac_core.vhd:112:34
  n233_o <= '1' when n231_o = "11" else '0';
  -- rtl/sagnac_core.vhd:112:47
  n234_o <= mask (3 downto 2);
  -- rtl/sagnac_core.vhd:112:59
  n236_o <= '1' when n234_o = "11" else '0';
  -- rtl/sagnac_core.vhd:112:40
  n237_o <= n233_o or n236_o;
  -- rtl/sagnac_core.vhd:61:18
  n241_o <= n229_o (63 downto 0);
  -- rtl/sagnac_core.vhd:61:21
  n243_o <= '1' when n241_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:33
  n245_o <= n229_o (63 downto 0);
  -- rtl/sagnac_core.vhd:62:36
  n247_o <= std_logic_vector (unsigned (n245_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n248_o <= n226_o (63 downto 0);
  n249_o <= n207_o (63 downto 0);
  -- rtl/sagnac_core.vhd:111:15
  n250_o <= n249_o when repeated = '0' else n248_o;
  -- rtl/sagnac_core.vhd:61:7
  n251_o <= n247_o when n243_o = '0' else n250_o;
  n252_o <= n228_o (0);
  n253_o <= n209_o (0);
  -- rtl/sagnac_core.vhd:111:15
  n254_o <= n253_o when repeated = '0' else n252_o;
  -- rtl/sagnac_core.vhd:61:7
  n255_o <= n254_o when n243_o = '0' else '1';
  n256_o <= n226_o (1535 downto 64);
  n257_o <= n207_o (1535 downto 64);
  -- rtl/sagnac_core.vhd:111:15
  n258_o <= n257_o when repeated = '0' else n256_o;
  n259_o <= n258_o & n251_o;
  n260_o <= n228_o (7 downto 1);
  n261_o <= n209_o (7 downto 1);
  -- rtl/sagnac_core.vhd:111:15
  n262_o <= n261_o when repeated = '0' else n260_o;
  n263_o <= n262_o & n255_o;
  -- rtl/sagnac_core.vhd:112:15
  n264_o <= n229_o when n237_o = '0' else n259_o;
  -- rtl/sagnac_core.vhd:112:15
  n265_o <= n230_o when n237_o = '0' else n263_o;
  -- rtl/sagnac_core.vhd:116:25
  n266_o <= '1' when unsigned (bin_end) < unsigned (run_stop) else '0';
  -- rtl/sagnac_core.vhd:116:56
  n268_o <= std_logic_vector (unsigned (bin_end) + unsigned'("0000000000000000000000000000000000000000000000000000001111101000"));
  -- rtl/sagnac_core.vhd:108:13
  n269_o <= bin_end when n273_o = '0' else n268_o;
  -- rtl/sagnac_core.vhd:108:13
  n271_o <= "011" when n151_o = '0' else state;
  -- rtl/sagnac_core.vhd:108:13
  n272_o <= bin_start when n151_o = '0' else bin_end;
  -- rtl/sagnac_core.vhd:108:13
  n273_o <= n151_o and n266_o;
  -- rtl/sagnac_core.vhd:108:13
  n275_o <= mask when n151_o = '0' else "0000";
  -- rtl/sagnac_core.vhd:108:13
  n277_o <= repeated when n151_o = '0' else '0';
  -- rtl/sagnac_core.vhd:108:13
  n278_o <= counts when n151_o = '0' else n264_o;
  n279_o <= flags (1 downto 0);
  n280_o <= flags (5 downto 3);
  n281_o <= flags (7);
  n282_o <= n281_o & n50_o & n280_o & n47_o & n279_o;
  -- rtl/sagnac_core.vhd:108:13
  n283_o <= n282_o when n151_o = '0' else n265_o;
  -- rtl/sagnac_core.vhd:107:11
  n285_o <= '1' when state = "010" else '0';
  -- rtl/sagnac_core.vhd:119:25
  n287_o <= '1' when item_kind = "100" else '0';
  -- rtl/sagnac_core.vhd:120:27
  n288_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- rtl/sagnac_core.vhd:120:15
  n291_o <= "001" when n288_o = '0' else "100";
  -- rtl/sagnac_core.vhd:124:27
  n293_o <= '1' when unsigned (item_time) < unsigned (run_start) else '0';
  -- rtl/sagnac_core.vhd:124:50
  n294_o <= '1' when unsigned (item_time) >= unsigned (run_stop) else '0';
  -- rtl/sagnac_core.vhd:124:38
  n295_o <= n293_o or n294_o;
  -- rtl/sagnac_core.vhd:126:31
  n298_o <= "00000000000000000000000000000" & item_kind;  --  uext
  -- rtl/sagnac_core.vhd:126:31
  n300_o <= std_logic_vector (unsigned'("00000000000000000000000000010010") + unsigned (n298_o));
  -- rtl/sagnac_core.vhd:126:29
  n301_o <= n300_o (30 downto 0);  --  trunc
  n302_o <= flags (1 downto 0);
  n303_o <= flags (5 downto 3);
  n304_o <= flags (7);
  n305_o <= n304_o & n50_o & n303_o & n47_o & n302_o;
  -- rtl/sagnac_core.vhd:61:18
  n308_o <= n301_o (4 downto 0);  --  trunc
  -- rtl/sagnac_core.vhd:61:18
  n310_o <= std_logic_vector (unsigned'("10111") - unsigned (n308_o));
  -- rtl/sagnac_core.vhd:61:21
  n314_o <= '1' when n781_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:20
  n316_o <= n301_o (4 downto 0);  --  trunc
  -- rtl/sagnac_core.vhd:62:20
  n318_o <= std_logic_vector (unsigned'("10111") - unsigned (n316_o));
  -- rtl/sagnac_core.vhd:62:33
  n320_o <= n301_o (4 downto 0);  --  trunc
  -- rtl/sagnac_core.vhd:62:33
  n322_o <= std_logic_vector (unsigned'("10111") - unsigned (n320_o));
  -- rtl/sagnac_core.vhd:62:36
  n326_o <= std_logic_vector (unsigned (n823_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  -- rtl/sagnac_core.vhd:61:7
  n328_o <= n927_o when n314_o = '0' else counts;
  n329_o <= n305_o (0);
  -- rtl/sagnac_core.vhd:61:7
  n330_o <= n329_o when n314_o = '0' else '1';
  n331_o <= n305_o (7 downto 1);
  n332_o <= n331_o & n330_o;
  -- rtl/sagnac_core.vhd:127:24
  n333_o <= item_kind (1 downto 0);  --  trunc
  -- rtl/sagnac_core.vhd:61:18
  n339_o <= n328_o (127 downto 64);
  -- rtl/sagnac_core.vhd:61:21
  n341_o <= '1' when n339_o = "1111111111111111111111111111111111111111111111111111111111111111" else '0';
  -- rtl/sagnac_core.vhd:62:33
  n343_o <= n328_o (127 downto 64);
  -- rtl/sagnac_core.vhd:62:36
  n345_o <= std_logic_vector (unsigned (n343_o) + unsigned'("0000000000000000000000000000000000000000000000000000000000000001"));
  n346_o <= counts (127 downto 64);
  n347_o <= n927_o (127 downto 64);
  -- rtl/sagnac_core.vhd:61:7
  n348_o <= n347_o when n314_o = '0' else n346_o;
  -- rtl/sagnac_core.vhd:61:7
  n349_o <= n345_o when n341_o = '0' else n348_o;
  n350_o <= n332_o (0);
  -- rtl/sagnac_core.vhd:61:7
  n351_o <= n350_o when n341_o = '0' else '1';
  n352_o <= counts (63 downto 0);
  n353_o <= n927_o (63 downto 0);
  -- rtl/sagnac_core.vhd:61:7
  n354_o <= n353_o when n314_o = '0' else n352_o;
  n355_o <= counts (1535 downto 128);
  n356_o <= n927_o (1535 downto 128);
  -- rtl/sagnac_core.vhd:61:7
  n357_o <= n356_o when n314_o = '0' else n355_o;
  n358_o <= n357_o & n349_o & n354_o;
  n359_o <= n332_o (7 downto 1);
  n360_o <= n359_o & n351_o;
  -- rtl/sagnac_core.vhd:127:17
  n362_o <= repeated when n933_o = '0' else '1';
  -- rtl/sagnac_core.vhd:127:17
  n363_o <= n328_o when n933_o = '0' else n358_o;
  -- rtl/sagnac_core.vhd:127:17
  n364_o <= n332_o when n933_o = '0' else n360_o;
  -- rtl/sagnac_core.vhd:130:21
  n365_o <= item_kind (1 downto 0);  --  trunc
  -- rtl/sagnac_core.vhd:124:15
  n369_o <= n950_o when n295_o = '0' else mask;
  -- rtl/sagnac_core.vhd:124:15
  n370_o <= n362_o when n295_o = '0' else repeated;
  -- rtl/sagnac_core.vhd:124:15
  n371_o <= n363_o when n295_o = '0' else counts;
  n372_o <= n364_o (4 downto 0);
  n373_o <= flags (1 downto 0);
  n374_o <= flags (4 downto 3);
  n375_o <= n374_o & n47_o & n373_o;
  -- rtl/sagnac_core.vhd:124:15
  n376_o <= n372_o when n295_o = '0' else n375_o;
  n377_o <= n364_o (5);
  -- rtl/sagnac_core.vhd:124:15
  n378_o <= n377_o when n295_o = '0' else '1';
  n379_o <= n364_o (7 downto 6);
  n380_o <= flags (7);
  n381_o <= n380_o & n50_o;
  -- rtl/sagnac_core.vhd:124:15
  n382_o <= n379_o when n295_o = '0' else n381_o;
  -- rtl/sagnac_core.vhd:119:13
  n384_o <= "001" when n287_o = '0' else n291_o;
  -- rtl/sagnac_core.vhd:119:13
  n385_o <= n369_o when n287_o = '0' else mask;
  -- rtl/sagnac_core.vhd:119:13
  n386_o <= n370_o when n287_o = '0' else repeated;
  -- rtl/sagnac_core.vhd:119:13
  n387_o <= n371_o when n287_o = '0' else counts;
  n388_o <= n382_o & n378_o & n376_o;
  n389_o <= flags (1 downto 0);
  n390_o <= flags (5 downto 3);
  n391_o <= flags (7);
  n392_o <= n391_o & n50_o & n390_o & n47_o & n389_o;
  -- rtl/sagnac_core.vhd:119:13
  n393_o <= n388_o when n287_o = '0' else n392_o;
  -- rtl/sagnac_core.vhd:118:11
  n396_o <= '1' when state = "011" else '0';
  n397_o <= flags (1 downto 0);
  n398_o <= flags (5 downto 3);
  n399_o <= flags (7);
  n400_o <= n399_o & n50_o & n398_o & n47_o & n397_o;
  -- rtl/sagnac_core.vhd:134:11
  n402_o <= '1' when state = "100" else '0';
  -- rtl/sagnac_core.vhd:136:11
  n404_o <= '1' when state = "101" else '0';
  n405_o <= n404_o & n402_o & n396_o & n285_o & n148_o & n104_o;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n408_o <=
    state when "100000",
    "101" when "010000",
    n384_o when "001000",
    n271_o when "000100",
    n137_o when "000010",
    n83_o when "000001",
    "XXX" when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n410_o <=
    shadow when "100000",
    counts when "010000",
    shadow when "001000",
    shadow when "000100",
    shadow when "000010",
    shadow when "000001",
    (1535 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n412_o <=
    shadow_flags when "100000",
    n400_o when "010000",
    shadow_flags when "001000",
    shadow_flags when "000100",
    shadow_flags when "000010",
    shadow_flags when "000001",
    "XXXXXXXX" when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n414_o <=
    run_start when "100000",
    run_start when "010000",
    run_start when "001000",
    run_start when "000100",
    run_start when "000010",
    n84_o when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n416_o <=
    run_stop when "100000",
    run_stop when "010000",
    run_stop when "001000",
    run_stop when "000100",
    run_stop when "000010",
    n85_o when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n418_o <=
    bin_start when "100000",
    bin_start when "010000",
    bin_start when "001000",
    n272_o when "000100",
    bin_start when "000010",
    n86_o when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n420_o <=
    bin_end when "100000",
    bin_end when "010000",
    bin_end when "001000",
    n269_o when "000100",
    bin_end when "000010",
    n87_o when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n422_o <=
    last_time when "100000",
    last_time when "010000",
    last_time when "001000",
    last_time when "000100",
    n138_o when "000010",
    n88_o when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n424_o <=
    item_time when "100000",
    item_time when "010000",
    item_time when "001000",
    item_time when "000100",
    n139_o when "000010",
    item_time when "000001",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n426_o <=
    item_kind when "100000",
    item_kind when "010000",
    item_kind when "001000",
    item_kind when "000100",
    n140_o when "000010",
    item_kind when "000001",
    "XXX" when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n428_o <=
    mask when "100000",
    mask when "010000",
    n385_o when "001000",
    n275_o when "000100",
    mask when "000010",
    n90_o when "000001",
    "XXXX" when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n430_o <=
    repeated when "100000",
    repeated when "010000",
    n386_o when "001000",
    n277_o when "000100",
    repeated when "000010",
    n92_o when "000001",
    'X' when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n432_o <=
    calibration when "100000",
    calibration when "010000",
    calibration when "001000",
    calibration when "000100",
    calibration when "000010",
    n93_o when "000001",
    (31 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n434_o <=
    setting when "100000",
    setting when "010000",
    setting when "001000",
    setting when "000100",
    setting when "000010",
    n94_o when "000001",
    "XX" when others;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n436_o <=
    counts when "100000",
    counts when "010000",
    n387_o when "001000",
    n278_o when "000100",
    counts when "000010",
    n96_o when "000001",
    (1535 downto 0 => 'X') when others;
  n437_o <= n102_o (0);
  n438_o <= n283_o (0);
  n439_o <= n393_o (0);
  n440_o <= flags (0);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n442_o <=
    n440_o when "100000",
    n440_o when "010000",
    n439_o when "001000",
    n438_o when "000100",
    n440_o when "000010",
    n437_o when "000001",
    'X' when others;
  n443_o <= n102_o (1);
  n444_o <= n283_o (1);
  n445_o <= n393_o (1);
  n446_o <= flags (1);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n448_o <=
    n446_o when "100000",
    n446_o when "010000",
    n445_o when "001000",
    n444_o when "000100",
    n142_o when "000010",
    n443_o when "000001",
    'X' when others;
  n449_o <= n102_o (2);
  n450_o <= n283_o (2);
  n451_o <= n393_o (2);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n453_o <=
    n47_o when "100000",
    n47_o when "010000",
    n451_o when "001000",
    n450_o when "000100",
    n47_o when "000010",
    n449_o when "000001",
    'X' when others;
  n454_o <= n102_o (3);
  n455_o <= n283_o (3);
  n456_o <= n393_o (3);
  n457_o <= flags (3);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n459_o <=
    n457_o when "100000",
    n457_o when "010000",
    n456_o when "001000",
    n455_o when "000100",
    n144_o when "000010",
    n454_o when "000001",
    'X' when others;
  n460_o <= n102_o (4);
  n461_o <= n283_o (4);
  n462_o <= n393_o (4);
  n463_o <= flags (4);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n465_o <=
    n463_o when "100000",
    n463_o when "010000",
    n462_o when "001000",
    n461_o when "000100",
    n463_o when "000010",
    n460_o when "000001",
    'X' when others;
  n466_o <= n102_o (5);
  n467_o <= n283_o (5);
  n468_o <= n393_o (5);
  n469_o <= flags (5);
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n471_o <=
    n469_o when "100000",
    n469_o when "010000",
    n468_o when "001000",
    n467_o when "000100",
    n136_o when "000010",
    n466_o when "000001",
    'X' when others;
  n472_o <= n102_o (7 downto 6);
  n473_o <= n283_o (7 downto 6);
  n474_o <= n393_o (7 downto 6);
  n475_o <= flags (7);
  n476_o <= n475_o & n50_o;
  -- rtl/sagnac_core.vhd:80:9
  with n405_o select n478_o <=
    n476_o when "100000",
    n476_o when "010000",
    n474_o when "001000",
    n473_o when "000100",
    n476_o when "000010",
    n472_o when "000001",
    "XX" when others;
  -- rtl/sagnac_core.vhd:67:7
  n482_o <= n408_o when wrap_reset = '0' else "000";
  -- rtl/sagnac_core.vhd:67:7
  n484_o <= n410_o when wrap_reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n486_o <= n412_o when wrap_reset = '0' else "00000000";
  -- rtl/sagnac_core.vhd:67:7
  n488_o <= n414_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n490_o <= n416_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n492_o <= n418_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n494_o <= n420_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n496_o <= n422_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n498_o <= n424_o when wrap_reset = '0' else "0000000000000000000000000000000000000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n500_o <= n426_o when wrap_reset = '0' else "000";
  -- rtl/sagnac_core.vhd:67:7
  n502_o <= n428_o when wrap_reset = '0' else "0000";
  -- rtl/sagnac_core.vhd:67:7
  n504_o <= n430_o when wrap_reset = '0' else '0';
  -- rtl/sagnac_core.vhd:67:7
  n506_o <= n432_o when wrap_reset = '0' else "00000000000000000000000000000000";
  -- rtl/sagnac_core.vhd:67:7
  n508_o <= n434_o when wrap_reset = '0' else "00";
  -- rtl/sagnac_core.vhd:67:7
  n510_o <= n436_o when wrap_reset = '0' else "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
  n511_o <= n478_o & n471_o & n465_o & n459_o & n453_o & n448_o & n442_o;
  -- rtl/sagnac_core.vhd:67:7
  n513_o <= n511_o when wrap_reset = '0' else "00000000";
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n535_q <= n482_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n536_q <= n510_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n537_q <= n484_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n538_q <= n513_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n539_q <= n486_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n540_q <= n488_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n541_q <= n490_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n542_q <= n492_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n543_q <= n494_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n544_q <= n496_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n545_q <= n498_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n546_q <= n500_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n547_q <= n502_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n548_q <= n504_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n549_q <= n506_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:65:5
  process (wrap_clk)
  begin
    if rising_edge (wrap_clk) then
      n550_q <= n508_o;
    end if;
  end process;
  -- rtl/sagnac_core.vhd:25:5
  n552_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:24:5
  n553_o <= counts (127 downto 64);
  -- rtl/sagnac_core.vhd:23:24
  n554_o <= counts (191 downto 128);
  -- rtl/sagnac_core.vhd:23:5
  n555_o <= counts (255 downto 192);
  -- rtl/sagnac_core.vhd:22:5
  n556_o <= counts (319 downto 256);
  -- rtl/sagnac_core.vhd:21:5
  n557_o <= counts (383 downto 320);
  -- rtl/sagnac_core.vhd:20:5
  n558_o <= counts (447 downto 384);
  -- rtl/sagnac_core.vhd:15:30
  n559_o <= counts (511 downto 448);
  -- rtl/sagnac_core.vhd:65:5
  n560_o <= counts (575 downto 512);
  n561_o <= counts (639 downto 576);
  -- rtl/sagnac_core.vhd:65:5
  n562_o <= counts (703 downto 640);
  -- rtl/sagnac_core.vhd:65:5
  n563_o <= counts (767 downto 704);
  -- rtl/sagnac_core.vhd:67:7
  n564_o <= counts (831 downto 768);
  -- rtl/sagnac_core.vhd:80:9
  n565_o <= counts (895 downto 832);
  n566_o <= counts (959 downto 896);
  -- rtl/sagnac_core.vhd:119:13
  n567_o <= counts (1023 downto 960);
  -- rtl/sagnac_core.vhd:57:15
  n568_o <= counts (1087 downto 1024);
  -- rtl/sagnac_core.vhd:57:15
  n569_o <= counts (1151 downto 1088);
  -- rtl/sagnac_core.vhd:57:15
  n570_o <= counts (1215 downto 1152);
  -- rtl/sagnac_core.vhd:57:15
  n571_o <= counts (1279 downto 1216);
  -- rtl/sagnac_core.vhd:123:24
  n572_o <= counts (1343 downto 1280);
  -- rtl/sagnac_core.vhd:57:15
  n573_o <= counts (1407 downto 1344);
  -- rtl/sagnac_core.vhd:57:15
  n574_o <= counts (1471 downto 1408);
  -- rtl/sagnac_core.vhd:57:15
  n575_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:61:18
  n576_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n576_o select n577_o <=
    n552_o when "00",
    n553_o when "01",
    n554_o when "10",
    n555_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n578_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n578_o select n579_o <=
    n556_o when "00",
    n557_o when "01",
    n558_o when "10",
    n559_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n580_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n580_o select n581_o <=
    n560_o when "00",
    n561_o when "01",
    n562_o when "10",
    n563_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n582_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n582_o select n583_o <=
    n564_o when "00",
    n565_o when "01",
    n566_o when "10",
    n567_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n584_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n584_o select n585_o <=
    n568_o when "00",
    n569_o when "01",
    n570_o when "10",
    n571_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n586_o <= n162_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n586_o select n587_o <=
    n572_o when "00",
    n573_o when "01",
    n574_o when "10",
    n575_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n588_o <= n162_o (3 downto 2);
  -- rtl/sagnac_core.vhd:61:18
  with n588_o select n589_o <=
    n577_o when "00",
    n579_o when "01",
    n581_o when "10",
    n583_o when "11",
    (63 downto 0 => 'X') when others;
  n590_o <= n162_o (2);
  -- rtl/sagnac_core.vhd:61:18
  n591_o <= n585_o when n590_o = '0' else n587_o;
  -- rtl/sagnac_core.vhd:61:18
  n592_o <= n162_o (4);
  -- rtl/sagnac_core.vhd:61:18
  n593_o <= n589_o when n592_o = '0' else n591_o;
  -- rtl/sagnac_core.vhd:61:19
  n594_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  n595_o <= counts (127 downto 64);
  n596_o <= counts (191 downto 128);
  n597_o <= counts (255 downto 192);
  n598_o <= counts (319 downto 256);
  n599_o <= counts (383 downto 320);
  n600_o <= counts (447 downto 384);
  n601_o <= counts (511 downto 448);
  n602_o <= counts (575 downto 512);
  n603_o <= counts (639 downto 576);
  n604_o <= counts (703 downto 640);
  n605_o <= counts (767 downto 704);
  n606_o <= counts (831 downto 768);
  n607_o <= counts (895 downto 832);
  n608_o <= counts (959 downto 896);
  n609_o <= counts (1023 downto 960);
  n610_o <= counts (1087 downto 1024);
  n611_o <= counts (1151 downto 1088);
  n612_o <= counts (1215 downto 1152);
  n613_o <= counts (1279 downto 1216);
  n614_o <= counts (1343 downto 1280);
  n615_o <= counts (1407 downto 1344);
  n616_o <= counts (1471 downto 1408);
  n617_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:62:33
  n618_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n618_o select n619_o <=
    n594_o when "00",
    n595_o when "01",
    n596_o when "10",
    n597_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n620_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n620_o select n621_o <=
    n598_o when "00",
    n599_o when "01",
    n600_o when "10",
    n601_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n622_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n622_o select n623_o <=
    n602_o when "00",
    n603_o when "01",
    n604_o when "10",
    n605_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n624_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n624_o select n625_o <=
    n606_o when "00",
    n607_o when "01",
    n608_o when "10",
    n609_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n626_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n626_o select n627_o <=
    n610_o when "00",
    n611_o when "01",
    n612_o when "10",
    n613_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n628_o <= n174_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n628_o select n629_o <=
    n614_o when "00",
    n615_o when "01",
    n616_o when "10",
    n617_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n630_o <= n174_o (3 downto 2);
  -- rtl/sagnac_core.vhd:62:33
  with n630_o select n631_o <=
    n619_o when "00",
    n621_o when "01",
    n623_o when "10",
    n625_o when "11",
    (63 downto 0 => 'X') when others;
  n632_o <= n174_o (2);
  -- rtl/sagnac_core.vhd:62:33
  n633_o <= n627_o when n632_o = '0' else n629_o;
  -- rtl/sagnac_core.vhd:62:33
  n634_o <= n174_o (4);
  -- rtl/sagnac_core.vhd:62:33
  n635_o <= n631_o when n634_o = '0' else n633_o;
  -- rtl/sagnac_core.vhd:62:12
  n636_o <= n170_o (4);
  -- rtl/sagnac_core.vhd:62:12
  n637_o <= not n636_o;
  -- rtl/sagnac_core.vhd:62:12
  n638_o <= n170_o (3);
  -- rtl/sagnac_core.vhd:62:12
  n639_o <= not n638_o;
  -- rtl/sagnac_core.vhd:62:12
  n640_o <= n637_o and n639_o;
  -- rtl/sagnac_core.vhd:62:12
  n641_o <= n637_o and n638_o;
  -- rtl/sagnac_core.vhd:62:12
  n642_o <= n636_o and n639_o;
  -- rtl/sagnac_core.vhd:62:12
  n643_o <= n170_o (2);
  -- rtl/sagnac_core.vhd:62:12
  n644_o <= not n643_o;
  -- rtl/sagnac_core.vhd:62:12
  n645_o <= n640_o and n644_o;
  -- rtl/sagnac_core.vhd:62:12
  n646_o <= n640_o and n643_o;
  -- rtl/sagnac_core.vhd:62:12
  n647_o <= n641_o and n644_o;
  -- rtl/sagnac_core.vhd:62:12
  n648_o <= n641_o and n643_o;
  -- rtl/sagnac_core.vhd:62:12
  n649_o <= n642_o and n644_o;
  -- rtl/sagnac_core.vhd:62:12
  n650_o <= n642_o and n643_o;
  -- rtl/sagnac_core.vhd:62:12
  n651_o <= n170_o (1);
  -- rtl/sagnac_core.vhd:62:12
  n652_o <= not n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n653_o <= n645_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n654_o <= n645_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n655_o <= n646_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n656_o <= n646_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n657_o <= n647_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n658_o <= n647_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n659_o <= n648_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n660_o <= n648_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n661_o <= n649_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n662_o <= n649_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n663_o <= n650_o and n652_o;
  -- rtl/sagnac_core.vhd:62:12
  n664_o <= n650_o and n651_o;
  -- rtl/sagnac_core.vhd:62:12
  n665_o <= n170_o (0);
  -- rtl/sagnac_core.vhd:62:12
  n666_o <= not n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n667_o <= n653_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n668_o <= n653_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n669_o <= n654_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n670_o <= n654_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n671_o <= n655_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n672_o <= n655_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n673_o <= n656_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n674_o <= n656_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n675_o <= n657_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n676_o <= n657_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n677_o <= n658_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n678_o <= n658_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n679_o <= n659_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n680_o <= n659_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n681_o <= n660_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n682_o <= n660_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n683_o <= n661_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n684_o <= n661_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n685_o <= n662_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n686_o <= n662_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n687_o <= n663_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n688_o <= n663_o and n665_o;
  -- rtl/sagnac_core.vhd:62:12
  n689_o <= n664_o and n666_o;
  -- rtl/sagnac_core.vhd:62:12
  n690_o <= n664_o and n665_o;
  n691_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:62:12
  n692_o <= n691_o when n667_o = '0' else n178_o;
  n693_o <= counts (127 downto 64);
  -- rtl/sagnac_core.vhd:62:12
  n694_o <= n693_o when n668_o = '0' else n178_o;
  n695_o <= counts (191 downto 128);
  -- rtl/sagnac_core.vhd:62:12
  n696_o <= n695_o when n669_o = '0' else n178_o;
  n697_o <= counts (255 downto 192);
  -- rtl/sagnac_core.vhd:62:12
  n698_o <= n697_o when n670_o = '0' else n178_o;
  n699_o <= counts (319 downto 256);
  -- rtl/sagnac_core.vhd:62:12
  n700_o <= n699_o when n671_o = '0' else n178_o;
  n701_o <= counts (383 downto 320);
  -- rtl/sagnac_core.vhd:62:12
  n702_o <= n701_o when n672_o = '0' else n178_o;
  n703_o <= counts (447 downto 384);
  -- rtl/sagnac_core.vhd:62:12
  n704_o <= n703_o when n673_o = '0' else n178_o;
  n705_o <= counts (511 downto 448);
  -- rtl/sagnac_core.vhd:62:12
  n706_o <= n705_o when n674_o = '0' else n178_o;
  n707_o <= counts (575 downto 512);
  -- rtl/sagnac_core.vhd:62:12
  n708_o <= n707_o when n675_o = '0' else n178_o;
  n709_o <= counts (639 downto 576);
  -- rtl/sagnac_core.vhd:62:12
  n710_o <= n709_o when n676_o = '0' else n178_o;
  n711_o <= counts (703 downto 640);
  -- rtl/sagnac_core.vhd:62:12
  n712_o <= n711_o when n677_o = '0' else n178_o;
  n713_o <= counts (767 downto 704);
  -- rtl/sagnac_core.vhd:62:12
  n714_o <= n713_o when n678_o = '0' else n178_o;
  n715_o <= counts (831 downto 768);
  -- rtl/sagnac_core.vhd:62:12
  n716_o <= n715_o when n679_o = '0' else n178_o;
  n717_o <= counts (895 downto 832);
  -- rtl/sagnac_core.vhd:62:12
  n718_o <= n717_o when n680_o = '0' else n178_o;
  n719_o <= counts (959 downto 896);
  -- rtl/sagnac_core.vhd:62:12
  n720_o <= n719_o when n681_o = '0' else n178_o;
  n721_o <= counts (1023 downto 960);
  -- rtl/sagnac_core.vhd:62:12
  n722_o <= n721_o when n682_o = '0' else n178_o;
  n723_o <= counts (1087 downto 1024);
  -- rtl/sagnac_core.vhd:62:12
  n724_o <= n723_o when n683_o = '0' else n178_o;
  n725_o <= counts (1151 downto 1088);
  -- rtl/sagnac_core.vhd:62:12
  n726_o <= n725_o when n684_o = '0' else n178_o;
  n727_o <= counts (1215 downto 1152);
  -- rtl/sagnac_core.vhd:62:12
  n728_o <= n727_o when n685_o = '0' else n178_o;
  n729_o <= counts (1279 downto 1216);
  -- rtl/sagnac_core.vhd:62:12
  n730_o <= n729_o when n686_o = '0' else n178_o;
  n731_o <= counts (1343 downto 1280);
  -- rtl/sagnac_core.vhd:62:12
  n732_o <= n731_o when n687_o = '0' else n178_o;
  n733_o <= counts (1407 downto 1344);
  -- rtl/sagnac_core.vhd:62:12
  n734_o <= n733_o when n688_o = '0' else n178_o;
  n735_o <= counts (1471 downto 1408);
  -- rtl/sagnac_core.vhd:62:12
  n736_o <= n735_o when n689_o = '0' else n178_o;
  n737_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:62:12
  n738_o <= n737_o when n690_o = '0' else n178_o;
  n739_o <= n738_o & n736_o & n734_o & n732_o & n730_o & n728_o & n726_o & n724_o & n722_o & n720_o & n718_o & n716_o & n714_o & n712_o & n710_o & n708_o & n706_o & n704_o & n702_o & n700_o & n698_o & n696_o & n694_o & n692_o;
  -- rtl/sagnac_core.vhd:62:21
  n740_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:62:12
  n741_o <= counts (127 downto 64);
  n742_o <= counts (191 downto 128);
  n743_o <= counts (255 downto 192);
  n744_o <= counts (319 downto 256);
  n745_o <= counts (383 downto 320);
  n746_o <= counts (447 downto 384);
  n747_o <= counts (511 downto 448);
  n748_o <= counts (575 downto 512);
  n749_o <= counts (639 downto 576);
  n750_o <= counts (703 downto 640);
  n751_o <= counts (767 downto 704);
  n752_o <= counts (831 downto 768);
  n753_o <= counts (895 downto 832);
  n754_o <= counts (959 downto 896);
  n755_o <= counts (1023 downto 960);
  n756_o <= counts (1087 downto 1024);
  n757_o <= counts (1151 downto 1088);
  n758_o <= counts (1215 downto 1152);
  n759_o <= counts (1279 downto 1216);
  n760_o <= counts (1343 downto 1280);
  n761_o <= counts (1407 downto 1344);
  n762_o <= counts (1471 downto 1408);
  n763_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:61:18
  n764_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n764_o select n765_o <=
    n740_o when "00",
    n741_o when "01",
    n742_o when "10",
    n743_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n766_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n766_o select n767_o <=
    n744_o when "00",
    n745_o when "01",
    n746_o when "10",
    n747_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n768_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n768_o select n769_o <=
    n748_o when "00",
    n749_o when "01",
    n750_o when "10",
    n751_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n770_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n770_o select n771_o <=
    n752_o when "00",
    n753_o when "01",
    n754_o when "10",
    n755_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n772_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n772_o select n773_o <=
    n756_o when "00",
    n757_o when "01",
    n758_o when "10",
    n759_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n774_o <= n310_o (1 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  with n774_o select n775_o <=
    n760_o when "00",
    n761_o when "01",
    n762_o when "10",
    n763_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:61:18
  n776_o <= n310_o (3 downto 2);
  -- rtl/sagnac_core.vhd:61:18
  with n776_o select n777_o <=
    n765_o when "00",
    n767_o when "01",
    n769_o when "10",
    n771_o when "11",
    (63 downto 0 => 'X') when others;
  n778_o <= n310_o (2);
  -- rtl/sagnac_core.vhd:61:18
  n779_o <= n773_o when n778_o = '0' else n775_o;
  -- rtl/sagnac_core.vhd:61:18
  n780_o <= n310_o (4);
  -- rtl/sagnac_core.vhd:61:18
  n781_o <= n777_o when n780_o = '0' else n779_o;
  -- rtl/sagnac_core.vhd:61:19
  n782_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:61:18
  n783_o <= counts (127 downto 64);
  n784_o <= counts (191 downto 128);
  n785_o <= counts (255 downto 192);
  n786_o <= counts (319 downto 256);
  n787_o <= counts (383 downto 320);
  n788_o <= counts (447 downto 384);
  n789_o <= counts (511 downto 448);
  n790_o <= counts (575 downto 512);
  n791_o <= counts (639 downto 576);
  n792_o <= counts (703 downto 640);
  n793_o <= counts (767 downto 704);
  n794_o <= counts (831 downto 768);
  n795_o <= counts (895 downto 832);
  n796_o <= counts (959 downto 896);
  n797_o <= counts (1023 downto 960);
  n798_o <= counts (1087 downto 1024);
  n799_o <= counts (1151 downto 1088);
  n800_o <= counts (1215 downto 1152);
  n801_o <= counts (1279 downto 1216);
  n802_o <= counts (1343 downto 1280);
  n803_o <= counts (1407 downto 1344);
  n804_o <= counts (1471 downto 1408);
  n805_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:62:33
  n806_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n806_o select n807_o <=
    n782_o when "00",
    n783_o when "01",
    n784_o when "10",
    n785_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n808_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n808_o select n809_o <=
    n786_o when "00",
    n787_o when "01",
    n788_o when "10",
    n789_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n810_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n810_o select n811_o <=
    n790_o when "00",
    n791_o when "01",
    n792_o when "10",
    n793_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n812_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n812_o select n813_o <=
    n794_o when "00",
    n795_o when "01",
    n796_o when "10",
    n797_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n814_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n814_o select n815_o <=
    n798_o when "00",
    n799_o when "01",
    n800_o when "10",
    n801_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n816_o <= n322_o (1 downto 0);
  -- rtl/sagnac_core.vhd:62:33
  with n816_o select n817_o <=
    n802_o when "00",
    n803_o when "01",
    n804_o when "10",
    n805_o when "11",
    (63 downto 0 => 'X') when others;
  -- rtl/sagnac_core.vhd:62:33
  n818_o <= n322_o (3 downto 2);
  -- rtl/sagnac_core.vhd:62:33
  with n818_o select n819_o <=
    n807_o when "00",
    n809_o when "01",
    n811_o when "10",
    n813_o when "11",
    (63 downto 0 => 'X') when others;
  n820_o <= n322_o (2);
  -- rtl/sagnac_core.vhd:62:33
  n821_o <= n815_o when n820_o = '0' else n817_o;
  -- rtl/sagnac_core.vhd:62:33
  n822_o <= n322_o (4);
  -- rtl/sagnac_core.vhd:62:33
  n823_o <= n819_o when n822_o = '0' else n821_o;
  -- rtl/sagnac_core.vhd:62:12
  n824_o <= n318_o (4);
  -- rtl/sagnac_core.vhd:62:12
  n825_o <= not n824_o;
  -- rtl/sagnac_core.vhd:62:12
  n826_o <= n318_o (3);
  -- rtl/sagnac_core.vhd:62:12
  n827_o <= not n826_o;
  -- rtl/sagnac_core.vhd:62:12
  n828_o <= n825_o and n827_o;
  -- rtl/sagnac_core.vhd:62:12
  n829_o <= n825_o and n826_o;
  -- rtl/sagnac_core.vhd:62:12
  n830_o <= n824_o and n827_o;
  -- rtl/sagnac_core.vhd:62:12
  n831_o <= n318_o (2);
  -- rtl/sagnac_core.vhd:62:12
  n832_o <= not n831_o;
  -- rtl/sagnac_core.vhd:62:12
  n833_o <= n828_o and n832_o;
  -- rtl/sagnac_core.vhd:62:12
  n834_o <= n828_o and n831_o;
  -- rtl/sagnac_core.vhd:62:12
  n835_o <= n829_o and n832_o;
  -- rtl/sagnac_core.vhd:62:12
  n836_o <= n829_o and n831_o;
  -- rtl/sagnac_core.vhd:62:12
  n837_o <= n830_o and n832_o;
  -- rtl/sagnac_core.vhd:62:12
  n838_o <= n830_o and n831_o;
  -- rtl/sagnac_core.vhd:62:12
  n839_o <= n318_o (1);
  -- rtl/sagnac_core.vhd:62:12
  n840_o <= not n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n841_o <= n833_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n842_o <= n833_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n843_o <= n834_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n844_o <= n834_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n845_o <= n835_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n846_o <= n835_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n847_o <= n836_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n848_o <= n836_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n849_o <= n837_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n850_o <= n837_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n851_o <= n838_o and n840_o;
  -- rtl/sagnac_core.vhd:62:12
  n852_o <= n838_o and n839_o;
  -- rtl/sagnac_core.vhd:62:12
  n853_o <= n318_o (0);
  -- rtl/sagnac_core.vhd:62:12
  n854_o <= not n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n855_o <= n841_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n856_o <= n841_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n857_o <= n842_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n858_o <= n842_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n859_o <= n843_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n860_o <= n843_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n861_o <= n844_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n862_o <= n844_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n863_o <= n845_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n864_o <= n845_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n865_o <= n846_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n866_o <= n846_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n867_o <= n847_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n868_o <= n847_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n869_o <= n848_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n870_o <= n848_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n871_o <= n849_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n872_o <= n849_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n873_o <= n850_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n874_o <= n850_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n875_o <= n851_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n876_o <= n851_o and n853_o;
  -- rtl/sagnac_core.vhd:62:12
  n877_o <= n852_o and n854_o;
  -- rtl/sagnac_core.vhd:62:12
  n878_o <= n852_o and n853_o;
  n879_o <= counts (63 downto 0);
  -- rtl/sagnac_core.vhd:62:12
  n880_o <= n879_o when n855_o = '0' else n326_o;
  n881_o <= counts (127 downto 64);
  -- rtl/sagnac_core.vhd:62:12
  n882_o <= n881_o when n856_o = '0' else n326_o;
  n883_o <= counts (191 downto 128);
  -- rtl/sagnac_core.vhd:62:12
  n884_o <= n883_o when n857_o = '0' else n326_o;
  n885_o <= counts (255 downto 192);
  -- rtl/sagnac_core.vhd:62:12
  n886_o <= n885_o when n858_o = '0' else n326_o;
  n887_o <= counts (319 downto 256);
  -- rtl/sagnac_core.vhd:62:12
  n888_o <= n887_o when n859_o = '0' else n326_o;
  n889_o <= counts (383 downto 320);
  -- rtl/sagnac_core.vhd:62:12
  n890_o <= n889_o when n860_o = '0' else n326_o;
  n891_o <= counts (447 downto 384);
  -- rtl/sagnac_core.vhd:62:12
  n892_o <= n891_o when n861_o = '0' else n326_o;
  n893_o <= counts (511 downto 448);
  -- rtl/sagnac_core.vhd:62:12
  n894_o <= n893_o when n862_o = '0' else n326_o;
  n895_o <= counts (575 downto 512);
  -- rtl/sagnac_core.vhd:62:12
  n896_o <= n895_o when n863_o = '0' else n326_o;
  n897_o <= counts (639 downto 576);
  -- rtl/sagnac_core.vhd:62:12
  n898_o <= n897_o when n864_o = '0' else n326_o;
  n899_o <= counts (703 downto 640);
  -- rtl/sagnac_core.vhd:62:12
  n900_o <= n899_o when n865_o = '0' else n326_o;
  n901_o <= counts (767 downto 704);
  -- rtl/sagnac_core.vhd:62:12
  n902_o <= n901_o when n866_o = '0' else n326_o;
  n903_o <= counts (831 downto 768);
  -- rtl/sagnac_core.vhd:62:12
  n904_o <= n903_o when n867_o = '0' else n326_o;
  n905_o <= counts (895 downto 832);
  -- rtl/sagnac_core.vhd:62:12
  n906_o <= n905_o when n868_o = '0' else n326_o;
  n907_o <= counts (959 downto 896);
  -- rtl/sagnac_core.vhd:62:12
  n908_o <= n907_o when n869_o = '0' else n326_o;
  n909_o <= counts (1023 downto 960);
  -- rtl/sagnac_core.vhd:62:12
  n910_o <= n909_o when n870_o = '0' else n326_o;
  n911_o <= counts (1087 downto 1024);
  -- rtl/sagnac_core.vhd:62:12
  n912_o <= n911_o when n871_o = '0' else n326_o;
  n913_o <= counts (1151 downto 1088);
  -- rtl/sagnac_core.vhd:62:12
  n914_o <= n913_o when n872_o = '0' else n326_o;
  n915_o <= counts (1215 downto 1152);
  -- rtl/sagnac_core.vhd:62:12
  n916_o <= n915_o when n873_o = '0' else n326_o;
  n917_o <= counts (1279 downto 1216);
  -- rtl/sagnac_core.vhd:62:12
  n918_o <= n917_o when n874_o = '0' else n326_o;
  n919_o <= counts (1343 downto 1280);
  -- rtl/sagnac_core.vhd:62:12
  n920_o <= n919_o when n875_o = '0' else n326_o;
  n921_o <= counts (1407 downto 1344);
  -- rtl/sagnac_core.vhd:62:12
  n922_o <= n921_o when n876_o = '0' else n326_o;
  n923_o <= counts (1471 downto 1408);
  -- rtl/sagnac_core.vhd:62:12
  n924_o <= n923_o when n877_o = '0' else n326_o;
  n925_o <= counts (1535 downto 1472);
  -- rtl/sagnac_core.vhd:62:12
  n926_o <= n925_o when n878_o = '0' else n326_o;
  n927_o <= n926_o & n924_o & n922_o & n920_o & n918_o & n916_o & n914_o & n912_o & n910_o & n908_o & n906_o & n904_o & n902_o & n900_o & n898_o & n896_o & n894_o & n892_o & n890_o & n888_o & n886_o & n884_o & n882_o & n880_o;
  -- rtl/sagnac_core.vhd:62:21
  n928_o <= mask (0);
  -- rtl/sagnac_core.vhd:62:12
  n929_o <= mask (1);
  n930_o <= mask (2);
  n931_o <= mask (3);
  -- rtl/sagnac_core.vhd:127:24
  n932_o <= n333_o (1 downto 0);
  -- rtl/sagnac_core.vhd:127:24
  with n932_o select n933_o <=
    n928_o when "00",
    n929_o when "01",
    n930_o when "10",
    n931_o when "11",
    'X' when others;
  -- rtl/sagnac_core.vhd:130:17
  n934_o <= n365_o (1);
  -- rtl/sagnac_core.vhd:130:17
  n935_o <= not n934_o;
  -- rtl/sagnac_core.vhd:130:17
  n936_o <= n365_o (0);
  -- rtl/sagnac_core.vhd:130:17
  n937_o <= not n936_o;
  -- rtl/sagnac_core.vhd:130:17
  n938_o <= n935_o and n937_o;
  -- rtl/sagnac_core.vhd:130:17
  n939_o <= n935_o and n936_o;
  -- rtl/sagnac_core.vhd:130:17
  n940_o <= n934_o and n937_o;
  -- rtl/sagnac_core.vhd:130:17
  n941_o <= n934_o and n936_o;
  n942_o <= mask (0);
  -- rtl/sagnac_core.vhd:130:17
  n943_o <= n942_o when n938_o = '0' else '1';
  n944_o <= mask (1);
  -- rtl/sagnac_core.vhd:130:17
  n945_o <= n944_o when n939_o = '0' else '1';
  n946_o <= mask (2);
  -- rtl/sagnac_core.vhd:130:17
  n947_o <= n946_o when n940_o = '0' else '1';
  n948_o <= mask (3);
  -- rtl/sagnac_core.vhd:130:17
  n949_o <= n948_o when n941_o = '0' else '1';
  n950_o <= n949_o & n947_o & n945_o & n943_o;
end rtl;
