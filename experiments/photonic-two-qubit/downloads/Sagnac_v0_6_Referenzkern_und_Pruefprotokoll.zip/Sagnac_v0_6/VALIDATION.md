# Ausgeführte Validierung v0.6

Die nachfolgenden Resultate stammen aus tatsächlich ausgeführten digitalen
Prüfungen am 11. Oktober 2026. Keine physische Messung wurde durchgeführt.

| Prüfung | Ergebnis |
|---|---|
| VHDL-2008 Analyse/Compilation | PASS |
| 24 RTL-Szenarien | PASS, darunter ein erwarteter Timeout ohne End-Watermark |
| Alle 24 Zähler und Flags pro abschliessendem Szenario gegen unabhängiges Batch-Modell | PASS |
| Python: acht Testmethoden mit Unterfällen | PASS |
| RTL-Snapshot → JSON → Python, gültige synthetische Messung | PASS |
| RTL-Source-Loss → ungültiger Python-Bericht und Exitcode 2 | PASS |
| GHDL-Synthese, Standardparameter | PASS |
| FPGA-Timing/Hardwaremessung | NICHT DURCHGEFÜHRT |
| Optik-, Klebe- und Umweltqualifikation | NICHT DURCHGEFÜHRT |
| Formale vollständige RTL-Verifikation | NICHT DURCHGEFÜHRT |

Die Testbench prüft bei jedem fertigen Snapshot auch dessen Unveränderlichkeit
unter weiteren Ereignis-, Steuer- und Konfigurationsänderungen. Der Treiber hält
Ereignisse unter Rückstau stabil. Nicht erkannt werden können von ihm verschwiegene
physische Erfassungsverluste; dafür ist ein Hardware-Source-Error erforderlich.

## Szenarien

- `all_16_masks`: PASS
- `same_channel_repeat_61`: PASS
- `half_open_boundaries`: PASS
- `equal_timestamps_forward`: PASS
- `equal_timestamps_reverse`: PASS
- `empty_windows`: PASS
- `near_u64_limit`: PASS
- `source_loss`: PASS
- `calibration_mismatch`: PASS
- `nonmonotonic_time`: PASS
- `before_run`: PASS
- `hit_at_stop`: PASS
- `invalid_kind`: PASS
- `counter_saturation`: PASS
- `invalid_zero_duration`: PASS
- `invalid_partial_window`: PASS
- `missing_final_watermark`: PASS_EXPECTED_TIMEOUT
- `random_seed_104729`: PASS
- `random_seed_37`: PASS
- `random_seed_8191`: PASS
- `synthetic_chsh_0`: PASS
- `synthetic_chsh_1`: PASS
- `synthetic_chsh_2`: PASS
- `synthetic_chsh_3`: PASS

## Interpretation

Der 61-Repeat-Test zählt 61 Fenster mit je zwei A+-Ereignissen. Erwartet und
beobachtet: 61 Wiederholungs-Trials, 61 zusätzliche Klicks, 0 Doppelport-Trials.
Das ist eine Zählklassifikation, kein Nachweis der physikalischen Ursache.

Der synthetische CHSH-Fall liefert S_cond = −2.8253650438389006 und
S_all = −1.4125. Für T=−S beträgt die modellbedingte Hoeffding-Untergrenze
im Koinzidenzzweig 2.5025865648002004, über alle Trials 1.1708258744988742.
Beide Berichte behalten physical_quantum_claim=NOT_ASSESSED.

Quellenhashes und Laufumgebung stehen unter `validation/`. Tests sind endlich,
und der GHDL-Syntheseerfolg ist keine Board-Freigabe. Ein Versionslabel ist kein
Ersatz für physische Daten oder unabhängige Reproduktion.
