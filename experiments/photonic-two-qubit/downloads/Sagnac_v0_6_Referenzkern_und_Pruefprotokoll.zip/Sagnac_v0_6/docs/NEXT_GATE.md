# Nächste reale Arbeitsstufe

## Erledigt in dieser Version

Die digitale Schnittstelle ist konsistent definiert und als Referenz umgesetzt.
Synthetische Stimuli, RTL-Zähler und Python-Auswertung sind gemeinsam ausgeführt.
Der Spiegelversuch ist als Strahlstabilitätstest spezifiziert. Keine realen
Quanten- oder Materialmessdaten wurden erzeugt oder behauptet.

## Gate A: Hardware-Messkette definieren

Vor einer FPGA-Anbindung werden konkrete Bauteile und ihre Datenblätter benötigt:

1. FPGA-Board, Takt, Schnittstelle zum Raspberry Pi und verfügbare Eingänge.
2. Vier Einzelphotonendetektoren: Modell, Ausgangspegel/-pulsbreite, Zeitjitter,
   Totzeit, maximale Rate und verfügbare Kalibrierinformationen.
3. Zeitstempelerfassung und Kanal-Merge: gemeinsame Epoche, gemessene Auflösung,
   Offsetkalibrierung, Sortiergrenze, FIFO-Kapazität und Verlustmeldung.
4. Erwartete Zählrate und physisch begründete Fensterbreite; Durchsatzbudget
   einschließlich leerer Fenster und Rückstau.

Aus diesen Daten folgen die konkreten Board-Adapter, der Hosttransport und
die Erfassungsarchitektur. Der aktuelle Kern ist kein fertiges Raspberry-HAT
und keine Timing-Closure für ein beliebiges FPGA.

## Gate B: Einstellbare optische Referenz

Zuerst Quelle und Polarisationsanalysatoren auf einem nachjustierbaren Aufbau
charakterisieren. Zielzustand, Pumpquelle, Kristall, Spektralfilter, Detektoren und
passende Optik für beide Wellenlängen müssen feststehen. Akzeptanz umfasst
Rohdatenintegrität, reproduzierbare Polarisationskorrelationen, Unsicherheitsbudget
und dokumentierte Detektionsannahmen. Hohe Zählraten allein genügen nicht.

Eine temperaturstabile, justierbare Referenz liefert das Toleranzbudget für
Miniaturisierung und Klebung. Vorher bleiben die endgültigen Klebegeometrien
und Fertigungstoleranzen offen. Ein Austausch der Referenzquelle durch die
geklebte Baugruppe darf nicht zugleich die Auswertelogik verändern.

## Gate C: Klebeprozess

MIRROR_TEST.md physisch ausführen; leere Vorlage unter examples ausfüllen.
Zuerst Messstreckenrauschen und Drift quantifizieren, dann drei unabhängige
Prüfkörper screenen. Nur bei ausreichendem Verhältnis zwischen Messunsicherheit
und optischem Toleranzbudget wird die Fertigungsvariante weiterverfolgt.

## Reihenfolge danach

Board-/Detektordaten → Erfassungsadapter und reale Kalibrierung → unveränderte
Rohdatenauswertung am justierbaren Sagnac → optisches Toleranzbudget → Klebeprozess
und Jig-CAD → Umweltqualifikation und unabhängiger Nachbau.

Ein photonischer Zwei-Qubit-Zustandspräparator mit kontrollierter Messung ist
ein sinnvoller erster Quantenbaustein. Universelle Gatter, skalierbarer Speicher
und Fehlerkorrektur werden durch diese Messkette nicht bereitgestellt.
