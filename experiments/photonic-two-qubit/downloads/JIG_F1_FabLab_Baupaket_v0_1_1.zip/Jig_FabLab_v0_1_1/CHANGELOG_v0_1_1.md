# JIG-F1 Dokumentation 0.1.1 / Geometrie 0.1

12.10.2026: Die frühere gemeinsame Druckseite für P02/P03 wurde wegen überlappender Beschriftungen auf zwei Seiten verteilt. 14 statt 13 Seiten; Bohrbilder, Maßstab und CAD-Geometrie unverändert. Die PDF wurde aus dem mitgelieferten Generator neu erzeugt.

Die älteren Modellprüfberichte bleiben als historische Ergebnisse erhalten. Die Veröffentlichung qualifiziert weder einen gebauten Jig noch eine Klebung oder optische Leistung. Preisangaben sind historische Recherchen bzw. Planungsschätzungen vom 11.10.2026.
