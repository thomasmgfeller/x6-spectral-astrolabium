# Photonische Messkette v0.1 — statistische Referenz

Stand: 11. Oktober 2026. Version: 0.1.0.

Dieses Paket implementiert die statistische Auswertung der vier Ergebniskategorien
pro akzeptiertem Herald-Trial. Es enthält vollständigen Python-Quellcode,
synthetische Beispiele, Tests und einen Vorschlag für das Exportformat.
Es enthält keine synthetisierte FPGA-Firmware, keine Hardwaremessungen und keine
validierte AQC-Schaltung. Alle mitgelieferten Daten sind synthetisch.

## Start

Getestet mit Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0.
Die mitgelieferten Versionsbindungen dokumentieren diesen Lauf. Die Installation
auf Raspberry Pi und die dortige Paketverfügbarkeit wurden nicht geprüft.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python photon_stats.py examples/twenty_triples.json --output result.json
python -m unittest -v test_photon_stats
```

Das Skript braucht für die Auswertung weder Netzwerk noch API-Schlüssel.
Die Installation der Abhängigkeiten kann Netzwerkzugriff benötigen.

Exit-Codes: `0` bedingtes statistisches Kriterium erfüllt; `1` nicht nachgewiesen
oder Zahlenbereich nicht unterstützt; `2` ungültige Eingabe beziehungsweise
Dateifehler. `CONDITIONAL_CRITERION_MET` ist keine physikalische Freigabe.
`physical_quantum_claim` bleibt immer `NOT_ASSESSED`.

## 1. Zählmodell

Zu jedem akzeptierten H-Ereignis existieren zwei vorab festgelegte Fenster:

\[
I_A(H)=[t_H+d_A-W_A/2,\ t_H+d_A+W_A/2),
\]

analog für B. Die untere Grenze gehört zum Fenster, die obere nicht.
Zeitoffset, Breite, Kalibrierung und Randbehandlung sind Bestandteil der
versionierten Gerätekonfiguration. Das Python-Skript erhält bereits klassifizierte
Zähler; es kann falsche Fensterzuordnungen nicht nachträglich erkennen.

Pro H wird ermittelt, ob mindestens ein A- beziehungsweise B-Ereignis im eigenen
Fenster liegt. Mehrere Treffer ergeben für den Hauptzähler weiterhin ein einziges
Boolesches Ergebnis. Mehrfachtreffer sollten zusätzlich diagnostiziert werden.

| Kategorie | A | B |
|---|---|---|
| n00 | kein Treffer | kein Treffer |
| n10 | mindestens ein Treffer | kein Treffer |
| n01 | kein Treffer | mindestens ein Treffer |
| n11 | mindestens ein Treffer | mindestens ein Treffer |

`n11` enthält auch zufällige oder instrumentell verursachte Koinzidenzen. Das Wort
"echt" wird ihm nicht automatisch zugeordnet.

\[
N=n_{00}+n_{10}+n_{01}+n_{11},\quad
N_{HA}=n_{10}+n_{11},\quad N_{HB}=n_{01}+n_{11},\quad N_{HAB}=n_{11}.
\]

Keine Dreifach-AND-Zählung: Mit tau=1 ns und Pulsbeginn H=0, A=-0.9, B=0.9 ns
überlappen H/A und H/B, aber nicht H/A/B gemeinsam. Die korrekte Kategorie für
die entsprechenden Herald-Fenster ist dennoch n11.

Die Herald-Auswahl muss vorab festgelegt und unabhängig vom Ergebnis in A und B
sein. Ein vorgeschlagener deterministischer H-only-Sperralgorithmus darf bekannte
überlappende Trials verhindern, beweist aber keine statistische Unabhängigkeit.
Zählverlust durch volle Ereignis-FIFOs ist kein zulässiger Ersatz für diese Regel.

## 2. Statistik und Nachweisgrenze

Unter dem bedingten Modell unabhängiger, identisch verteilter Trials folgen die
vier Kategorien einer Multinomialverteilung. Die einzelnen Marginalzähler sind
binomialverteilt, jedoch untereinander abhängig.

\[
g_{click}=p_{AB}/(p_Ap_B),\qquad
\widehat g_{click}=N_{HAB}N/(N_{HA}N_{HB}).
\]

Das ist zunächst eine bedingte Klickkorrelation. Die Gleichsetzung mit einem
optischen, zeitlich definierten g_h^(2) benötigt das passende Messmodell,
insbesondere für Schwellen-Detektoren, endliche Fenster und Sättigung.

Festgelegt für diese Referenz: alpha=0.05, Projektschwelle=0.5 und je
epsilon=alpha/3 pro einseitiger Grenze. Für k von N Treffern:

\[
L(k,N)=B^{-1}(\epsilon;k,N-k+1)\quad(k>0),\quad L(0,N)=0,
\]

\[
U(k,N)=B^{-1}(1-\epsilon;k+1,N-k)\quad(k<N),\quad U(N,N)=1.
\]

B^-1 bezeichnet das Beta-Quantil. Im Code wird für den oberen Rand die inverse
Überlebensfunktion verwendet. Der Nullereignisfall wird numerisch stabil als
`-expm1(log(epsilon)/N)` ausgewertet; er ist strikt positiv.

\[
g_U=U(N_{HAB},N)/(L(N_{HA},N)L(N_{HB},N)).
\]

Ist ein unterer Nenner null, ist die Schranke unbeschränkt. JSON enthält dann
`null` sowie `upper_bound_unbounded: true`; kein nichtstandardisiertes Infinity.

Abdeckungsargument: Jede der drei ungünstigen Randverletzungen hat unter dem
Binomialmodell Wahrscheinlichkeit höchstens alpha/3. Ihre Vereinigung hat
höchstens alpha. Auf dem verbleibenden Ereignis gilt g_click <= g_U. Das benötigt
keine Unabhängigkeit zwischen den drei Zählern. Die Abdeckung beträgt mindestens
95 Prozent, nicht notwendig exakt 95 Prozent. Die Methode kann konservativ sein.

Die Konfidenzgrenze ist frequentistisch: Sie bezeichnet die Abdeckung des
Verfahrens über Wiederholungen, keine posteriori Wahrscheinlichkeit des festen g.

Die Bezeichnung "exakt" betrifft die Binomialkonstruktion. SciPy verwendet
Gleitkomma-Numerik; es handelt sich nicht um zertifizierte Intervallarithmetik.
Für die automatische Rechnung ist N auf 1..1'000'000'000 begrenzt. Grössere
uint64-Zähler werden exakt eingelesen und weitergegeben, aber ohne automatische
Inferenz (`UNSUPPORTED_NUMERICAL_RANGE`). Nicht nachträglich einen passenden
Teilbereich aussuchen, um diese Grenze zu umgehen.

## 3. Grenzen der Aussage

Die statistische Rechnung prüft weder iid noch korrekte Ereigniserfassung.
Ein Sensor- oder Firmwarefehler, der n11 unterdrückt, kann auch eine kleine obere
Konfidenzgrenze erzeugen. Die physikalische Abnahme braucht deshalb separat:

- kalibrierte Ein- und Mehrkanalerfassung, Zeitauflösung, Totzeiten und Effizienz;
- kontrollierte Untersuchungen von Nachpulsen, Übersprechen und Sättigung;
- festgelegte Behandlung von Drift und Abhängigkeit zwischen Trials;
- eine begründete Zuordnung von Klickstatistik zu optischer Korrelation;
- unabhängigen Nachbau beziehungsweise externe Reproduktion.

Mehrere Zeitversatzfenster sind Diagnostik. Ungleiche Raten können Hinweise auf
Korrelationen, Drift oder unterschiedliche effektive Erfassungszeiten geben.
Sie beweisen keine bestimmte Ursache. Gleiche Raten beweisen keine Unabhängigkeit.
Fenster um +/-100 und +/-200 ns erhalten keine vorgegebene physikalische
Bezeichnung wie "rein thermisch". Falls später Signifikanztests eingebaut werden,
benötigen sie eine definierte Nullhypothese, die gemeinsame Kovarianzstruktur,
Mehrfachtestkontrolle und eine vorab festgelegte Wiederholungsregel.

Diese Version subtrahiert keinen Untergrund. Sie testet die rohe Klickkorrelation.
Das Quellenprotokoll muss reine Dunkelmessung mit geschlossenen Eingängen und
Messung des optischen Hintergrunds unterscheiden. Ein ausgeschalteter Pumplaser
allein garantiert keine reine Dunkelmessung.

Die 1000 s in den Beispielen sind fiktive Metadaten. Eine echte Messdauer wird
vorab aus Pilotdaten und einer Leistungsplanung festgelegt. Wiederholtes Messen
bis zum ersten Bestehen ist nicht durch diese Einzelintervall-Methode abgedeckt.
Ein nicht bestandenes Kriterium ist kein Beweis für klassisches Licht.

## 4. Exportvertrag v0.1 (noch keine Registeradressen)

Ein Export ist ein vollständiger Endsnapshot eines Messlaufs, keine Sammlung
separat gelesener laufender Zähler. Alle uint64-Werte stehen als dezimale Strings
im JSON. Dadurch bleiben auch Zahlen oberhalb 2^53 auf JavaScript-Hosts erhalten.

| Pflichtfeld | Bedeutung |
|---|---|
| schema, data_kind | Formatversion; synthetic oder measurement |
| run_id | eindeutige Laufkennung |
| firmware_id, config_id, calibration_id, protocol_id | zugehörige versionierte Artefakte |
| counting_rule | one-category-per-accepted-herald.v1 |
| stopping_rule | prespecified-fixed-duration |
| prespecified_analysis | erklärte Vorabfestlegung; vom Skript nicht historisch verifizierbar |
| snapshot.sequence_before/after | identische Kennung des eingefrorenen Snapshots |
| exposure.planned_ns/observed_ns | vorher festgelegte und tatsächlich abgeschlossene Akquisitionsdauer |
| counts.n00/n10/n01/n11 | ausschliessliche Ergebniskategorien |
| counts.h_raw/h_accepted/h_rejected_policy | Herald-Bilanz der Zählstufe |
| counts.h_pending | muss beim Endexport null sein |
| flags | atomarer Snapshot, vollständiger Lauf sowie Fehlerzustände |

`h_raw` bedeutet: an der digitalen Ereignisschnittstelle registrierte Heralds.
Es ist keine Behauptung, dass alle physikalischen Pulse erfasst wurden.
Validierte Invarianten:

```
n00 + n10 + n01 + n11 == h_accepted
h_raw == h_accepted + h_rejected_policy
h_pending == 0
sequence_before == sequence_after
observed_ns == planned_ns > 0
```

`h_rejected_policy` darf nur die vorab definierte H-only-Auswahl enthalten.
FIFO-Verluste und Kapazitätsüberschreitungen müssen Fehlerflags setzen und dürfen
nicht als harmlose Auswahl umetikettiert werden. Gleichheit der Sequenzkennungen
allein beweist keine Atomizität; diese ist durch das Snapshot-Protokoll herzustellen.

Der Parser sperrt gemeldete Überläufe, Ereignisverluste, Erfassungsfehler,
Konfigurationswechsel und unvollständige Läufe. Er sperrt fehlende Flags,
doppelte JSON-Schlüssel, falsche Zählertypen und inkonsistente Summen.
Er kann verschwiegene Hardwarefehler oder plausible Datenkorruption nicht erkennen.
Der ausgegebene SHA-256 dokumentiert die analysierten Dateibytes. Er ersetzt weder
eine Transport-CRC noch einen Sendernachweis.

Vorgeschlagener späterer Hardwareablauf:

1. Innerhalb der vorher definierten Zeitspanne Heralds annehmen.
2. Annahme weiterer Heralds am festen Endzeitpunkt stoppen.
3. Bereits offene Haupt- und positive Diagnosefenster vollständig abarbeiten.
   Die notwendige Nachlaufzeit verändert die definierte Herald-Akquisitionsdauer nicht.
4. Alle zugehörigen Zähler, Statuswerte, Konfigurationskennung und Zeitangaben
   atomar in eine Shadow-Bank übernehmen.
5. Snapshot-ID und READY setzen, Shadow-Bank bis zum Host-ACK unverändert halten.
6. Host liest vollständigen Frame mit Länge, Sequenz und vereinbarter CRC;
   Integritätsfehler führen zu erneutem Lesen desselben Snapshots.
7. Überlaufzähler nicht still modulo 2^64 umbrechen lassen. Sättigung und ein
   dauerhaftes Overflow-Flag machen die betroffene Messung ungültig; alternativ
   ein vorab spezifizierter, atomar gelesener erweiterter Zähler.

Der Exportvertrag ist eine Grundlage für die spätere Register-Map. Busbreite,
Endianness, Adressen, CRC-Parameter, Resets und Snapshot-Handshakes müssen vor RTL
festgelegt werden. Die Software behauptet keine bereits implementierte Übertragung.

## 5. Offene Architekturpunkte vor VHDL

- Ein einzelnes I/O-Register oder ein gewöhnlicher Synchronizer erfasst kurze
  asynchrone Pulse nicht garantiert und misst keine ps-Zeitmarken. Erforderlich
  sind eine konkret validierte Erfassungs-/TDC-Struktur und sichere Clock-Domain-
  Übertragung, beispielsweise über eine dafür ausgelegte FIFO.
- H-Hold-off, Detektor-AQC-Hold-off und Fensterlänge sind verschiedene Parameter.
  Digitales Ignorieren löscht keine physikalische Lawine. A/B dürfen nicht durch
  den H-Hold-off blind werden, während ihre Fenster ausgewertet werden.
- Negative Fenster brauchen ausreichend Vorgeschichte. Positive Fenster bis
  +200 ns brauchen mehrere gleichzeitig offene Trial-Kontexte, wenn H bereits
  nach 100 ns erneut zugelassen wird. FIFO-Tiefe, Rate, Latenz und Rand-Exposition
  werden zusammen ausgelegt. Diagnose-Trials mit unvollständiger Vorgeschichte
  erhalten eigene gültige Expositionszähler; keine stillschweigende Nullfüllung.
- Die Auswahl der Verzögerungen richtet sich nach gemessener Zeitstruktur.
  Feste 100-ns-Schritte könnten gerade mit der Laserperiode zusammenfallen.
- GaN ist keine aus dem Quench-Hub ableitbare Pflichttechnologie. Entscheidend
  ist die reale Detektorspannung unter dem temperaturabhängigen Durchbruch mit
  ausreichender Reserve über die ganze Hold-off-Phase, einschliesslich Ringing,
  parasitärer Kapazitäten und Reset. 25..30 V und <5 ns sind unvalidierte Ziele.

## 6. Prüfung und Dateien

`test_photon_stats.py` prüft Null- und Vollereignisfälle, binomiale Tail-Inversion,
die drei numerischen Referenzfälle, Nenner-null, vollständige Enumeration aller
455 möglichen Multinomialausgänge bei N=12 an vier Parameterpunkten, uint64-
Erhalt sowie Integritäts- und CLI-Fehler. Die endliche Enumeration unterstützt
die Implementierungsprüfung; sie ersetzt nicht das allgemeine Abdeckungsargument.

`test_results.txt` und `run_summary.json` dokumentieren den tatsächlich ausgeführten
Lauf. `examples/` enthält deterministisch erzeugte Eingaben, `reports/` ihre
Ausgaben. `make_examples.py` reproduziert die Eingaben ohne Zufallszahlengenerator.
`SHA256SUMS.txt` enthält Prüfsummen der übrigen Paketdateien.

MIT-Lizenz für den neu erstellten Code und die Dokumentation; siehe LICENSE.
Die Drittbibliotheken behalten ihre eigenen Lizenzen.

## Quellen

1. NIST, Exact Binomial Confidence Limits:
   https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbici.htm
2. Razavi et al., Characterizing heralded single-photon sources with imperfect
   measurement devices: https://arxiv.org/abs/0812.2445
3. Excelitas, C30902SH Series Datasheet, Rev. 2022.02:
   https://www.excelitas.com/file-download/download/public/61601?filename=Excellitas_Si_APD_C30902SH_Series_Datasheet.pdf
4. Intel, Metastability Analysis:
   https://www.intel.com/content/www/us/en/docs/programmable/683068/18-1/metastability-analysis.html
5. Intel, Use Synchronous Resets (Grenzen kurzer asynchroner Eingangspulse):
   https://www.intel.com/content/www/us/en/docs/programmable/683082/25-1/use-synchronous-resets.html
6. Charlot et al., High-Resolution Waveform Capture Device on a Cyclone-V FPGA:
   https://arxiv.org/abs/2109.03026
7. High-voltage integrated active quenching circuit for single photon
   count rate up to 80 Mcounts/s (HV-CMOS, Quench-Hub bis 50 V):
   https://pmc.ncbi.nlm.nih.gov/articles/PMC5946911/

Quellen fachlich geprüft am 11. Oktober 2026. Die Spezifikationsentscheidungen und
Bonferroni-Verknüpfung sind die hier dokumentierte eigene Ableitung; die Quellen
bestätigen nicht die Funktionsfähigkeit unseres noch ungebauten Gesamtsystems.
