#!/usr/bin/env python3
"""Create deterministic synthetic fixtures, never experimental data."""
# SPDX-License-Identifier: MIT
import copy
import json
from pathlib import Path


def fixture(n, na, nb, nab, name="synthetic"):
    return {
        "schema": "photon-chain.raw.v0.1", "data_kind": "synthetic", "run_id": name,
        "firmware_id": "NO_HARDWARE", "config_id": "SYNTHETIC_FIXED_COUNTS",
        "calibration_id": "NOT_APPLICABLE_SYNTHETIC", "protocol_id": "reference-trials.v0.1",
        "counting_rule": "one-category-per-accepted-herald.v1",
        "stopping_rule": "prespecified-fixed-duration", "prespecified_analysis": True,
        "snapshot": {"sequence_before": "1", "sequence_after": "1"},
        "exposure": {"planned_ns": "1000000000000", "observed_ns": "1000000000000"},
        "counts": {"n00": str(n-na-nb+nab), "n10": str(na-nab), "n01": str(nb-nab),
                   "n11": str(nab), "h_raw": str(n), "h_accepted": str(n),
                   "h_rejected_policy": "0", "h_pending": "0"},
        "flags": {"atomic_snapshot": True, "acquisition_complete": True,
                  "counter_overflow": False, "event_loss": False,
                  "capture_error": False, "config_changed": False},
    }


def main():
    destination = Path(__file__).resolve().parent / "examples"
    destination.mkdir(exist_ok=True)
    examples = {
        "zero_triples_insufficient": fixture(10000, 100, 100, 0),
        "zero_triples_sufficient": fixture(1000000, 10000, 10000, 0),
        "twenty_triples": fixture(1000000, 10000, 10000, 20),
        "empty_denominator": fixture(10000, 0, 100, 0),
    }
    invalid = copy.deepcopy(examples["twenty_triples"])
    invalid["flags"]["event_loss"] = True
    examples["reported_event_loss"] = invalid
    for name, record in examples.items():
        record["run_id"] = name
        (destination / (name + ".json")).write_text(
            json.dumps(record, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
