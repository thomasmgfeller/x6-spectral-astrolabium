#!/usr/bin/env python3
"""Conditional click-correlation inference; no physical quantum certification.

SPDX-License-Identifier: MIT
One fixed-duration, prespecified acquisition. No background subtraction.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys

import scipy
from scipy.stats import beta

VERSION = "0.1.0"
ALPHA = 0.05
THRESHOLD = 0.5
MAX_U64 = (1 << 64) - 1
# An explicit software limit; not a limit of the proposed hardware counters.
MAX_INFERENCE_TRIALS = 1_000_000_000
CATEGORIES = ("n00", "n10", "n01", "n11")
COUNT_KEYS = CATEGORIES + ("h_raw", "h_accepted", "h_rejected_policy", "h_pending")
FLAGS = {
    "atomic_snapshot": True,
    "acquisition_complete": True,
    "counter_overflow": False,
    "event_loss": False,
    "capture_error": False,
    "config_changed": False,
}


class InvalidRecord(ValueError):
    """Malformed or explicitly invalid acquisition record."""


def uint64(value, name):
    # Reject JSON numbers, floats and booleans: every hardware integer is a string.
    if not isinstance(value, str) or re.fullmatch(r"0|[1-9][0-9]*", value) is None:
        raise InvalidRecord(f"{name}: expected canonical unsigned decimal string")
    number = int(value)
    if number > MAX_U64:
        raise InvalidRecord(f"{name}: outside uint64 range")
    return number


def _object(value, name):
    if not isinstance(value, dict):
        raise InvalidRecord(f"{name}: expected object")
    return value


def validate(record):
    r = _object(record, "record")
    if r.get("schema") != "photon-chain.raw.v0.1":
        raise InvalidRecord("unsupported schema")
    if r.get("data_kind") not in ("synthetic", "measurement"):
        raise InvalidRecord("data_kind must be synthetic or measurement")
    for key in ("run_id", "firmware_id", "config_id", "calibration_id", "protocol_id"):
        if not isinstance(r.get(key), str) or not r[key].strip():
            raise InvalidRecord(f"missing or empty {key}")
    if r.get("counting_rule") != "one-category-per-accepted-herald.v1":
        raise InvalidRecord("incompatible counting rule")
    if r.get("stopping_rule") != "prespecified-fixed-duration":
        raise InvalidRecord("this method requires a prespecified fixed duration")
    if r.get("prespecified_analysis") is not True:
        raise InvalidRecord("analysis was not declared prespecified")
    flags = _object(r.get("flags"), "flags")
    if set(flags) != set(FLAGS):
        raise InvalidRecord("missing or unknown quality flag")
    for name, required in FLAGS.items():
        if type(flags[name]) is not bool or flags[name] is not required:
            raise InvalidRecord(f"quality gate failed: {name}")
    snapshot = _object(r.get("snapshot"), "snapshot")
    before = uint64(snapshot.get("sequence_before"), "sequence_before")
    after = uint64(snapshot.get("sequence_after"), "sequence_after")
    if before != after:
        raise InvalidRecord("snapshot sequence changed during readout")
    exposure = _object(r.get("exposure"), "exposure")
    planned = uint64(exposure.get("planned_ns"), "planned_ns")
    observed = uint64(exposure.get("observed_ns"), "observed_ns")
    if planned == 0 or observed != planned:
        raise InvalidRecord("fixed acquisition duration not completed exactly")
    raw_counts = _object(r.get("counts"), "counts")
    if set(raw_counts) != set(COUNT_KEYS):
        raise InvalidRecord("missing or unknown counter")
    counts = {name: uint64(raw_counts[name], name) for name in COUNT_KEYS}
    n = sum(counts[name] for name in CATEGORIES)
    if n > MAX_U64 or n != counts["h_accepted"]:
        raise InvalidRecord("category sum differs from h_accepted")
    if counts["h_raw"] != counts["h_accepted"] + counts["h_rejected_policy"]:
        raise InvalidRecord("herald accounting is inconsistent")
    if counts["h_pending"] != 0:
        raise InvalidRecord("unfinished trials: drain pending windows before snapshot")
    if n == 0:
        raise InvalidRecord("no accepted herald trials")
    return counts


def cp_one_sided(k, n, tail):
    """Separate lower/upper Clopper-Pearson endpoints, each tail probability tail.

    The interval construction is exact in the binomial model. Numerical beta
    quantiles are floating-point approximations, not interval-arithmetic proofs.
    """
    if type(k) is not int or type(n) is not int or not 0 <= k <= n or n < 1:
        raise ValueError("require integer 0 <= k <= n and n >= 1")
    if not math.isfinite(tail) or not 0 < tail < 0.5:
        raise ValueError("tail must lie strictly between 0 and 0.5")
    if k == 0:
        lower = 0.0
        upper = -math.expm1(math.log(tail) / n)
    elif k == n:
        lower = math.exp(math.log(tail) / n)
        upper = 1.0
    else:
        lower = float(beta.ppf(tail, k, n - k + 1))
        upper = float(beta.isf(tail, k + 1, n - k))
    if not (math.isfinite(lower) and math.isfinite(upper)
            and 0 <= lower <= k / n <= upper <= 1):
        raise ArithmeticError("invalid numerical confidence endpoint")
    return lower, upper


def correlation_bound(n00, n10, n01, n11):
    counts = (n00, n10, n01, n11)
    if any(type(x) is not int or x < 0 for x in counts):
        raise ValueError("categories must be nonnegative integers")
    n = sum(counts)
    if not 1 <= n <= MAX_INFERENCE_TRIALS:
        raise ValueError(f"inference supports 1..{MAX_INFERENCE_TRIALS} trials")
    na, nb = n10 + n11, n01 + n11
    tail = ALPHA / 3
    la, _ = cp_one_sided(na, n, tail)
    lb, _ = cp_one_sided(nb, n, tail)
    _, uab = cp_one_sided(n11, n, tail)
    point = n11 * n / (na * nb) if na and nb else None
    # JSON null plus an explicit flag is used instead of nonstandard Infinity.
    upper = uab / (la * lb) if la > 0 and lb > 0 else None
    return {
        "N_H": str(n), "N_HA": str(na), "N_HB": str(nb), "N_HAB": str(n11),
        "g_click_hat": point, "g_click_upper_95": upper,
        "upper_bound_unbounded": upper is None,
        "marginal_limits": {"p_A_lower": la, "p_B_lower": lb, "p_AB_upper": uab},
        "alpha_total": ALPHA, "alpha_per_tail": tail, "threshold": THRESHOLD,
        "conditional_criterion_met": upper is not None and upper < THRESHOLD,
    }


def analyze(record):
    counts = validate(record)
    base = {
        "schema": "photon-chain.analysis.v0.1", "software_version": VERSION,
        "scipy_version": scipy.__version__,
        "run_id": record["run_id"], "data_kind": record["data_kind"],
        "raw_counts": {name: str(value) for name, value in counts.items()},
        "physical_quantum_claim": "NOT_ASSESSED",
        "method": "one-sided Clopper-Pearson; Bonferroni alpha/3",
        "background_subtraction": False,
        "assumptions": [
            "Accepted trials are iid multinomial conditional on their number.",
            "Duration, alpha, threshold and analysis were fixed before acquisition.",
            "Herald selection is predefined and does not depend on A/B outcomes.",
            "Detector artefacts and mapping from click to optical correlations require separate validation.",
            "Declared hardware flags are trusted inputs; this script cannot verify the electronics.",
        ],
    }
    if counts["h_accepted"] > MAX_INFERENCE_TRIALS:
        return base | {"status": "UNSUPPORTED_NUMERICAL_RANGE", "statistics": None}
    stats = correlation_bound(*(counts[name] for name in CATEGORIES))
    status = "CONDITIONAL_CRITERION_MET" if stats["conditional_criterion_met"] else "NOT_ESTABLISHED"
    return base | {"status": status, "statistics": stats}


def _unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise InvalidRecord(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def load_record(raw_bytes):
    def bad_constant(value):
        raise InvalidRecord(f"nonstandard JSON constant: {value}")
    return json.loads(raw_bytes.decode("utf-8"), object_pairs_hook=_unique_object,
                      parse_constant=bad_constant)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="one completed raw JSON snapshot")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    raw = b""
    try:
        if args.output and args.output.resolve() == args.input.resolve():
            raise InvalidRecord("output must not overwrite raw input")
        raw = args.input.read_bytes()
        result = analyze(load_record(raw))
        exit_code = 0 if result["status"] == "CONDITIONAL_CRITERION_MET" else 1
    except (InvalidRecord, ValueError, ArithmeticError, OSError, UnicodeError) as exc:
        result = {"schema": "photon-chain.analysis.v0.1", "status": "INVALID_INPUT",
                  "physical_quantum_claim": "NOT_ASSESSED", "error": str(exc)}
        exit_code = 2
    result["input_sha256"] = hashlib.sha256(raw).hexdigest() if raw else None
    output = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    if args.output:
        if args.output.resolve() == args.input.resolve():
            sys.stderr.write(output)
            return 2
        try:
            args.output.write_text(output, encoding="utf-8")
        except OSError as exc:
            sys.stderr.write(f"Cannot write report: {exc}\n")
            return 2
    else:
        sys.stdout.write(output)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
