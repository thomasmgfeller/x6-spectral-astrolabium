"""Scientific boundary checks and acquisition integrity checks. No hardware tests."""
# SPDX-License-Identifier: MIT
import copy
import itertools
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from scipy.stats import binom, multinomial

from make_examples import fixture
from photon_stats import (ALPHA, MAX_U64, InvalidRecord, analyze, correlation_bound,
                          cp_one_sided, load_record, validate)


class StatisticalTests(unittest.TestCase):
    def test_zero_events_closed_form(self):
        tail = ALPHA / 3
        for n in (1, 10, 10000, 1_000_000_000):
            lower, upper = cp_one_sided(0, n, tail)
            self.assertEqual(lower, 0)
            self.assertAlmostEqual(n * math.log1p(-upper), math.log(tail), places=11)

    def test_all_events_closed_form(self):
        tail = ALPHA / 3
        for n in (1, 10, 10000):
            lower, upper = cp_one_sided(n, n, tail)
            self.assertEqual(upper, 1)
            self.assertAlmostEqual(lower ** n, tail, places=11)

    def test_binomial_tail_inversion(self):
        tail = ALPHA / 3
        for k, n in ((1, 100), (20, 1000000), (99, 100), (500, 1000)):
            lower, upper = cp_one_sided(k, n, tail)
            self.assertAlmostEqual(binom.sf(k-1, n, lower), tail, places=10)
            self.assertAlmostEqual(binom.cdf(k, n, upper), tail, places=10)

    def test_reference_small_zero_sample_does_not_pass(self):
        r = correlation_bound(9800, 100, 100, 0)
        self.assertEqual(r["g_click_hat"], 0)
        self.assertAlmostEqual(r["g_click_upper_95"], 6.398364938107409, places=10)
        self.assertFalse(r["conditional_criterion_met"])

    def test_reference_large_zero_sample(self):
        r = correlation_bound(980000, 10000, 10000, 0)
        self.assertAlmostEqual(r["g_click_upper_95"], 0.04272388736081181, places=11)
        self.assertTrue(r["conditional_criterion_met"])

    def test_reference_positive_triples(self):
        r = correlation_bound(980020, 9980, 9980, 20)
        self.assertEqual(r["g_click_hat"], 0.2)
        self.assertAlmostEqual(r["g_click_upper_95"], 0.3327886692305544, places=10)

    def test_empty_denominator_is_unbounded(self):
        r = correlation_bound(9900, 0, 100, 0)
        self.assertIsNone(r["g_click_upper_95"])
        self.assertTrue(r["upper_bound_unbounded"])
        self.assertFalse(r["conditional_criterion_met"])
        json.dumps(r, allow_nan=False)

    def test_exhaustive_small_sample_coverage(self):
        # Enumerate all multinomial outcomes, not Monte Carlo. This checks
        # selected parameter points; general coverage follows from the proof.
        n = 12
        outcomes = []
        upper = []
        for a in range(n+1):
            for b in range(n-a+1):
                for c in range(n-a-b+1):
                    d = n-a-b-c
                    outcomes.append((a,b,c,d))
                    value = correlation_bound(a,b,c,d)["g_click_upper_95"]
                    upper.append(math.inf if value is None else value)
        for probs in ((.81,.09,.09,.01), (.6,.1,.1,.2), (.25,.25,.25,.25), (.9,.049,.049,.002)):
            true_g = probs[3] / ((probs[1]+probs[3])*(probs[2]+probs[3]))
            weights = multinomial.pmf(np.array(outcomes), n, probs)
            failure = weights[np.array(upper) < true_g].sum()
            self.assertLessEqual(failure, ALPHA + 1e-12)


class RecordTests(unittest.TestCase):
    def setUp(self):
        self.r = fixture(1000000,10000,10000,20)

    def test_valid_record_has_conditional_only_result(self):
        r = analyze(self.r)
        self.assertEqual(r["status"], "CONDITIONAL_CRITERION_MET")
        self.assertEqual(r["physical_quantum_claim"], "NOT_ASSESSED")

    def test_each_quality_flag_blocks_analysis(self):
        for key in self.r["flags"]:
            r = copy.deepcopy(self.r)
            r["flags"][key] = not r["flags"][key]
            with self.subTest(flag=key), self.assertRaises(InvalidRecord):
                analyze(r)

    def test_mixed_snapshots_rejected(self):
        self.r["snapshot"]["sequence_after"] = "2"
        with self.assertRaises(InvalidRecord): analyze(self.r)

    def test_pending_trials_rejected(self):
        self.r["counts"]["h_pending"] = "1"
        with self.assertRaises(InvalidRecord): analyze(self.r)

    def test_inconsistent_accounting_rejected(self):
        for key in ("h_raw", "h_accepted", "n00"):
            r = copy.deepcopy(self.r)
            r["counts"][key] = str(int(r["counts"][key])+1)
            with self.subTest(counter=key), self.assertRaises(InvalidRecord): analyze(r)

    def test_counter_types_and_overflow_rejected(self):
        for bad in (1, 1.0, True, "-1", "01", "1.5", str(MAX_U64+1)):
            r = copy.deepcopy(self.r)
            r["counts"]["n00"] = bad
            with self.subTest(value=bad), self.assertRaises(InvalidRecord): analyze(r)

    def test_uint64_preserved_beyond_javascript_precision(self):
        r = fixture(MAX_U64, 0, 0, 0)
        decoded = load_record(json.dumps(r).encode())
        self.assertEqual(validate(decoded)["n00"], MAX_U64)
        result = analyze(decoded)
        self.assertEqual(result["status"], "UNSUPPORTED_NUMERICAL_RANGE")
        self.assertEqual(result["raw_counts"]["n00"], str(MAX_U64))

    def test_duplicate_json_rejected(self):
        with self.assertRaises(InvalidRecord): load_record(b'{"schema": "a", "schema": "b"}')

    def test_incomplete_time_rejected(self):
        self.r["exposure"]["observed_ns"] = "999999999999"
        with self.assertRaises(InvalidRecord): analyze(self.r)

    def test_nonprespecified_analysis_rejected(self):
        self.r["prespecified_analysis"] = False
        with self.assertRaises(InvalidRecord): analyze(self.r)

    def test_cli_success_invalid_and_raw_protection(self):
        script = Path(__file__).resolve().parent / "photon_stats.py"
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/"raw.json"
            original = json.dumps(self.r)
            p.write_text(original)
            good = subprocess.run([sys.executable,str(script),str(p)],capture_output=True,text=True)
            self.assertEqual(good.returncode,0)
            self.assertEqual(len(json.loads(good.stdout)["input_sha256"]),64)
            same = subprocess.run([sys.executable,str(script),str(p),"--output",str(p)],capture_output=True,text=True)
            self.assertEqual(same.returncode,2)
            self.assertEqual(p.read_text(),original)
            p.write_text('{"schema":"bad"}')
            bad = subprocess.run([sys.executable,str(script),str(p)],capture_output=True,text=True)
            self.assertEqual(bad.returncode,2)
            self.assertEqual(json.loads(bad.stdout)["status"],"INVALID_INPUT")


if __name__ == "__main__":
    unittest.main(verbosity=2)
