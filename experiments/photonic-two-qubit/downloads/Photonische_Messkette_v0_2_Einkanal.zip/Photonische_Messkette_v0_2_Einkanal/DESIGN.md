# D0.2 - Entwurfsentscheidung für einen einzelnen Detektorkanal

## 1. Zweck, Annahmen und Evidenz

Ziel ist eine nachvollziehbare photonische Messkette für das Raspberry-Pi-Ökosystem.
Der Pi konfiguriert, protokolliert und wertet aus. Er liegt nicht im zeitkritischen Quenchpfad.
Der Ein-Kanal-Prototyp charakterisiert das Detektorfrontend; die spätere Korrelation benötigt
H/A/B-Kanäle sowie eine real implementierte und kalibrierte Zeitdigitalisierung.

Arbeitsannahme ist sichtbares/nahinfrarotes Licht, mit 800 nm als Messplan-Nennwert. Das ist keine
behauptete Vorgabe der künftigen Quelle. Für 1550 nm ist dieser Si-SPAD keine passende Auswahl.
Erst nach Festlegung der tatsächlichen Quelle werden Wellenlänge, Filter und Optik eingefroren.

Kennzeichnung: Herstellerdaten [H], eigene Entwurfsziele [Z], Rechenannahmen [A], Labornachweis [M].
In diesem Paket existiert noch kein [M]. Quellen stehen in SOURCES.md.

## 2. Bauteilentscheidungen

| Funktion | Auswahl für die nächste Entwicklungsstufe | Einordnung |
|---|---|---|
| Detektor | Excelitas C30902SH, ungekühlte TO-18-Version | Vorläufiger Kandidat für elektrische Charakterisierung; keine Beschaffungsfreigabe. |
| Niedriger Betriebspunkt | Vex = 3 V über individuell gemessenem VBD(T) | [Z], reduzierte Photoneneffizienz wird akzeptiert und gemessen. Keine Übertragung der Hersteller-PDE bei höherer Überspannung. |
| Quenchhub | 8 V nominal, Zielreserve mindestens 2 V unter Durchbruch | [Z], nur unter den expliziten Reserveannahmen berechnet. |
| Schwellenwert | TI DAC80501, 1,25-V-Ausgangsbereich, interner Referenzbetrieb | Kandidat mit echtem Referenzkonzept; SPI oder I2C. Nachfolgender Filter/Buffer und Offsetkalibrierung erforderlich. |
| Zeitdiskriminator | ADCMP607 als erster Messkandidat | CML-Ausgang. Keine generelle 50-ps-Dispersion zugesagt; Amplituden- und Flankenabhängigkeit messen. |
| Schneller Vergleich | ADCMP580 auf separater Vergleichsstufe | Grössere Anforderungen an Versorgung/Layout; negativer CML-Ausgang, nicht mit ADCMP607-Pegel austauschbar. |
| Quench-Treiber | UCC27511 zunächst nur an kapazitiver Ersatzlast untersuchen | 8-V-Betrieb im Versorgungsbereich. Seine typische Latenz um 13 ns ist kein Nachweis eines schnellen SPAD-AQC. |
| Haltezeit | Lokales nicht retriggerbares Latch mit Hardware-Timer | Bereichsziel 0,1 bis 10 us; Entwicklung zunächst bei 1 us. Tatsächliche Totzeit wird gemessen. |

Der BFP840ESD als unmittelbarer 30-V-Schalter und die Kombination MCP4725/unspezifizierte LM4040
werden aus dieser Arbeitsarchitektur gestrichen. Es wird keine ungeprüfte Ersatzliste als
fertigungsfähige Stückliste ausgegeben. Preise, Lieferbarkeit, Stecker und Pinbelegung sind offen.

### Herstellerdaten, die die Entscheidung begrenzen

[S1] nennt für C30902SH VBD 185..260 V, typisch 225 V; Tempco 0,5..0,9 V/K, typisch 0,7;
Kapazität typisch 1,5 pF, maximal 1,8 pF unter den Datenblattbedingungen. Die Geiger-Tabelle bei
20 V Überspannung nennt ungekühlt 20 kcps typisch/80 kcps maximal und Nachpulsanteile 3% typisch/
10% maximal bei 100 ns Totzeit (Nachweisfenster 100..500 ns). Diese Raten gelten nicht automatisch
für unseren 3-V-Pilotbetrieb. 0,4 ns Anstiegszeit aus dem linearen Betrieb ist kein Photon-Timingjitter.

[S2] beschreibt einen diskreten nicht retriggerbaren AQC mit C30902S und kleinem Quenchhub.
Dessen Betrieb ist auf niedrige Überspannung begrenzt; die Arbeit ist ein Machbarkeitsbeleg,
kein validierter Ersatzschaltplan für C30902SH. Wir übernehmen weder die Messwerte noch eine
20-V-Tauglichkeit. Die vorgeschlagene positive Anodenanhebung ist eine eigene Blockarchitektur;
sie ist nicht der identische Aufbau der Publikation.

Beim ADCMP607 stehen Überblicksaussagen über kleine typische Dispersion neben 2,3 ns in der
elektrischen Tabelle für den breiten Overdrive-Bereich. Diese Diskrepanz ist offengelegt.
Keinen 50-ps-Nachweis allein aus der Produktbeschreibung ableiten. [S3]

## 3. Funktionsarchitektur (kein Anschluss-/Fertigungsschaltplan)

```mermaid
flowchart TD
  HV["Strombegrenzte Biasquelle"] --> D["SPAD und Stromabgriff"]
  D --> P["Schutz und Diskriminator"]
  DAC["Gefilterter DAC-Schwellenwert"] --> P
  P --> T["Zeitmarkenpfad zur Messreferenz"]
  P --> Q["Lokales Latch und Haltezeit"]
  Q --> DR["Quench-/Resettreiber"]
  DR --> D
  Q --> B["BUSY und Fehlerdiagnose"]
```

Positive Bias an der Kathode, Anode im scharfen Zustand nahe einem definierten Bezug. Eine
positive Anodenanhebung reduziert VR = VK - VA. Für die ganze Hold-off-Phase muss
VK - VA <= VBD(T) - Reserve gelten. Die Biaszuführung darf dieses Kriterium nicht durch dynamische
Kathodenbewegung unterlaufen. Spannungen beider Elektroden sind deshalb nötig.

Nicht einfach den Treiberausgang niederohmig an denselben Knoten legen, dessen Avalanche-Spannung
gemessen werden soll: das könnte das Nutzsignal kurzschliessen. Stromabgriff, Quench-Einkopplung,
Schutzdioden und Resetpfad werden erst nach Ersatzlast-/Signalmodell dimensioniert. Vorläufige
Netznamen: HV_BIAS, SPAD_K, SPAD_A, SENSE_RAW, SENSE_LIMITED, VTH, EVENT_RAW, QUENCH,
BUSY, EVENT_OUT, FAULT. Das ist ein Funktionsvertrag, keine fertige Netzliste.

### Verbindliches Zeitverhalten

1. ARMED: Ein valides Primärereignis löst Zeitmarke und lokalen Quenchpfad aus.
2. QUENCH: BUSY wird gesetzt; der physische Bias fällt unter Durchbruch.
3. HOLD: neue Trigger verlängern die festgelegte Haltezeit nicht; keine neuen gültigen Ausgangsklicks.
4. RESET/SETTLE: Bias kehrt kontrolliert zurück; Rückladeimpuls darf keinen falschen Klick erzeugen.
5. ARMED erst nach vollständiger Erholung; die Sperre während SETTLE zählt zur effektiven Totzeit.
6. Fehler, Unterspannung oder fehlender Takt: Biasfreigabe aus. Ein auf LOW fallender Treiber
   allein ist kein sicherer Zustand, weil er eine zuvor angehobene Anode wieder scharf stellen könnte.

Asynchroner Ereignisbeginn und synchrones Timerende erzeugen zusätzliche Phasenunsicherheit.
Bei beispielhaft 100 MHz sind bereits bis zu etwa ein Takt plus Synchronizer-/Treiberanteile
einzuplanen. Es wird keine Garantie 100 ns +/-1 ns ausgesprochen. Ein gewöhnlicher Synchronizer
ersetzt weder eine schnelle Triggererfassung noch den TDC. Die Zeitmarke wird vor dem langsamen
Hold-off-Timer abgenommen. Schutzreaktion und Messzeitgenauigkeit sind verschiedene Grössen.

## 4. Elektrische Schnittstellen

- Die erste Zeitmessung erfolgt über einen geeigneten externen Zeitmesser/Oszilloskop. Das
  vorhandene VHDL-Ereignismodul kann noch keine analogen Flanken in ps-Zeitstempel verwandeln.
- CML-Pegel werden in ihrem jeweiligen Bias- und Abschlusskonzept vermessen. Kein direkter
  Anschluss an Raspberry-GPIO. DC-Kopplung und Empfänger-Gleichtaktbereich sind zu prüfen;
  AC-Kopplung darf bei seltenen Pulsen keine undefinierte Grundlinie erzeugen.
- Die DAC-Stufe arbeitet während eines Messlaufs statisch. Änderungen beenden/invalidieren den
  Lauf; neue Kalibrier-ID, Einschwingzeit und neuer START. Register-Readback prüfen.
- Comparator-Offset, DAC-Offset und Filterbelastung werden gemeinsam am Pin kalibriert.
  1,25 V / 65536 = 19,07 uV ist nur die ideale Codeschrittweite, keine absolute Genauigkeit.
- Bei Fehler/Start/Reset bleiben Detektor-Bias und EVENT_VALID gesperrt, bis Versorgung,
  Schwelle, Temperatur und Erfassung gültig sind. Rohdiagnosen bleiben vom Ereigniszähler getrennt.

## 5. Quantitative Auslegung

Pilot: Vex_worst = 3 + 0,5 = 3,5 V. Mit Hub 8 V, Treiberverlust 1 V und positiv wirkender
Ringing-Reserve 1 V bleiben rechnerisch 8 - 1 - 1 - 3,5 = 2,5 V unter Durchbruch.
Das sind angenommene Worst-Case-Budgets. Am Messgerät ist die minimale Reserve während HOLD
mit Unsicherheit nachzuweisen. Gemessene Reserve abzüglich U muss mindestens 2 V bleiben.

Kapazitätslast Ctotal enthält Diode, Pads, Treiber, Schutznetzwerk, Testpunkte und Tastkopf.
I_cap = Ctotal * Hub / Flankenzeit. Bei 10 pF und 1,5 ns ergeben sich 53,3 mA für 8 V,
aber 200 mA für 30 V. Der reale Strom enthält weitere Beiträge. Diese Rechnung ist keine
SPICE-Simulation und kein Nachweis für 1,5 ns. UCC27511 wird gerade wegen seiner Latenz und
Lastabhängigkeit nur als zu untersuchender Treiberkandidat geführt.

Oberes Planungsende der Biasquelle bei 30 C: 260 + 0,9*(30-22) + 3 = 270,2 V, ohne zusätzliche
Versorgungsreserve. 0..300 V beschreibt einen zu prüfenden Laborquellenbereich, keinen pauschalen
SPAD-Sollwert. Der reale Sollwert wird aus dem individuellen VBD und der gemessenen Temperatur
bestimmt. Strombegrenzung und Entladung sind Teil des Frontends, nicht der Hostsoftware.

Bei konstanter, nicht verlängernder Totzeit und Poisson-Ankunft gilt für die gesamte hypothetische
Detektionsrate r0 vor Totzeit: r_obs = r0/(1+r0*tau). Der verlorene Anteil ist r0*tau/(1+r0*tau).
Für <=1% Verlust: r0 <= 0,01/(0,99*tau), beziehungsweise r_obs*tau <= 0,01.
Bei 1 us sind das nur ungefähr 10,1 kcps vor Totzeit. 20 kcps ergeben bereits 1,96% Verlust,
80 kcps 7,41%. Dunkelereignisse belegen dieselbe Totzeit; eine spätere Hintergrundsubtraktion
gibt verlorene Photonen nicht zurück. Deshalb muss die Wahl 1 us gegen Nachpulse UND Rate
optimiert werden. Bei nicht erfülltem Budget Betrieb ändern oder Modell erweitern, nicht verdecken.

## 6. PCB und Mechanik

Vier Lagen sind die Arbeitsbasis: L1 Bauteile/kurze Signale, L2 zusammenhängende Referenzfläche
im schnellen Niederspannungsbereich, L3 gefilterte Versorgungsinseln, L4 langsame Steuerung.
Der Hochspannungsbereich braucht passende Isolationsabstände und Kupferfreistellungen; die
Referenzfläche wird nicht pauschal durch die Isolationszone geführt. Kein schneller Rückstrom
über eine Trennung. Konkrete Abstände erst nach Spannungs-, Material- und Umweltfestlegung.

Keine feste Leiterbahnbreite ohne gewählten Herstellerstackup. 50-Ohm-Einzel-/100-Ohm-Differenz-
leitungen nur dort, wo Quelle, Empfänger und Abschluss passen. Erst Stackup, dann Feldrechnung,
dann Fertigertoleranz und Couponmessung. Keine unbestückten Stub-Abzweige am SPAD-Knoten.
Messpads/Tastkopfkapazität in Ctotal aufnehmen. Quenchstromschleife vom Sense-/DAC-Rückstrom
trennen, bei gemeinsamer kontrollierter Referenz. Gerberfreigabe setzt Schaltplan, ERC, DRC,
Bauteilspannungen, Einschaltzustände und transiente Nachweise voraus.

Für den ersten Kanal: kurzer gekapselter Freistrahlweg auf gemeinsamer Metallbasis; kein
Singlemode-Faserzwang. Schienen, Granit und magnetische Wechselhalter werden erst eingesetzt,
wenn der Versuch sie benötigt. Das senkt Zahl der Freiheitsgrade und Beschaffungslast.
Metallhalter und eine definierte XYZ-Linsen-/Detektorjustage; gedruckte Teile dürfen Gehäuse,
Blenden oder nachgewiesen ausreichend stabile Hilfsteile sein. Abnahme über normierte optische
Transmission bei kontrollierter Quelle, nicht über bloss stabile Zählrate. Temperatur, Luftzug,
Lichtdichtheit und Quellenleistung protokollieren. Kühlung bei Bedarf mit Kondensationskontrolle.

## 7. Übergabe an v0.1 und offene Gates

Nach realem TDC: validierte Code-Density-LUT -> Kanaloffsetkorrektur -> zeitliche Sortierung ->
FIFO/CDC/Watermarks -> vorhandener Ereigniskern. Eine Offsetänderung gehört VOR Sortierung und
Fensterklassifikation; nachträgliche Korrektur der Summenzähler kann verlorene Treffer nicht retten.
Default-H-Hold-off (100 ns) in v0.1 bleibt von physischer Detektortotzeit verschieden. Neue
Detektorbedingungen erfordern neue Kalibrier-/Konfigurationsidentität und erneute iid-Prüfung.

Offen vor Fertigung: komplette Sense-/Quench-/Reset-Schaltung mit Schutznetzwerk; genaue
Treiber-/Empfängerbelastung und Logikpegel; gemessene Pulse/Time-Walk; AQC-Rückkopplungsstabilität;
konkretes TDC/FPGA-Board und Interface; reale Stückpreise; thermisches Konzept und optische Quelle.
Die Datenerfassungsvorlage macht diese fehlende Evidenz sichtbar. Kein offenes Gate wird allein
durch einen guten Softwaretest geschlossen.
