# K0.2 - Laborprotokoll und Abnahmekriterien

Alle Grenzen mit [Z] sind vorläufige Projektziele. Sie sind vor Messbeginn einzufrieren und
ersetzen kein vollständiges Experimentfehlerbudget. Keine Zeile dieses Protokolls wurde bereits
an Hardware ausgeführt. Der Laborstatus ist daher überall NOT_RUN.

## K0 - Messmittel, Bezugsebenen und Ersatzlast

Dokumentieren: Board-/Bauteilseriennummern, tatsächlicher Schaltplanstand, Stückliste, Datum,
Bedienperson, Netzteil, Temperaturfühler, Zeitreferenz, Eingangspegel und Kalibrierscheine.
Zuerst nur Niederspannung und kapazitive Ersatzlasten 2, 5, 10 und 20 pF. Tastkopfkapazität und
Masse-/Kabelinduktivität zählen zur Last. Der Quench-Treiber muss seine Last versorgen, während
die Sense-Einspeisung ein unabhängiges definierbares Signal bleibt.

Messen: Treiberdelay, 10-90%-Flanken, Amplitude unter Last, Overshoot, Undershoot, Ringing,
Rückladeimpuls sowie Versorgungseinbruch bei Einzelimpulsen und Bursts. An jedem Zustand
prüfen, ob der Detektorsense-Pfad falsche EVENT_OUT-Flanken erzeugt. Vor Anschluss des SPAD
vollständige Schutzschaltung, Strombegrenzung und Entladestrecke prüfen. Deren konkrete
Dimensionierung ist ein offenes Schaltplangate; dieses Protokoll ist keine Verdrahtungsanleitung.

Gate K0: alle Bauteile innerhalb Betriebsgrenzen, reproduzierbarer Quenchhub, keine unkontrollierte
Oszillation. Bei UVLO/Reset/fehlendem Timer Biasfreigabe deaktiviert; Treiber-LOW genügt nicht.
100 ms Netzteilausfall und Wiederanlauf müssen als Fehler erkannt werden; keine automatische
Wiederaufnahme eines laufenden wissenschaftlichen Datensatzes.

## K1 - Elektrischer Zeitmarkenpfad

Zwei Einspeisestellen trennen: vor dem Diskriminator (Frontendmessung) und direkt am TDC-Eingang
(Erfassungsmessung). Ohne realen TDC ein unabhängiges Messgerät nutzen. Keine ps-Auflösung aus
den Zahlentypen des Ereigniskerns ableiten.

Pilotmatrix [Z]: Temperaturen 20/25/30 C; Nennversorgung und +/-5%; externe Ereignisraten
1/10/100 kcps (nur elektrische Ersatzlast, keine garantierte SPAD-Nutzrate); Überschreitungen
der Schwelle 10/25/50/125/200 mV; Flanken 0,1/0,5/1 V/ns; Pulsbreiten 2/5/20 ns.
Nur innerhalb der realen Eingangs- und Quellenbereiche arbeiten. Später reale SPAD-Pulsformen
einschliesslich Amplitudenverteilung nachbilden. Mit der Pilotmatrix wird kein Vollbereich des
Komparators beansprucht. Erst Screening, dann vorab ausgewählte unabhängige Validierungspunkte.

Aufzeichnen: Eingangsspannung am Komparatorpin, EVENT_RAW, EVENT_OUT, Referenzzeit,
BUSY, Schwellenwert, Temperatur, Versorgung und Pulseingangszähler.
Getrennt berichten: konstante Verzögerung, Time-Walk, Einzelereignis-Paarstreuung, Quantile,
Pulsverluste, Duplikate und unzulässige Codes. Kein sqrt(2)-Rückschluss auf einen Kanal ohne
nachgewiesen unabhängige und gleichartige Kanaljitter.

Gate K1a [Z]: Bei jedem vorab ausgewählten kritischen Erfassungspunkt null Ausfälle/Duplikate
unter mindestens 2.995.731 unabhängigen Versuchen -> einseitige 95%-CP-Obergrenze <=1e-6
für DIESEN Punkt. Für simultane Aussagen über m Punkte alpha/m verwenden und N neu planen.
Dieses Kriterium betrifft elektrisch eingespeiste, erfassbare Pulse; ineffiziente Photonendetektion
ist etwas anderes. Tests unmittelbar an einer asynchronen Taktgrenze einschliessen.

Gate K1b [Z]: elektrische Paarstreuung als Entwicklungsziel <=50 ps RMS, separat von der
Offsetgenauigkeit. Eine endgültige Freigabe braucht eine obere Unsicherheitsgrenze und ein
begründetes Verteilungsmodell; die mitgelieferte Software gibt nur die beobachtete Streuung aus.
Kein 50-ps-Gesamtdetektornachweis. Nichtnormalität, lange Ausläufer und Mehrgipfligkeit berichten.

## K2 - Kabeltausch, Nichtlinearität und unabhängige Referenz

Eine gemeinsame Flanke teilt sich in die Zweige Z1 und Z2 (je Splitterausgang, Kabel, Stecker).
Definition: delta = tA - tB, o = elektronischer Versatz A-B, d = Laufzeit Z1-Z2.
Normal: A<-Z1, B<-Z2, delta_plus=o+d.
Getauscht: A<-Z2, B<-Z1, delta_minus=o-d.
Splitter/Kabel-Zuordnung bleibt innerhalb der mitvertauschten Zweige bestehen.

Allein identische Kabellänge ist nicht notwendig. Elektrische Stabilität, Impedanz, Pegel und
Steckerwiederholbarkeit sind notwendig. Eine vollständige Steckvertauschung beseitigt weder
amplitudenabhängige Kanalantworten noch driftempfindliche Signalformunterschiede.

Mindestens vier Zyklen plus/minus/minus/plus mit Zeitstempeln der Messblöcke erfassen.
Diese Reihenfolge dient der Driftdiagnose. Sie macht Rohdaten nicht automatisch iid und
entfernt keine allgemeine Drift aus o. Bei signifikanter Drift keine naive Mittelwert-SE
verwenden: Messdauer verkürzen/Temperatur stabilisieren oder Block-/Kovarianzmodell ergänzen.

Nach Festlegung von o: neue, unabhängige Messungen bei vorab festgelegten Verzögerungen
-1/0/+1 ns und an wenigstens einer tatsächlichen Taktperiodengrenze. Referenzverzögerungen
müssen passend charakterisiert sein; dieselben Daten nicht zum Offsetfit und Nachweis verwenden.
Unabhängige Prüfung bei den später akzeptierten Pegeln, Temperaturen und Raten wiederholen.
Für TDC-Binbreiten ist zusätzlich validierte Code-Density-Kalibrierung erforderlich; nur asynchron
zu sein garantiert keine gleichmässige Phasenverteilung. K0.1 des bestehenden Pakets bleibt gültig.

Gate K2 [Z]: abs(Restabweichung)+U <=200 ps für jede vorab festgelegte Bedingung. U umfasst
Referenz, Offsetkalibrierung, Restdrift, Stecken, verbleibende Nichtlinearität und weitere relevante
Effekte. Die Zahl 200 ps ist Wmin/10 für Wmin=2 ns; sie garantiert nicht automatisch kleine
Fensterfehlklassifikation. Ereignisse an beiden Fensterrändern zusätzlich einspeisen.

## K3 - Individueller Detektor und effektive Totzeit

Nach K0-Schaltplanfreigabe individuellen Durchbruch als Funktion der Gehäusetemperatur messen;
Testmethode und Messstrom angeben. Gehäusetemperatur ist kein perfekter Ersatz für Sperrschicht-
temperatur. Erste Betriebspunkte 2/3/4 V über gemessenem VBD; optische Leistung sehr klein,
Dunkelbedingungen kontrolliert. 3 V ist ein Pilotziel, kein optimierter Endpunkt.
Erste stabile Messzone [Z]: 25 C +/-0,25 K; Bias-Nachstellung zwischen abgeschlossenen Läufen.
Künftige Erweiterung 20..30 C nur nach eigener temperaturabhängiger Kalibrierung.

Messung an SPAD_K UND SPAD_A: realer Bias, Zeitpunkt unterhalb VBD, Haltephase und Wiederanlauf.
Gate K3a [Z]: kleinster gemessener Abstand unter Durchbruch minus seine erweiterte Unsicherheit
>=2 V während der festgelegten HOLD-Phase. Transiente Lawinenladung als Integral des Stroms
bestimmen und gegen zulässigen Detektor-/Schaltungsbetrieb prüfen. Dafür liegt noch kein
herstellerbestätigtes Grenzbudget für unseren Aufbau vor; es ist vor Dauerbetrieb zu klären.

Die nominelle Timerzeit ist nicht die effektive Totzeit. Primär-/Probe-Lichtpulse verwenden;
Probeabstand schrittweise variieren. Bei schwacher, gleicher Probehelligkeit die Klickwahrscheinlichkeit
mit grossem Abstand als Bezug messen. Erholungskurve und t99 (99% der Plateauantwort) mit
Unsicherheit angeben. Das Minimum beobachteter Ereignisabstände genügt nicht als t99-Nachweis.
Regelmässige Folgeereignisse während BUSY dürfen HOLD nicht verlängern; Verlust der ersten
zulässigen Folgepulse und Reset-Fehltrigger werden getrennt gezählt.

Haltezeiten [Z]: 0,1/0,25/0,5/1/2/5/10 us. Bei 1 us beginnen; diesen Wert erst nach K4 als
Betriebsparameter übernehmen. Jede Einstellung verändert Kalibrierung und mögliche Statistik.

## K4 - Dunkelrate, Nachpulse, Lebendzeit und Linearität

Dunkelmessung mit lichtdicht verschlossenem Eingang, nicht nur abgeschaltetem Pumplaser.
Mindestens zehn vorab festgelegte Zeitblöcke; Rate, Drift und Autokorrelation erfassen.
Kein automatisches Poisson-Modell bei Überdispersion oder zeitlichen Abhängigkeiten.

Für die erste Nachlaufdiagnostik: schwache isolierte Primäranregungen, ein prädefiniertes Fenster
von Wieder-Scharfschaltung bis 10 us nach dem Primärereignis, mindestens 100 us Abstand zwischen
Anregungen. Zusätzlich Kontrollfenster mit gleicher wirksamer Lebendzeit und passender Temperatur,
Bias- und Beleuchtungssituation. Fenster bis 1 ms explorativ auf längere Gedächtniseffekte prüfen;
der 10-us-Test kann spätere Nachpulse nicht ausschliessen. Keine Selektion danach, ob später ein
Treffer vorkommt. Nachfolgende Klicks erfassen, nicht als unerwünschte Ausreisser löschen.

Gate K4a [Z]: obere einseitige 95%-Schranke des positiven Nachlauf-Exzesses <=0,005 für das
vorab definierte Fenster, sofern das binomiale Trialmodell begründet ist. Das ist eine
Instrumentendiagnostik und keine vollständige Quanten- oder Unabhängigkeitszertifizierung.
Kaskaden/verlängerte Totzeit können Treffer verdecken; deshalb Intervalle UND Lebendzeit speichern.

Gate K4b [Z]: Totzeitverlust <=1% im gewählten Nutzbetrieb, falls das nicht verlängernde
Poisson-Modell experimentell passt. Gesamtrate inklusive Dunkelereignissen verwenden.
Bei Scheitern zählen längere Haltezeit und kleinere Nutzrate nicht pauschal als Lösung:
Dunkelereignisse bleiben. Optionen sind kleineres Vex, Kühlung, anderer Detektor oder ein
explizites erweitertes Fehlerbudget. Zielkonflikt transparent dokumentieren.

Gate K4c [Z]: Dunkel-Klickwahrscheinlichkeit im 2-ns-Fenster <=1e-4. Nur unter einem validierten
stationären Poisson-Modell wäre p=1-exp(-r_dark*W). Zusätzlich direkt an leeren Fenstern messen.
Bei drei Kanälen gilt dies noch nicht als ausreichendes Gesamtbudget für g_click.

Relative Linearität über kalibrierte Abschwächungen prüfen, Quellenleistung unabhängig monitoren.
Keine Division durch (1-r*tau) nahe Sättigung zur scheinbaren Reparatur des Datenstroms.
Absolute PDE nur mit kalibriertem Photonenfluss und Kopplungsverlustbudget angeben.

## K5 - Mechanische Stabilität und Übergabe

Vierstündiger Pilotlauf [Z] bei vorgesehener Temperaturzone: Geometrie nach Justage nicht ändern.
Optische Transmission auf unabhängige Quellleistungsmessung normieren. Ziel [Z] <=2% relative
Änderung; Messunsicherheit und beobachtete Drift getrennt angeben. Zählstabilität allein trennt
Kopplung, PDE, Dunkelrate und Totzeit nicht. Dieser Pilot ist kein Dauerfestigkeitsnachweis.

Übergabe erst mit realen Rohzeitdaten, keine ausschliesslichen Summenzähler. Neue Bitstream-/
Layoutversion = neue Kalibrieridentität, sofern Übertragbarkeit nicht nachgewiesen ist.
Nach Ein-Kanal-Nachweis folgen H/A/B-Integration, Übersprechen, zeitliche Sortierung, Snapshot-
Transport und Kontrolle der statistischen Annahmen des bereits vorhandenen photon_stats.py.
