#!/usr/bin/env python3
"""Single-channel planning and conditional metrology. No hardware control.

SPDX-License-Identifier: MIT
All timing inputs are interval differences in ps, never absolute epoch timestamps.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

import numpy as np
from scipy.stats import beta, t

VERSION = "0.2.0"
DECLARATIONS = (
    "independent_iid_samples", "independent_calibration_validation",
    "stable_offset_during_run", "complete_acquisition",
    "reference_calibrated", "uncertainty_budget_complete",
    "type_b_normal_large_dof", "prespecified_validation_grid",
)


def finite(x, name):
    if type(x) not in (int, float) or not math.isfinite(x):
        raise ValueError(f"{name}: finite numeric value required")
    return float(x)


def nonnegative(x, name):
    x = finite(x, name)
    if x < 0:
        raise ValueError(f"{name}: must be nonnegative")
    return x


def positive(x, name):
    x = finite(x, name)
    if x <= 0:
        raise ValueError(f"{name}: must be positive")
    return x


def samples(values, name):
    if not isinstance(values, list) or len(values) < 2:
        raise ValueError(f"{name}: at least two samples required")
    out = [finite(x, name) for x in values]
    if max(map(abs, out)) > 1e9:
        raise ValueError("Use interval differences within +/-1e9 ps, not absolute timestamps")
    return out


def cable_swap(plus, minus):
    a, b = samples(plus, "plus_ps"), samples(minus, "minus_ps")
    ma, mb = statistics.mean(a), statistics.mean(b)
    va, vb = statistics.variance(a)/len(a), statistics.variance(b)/len(b)
    return {
        "offset_ps": (ma+mb)/2, "branch_asymmetry_ps": (ma-mb)/2,
        "sampling_u_ps": math.sqrt((va+vb)/4),
        "pair_sd_plus_ps": statistics.stdev(a),
        "pair_sd_minus_ps": statistics.stdev(b),
        # variance and degrees of freedom of the two mean contributions
        "variance_terms": [(va/4, len(a)-1), (vb/4, len(b)-1)],
    }


def budget_variance(components, correlations):
    if not isinstance(components, list) or not components:
        raise ValueError("At least one explicit type-B uncertainty component required")
    names = [c["name"] for c in components]
    if any(not isinstance(n, str) or not n.strip() for n in names) or len(set(names)) != len(names):
        raise ValueError("Uncertainty names must be unique nonempty strings")
    u = np.array([nonnegative(c["u_ps"], c["name"]) for c in components])
    r = np.asarray(correlations, dtype=float)
    n = len(u)
    if r.shape != (n,n) or not np.all(np.isfinite(r)):
        raise ValueError("Correlation matrix must be finite and square")
    if not np.allclose(r, r.T, rtol=0, atol=1e-12):
        raise ValueError("Correlation matrix must be symmetric")
    if not np.allclose(np.diag(r), 1, rtol=0, atol=1e-12) or np.any(np.abs(r) > 1+1e-12):
        raise ValueError("Invalid correlation entries")
    if np.linalg.eigvalsh(r).min() < -1e-12:
        raise ValueError("Correlation matrix must be positive semidefinite")
    # Only round off tiny numerical negatives from a validated PSD matrix.
    return max(0.0, float(u @ r @ u))


def analyze_timing(record):
    if record.get("schema") != "channel-timing.v0.2":
        raise ValueError("Unsupported timing schema")
    kind = record.get("data_kind")
    if kind not in ("synthetic", "measurement"):
        raise ValueError("data_kind must be synthetic or measurement")
    for key in ("run_id", "calibration_id", "reference_id", "scope"):
        if not isinstance(record.get(key), str) or not record[key].strip():
            raise ValueError(f"Missing {key}")
    if record["scope"] not in ("electrical_pair", "optical_pair"):
        raise ValueError("Unknown measurement scope")
    dec = record.get("declarations", {})
    if any(type(dec.get(k)) is not bool for k in DECLARATIONS):
        raise ValueError("All declarations must be explicit booleans")
    alpha = finite(record["alpha"], "alpha")
    if not 0 < alpha < 0.5:
        raise ValueError("alpha outside (0,0.5)")
    limit = positive(record["residual_limit_ps"], "limit")
    cal = cable_swap(record["calibration"]["plus_ps"], record["calibration"]["minus_ps"])
    vb = budget_variance(record["type_b_components"], record["correlation_matrix"])
    points = record["validation"]
    if not isinstance(points,list) or not points:
        raise ValueError("Independent validation points required")
    ids = [p["id"] for p in points]
    if any(not isinstance(x,str) or not x.strip() for x in ids) or len(set(ids)) != len(ids):
        raise ValueError("Unique validation identifiers required")
    out = []
    for p in points:
        y = samples(p["delta_ps"], "delta_ps")
        reference = finite(p["reference_delay_ps"], "reference_delay_ps")
        ur = nonnegative(p["reference_u_ps"], "reference_u_ps")
        if not isinstance(p.get("conditions"),dict) or not p["conditions"]:
            raise ValueError("Validation conditions must be recorded")
        residual = statistics.mean(y)-cal["offset_ps"]-reference
        vv = statistics.variance(y)/len(y)
        terms = cal["variance_terms"] + [(vv,len(y)-1)]
        variance = vb + ur*ur + sum(v for v,_ in terms)
        if variance <= 0:
            raise ValueError("Zero total uncertainty is not an acceptable metrology budget")
        denominator = sum(v*v/df for v,df in terms)
        df = variance*variance/denominator if denominator > 0 else math.inf
        # Approximate GUM/Welch coverage, Bonferroni for prespecified points.
        # This is NOT an exact distribution-free bound.
        k = float(t.ppf(1-alpha/(2*len(points)), df))
        expanded = k*math.sqrt(variance)
        metric = abs(residual)+expanded
        out.append({"id":p["id"], "conditions":p["conditions"],
                    "n":len(y), "reference_delay_ps":reference,
                    "residual_mean_ps":residual, "u_combined_ps":math.sqrt(variance),
                    "coverage_factor":k, "effective_dof":df if math.isfinite(df) else None,
                    "expanded_u_ps":expanded, "abs_bias_plus_u_ps":metric,
                    "numeric_gate_met":metric<=limit,
                    "pair_event_sd_ps":statistics.stdev(y),
                    "pair_event_p01_ps":float(np.quantile(y,0.01)),
                    "pair_event_p99_ps":float(np.quantile(y,0.99))})
    declarations_ok = all(dec[k] for k in DECLARATIONS)
    numeric = all(p["numeric_gate_met"] for p in out)
    decision = ("SYNTHETIC_ONLY" if kind=="synthetic" else
                "MODEL_NOT_ESTABLISHED" if not declarations_ok else
                "CONDITIONAL_TIMING_CRITERION_MET" if numeric else "TIMING_CRITERION_NOT_MET")
    return {"schema":"channel-timing-result.v0.2", "software_version":VERSION,
            "data_kind":kind, "run_id":record["run_id"], "scope":record["scope"],
            "calibration_id":record["calibration_id"], "reference_id":record["reference_id"],
            "decision":decision, "hardware_validated":False,
            "physical_quantum_claim":"NOT_ASSESSED", "numeric_gate_met":numeric,
            "declarations":dec, "limit_ps":limit, "alpha_family":alpha,
            "calibration":{k:v for k,v in cal.items() if k!="variance_terms"},
            "type_b_components":record["type_b_components"],
            "correlation_matrix":record["correlation_matrix"], "validation":out,
            "limitations":[
                "Declared metadata are not independent evidence of correct acquisition.",
                "Approximate GUM/Welch uncertainty; type-B terms assumed normal, large DOF.",
                "Calibration, validation and type-B terms assumed mutually independent except supplied type-B correlations.",
                "Uniform simultaneous coverage is conditional on each approximate marginal coverage.",
                "No drift removal, TDC calibration, jitter qualification or single-channel deconvolution.",
                "No automatic LUT write, detector qualification or hardware release."]}


def cp_limit(k, n, tail, upper=True):
    if type(k) is not int or type(n) is not int or not 0<=k<=n or not 1<=n<=1_000_000_000:
        raise ValueError("Require integer 0 <= k <= n <= 1e9 and n>0")
    tail=finite(tail,"tail")
    if not 0<tail<0.5:
        raise ValueError("tail outside (0,0.5)")
    if upper:
        return 1.0 if k==n else -math.expm1(math.log(tail)/n) if k==0 else float(beta.isf(tail,k+1,n-k))
    return 0.0 if k==0 else math.exp(math.log(tail)/n) if k==n else float(beta.ppf(tail,k,n-k+1))


def followup_excess(k_primary,n_primary,k_control,n_control,alpha=0.05):
    """Upper bound on p_followup|primary - p_followup|control, clipped at zero.

    Requires iid trials within each marginal and pre-fixed windows/stopping.
    Marginal independence between the two groups is not required by Bonferroni.
    This is a diagnostic, not automatically an intrinsic afterpulse probability.
    """
    upper=cp_limit(k_primary,n_primary,alpha/2,True)
    lower=cp_limit(k_control,n_control,alpha/2,False)
    return {"upper95_excess_probability" if alpha==0.05 else "upper_excess_probability":max(0,upper-lower),
            "alpha":alpha,"primary_upper":upper,"control_lower":lower,
            "point_difference":k_primary/n_primary-k_control/n_control,
            "physical_afterpulse_probability":"NOT_IDENTIFIED"}


def design_calculations():
    """Own planning assumptions; no transistor transient or avalanche simulation."""
    designs=[]
    for name,vex,ex_error,hub,driver_loss,ringing in [
        ("low_excess_pilot",3.0,0.5,8.0,1.0,1.0),
        ("high_excess_comparison",20.0,1.0,30.0,1.5,2.0)]:
        margin=hub-driver_loss-ringing-vex-ex_error
        designs.append({"name":name,"vex_nominal_V":vex,"vex_error_bound_V":ex_error,
                        "quench_nominal_V":hub,"driver_loss_bound_V":driver_loss,
                        "ringing_bound_V":ringing,"minimum_below_breakdown_margin_V":margin,
                        "candidate_capacitive_loads":[
                            {"C_total_pF":c,"current_mA_at_1_5_ns":c*hub/1.5,
                             "charge_pC":c*hub,"stored_energy_pJ":0.5*c*hub*hub}
                            for c in (1.8,5.0,10.0,20.0)]})
    deadtime=[]
    for ns in (100,250,500,1000,2000,5000,10000):
        tau=ns*1e-9
        deadtime.append({"deadtime_ns":ns,"max_incident_detectable_rate_per_s_for_1pct_loss":0.01/(0.99*tau),
                         "max_observed_rate_per_s_for_1pct_loss":0.01/tau,
                         "loss_at_20k_total_input":20000*tau/(1+20000*tau),
                         "loss_at_80k_total_input":80000*tau/(1+80000*tau)})
    return {"schema":"channel-design-calculations.v0.2","data_kind":"planning_model",
            "hardware_validated":False,"designs":designs,"deadtime_model":deadtime,
            "bias_upper_at_30C_V_pilot":260+0.9*(30-22)+3,
            "bias_upper_at_30C_V_high_excess":260+0.9*(30-22)+20,
            "dac_1_25V_range_lsb_uV":1.25/65536*1e6,
            "zero_errors_trials_for_upper_1e_6_at_95pct":math.ceil(math.log(0.05)/math.log1p(-1e-6)),
            "assumptions":["Low-excess pilot is a project choice, not a manufacturer PDE claim.",
                           "Current is the capacitive C*dV/dt term only; 1.5ns is a comparison, not a driver promise.",
                           "Constant nonparalyzable deadtime, stationary Poisson input; total rate includes dark events.",
                           "Driver loss and ringing are assumed worst-case budgets, not measured values."]}


def load_json(raw):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:
                raise ValueError(f"Duplicate JSON key: {k}")
            out[k]=v
        return out
    def invalid(v):
        raise ValueError(f"Invalid JSON constant {v}")
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("command",choices=("design","timing"))
    p.add_argument("input",nargs="?",type=Path)
    p.add_argument("--output",type=Path)
    args=p.parse_args()
    try:
        if args.input and args.output and args.input.resolve()==args.output.resolve():
            raise ValueError("Output must not overwrite raw input")
        if args.command=="design":
            result=design_calculations()
        else:
            if not args.input:
                raise ValueError("timing requires a JSON input")
            raw=args.input.read_bytes()
            result=analyze_timing(load_json(raw))
            result["input_sha256"]=hashlib.sha256(raw).hexdigest()
        body=json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+"\n"
        if args.output:
            args.output.write_text(body,encoding="utf-8")
        else:
            print(body,end="")
    except (ValueError,KeyError,TypeError,OSError) as exc:
        p.exit(2,f"INVALID_INPUT: {exc}\n")


if __name__=="__main__":
    main()
