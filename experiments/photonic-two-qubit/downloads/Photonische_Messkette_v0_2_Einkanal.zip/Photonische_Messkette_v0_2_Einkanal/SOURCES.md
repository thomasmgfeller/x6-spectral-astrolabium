# Quellen und Prüfumfang

Abruf/Prüfung: 11. Oktober 2026. Herstellerdaten sind keine Messergebnisse unseres Aufbaus.
Links dienen der Nachprüfbarkeit; fremde Datenblätter und Abbildungen werden nicht mitverteilt.

1. **S1 - Excelitas C30902SH**, Datenblatt Rev. 2022.02, Tabellen 1/3/4/6.
   https://www.excelitas.com/file-download/download/public/61601?filename=Excellitas_Si_APD_C30902SH_Series_Datasheet.pdf
   Produktseite: https://www.excelitas.com/product/c30902sh-si-apd-05mm-18-photon-counting
   Geprüft: Durchbruch, Temperaturkoeffizient, Kapazität, Geiger-Parameter und deren Bedingungen.
2. **S2 - M. Stipcevic**, A novel active quenching circuit for single photon detection with Geiger mode avalanche photodiodes.
   https://arxiv.org/html/0805.2727v1
   Journal: Applied Optics 48, 1705-1714 (2009), https://doi.org/10.1364/AO.48.001705
   Volltext geprüft: diskrete Architektur und Begrenzung auf niedrige Überspannung. Keine
   Gleichsetzung des älteren C30902S mit unserem C30902SH. Kein Layout oder Schaltplan kopiert.
3. **S3 - Analog Devices ADCMP606/607**, Datenblatt Rev. C, Tabelle AC Performance und Ausgangsstufe.
   https://www.analog.com/media/en/technical-documentation/data-sheets/adcmp606_607.pdf
   Die breite Overdrive-Tabellenangabe (2,3 ns) wird gegenüber der knappen Überblicksaussage
   ausdrücklich berücksichtigt. Typischer Jitter unter speziellen Bedingungen ist kein Systemwert.
4. **S4 - Analog Devices ADCMP580/581/582**, Datenblatt Rev. B.
   https://www.analog.com/media/en/technical-documentation/data-sheets/ADCMP580_581_582.pdf
   Vergleichskandidat; Versorgung und unterschiedliche Ausgangspegel geprüft.
5. **S5 - Texas Instruments DAC80501**, Produktseite und Datenblatt Rev. E.
   https://www.ti.com/product/DAC80501
   https://www.ti.com/lit/ds/symlink/dac80501.pdf
   Interne Referenz, Ausgangsbereiche, SPI/I2C; Referenz-Tempco ist nicht Gesamtfehler des Frontends.
6. **S6 - Texas Instruments UCC27511**, Produktseite und Datenblatt.
   https://www.ti.com/product/UCC27511
   https://www.ti.com/lit/gpn/UCC27511
   Versorgungsbereich und typische Verzögerung; Gate-Treiberfunktion ist kein Nachweis für SPAD-AQC.
7. **S7 - NIST TN1297**, Combined Standard Uncertainty / Komponenten.
   https://www.nist.gov/pml/nist-technical-note-1297/nist-tn-1297-5-combined-standard-uncertainty
   https://www.nist.gov/pml/nist-technical-note-1297/nist-tn-1297-2-classification-components-uncertainty
   Grundlage für Unsicherheitsfortpflanzung; eigene Implementierung ist approximativ.
8. **S8 - NIST Dataplot**, Exact Binomial Confidence Limits.
   https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbici.htm
   Grundlage der CP-Ränder; Bonferroni-Verknüpfung ist hier explizit eigene Ableitung.
9. **S9 - Bestehender Projektstand**, Photonische_Messkette_v0_1_Digitalkern.zip und
   Photonische_Messkette_v0_1_Auswertung.zip. Inhalt im vorherigen Arbeitsschritt gelesen;
   Prüfsummen in SOURCE_PROVENANCE.json. Referenzkern, Kalibrierprotokoll und iid-Grenzen bleiben gültig.

## Eigene, noch zu falsifizierende Entscheidungen

3-V-Pilotpunkt, 8-V-Hub, 2-V-Reserve, 1-us-Startwert, Temperaturzone, alle Laborgates,
elektrische Budgetaufteilung, Quench-/Reset-Funktionsvertrag und die Einspeisearchitektur sind
eigene Entwicklungsentscheidungen. Keine Quelle bestätigt bereits deren gemeinsame Funktion.
Aktuelle Einzelstückpreise und Messgerätezugang wurden nicht festgestellt. Es gibt daher
keine erfundene Kostenobergrenze oder Zusage eines kostenfreien Hardwareaufbaus.
