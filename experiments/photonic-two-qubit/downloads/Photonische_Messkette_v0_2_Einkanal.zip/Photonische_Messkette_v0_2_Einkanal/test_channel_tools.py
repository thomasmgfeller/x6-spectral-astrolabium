import copy
import json
import math
import unittest

from channel_tools import (DECLARATIONS, analyze_timing, budget_variance, cable_swap,
                           cp_limit, design_calculations, followup_excess, load_json)


def fixture(kind="synthetic"):
    return {"schema":"channel-timing.v0.2","data_kind":kind,"run_id":"test-only",
            "calibration_id":"test-cal","reference_id":"synthetic-reference",
            "scope":"electrical_pair","alpha":0.05,"residual_limit_ps":200,
            "declarations":{k:True for k in DECLARATIONS},
            "calibration":{"plus_ps":[110,120,130],"minus_ps":[30,40,50]},
            "type_b_components":[{"name":"drift","u_ps":10},{"name":"reconnect","u_ps":20}],
            "correlation_matrix":[[1,0],[0,1]],
            "validation":[{"id":"d1","reference_delay_ps":1000,"reference_u_ps":5,
                           "delta_ps":[1080,1090,1100],"conditions":{"temperature_C":25}}]}


class NumericalTests(unittest.TestCase):
    def test_swap_sign_and_scale(self):
        r=cable_swap([110,120,130],[30,40,50])
        self.assertEqual(r["offset_ps"],80)
        self.assertEqual(r["branch_asymmetry_ps"],40)
        self.assertAlmostEqual(r["sampling_u_ps"],math.sqrt(100/6))

    def test_shared_component_covariance(self):
        c=[{"name":"x","u_ps":10},{"name":"y","u_ps":20}]
        self.assertAlmostEqual(budget_variance(c,[[1,1],[1,1]]),900)
        self.assertAlmostEqual(budget_variance(c,[[1,0],[0,1]]),500)
        self.assertAlmostEqual(budget_variance(c,[[1,-1],[-1,1]]),100)

    def test_bad_covariance(self):
        c=[{"name":str(i),"u_ps":1} for i in range(3)]
        with self.assertRaises(ValueError):
            budget_variance(c,[[1,.9,.9],[.9,1,-.9],[.9,-.9,1]])

    def test_synthetic_cannot_be_hardware_pass(self):
        r=analyze_timing(fixture())
        self.assertTrue(r["numeric_gate_met"])
        self.assertEqual(r["decision"],"SYNTHETIC_ONLY")
        self.assertFalse(r["hardware_validated"])

    def test_measurement_is_only_conditional(self):
        r=analyze_timing(fixture("measurement"))
        self.assertEqual(r["decision"],"CONDITIONAL_TIMING_CRITERION_MET")
        self.assertFalse(r["hardware_validated"])
        self.assertEqual(r["physical_quantum_claim"],"NOT_ASSESSED")

    def test_nonstationarity_blocks_inference(self):
        x=fixture("measurement"); x["declarations"]["stable_offset_during_run"]=False
        self.assertEqual(analyze_timing(x)["decision"],"MODEL_NOT_ESTABLISHED")

    def test_fixed_bias_cannot_hide_in_small_variance(self):
        x=fixture("measurement"); x["validation"][0]["delta_ps"]=[1380,1380.1,1379.9]
        r=analyze_timing(x)
        self.assertEqual(r["decision"],"TIMING_CRITERION_NOT_MET")
        self.assertGreater(r["validation"][0]["abs_bias_plus_u_ps"],300)

    def test_jitter_is_not_mean_precision(self):
        x=fixture(); x["validation"][0]["delta_ps"]=[580,1580]*5000
        r=analyze_timing(x)
        self.assertTrue(r["numeric_gate_met"])
        self.assertGreater(r["validation"][0]["pair_event_sd_ps"],490)
        self.assertFalse(r["hardware_validated"])

    def test_multiple_points_use_larger_coverage_factor(self):
        x=fixture(); r1=analyze_timing(x)
        q=copy.deepcopy(x["validation"][0]); q["id"]="d2"; x["validation"].append(q)
        r2=analyze_timing(x)
        self.assertGreater(r2["validation"][0]["coverage_factor"],r1["validation"][0]["coverage_factor"])

    def test_independent_validation_reference_used(self):
        x=fixture(); x["validation"][0]["reference_delay_ps"]=2000
        self.assertFalse(analyze_timing(x)["numeric_gate_met"])

    def test_missing_budget_rejected(self):
        x=fixture(); x["type_b_components"]=[]
        with self.assertRaises(ValueError): analyze_timing(x)

    def test_zero_total_uncertainty_rejected(self):
        x=fixture(); x["calibration"]={"plus_ps":[120,120],"minus_ps":[40,40]}
        x["type_b_components"]=[{"name":"zero","u_ps":0}]; x["correlation_matrix"]=[[1]]
        x["validation"][0].update(delta_ps=[1080,1080],reference_u_ps=0)
        with self.assertRaises(ValueError): analyze_timing(x)

    def test_invalid_sample_rejected(self):
        for val in (True,float("nan"),float("inf"),1e18):
            with self.assertRaises(ValueError): cable_swap([0,val],[0,1])

    def test_missing_declaration_rejected(self):
        x=fixture(); del x["declarations"]["reference_calibrated"]
        with self.assertRaises(ValueError): analyze_timing(x)

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(ValueError): load_json('{"a":1,"a":2}')

    def test_zero_count_exact_limit(self):
        self.assertAlmostEqual(cp_limit(0,1000,.05),1-.05**(1/1000))
        self.assertGreater(cp_limit(0,1000,.05),0)

    def test_cp_boundary_and_invalid_counts(self):
        self.assertEqual(cp_limit(10,10,.05),1)
        self.assertEqual(cp_limit(0,10,.05,False),0)
        for k,n in ((True,10),(1,0),(11,10),(-1,10),(0,10**10)):
            with self.assertRaises(ValueError): cp_limit(k,n,.05)

    def test_followup_zero_events_not_zero_risk(self):
        r=followup_excess(0,1000,0,1000)
        self.assertGreater(r["upper95_excess_probability"],0)
        self.assertEqual(r["physical_afterpulse_probability"],"NOT_IDENTIFIED")

    def test_quench_current_dimensional_reference(self):
        r=design_calculations()
        a=r["designs"][0]; b=r["designs"][1]
        self.assertAlmostEqual(a["minimum_below_breakdown_margin_V"],2.5)
        self.assertAlmostEqual(b["minimum_below_breakdown_margin_V"],5.5)
        self.assertEqual(b["candidate_capacitive_loads"][2]["current_mA_at_1_5_ns"],200)
        self.assertEqual(b["candidate_capacitive_loads"][2]["stored_energy_pJ"],4500)

    def test_deadtime_model_saturates_and_includes_dark(self):
        r=design_calculations(); row=r["deadtime_model"][3]
        self.assertAlmostEqual(row["loss_at_20k_total_input"],.02/1.02)
        self.assertAlmostEqual(row["max_observed_rate_per_s_for_1pct_loss"],10000)

    def test_zero_error_sample_size(self):
        n=design_calculations()["zero_errors_trials_for_upper_1e_6_at_95pct"]
        self.assertLessEqual(cp_limit(0,n,.05),1e-6)
        self.assertGreater(cp_limit(0,n-1,.05),1e-6)


if __name__=="__main__":
    unittest.main(verbosity=2)
