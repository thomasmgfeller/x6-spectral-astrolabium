#!/usr/bin/env python3
"""Rebuild the compact German engineering report. Requires reportlab."""
from pathlib import Path
import json
import sys
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable

ROOT=Path(__file__).resolve().parent
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'Photonische_Messkette_v0_2_Pruefbericht.pdf'
OUT.parent.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='DejaVu',boldItalic='DejaVu-Bold')
INK=colors.HexColor('#172A3D'); BLUE=colors.HexColor('#176E87'); GREY=colors.HexColor('#52616E')
LIGHT=colors.HexColor('#EEF4F7'); LINE=colors.HexColor('#CBD8DF'); AMBER=colors.HexColor('#805517')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyD',fontName='DejaVu',fontSize=9.4,leading=14,textColor=INK,spaceAfter=8))
styles.add(ParagraphStyle(name='SmallD',parent=styles['BodyD'],fontSize=8.2,leading=11.8,spaceAfter=6))
styles.add(ParagraphStyle(name='TitleD',fontName='DejaVu-Bold',fontSize=24,leading=29,textColor=INK,spaceAfter=15))
styles.add(ParagraphStyle(name='H1D',fontName='DejaVu-Bold',fontSize=17,leading=23,textColor=INK,spaceAfter=15))
styles.add(ParagraphStyle(name='H2D',fontName='DejaVu-Bold',fontSize=11.3,leading=16,textColor=BLUE,spaceBefore=8,spaceAfter=7))
styles.add(ParagraphStyle(name='EyebrowD',fontName='DejaVu-Bold',fontSize=9,leading=13,textColor=BLUE,spaceAfter=10))
story=[]

def p(text,style='BodyD'):
    story.append(Paragraph(text,styles[style]))
def title(kicker,text):
    p(kicker,'EyebrowD'); p(text,'H1D')
def table(headers, rows, widths):
    cells=[[Paragraph(escape(str(c)),styles['SmallD']) for c in row] for row in [headers]+rows]
    tab=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1)
    tab.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LINEBELOW',(0,0),(-1,0),.7,BLUE),('LINEBELOW',(0,1),(-1,-1),.35,LINE),
        ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8)]))
    story.extend([tab,Spacer(1,10)])
def callout(text):
    t=Table([[Paragraph(text,styles['BodyD'])]],colWidths=[499])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,LINE),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12)]))
    story.extend([t,Spacer(1,10)])

class Diagram(Flowable):
    def __init__(self): Flowable.__init__(self); self.width=499; self.height=176
    def draw(self):
        c=self.canv
        def box(x,y,w,h,label):
            c.setFillColor(LIGHT); c.setStrokeColor(LINE); c.roundRect(x,y,w,h,5,stroke=1,fill=1)
            c.setFillColor(INK); c.setFont('DejaVu',8.2)
            lines=label.split('|')
            for i,line in enumerate(lines): c.drawCentredString(x+w/2,y+h/2+(len(lines)-1)*5-i*11-3,line)
        def arrow(points):
            c.setStrokeColor(BLUE); c.setLineWidth(1.2)
            for (x,y),(xx,yy) in zip(points,points[1:]): c.line(x,y,xx,yy)
            x,y=points[-1]; a,b=points[-2]; import math
            angle=math.atan2(y-b,x-a)
            for theta in [angle+2.6,angle-2.6]: c.line(x,y,x+6*math.cos(theta),y+6*math.sin(theta))
        box(0,120,114,42,'Biasquelle|strombegrenzt')
        box(0,41,114,48,'SPAD|und Stromabgriff')
        box(161,41,140,48,'Schutz und|Diskriminator')
        box(358,117,141,45,'Zeitmarkenpfad|externe Referenz')
        box(358,3,141,49,'Lokaler Quench-|Timer und Treiber')
        box(163,120,136,42,'DAC-Schwelle|während Lauf statisch')
        arrow([(57,120),(57,89)])
        arrow([(114,65),(161,65)])
        arrow([(231,120),(231,89)])
        arrow([(301,73),(328,73),(328,139),(358,139)])
        arrow([(301,57),(330,57),(330,28),(358,28)])
        arrow([(358,14),(138,14),(57,14),(57,41)])
        c.setFillColor(GREY); c.setFont('DejaVu',7.3); c.drawString(155,1,'Physischer Bias wird unter Durchbruch gehalten')

calc=json.loads((ROOT/'reports/design_calculations.json').read_text())
good=json.loads((ROOT/'reports/synthetic_within_budget.json').read_text())
bad=json.loads((ROOT/'reports/synthetic_hidden_bias.json').read_text())

p('THOMAS GFELLER  /  PHOTONISCHE MESSKETTE','EyebrowD')
p('Ein Detektorkanal,<br/>prüfbar entwickelt.','TitleD')
p('Entwicklungspaket v0.2 · 11. Oktober 2026')
callout('<b>Status:</b> Architektur und Rechenwerkzeuge erstellt; 21 Softwaretests bestanden. '
        '<b>Keine Hardwaremessung und keine Fertigungsfreigabe.</b> Alle Beispieldaten sind synthetisch.')
p('Die nächste Stufe ist ein charakterisiertes Frontend für die spätere photonische Messkette. '
  'Der Raspberry Pi übernimmt Konfiguration und Auswertung. Die schnelle Reaktion bleibt in lokaler Hardware.')
p('Die Arbeitsentscheidung','H2D')
table(['Baustein','Festlegung für den nächsten Versuch'],[
    ['Detektor','C30902SH als vorläufiger Kandidat; sichtbares/NIR-Licht, 800 nm als Planungswert.'],
    ['Pilotbetrieb','3 V über individuell gemessenem Durchbruch; 8 V Quenchhub als Entwurfsziel.'],
    ['Haltezeit','Einstellbar, zunächst 1 us; 100 ns werden nicht als ausreichend vorausgesetzt.'],
    ['Messkette','Zeitmarke vor Hold-off-Timer; unabhängige elektrische und optische Prüfung.'],
],[105,394])
story.append(Diagram()); story.append(Spacer(1,10))
p('Funktionsdarstellung. Schutzbeschaltung, Stromabgriff, Treiberanbindung und Empfängerpegel '
  'müssen vor einem Aufbau als vollständiger Schaltplan geprüft werden.','SmallD')
story.append(PageBreak())

title('01 / BAUTEILE UND BETRIEBSPUNKT','Frugalität beginnt beim Betriebspunkt')
p('Der niedrige Überspannungsbetrieb senkt den benötigten Quenchhub. Er kann zugleich die '
  'Photoneneffizienz verringern. Diese wird gemessen; Datenblattwerte bei anderem Betriebspunkt '
  'werden nicht übernommen. Die Literatur belegt diskrete AQC bei niedriger Überspannung, '
  'validiert aber nicht unseren neuen Aufbau. [S1, S2]')
table(['Funktion','Kandidat','Grenze der Aussage'],[
    ['Detektor','C30902SH','Ungekühlter Lernaufbau. Dunkelrate kann spätere Kühlung oder anderen Detektor erzwingen.'],
    ['Schwelle','DAC80501','Interne Referenz; 1,25-V-Bereich. Gesamtrauschen und Offset am Komparatorpin messen.'],
    ['Zeitmarke','ADCMP607','CML. Die breite Overdrive-Tabelle enthält 2,3 ns; kein pauschaler 50-ps-Nachweis.'],
    ['Vergleich','ADCMP580','Andere Versorgung und Ausgangspegel; anspruchsvollere Vergleichsstufe.'],
    ['Quench','UCC27511','Nur Ersatzlast-Kandidat. Typisch 13 ns Treiberdelay; keine Zusage einer 1,5-ns-AQC.'],
],[77,101,321])
p('Was wir bewusst korrigieren','H2D')
p('Ein RF-Kleinsignaltransistor ersetzt keinen passenden Spannungstreiber. Eine Referenzdiode '
  'macht einen versorgungsreferenzierten DAC nicht automatisch präzise. Eine kurze Pulsdauer '
  'garantiert weder kleine Nachpulse noch eine definierte vollständige Detektorerholung.')
p('Die Zustände sind festgelegt','H2D')
p('<b>ARMED → QUENCH → HOLD → RESET/SETTLE → ARMED.</b> Während HOLD verlängern weitere '
  'Trigger die Sperre nicht. Resettransienten dürfen keinen neuen Ausgangsklick erzeugen. '
  'Ein Fehler sperrt die Biasfreigabe. Der sichere Zustand darf nicht allein von Hostsoftware abhängen.')
callout('<b>Offenes Schaltplangate:</b> Sense-Netzwerk und Quench-Einkopplung müssen zusammen '
        'dimensioniert werden. Ein niederohmiger Treiber direkt am Sense-Knoten könnte das Nutzsignal '
        'unterdrücken. Die Blockarchitektur ist noch keine Verdrahtungsanleitung.')
p('Bestellungen, aktuelle Einzelstückpreise und Lieferfähigkeit wurden nicht festgestellt. '
  'Die Auswahl ist eine überprüfbare Entwicklungsentscheidung, keine freigegebene Stückliste.','SmallD')
story.append(PageBreak())

title('02 / RECHNUNG','Spannungsreserve und Zählverlust')
p('Die folgenden Zahlen sind eigene Modellrechnungen mit offengelegten Annahmen. Sie ersetzen '
  'weder eine Transientenrechnung des Schaltplans noch Messungen am Detektor.')
p('Quenchreserve des Pilotpunkts','H2D')
table(['Beitrag','Angenommener Wert'],[
    ['Nominaler Quenchhub','8,0 V'],['Maximale Überspannung inkl. Fehlerbudget','3,5 V'],
    ['Treiberverlust / Ringing-Budget','1,0 V / 1,0 V'],
    ['Verbleibende Reserve unter Durchbruch','8 - 1 - 1 - 3,5 = 2,5 V'],
    ['Abnahmeziel','Gemessene Mindestreserve minus Unsicherheit >= 2 V'],
],[320,179])
p('Kapazitiver Spitzenstrom','H2D')
p('<b>I = C · ΔV / Δt.</b> Für 10 pF Gesamtlast und den reinen Vergleich bei 1,5 ns ergeben '
  'sich 53,3 mA bei 8 V und 200 mA bei 30 V. Tastkopf, Pads und Schutznetzwerk gehören zur Last. '
  'Der ausgewählte Treiber muss diese Flanke erst nachweisen; 1,5 ns ist keine Zusage.')
p('Totzeit setzt das Ratenbudget','H2D')
rows=[]
for index in [0,2,3,4,6]:
    r=calc['deadtime_model'][index]
    rows.append([str(r['deadtime_ns']),f"{r['max_observed_rate_per_s_for_1pct_loss']:,.0f}".replace(',',' '),f"{100*r['loss_at_20k_total_input']:.2f}%",f"{100*r['loss_at_80k_total_input']:.2f}%"])
table(['Totzeit / ns','Max. beobachtet / s¹','Verlust bei 20k²','Verlust bei 80k²'],rows,[84,159,128,128])
p('¹ Für höchstens 1% Verlust. ² Gesamtrate vor Totzeit, einschliesslich Dunkelereignissen. '
  'Modell: konstante nicht verlängernde Totzeit und stationäre Poisson-Ankunft.','SmallD')
callout('Bei <b>1 us</b> ergeben 20 kcps schon <b>1,96%</b> Verlust. Längere Haltezeiten können '
        'Nachpulse reduzieren und gleichzeitig die nutzbare Rate begrenzen. Beide Effekte werden gemeinsam geprüft.')
story.append(PageBreak())

title('03 / LABOR','Messbare Gates statt zugesagter Präzision')
p('Alle Gates sind NOT_RUN. Die Zahlen sind vorläufige, vor Beginn einzufrierende Projektziele. '
  'Das vollständige Protokoll im ZIP enthält Versuchsreihen, Kontrollfenster und Bezugsebenen.')
table(['Gate','Messung','Kriterium / Konsequenz'],[
    ['K0','Ersatzlast 2/5/10/20 pF','Hub, Ringing, Rückkopplung und Startzustände. Erst danach SPAD-Anschluss.'],
    ['K1a','Elektrische Erfassung','Pro kritischem Punkt >=2.995.731 unabhängige Pulse ohne Fehler für CP-Obergrenze <=1e-6 bei 95%.'],
    ['K1b','Einzelereignis-Streuung','50 ps RMS elektrische Paarstreuung als Ziel; eigener Unsicherheitsnachweis erforderlich.'],
    ['K2','Unabhängige Referenzdelays','Abs(Restabweichung)+U <=200 ps über vorab bestimmte Bedingungen.'],
    ['K3','Realer Bias und Erholung','>=2 V Reserve unter Durchbruch inkl. Unsicherheit; Erholung mit optischem Puls-Paar prüfen.'],
    ['K4','Dunkelrate / Nachlauf / Rate','Nachlauf-Exzess-Obergrenze <=0,5% im definierten Fenster; Totzeitverlust <=1% im begründeten Modell.'],
    ['K5','Vier Stunden Mechanik','Quellnormierte optische Transmission: Änderung <=2% als Pilotziel.'],
],[50,150,299])
p('Keine Verwechslung der Nachweise','H2D')
p('Elektrische Einspeisung direkt am TDC umfasst keinen Detektor. Einspeisung vor dem '
  'Diskriminator umfasst noch keinen optischen Timingjitter. Erst die optische Referenzmessung '
  'charakterisiert die gesamte Detektionskette.')
p('Die nominelle Haltezeit ist nicht die effektive Totzeit. Die gemessene Erholungskurve bestimmt, '
  'wann die Detektionswahrscheinlichkeit wieder ihr Plateau erreicht. Ein gewöhnlicher Synchronizer '
  'ist keine ps-Zeitdigitalisierung.')
p('Der Nullfehler-Grenzwert in K1a gilt einzeln. Für gemeinsame Aussagen über mehrere Punkte '
  'muss die Fehlerwahrscheinlichkeit aufgeteilt und die Stichprobe vergrössert werden.','SmallD')
story.append(PageBreak())

title('04 / SOFTWARE','Die Rechnung erkennt auch Gegenbeispiele')
p('Die neue Auswertung ergänzt den vorhandenen Digitalkern. Sie schreibt keine LUT und '
  'verändert keine Hardware. Referenz- und Validierungsdaten werden getrennt eingegeben.')
table(['Prüfung','Tatsächliches Ergebnis'],[
    ['Softwaretests','21 von 21 bestanden; Testprotokoll und Laufumgebung im ZIP.'],
    ['Synthetisches Beispiel innerhalb Budget',f"Grösster Wert abs(Bias)+U: {max(v['abs_bias_plus_u_ps'] for v in good['validation']):.2f} ps. Status SYNTHETIC_ONLY."],
    ['Synthetisches Beispiel mit verstecktem Bias',f"Grösster Wert: {max(v['abs_bias_plus_u_ps'] for v in bad['validation']):.2f} ps. Numerisches Kriterium verfehlt."],
    ['Fehlerfälle','Ungültige Kovarianz, fehlende Unsicherheit, NaN, doppelte JSON-Schlüssel und falsche Zähler werden zurückgewiesen.'],
],[210,289])
p('Was berechnet wird','H2D')
p('Kabeltausch liefert den Offset aus dem Mittel der beiden Anordnungen. Unabhängige '
  'Referenzverzögerungen liefern anschliessend die Restabweichungen. Kalibrierstatistik, '
  'Validierungsstatistik, Referenz- und weitere Standardunsicherheiten werden zusammengeführt. '
  'Eine Korrelationsmatrix erlaubt abhängige Budgetbeiträge.')
p('Der Faktor für die erweiterte Unsicherheit nutzt eine angenäherte GUM-/Welch-Rechnung und '
  'Bonferroni über die vorab festgelegten Validierungspunkte. Es ist keine exakte oder '
  'verteilungsfreie 95%-Garantie. Stationarität, geeignete Verteilungsmodelle und vollständige '
  'Unsicherheitsbeiträge müssen experimentell begründet sein. [S7]')
p('Die Klickstatistik bleibt getrennt','H2D')
p('Die Clopper-Pearson-Auswertung von n00/n10/n01/n11 ist bereits in v0.1 vorhanden. '
  'Neu ist eine zusätzliche Schranke für den Nachlauf-Exzess gegenüber Kontrollfenstern. '
  'Auch sie identifiziert nicht automatisch die intrinsische Nachpulswahrscheinlichkeit. [S8]')
callout('<b>Reproduzierbar:</b> Beispiele verwenden Seed 104729. Rohdaten, Berichte, Quellcode, '
        'Tests und Prüfsummen liegen bei. <b>hardware_validated</b> bleibt in allen Ausgaben false.')
story.append(PageBreak())

title('05 / WEITERARBEIT','Der nächste reale Nachweis ist klar begrenzt')
p('<b>Jetzt:</b> vollständigen Ein-Kanal-Schaltplan aus dem Funktionsvertrag ableiten und '
  'die Ersatzlast-/Schutzprüfung durchführen. <b>Danach:</b> SPAD individuell charakterisieren, '
  'Quench-/Resetverhalten und optische Erholung messen. <b>Anschliessend:</b> TDC und H/A/B '
  'integrieren und das Experimentfehlerbudget schliessen.')
p('Die Unterlagen enthalten ausdrücklich noch keine Gerberdateien. Ohne geprüfte Sense-/Quench-'
  'Schaltung, Empfängerpegel, tatsächlichen Stackup und transiente Nachweise wären solche '
  'Dateien keine belastbare Fertigungsgrundlage.')
p('Primärquellen und bestehender Stand','H2D')
sources=[
('S1','Excelitas C30902SH, Datenblatt Rev. 2022.02','https://www.excelitas.com/product/c30902sh-si-apd-05mm-18-photon-counting'),
('S2','Stipcevic, diskrete AQC, Volltext','https://arxiv.org/html/0805.2727v1'),
('S3','Analog Devices ADCMP606/607, Rev. C','https://www.analog.com/media/en/technical-documentation/data-sheets/adcmp606_607.pdf'),
('S4','Analog Devices ADCMP580/581/582, Rev. B','https://www.analog.com/media/en/technical-documentation/data-sheets/ADCMP580_581_582.pdf'),
('S5','Texas Instruments DAC80501','https://www.ti.com/product/DAC80501'),
('S6','Texas Instruments UCC27511','https://www.ti.com/product/UCC27511'),
('S7','NIST, kombinierte Standardunsicherheit','https://www.nist.gov/pml/nist-technical-note-1297/nist-tn-1297-5-combined-standard-uncertainty'),
('S8','NIST, exakte Binomialgrenzen','https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbici.htm')]
for ref,name,url in sources:
    p(f'<b>{ref}</b> · <link href="{url}" color="#176E87">{escape(name)}</link>','SmallD')
p('Vollständige Quellen-URLs, Prüfumfang und Herkunft der v0.1-Dateien stehen im ZIP. '
  'Herstellerangaben und Literatur belegen einzelne Eigenschaften; die Funktion unseres '
  'Gesamtsystems bleibt nachzuweisen.','SmallD')
p('Inhalt des Arbeitspakets','H2D')
p('Entwurfsbeschreibung · Laborprotokoll · Python-Werkzeuge · 21 Tests · synthetische Beispiele '
  'mit Negativfall · Rechenergebnisse · leere Laborvorlage · Quellen und Prüfsummen.')
callout('<b>Erreichter Stand:</b> Ein konkreter Entwicklungsversuch mit prüfbaren Annahmen und '
        'automatisierter Auswertung ist vorbereitet. Ein vermessener Detektor oder ein funktionsfähiger '
        'Quantencomputer wird damit noch nicht behauptet.')

def footer(canvas,doc):
    canvas.saveState(); w,h=A4
    canvas.setStrokeColor(LINE); canvas.line(48,42,w-48,42)
    canvas.setFont('DejaVu',7.5); canvas.setFillColor(GREY)
    canvas.drawString(48,29,'Photonische Messkette v0.2 | Entwicklungsstand, keine Hardwarefreigabe')
    canvas.drawRightString(w-48,29,str(doc.page)); canvas.restoreState()

doc=SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=43,bottomMargin=57,
                      title='Photonische Messkette v0.2 - Ein-Kanal-Prüfbericht',author='Thomas Gfeller / Entwicklungsassistenz')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
