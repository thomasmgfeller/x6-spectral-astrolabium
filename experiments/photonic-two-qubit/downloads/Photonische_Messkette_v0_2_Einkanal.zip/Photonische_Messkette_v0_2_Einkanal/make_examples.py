#!/usr/bin/env python3
"""Reproducible demonstration data. Every generated dataset is synthetic."""
import copy
import hashlib
import json
from pathlib import Path
import random
from channel_tools import DECLARATIONS, analyze_timing, design_calculations, followup_excess

ROOT=Path(__file__).resolve().parent

def write(path,obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")

def main():
    rng=random.Random(104729)
    def draw(mu,sd,n=800): return [round(rng.gauss(mu,sd),6) for _ in range(n)]
    record={"schema":"channel-timing.v0.2","data_kind":"synthetic","run_id":"synthetic-104729",
            "calibration_id":"synthetic-cal-01","reference_id":"synthetic-delays",
            "scope":"electrical_pair","alpha":.05,"residual_limit_ps":200,
            "declarations":{k:True for k in DECLARATIONS},
            "calibration":{"plus_ps":draw(120,30),"minus_ps":draw(40,30)},
            "type_b_components":[{"name":"reconnection","u_ps":15},
                                  {"name":"residual_temperature","u_ps":15},
                                  {"name":"unresolved_TDC_nonlinearity","u_ps":20}],
            "correlation_matrix":[[1,0,0],[0,1,0],[0,0,1]],
            "validation":[{"id":str(i),"reference_delay_ps":d,"reference_u_ps":10,
                           "delta_ps":draw(d+80+b,30),
                           "conditions":{"temperature_C":25,"input_rate_Hz":10000,
                                         "amplitude_mV":200,"threshold_mV":30}}
                          for i,(d,b) in enumerate([(-1000,5),(0,10),(1000,-5),(12000,15)])]}
    for name,bias in (("synthetic_within_budget",0),("synthetic_hidden_bias",300)):
        obj=copy.deepcopy(record)
        obj["run_id"]=name
        if bias:
            obj["validation"][2]["delta_ps"]=[x+bias for x in obj["validation"][2]["delta_ps"]]
        target=ROOT/"examples"/(name+".json")
        write(target,obj)
        result=analyze_timing(obj); result["input_sha256"]=hashlib.sha256(target.read_bytes()).hexdigest()
        write(ROOT/"reports"/(name+".json"),result)
    write(ROOT/"reports"/"design_calculations.json",design_calculations())
    write(ROOT/"reports"/"followup_synthetic.json",{
        "data_kind":"synthetic","hardware_validated":False,
        "zero_followups":followup_excess(0,1000,0,1000),
        "excess_followups":followup_excess(150,10000,10,10000)})

if __name__=="__main__": main()
