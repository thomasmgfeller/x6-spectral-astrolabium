# Photonische Messkette v0.2 - Ein-Kanal-Entwicklung

Stand: 11. Oktober 2026. Entwicklungsentscheidung, Rechenwerkzeuge und Laborprotokoll.
Status: **berechnet und softwaregeprüft; keine Hardwaremessung, keine Fertigungsfreigabe**.

## Was jetzt konkret vorliegt

- C30902SH als vorläufiger, diskreter Si-SPAD-Kandidat für einen Ein-Kanal-Lernaufbau.
- Niedrige Überspannung als erster Betriebspunkt: Vex = 3 V; Quenchhub-Ziel 8 V.
- Getrennter Zeitmarkenpfad und lokaler, nicht verlängernder Quench-/Resetpfad.
- Konkrete Kandidatenprüfung für Komparator, DAC und Treiber; offene Schaltungsrisiken benannt.
- Rechenmodell für Spannungsreserve, kapazitive Stromspitzen und Totzeitverluste.
- Auswertung von Kabeltausch und unabhängigen Referenzverzögerungen mit Unsicherheitsbudget.
- 21 ausgeführte Softwaretests; synthetische positive und negative Beispiele.
- Messreihen und eine leere Laborvorlage, die keine fehlenden Daten als bestanden ausgibt.

Das ist eine vorgelagerte Entwicklungsstufe für einen photonischen Quantenkern. Die Software
steuert keine reale Hochspannung, keinen Detektor und kein Messgerät. Es wurde nichts bestellt.
Die vorhandene VHDL- und Klickstatistik-v0.1 wird nicht verändert oder durch diese Werkzeuge ersetzt.

## Ausführen

Python 3.11 oder neuer; die tatsächlich verwendeten Paketversionen stehen in requirements-tested.txt.

```bash
python3 -m pip install -r requirements-tested.txt
python3 -m unittest -v test_channel_tools
python3 make_examples.py
python3 channel_tools.py design --output reports/design_calculations.json
python3 channel_tools.py timing examples/synthetic_within_budget.json --output reports/timing_cli.json
```

Der CLI-Exitcode 0 bedeutet nur, dass eine Berechnung abgeschlossen wurde. Die Entscheidung steht
im JSON. Exitcode 2 bedeutet ungültige Eingabe. SYNTHETIC_ONLY ist niemals eine Hardwareabnahme.
Vollständige Rohdaten bleiben erhalten; Ausgaben dürfen die Eingabedatei nicht überschreiben.
Keine Online-Abfragen oder API-Kosten im Rechenbetrieb. Paketinstallation kann Netzwerk benötigen.

## Dateien

- `DESIGN.md`: Entwicklungsentscheidungen, Funktionsvertrag, Blockschaltbild und PCB-/Mechanikvorgaben.
- `LAB_PROTOCOL.md`: konkrete, gestufte Laborabnahme und Messgrössen.
- `channel_tools.py`: Rechenwerkzeuge; keine Hardwaretreiber.
- `make_examples.py`: deterministische Beispiele, Seed 104729.
- `test_channel_tools.py`: Grenzfälle und wissenschaftliche Fehlinterpretationen.
- `templates/lab_record.json`: leere Messvorlage, ausdrücklich unvollständig.
- `examples/`: ausschliesslich synthetische Zeitdifferenzen.
- `reports/`: ausgeführte Beispielauswertungen, Rechenwerte, Testprotokoll und Laufumgebung.
- `SOURCES.md`: Hersteller- und Methodenquellen mit Prüfumfang.
- `SOURCE_PROVENANCE.json`: Prüfsummen der bereits vorhandenen v0.1-Pakete.
- `SHA256SUMS.txt`: Prüfsummen der ausgelieferten Dateien, ausser dieser Prüfsummenliste.

## Was die Zeitrechnung tatsächlich prüft

Eingabe sind ZeitDIFFERENZEN in ps, keine grossen absoluten Epochentimestamps.
Kabeltausch: o_hat = (mean(plus)+mean(minus))/2. Der Zweigtausch muss vollständig sein.
Für jeden unabhängigen Validierungspunkt wird der bekannte Referenzdelay und o_hat abgezogen.
Prüfmetrik ist abs(Restabweichung) + U <= 200 ps. U enthält Kalibrierstatistik, Validierungsstatistik,
die Referenzunsicherheit und die angegebenen Type-B-Standardunsicherheiten mit Korrelationsmatrix.
Diese Komponenten müssen in bereits ausgangsäquivalente ps umgerechnet sein; Vorzeichen der
Sensitivitätskoeffizienten müssen in der Korrelationsmatrix berücksichtigt sein.

Das Werkzeug verwendet eine angenäherte GUM-/Welch-Satterthwaite-Rechnung. Type-B-Beiträge werden
als normalverteilt mit grossen Freiheitsgraden modelliert. Die effektiven Freiheitsgrade sind
approximativ. Für m vorab bestimmte Validierungspunkte wird der zweiseitige Faktor mit alpha/m
berechnet. Gemeinsame Kalibrierfehler zwischen Punkten verletzen Bonferroni nicht; seine Aussage
bleibt aber an die Gültigkeit der einzelnen angenäherten Intervalle gebunden. Nicht als exakte,
verteilungsfreie 95%-Garantie interpretieren. Kalibrier-, Validierungs- und Type-B-Teile sind
untereinander unabhängig angenommen; komplexere gemeinsame Unsicherheiten erfordern ein
erweitertes Modell. Referenzbeiträge nicht zugleich unter Type B und pro Punkt doppelt eintragen.

Die Streuung einzelner Paarereignisse wird separat berichtet. Sie wird weder durch sqrt(2)
geteilt noch in einen vermeintlich bestandenen 50-ps-Einzelkanalnachweis umgedeutet.
Metadaten sind Erklärungen des Messenden; das Werkzeug kann deren Wahrheit nicht überprüfen.
Es setzt auch bei echten Messdaten nie `hardware_validated=true`.

## Nachpulsdiagnostik

`followup_excess` berechnet aus Treffern in vorab fixierten Nachlauf- und Kontrollfenstern eine
konservative einseitige Schranke auf max(0, p_followup - p_control), mit zwei CP-Grenzen und
Bonferroni alpha/2. Trials müssen innerhalb jeder Gruppe iid sein. Identische Fenster und
vergleichbare Lebendzeit sind experimentell zu begründen. Diese Grösse ist keine automatische
Bestimmung der intrinsischen Nachpulswahrscheinlichkeit. Nachpulskaskaden, Primärselektion,
Sättigung und Hintergrund können das Modell verletzen. Bei Abhängigkeiten ist ein separates,
blockweises oder zeitprozessbasiertes Modell nötig.

## Wichtigster nächster physischer Schritt

Zuerst den Quench-Treiber an einer nachgebildeten kapazitiven Last charakterisieren und den
Messpfad elektrisch injizieren. Erst nach dokumentierter Schutz-, Überschwing- und Rückkopplungs-
prüfung einen realen SPAD anschliessen. Schaltplan-/Bauteilfreigabe dafür bleibt ein eigenes Gate.
Ohne Laborzugang können diese Schritte nicht als ausgeführt gelten.

## PDF reproduzieren (optional)

`python3 -m pip install -r requirements-report.txt`, danach `python3 make_pdf.py`.
Der Renderer nutzt DejaVu Sans unter `/usr/share/fonts/truetype/dejavu/`; bei einem anderen
Betriebssystem die beiden Fontpfade im Renderer auf lokal installierte Schriftdateien setzen.
Die wissenschaftlichen Rechenwerkzeuge benötigen den PDF-Renderer nicht.
