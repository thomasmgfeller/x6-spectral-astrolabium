# CST-DUST · Erster Lauf zur Enduhr und physikalischen Paarung

Die Studie prüft zwei aus der Normgleichung konstruierte Referenzpaarungen, ihre kohärente Paketauslese und die Auswahl des N14-Transfers t. Der Projektstand ist [2770f28](https://github.com/thomasmgfeller/x6-spectral-astrolabium/commit/2770f280ddcab063b925813170dc87c58a8b3821). Die Theorie, der Solver und der Audit wurden zunächst getrennt ausgearbeitet. Alle neuen Rechnungen verwenden die Python-Standardbibliothek. Es gab keine neuen 4D-Ensembles, Zufallsziehungen oder bezahlten Rechenjobs.

## Wiederholen

Paket entpacken, mit Python 3.10 oder neuer ausführen.

```sh
python3 -B start.py
```

Das Startskript kontrolliert die übernommenen Originaldaten und startet jede Rechnung neu. Es vergleicht die rationalen Solver- und Auditdaten mit den beigelegten Ergebnissen und prüft die Übereinstimmung des komplexen Kreuzterms mit dem Anfangsprodukt. Die klassische RK4-Kontrolle und die Gleitkommaauswertung der Wirkungsphasen tragen getrennte numerische Toleranzen.

## Ergebnisse und Reichweite

- **theorie/** enthält die Herleitung der gesamten positiven, klassendiagonalen Normdichten des gewählten N≤2-Kerns im endlichen Fenster. Zwei unterschiedliche Anfangsmetriken sind mit den vorhandenen Norm- und Schnittbedingungen verträglich. Auf dem vollständigen Raum markierter Historien kann man entweder den Roh-Amplitudenkern im zeitabhängig gewichteten Produkt verwenden oder die Normgewichte in den Kern verschieben. Die Zeilenmatrix auf vier Typen beschreibt die resultierenden Wahrscheinlichkeiten.
- **numerik/** enthält sechs Parameterfälle, davon zwei primäre. Die 502 Vergleiche pro Fall für das lange Gitter zählen sämtliche Zerlegungen über alle Endpunktpaare einschliesslich der Direktwege. Das kurze Gitter ist darin enthalten. Der zusätzliche kohärente Registertest benutzt ein eigens deklariertes Hilfsregister.
- **audit/** enthält das unabhängige Experiment mit zwei überlappenden Einerelementpaketen, vier relativen Präparationsphasen und einem festen frühen Ereignis. Der komplexe Kreuzterm bleibt über drei Enduhrwerte stabil. Er stammt aus der Überlappung zweier Präparationen. Die Wirkungsphase einer gegebenen Historie kürzt sich im Produkt mit ihrem konjugierten Zweig heraus.
- **zusatz.py** rekonstruiert die beiden N14-Präfixspalten über sechs Permutationen und prüft die Empfindlichkeit der gewichteten F₄-Zeile. Im N≤2-Zweipfadversuch berechnet es die Wirkungsdifferenzen auf beiden Ordnungen. Der materielle Kontrollarm wertet den Staubanteil auf der Antikette mit denselben Uhren und Dichtemarken aus. Weitere Arme schalten Gravitationsphase, Staubphase und beide getrennt bzw. gemeinsam ab. Die Auslese im diagonalen Pfadprodukt ist blind für diese Wirkungsphasen. Das Paket kontrolliert ausserdem den N11-Archivvergleich, Speicherpermutationen und synthetische Kleinvolumen-Tails.
- Der klassische Pilot integriert die P3-Gleichung für M=1 mit RK4 auf 128 Schritten neu und prüft alle 20 analytischen Werte gegen das archivierte Euler-Intervall. Die 128 Schritte sind eine Zeitauflösung für die klassische Rechnung. Die physikalische Basisdichte, die Längenskalen, die kalibrierten Messoperatoren und der gekoppelte physikalische Transport bleiben offen. Die kleinste vorgesehene P3-Kohorte kann nach der Zulassung 38 von 524 Vergleichen beliefern.
- **quellen.json** dokumentiert die einzelnen Originaldateien mit Pfad und SHA-256. Der Bericht **CST_DUST_Uhrpaarung_Erster_Lauf.pdf** fasst die Resultate zusammen.
