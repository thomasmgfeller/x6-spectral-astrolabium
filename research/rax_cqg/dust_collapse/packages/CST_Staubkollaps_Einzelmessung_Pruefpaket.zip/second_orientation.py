"""Run the fixed second full high-density cohort, with a separate master seed."""
import csv,json,os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import high_full as hf
def worker(i):
    hf.cfg=json.loads(Path('second_orientation.json').read_text())
    return hf.work(i)
if __name__=='__main__':
    hf.compile_kernel()
    cfg=json.loads(Path('second_orientation.json').read_text())
    with open('high_second.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','7'))) as pool:
        wr=csv.writer(f);wr.writerow(['run','n','endpoints','raw','wall_seconds'])
        for r in pool.map(worker,range(cfg['reps'])):wr.writerow(r);f.flush()
