"""Descriptive summaries and distinct one-sided limits for the two direct cohorts."""
from analyze import read,upper,expect,summary,write
import numpy as np
def main():
    result=[]
    for j,path in [(1,'high_full.csv'),(0,'high_second.csv')]:
        r=read(path)
        assert len(r)==16 and len({row['run'] for row in r})==16
        ref=expect[j,600000];pred=float(ref['Rpred'])
        x=np.array([float(x['raw']) for x in r])/pred
        hits=int((abs(x-1)<=.1).sum())
        result.append(dict(j=j,P=ref['P'],F=ref['F'],lam=600000,n=len(x),Rpred=pred,
                           exact_mean=ref['corrected_mean'],**summary(x),hits=hits,upper99=upper(hits,len(x),.01),
                           minimum=x.min(),maximum=x.max(),min_events=min(int(a['n']) for a in r),
                           max_events=max(int(a['n']) for a in r),se=x.std(ddof=1)/np.sqrt(len(x))))
    write('direct_high_summary.csv',result)
    print(*result,sep='\n')
if __name__=='__main__':main()
