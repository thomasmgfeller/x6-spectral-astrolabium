"""Distribution-free simultaneous bounds and descriptive single-realization summaries."""
import csv,json,math
from pathlib import Path
import numpy as np
from scipy.stats import beta
from cap_cases import cap_parameters,lattice
cfg=json.loads(Path('design.json').read_text())
def read(p):return list(csv.DictReader(open(p)))
def write(p,rows):
    with open(p,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def lower(k,n,alpha):return 0. if k==0 else float(beta.ppf(alpha,k,n-k+1))
def upper(k,n,alpha):return 1. if k==n else float(beta.isf(alpha,k+1,n-k))
def summary(x):
    return dict(mean=x.mean(),sd=x.std(ddof=1),rmse=np.sqrt(np.mean((x-1)**2)),median=np.median(x),
                q05=np.quantile(x,.05),q95=np.quantile(x,.95),negative=int((x<0).sum()))
expect={(int(r['j']),int(r['lam'])):r for r in read('expectations.csv')}
alpha=.01/(2*4+len(cfg['cap']['densities'])*2*len(cfg['cap']['difference_thresholds']))
def gselect(r,j,lam):return [x for x in r if int(x['j'])==j and int(x['lam'])==lam]
def analyze():
    ful=read('full.csv');caps=read('caps.csv')
    assert len(ful)==640 and len(caps)==512
    one=[];tally=[];bound=[]
    for j,(p,f) in enumerate(cfg['windows']):
        for lam in cfg['full']['densities']:
            cell=gselect(ful,j,lam);n=cfg['full']['reps']
            assert len(set(int(r['run']) for r in cell))==len(cell)==n
            rp=float(expect[j,lam]['Rpred']);x=np.array([float(r['raw']) for r in cell])/rp
            k=int((abs(x-1)<=.1).sum())
            one.append(dict(j=j,P=p,F=f,lam=lam,reps=n,predicted=rp,expected=float(expect[j,lam]['corrected_mean']),
                            **summary(x),hits=k,hit_lo=lower(k,n,alpha),hit_hi=upper(k,n,alpha)))
        for lam in cfg['cap']['densities']:
            cell=gselect(caps,j,lam);n=cfg['cap']['reps']
            assert len(set(int(r['run']) for r in cell))==len(cell)==n
            rp=float(expect[j,lam]['Rpred']);mean=float(expect[j,lam]['corrected_mean'])
            dif=np.array([float(r['A0'])-float(r['A1']) for r in cell])/rp
            q0,q1,qb,radius=cap_parameters(p,f,lam);K=lattice(radius)
            energy=0.;previous=0.
            for threshold in cfg['cap']['difference_thresholds']:
                k=int((abs(dif)>threshold).sum());low=lower(k,n,alpha)
                energy+=(threshold**2-previous**2)*low;previous=threshold
                if threshold==.2: cover=math.sqrt(1-low)
                tally.append(dict(j=j,lam=lam,threshold=threshold,count=k,reps=n,lower=low))
            floor=math.sqrt(K*energy/2)
            bound.append(dict(j=j,P=p,F=f,lam=lam,n=n,r=radius,K=K,Rpred=rp,exact_corrected_mean=mean,
                event_mean=np.mean([int(x['n0'])+int(x['n1']) for x in cell])/2,
                single_pair_d2=np.mean(dif*dif),sd_lower=floor,var_lower=floor**2,
                cv_lower=floor/mean,rmse_lower=math.sqrt(floor**2+(mean-1)**2),coverage_upper=cover))
    write('medium_summary.csv',one);write('thresholds.csv',tally);write('high_bounds.csv',bound)
    print('CAP',[(a['j'],a['lam'],a['K'],round(a['sd_lower'],3),round(a['coverage_upper'],4)) for a in bound])
    print('FULL',[(a['j'],a['lam'],round(a['mean'],2),round(a['sd'],2),a['hits']) for a in one])
if __name__=='__main__':analyze()
