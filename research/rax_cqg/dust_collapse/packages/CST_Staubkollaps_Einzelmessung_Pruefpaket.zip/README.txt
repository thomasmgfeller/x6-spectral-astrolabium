KORRIGIERTER MASSESTROM EINER EINZELNEN KAUSALORDNUNG
Prüfpaket vom 2. November 2026. Zugehöriger Bericht CST_Staubkollaps_Einzelmessung.pdf.

Die beiden früher geprüften Fenster und die vier interessierenden Hochdichtefälle
stehen im Repository thomasmgfeller/x6-spectral-astrolabium bei Commit
2ed57fff0bc09c56cdf268e0a9044785ec753eec im Dossier research/rax_cqg/dust_collapse.
Das vorliegende Paket enthält die für die Rechnung benötigten Dateien.

Getestet unter Linux x86_64 mit Python 3.12, NumPy 2.3.5, SciPy 1.17.0 und g++.
In einer frischen entpackten Arbeitskopie ausführen. Die Programme schreiben ihre
Ergebnistabellen neu. Die C++17-Kerne werden dabei kompiliert. Die Abbildung ist optional.
  sha256sum -c SHA256SUMS.txt
  export OPENBLAS_NUM_THREADS=1
  export CST_WORKERS=4
  python3 direct_cases.py
  python3 cap_cases.py
  python3 high_full.py
  python3 second_orientation.py
  python3 controls.py
  python3 high_oracle_check.py
  python3 analyze.py
  python3 summarize_full.py
  python3 figure.py
Für die optionale Abbildung wird matplotlib benötigt. Die Reproduktion umfasst
auch vollständige Umgebungsordnungen mit mehr als 300 000 Ereignissen und kann je
nach Maschine mehrere Minuten oder länger dauern. Keine Binärdatei wird ausgeliefert.

design.json legt Referenz, Hauptkohorten, Verteilungskriterium, Startwerte und
feste Stichprobenumfänge fest. Die ergänzenden Hochdichte-Vollkohorten haben die
getrennten Protokolle high_full_design.json und second_orientation.json. Die
zweite Orientierung folgte nach einem Laufzeitcheck der ersten. Dies dokumentiert
den lokalen Arbeitsablauf, keine externe Präregistrierung. Der Vollgitterkern
verwendet für alle Ergebnisse stride=1. Alle markierten Endpunkte werden gezählt.

Erwartungswerte und ursprüngliche Korrektur:
  expectations.csv, common.py, prediction.py, reference.py, lens_reference.py,
  previous_design.json
Direkte Messungen:
  full.csv (640 mittlere und kleine Dichtefälle), medium_summary.csv,
  high_full.csv und high_second.csv (je 16 vollständige Einzelwerte bei 600000),
  direct_high_summary.csv, oracle.cpp, high_full.cpp und die Python-Treiber.
  Die Spalte raw ist M_B vor Division durch Rpred. Die Spalten sd und rmse
  beziehen sich auf korrigierte Werte in Einheiten der Sollmasse. wall_seconds
  dient nur als Laufzeitinformation und ist nicht deterministisch.
Gepaarte Experimente und Schranken:
  caps.csv enthält 512 unabhängige Paare (128 pro Hochdichtefall).
  A0,A1 sind die ROHEN Flussanteile der spätesten Endpunkte im Kegel, keine
  absoluten Gesamtmassen. Ihre Differenz geteilt durch Rpred liefert die
  korrekte Differenz der Gesamtmassen. thresholds.csv enthält Bonferroni-
  korrigierte einseitige Binomialgrenzen; high_bounds.csv überträgt diese auf
  Gesamtvarianz und maximale Trefferchance der ganzen Kugel.
Kontrollen:
  solver_checks.json, high_oracle.csv, poisson_control.csv
  C++-Gitter und lokale Schichtauszählung gegen unabhängige Bitmengenrechnung.
  Die Exponenten- und Randkoeffizienten werden nicht an neue Daten angepasst.

Für jede Realisierung erzeugen die angegebenen NumPy-SeedSequence-Komponenten
den Strom von Anfang an neu; Paarpartner teilen einen exakten Poisson-Aussenbereich.
Die Rohwerttabellen enthalten sämtliche Einzelmessungen, jedoch nicht jede
Ereigniskoordinate. Numerisch gleichwertige Läufe können zwischen Compilern
und Architekturen in den letzten Gleitkommastellen abweichen.
