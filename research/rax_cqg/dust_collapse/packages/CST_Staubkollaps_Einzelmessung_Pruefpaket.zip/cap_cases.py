"""Coupled terminal caps. All retained causal interval weights are counted exactly."""
import ctypes,csv,json,math,os,subprocess
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
cfg=json.loads(Path('design.json').read_text());s=cfg['s'];spec=cfg['cap']
ball=(3/(4*math.pi))**(1/3)
def eta(t):return -3*np.expm1(np.log1p(-t)/3)
def time_of_eta(q):return -np.expm1(3*np.log1p(-q/3))
def scale4(q):return (1-q/3)**8
def sphere(rng,r):
    vec=rng.normal(size=(len(r),3));norm=np.linalg.norm(vec,axis=1)
    return vec*(r*np.cbrt(rng.random(len(r)))/norm)[:,None]
def cap_parameters(P,F,lam):
    q0,q1=eta(s-P),eta(s+F)
    base_time=s+F-spec['height_in_discreteness_lengths']*lam**(-.25)
    assert base_time>s
    qb=eta(base_time); radius=q1-qb
    assert radius<ball
    return q0,q1,qb,radius
def draw_cap(rng,qb,q1,lam):
    span=q1-qb
    n=rng.poisson(lam*math.pi/3*scale4(qb)*span**4)
    q=qb+span*rng.random(n)**.25
    q=q[rng.random(n)*scale4(qb)<scale4(q)]
    return q,sphere(rng,q-qb)
def draw_exterior(rng,q0,qb,q1,r,lam):
    outer=r+q1-q0
    n=rng.poisson(lam*math.pi/3*scale4(q0)*(outer**4-r**4))
    radii=(r**4+(outer**4-r**4)*rng.random(n))**.25
    q=q1+r-radii
    keep=rng.random(n)*scale4(q0)<scale4(q)
    q=q[keep]; xyz=sphere(rng,radii[keep])
    inside=(q>qb)&(np.sum(xyz*xyz,axis=1)<np.maximum(0.,q-qb)**2)
    return q[~inside],xyz[~inside]
def load_kernel():
    lib=ctypes.CDLL(str(Path('layers.so').resolve()))
    arr=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    ii=ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
    func=lib.endpoint_flux
    func.argtypes=[ctypes.c_int,arr,arr,arr,ii,ctypes.c_int,ctypes.c_double,ctypes.c_double]
    func.restype=ctypes.c_double
    return lib,func
def compute(ext,cap,lam,func):
    a,p=ext;b,z=cap
    qs=np.concatenate([a,b]); order=np.argsort(qs);qs=qs[order]
    xyz=np.concatenate([p,z])[order]
    targets=np.flatnonzero(order>=len(a)).astype(np.int32)
    if len(targets)==0:return 0.
    return func(len(qs),time_of_eta(qs),qs,xyz,targets,len(targets),s,lam)
def lattice(r):
    m=int((ball-r)/(2*r))
    return sum((2*r)**2*(i*i+j*j+k*k)<(ball-r)**2 for i in range(-m,m+1)
               for j in range(-m,m+1) for k in range(-m,m+1))
def work(arg):
    j,lam,run=arg
    rng=np.random.default_rng(np.random.SeedSequence([spec['seed'],j,lam,run]))
    P,F=cfg['windows'][j];q0,q1,qb,r=cap_parameters(P,F,lam)
    ext=draw_exterior(rng,q0,qb,q1,r,lam)
    c0=draw_cap(rng,qb,q1,lam);c1=draw_cap(rng,qb,q1,lam)
    lib,fn=load_kernel()
    return [j,P,F,lam,run,len(ext[0]),len(c0[0]),len(c1[0]),compute(ext,c0,lam,fn),compute(ext,c1,lam,fn)]
def compile_kernel():
    subprocess.run(['g++','-std=c++17','-O3','-march=native','-fopenmp-simd','-ffp-contract=off','-fPIC','-shared','layers.cpp','-o','layers.so'],check=True)
if __name__=='__main__':
    compile_kernel()
    jobs=[(j,lam,i) for i in range(spec['reps']) for j in range(len(cfg['windows'])) for lam in spec['densities']]
    with open('caps.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','4'))) as pool:
        wr=csv.writer(f);wr.writerow(['j','P','F','lam','run','outside','n0','n1','A0','A1'])
        for row in pool.map(work,jobs,chunksize=1):wr.writerow(row);f.flush()
