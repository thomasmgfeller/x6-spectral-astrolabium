"""Check causal interval counts, hull restriction, and pathwise coupling identities."""
import csv,ctypes,json,math
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
from scipy.special import roots_legendre
from scipy.stats import poisson
from cap_cases import draw_cap,eta,scale4,time_of_eta,compute,cap_parameters,cfg,s,load_kernel
from high_full import cloud,load
# oracle.so and high_full.so and layers.so are built by the respective run scripts.
vec=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
old=ctypes.CDLL(str(Path('oracle.so').resolve())).cut_flux
old.argtypes=[ctypes.c_int,vec,vec,vec,vec]+[ctypes.c_double]*3;old.restype=ctypes.c_double
_,front=load_kernel(); fast=load();rng=np.random.default_rng(71100651)
R=(3/(4*math.pi))**(1/3)
checks={'grid_oracle':0.,'cap_difference':0.,'cap_value':0.,'single_chain':0.,'cap_endpoints':0}
for i in range(10):
    args=cloud(5600,i+20000)
    checks['grid_oracle']=max(checks['grid_oracle'],abs(fast(*args,1)-old(*args[:8])))
for j,(P,F) in enumerate(cfg['windows']):
    for i in range(10):
        lam=7000;box=1.86
        a,b=s-P,s+F;q0,q1,qb=eta(a),eta(b),eta(b-min(.10,.9*F))
        extent=q1-qb
        assert extent+q1-q0<box/2 and 2*(q1-q0)<box
        n=rng.poisson(lam*box**3*((1-a)**3-(1-b)**3)/3)
        ts=1-np.cbrt(rng.uniform((1-b)**3,(1-a)**3,n));qe=eta(ts);pos=rng.uniform(-box/2,box/2,(n,3))
        rr=np.linalg.norm(pos,axis=1)
        keep=~((qe>qb)&(rr<np.maximum(0,qe-qb)))
        qe,pos,rr=qe[keep],pos[keep],rr[keep];hull=rr<extent+q1-qe
        ext=qe[hull],pos[hull];ball_scores=[];cap_scores=[]
        for _ in range(2):
            qc,pc=draw_cap(rng,qb,q1,lam);checks['cap_endpoints']+=len(qc)
            qs=np.r_[qe,qc];order=np.argsort(qs);times=time_of_eta(qs[order]);xyz=np.r_[pos,pc][order]
            sig=(np.sum(xyz*xyz,axis=1)<R**2)/(1-times)**2
            args=(len(qs),times,qs[order],xyz)
            ball_scores.append(old(*args,sig,box,s,lam))
            exact=old(*args,(order>=len(qe))/(1-times)**2,box,s,lam)
            score=compute(ext,(qc,pc),lam,front)
            cap_scores.append(score)
            checks['cap_value']=max(checks['cap_value'],abs(exact-score))
        checks['cap_difference']=max(checks['cap_difference'],abs((ball_scores[1]-ball_scores[0])-(cap_scores[1]-cap_scores[0])))
# Timelike total chain with more than four intermediates. Below-cut lower endpoints only.
tt=np.array([.1,.2,.3,.4,.44,.5,.6,.7]);xx=np.zeros((len(tt),3));idx=np.array([7],dtype=np.int32)
val=front(len(tt),tt,eta(tt),xx,idx,1,s,1.)
c=[1,-9,16,-8]
truth=-2/math.sqrt(6)/(1-tt[-1])**2*sum((tt[-1]-tt[k])*c[6-k] for k in range(7) if tt[k]<s and 6-k<4)
checks['single_chain']=abs(val-truth)
assert checks['cap_endpoints']>15 and all(checks[x]<1e-8 for x in ['grid_oracle','cap_difference','cap_value','single_chain'])
Path('solver_checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(checks)
data=list(csv.DictReader(open('caps.csv')));nodes,weights=roots_legendre(6)
def integral(lo,hi,fn):return (hi-lo)/2*np.dot(weights,fn((lo+hi)/2+(hi-lo)*nodes/2))
rows=[]
for j,(P,F) in enumerate(cfg['windows']):
    for lam in cfg['cap']['densities']:
        q0,q1,qb,r=cap_parameters(P,F,lam);factor=4*math.pi/3*lam
        muc=factor*integral(qb,q1,lambda u:scale4(u)*(u-qb)**3)
        muh=factor*integral(q0,q1,lambda u:scale4(u)*(r+q1-u)**3)
        cell=[x for x in data if int(x['j'])==j and int(x['lam'])==lam];n=len(cell)
        for part,k,mu,nn in [('cap',sum(int(x['n0'])+int(x['n1']) for x in cell),muc,2*n),
                            ('outside',sum(int(x['outside']) for x in cell),muh-muc,n)]:
            rows.append(dict(j=j,lam=lam,part=part,analytic=mu,observed=k/nn,z=(k-nn*mu)/math.sqrt(nn*mu)))
with open('poisson_control.csv','w',newline='') as out:
    wr=csv.DictWriter(out,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
print('max absolute count z',max(abs(x['z']) for x in rows))
