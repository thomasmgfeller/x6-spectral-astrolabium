"""Full single-order measurement with the original exact C++ interval counter."""
import csv,ctypes,json,math,subprocess,os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from numpy.ctypeslib import ndpointer
from prediction import A,constant
from reference import physical_expectation
cfg=json.loads(Path('design.json').read_text());s=cfg['s'];U=1-s;rad=(3/(4*math.pi))**(1/3)
def preparation():
    rows=[]
    for j,(P,F) in enumerate(cfg['windows']):
        B=constant(P/U,F/U)
        for lam in cfg['full']['densities']+cfg['cap']['densities']:
            L=lam*U**4;pred=1+(A*math.log(L)+B)/math.sqrt(L)
            r=physical_expectation(s,P,F,lam,96)
            rows.append(dict(j=j,P=P,F=F,lam=lam,Rpred=pred,exact_mean=r,corrected_mean=r/pred))
    with open('expectations.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def work(arg):
    j,lam,i=arg;P,F=cfg['windows'][j];spec=cfg['full'];side=spec['box_side'];a=s-P;b=s+F
    assert 2*3*((1-a)**(1/3)-(1-b)**(1/3))<side and 2*rad<side
    rng=np.random.default_rng(np.random.SeedSequence([spec['seed'],j,lam,i]))
    n=rng.poisson(lam*side**3*((1-a)**3-(1-b)**3)/3)
    ts=1-np.cbrt(rng.uniform((1-b)**3,(1-a)**3,n));ts.sort()
    eta=-3*np.expm1(np.log1p(-ts)/3)
    xyz=rng.uniform(0,side,(n,3));sigma=(np.sum((xyz-side/2)**2,axis=1)<rad**2)/(1-ts)**2
    func=ctypes.CDLL(str(Path('oracle.so').resolve())).cut_flux;arr=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    func.argtypes=[ctypes.c_int,arr,arr,arr,arr,ctypes.c_double,ctypes.c_double,ctypes.c_double]
    func.restype=ctypes.c_double
    return [j,P,F,lam,i,n,func(n,ts,eta,xyz,sigma,side,s,lam)]
if __name__=='__main__':
    preparation()
    subprocess.run(['g++','-O3','-mpopcnt','-std=c++17','-fPIC','-shared','oracle.cpp','-o','oracle.so'],check=True)
    jobs=[(j,l,i) for j in range(2) for l in cfg['full']['densities'] for i in range(cfg['full']['reps'])]
    with open('full.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','3'))) as pool:
        wr=csv.writer(f);wr.writerow(['j','P','F','lam','run','n','raw'])
        for row in pool.map(work,jobs,chunksize=2):wr.writerow(row);f.flush()
