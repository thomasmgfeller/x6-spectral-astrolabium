"""Independent, full unit-ball high-density histories. Compile and run in this directory."""
import csv,ctypes,json,math,os,subprocess,time as clock
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
cfg=json.loads(Path('high_full_design.json').read_text())
def compile_kernel():
    subprocess.run(['g++','-std=c++17','-O3','-march=native','-fopenmp-simd','-ffp-contract=off','-shared','-fPIC','high_full.cpp','-o','full_grid_native.so'],check=True)
def load():
    f=ctypes.CDLL(str(Path('full_grid_native.so').resolve())).full_grid
    arr=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    f.argtypes=[ctypes.c_int,arr,arr,arr,arr]+[ctypes.c_double]*5+[ctypes.c_int]
    f.restype=ctypes.c_double;return f
def cloud(lam,i):
    L=cfg['box_side'];s=cfg['s'];lo=s-cfg['P'];hi=s+cfg['F']
    rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],int(lam),i]))
    n=rng.poisson(lam*L**3*((1-lo)**3-(1-hi)**3)/3)
    t=1-np.cbrt(rng.uniform((1-hi)**3,(1-lo)**3,n));t.sort()
    eta=lambda v:-3*np.expm1(np.log1p(-v)/3)
    xyz=rng.uniform(0,L,(n,3))
    sigma=(np.sum((xyz-L/2)**2,axis=1)<(3/(4*math.pi))**(2/3))/(1-t)**2
    assert 2*(eta(hi)-eta(lo))<L
    return (n,t,eta(t),xyz,sigma,L,s,float(lam),float(eta(lo)),float(eta(hi)))
def work(i):
    args=cloud(cfg['lam'],i);start=clock.perf_counter();val=load()(*args,1)
    return [i,args[0],np.count_nonzero((args[1]>=cfg['s'])&(args[4]>0)),val,clock.perf_counter()-start]
if __name__=='__main__':
    compile_kernel()
    with open('high_full.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','7'))) as pool:
        wr=csv.writer(f);wr.writerow(['run','n','endpoints','raw','wall_seconds'])
        for row in pool.map(work,range(cfg['reps'])):wr.writerow(row);f.flush()
