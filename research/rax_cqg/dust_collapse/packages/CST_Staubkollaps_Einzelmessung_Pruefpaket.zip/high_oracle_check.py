"""Independent bitset enumeration on true high-density past cones."""
import ctypes,json,math
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
import high_full as hf
from analyze import write

arr=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
old=ctypes.CDLL(str(Path('oracle.so').resolve())).cut_flux
old.argtypes=[ctypes.c_int,arr,arr,arr,arr]+[ctypes.c_double]*3;old.restype=ctypes.c_double
def main():
    rows=[];fn=hf.load()
    for j,(P,F) in enumerate([(.11,.24),(.24,.11)]):
        hf.cfg.update(P=P,F=F,seed=20261102513)
        n,t,e,xyz,sg,L,s,l,q0,q1=hf.cloud(600000,0)
        ids=np.flatnonzero((sg>0)&(t>s))
        for frac in [.1,.5,.9]:
            x=ids[int(len(ids)*frac)]
            rel=xyz-xyz[x];rel-=L*np.rint(rel/L)
            keep=(t<t[x])&(np.sum(rel*rel,axis=1)<(e[x]-e)**2)
            keep[x]=True
            # Every intermediate of a pair ending at x is retained in its past.
            sub_t=t[keep];local_sigma=np.zeros(len(sub_t));local_sigma[-1]=sg[x]
            v=old(len(sub_t),sub_t,e[keep],rel[keep],local_sigma,4.,s,l)
            sigma=np.zeros(n);sigma[x]=sg[x]
            z=fn(n,t,e,xyz,sigma,L,s,l,q0,q1,1)
            rows.append(dict(j=j,fraction=frac,cone_events=len(sub_t),bitset=v,grid=z,gap=abs(v-z)))
    write('high_oracle.csv',rows)
    print('high density max discrepancy',max(r['gap'] for r in rows),'max cone',max(r['cone_events'] for r in rows))
    assert max(r['gap'] for r in rows)<1e-8
if __name__=='__main__':main()
