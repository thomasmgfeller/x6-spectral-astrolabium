import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze import read,expect
fig,ax=plt.subplots(figsize=(6.5,2.28))
for y,j,path,color in [(1,0,'high_second.csv','#08796f'),(0,1,'high_full.csv','#a05230')]:
    pred=float(expect[j,600000]['Rpred'])
    a=np.sort([float(x['raw'])/pred for x in read(path)])
    ax.plot([a[0],a[-1]],[y,y],color=color,alpha=.33,lw=1)
    ax.scatter(a,y+np.array([-.05,.05]*8),s=23,color=color,zorder=3,edgecolor='white',linewidth=.4)
ax.axvline(1,color='#172e3b',ls='--',lw=1)
ax.set_yticks([0,1],['P 0,24  ·  F 0,11','P 0,11  ·  F 0,24'])
ax.set(xlim=(-123,100),ylim=(-.4,1.46),xlabel='Korrigierter Massestrom in Einheiten der Sollmasse')
ax.text(4,1.30,'Sollwert 1',fontsize=8,color='#172e3b')
ax.spines[['top','left','right']].set_visible(False);ax.tick_params(axis='y',length=0)
ax.grid(axis='x',alpha=.2,lw=.5);fig.subplots_adjust(left=.20,right=.98,bottom=.27,top=.98)
fig.savefig('single_histories.pdf')
