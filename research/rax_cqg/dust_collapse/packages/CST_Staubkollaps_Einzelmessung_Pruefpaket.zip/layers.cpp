#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

// Input sorted by increasing time. All rows may be intermediate events, also
// outside the spatially marked ball. x_indices selects the terminal endpoints.
extern "C" double endpoint_flux(int n, const double *time, const double *eta,
        const double *xyz, const int *x_indices, int nx, double cut, double density) {
    const int coeff[] = {1,-9,16,-8};
    double total = 0.0;
    std::vector<double> X,Y,Z,E;
    for (int ii=0; ii<nx; ++ii) {
        const int x=x_indices[ii];
        X.clear();Y.clear();Z.clear();E.clear();
        double value=0.;
        for(int y=x-1; y>=0; --y) {
            const double dt=eta[x]-eta[y];
            const double px=xyz[3*y]-xyz[3*x], py=xyz[3*y+1]-xyz[3*x+1], pz=xyz[3*y+2]-xyz[3*x+2];
            if(px*px+py*py+pz*pz>=dt*dt) continue;
            // All stored points lie strictly before x and strictly after y.
            const int m=X.size();
            int k=0, j=0;
            for(; j<m && j<24 && k<4; ++j) {
                const double a=X[j]-px,b=Y[j]-py,c=Z[j]-pz,t=dt-E[j];
                k+=(a*a+b*b+c*c<t*t);
            }
            for(; j<m && k<4; j+=64) {
                const int stop=std::min(m,j+64);
                int count=0;
                #pragma omp simd reduction(+:count)
                for(int h=j;h<stop;++h) {
                    const double a=X[h]-px,b=Y[h]-py,c=Z[h]-pz,t=dt-E[h];
                    count+=(a*a+b*b+c*c<t*t);
                }
                k+=count;
            }
            if(k<4) {
                if(time[y]<cut) value+=coeff[k]*(time[x]-time[y]);
                X.push_back(px);Y.push_back(py);Z.push_back(pz);E.push_back(dt);
            }
        }
        total+=value/((1-time[x])*(1-time[x]));
    }
    return -2*total/std::sqrt(6*density);
}
