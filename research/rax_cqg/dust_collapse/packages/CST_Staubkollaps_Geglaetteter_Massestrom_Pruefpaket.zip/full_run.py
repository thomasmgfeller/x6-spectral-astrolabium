import csv,ctypes,json,math,os,subprocess,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
from cap_run import cfg,s,mu
from cap_geometry import eta
from weights import layer_table
def compile_kernel():
    subprocess.run(['g++','-O3','-march=native','-fopenmp-simd','-ffp-contract=off','-std=c++17','-shared','-fPIC','whole_grid.cpp','-o','whole_grid_native.so'],check=True)
def load():
    f=ctypes.CDLL(str(Path('whole_grid_native.so').resolve())).whole_grid
    a=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    f.argtypes=[ctypes.c_int,a,a,a,a]+[ctypes.c_double]*5+[a,ctypes.c_int,a];f.restype=None
    return f
def cloud(seed,lam,i,P,F):
    L=cfg['full']['box_side'];lo=s-P;hi=s+F
    rng=np.random.default_rng(np.random.SeedSequence([seed,int(lam),i]))
    n=rng.poisson(lam*L**3*((1-lo)**3-(1-hi)**3)/3)
    ts=1-np.cbrt(rng.uniform((1-hi)**3,(1-lo)**3,n));ts.sort()
    pos=rng.uniform(0,L,(n,3))
    sig=(np.sum((pos-L/2)**2,axis=1)<(3/(4*math.pi))**(2/3))/(1-ts)**2
    assert 2*(eta(hi)-eta(lo))<L and 2*(3/(4*math.pi))**(1/3)<L
    return (n,ts,eta(ts),pos,sig,L,s,float(lam),float(eta(lo)),float(eta(hi)))
def compute(args,eff):
    n,ts,qt,pos,sig,L,cut,lam,q0,q1=args
    p=eff/lam;tab,eps=layer_table(p);out=np.zeros(2)
    load()(*args,tab,len(tab),out)
    marked=np.count_nonzero((ts>=cut)&(sig>0))
    factor=2*p*p/math.sqrt(6*eff)
    tail=factor*eps*marked*np.count_nonzero(ts<cut)*(ts[-1]-ts[0])*sig.max()
    return [marked,-factor*out[0],-2*out[1]/math.sqrt(6*lam),tail]
def work(i):
    spec=cfg['full'];P,F=cfg['windows'][spec['window_index']];lam=spec['density'];start=time.monotonic()
    args=cloud(spec['seed'],lam,i,P,F)
    return [i,args[0],*compute(args,mu),time.monotonic()-start]
if __name__=='__main__':
    compile_kernel()
    with open('full.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','3'))) as pool:
        out=csv.writer(f);out.writerow(['run','n','marked','smooth','local','tail_bound','seconds']);f.flush()
        tasks=[pool.submit(work,i) for i in range(cfg['full']['reps'])]
        for task in as_completed(tasks):out.writerow(task.result());f.flush()
