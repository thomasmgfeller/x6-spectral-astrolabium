"""Create report tables from verified observations. All probability upper limits round outwards."""
import csv,json,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def read(n):
    with open(n) as f:return list(csv.DictReader(f))
def fmt(x,n):return f'{x:.{n}f}'.replace('.',r'{,}')
def up(x,n=1):return fmt(math.ceil(100*x*10**n)/10**n,n)
def pct(x):return '$'+up(x)+r'\,\%$'
def num(x,n=2):return '$'+fmt(float(x),n)+'$'
def wr(name,value):Path(name+'.tex').write_text(value+'\n')
def table(name,head,body,columns):
    lines=[r'\renewcommand{\arraystretch}{1.21}',r'\begin{tabular}{@{}'+columns+r'@{}}\toprule',
           head+r'\\\midrule']
    lines.extend(' & '.join(row)+r'\\' for row in body)
    lines.append(r'\bottomrule\end{tabular}')
    wr(name,'\n'.join(lines))
def main():
    bounds=read('bounds.csv');supp=json.loads(Path('extension_summary.json').read_text())
    full=json.loads(Path('full_summary.json').read_text());scores=read('full_scores.csv');fs=full['smoothed'];loc=full['local']
    assert len(bounds)==4 and len(scores)==12 and supp['n']==40
    drows=[];crows=[]
    for r in sorted(bounds,key=lambda x:(int(x['lam']),int(x['j']))):
        j=int(r['j']);lam=int(r['lam'])
        den='$1{,}2$ Mio.' if lam==1200000 else '$6$ Mio.'
        u=float(r['coverage_upper']);basis='Haupttest'
        if j==1 and lam==1200000 and supp['coverage_upper']<u:
            u=supp['coverage_upper'];basis='Zusatztest'
        decision='verfehlt' if u<.95 else 'offen'
        drows.append([den,num(r['P']),num(r['F']),num(100*float(r['mean_bias']),2)+r'\,\%',pct(u)+' '+r'{\footnotesize ('+basis+')}',decision])
        crows.append([den,num(r['F']),r['cap_gap'],r['local_cap_gap'],num(r['cap_rms_smooth'],3),num(r['cap_rms_local'],3)])
    table('decision_table',r'$\lambda$ & $P$ & $F$ & Fehler $\E S$ & Trefferchance höchstens & Einzelziel',drows,'lrrrll')
    table('cap_table',r'$\lambda$ & $F$ & gegl. $>0{,}2$ & lokal $>0{,}2$ & RMS gegl. & RMS lokal',crows,'lrrrrr')
    assert sum(row[-1]=='verfehlt' for row in drows)==2 and all(row[-1]=='offen' for row in drows[2:])
    wr('decision',r'\textbf{Bei 1,2 Millionen Ereignissen je Einheit Vierervolumen verfehlt auch der geglättete Strom das Einzelziel in beiden Zeitfenstern.} Bei sechs Millionen ist die Trefferquote offen. Der Mittelwert liegt in allen vier Fällen im Zielband. Bei fester Glättungslänge konvergiert die Einzelmasse im quadratischen Mittel. Der Grenzwert liegt nach beiden Referenzintegrationen im Zielband.')
    n=fs['n'];assert fs['possible']==fs['hits']
    table('full_table',r'Ganze Kugel im periodischen Würfel & geglättet & lokal',[
        ['Treffer in zwölf Ordnungen',str(fs['hits']),str(loc['hits'])],
        ['Kleinster bis grösster Einzelwert',num(fs['minimum'])+' bis '+num(fs['maximum']),num(loc['minimum'])+' bis '+num(loc['maximum'])],
        ['Stichproben-Standardabweichung',num(fs['sd']),num(loc['sd'])],
        ['Quadratischer Mittelfehler (RMSE)',num(fs['rmse']),num(loc['rmse'])],
    ],'lrr')
    wr('full_text','Die beobachtete Standardabweichung des geglätteten Stroms beträgt '+num(100*fs['sd_ratio'],1)+r'\,\% der lokalen Standardabweichung. Diese Verhältniszahl beschreibt die zwölf Ordnungen. Die einseitige exakte Obergrenze für die wahre Trefferchance des geglätteten Stroms beträgt '+pct(fs['p_hi'])+'.')
    wr('extension_text',f"Nach Sichtung eines Teils der Hauptdaten wurden 40 neue Paare bei $\\lambda=1{{,}}2$ Millionen vor der Ziehung auf eine Kegelhöhe von $2{{,}}75\\lambda^{{-1/4}}$ festgelegt. Davon überschritten {supp['exceed']} die einzige Prüfschwelle $0{{,}}2$. Mit separater einseitiger 99,9-Prozent-Absicherung folgt $h\\le "+up(supp['coverage_upper'])+r'\,\%$. Der grössere Bereich erfasst die gemeinsame Wirkung vieler weiterer Endpunkte. Die Schranke gilt im räumlich unbeschränkten Modell.')
    wr('checks_text',r'Die Summe über alle 512 Ausdünnungen einer Neun-Punkte-Ordnung prüft das Gewicht direkt. Unabhängiges Zählen der Zwischenmengen reproduziert die Gitter- und Kegeltests bis $1{,}8\cdot 10^{-15}$, die zwölf vollständigen Ersatzdifferenzen bis $3{,}4\cdot 10^{-16}$. Die Schichtabschlüsse $J=63,403$ begrenzen den Betrag jedes ausgelassenen Gewichts durch $10^{-13}$. Die deterministische Fehlerschranke für die normierte Masse in den zwölf Vollordnungen bleibt unter $5\cdot 10^{-7}$. Code, Startwerte, Protokolle, Rohwerte und Auswertung liegen im Prüfpaket.')
    assert fs['max_numerical_error']<5e-7
    a=np.array([float(r['smoothed']) for r in scores]);b=np.array([float(r['unsmoothed']) for r in scores]);runs=np.array([int(r['run'])+1 for r in scores]); 
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(7.45,2.42),layout='constrained')
    for ax,arr,c,title in zip(axes,[b,a],['#516674','#007264'],['Lokaler Vierschichtenstrom','Geglätteter Strom']):
        ax.axhspan(.9,1.1,color='#72b49c',alpha=.48)
        ax.axhline(1,color='#508271',lw=.85,ls='--')
        ax.scatter(runs,arr,color=c,s=26,zorder=3)
        ax.axhline(0,color='#a7aeaf',lw=.6,zorder=0);ax.grid(axis='y',alpha=.16)
        ax.set_xticks([1,4,8,12]);ax.set_xlabel('Ordnung');ax.set_title(title,fontsize=10,loc='left',fontweight='bold')
        ax.set_xlim(.1,12.9)
    axes[0].set_ylabel('Masse in Einheiten der Sollmasse')
    fig.savefig('full_scores_plot.pdf',bbox_inches='tight',pad_inches=.035)
if __name__=='__main__':main()
