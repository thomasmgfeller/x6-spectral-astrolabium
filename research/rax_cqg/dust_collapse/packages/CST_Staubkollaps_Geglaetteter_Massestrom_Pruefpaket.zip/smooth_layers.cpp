#include <algorithm>
#include <cmath>
#include <vector>

// For a fixed upper endpoint x retain y with < J intermediates. The J latest
// intermediates, whenever they exist, themselves always have < J intermediates.
struct LayerCounter {
    std::vector<double> X,Y,Z,T;
    void clear(){X.clear();Y.clear();Z.clear();T.clear();}
    int count(double x,double y,double z,double lag,int J) {
        const int m=X.size();int k=0;
        for(int j=0;j<m && k<J;j+=64) {
            const int stop=std::min(m,j+64);int block=0;
            #pragma omp simd reduction(+:block)
            for(int i=j;i<stop;++i){
                double a=X[i]-x,b=Y[i]-y,c=Z[i]-z,t=lag-T[i];
                block+=(a*a+b*b+c*c<t*t);
            }
            k+=block;
        }
        if(k<J){X.push_back(x);Y.push_back(y);Z.push_back(z);T.push_back(lag);}
        return k;
    }
};
extern "C" void endpoints(int n,const double *time,const double *eta,const double *xyz,
                const int *ids,int nids,double cut,const double *weights,int J,double *sums) {
    const double coeff[]={1.,-9.,16.,-8.};
    LayerCounter counter; sums[0]=sums[1]=0.;
    for(int a=0;a<nids;++a){
        int x=ids[a];counter.clear();double smooth=0.,local=0.;
        for(int y=x-1;y>=0;--y){
            double lag=eta[x]-eta[y],px=xyz[3*y]-xyz[3*x],py=xyz[3*y+1]-xyz[3*x+1],pz=xyz[3*y+2]-xyz[3*x+2];
            if(px*px+py*py+pz*pz>=lag*lag)continue;
            int k=counter.count(px,py,pz,lag,J);
            if(time[y]<cut && k<J){
                smooth+=weights[k]*(time[x]-time[y]);
                if(k<4)local+=coeff[k]*(time[x]-time[y]);
            }
        }
        double sigma=1./((1.-time[x])*(1.-time[x]));
        sums[0]+=sigma*smooth;sums[1]+=sigma*local;
    }
}
