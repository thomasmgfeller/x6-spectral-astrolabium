"""Verify the cap difference against two complete nonperiodic order sums."""
import math
import numpy as np
from analysis import write
from cap_geometry import eta, time_of_eta, draw_cap
from cap_run import load
from checks import exact
from weights import layer_table

def run():
    rng=np.random.default_rng(20261102831)
    lam=4200
    s,lo,hi=.47,.36,.71
    qb,q1=eta(s+.055),eta(hi)
    radius=(3/(4*math.pi))**(1/3)
    side=1.35
    assert q1-qb<radius
    rows=[]
    for i in range(6):
        n=rng.poisson(lam*side**3*((1-lo)**3-(1-hi)**3)/3)
        t=1-np.cbrt(rng.uniform((1-hi)**3,(1-lo)**3,n))
        q=eta(t);xyz=rng.uniform(-side/2,side/2,(n,3))
        exterior=(q<=qb)|(np.sum(xyz**2,axis=1)>np.maximum(q-qb,0)**2)
        qe,xe=q[exterior],xyz[exterior]
        pair=[draw_cap(rng,qb,q1,lam) for _ in range(2)]
        for p in [.5,.1]:
            mu=p*lam;w,_=layer_table(p);all_scores=[];cap_scores=[]
            for qc,xc in pair:
                qr=np.r_[qe,qc];idx=np.argsort(qr)
                tt=time_of_eta(qr[idx]);xx=np.r_[xe,xc][idx];qsort=qr[idx]
                mark=np.sum(xx**2,axis=1)<radius**2
                all_scores.append(exact(tt,qsort,xx,mark,s,lam,mu))
                ids=np.flatnonzero(idx>=len(qe)).astype(np.int32);out=np.zeros(2)
                load()(len(tt),tt,qsort,xx,ids,len(ids),s,w,len(w),out)
                cap_scores.append(-2*p*p/math.sqrt(6*mu)*out[0])
            full=all_scores[0]-all_scores[1];part=cap_scores[0]-cap_scores[1]
            assert abs(full-part)<1e-10
            rows.append(dict(run=i,p=p,n_ext=len(qe),n0=len(pair[0][0]),n1=len(pair[1][0]),
                             full_difference=full,cap_difference=part,gap=abs(full-part)))
    write('coupling_checks.csv',rows)
    print(max(x['gap'] for x in rows))
if __name__=='__main__':run()
