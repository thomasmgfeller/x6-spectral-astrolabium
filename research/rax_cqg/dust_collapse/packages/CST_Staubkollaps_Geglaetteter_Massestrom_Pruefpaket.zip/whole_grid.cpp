#include <algorithm>
#include <cmath>
#include <vector>
struct Record {int id; double x,y,z,lag;};
struct Frontier {
    std::vector<double> X,Y,Z,T;
    void clear() {X.clear();Y.clear();Z.clear();T.clear();}
    int inspect(const Record &p, int J) {
        int k=0,j=0,m=X.size();
        for(;j<m && j<24 && k<J;++j) {
            double a=X[j]-p.x,b=Y[j]-p.y,c=Z[j]-p.z,t=p.lag-T[j];
            k+=(a*a+b*b+c*c<t*t);
        }
        for(;j<m && k<J;j+=64) {
            int count=0,limit=std::min(m,j+64);
            #pragma omp simd reduction(+:count)
            for(int h=j;h<limit;++h) {
                double a=X[h]-p.x,b=Y[h]-p.y,c=Z[h]-p.z,t=p.lag-T[h];
                count+=(a*a+b*b+c*c<t*t);
            }
            k+=count;
        }
        if(k<J){X.push_back(p.x);Y.push_back(p.y);Z.push_back(p.z);T.push_back(p.lag);}
        return k;
    }
};
static int periodic(int i,int side){return (i%side+side)%side;}
extern "C" void whole_grid(int n, const double* time,const double* eta,const double* pos,
                           const double* sigma,double box,double cut,double density,
                           double q0,double q1,const double* weights,int J,double* out) {
    const int cells=14,slices=18,V=cells*cells*cells,c[] = {1,-9,16,-8};
    const double ds=(q1-q0)/slices,dx=box/cells;
    std::vector<std::vector<int>> grid(slices*V);
    for(int i=0;i<n;++i) {
        int a=pos[3*i]/dx,b=pos[3*i+1]/dx,d=pos[3*i+2]/dx,j=std::min(slices-1,int((eta[i]-q0)/ds));
        grid[j*V+(a*cells+b)*cells+d].push_back(i);
    }
    int first=std::lower_bound(time,time+n,cut)-time;
    Frontier frontier;
    std::vector<Record> past;
    double sum=0.,loc=0.;
    for(int x=first;x<n;++x) {
        if(!sigma[x]) continue;
        frontier.clear();double val=0.,local=0.;
        const int js=std::min(slices-1,int((eta[x]-q0)/ds));
        for(int j=js;j>=0;--j) {
            const double reach=eta[x]-(q0+j*ds);
            int lo[3],hi[3];
            for(int k=0;k<3;++k){
                lo[k]=int(std::floor((pos[3*x+k]-reach)/dx));
                hi[k]=int(std::floor((pos[3*x+k]+reach)/dx));
            }
            past.clear();
            for(int a=lo[0];a<=hi[0];++a)for(int b=lo[1];b<=hi[1];++b)for(int d=lo[2];d<=hi[2];++d){
                int aa=periodic(a,cells),bb=periodic(b,cells),dd=periodic(d,cells);
                double sx=(a-aa)*dx-pos[3*x],sy=(b-bb)*dx-pos[3*x+1],sz=(d-dd)*dx-pos[3*x+2];
                for(int y:grid[j*V+(aa*cells+bb)*cells+dd]){
                    if(y>=x) continue;
                    double u=pos[3*y]+sx,v=pos[3*y+1]+sy,w=pos[3*y+2]+sz,lag=eta[x]-eta[y];
                    if(u*u+v*v+w*w<lag*lag)past.push_back({y,u,v,w,lag});
                }
            }
            std::sort(past.begin(),past.end(),[](const Record&a,const Record&b){return a.id>b.id;});
            for(const Record&p:past) {
                int k=frontier.inspect(p,J);
                if(k<J && time[p.id]<cut){val+=weights[k]*(time[x]-time[p.id]); if(k<4)local+=c[k]*(time[x]-time[p.id]);}
            }
        }
        sum+=val*sigma[x];loc+=local*sigma[x];
    }
    out[0]=sum;out[1]=loc;
}
