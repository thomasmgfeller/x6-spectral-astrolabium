"""Independently seeded, larger-cap confirmation for the nonperiodic model."""
from concurrent.futures import ProcessPoolExecutor
import csv,json,math,os
from pathlib import Path
import numpy as np
from analysis import lo,read
from cap_run import endpoint_result,compile_kernel
from cap_geometry import eta,draw_exterior,draw_cap
from weights import layer_table
cfg=json.loads(Path('design.json').read_text())
ext=json.loads(Path('extension_design.json').read_text())
j=ext['window_index'];P,F=cfg['windows'][j]
lam=ext['density'];mu=ext['effective_density'];s=cfg['s']
def work(i):
    rng=np.random.default_rng(np.random.SeedSequence([ext['seed'],j,lam,i]))
    top=s+F;apex=top-ext['height_in_input_lengths']*lam**(-.25)
    q0,q1,qb=eta(s-P),eta(top),eta(apex);r=q1-qb
    assert apex>s and r<(3/(4*math.pi))**(1/3)
    exterior=draw_exterior(rng,q0,qb,q1,r,lam)
    pair=[draw_cap(rng,qb,q1,lam) for _ in range(2)]
    w,eps=layer_table(mu/lam)
    a,b=[endpoint_result(exterior,points,lam,w,eps) for points in pair]
    return i,len(exterior[0]),len(pair[0][0]),len(pair[1][0]),a[0],b[0],a[2]+b[2]
def summary():
    data=read('extension.csv')
    assert len(data)==len({r['run'] for r in data})==ext['pairs']
    pred=float(next(r['Rpred'] for r in read('expectations.csv') if int(r['lam'])==mu and int(r['j'])==j))
    k=sum(abs(float(r['a'])-float(r['b']))-float(r['error'])>ext['difference_threshold']*pred for r in data)
    q=lo(k,len(data),ext['alpha'])
    Path('extension_summary.json').write_text(json.dumps(dict(n=len(data),exceed=k,lower_q=q,coverage_upper=math.sqrt(1-q),alpha=ext['alpha']),indent=2)+'\n')
if __name__=='__main__':
    if not Path('smooth_nodes.so').exists():compile_kernel()
    with open('extension.csv','w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','2'))) as pool:
        out=csv.writer(f);out.writerow(['run','ext','n0','n1','a','b','error']);f.flush()
        for row in pool.map(work,range(ext['pairs'])):out.writerow(row);f.flush()
    summary()
