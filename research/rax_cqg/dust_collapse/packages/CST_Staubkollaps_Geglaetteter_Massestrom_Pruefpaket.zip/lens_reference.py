"""Independent physical Alexandrov-volume integration from the published dust reference."""
from functools import cache
import numpy as np
from numpy.polynomial.legendre import leggauss

@cache
def unit_gauss(n):
    p,w = leggauss(n)
    return (p+1)/2, w/2

def eta(t, dust):
    return 3*(-np.expm1(np.log1p(-t)/3)) if dust else t

def interval_volume(eta_y,d,v,dust):
    if not dust:
        return np.pi/24 * (d*d*(1-v*v))**2
    left=d*(1-v)/2
    right=d*(1+v)/2
    r=d*v
    vol=0.
    p,w=unit_gauss(6)
    for zone,(lo,hi) in enumerate(((0,left),(left,right),(right,d))):
        width=hi-lo
        for u,weight in zip(p,w):
            s=lo+width*u
            if zone==0:
                lens=4*np.pi/3*s**3
            elif zone==2:
                lens=4*np.pi/3*(d-s)**3
            else:
                lens=np.pi*(d-r)**2*(r*r+2*r*d-3*(2*s-d)**2)/(12*r)
            vol+=weight*width*(1-(eta_y+s)/3)**8*lens
    return vol
