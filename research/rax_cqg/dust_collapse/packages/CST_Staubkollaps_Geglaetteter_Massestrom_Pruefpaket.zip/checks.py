"""Independent oracle for the conditional mean and true interval sizes."""
import ctypes,json,math,itertools
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
from scipy.stats import binom
from cap_run import load as cap_load
from full_run import compute as grid_compute,cloud
from weights import layer_table,c
from cap_geometry import eta,time_of_eta
from analysis import write

def exact(ts,qt,xyz,marked,s,lam,mu,periodic=None):
    n=len(ts)
    relation=np.zeros((n,n),dtype=bool)
    for j in range(n):
        r=xyz[:j]-xyz[j]
        if periodic: r-=periodic*np.rint(r/periodic)
        relation[:j,j]=np.einsum('ij,ij->i',r,r)<(qt[j]-qt[:j])**2
    past=[int.from_bytes(np.packbits(v,bitorder='little').tobytes(),'little') for v in relation.T]
    future=[int.from_bytes(np.packbits(v,bitorder='little').tobytes(),'little') for v in relation]
    out=0.;p=mu/lam
    for j in np.flatnonzero(marked & (ts>=s)):
        early=np.flatnonzero(relation[:,j]&(ts<s))
        sizes=np.array([(future[i]&past[j]).bit_count() for i in early],dtype=int)
        if len(sizes):
            wt=binom.pmf(np.arange(4)[None,:],sizes[:,None],p)@c
            out+=np.sum(wt*(ts[j]-ts[early]))/(1-ts[j])**2
    return -2*p*p/math.sqrt(6*mu)*out

def run():
    t=np.array([.2,.23,.25,.27,.30,.32,.39,.42,.45])
    points=np.array([[0,0,0],[.03,.01,0],[0,0,0],[.11,.2,0],[0,0,0],
                     [.06,.06,.03],[0,0,0],[.13,0,0],[0,0,0]])
    marked=np.array([1,0,1,1,1,0,1,1,1],dtype=bool)
    qt=eta(t);cut=.31;lam=2200;checks=[]
    for p in [1.,.5,.1]:
        average=0.
        for mask in itertools.product([False,True],repeat=len(t)):
            mask=np.array(mask);k=int(mask.sum());prob=p**k*(1-p)**(len(t)-k)
            if prob:average+=prob*exact(t[mask],qt[mask],points[mask],marked[mask],cut,p*lam,p*lam)
        val=exact(t,qt,points,marked,cut,lam,p*lam)
        w,eps=layer_table(p);out=np.zeros(2);ids=np.flatnonzero(marked&(t>=cut)).astype(np.int32)
        cap_load()(len(t),t,qt,points,ids,len(ids),cut,w,len(w),out)
        prod=-2*p*p/math.sqrt(6*p*lam)*out[0]
        assert max(abs(val-average),abs(prod-average))<1e-10
        checks.append(dict(test='all_512_subsets',p=p,n=len(t),production=prod,oracle=average,gap=abs(prod-average)))
    for p in [.1,.5,1.]:
        args=cloud(20261102811,2600,1,.11,.24)
        m,x,l,e=grid_compute(args,2600*p)
        n,t,q,xyz,sig,side,s,den,_,_=args
        val=exact(t,q,xyz,sig>0,s,den,2600*p,side)
        checks.append(dict(test='whole_bitset',p=p,n=n,production=x,oracle=val,gap=abs(x-val)))
        assert abs(x-val)<e+1e-10
    # Fixed physical high-density endpoints with an independently counted full past.
    rng=np.random.default_rng(20261102812)
    for lam,p in [(1200000,.5),(6000000,.1)]:
        for top in [.48,.50,.52]:
            q0=eta(.36);q1=eta(top);d=q1-q0
            denmax=(1-q0/3)**8
            n=rng.poisson(lam*math.pi/3*d**4*denmax)
            q=q1-d*rng.random(n)**.25
            q=q[rng.random(n)*denmax<(1-q/3)**8]
            q.sort()
            vec=rng.normal(size=(len(q),3));xr=vec/np.linalg.norm(vec,axis=1)[:,None]
            xyz=np.r_[xr*((q1-q)*np.cbrt(rng.random(len(q))))[:,None],[[0.,0.,0.]]]
            q=np.r_[q,q1];t=time_of_eta(q);n=len(t);mark=np.zeros(n,dtype=bool);mark[-1]=True
            val=exact(t,q,xyz,mark,.47,lam,p*lam)
            w,eps=layer_table(p);out=np.zeros(2);ids=np.array([n-1],dtype=np.int32)
            cap_load()(n,t,q,xyz,ids,1,.47,w,len(w),out)
            prod=-2*p*p/math.sqrt(6*p*lam)*out[0]
            bound=2*p*p/math.sqrt(6*p*lam)*eps*n*(top-.36)/(1-top)**2
            assert abs(prod-val)<bound+1e-10
            checks.append(dict(test='dense_past',p=p,n=n,production=prod,oracle=val,gap=abs(prod-val)))
    write('checks.csv',checks);print('Max gap',max(x['gap'] for x in checks),'max cone n',max(x['n'] for x in checks))
if __name__=='__main__':run()
