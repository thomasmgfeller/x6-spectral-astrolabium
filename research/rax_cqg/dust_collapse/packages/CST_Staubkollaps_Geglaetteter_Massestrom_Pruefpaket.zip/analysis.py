import csv,json,math
from pathlib import Path
import numpy as np
from scipy.stats import beta
from cap_geometry import eta
from weights import c,layer_table
from prediction import A,constant
from reference import physical_expectation
cfg=json.loads(Path('design.json').read_text())
s=cfg['s'];U=1-s;mu=cfg['effective_density'];ball=(3/(4*math.pi))**(1/3)
def read(p):
    with open(p) as f:return list(csv.DictReader(f))
def write(p,rows):
    with open(p,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def lo(k,n,a):return 0. if k==0 else float(beta.ppf(a,k,n-k+1))
def hi(k,n,a):return 1. if k==n else float(beta.isf(a,k+1,n-k))
def packed(r):
    m=int((ball-r)/(2*r))
    return sum((2*r)**2*(i*i+j*j+k*k)<(ball-r)**2 for i in range(-m,m+1) for j in range(-m,m+1) for k in range(-m,m+1))
def expectations():
    rows=[]
    for j,(P,F) in enumerate(cfg['windows']):
        B=constant(P/U,F/U)
        for lam in [mu,*cfg['input_densities']]:
            scale=lam*U**4
            rpred=1+(A*math.log(scale)+B)/math.sqrt(scale)
            v=physical_expectation(s,P,F,lam,96)
            w=physical_expectation(s,P,F,lam,112,lens=True,cap=13.)
            assert abs(v-w)<5e-5
            rows.append(dict(j=j,P=P,F=F,lam=lam,Rpred=rpred,reference=v,lens=w,mean=v/rpred))
    write('expectations.csv',rows);return rows

def main():
    ex={(r['j'],r['lam']):r for r in expectations()}
    alpha=.01/30
    cap=read('caps.csv');full=read('full.csv');out=[];thresholds=[]
    assert len(cap)==512 and len(full)==12
    for j,(P,F) in enumerate(cfg['windows']):
        for lam in cfg['input_densities']:
            lref=ex[j,lam];sref=ex[j,mu];cs=[x for x in cap if int(x['j'])==j and int(x['lam'])==lam]
            assert len(cs)==len({x['run'] for x in cs})==128
            n=len(cs);radius=eta(s+F)-eta(s+F-cfg['cap']['height_in_input_lengths']*lam**(-.25));K=packed(radius)
            vals=np.abs(np.array([float(x['sm0'])-float(x['sm1']) for x in cs]))/sref['Rpred']
            old=np.abs(np.array([float(x['local0'])-float(x['local1']) for x in cs]))/lref['Rpred']
            eps=np.array([float(x['err0'])+float(x['err1']) for x in cs])/sref['Rpred']
            vlow=0.;prev=0.
            for t in cfg['cap']['difference_thresholds']:
                k=int((vals-eps>t).sum());k0=int((old>t).sum());qlo=lo(k,n,alpha)
                thresholds.append(dict(j=j,lam=lam,t=t,sm_exceed=k,local_exceed=k0,n=n,sm_lo=qlo))
                vlow+=(t*t-prev*prev)*qlo;prev=t
                if t==.2:hu=math.sqrt(1-qlo);hits=k;ohits=k0
            tab,wt=layer_table(mu/lam)
            out.append(dict(j=j,P=P,F=F,lam=lam,p=mu/lam,J=len(tab),K=K,n=n,mean_bias=sref['mean']-1,
                   cap_gap=hits,local_cap_gap=ohits,coverage_upper=hu,sd_floor=math.sqrt(K*vlow/2),
                   cap_rms_smooth=np.sqrt(np.mean(vals**2)),cap_rms_local=np.sqrt(np.mean(old**2)),max_delta_error=eps.max()))
    write('bounds.csv',out);write('thresholds.csv',thresholds)
    j=cfg['full']['window_index'];lam=cfg['full']['density'];E=ex[j,mu]['Rpred'];E0=ex[j,lam]['Rpred']
    assert len({x['run'] for x in full})==len(full)
    a=np.array([float(x['smooth'])/E for x in full]);b=np.array([float(x['local'])/E0 for x in full])
    eps=np.array([float(x['tail_bound'])/E for x in full])
    pres=[]
    for x,y,z,row in zip(a,b,eps,full):
        pres.append(dict(run=int(row['run']),smoothed=x,unsmoothed=y,tail_bound=z))
    write('full_scores.csv',sorted(pres,key=lambda r:r['run']))
    def stats(x,d):
        hit=int((np.abs(x-1)+d<=.1).sum());possible=int((np.abs(x-1)-d<=.1).sum())
        return dict(n=len(x),mean=x.mean(),sd=x.std(ddof=1),rmse=np.sqrt(np.mean((x-1)**2)),
            minimum=x.min(),maximum=x.max(),hits=hit,possible=possible,p_lo=lo(hit,len(x),alpha),p_hi=hi(possible,len(x),alpha))
    fs=stats(a,eps);ls=stats(b,0);fs.update(max_numerical_error=eps.max(),sd_ratio=fs['sd']/ls['sd'])
    fs['mean_diagnostic_hits']=int((np.abs(np.array([float(r['smooth']) for r in full])/ex[j,mu]['reference']-1)<=.1).sum())
    Path('full_summary.json').write_text(json.dumps(dict(smoothed=fs,local=ls),indent=2)+'\n')
    print(out,fs,ls)
if __name__=='__main__':main()
