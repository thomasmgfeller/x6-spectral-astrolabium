"""Analytic thinning weights with a uniform deterministic tail bound."""
import numpy as np
from scipy.stats import binom
c=np.array([1.,-9.,16.,-8.])
def layer_table(p,tolerance=1e-13):
    if p==1:return c.copy(),0.
    cutoff=4
    while 16*binom.cdf(3,cutoff,p)>tolerance:cutoff+=1
    n=np.arange(cutoff)[:,None]
    table=binom.pmf(np.arange(4)[None,:],n,p)@c
    return np.ascontiguousarray(table),16*binom.cdf(3,cutoff,p)
