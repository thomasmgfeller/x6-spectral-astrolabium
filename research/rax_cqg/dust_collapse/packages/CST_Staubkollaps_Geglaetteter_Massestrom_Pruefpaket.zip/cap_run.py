import csv,ctypes,json,math,os,subprocess,sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
from cap_geometry import eta,time_of_eta,draw_cap,draw_exterior
from weights import layer_table
cfg=json.loads(Path('design.json').read_text());s=cfg['s'];mu=cfg['effective_density']
def compile_kernel():
    subprocess.run(['g++','-O3','-march=native','-fopenmp-simd','-ffp-contract=off','-std=c++17','-shared','-fPIC','smooth_layers.cpp','-o','smooth_nodes.so'],check=True)
def load():
    f=ctypes.CDLL(str(Path('smooth_nodes.so').resolve())).endpoints
    a=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    ii=ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
    f.argtypes=[ctypes.c_int,a,a,a,ii,ctypes.c_int,ctypes.c_double,a,ctypes.c_int,a];f.restype=None
    return f
def endpoint_result(ext,cap,lam,w,eps):
    qe,pos=ext;qc,xx=cap;ordered=np.r_[qe,qc].argsort()
    q=np.r_[qe,qc][ordered];ts=time_of_eta(q)
    coords=np.r_[pos,xx][ordered];target=np.flatnonzero(ordered>=len(qe)).astype(np.int32)
    values=np.zeros(2);load()(len(ts),ts,q,coords,target,len(target),s,w,len(w),values)
    p=mu/lam;factor=2*p*p/math.sqrt(6*mu)
    bound=factor*eps*len(target)*np.count_nonzero(ts<s)*(ts[-1]-ts[0])/(1-ts[-1])**2 if len(ts) else 0.
    return -factor*values[0],-2*values[1]/math.sqrt(6*lam),bound
def work(job):
    j,lam,i=job;P,F=cfg['windows'][j];p=mu/lam
    rng=np.random.default_rng(np.random.SeedSequence([cfg['cap']['seed'],j,lam,i]))
    q0,q1=eta(s-P),eta(s+F);tb=s+F-cfg['cap']['height_in_input_lengths']*lam**(-.25)
    assert tb>s
    qb=eta(tb);r=q1-qb;assert r<(3/(4*math.pi))**(1/3)
    ext=draw_exterior(rng,q0,qb,q1,r,lam)
    pair=[draw_cap(rng,qb,q1,lam) for _ in range(2)]
    w,eps=layer_table(p)
    return [j,P,F,lam,i,len(ext[0]),len(pair[0][0]),len(pair[1][0]),*[v for part in pair for v in endpoint_result(ext,part,lam,w,eps)]]
if __name__=='__main__':
    compile_kernel()
    jobs=[(j,l,i) for i in range(cfg['cap']['pairs']) for j in range(2) for l in cfg['input_densities']]
    resume='--resume' in sys.argv and Path('caps.csv').exists()
    if resume:
        with open('caps.csv',newline='') as previous:
            recovered=list(csv.DictReader(previous))
        assert all(all(v is not None for v in row.values()) for row in recovered)
        done={(int(row['j']),int(row['lam']),int(row['run'])) for row in recovered}
        assert len(done)==len(recovered) and done.issubset(set(jobs))
        jobs=[job for job in jobs if job not in done]
    with open('caps.csv','a' if resume else 'w',newline='') as f,ProcessPoolExecutor(max_workers=int(os.getenv('CST_WORKERS','6'))) as pool:
        out=csv.writer(f)
        if not resume:
            out.writerow(['j','P','F','lam','run','ext','n0','n1','sm0','local0','err0','sm1','local1','err1'])
        for row in pool.map(work,jobs,chunksize=1):out.writerow(row);f.flush()
