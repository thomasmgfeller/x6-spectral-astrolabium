"""Exact finite causal halo for a unit ball in spatially unbounded flat dust slices.

The default command validates low-density complete orders and predicts the high-density
point counts. The --one option evaluates one chosen complete order in the halo.
"""
import argparse, csv, json, math, platform, time
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from analysis import write
from cap_geometry import eta
from full_run import compile_kernel, compute
from checks import exact
from cap_run import s,cfg
ball=(3/(4*math.pi))**(1/3)

def halo_cloud(seed,lam,index,P,F):
    rng=np.random.default_rng(np.random.SeedSequence([seed,lam,index]))
    lo,hi=s-P,s+F
    q0,q1=eta(lo),eta(hi)
    radius=ball+q1-q0
    side=2.01*radius
    # Uniform physical four-volume proposal in the maximum comoving sphere.
    volume=4*math.pi/3*radius**3*((1-lo)**3-(1-hi)**3)/3
    n=rng.poisson(lam*volume)
    t=1-np.cbrt(rng.uniform((1-hi)**3,(1-lo)**3,n))
    maxr=ball+q1-eta(t)
    retained=rng.random(n)<(maxr/radius)**3
    t=t[retained];t.sort()
    q=eta(t);maxr=ball+q1-q
    u=rng.normal(size=(len(t),3))
    u/=np.linalg.norm(u,axis=1)[:,None]
    r=maxr*np.cbrt(rng.random(len(t)))
    xyz=u*r[:,None]+side/2
    sigma=(r<ball)/(1-t)**2
    return len(t),t,q,xyz,sigma,side,s,float(lam),q0,q1

def counts(lam,P,F):
    lo,hi=s-P,s+F
    n=lam*quad(lambda t: (1-t)**2*4*math.pi/3*(ball+eta(hi)-eta(t))**3,lo,hi)[0]
    nx=lam*((1-s)**3-(1-hi)**3)/3
    return n,nx

def checks():
    records=[];forecast=[]
    for j,(P,F) in enumerate(cfg['windows']):
        for i in range(2):
            lam=1400;args=halo_cloud(20261102891+j,lam,i,P,F)
            n,t,q,xyz,sig,_,cut,_,_,_=args
            for p in (.1,.5):
                _,value,_,err=compute(args,p*lam)
                expected=exact(t,q,xyz,sig>0,cut,lam,p*lam,periodic=None)
                assert abs(value-expected)<err+1e-10
                records.append(dict(j=j,run=i,p=p,n=n,grid=value,nonperiodic_oracle=expected,gap=abs(value-expected)))
        for lam in cfg['input_densities']:
            n,nx=counts(lam,P,F)
            forecast.append(dict(j=j,P=P,F=F,lam=lam,expected_halo=n,expected_marked_future=nx,
                minimum_cube_side=2*(ball+eta(s+F)-eta(s-P))))
    write('halo_checks.csv',records);write('halo_cost.csv',forecast)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--one',type=int,metavar='SEED')
    parser.add_argument('--window',type=int,choices=[0,1],default=0)
    parser.add_argument('--density',type=int,choices=cfg['input_densities'],default=6000000)
    args=parser.parse_args()
    if not Path('whole_grid_native.so').exists():compile_kernel()
    if args.one is None:
        checks()
    else:
        if args.density<cfg['effective_density']:parser.error('density must be at least mu')
        P,F=cfg['windows'][args.window];lam=args.density
        started=time.process_time()
        order=halo_cloud(args.one,lam,args.window,P,F)
        marked,raw,local,err=compute(order,cfg['effective_density'])
        with open('expectations.csv') as f:
            rows=list(csv.DictReader(f))
        def pred(l):
            return float(next(r['Rpred'] for r in rows if int(r['j'])==args.window and int(r['lam'])==l))
        result=dict(window=args.window,P=P,F=F,density=lam,effective_density=cfg['effective_density'],
                    seed=args.one,n=order[0],marked=int(marked),smoothed=raw/pred(cfg['effective_density']),
                    local=local/pred(lam),tail_bound=err/pred(cfg['effective_density']),
                    process_cpu_seconds=time.process_time()-started,python=platform.python_version(),
                    architecture=platform.machine(),numpy=np.__version__)
        print(json.dumps(result,indent=2,allow_nan=False))
