"""Compute a fixed time-stratified subset of marked endpoints solely to measure cost."""
from pathlib import Path
import math,time
import numpy as np
from analysis import write
from cap_run import cfg,mu,s
from full_run import load,compile_kernel
from halo_reference import halo_cloud
from weights import layer_table

def run():
    if not Path('whole_grid_native.so').exists():compile_kernel()
    data=[];lam=6000000;seed=20261102911;w,eps=layer_table(mu/lam)
    kernel=load()
    for j,(P,F) in enumerate(cfg['windows']):
        args=halo_cloud(seed,lam,j,P,F)
        n,t,q,xyz,sigma,side,cut,den,q0,q1=args
        idx=np.flatnonzero((t>=s)&(sigma>0));rng=np.random.default_rng([seed,j,1])
        selected=np.sort(np.concatenate([rng.choice(group,4,replace=False) for group in np.array_split(idx,8)]))
        mark=np.zeros_like(sigma)
        def timed():
            dst=np.zeros(2);start=time.process_time()
            kernel(n,t,q,xyz,mark,side,cut,den,q0,q1,w,len(w),dst)
            return time.process_time()-start,dst
        setup,_=timed()
        mark[selected]=sigma[selected]
        cpu,sums=timed()
        raw=-2*(mu/lam)**2*sums[0]/math.sqrt(6*mu)
        data.append(dict(j=j,lam=lam,seed=seed,halo_points=n,marked_future=len(idx),tested=len(selected),
                         cpu_full_grid_only=setup,cpu_sample=cpu,partial_raw=raw,
                         projected_core_hours=(setup+max(0,cpu-setup)*len(idx)/len(selected))/3600))
        write('high_cost.csv',data)
        del args,n,t,q,xyz,sigma,idx,selected,mark
if __name__=='__main__':run()
