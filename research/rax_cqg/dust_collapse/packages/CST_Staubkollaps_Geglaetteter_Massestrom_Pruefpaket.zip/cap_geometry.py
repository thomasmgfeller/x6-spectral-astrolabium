"""Terminal caps and their common exterior in homogeneous flat dust slices."""
import math
import numpy as np
def eta(t):return -3*np.expm1(np.log1p(-t)/3)
def time_of_eta(q):return -np.expm1(3*np.log1p(-q/3))
def scale4(q):return (1-q/3)**8
def sphere(rng,r):
    vec=rng.normal(size=(len(r),3));norm=np.linalg.norm(vec,axis=1)
    return vec*(r*np.cbrt(rng.random(len(r)))/norm)[:,None]
def draw_cap(rng,qb,q1,lam):
    span=q1-qb
    n=rng.poisson(lam*math.pi/3*scale4(qb)*span**4)
    q=qb+span*rng.random(n)**.25
    q=q[rng.random(n)*scale4(qb)<scale4(q)]
    return q,sphere(rng,q-qb)
def draw_exterior(rng,q0,qb,q1,r,lam):
    outer=r+q1-q0
    n=rng.poisson(lam*math.pi/3*scale4(q0)*(outer**4-r**4))
    radii=(r**4+(outer**4-r**4)*rng.random(n))**.25
    q=q1+r-radii
    keep=rng.random(n)*scale4(q0)<scale4(q)
    q=q[keep]; xyz=sphere(rng,radii[keep])
    inside=(q>qb)&(np.sum(xyz*xyz,axis=1)<np.maximum(0.,q-qb)**2)
    return q[~inside],xyz[~inside]
