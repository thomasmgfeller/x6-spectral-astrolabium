"""Display the mean bounce and the cutoff sensitivity of two odd preparations."""
import csv
from fractions import Fraction
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
path=Path(__file__).resolve().parent
with (path/'cutoffs.csv').open() as stream:
    rows=list(csv.DictReader(stream))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
fig,(a,b)=plt.subplots(1,2,figsize=(7.6,2.55))
fig.subplots_adjust(left=.08,right=.99,bottom=.23,top=.86,wspace=.37)
t=np.linspace(-.25,.25,181)
a.plot(t,.75+12*t*t,c='#08736a',label='Lineares Paket')
a.plot(t,1.75+44/5*t*t,c='#a5532a',label='Kubisches Paket')
a.scatter([0,0],[.75,1.75],s=14,c=['#08736a','#a5532a'])
a.set(title='Mittleres Volumen',xlabel='Staubzeit relativ zur Umkehr',ylabel='⟨V⟩',xlim=(-.25,.25),ylim=(.52,2.55))
a.legend(frameon=False,loc='center',fontsize=7.5)
for n,tm,label,color,style in [(1,0,'linear, t = 0','#08736a','-'),(3,0,'kubisch, t = 0','#a5532a','--'),(3,Fraction(1,8),'kubisch, t = 1/8','#57467f','-')]:
    chosen=[r for r in rows if int(r['packet_power'])==n and Fraction(r['time'])==tm]
    xx=[int(r['negative_log2_lower_Y']) for r in chosen]
    yy=[float(r['scipy_check']) for r in chosen]
    b.plot(xx,yy,color=color,ls=style,label=label,marker='.',ms=4)
b.set_yscale('log');b.set(xlabel='j   (untere Grenze Y = 2⁻ʲ)',title='Zweites inverses Moment',ylabel='Regulierter Erwartungswert',xticks=[4,6,8,10])
b.legend(frameon=False,fontsize=7,loc='upper left')
for ax in (a,b):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.16)
fig.savefig(path/'figure.pdf')
