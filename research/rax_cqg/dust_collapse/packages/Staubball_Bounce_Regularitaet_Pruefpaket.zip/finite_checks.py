"""Catalogue inventory, terminal-data counterexample and exact metric/refinement controls."""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parent
PLAN="b9b98d1defec9ecd31ced6bb39da31a8b27a777f955c98fa7dd700370901f15d"
CATALOGUE="53666ad0aab5fcee9ac102f562f83c7b380954c2356844fab7af8cfe4f793c39"


def ranks(edges):
    """Peel current minimal elements without relying on vertex numbering."""
    remaining=set(range(len(edges))); widths=[]
    while remaining:
        above={j for i in remaining for j in edges[i] if j in remaining}
        minima=remaining-above
        if not minima: raise ValueError("Cycle")
        widths.append(len(minima));remaining.difference_update(minima)
    return widths


def catalogue():
    archive=ROOT/'inputs/family_C.zip'
    assert sha256(archive.read_bytes()).hexdigest()==CATALOGUE
    with TemporaryDirectory() as directory:
        with ZipFile(archive) as src: src.extractall(directory)
        sys.path.insert(0,directory)
        import run as previous
        rows=[]
        for k in (1,2,3):
            orbit=Counter(); labelled=Counter()
            for key,multiplicity in previous.orbits(k,4).items():
                edges=previous.graph(previous.PREPS['original'],k,4,key)
                w=ranks(edges)
                assert w==[3,2,k,4,1]
                strict=any(a>b<c for a,b,c in zip(w,w[1:],w[2:]))
                flat=any(w[i-1]>w[i] and w[i]==w[i+1] and w[i+2]>w[i] for i in range(1,len(w)-2))
                assert strict != flat
                label="strict" if strict else "plateau"
                orbit[label]+=1; labelled[label]+=multiplicity
            rows.append(dict(k=k,widths=w,orbits=dict(orbit),labelled=dict(labelled)))
    assert sum(sum(r['orbits'].values()) for r in rows)==840
    assert sum(sum(r['labelled'].values()) for r in rows)==54579
    return rows


def completions():
    # x=t-1. On t>1, Vb'=x^3-(3/2)x^2-1, strictly increasing for x>1.
    derivative=lambda x:x**3-F(3,2)*x*x-1
    lo,hi=F(1),F(2)
    for _ in range(32):
        mid=(lo+hi)/2
        if derivative(mid)<0: lo=mid
        else: hi=mid
    assert derivative(lo)<0<derivative(hi)
    def values(t):
        base=4-t; x=max(F(0),t-1)
        return base,base-x**3*(3-t)/4
    assert all(a==b for a,b in (values(t) for t in (0,F(1,2),1,3)))
    return dict(same_early_until=1,end_volume=1,contract_end_derivative=-1,
                bounce_end_derivative=str(derivative(F(2))),
                bounce_time_bracket=[str(1+lo),str(1+hi)],
                positive_lower_bound=str(1-F(27,64)))


def metric():
    def evaluate(b,c,t):
        volume=b+c*t*t
        H=2*c*t/(3*volume)
        Hdot=2*c*(b-c*t*t)/(3*volume**2)
        direct=12*((Hdot+H*H)**2+H**4)
        s=c*t*t/b
        simplified=F(16,27)*(c/b)**2*(9-6*s+5*s*s)/(1+s)**4
        maximum=F(16,3)*(c/b)**2
        assert direct==simplified
        assert maximum-direct==F(16,27)*(c/b)**2*(42*s+49*s**2+36*s**3+9*s**4)/(1+s)**4
        return volume,direct
    physical=[]
    for nu in (F(1),F(1,2),F(1,4),F(1,8)):
        b=nu**2/4
        vol,K=evaluate(b,F(1),F(0))
        assert vol==b and K*nu**4==F(256,3)
        physical.append(dict(nu=str(nu),Vmin=str(vol),Kmax=str(K)))
    numerical=[]
    for step in (F(1,8),F(1,16),F(1,32),F(1,64)):
        v,k=evaluate(F(1,4),F(1),step/2)
        assert v-F(1,4)==step**2/4
        numerical.append(dict(step=str(step),grid_min=str(v),grid_max_K=str(k)))
    return dict(effective_units='6*pi*G=M=hbar=1',physical_resolution=physical,
                half_shifted_time_grid_at_nu_one=numerical)


if __name__=='__main__':
    if not __debug__: raise RuntimeError("Enable assertions")
    assert sha256((ROOT/'design.json').read_bytes()).hexdigest()==PLAN
    print(json.dumps(dict(catalogue=catalogue(),terminal_completions=completions(),effective=metric(),
                          dynamic_CST_bounce='HOLD',dynamic_CST_regularity='HOLD'),indent=2))
