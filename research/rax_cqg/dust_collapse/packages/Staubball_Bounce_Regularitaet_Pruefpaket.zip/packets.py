"""Analytic evolution, 160-bit cutoff integrals, independent sine propagation and quadrature."""
import csv
from fractions import Fraction as F
import json
import math
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from flint import arb, acb, ctx

ROOT=Path(__file__).resolve().parent
TIMES=[F(-1,4),F(-1,8),F(0),F(1,8),F(1,4)]


def ball(f):
    f=F(f)
    return arb(f.numerator)/f.denominator


def check_packet(n,time):
    t=ball(time); q=acb(1,-4*t)
    a,b=(acb(1),acb(0)) if n==1 else (acb(0,-6*t)/q,1/q**2)
    coeff=[abs(a)**2,2*(a.conjugate()*b).real,abs(b)**2]
    N2=2*(arb(2)**n)*arb(2).sqrt()/ball(F(2*n+1,2)).gamma()
    weight=N2/abs(q)**3
    gamma=2/(1+16*t*t)
    J=[arb.pi().sqrt()/(2*gamma.sqrt())]
    for j in range(1,5):
        J.append((2*j-1)*J[-1]/(2*gamma))
    norm=weight*sum(c*j for c,j in zip(coeff,J[1:4]))
    vol=weight*sum(c*j for c,j in zip(coeff,J[2:5]))
    A=F(2*n+1,4)
    B=F(3) if n==1 else F(11,5)
    inverse_first=weight*sum(c*j for c,j in zip(coeff,J[:3]))
    assert inverse_first < ball(4*B)
    assert norm.contains(1) and (vol-ball(A+4*B*time**2)).contains(0)
    slope2=weight*coeff[0]
    norm_float=math.sqrt(2*2**(n+.5)/math.gamma(n+.5))
    tf=float(time); qf=1-4j*tf
    def wave(y):
        poly=1 if n==1 else (y*y/qf**2-6j*tf/qf)
        return norm_float*y*qf**(-1.5)*np.exp(-y*y/qf)*poly
    def spectrum(k):
        factor=1 if n==1 else (1.5-k*k/4)
        return norm_float*np.sqrt(2)*k/4*np.exp(-k*k/4)*factor
    def sine_value(y,wall=False):
        def integrand(k):
            kernel=k if wall else np.sin(k*y)
            return np.sqrt(2/math.pi)*spectrum(k)*np.exp(1j*tf*k*k)*kernel
        return sum(factor*quad(lambda k:float(part(integrand(k))),0,32,
                   epsabs=4e-13,epsrel=4e-13)[0] for part,factor in [(np.real,1),(np.imag,1j)])
    errors=[abs(sine_value(y)-wave(y)) for y in (.125,.5,1.5)]
    errors.append(abs(abs(sine_value(0,True))**2-float(slope2)))
    assert max(errors)<8e-11
    def cutoff(e):
        exp=(-gamma*e*e).exp()
        j0=(gamma.sqrt()*e).erfc()*arb.pi().sqrt()/(2*gamma.sqrt())
        values=[exp/e-2*gamma*j0,j0,(e*exp+j0)/(2*gamma)]
        return weight*sum(c*j for c,j in zip(coeff,values))
    rows=[]
    for j in range(4,11):
        ef=2.**(-j); e=ball(F(1,2**j))
        theory=cutoff(e)
        def integrand(y):return abs(wave(y))**2/y**4
        numeric=sum(quad(integrand,lo,hi,epsabs=2e-12,epsrel=2e-13)[0] for lo,hi in ((ef,1),(1,np.inf)))
        err=abs(numeric-float(theory))/max(1.,abs(numeric))
        assert err<1e-10
        coeff_est=e*(cutoff(e/2)-theory)
        rows.append((n,str(time),j,str(theory),format(numeric,'.15g'),str(coeff_est)))
    if n==3 and time==0:
        finite=weight*coeff[2]*J[1]
        assert finite.contains(ball(F(16,15))) and slope2==0
    else:
        assert slope2>0
    return dict(volume=str(vol),inverse_first=str(inverse_first),hardy_bound=str(4*B),boundary_slope_squared=str(slope2),
                infinite_inverse_second_moment=not (n==3 and time==0),
                sine_evolution_max_error=max(errors)),rows


def run():
    ctx.prec=160
    results={}
    with (ROOT/'cutoffs.csv').open('w',newline='') as stream:
        wr=csv.writer(stream,lineterminator='\n')
        wr.writerow(['packet_power','time','negative_log2_lower_Y','inverse_moment_ball','scipy_check','leading_coefficient_estimate_ball'])
        for n in (1,3):
            results[str(n)]={}
            for t in TIMES:
                item,rows=check_packet(n,t)
                results[str(n)][str(t)]=item
                wr.writerows(rows)
    return dict(kappa=1,hbar=1,beta=1,bits=ctx.prec,packets=results,
                finite_focus_inverse_second_moment_cubic='16/15')


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Enable assertions')
    print(json.dumps(run(),indent=2))
