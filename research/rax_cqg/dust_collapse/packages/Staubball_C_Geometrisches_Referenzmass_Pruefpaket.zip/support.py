"""Supplementary deterministic positive-volume witnesses; no additional pilot draws."""
import json
from fractions import Fraction as F
from itertools import combinations
from catalogue import c_key

DELTA = F(1,1000)
R = F(1,8)


def fraction_early(t, dust):
    return (512-(-t)**9)/511 if dust else t+2


def point(time, x):
    return tuple(map(F,(time,x,0,0)))


def check(k):
    early=[point("-1.98",x) for x in ("-.04","0",".04")]
    early += [point("-1.95",x) for x in ("-.02",".02")]
    middle=[point("-1.5",x) for x in {1:("0",),2:("-.02",".02"),3:("-.04","0",".04")}[k]]
    upper=[point("-1.30",x) for x in ("-.06","-.02",".02",".06")]
    points=early+middle+upper+[point("-1.1","0")]
    for i,(t,*spatial) in enumerate(points):
        assert -2<t-DELTA<t+DELTA<-1
        assert sum((abs(s)+DELTA)**2 for s in spatial)<R**2
        for dust in (True,False):
            edge=t+DELTA if i<5 else t-DELTA
            assert (fraction_early(edge,dust)<F(5,12) if i<5 else fraction_early(edge,dust)>F(5,12))
    future=[set() for _ in points]
    for (i,a),(j,b) in combinations(enumerate(points),2):
        dt=b[0]-a[0]
        d=[abs(bt-at) for at,bt in zip(a[1:],b[1:])]
        assert any(abs(bv-av)>2*DELTA for av,bv in zip(a,b)), "overlapping boxes"
        max_r2=sum((dx+2*DELTA)**2 for dx in d)
        min_r2=sum(max(F(0),dx-2*DELTA)**2 for dx in d)
        if dt>2*DELTA and (dt-2*DELTA)**2>max_r2:
            future[i].add(j)
        else:
            assert (abs(dt)+2*DELTA)**2<min_r2, "pair unresolved on open boxes"
    full=(1<<k)-1
    expected=(k,(full,full,(full,)*4))
    for roles in ([0,1,2,3,4],[2,1,0,4,3]):
        assert c_key(future,roles)==expected
    return dict(k=k,centres=[[str(s) for s in p] for p in points],positive_for_both_geometries=True)


if __name__=="__main__":
    if not __debug__: raise RuntimeError("Assertions required")
    print(json.dumps(dict(half_width=str(DELTA),witnesses=[check(k) for k in (1,2,3)]),indent=2))
