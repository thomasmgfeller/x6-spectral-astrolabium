"""Isomorphism key for family C with its five individual early roles fixed."""
from functools import cache
from itertools import permutations


@cache
def bit_maps(k):
    return [[sum(1 << p[i] for i in range(k) if mask & (1<<i))
             for mask in range(1<<k)] for p in permutations(range(k))]


def orbit_key(k, a, b, columns):
    return min((m[a],m[b],tuple(sorted(m[c] for c in columns))) for m in bit_maps(k))


def closure(edges):
    future = [set(row) for row in edges]
    for j in range(len(edges)):
        for row in future:
            if j in row:
                row.update(future[j])
    return future


def c_key(future, roles):
    """Accept only the complete old poset, including absence of skip-layer covers."""
    n = len(future)
    k = n-10
    if k not in (1,2,3) or len(set(roles)) != 5:
        return None
    remaining = set(range(n))
    layers = []
    for width in (3,2,k,4,1):
        later = set().union(*(future[i] for i in remaining))
        level = sorted(remaining - later)
        if len(level) != width:
            return None
        layers.append(level)
        remaining.difference_update(level)
    if remaining or set(layers[0]) != set(roles[:3]) or set(layers[1]) != set(roles[3:]):
        return None
    layers[0],layers[1] = list(roles[:3]),list(roles[3:])
    edges = [[] for _ in future]
    for low, high in zip(layers,layers[1:]):
        for i in low:
            edges[i] = [v for v in high if v in future[i]]
            if not edges[i]:
                return None
    if closure(edges) != future:
        return None
    def masks(low,high):
        return [sum(1<<j for j,v in enumerate(high) if v in future[i]) for i in low]
    if masks(layers[0], layers[1]) != [1,3,2]:
        return None
    a,b = masks(layers[1],layers[2])
    cols = tuple(sum(1<<j for j,u in enumerate(layers[2]) if v in future[u]) for v in layers[3])
    return k, orbit_key(k,a,b,cols)
