"""Exact finite checks preceding the 4-D pilot."""
import csv
import hashlib
import itertools
import json
import math
import sys
import tempfile
import zipfile
from collections import Counter
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from catalogue import c_key, closure, orbit_key

ROOT = Path(__file__).resolve().parent
PLAN = "e0d4b5b3c2a3b460993a017a3e5983ecdc812ea4f64c712ad5b38e99298baa6b"
REFERENCE = "53666ad0aab5fcee9ac102f562f83c7b380954c2356844fab7af8cfe4f793c39"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def check_inputs():
    for name,digest in (("design.json",PLAN),("reference_C.zip",REFERENCE)):
        require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name)


def diamond(n, marked):
    # Orders of labels along the two independent uniform null coordinates.
    perms = list(itertools.permutations(range(n)))
    renames = [p for p in perms if not marked or p[:2] == (0,1)]
    def relation(u,v):
        return tuple(sorted((a,b) for i,a in enumerate(u) for b in u[i+1:] if v.index(a)<v.index(b)))
    def admissible(edges):
        # Marked labels 0 and 1 are incomparable minima, fixed individually.
        return not marked or not any(b in (0,1) for a,b in edges)
    @cache
    def images(edges):
        return frozenset(tuple(sorted((p[a],p[b]) for a,b in edges)) for p in renames)
    labelled = Counter(relation(u,v) for u in perms for v in perms)
    direct = Counter()
    for edges,count in labelled.items():
        if admissible(edges):
            direct[min(images(edges))] += count
    # Independently sort on u, then assign two distinct anchor identities uniformly
    # among rank positions (or use the full unmarked permutation symmetry).
    sorted_u = tuple(range(n))
    representative = Counter()
    for v in perms:
        edges = relation(sorted_u,v)
        for ranks in (itertools.permutations(range(n),2) if marked else [()]):
            order = list(ranks)+[j for j in range(n) if j not in ranks]
            marked_edges = tuple(sorted((order.index(a),order.index(b)) for a,b in edges))
            if admissible(marked_edges):
                representative[min(images(marked_edges))] += 1
    d1 = math.factorial(n)**2
    d2 = math.factorial(n)*(n*(n-1) if marked else 1)
    target = {g:F(c,d1) for g,c in direct.items()}
    require(target == {g:F(c,d2) for g,c in representative.items()},'sorted-u enumeration')
    for g,prob in target.items():
        orbit = images(g)
        expected = F(labelled[g],d1) * len(orbit)
        stabilizer = sum(tuple(sorted((p[a],p[b]) for a,b in g)) == g for p in renames)
        require(len(orbit)*stabilizer==len(renames) and prob==expected,'orbit-stabilizer')
        require(all(labelled[h]==labelled[g] for h in orbit),'relabel invariance')
    event = sum(target.values())
    require(event>0 and sum(x/event for x in target.values())==1,'conditional mass')
    if not marked:
        require(event==1,'unit total')
    if n==2 and not marked:
        require(sorted(target.values())==[F(1,2)]*2,'two-point analytic')
    bad = sum(p/len(images(g)) for g,p in target.items())
    return dict(n=n,marked=marked,classes=len(target),event=str(event),wrong_factor_total=str(bad),
                wrong_correction_detectable=bad != event,
                joint_class_weights={str(g):str(target[g]) for g in sorted(target)})


def family(ref):
    sys.path.insert(0,str(ref))
    import run as reference
    totals, label_totals = [], []
    by_class = []
    skip_rejected = False
    for k in (1,2,3):
        full=(1<<k)-1
        counts=Counter()
        for a,b in itertools.product(range(1,full+1),repeat=2):
            if a|b != full: continue
            for cols in itertools.product(range(1,full+1),repeat=4):
                if cols[0]|cols[1]|cols[2]|cols[3] == full:
                    counts[orbit_key(k,a,b,cols)] += 1
        require(counts==reference.orbits(k,4),'full labelled catalogue')
        for key,multiple in counts.items():
            edges=reference.graph(reference.PREPS['original'],k,4,key)
            future=closure(edges)
            require(c_key(future,(0,1,2,3,4))==(k,key),'graph round trip')
            rev=list(reversed(range(len(edges))))
            shuffled=[set() for _ in edges]
            for i,row in enumerate(future):
                shuffled[rev[i]]={rev[j] for j in row}
            require(c_key(shuffled,rev[:5])==(k,key),'point relabel test')
            if not skip_rejected:
                for u in range(3):
                    target=next((v for v in range(5,5+k) if v not in future[u]),None)
                    if target is not None:
                        bad=[list(v) for v in edges]
                        bad[u].append(target)
                        require(c_key(closure(bad),range(5)) is None,'skip-cover negative')
                        skip_rejected=True
                        break
        broken=[list(row) for row in edges]
        for row in broken:
            if len(edges)-1 in row: row.remove(len(edges)-1)
        require(c_key(closure(broken),range(5)) is None,'detached sink')
        totals.append(len(counts));label_totals.append(sum(counts.values()))
        by_class.append(dict(k=k,orbits=len(counts),labelled=sum(counts.values())))
    require(sum(totals)==840 and sum(label_totals)==54579 and skip_rejected,'catalogue inventory')
    return by_class


def run():
    check_inputs()
    exact = [diamond(n,marked) for n in (2,3,4) for marked in (False,True)]
    require(any(x['wrong_correction_detectable'] for x in exact if x['marked']),'marked negative')
    # Algebraic Poisson identity: normalization of n-conditional orbit distributions
    # preserves each class mass, including an outside-C residual. Check lambda=7
    # relative to exp(-7), so all checked expressions remain rational.
    weights=[F(7**m,math.factorial(m)) for m in (6,7,8)]
    require(weights[1]/weights[0]==1 and weights[2]/weights[1]==F(7,8),'Poisson sizes')
    with tempfile.TemporaryDirectory() as d:
        base=Path(d)
        with zipfile.ZipFile(ROOT/'reference_C.zip') as z: z.extractall(base)
        cases=family(base)
    return dict(gate="PASS",design_sha256=PLAN,diamond=exact,catalogue=cases,
                relative_poisson_weights_6_7_8=[str(v/weights[0]) for v in weights],
                skip_cover_and_detached_sink_rejected=True)


if __name__ == '__main__':
    print(json.dumps(run(),indent=2))
