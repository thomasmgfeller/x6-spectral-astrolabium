# Geometrisches Referenzmass für Randfamilie C

Der kleine Quotiententest prüft die Abbildung von beschrifteten Punktmengen auf Ordnungsklassen. Der anschliessende Pilot schätzt getrennt die Zugehörigkeit zur Familie C nach den frühen Daten E und die bedingte Verteilung innerhalb von C. Der Versuch verwendet eine vorgegebene klassische Staubgeometrie, eine flache geometrische Kontrolle und die bisherigen 840 unmarkierten Ausgangsgeometrien. Das dynamische Wachstumsmass aus PR 212 bleibt ein eigener Vergleich.

## Reproduktion

Alle Eingaben sind im Archiv. Getestet unter Linux mit Python 3.12, NumPy 2.3.5 und SciPy 1.17.0. Die wissenschaftlichen Skripte im normalen Python-Modus ausführen. Die exakten Quotienten- und Stütztests verwenden nur die Standardbibliothek, der Pilot zusätzlich NumPy und SciPy. Die Programme lesen keine externen Daten. Die beiden Geometrien benötigen zusammen 2 097 152 frühe Quintette. Die genaue Sequenz hängt unter anderem von Softwareversion und Blockgrösse ab.

    sha256sum -c SHA256SUMS
    python3 -m venv .venv
    .venv/bin/python -m pip install numpy==2.3.5 scipy==1.17.0
    .venv/bin/python quotient_gate.py > gate-replay.json
    cmp gate-replay.json gate.json
    OPENBLAS_NUM_THREADS=1 .venv/bin/python pilot.py > pilot-replay.json
    cmp pilot-replay.json pilot_results.json
    .venv/bin/python support.py > support-replay.json
    cmp support-replay.json support.json
    sha256sum -c SHA256SUMS

design.json und DESIGN_SHA256 dokumentieren die lokale Festlegung vor dem Pilotlauf. Es gab keine externe Präregistrierung. Das Archiv reference_C.zip ist die veröffentlichte Fassung aus PR 210. pilot.py vergleicht das frisch berechnete Quotientenzertifikat mit gate.json, bevor es Daten zieht. support.py ist eine nachträgliche, unabhängige Zusatzfrage zur Existenz geometrischer Beispiele. Es verändert keine Auswertungsentscheidung.

## Quotient und frühe Rollen

Sei π die Abbildung einer beschrifteten geometrischen Stichprobe auf die Isomorphieklasse ihrer Ordnung, einschliesslich der fixierten frühen Rollen. Das Gewicht der Klasse ist die Wahrscheinlichkeit ihres gesamten Urbildes. Die Urbilder verschiedener Klassen sind disjunkt. Jede zulässige Umbenennung innerhalb einer austauschbaren Gruppe bewahrt das geometrische Produktmass; für beliebige feste Koordinaten wird dabei die Rolleninformation mitgeführt. Die Wahrscheinlichkeit einer Klasse ist die Summe der Wahrscheinlichkeiten der verschiedenen beschrifteten Vertreter. Eine direkte Ablage jeder vollständigen Stichprobe in genau einer Klasse erledigt diese Summe bereits. Einen weiteren Symmetriefaktor einzusetzen verändert im Allgemeinen die Gesamtmasse.

Im flachen 1+1-Diamanten mit normierten Nullkoordinaten sind die beiden Rängefolgen gleichverteilt und unabhängig. Für N=2,3,4 werden alle (N!)² Kombinationen exakt und mit rationaler Arithmetik gezählt. Ein zweiter Weg sortiert nach der ersten Koordinate und variiert die zweite. Im verankerten Kontrollfall sind die Labels 0 und 1 unvergleichbare Minimalpunkte; beide bleiben punktweise fixiert. Das markierte Kontrollereignis ist absichtlich ein kleinerer, analytisch zählbarer Fall. Auch bei Konditionierung bleibt die Gesamtwahrscheinlichkeit eins. Der Test kontrolliert für jede Klasse ihre Anzahl unterschiedlicher Vertreter und den Stabilisator. Eine absichtlich zusätzlich durch die Orbitgrösse geteilte Summe liefert schon bei N=2 ohne Rollen nur 3/4.

Im grossen C-Katalog werden die beschrifteten Inzidenzen zwischen den Schichten direkt aufgelistet. Für jede der 840 Ordnungsklassen werden eine rückwärts indizierte Version und die Ausgangsordnung erkannt. Ein zusätzlicher Überdeckungslink über eine Schicht hinweg und ein abgetrennter Endpunkt werden als Negativkontrollen verworfen. catalogue.py vergleicht die gesamte transitive Ordnung mit der Hülle der zulässigen Nachbarschichtrelationen. Die Katalog-Multiplizitäten sind kein Ersatz für geometrische Wahrscheinlichkeiten.

## Vierdimensionales Gebiet

Die Einheiten beziehen sich auf eine frei gewählte konforme Länge. Bei -2 < η < -1 und |x| < 1/8 ist die Metrik a²(-dη²+dx²). Das marginal gebundene homogene Staubinnere hat a=η²/4. Das flache Vergleichsgebiet hat konstantes a=(511/2304)^(1/4). Damit stimmen Vierervolumen, Streudichte und konforme Kegel überein. Der konvexe räumliche Querschnitt enthält das gerade Segment zwischen jedem Punktepaar. Das gemeinsame Vierervolumen ist V=(4π/3)(1/8)^3 (511/2304). Die Dichte ist 12/V. Die Punktzahl ist vor der Konditionierung Poisson-verteilt mit Mittel 12. Diese Werte definieren ein Referenzfenster; sie sind nicht an physikalische Messwerte angepasst.

Frühes und spätes Fenster haben Volumenanteile 5/12 und 7/12. Singuläre Zeitgrenzen haben Mass null. Die frühe Beobachtung ist ausschliesslich im frühen Fenster definiert. Es enthält genau fünf Punkte und die vorgegebene Ordnung mit drei minimalen und zwei maximalen Ereignissen. Jeder obere Punkt hat zwei Vorgänger, beide haben einen gemeinsamen Vorgänger. Eine unabhängige faire Orientierung der beiden oberen Punkte legt zusammen mit der frühen Ordnung die fünf Rollen fest. Praktisch wird von den oberen Punkten einer nach der frühen Uhr zuerst genannt und die Zuordnung dann per Münzwurf gewählt. So zählen wir jede gültige Frühordnung einmal und gewichten die kompatiblen Rollenzuordnungen zusammen mit Gewicht eins. Dies ist eine Beobachtungsvorschrift für anonyme Poisson-Punkte. Ein Experiment mit vorgegebenen räumlichen Ankerpositionen hätte ein anderes bedingtes Mass.

Bedingt auf die Zahl der Punkte ist die Raumposition gleichverteilt in der dreidimensionalen Kugel. Für einen normierten Volumenzeitpunkt u in [0,1] lautet die konforme Zeit im Staub η=−(512−511u)^(1/9) und in der Kontrolle η=−2+u. Die jeweilige frühe oder späte Verteilung ergibt sich durch die Wahl des u-Teilintervalls.

## Statistische Auswertung

Jedes der 1 048 576 frühen Quintette je Geometrie ist bereits auf N_früh=5 bedingt. P(E) ist die gemessene frühe Formrate mal dem Poisson-Faktor exp(−5)5^5/5!. Nur bei passender Form wird weitergerechnet. Dann erzeugen wir pro frühem Beispiel jeweils eine späte Stichprobe zu jeder der Grössen m=6,7,8. Die gemeinsame frühe Lage erzeugt Abhängigkeiten zwischen den drei Strata, innerhalb eines Stratums sind die Versuche im idealen Modell unabhängig. Weil die disjunkten Zeitfenster unabhängige Poisson-Zahlen haben und alle anderen Grössen keinen Beitrag zu C leisten, gilt

    P(C | E) = Summe_m [exp(−7) 7^m/m!] P(C | E, M=m).

Das Verhältnis der drei Faktoren ist 8 : 8 : 7. Zusammen haben sie die Masse 0,4284 (gerundet). Ihre Werte werden in dieser Summe nicht auf eins normiert. Bei einem C-Treffer bleibt seine Isomorphieklasse im Rohzählprotokoll erhalten; es gibt keine weitere Gewichtung nach Umbenennungen oder Markierungen. Für P([G] | E,C) wäre der unbedingte Stratumfaktor mal der beobachteten Orbitrate durch die Gesamtmasse von C zu teilen. Bei null Treffern ist die empirische Division undefiniert. Nullbeobachtungen sind keine strukturellen Nullen.

Die acht einzelnen binomialen Proportionen (zwei frühe Raten und sechs späte Trefferquoten) erhalten exakte zweiseitige Clopper-Pearson-Intervalle mit Fehleranteil 0,05/8 je Intervall. Die Bonferroni-Abdeckung benötigt keine Unabhängigkeit zwischen den Strata. Die lineare Kombination und die Quotientenhüllen der drei Klassen verwenden die simultanen Grenzen. Der bedingte Nenner ist die tatsächlich beobachtete Zahl passender früher Quintette. pilot_results.json enthält die acht Raten in Form der Zähler und zugehörigen Stichprobengrössen, abgeleitete Grössen und alle beobachteten Orbitkennungen. Der finale Status HOLD folgt aus der vorab geforderten Zahl verschiedener früher Trefferträger und der Intervallbreite. Die Intervalle beziehen sich auf die modellierte iid-Stichprobe; die Implementierung verwendet Pseudozufall und Gleitkomma. Eine Abstandsprüfung verlangt einen Abstand vom Lichtkegel von mindestens 1e-13 im verwendeten quadrierten Koordinatenmass. Sie ist keine umfassende Fehlerzertifizierung des Zufallszahlengenerators.

## Positive geometrische Beispiele

Die nachträgliche Kontrolle in support.py verwendet disjunkte offene vierdimensionale Koordinatenboxen mit rationalen Zentren und Halbkantenlänge 1/1000. Für jede mögliche Breite werden Kugelrand, frühe/späte Lage und alle Paarrelationen für die ganzen Boxen mit rationalen Schranken kontrolliert. Genau ein Punkt in jeder Box und keine weiteren Punkte im Gesamtfenster hat Wahrscheinlichkeit exp(−ρV) mal dem Produkt aller positiven Faktoren ρV_i. Da beide Volumendichten hier strikt positiv sind, haben die drei konstruierten, voll zwischen den späteren Nachbarschichten verbundenen Ordnungen positives Gewicht in beiden Geometrien. Der Beweis sagt nichts über die Gewichte der übrigen Orbits oder praktisch messbare Untergrenzen.

Quellen: [Bombelli, statistische Lorentzgeometrie](https://arxiv.org/abs/gr-qc/0002053), [Surya, Poisson-Streuung auf Kausalsets](https://doi.org/10.1007/s41114-019-0023-1), [Trodden und Carroll, Gleichungen 38–40](https://ned.ipac.caltech.edu/level5/Sept03/Trodden/paper.pdf). Die Inhalte des Referenzarchivs stammen aus [PR 210](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/210). Das separate Wachstumsergebnis ist in [PR 212](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/212) dokumentiert.
