"""Fixed-budget conditional geometric pilot after a successful exact quotient audit."""
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.stats import beta

from catalogue import c_key
from quotient_gate import run as quotient_gate

ROOT = Path(__file__).resolve().parent
TRIALS = 1 << 20
CHUNK = 4096
SEED = 2026110417
RADIUS = 1/8
SPLIT = 5/12


def points(rng, count, number, is_dust, early):
    low,high = (0,SPLIT) if early else (SPLIT,1)
    volume_time = rng.uniform(low,high,(count,number))
    eta = -(512-511*volume_time)**(1/9) if is_dust else -2+volume_time
    xyz = rng.normal(size=(count,number,3))
    lengths = np.linalg.norm(xyz,axis=2)
    if np.any(lengths==0): raise RuntimeError("Unusable random direction")
    xyz *= (RADIUS*np.cbrt(rng.random((count,number)))/lengths)[:,:,None]
    return eta,xyz


def order(t,x):
    dt = t[:,None,:] - t[:,:,None]
    dx = x[:,None,:,:] - x[:,:,None,:]
    distance2 = np.einsum("...l,...l->...",dx,dx)
    gap = dt*dt-distance2
    # Track closeness to the cone at the scale of these coordinates.
    offdiag = np.triu_indices(t.shape[1],1)
    near = np.count_nonzero(abs(gap[:,offdiag[0],offdiag[1]]) < 1e-13)
    if near: raise ArithmeticError("Near-null comparison needs higher-precision replay")
    return (dt>0) & (gap>0)


def early_rows(rel):
    inc = rel.sum(axis=1)
    out = rel.sum(axis=2)
    return np.flatnonzero((((inc==2)&(out==0)).sum(axis=1)==2)
                      & (((inc==0)&(out==2)).sum(axis=1)==1)
                      & (((inc==0)&(out==1)).sum(axis=1)==2))


def seed_roles(rel,t,coin):
    upper = np.flatnonzero(rel.sum(axis=0)==2)
    left,right = upper[np.argsort(t[upper],kind="stable")]
    if t[left]==t[right]: raise ArithmeticError("Tied early clocks")
    if coin: left,right=right,left
    mask=rel[:,left].astype(int)+2*rel[:,right]
    return [int(np.flatnonzero(mask==j)[0]) for j in (1,3,2)]+[int(left),int(right)]


def cp(hit,n):
    if not n: return (0.,1.)
    tail=.05/(2*8)
    return (0. if hit==0 else float(beta.ppf(tail,hit,n-hit+1)),
            1. if hit==n else float(beta.isf(tail,hit+1,n-hit)))


def summary(n,accepted,hits):
    pmf = [math.exp(-7)*7**m/math.factorial(m) for m in (6,7,8)]
    early_count_p = math.exp(-5)*5**5/math.factorial(5)
    early_bounds = cp(accepted,n)
    joint = [(p*lo,p*hi) for p,(lo,hi) in zip(pmf,[cp(x,accepted) for x in hits])]
    lo,hi = [sum(v) for v in zip(*joint)]
    ratios=[]
    for k,(lower,upper) in enumerate(joint):
        others=[b for i,b in enumerate(joint) if i!=k]
        d_lo=lower+sum(o[1] for o in others)
        d_hi=upper+sum(o[0] for o in others)
        ratios.append([lower/d_lo if d_lo else 0.,upper/d_hi if d_hi else 1.])
    return dict(p_early=early_count_p*accepted/n,p_early_bounds=[early_count_p*x for x in early_bounds],
                p_C_given_E=sum(p*h/accepted for p,h in zip(pmf,hits)) if accepted else None,
                p_C_given_E_bounds=[lo,hi],class_intervals=ratios,
                joint_class_given_E_bounds=joint,poisson_late_strata=pmf)


def geometry(label,geo_id):
    rngs = [np.random.Generator(np.random.PCG64(np.random.SeedSequence([SEED,geo_id,tag]))) for tag in range(5)]
    counts=[Counter() for _ in range(3)]
    accepted=0
    unique=0
    for offset in range(0,TRIALS,CHUNK):
        early_t,early_x=points(rngs[0],CHUNK,5,label=="dust",True)
        early_rel=order(early_t,early_x)
        indices=early_rows(early_rel)
        n=len(indices)
        if not n: continue
        t,x=early_t[indices],early_x[indices]
        coins=rngs[1].integers(0,2,size=n)
        roles=[seed_roles(early_rel[j],early_t[j],c) for j,c in zip(indices,coins)]
        accepted+=n
        successful=set()
        for s,m in enumerate((6,7,8)):
            late_t,late_x=points(rngs[2+s],n,m,label=="dust",False)
            rel=order(np.concatenate((t,late_t),axis=1),np.concatenate((x,late_x),axis=1))
            # In C the unique sink lies above every other point.
            possible=np.flatnonzero((rel.sum(axis=1)==(m+4)).any(axis=1))
            for i in possible:
                future=[set(np.flatnonzero(row)) for row in rel[i]]
                key=c_key(future,roles[i])
                if key is not None:
                    k,(a,b,cols)=key
                    if k!=m-5: raise ValueError("Size mismatch")
                    name=f"{k}/{a}/{b}/"+",".join(map(str,cols))
                    counts[s][name]+=1
                    successful.add(int(i))
        unique+=len(successful)
    hits=[sum(counter.values()) for counter in counts]
    stats=summary(TRIALS,accepted,hits)
    return dict(early_quintets=TRIALS,early_shapes=accepted,stratum_C_hits=hits,independent_early_rows_with_any_C=unique,
                observed_orbit_counts=[dict(sorted(c.items())) for c in counts],**stats,
                screening_pass=bool(unique>=100 and all(hi-lo<=.1 for lo,hi in stats["class_intervals"])))


def main():
    exact=quotient_gate()
    if exact!=json.loads((ROOT/'gate.json').read_text()) or exact["gate"]!="PASS":
        raise RuntimeError("Exact gate mismatch")
    result={name:geometry(name,idx) for idx,name in enumerate(("dust","flat"))}
    vv=4*math.pi*RADIUS**3/3 * (511/(9*256))
    return dict(design_sha256=exact["design_sha256"],geometry=result,four_volume=vv,rho=12/vv,
                flat_scale_factor=(511/(9*256))**.25,
                numpy=np.__version__,seed=SEED,
                phase_status="HOLD" if not result["dust"]["screening_pass"] else "requires_propagation")


if __name__=="__main__":
    print(json.dumps(main(),indent=2))
