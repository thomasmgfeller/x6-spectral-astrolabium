"""Four additional validation cases with the published dust coefficients."""
import csv
import math
from pathlib import Path
from prediction import A, constant
from reference import physical_expectation

s = 0.47
U = 1 - s
windows = [(0.11, 0.24), (0.24, 0.11)]
densities = [600000, 6000000]
rows = []
# Compute and freeze all predictions before consulting either finite-density integral.
for P, F in windows:
    B = constant(P / U, F / U, n=64)
    assert abs(B - constant(P / U, F / U, n=96)) < 1e-8
    for lam in densities:
        scale = lam * U**4
        pred = 1 + (A * math.log(scale) + B) / math.sqrt(scale)
        rows.append(dict(s=s, P=P, F=F, lam=lam, B=B, predicted=pred))
for row in rows:
    P, F, lam = (row[k] for k in ('P', 'F', 'lam'))
    actual = physical_expectation(s, P, F, lam, 96)
    lens = physical_expectation(s, P, F, lam, 112, lens=True, cap=13.)
    err = actual / row['predicted'] - 1
    gap = abs(lens - actual)
    row.update(reference=actual, lens=lens, numerical_gap=gap, raw_error=actual-1,
               corrected_error=err, improved=abs(err)<abs(actual-1),
               within_10_percent=abs(err)<=0.10, resolved=gap<=0.00005)
    print(f'{P} {F} {lam} ref {actual:.9f} pred {row["predicted"]:.9f}'
          f' raw {(actual-1)*100:.5f}% corrected {err*100:.5f}% delta {gap:.3g}')
with Path('results.csv').open('w', newline='') as out:
    writer = csv.DictWriter(out, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
