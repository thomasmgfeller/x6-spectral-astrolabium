# Vier zusätzliche Zeitfenster-Vergleiche beim Staubkollaps

Die ursprünglichen 24 Prüfkonfigurationen und die vollständige Herleitung stehen im [veröffentlichten Forschungsdossier](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dd78ba05f4d91b6e62579ab41621be5cecaa079c/research/rax_cqg/dust_collapse). Die fünf Abhängigkeiten des Prüflaufs wurden unverändert aus dessen Verzeichnis `curved_boundary` übernommen und mit den Git-Objekten abgeglichen. `check_windows.py` definiert die vier zusätzlichen Fälle.

Im entpackten Verzeichnis mit Python 3.12, NumPy 2.3.5 und SciPy 1.17.0 ausführen:

```sh
OPENBLAS_NUM_THREADS=1 python3 check_windows.py
```

Die dimensionslosen Referenzeinheiten sind wie im Forschungsbericht gewählt. Für die Schnittzeit 0,47 gilt eine restliche klassische Eigenzeit von 0,53. Die beiden Zeitabstände sind 0,11 und 0,24. Jede Orientierung wird bei den Beprobungsdichten 600 000 und 6 000 000 geprüft. Alle Vorhersagen werden vor Auswertung des endlichen Poisson-Integrals gebildet. Dessen unabhängige Berechnung des Intervallvolumens über eine Kugelschnittlinse kontrolliert die numerische Auflösung. Die Prüfung verwendet die veröffentlichte Modellkorrektur ohne Anpassung. Sie ist ein zusätzlicher interner Rechentest mit vorgegebener klassischer Geometrie.

In `results.csv` sind die relativen Fehler als Bruchteile der Sollmasse gespeichert. Für die korrigierte Masse gilt `corrected_error = reference / predicted - 1`. Die Streuung des Massestroms einer einzelnen Kausalordnung wurde in diesem Vergleich nicht bestimmt.
