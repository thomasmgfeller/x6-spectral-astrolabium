# Endliche Staubkopplung auf Kausalordnungen

Prüfpaket zum Schritt 1 vom 3. November 2026. Alle endlichen Klassen werden vollständig summiert. Der lokale Integralwert ist analytisch, die angegebenen komplexen Summen sind numerisch. Python 3.12.14 und NumPy 2.3.5 wurden verwendet.

## Reproduktion

Aus einer entpackten Kopie mit installiertem NumPy:

    sha256sum -c SHA256SUMS
    python3 run.py
    python3 score.py

Die Prüfsummen beziehen sich auf die gelieferten Dateien. Bei Wiederholung auf anderen Plattformen können letzte Nachkommastellen abweichen. Die numerischen Gegenprüfungen benutzen Toleranzen. Der Rechner benötigt weder Netzwerkzugang noch Zufallszahlen.

## Welche Datei beantwortet welche Frage?

- design.json fixiert Modelle, Parameter und Entscheidungsregel vor der Hauptauswertung. Es handelt sich um eine lokale Spezifikation, keine öffentliche Präregistrierung.
- primary_histogram.csv und window_histogram.csv enthalten exakte ganzzahlige Häufigkeiten. site_scores sind aufsteigend sortierte Ganzzahlen u mit Gamma = 2u/sqrt(6). k=0 in der Primärtabelle ist nur eine Gruppenkennung.
- primary_sums.csv enthält die 24 Summen der Acht-Ereignis-Klasse. s = ell^4 Sigma/(4 hbar). R ist der Betrag der gravitativen Summe dividiert durch den Betrag bei g=0 bei gleichem s. L1 ist die Summe der Beträge der Einzelgewichte. coherence ist absZ/L1.
- window_amplitudes.csv enthält die komplexen Amplituden der Zählwerte k=1,2,3. window_sums.csv enthält Hilfsgewichte q, Interferenz, die maximale Abweichung über alle acht Vereinigungsklassen und die Entscheidung. In worst_mask steht Bit 0 für k=1, Bit 1 für k=2 und Bit 2 für k=3. Ein leeres bound-Feld bedeutet epsilon >= 1.
- checks.json enthält unabhängige numerische Konsistenzprüfungen. reference_score.json enthält den getrennt berechneten Referenzwert. Dessen Eingang sind nur die zwei frühen Fenster 3 und 2. run.py liest keinen späten Referenzwert.
- Pruefbericht.pdf beschreibt die physikalischen Voraussetzungen, die bedingte Massengegenprobe und die Geltungsgrenze.

Im Haupttest werden beschriftete 2+4+2-Ordnungen genauso gezählt wie im veröffentlichten Referenzmodell. Im separaten Fenstertest sind die frühen fünf Ereignisse individuell markiert, ebenso der gemeinsame Endpunkt. Die austauschbaren inneren Ereignisse werden durch k!(4-k)! dividiert. Der einzige Endkanal enthält kein Messgerät und keinen zusätzlichen Speicher für k. Der Fensterwert ist die Zahl der Ereignisse in der dritten Schicht. Der fixe Beitrag der beiden ersten Messfenster und das gleiche Endereignis erlauben sämtliche drei späteren Zählwerte.

Der Massentest ist analytisch auf vorgegebenem klassischem Staub mit idealer kontinuierlicher Eigenzeit. Die lokale Dichteintegration bei Gamma=-1 ergibt die mittlere Dichte Sigma/2. Die Modellwahl lässt damit bei räumlich konstantem Sigma und festgehaltenem T die konditionierte mittlere Masse proportional zum schrumpfenden Volumen abnehmen. Eine dynamische T-Integration oder eine physikalische Massenpräparation ist nicht Teil dieses Tests.
