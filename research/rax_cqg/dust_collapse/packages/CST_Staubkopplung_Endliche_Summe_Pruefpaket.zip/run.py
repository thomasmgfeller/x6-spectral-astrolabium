"""Finite dust-density test. Run in Python 3.10+ with NumPy. No random draws."""
import csv
import itertools as it
import json
import math
import cmath
from collections import Counter
from functools import lru_cache
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
DESIGN = json.loads((ROOT / 'design.json').read_text())
SIGMAS = DESIGN['sigma_dimensionless']
COUPLINGS = {'0': 0., '4*pi/5': 4*math.pi/5, '2.4': 2.4, '2.6': 2.6}
C = (1, -9, 16, -8)
SQ = 2 / math.sqrt(6)
NODES, GAUSS_WEIGHTS = np.polynomial.legendre.leggauss(20)


def csum(values):
    values = list(values)
    return complex(math.fsum(z.real for z in values), math.fsum(z.imag for z in values))


def local(sheet_score, s):
    z = s * (1 + SQ * sheet_score)
    return cmath.exp(-1j*z) * (math.sin(z)/z if z else 1.)


@lru_cache(None)
def independent_integral(sheet_score, s):
    # Average of exp(-2 i z u) on 0<=u<=1. Limit phase change per panel.
    frequency = 2*s*(1+SQ*sheet_score)
    panels = max(1, math.ceil(abs(frequency)/math.pi))
    u = (np.arange(panels)[:, None] + (1 + NODES)/2) / panels
    return complex(np.sum(np.exp(-1j*frequency*u)*GAUSS_WEIGHTS)/(2*panels))


def covers(m, n):
    full = (1 << n)-1
    for rows in it.product(range(1, full+1), repeat=m):
        union = 0
        for row in rows:
            union |= row
        if union == full:
            yield rows


def relation_scores(sizes, matrices, first_family=False):
    times = [j for j,n in enumerate(sizes) for _ in range(n)]
    n = len(times)
    future = [0] * n
    offset = 0
    for rows in matrices:
        new_offset = offset + len(rows)
        for i,row in enumerate(rows):
            future[offset+i] |= row << new_offset
        offset = new_offset
    if first_family:
        for x in range(2):
            future[x] |= 3 << 6
    for x in reversed(range(n)):
        for y in range(x+1,n):
            if future[x] & (1<<y):
                future[x] |= future[y]
    past = [sum(1<<x for x in range(y) if future[x] & (1<<y)) for y in range(n)]
    q, scores = n, []
    for y in range(n):
        u = 0
        for x in range(y):
            if not (past[y] & 1<<x):
                continue
            j = (future[x] & past[y]).bit_count()
            if j < len(C):
                q -= C[j]
                u += C[j]*(times[y]-times[x])**2
        if times[y] not in (0,len(sizes)-1):
            scores.append(u)
    return q, tuple(sorted(scores))


def all_cases():
    primary, future = [], []
    for low, high in it.product(covers(2,4), covers(4,2)):
        q, u = relation_scores((2,4,2),(low,high),True)
        outer = [sum(bool(low[i] & 1<<j and high[j] & 1<<k) for j in range(4))
                 for i in range(2) for k in range(2)]
        adjacent = sum(row.bit_count() for row in low + high)
        alt_q = 8 - adjacent - sum(C[m] if m<4 else 0 for m in outer)
        alt_u = tuple(sorted(sum(bool(row & 1<<j) for row in low) for j in range(4)))
        assert (q,u)==(alt_q,alt_u)
        primary.append((0, q, u))
    for k in (1,2,3):
        sizes = (3,2,k,4-k,1)
        for b,c,d in it.product(covers(2,k),covers(k,4-k),covers(4-k,1)):
            q,u = relation_scores(sizes, ((1,3,2),b,c,d))
            future.append((k,q,u))
    assert len(primary)==6241
    assert Counter(k for k,_,_ in future)=={1:1,2:49,3:25}
    return primary, future


def csv_file(name, rows):
    with (ROOT / name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader(); writer.writerows(rows)


def independent_window(sizes, matrices):
    # Boolean matrix powers for reachability and integer matrix multiplication for intervals.
    n=sum(sizes)
    t=np.repeat(np.arange(len(sizes)), sizes)
    a=np.zeros((n,n),dtype=np.int64)
    i=0
    for rows, width in zip(matrices,sizes[1:]):
        off=i+len(rows)
        for j,row in enumerate(rows):
            for z in range(width):
                a[i+j,off+z]=bool(row & 1<<z)
        i=off
    rel=np.zeros_like(a)
    for _ in sizes:
        rel=((rel+rel@a+a)>0).astype(np.int64)
    counts=rel@rel
    coeff=sum(c*((counts==j)&(rel!=0)) for j,c in enumerate(C))
    q=n-int(coeff.sum())
    u=np.sum(coeff*(t[:,None]-t[None,:])**2,axis=0)
    return q, tuple(sorted(int(x) for x in u[(t>0)&(t<len(sizes)-1)]))


def grouped(hist,k,g,s):
    terms = []
    for (b,q,u),mult in hist.items():
        if k==b:
            weight = math.prod(local(item,s) for item in u)
            terms.append((mult,cmath.exp(1j*g*q)*weight,abs(weight)))
    z=csum(m*a for m,a,_ in terms)
    return z,math.fsum(m*absw for m,_,absw in terms)


def main():
    primary, window = all_cases()
    h=Counter(primary); w=Counter(window)
    known = [1176,1004,1149,1472,1440]
    residues=Counter(q%5 for _,q,_ in primary)
    assert [residues[k] for k in range(5)]==known
    max_local_error=max(abs(local(u,s)-independent_integral(u,s))
                        for _,_,us in list(h)+list(w) for u in set(us) for s in SIGMAS)
    assert max_local_error<5e-14
    for k in (1,2,3):
        sizes=(3,2,k,4-k,1)
        for b,c,d in it.product(covers(2,k),covers(k,4-k),covers(4-k,1)):
            matrices=((1,3,2),b,c,d)
            assert independent_window(sizes,matrices)==relation_scores(sizes,matrices)
    for filename,hist in [('primary_histogram.csv',h),('window_histogram.csv',w)]:
        csv_file(filename,[dict(k=k,Q=q,site_scores=' '.join(map(str,u)),multiplicity=m)
                           for (k,q,u),m in sorted(hist.items())])
    main_rows,window_rows,branch_rows=[],[],[]
    max_sum_error=0.
    max_branch_error=0.
    for s in SIGMAS:
        z0,_=grouped(h,0,0.,s)
        for gname,g in COUPLINGS.items():
            z,l1=grouped(h,0,g,s)
            direct=csum(cmath.exp(1j*g*q)*math.prod(independent_integral(v,s) for v in u)
                        for _,q,u in primary)
            max_sum_error=max(max_sum_error,abs(z-direct))
            assert abs(z-direct) < 3e-10
            main_rows.append(dict(s=s,g=gname,ReZ=z.real,ImZ=z.imag,absZ=abs(z),L1=l1,
                                  coherence=abs(z)/l1,R=abs(z)/abs(z0)))
            branch=[]
            for k in (1,2,3):
                a,_=grouped(w,k,g,s)
                a/=math.factorial(k)*math.factorial(4-k)
                raw_terms = (cmath.exp(1j*g*q)*math.prod(independent_integral(v,s) for v in u)
                             for category,q,u in window if category==k)
                independent = csum(raw_terms)/(math.factorial(k)*math.factorial(4-k))
                error = abs(a-independent)
                max_branch_error = max(error, max_branch_error)
                assert error < 1e-10*max(abs(a),1e-15)
                branch.append(a)
            trace=math.fsum(abs(a)**2 for a in branch)
            total=abs(csum(branch))**2
            assert trace>0 and total>0
            diag=[abs(a)**2/trace for a in branch]
            eps=sum(abs(a)*abs(b) for i,a in enumerate(branch)
                    for j,b in enumerate(branch) if i!=j)/trace
            diffs=[]
            for mask in range(8):
                ids=[i for i in range(3) if mask & 1<<i]
                diff=abs(abs(csum(branch[i] for i in ids))**2/total-sum(diag[i] for i in ids))
                diffs.append(diff)
            bound=2*eps/(1-eps) if eps<1 else None
            if bound is not None: assert max(diffs)<=bound+1e-12
            best=max(range(3),key=diag.__getitem__)+1
            accepted=bound is not None and bound<=.10 and max(diag)>=.80
            window_rows.append(dict(s=s,g=gname,q1=diag[0],q2=diag[1],q3=diag[2],
                                    epsilon=eps,coherent_norm=total,diagonal_trace=trace,
                                    bound=bound,max_subset_discrepancy=max(diffs),worst_mask=diffs.index(max(diffs)),
                                    peak_bin=best,decision='issue' if accepted else 'withhold'))
            branch_rows.extend(dict(s=s,g=gname,k=k,Re=a.real,Im=a.imag) for k,a in enumerate(branch,1))
    csv_file('primary_sums.csv',main_rows)
    csv_file('window_sums.csv',window_rows)
    csv_file('window_amplitudes.csv',branch_rows)
    result=dict(primary_histories=len(primary),window_histories=len(window),
                primary_joint_histogram_bins=len(h),window_joint_histogram_bins=len(w),
                max_abs_factor_quadrature_difference=max_local_error,
                max_abs_primary_sum_difference=max_sum_error,
                max_abs_window_amplitude_difference=max_branch_error,primary_mod_5=known)
    (ROOT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
