"""Score the frozen window output against the external GR reference (no fitting to late data)."""
import csv
import json
import math
from pathlib import Path
root=Path(__file__).resolve().parent
x=2/(10+math.sqrt(100-16/3))
reference=1+2*x
rows=list(csv.DictReader((root/'window_sums.csv').open()))
issued=[r for r in rows if r['decision']=='issue']
out={'early_window_counts':[3,2],'later_reference_average':reference,
     'nearest_count':round(reference),'parameter_cells':len(rows),'issued':len(issued),
     'matching_issued':sum(int(r['peak_bin'])==round(reference) for r in issued),
     'classical_mass_ratio_for_half_volume':0.5}
(root/'reference_score.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
