# Wachstumsmass auf der endlichen Randfamilie C

Der Test ersetzt ausschliesslich das positive Gewicht der unmarkierten Ausgangsgeometrien. Grundlage sind die ursprünglichen frühen Daten aus [PR 210](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/210) und das gleiche Gate wie in [PR 211](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/211). Die Vergleichskarte zu den beiden früheren Geometriemassen wird für diesen Lauf nicht benötigt. Die Auswertung ist vollständig endlich und deterministisch.

## Testplan und Bedeutung

design.json und DESIGN_SHA256 halten den lokal vor der neuen Rechnung festgelegten Plan fest. Dieser Hash dient der Wiederholung. Die Familie C und die Resultate mit den bisherigen Gewichten waren bekannt. Der Plan wurde nicht extern präregistriert.

Nach dem punktweise fixierten fünfgliedrigen Anfangsstück fügen wir jeweils ein maximales Element hinzu. Jedes alte Element wird mit Wahrscheinlichkeit p unabhängig als Vorgänger vorgeschlagen. Die transitive Hülle bestimmt die kausale Vergangenheit des neuen Elements. Die Vorschlagswahrscheinlichkeit p=1/2 ist die primäre, unkalibrierte Wahl. Diese klassische Dynamik entspricht der transitiven Perkolation nach [Rideout und Sorkin, Gleichung (6)](https://doi.org/10.1103/PhysRevD.61.024002). Stoppuhr, spätere Auswahl der Familie, Materiemarkierung und Einsetzung des klassischen Gewichts in die Amplitude gehören zum vorliegenden Modelltest.

Für eine konkrete Geburtsreihenfolge müssen alle neuen Überdeckungsrelationen vorgeschlagen werden; jede frühere unvergleichbare Stelle muss ausgeschlossen werden. Alle weiteren Entscheidungen über bereits mittelbar verbundene Vorfahren summieren sich zu eins. Damit ist die Wahrscheinlichkeit der nummerierten Fortsetzung p^L (1-p)^I. L zählt Überdeckungen mit neuem oberen Ende, I alle unvergleichbaren Paare mit mindestens einem neuen Element. Jede mit dem frühen Segment kompatible natürliche Nummerierung hat dieselbe Wahrscheinlichkeit. Sind e die möglichen Geburtsfolgen auf benannten Punkten und a die Ordnung der Automorphismengruppe bei punktweise fixiertem Anfang, gibt es e/a verschiedene nummerierte Fortsetzungen. Die Gruppe wirkt frei auf den Nummerierungen. Die beiden permutierten Schichten sind durch ihre Ordnungshöhe ausgezeichnet. Unterschiedliche Schichten werden durch einen Automorphismus nicht vertauscht.

Vor dem Wachstum wird unabhängig eine Zahl M weiterer Geburten gezogen, gleichverteilt von 1 bis 10. Die Kandidaten der Familie C haben M=6,7,8, also an allen drei Endgrössen dasselbe Stoppgewicht. Der Vergleichstakt stoppt ab der ersten Geburt mit konstanter Wahrscheinlichkeit 1/6 nach jeder Geburt. Sein Faktor beträgt (5/6)^(M-1)/6. Die Rohgewichte werden über sämtliche 840 Geometrien gemeinsam auf eins normiert. Die Klassensummen sind ein Ergebnis des Modells. Das normierte Gewicht wird linear als Integrationsgewicht der alten Amplituden verwendet. Eine späte Kante wird wie bisher innerhalb der Geometrie gleichverteilt markiert. Die Attestierung gilt nur für diese Übertragung von klassischen Wahrscheinlichkeiten in die Amplitudensumme.

## Reproduktion

Getestet mit Python 3.12.14, NumPy 2.3.5 und python-flint 0.9.0 unter Linux. Sämtliche wissenschaftlichen Eingaben sind enthalten. NumPy wird von den archivierten Referenzmodulen importiert. python-flint wird für die zusätzliche Intervall-Gegenrechnung benötigt. Im entpackten Ordner ausführen.

    sha256sum -c SHA256SUMS
    python3 -m venv .venv
    .venv/bin/python -m pip install numpy==2.3.5 python-flint==0.9.0
    OPENBLAS_NUM_THREADS=1 .venv/bin/python evaluate.py
    .venv/bin/python verify_scores.py > replay-audit.json
    cmp replay-audit.json arithmetic_audit.json
    sha256sum -c SHA256SUMS

evaluate.py berechnet orbits.csv, coefficients.csv und results.json neu. Das eingebettete Archiv reference_C.zip ist das veröffentlichte Referenzpaket aus PR 210. results.json enthält die exakten rationalen Intervallgrenzen der Zweigauswertung. arithmetic_audit.json enthält die zusätzliche Auswertung der Koeffizienten mit nach aussen gerundeter 160-Bit-Arithmetik. Angezeigte Ballradien können bei anderen Softwareversionen abweichen.

## Kontrollen und Dateien

- growth.py berechnet die Orbitwahrscheinlichkeit aus der Zahl der Geburtsfolgen und der Linkformel. Für p=1/2 zählt es separat alle erlaubten Elternauswahlen und summiert deren Pfadgewichte vorwärts. Zwei freie Geburten nach demselben Anfangsstück prüfen an allen 2048 Vorschlagsmustern bei allen drei p-Werten die Normierung und die Wahrscheinlichkeit jeder nummerierten Ordnung.
- evaluate.py prüft die Orbitgrössen durch separate Stabilisatorzählung. Es vergleicht die Routenpolynome und den Wirkungszähler jeder repräsentativen Markierung über je zwei Rechenwege. Die erneute Symmetriegewichtung muss exakt die 230 Koeffizienten der Referenz liefern.
- orbits.csv führt den eindeutigen repräsentativen Schlüssel, Automorphismenzahl, Geburtsfolgen, L, I und die unnormierten gestoppten Orbitwahrscheinlichkeiten. coefficients.csv enthält die bedingt normierten rationalen Integrationsgewichte für die eigentliche Phasensumme.
- q23 ist das normierte Zweiggewicht für den kohärent zusammengefassten Zweig k=2 oder 3. epsilon ist die normierte Interferenz dieses Zweigs mit k=1. Die klassische bedingte Wahrscheinlichkeit für die Klassen in results.json ist eine andere Grösse. Ein gescheitertes Interferenzkriterium lässt auch die umgekehrte Vorhersage k=1 offen.
