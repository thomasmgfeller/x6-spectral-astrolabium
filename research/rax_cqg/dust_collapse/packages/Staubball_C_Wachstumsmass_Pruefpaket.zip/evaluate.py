"""Reproduce the growth-gate test using the pinned family C generator and phase bounds."""
import csv
import hashlib
import json
import math
import sys
import tempfile
import zipfile
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

from growth import SEED, geometry_likelihood, forward_probability, two_birth_check

ROOT = Path(__file__).resolve().parent
VARIANTS = ("p_half_flat", "p_third_flat", "p_two_thirds_flat", "p_half_geometric")
KEYS = ("k", "signature", "h", "residue")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_digest(path, expected):
    require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, f"Checksum mismatch in {path.name}")


def conditional_transports(old, edges):
    from enumerate_records import read_routes, history_poly, lift
    from audit import trace, twin_deltas

    sink = len(edges) - 1
    marks = [(u,v) for u in range(3,sink) for v in edges[u]]
    forward = [read_routes(edges,u) for u in range(3)]
    audit_action = twin_deltas(edges)
    coefficients = Counter()
    for mark in marks:
        terms = history_poly(forward,mark,sink)
        other,norm = trace(edges,mark)
        require(terms == {key:F(value,norm) for key,value in other.items()}, "Marked transport mismatch")
        action = old.action(lift(edges,mark)[0])
        require(action == audit_action(mark), "Action mismatch")
        for (signature,h),weight in terms.items():
            coefficients[signature,h,action % 5] += weight
    require(sum(coefficients.values()) == len(marks), "Mark sum")
    return {key:value/len(marks) for key,value in coefficients.items()}, len(marks)


def run(base):
    check_digest(ROOT / "design.json","7863194ebb779e1ffc76c41ec28d69f0d3a3b941dab790590dfb4bcdafe5c3f7")
    check_digest(ROOT / "reference_C.zip","53666ad0aab5fcee9ac102f562f83c7b380954c2356844fab7af8cfe4f793c39")
    with zipfile.ZipFile(ROOT / "reference_C.zip") as archive:
        archive.extractall(base)
    sys.path.insert(0,str(base))
    import run as old
    old.reference(base / "prior")
    from audit import orbit_size

    with (base / "coefficients.csv").open() as stream:
        reference = {tuple(int(row[key]) for key in KEYS):F(row["weight"]) for row in csv.DictReader(stream)
                     if row["family"]=="C" and row["preparation"]=="original"}
    coefficients = {key:Counter() for key in (*VARIANTS, "symmetry")}
    records = []
    labelled_marks = 0
    mark_checks = 0
    for k in (1,2,3):
        for key, orbit in sorted(old.orbits(k,4).items()):
            edges = old.graph(old.PREPS["original"],k,4,key)
            size = len(edges)
            births = size - SEED
            require(1 <= births <= 2*SEED and births == k+5, "Candidate size")
            group = math.factorial(k)*math.factorial(4)
            aut, remainder = divmod(group,orbit)
            require(remainder == 0, "Orbit divisor")
            alternate_orbit = orbit_size(k,4,key)
            require(orbit == alternate_orbit, "Stabilizer check")
            prob,(extensions,links,inc) = geometry_likelihood(edges,aut)
            direct = forward_probability(edges, group // alternate_orbit)
            require(direct == prob[F(1,2)], "Independent growth probability")
            flat = F(1,2*SEED)
            hazard = F(1,SEED+1)
            weights = dict(p_half_flat=flat*direct, p_third_flat=flat*prob[F(1,3)],
                           p_two_thirds_flat=flat*prob[F(2,3)],
                           p_half_geometric=hazard*(1-hazard)**(births-1)*direct,
                           symmetry=F(1,aut))
            coeff, marks = conditional_transports(old,edges)
            for mode,weight in weights.items():
                for idx,value in coeff.items():
                    coefficients[mode][(k,*idx)] += weight*value
            mark_checks += marks
            labelled_marks += marks*orbit
            records.append((k,key[0],key[1],"/".join(map(str,key[2])),aut,extensions,links,inc,
                            *(weights[mode] for mode in VARIANTS)))
    require(coefficients.pop("symmetry") == reference, "Published symmetry coefficients")
    require((len(records),labelled_marks) == (840,822792), "Family inventory")
    seed_edges = [[v for v in row if v<SEED] for row in edges[:SEED]]
    small_check = two_birth_check(seed_edges)
    results = {}
    with (ROOT / "coefficients.csv").open("w",newline="") as stream:
        writer = csv.writer(stream,lineterminator="\n")
        writer.writerow(["scenario",*KEYS,"conditional_weight"])
        for mode,table in coefficients.items():
            class_mass = [sum(w for (j,*_),w in table.items() if j==k) for k in (1,2,3)]
            total = sum(class_mass)
            require(0 < total < 1,"Selection probability")
            conditional = {key:prob/total for key,prob in table.items()}
            require(sum(conditional.values()) == 1, "Normalization")
            with_stops = [sum(row[8+VARIANTS.index(mode)] for row in records if row[0]==k) for k in (1,2,3)]
            require(with_stops == class_mass,"Orbit mass vs transport sum")
            for key,value in sorted(conditional.items()):
                writer.writerow([mode,*key,value])
            phase_cases = ["primary", "gravity_off", "no_phases", "count_only"] if mode==VARIANTS[0] else ["primary"]
            scores = {phase:old.scores(conditional,phase) for phase in phase_cases}
            results[mode] = dict(selection_probability=str(total),
                                 conditional_class_probabilities=[str(x/total) for x in class_mass],
                                 scores=scores)
    with (ROOT / "orbits.csv").open("w",newline="") as stream:
        writer = csv.writer(stream,lineterminator="\n")
        writer.writerow(["k","mask_a","mask_b","columns","aut","birth_orders","links_new","incomparable_new",*VARIANTS])
        writer.writerows(records)
    audit = dict(orbits=len(records), labelled_marks=labelled_marks, representative_marks=mark_checks,
                 matched_primary_orbit_weights=len(records), two_birth_masks=2**(2*SEED+1),
                 distinct_two_birth_outputs=small_check, recovered_symmetry_coefficients=len(reference))
    (ROOT / "results.json").write_text(json.dumps(dict(results=results,audit=audit),indent=2)+"\n")


if __name__ == "__main__":
    require(__debug__, "Use Python with assertions enabled")
    with tempfile.TemporaryDirectory() as tmp:
        run(Path(tmp))
