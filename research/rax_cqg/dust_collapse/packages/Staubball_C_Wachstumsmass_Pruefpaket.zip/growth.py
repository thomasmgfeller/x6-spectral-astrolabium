"""Conditional transitive percolation on a finite causet with a fixed five-point stem."""
from collections import Counter
from fractions import Fraction
from functools import cache

SEED = 5
PROBABILITIES = (Fraction(1, 2), Fraction(1, 3), Fraction(2, 3))


def ancestors(edges):
    """Transitive pasts, using the reference topological indexing."""
    past = [0] * len(edges)
    for source, targets in enumerate(edges):
        for target in targets:
            if target <= source:
                raise ValueError("Expected topological indexing")
            past[target] |= past[source] | (1 << source)
    return past


def extension_count(edges):
    """Delete maximal elements, leaving the labelled stem untouched."""
    start = (1 << SEED) - 1
    successors = [sum(1 << j for j in row) for row in edges]

    @cache
    def remove(state):
        if state == start:
            return 1
        return sum(remove(state ^ (1 << j)) for j in range(SEED, len(edges))
                   if state & (1 << j) and not (state & successors[j]))

    return remove((1 << len(edges)) - 1)


def geometry_likelihood(edges, automorphisms):
    """Unstopped orbit probability at its own size; no conditioning on family C yet."""
    past = ancestors(edges)
    links = sum(v >= SEED for row in edges for v in row)
    incomparable = sum(v - past[v].bit_count() for v in range(SEED, len(edges)))
    extensions = extension_count(edges)
    distinct, remainder = divmod(extensions, automorphisms)
    if remainder:
        raise ValueError("Non-free action on labelled birth sequences")
    weights = {p: distinct * p**links * (1 - p)**incomparable for p in PROBABILITIES}
    return weights, (extensions, links, incomparable)


def closure_of_choices(chosen, past):
    closure = chosen
    while chosen:
        bit = chosen & -chosen
        closure |= past[bit.bit_length() - 1]
        chosen ^= bit
    return closure


def forward_probability(edges, automorphisms):
    """Explicit parental subsets and a forward sum over all compatible birth paths at p=1/2."""
    # Compute each target past by a separate backward graph search.
    parents = [{u for u, row in enumerate(edges) if v in row} for v in range(len(edges))]
    past = []
    for immediate in parents:
        seen = set()
        todo = list(immediate)
        while todo:
            u = todo.pop()
            if u not in seen:
                seen.add(u)
                todo.extend(parents[u])
        past.append(sum(1 << u for u in seen))
    choices = {}
    for v in range(SEED, len(edges)):
        # Older nonancestors must be absent; enumerate every subset of actual ancestors.
        sub = past[v]
        total = 0
        while True:
            total += closure_of_choices(sub, past) == past[v]
            if not sub:
                break
            sub = (sub - 1) & past[v]
        choices[v] = total
    initial = (1 << SEED) - 1
    frontier = Counter({initial: 1})
    total_flips = 0
    for size in range(SEED, len(edges)):
        next_layer = Counter()
        for state, paths in frontier.items():
            for v, ways in choices.items():
                bit = 1 << v
                if not (state & bit or past[v] & ~state):
                    next_layer[state | bit] += paths * ways
        frontier = next_layer
        total_flips += size
    return Fraction(frontier[(1 << len(edges)) - 1], (2**total_flips) * automorphisms)


def two_birth_check(seed_edges):
    """All 2^(5+6) proposal patterns, with birth labels retained."""
    stem = ancestors(seed_edges)
    outcomes = {p: Counter() for p in PROBABILITIES}
    for first in range(1 << SEED):
        a = closure_of_choices(first, stem)
        for second in range(1 << (SEED + 1)):
            b = closure_of_choices(second, stem + [a])
            selected = first.bit_count() + second.bit_count()
            for p in PROBABILITIES:
                outcomes[p][a,b] += p**selected * (1 - p)**(2*SEED + 1 - selected)
    for p, distribution in outcomes.items():
        if sum(distribution.values()) != 1:
            raise ValueError("Unrestricted growth probabilities do not normalize")
        for (a,b), weight in distribution.items():
            past = stem + [a,b]
            links = 0
            for incoming, j in ((a,SEED), (b,SEED+1)):
                indirect = 0
                for i in range(j):
                    if incoming & (1 << i):
                        indirect |= past[i]
                links += (incoming & ~indirect).bit_count()
            inc = 2*SEED + 1 - a.bit_count() - b.bit_count()
            if p**links * (1 - p)**inc != weight:
                raise ValueError("Closed likelihood differs on a two-birth labelled output")
    return len(outcomes[PROBABILITIES[0]])
