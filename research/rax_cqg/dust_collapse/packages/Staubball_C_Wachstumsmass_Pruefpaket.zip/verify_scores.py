"""Check the reported primary phase enclosures with independent 160-bit ball arithmetic."""
import csv
import json
from fractions import Fraction
from pathlib import Path
from flint import acb, arb, ctx

ROOT = Path(__file__).resolve().parent
ctx.prec = 160


def ball(value):
    f = Fraction(value)
    return arb(f.numerator) / f.denominator


def run():
    results = json.loads((ROOT / "results.json").read_text())["results"]
    phase = acb(0, 4 * arb.pi() / 5).exp()
    matter = acb(0, -((48 / arb.pi()).root(4) - (24 / arb.pi()).root(4))).exp()
    with (ROOT / "coefficients.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    summary = {}
    for name in results:
        branches = [[acb(0) for _ in range(5)] for _ in range(2)]
        for row in rows:
            if row["scenario"] == name:
                t = int(row["k"]) != 1
                s = (0,1,2,4,7).index(int(row["signature"]))
                branches[t][s] += (ball(row["conditional_weight"]) * phase**int(row["residue"])
                                   * matter**int(row["h"]))
        u,v = branches
        a,b = (sum(abs(z)**2 for z in vec) for vec in branches)
        cross = sum(z.conjugate()*w for z,w in zip(u,v))
        if not a+b > 0:
            raise ArithmeticError("Nonpositive norm")
        q, eps = b / (a+b), 2*abs(cross)/(a+b)
        score = results[name]["scores"]["primary"]
        for var, value in (("q23", q), ("epsilon", eps)):
            lower, upper = map(ball, score[var])
            if not (value >= lower and value <= upper):
                raise ArithmeticError(name + " " + var)
        fails = (q < ball("4/5") or eps > ball("1/21"))
        passes = (q >= ball("4/5") and eps <= ball("1/21"))
        decision = "fails" if fails else "passes" if passes else "unresolved"
        if score["status"] != decision:
            raise ArithmeticError("Decision mismatch")
        summary[name] = {"q23":str(q),"epsilon":str(eps),"status":decision}
    return dict(precision_bits=ctx.prec, checked=summary)


if __name__=="__main__":
    print(json.dumps(run(),indent=2))
