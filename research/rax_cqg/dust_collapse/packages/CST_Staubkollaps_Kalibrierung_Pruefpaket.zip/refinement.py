"""Single, independently generated late-window confirmation and quadrature audit."""
import csv
import json
from pathlib import Path
import numpy as np
from scipy.stats import chi2
from flux import responses, cfg

spec=json.loads(Path('supplemental.json').read_text())
s=spec['volume_once']
t,h,lam,n=s['center'],s['width'],s['intensity'],s['reps']
rng=np.random.default_rng(s['seed'])
lo,hi=t-h/2,t+h/2
# The total window count is Poisson. Conditional times follow V(t) dt.
a,b=(1-hi)**3,(1-lo)**3
counts=rng.poisson(lam*(b-a)/3,n)
times=1-np.cbrt(rng.uniform(a,b,int(counts.sum())))
ni=int((abs(times-t)<h/4).sum())
no=int(counts.sum())-ni
alpha=(1-s['coverage'])/2
def interval(k):
    return chi2.ppf(alpha/2,2*k)/2, chi2.isf(alpha/2,2*(k+1))/2
il,iu=interval(ni)
ol,ou=interval(no)
scale=3*lam*h*n*(1-t)**2
check=dict(inner=ni,shell=no,rel_mean=(7*ni-no)/scale-1,
    lower=(7*il-ou)/scale-1,upper=(7*iu-ol)/scale-1)
Path('confirmation.json').write_text(json.dumps(check,indent=2)+'\n')
print(check)
rows=[]
s=spec['flux_refine']
for geo in cfg['geometries']:
    for t in cfg['flux_centers']:
        for pad in cfg['flux_padding']:
            values=[responses(t,pad,geo=='dust',k,s['radial_power']) for k in s['orders']]
            for j,lam in enumerate(cfg['flux_intensities']):
                x,y,z=[float(v[j]) for v in values]
                rows.append(dict(geo=geo,t=t,pad=pad,lam=lam,q48=x,q80=y,q112=z,gap=abs(y-z),
                    passed=abs(y-z)<=.01 and abs(z-1)<=.10))
with open('flux_refined.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('max gap',max(r['gap'] for r in rows))
for r in rows:
    if r['lam']>=100000 and (r['geo']=='dust' or r['t']==0.4): print(r)
