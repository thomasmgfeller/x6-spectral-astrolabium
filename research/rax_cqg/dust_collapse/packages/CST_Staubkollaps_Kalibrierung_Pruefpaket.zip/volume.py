"""Marked volume and supplied-density mass control. Run from this directory."""
import csv
import json
import math
from pathlib import Path
import numpy as np
from scipy.stats import chi2

cfg = json.loads(Path("design.json").read_text())
rows = []
cells = len(cfg["geometries"])*len(cfg["volume_centers"])*len(cfg["volume_widths"])*len(cfg["volume_intensities"])
n = cfg["reps"]
alpha_component = (1-cfg["volume_family_coverage"])/(2*cells)
log_tail = math.log(2*cells/(1-cfg["mass_control_family_coverage"]))

def garwood(k):
    low = 0 if k == 0 else chi2.ppf(alpha_component/2, 2*k)/2
    return low, chi2.isf(alpha_component/2,2*(k+1))/2

for g, geo in enumerate(cfg["geometries"]):
    for j,t in enumerate(cfg["volume_centers"]):
        for k,h in enumerate(cfg["volume_widths"]):
            for i,lam in enumerate(cfg["volume_intensities"]):
                rng = np.random.default_rng(np.random.SeedSequence([cfg["seed"],g,j,k,i]))
                low, high = t-h/2, t+h/2
                vmax = 1 if g==0 else (1-low)**2
                inner, shell, mass = np.zeros(n,dtype=int), np.zeros(n,dtype=int), np.zeros(n)
                for start in range(0,n,128):
                    nv = rng.poisson(lam*h*vmax,128)
                    labels = np.repeat(np.arange(128),nv)
                    times = rng.uniform(low,high,len(labels))
                    if g:
                        keep = rng.random(len(labels))*vmax < (1-times)**2
                        times, labels = times[keep], labels[keep]
                    core = abs(times-t) < h/4
                    sl = slice(start,start+128)
                    inner[sl] = np.bincount(labels[core],minlength=128)
                    shell[sl] = np.bincount(labels[~core],minlength=128)
                    w = (1-times)**-2 if g else np.ones(len(labels))
                    mass[sl] = np.bincount(labels,weights=w,minlength=128)/(lam*h)
                scale = lam*h
                v0 = (1-t)**2 if g else 1
                bias = h*h/12 if g else 0
                raw = (inner+shell)/scale
                corrected = (7*inner-shell)/(3*scale)
                ilo,ihi = garwood(inner.sum())
                olo,ohi = garwood(shell.sum())
                lower=(7*ilo-ohi)/(3*scale*n*v0)-1
                upper=(7*ihi-olo)/(3*scale*n*v0)-1
                mi = lam*h/2*(v0+bias/4)
                mo = lam*h*(v0+bias)-mi
                cv = math.sqrt(49*mi+mo)/(3*scale*v0)
                var_mass = (1/(1-high)-1/(1-low))/(lam*h*h) if g else 1/scale
                maxjump = (1-high)**-2/scale if g else 1/scale
                radius_mass = math.sqrt(2*var_mass*log_tail/n) + maxjump*log_tail/(3*n)
                rows.append(dict(geo=geo,t=t,h=h,lam=lam,reps=n,inner=int(inner.sum()),shell=int(shell.sum()),
                    target=v0,raw_mean=raw.mean(),expected_raw=v0+bias,corrected_mean=corrected.mean(),rel_error=corrected.mean()/v0-1,
                    rel_lo=lower,rel_hi=upper,cv_exact=cv,cv_observed=corrected.std(ddof=1)/v0,
                    neg_fraction=(corrected<0).mean(),mass=mass.mean(),mass_var_exact=var_mass,mass_radius=radius_mass,
                    v_pass=(lower>=-cfg["volume_equivalence_relative"] and upper<=cfg["volume_equivalence_relative"]),
                    m_pass=(abs(mass.mean()-1)+radius_mass<=cfg["mass_control_relative"])))
with open("volume.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
print('volume equivalence, mass control, total',sum(x['v_pass'] for x in rows),sum(x['m_pass'] for x in rows),len(rows))
print('worst relative simultaneous bounds',min(x['rel_lo'] for x in rows),max(x['rel_hi'] for x in rows))
print('worst observed error',max(abs(x['rel_error']) for x in rows))
print('individual CV pass',sum(x['cv_exact']<=cfg['single_cloud_cv'] for x in rows))
for r in rows:
    if r['geo']=='dust' and r['t']==0.8 and r['h']==0.24:
        print('late',r)
