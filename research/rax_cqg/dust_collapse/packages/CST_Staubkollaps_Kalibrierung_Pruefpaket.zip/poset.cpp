#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

// Times must be sorted. The rank labels are used only to evaluate the order.
extern "C" double cut_flux(int n, const double *time, const double *eta,
                           const double *pos, const double *sigma,
                           double side, double cut, double density) {
    const int words = (n+63)/64;
    std::vector<std::uint64_t> future(n*words, 0), past(n*words, 0);
    for (int j=1; j<n; ++j) {
        for (int i=0; i<j; ++i) {
            const double limit = eta[j]-eta[i];
            double r2 = 0.;
            for (int k=0; k<3; ++k) {
                double d = std::abs(pos[3*j+k]-pos[3*i+k]);
                d = std::min(d, side-d);
                r2 += d*d;
            }
            if (r2 >= limit*limit) continue;
            future[i*words+j/64] |= UINT64_C(1)<<(j%64);
            past[j*words+i/64] |= UINT64_C(1)<<(i%64);
        }
    }
    const int split = std::lower_bound(time,time+n,cut)-time;
    const int c[] = {1,-9,16,-8};
    double total = 0.;
    for (int j=split; j<n; ++j) {
        if (!sigma[j]) continue;
        for (int i=0; i<split; ++i) {
            if (!(past[j*words+i/64] & (UINT64_C(1)<<(i%64)))) continue;
            int count = 0;
            for (int b=i/64; b<=j/64 && count<4; ++b)
                count += __builtin_popcountll(past[j*words+b] & future[i*words+b]);
            if (count<4) total += sigma[j]*(time[j]-time[i])*c[count];
        }
    }
    return -2.*total/std::sqrt(6.*density);
}
