STAUBKOLLAPS  |  REPRODUKTION DER KALIBRIERUNG
2. November 2026. Dieses Paket gehört zum Bericht CST_Staubkollaps_Kalibrierung.pdf.

Im entpackten Verzeichnis ausführen:
  python3 volume.py
  python3 flux.py
  python3 refinement.py
  python3 direct.py
  python3 geometric.py

Getestet mit Python 3.12, NumPy 2.3.5, SciPy 1.17.0 und g++ mit C++17 auf Linux.
Für die optionale Grafik matplotlib und zusätzlich python3 diagram.py verwenden.
direct.py kompiliert die beiliegende poset.cpp lokal und schreibt poset.so.
Der Test benötigt keine Internetverbindung. Die Skripte schreiben ihre Ergebnistabellen neu.

Ablauf und Trennung der Daten:
design.json definiert den ersten Durchlauf mit Volumen-, Dichte- und Flusskriterien.
supplemental.json definiert die einmalige Nachprüfung einer zu ungenauen Zelle,
eine zweite Quadratur und den unabhängigen vollständigen Ordnungsaufbau.
geometric_design.json ist der nachfolgende klassische Massentest mit eigenen Daten.
Diese Dateien dokumentieren die Reihenfolge. Sie sind keine externe Präregistrierung.

volume.csv enthält alle Zählzellen und die simultanen Intervallgrenzen.
confirmation.json dokumentiert die unabhängige Nachprüfung.
flux.csv enthält die erste Quadratur, flux_refined.csv die verfeinerte.
direct.csv enthält alle 1024 einzelnen Flusswerte der Raumzeit-Realisierungen.
geometric.csv enthält die getrennte Massenprüfung in der klassischen Referenz.
SHA256SUMS.txt enthält die Prüfsummen aller mitgelieferten Dateien ausser sich selbst.
