import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator
data=list(csv.DictReader(open('flux_refined.csv')))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#183646','xtick.color':'#183646','ytick.color':'#183646','pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(6.5,2.35),sharey=True)
for i,ax in enumerate(axes):
    center=['0.4','0.65'][i]
    ax.axhspan(.9,1.1,color='#deeae3')
    ax.axhline(1,color='#547065',lw=.7,ls=':')
    for pad,col,mark,sty in [('0.12','#a74b2a','s','--'),('0.24','#066d69','o','-')]:
        rows=[r for r in data if r['geo']=='dust' and r['t']==center and r['pad']==pad]
        ax.plot([float(r['lam']) for r in rows],[float(r['q112']) for r in rows],color=col,marker=mark,ls=sty,lw=1.5,markersize=4,label='Halbbreite '+pad.replace('.',','))
    ax.set(xscale='log',ylim=(-1.5,4.5),xlabel='Beprobungsdichte λ',title='Schnitt bei T = '+center.replace('.',','))
    ax.xaxis.set_major_locator(FixedLocator([1e3,1e4,1e5,1e6]))
    ax.xaxis.set_minor_locator(FixedLocator([]))
    ax.grid(axis='y',lw=.35,alpha=.35)
axes[0].set_ylabel('Mittlerer Fluss / Sollmasse')
fig.legend(*axes[0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.52,1.02),ncol=2,frameon=False)
fig.subplots_adjust(left=.09,right=.98,top=.77,bottom=.24,wspace=.15)
fig.savefig('fluxfigure.pdf')
