"""Mass from second differences only in the classical marginal dust model."""
import json
import math
import csv
from pathlib import Path
import numpy as np
from scipy.stats import chi2
cfg=json.loads(Path('geometric_design.json').read_text())
n,h=cfg['reps'],cfg['width']
centers=np.array(cfg['times'])
delta=centers[1]-centers[0]
assert delta==centers[2]-centers[1] and h<delta
levels=[0]+cfg['dust_masses']
alpha=(1-cfg['coverage'])/(len(levels)*len(cfg['intensities'])*3)
rows=[]
for g,mass in enumerate(levels):
    for j,lam in enumerate(cfg['intensities']):
        rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],g,j]))
        v=mass*((1-centers)**2+h**2/12) if mass else np.full(3,cfg['constant_volume_control'])
        counts=rng.poisson(lam*h*v,(n,3))
        totals=counts.sum(axis=0)
        lo=chi2.ppf(alpha/2,2*totals)/2
        hi=chi2.isf(alpha/2,2*(totals+1))/2
        scale=2*delta**2*lam*h
        est=counts@np.array([1,-2,1])/scale
        lower=(lo[0]-2*hi[1]+lo[2])/(scale*n)
        upper=(hi[0]-2*lo[1]+hi[2])/(scale*n)
        tol=cfg['mass_relative_tolerance']*mass if mass else cfg['mass_abs_tolerance_at_null']
        rows.append(dict(target=mass,lam=lam,observed=est.mean(),lo=lower,hi=upper,
               sd=est.std(ddof=1),sd_exact=math.sqrt(lam*h*(v@[1,4,1]))/scale,
               n0=totals[0],n1=totals[1],n2=totals[2],passed=lower>=mass-tol and upper<=mass+tol))
with open('geometric.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for r in rows: print(r)
