"""Independent whole-order check using a finite periodic ambient space."""
import ctypes
import csv
import json
import math
import subprocess
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer

subprocess.run(['g++','-std=c++17','-O3','-fPIC','-shared','poset.cpp','-o','poset.so'],check=True)
func=ctypes.CDLL(str(Path('poset.so').resolve())).cut_flux
array=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
func.argtypes=[ctypes.c_int,array,array,array,array,ctypes.c_double,ctypes.c_double,ctypes.c_double]
func.restype=ctypes.c_double
# Six-element chain exercises every layer including zero weight beyond j=3.
times=np.arange(6,dtype=float)
sigma=np.ones(6)
simple=sum((times[j]-times[i])*[1,-9,16,-8,0][j-i-1] for i in range(3) for j in range(3,6))
assert abs(func(6,times,times,np.zeros((6,3)),sigma,20,2.5,1)+2*simple/math.sqrt(6))<1e-10
s=json.loads(Path('supplemental.json').read_text())['direct']
rad=(3/(4*math.pi))**(1/3); L=s['periodic_side']; lam=s['intensity']; t=s['t']
assert 2*rad<L
rows=[]
for j,geo in enumerate(s['geometry']):
    dust=geo=='dust'
    for k,pad in enumerate(s['padding']):
        low,high=t-pad,t+pad
        lag=3*((1-low)**(1/3)-(1-high)**(1/3)) if dust else high-low
        assert 2*lag<L
        measure=((1-low)**3-(1-high)**3)/3 if dust else high-low
        rng=np.random.default_rng(np.random.SeedSequence([s['seed'],j,k]))
        for run in range(s['reps']):
            n=rng.poisson(lam*L**3*measure)
            if dust:
                times=1-np.cbrt(rng.uniform((1-high)**3,(1-low)**3,n))
            else:
                times=rng.uniform(low,high,n)
            times.sort()
            eta=3*(-np.expm1(np.log1p(-times)/3)) if dust else times
            pos=rng.uniform(0,L,(n,3))
            inside=np.sum((pos-L/2)**2,axis=1)<rad**2
            sigma=inside/(1-times)**2 if dust else inside.astype(float)
            val=func(n,times,eta,pos,sigma,L,t,lam)
            rows.append(dict(geo=geo,pad=pad,run=run,n=n,mass=val))
        vals=[r['mass'] for r in rows if r['geo']==geo and r['pad']==pad]
        print(geo,pad,np.mean(vals),np.std(vals,ddof=1)/math.sqrt(len(vals)),flush=True)
with open('direct.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
