# Offene Staubhistorien · Eingabe für CST Dynamic Bounce Gate v0.1

Der Generator bildet eine vollständige, kleine Summe von 27 markierten homogenen Verlaufskandidaten. Er konstruiert die Ordnungen aus raumzeitlichen Lichtkegeln, misst fünf Volumina und berechnet die Historiensummen. Es gibt keine von Hand eingetragenen Zweigamplituden. Dies ist eine neue, eingeschränkte Vergleichsfamilie mit vorgegebenem Raumansatz, lokaler Schrittregel, physikalischer Skalenkonvention und einfacher Staubkopplung. Sie ersetzt weder Familie C noch die dort offene geometrische Gewichtung. Die Quellen des unveränderten Gates und ihr Herkunftsnachweis liegen in gate_v01/. plan.json wurde lokal vor Berechnung der neuen Amplituden eingefroren. Der Hash ist kein externer Präregistrierungszeitstempel.

## Reproduktion

Getestet unter Linux mit Python 3.12.14, python-flint 0.9.0, NumPy 2.3.5, SciPy 1.17.0 und g++ 13.3 mit C++17. g++ muss im Suchpfad liegen. Die Vollrechnung und das Audit laufen nacheinander auf einem lokalen Rechner. Die Daten werden vollständig im Paket erzeugt. Für ausdrücklich unveränderte Ausgabebytes die Referenzversionen einsetzen und Python mit aktivierten Assertions ausführen.

    sha256sum -c SHA256SUMS
    sha256sum -c PLAN_SHA256
    (cd gate_v01 && sha256sum -c CONTRACT_SHA256)
    python3 -m venv .venv
    .venv/bin/python -m pip install python-flint==0.9.0 numpy==2.3.5 scipy==1.17.0
    OPENBLAS_NUM_THREADS=1 .venv/bin/python geometry.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python run.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python audit.py > replay-audit.json
    cmp audit.json replay-audit.json
    .venv/bin/python gate_v01/gate.py primary_input.json > replay-gate.json
    cmp primary_result.json replay-gate.json
    sha256sum -c SHA256SUMS

Die Reihenfolge ist wichtig: geometry.py prüft die vollständige Offenheit des Trägers, bevor run.py die Gravitationsphasen auswertet. run.py wiederholt die Prüfung, kompiliert den C++-Zähler im temporären Ordner und schreibt beide Gate-Eingaben/-Ausgaben, intervals.csv und support.json neu. Das technische HOLD ist eine reguläre Auswertung. Die Grafik lässt sich optional mit Matplotlib 3.10.8 und figure.py nachzeichnen.

## Welche Geometrien entstehen?

Der Kandidat verwendet eine komovierende Einheitszelle mit drei periodischen Raumrichtungen. Das metrische Vergleichsmodell hat c=1, ds²=−dT²+a(T)² dx², mit a linear zwischen den fünf makroskopischen Staubzeiten. In Einheiten der anfänglichen physikalischen Seitenlänge sind diese T=0, 2/5, 4/5, 6/5, 8/5. Pro Seite werden bei der groben Diskretisierung s=1/5 zunächst 5, danach 4 Zellen gezählt. Ausgehend davon wird die Breite bei jedem der drei folgenden Schritte um −1, 0 oder +1 verändert. Es gibt keine Filterung nach dem Endvolumen. Bei gleicher früher Präparation treten Kontraktion und Umkehr auf. Die minimale Breite eins wird frühestens am Ende erreicht. Im betrachteten Fenster gibt es keine Regel, die eine Reflexion an der Breite eins verlangt. Das Modell macht keine Aussage über die anschliessende Entwicklung. Alle 27 Breitenpfade haben positives Grundgewicht 1/27. In dieser reduzierten Summe identifiziert die Folge der markierten Schichtgrössen die jeweilige Klasse. Die Erzeugungsregel stellt keine Herleitung eines physikalischen Masses auf beliebigen Kausalsets dar.

Bei der feineren Auflösung s=1/10 wird jede komovierende Gitterdimension an den gemeinsamen Ablesezeiten verdoppelt. In jeden der vier Zeitabschnitte wird eine echte zusätzliche Schicht in der zeitlichen Mitte eingefügt. Bei ganzzahligen Seitenzahlen n liegt jede Gitterstelle bei (i/n,j/n,k/n), die Gitterursprünge stimmen überein. Die alten Punkte bilden darin eine eingebettete Teilordnung. Die Verfeinerung verbessert die Abtastung derselben geometrischen Verläufe. Sie vergrössert den Raum zulässiger makroskopischer Bewegungen nicht.

Die Distanz zweier komovierender Orte ist der kürzeste periodische euklidische Abstand, einschliesslich möglicher Umwicklungen. Zwischen verschiedenen Staubzeiten gilt die Kausalrelation genau dann, wenn dieser Abstand höchstens dem Integral von dT/a entspricht. Für benachbarte Tickschichten mit Seitenzahlen n,m ergibt sich 2/n bei n=m, sonst 2 log(m/n)/(m−n). Die 160-Bit-Einschliessung dieser Länge legt den ganzzahligen Vergleich mit den quadrierten Koordinatendifferenzen fest. Konstante Abschnitte werden rational behandelt, sodass echte Lichtkegelgleichheit einbezogen wird. Die Einheiten der Modelluhr sind hier vorgegeben. Das explizite Audit rekonstruiert die Ränge aus der vollständigen Ordnung; die absoluten Eigenzeitabstände und der Faktor s³ stammen aus der Kalibrierung des Gitters.

Das Volumen der gesamten räumlichen Schicht ist N_j s³=(n_j s)³. Diese Gleichheit folgt unabhängig der Amplituden aus der räumlich flachen Metrik und der exakten Kachelung. Die punktförmigen Ereignisse stammen aus einem regulären Gitter, nicht aus einer unabhängigen Poisson-Streuung. Eine Übertragung der Volumeneinheiten und der diskreten Wirkung auf unmarkierte, poissonartige 4D-Kausalsets wäre gesondert zu prüfen.

## Was liefert die Dynamik?

Pro diskreter Ordnung wird Q = N−N0+9N1−16N2+8N3 direkt aus den Anzahlen offener Intervalle mit null bis drei inneren Elementen berechnet. Die Phase ist exp(i g Q). Mit Tickabstand 2s und räumlichem Zellvolumen s³ ist die nominale Vierervolumeneinheit 2s⁴. Bei festem G und hbar wird der Vorfaktor proportional zur Quadratwurzel dieses Volumens skaliert. Aus g_grob=4pi/5 folgt g_fein=pi/5. Eine einheitliche komovierende Staubwirkung −M mal gesamte Eigenzeit erzeugt nur eine gemeinsame Phase, die wegfällt. Dies liefert eine gravitative Phasendiagnostik auf einem homogenen Ansatz. Ein massenabhängiger Druckterm, dynamisch bestimmte Anfangsimpulse, der Rand eines endlichen Staubballs, eine Kontinuumsrenormierung und ein unabhängiger Nachweis der BDG-Kontinuumstreue gehören nicht zum getesteten Kandidaten. Auf dem Torus gibt es keinen räumlichen Rand; an den beiden Zeitschnitten ist kein zusätzlicher Randterm eingesetzt.

Die primäre Endaufzeichnung ist ein idealer, grob aufgelöster Volumenzähler. Seine elf orthonormalen Kanäle haben Index floor(4 V_end/V_ref). Er speichert ausschliesslich das endgültige Volumen und kennt die Abfolge der fünf Messwerte nicht. Ein einzelner Endbin enthält die Bounce-Historie und fünf übrige Historien; die Endspur trennt also nicht die beiden Ergebnisse künstlich. Der kinematische Vergleich verwendet genau dieselben Historiensätze, Markierungen, Basis und positiven Gewichte mit ausgeschalteter BDG-Phase. Eine sekundäre Kontrollrechnung entfernt die Endinformation ganz.

Die positive B-Fortsetzung hat die fünf Volumenverhältnisse 1,64/125,27/125,64/125,1. Ein streng weiter kontrahierendes N-Beispiel lautet 1,64/125,27/125,8/125,1/125. N enthält insgesamt 26 Verläufe und umfasst jede Verletzung des festgelegten Fünf-Zeiten-Musters; diese 26 sind nicht alle monoton. Die ungewichtete Häufigkeit von B beträgt 1/27. Das kohärent berechnete Diagonalgewicht des Nullmodells beträgt dagegen exakt 1/185. Zu den fünf besetzten Endbins tragen die N-Verläufe die Anzahlen 10,7,5,3,1 bei. Mit der B-Amplitude 1 im gemeinsam genutzten Bin ergibt sich S=185 vor gemeinsamer Normierung und epsilon=2*5/185=2/37 > 1/21. Diese Schrankenverletzung besteht bereits ohne eine Gravitationsphase. Mehr numerische Präzision bei unveränderter Präparation und Messregel kann sie nicht beseitigen.

## Unabhängige Prüfung

intervals.cpp baut für jedes Schichtpaar die volle Kausalrelation (oder einen expliziten Vollblock) und zählt pro vergleichbarem Endpunktpaar die offenen Intervallpunkte in allen dazwischen liegenden Schichten. Ab vier Punkten kann die Zählung abbrechen. Ganze Teilintervalle zwischen Schichten werden zwischengespeichert, wenn sie dieselben Zwischenschichtzahlen haben. Einschliesslich der Endeffekte wird keine Zeitschicht ausgelassen.

audit.py baut unabhängig die einzelnen kartesischen Punkte, berechnet die optische Zeit durch direkte Quadratur und verwendet volle Zukunfts- und Vergangenheitsmengen. Ihre Schnittmengen liefern N0 bis N3 ohne die Optimierungen des Hauptzählers. Alle 27 groben Ordnungen sowie die vollständigen fein aufgelösten Beispielordnungen für den strikten Kollaps und den Bounce stimmen exakt überein. Für alle 54 Aktionsauswertungen werden die Klassenphasen zusätzlich als ganzzahlige Polynome modulo Phi_10=X⁴−X³+X²−X+1 aufsummiert. Eine separate Radikaldarstellung der Einheitswurzel mit 192-Bit-Ballarithmetik prüft die Hauptschranken und zeigt, dass die tatsächliche Interferenz die Schwelle überschreitet. Die Radien im Gate-Eingabedokument decken nur den numerischen Approximationsfehler der Phasen ab. Sie decken keine Unsicherheit der Modellwahl ab.

Ein negatives numerisches FAIL verlangt im unveränderten Gate ebenfalls kleine Interferenz. Die beiden HOLD-Entscheidungen weisen daher keine dominante physikalische Fortsetzung aus. Die Krümmungsregularität und die globale Fortsetzung werden hier nicht gemessen.

Quellen: [Gate v0.1, PR 217](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/217); [Projektbericht zur Wirkung, Gl. 14](https://github.com/thomasmgfeller/x6-spectral-astrolabium/blob/main/research/rax_cqg/dust_collapse/reports/CST_Staubkollaps_Quantendynamik_Herleitung.pdf); [BDG-Intervallwirkung, Phys. Rev. Research](https://doi.org/10.1103/qdst-yrh6).
