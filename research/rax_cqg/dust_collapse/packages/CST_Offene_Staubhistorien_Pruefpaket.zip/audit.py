"""Independent coordinate posets, interval recount and exact phase-polynomial audit."""
import csv
import json
import math
from collections import Counter,defaultdict
from fractions import Fraction as F
import itertools
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from flint import arb,acb,ctx

ROOT=Path(__file__).resolve().parent
ctx.prec=192


def explicit_order(n):
    # Generate the actual cartesian point sets. No C++ masks, interval cache or generator thresholds.
    xyz=[np.array(list(itertools.product(range(m),repeat=3)),dtype=np.int32) for m in n]
    offsets=list(itertools.accumulate((len(x) for x in xyz),initial=0))
    future=[0]*offsets[-1]; past=[0]*offsets[-1]
    optical=[quad(lambda u:2/(a+(b-a)*u),0.,1.,epsabs=2e-14)[0] for a,b in zip(n,n[1:])]
    for i,low in enumerate(xyz):
        for j in range(i+1,len(n)):
            product=n[i]*n[j]
            if len(set(n[i:j+1]))==1:
                sq=(F(2*(j-i),n[i])*product)**2;cut=sq.numerator//sq.denominator
            else:
                x=(sum(optical[i:j])*product)**2
                if x>=3*(product//2)**2+1.e-7:cut=3*(product//2)**2
                else:
                    assert abs(x-round(x))>1e-7
                    cut=math.floor(x)
            high=xyz[j];rel=np.empty((len(low),len(high)),dtype=bool)
            for start in range(0,len(low),32):
                delta=abs(low[start:start+32,None,:]*n[j]-high[None,:,:]*n[i])
                delta=np.minimum(delta,product-delta)
                rel[start:start+32]=np.einsum('...i,...i->...',delta,delta)<=cut
            if j==i+1: assert rel.any(axis=1).all() and rel.any(axis=0).all()
            for row,bits in enumerate(np.packbits(rel,axis=1,bitorder='little')):
                future[offsets[i]+row] |= int.from_bytes(bits.tobytes(),'little')<<offsets[j]
            for col,bits in enumerate(np.packbits(rel.T,axis=1,bitorder='little')):
                past[offsets[j]+col] |= int.from_bytes(bits.tobytes(),'little')<<offsets[i]
    remaining=(1<<len(future))-1;widths=[]
    while remaining:
        layer=[u for u,p in enumerate(past) if (remaining>>u)&1 and not (remaining&p)]
        assert layer
        widths.append(len(layer)); remaining-=sum(1<<u for u in layer)
    assert widths==[m**3 for m in n]
    bins=[0,0,0,0]
    for u,after in enumerate(future):
        # Iterate the future point labels; every open Alexandrov interval is the bitwise intersection.
        bits=after
        while bits:
            lowbit=bits & -bits
            j=lowbit.bit_length()-1
            num=(after & past[j]).bit_count()
            if num<4:bins[num]+=1
            bits^=lowbit
    return [len(future),*bins,len(future)-bins[0]+9*bins[1]-16*bins[2]+8*bins[3]]


def poly(counts):
    # Integer remainder modulo Phi_10 = X^4-X^3+X^2-X+1.
    c=[counts[j] for j in range(10)]
    for i in range(9,3,-1):
        top=c[i]
        for j,x in enumerate((1,-1,1,-1,1)):c[i-4+j]-=top*x
    return c[:4]


def evaluate_polynomial(p,z):
    v=acb(0)
    for a in reversed(p):v=v*z+a
    return v


def rational(x):
    x=F(x);return arb(x.numerator)/x.denominator


def phase_check(rows,name,silent):
    encoded=json.loads((ROOT/(name+'_input.json')).read_text())
    report=json.loads((ROOT/(name+'_result.json')).read_text())
    assert report['numeric_status']=='HOLD'
    verified=[]
    for level,result in enumerate(report['levels']):
        class_counts=Counter()
        bins=defaultdict(Counter)
        for row in rows:
            if int(row['level'])!=level: continue
            w=[int(x) for x in row['path'].split('-')]
            v=[F(x**3,125) for x in w]
            direction=(v[0]-v[1],v[1]-v[2],v[3]-v[2],v[4]-v[3])
            k='B' if min(*direction,v[2])>=F(1,20) else 'N'
            end=0 if silent else int(4*v[-1])
            class_counts[k,end]+=1
            r=(int(row['Q'])*(4 if level==0 else 1))%10
            bins[k,end][r]+=1
        dim=1 if silent else 11
        # Algebraic radical representation of exp(i*pi/5), independent of exponential calls.
        root5=arb(5).sqrt()
        z=acb((1+root5)/4,(10-2*root5).sqrt()/4)
        states=[[evaluate_polynomial(poly(bins[k,i]),z) for i in range(dim)] for k in ('B','N')]
        b,n=states
        nb=sum(abs(v)**2 for v in b);nn=sum(abs(v)**2 for v in n)
        cross=sum(x.conjugate()*y for x,y in zip(b,n))
        q=nb/(nb+nn);eps=2*abs(cross)/(nb+nn)
        bound=result['dynamic']
        assert rational(bound['q']['B'][0])<q<rational(bound['q']['B'][1])
        assert eps>rational('1/21') and eps<rational(bound['epsilon_upper'])
        count_sums=[sum(class_counts[k,i]**2 for i in range(dim)) for k in ('B','N')]
        norm=sum(count_sums)
        null_q=F(count_sums[0],norm)
        null_eps=F(2*sum(class_counts['B',i]*class_counts['N',i] for i in range(dim)),norm)
        assert F(result['null']['q']['B'][0])<=null_q<=F(result['null']['q']['B'][1])
        assert null_eps>F(1,21) and null_eps<=F(result['null']['epsilon_upper'])
        # No history receives an outcome flag as an end record.
        assert sum(1 for i in range(dim) if class_counts['B',i] and class_counts['N',i])>=1
        assert len(encoded['levels'][level]['histories'])==sum(class_counts.values())
        verified.append(dict(q_B=str(q),epsilon=str(eps),null_q=str(null_q),null_epsilon=str(null_eps)))
    return verified


def main():
    with (ROOT/'intervals.csv').open() as f:rows=list(csv.DictReader(f))
    checked=[]
    for row in rows:
        level=int(row['level'])
        if level==1 and row['path'] not in ('5-4-3-4-5','5-4-3-2-1'):continue
        answer=explicit_order([int(x) for x in row['side_counts'].split(',')])
        assert answer==[int(row[k]) for k in ('events','N0','N1','N2','N3','Q')]
        checked.append([row['path'],level])
    assert len(checked)==29
    return dict(full_orders_explicitly_recounted=checked,primary=phase_check(rows,'primary',False),
                silent=phase_check(rows,'silent',True))


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Enable assertions')
    print(json.dumps(main(),indent=2))
