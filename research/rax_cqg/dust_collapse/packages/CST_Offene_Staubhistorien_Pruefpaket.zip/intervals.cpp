// Exact counts for strict temporal precedence and periodic spherical light cones.
// Each link block is a full order relation between two time slices.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <tuple>
#include <vector>
using Bits = std::uint64_t;
using Hist = std::array<long long,4>;
using Key = std::tuple<int,int,int>;

struct Relation {
    int left, right, na, nb, fwa, pwb;
    bool complete;
    std::vector<Bits> future, past;
    std::vector<int> nf,np;
    Relation(int a,int b,int cut) : left(a),right(b),na(a*a*a),nb(b*b*b),
        fwa((nb+63)/64),pwb((na+63)/64),complete(cut>=3*((a*b)/2)*((a*b)/2)) {
        if(complete) return;
        future.assign(na*fwa,0);past.assign(nb*pwb,0);
        nf.assign(na,0);np.assign(nb,0);
        std::vector<int> d(a*b);
        for(int i=0;i<a;i++) for(int j=0;j<b;j++){
            int dx=std::abs(i*b-j*a);dx=std::min(dx,a*b-dx);d[i*b+j]=dx*dx;
        }
        for(int u=0;u<na;u++){
            const int *xx=&d[(u/(a*a))*b], *yy=&d[((u/a)%a)*b], *zz=&d[(u%a)*b];
            for(int x=0;x<b;x++) for(int y=0;y<b;y++){
                int rem=cut-xx[x]-yy[y];if(rem<0)continue;
                for(int z=0;z<b;z++) if(zz[z]<=rem){
                    int v=(x*b+y)*b+z;
                    future[u*fwa+v/64] |= Bits(1)<<(v%64);
                    past[v*pwb+u/64] |= Bits(1)<<(u%64);
                    nf[u]++;np[v]++;
                }
            }
        }
    }
    bool has(int u,int v)const{return complete || (future[u*fwa+v/64] & (Bits(1)<<(v%64)));}
};

static std::map<Key,std::unique_ptr<Relation>> blocks;
const Relation *block(int a,int b,int cut){
    Key key={a,b,cut};auto &ptr=blocks[key];
    if(!ptr) ptr=std::make_unique<Relation>(a,b,cut);
    return ptr.get();
}

int count_middle(const Relation &left,const Relation &right,int u,int v,int limit){
    if(left.complete) return right.complete ? left.nb : right.np[v];
    if(right.complete)return left.nf[u];
    const Bits *a=left.future.data()+u*left.fwa,*b=right.past.data()+v*right.pwb;
    int total=0;
    for(int w=0;w<left.fwa;w++){
        total+=__builtin_popcountll(a[w]&b[w]);
        if(total>=limit)break;
    }
    return total;
}

using Matrix=std::vector<std::vector<const Relation*>>;
static std::map<std::vector<int>,Hist> cache;
Hist count_span(const Matrix &links,const std::vector<int>&n,int i,int j){
    std::vector<int> key(n.begin()+i,n.begin()+j+1);
    auto found=cache.find(key);
    if(found!=cache.end())return found->second;
    Hist h{};const Relation &ab=*links[i][j];
    for(int k=i+1;k<j;k++) if(links[i][k]->complete && links[k][j]->complete && n[k]*n[k]*n[k]>=4)
        return cache[key]=h;
    if(j==i+1){
        if(ab.complete) h[0]=static_cast<long long>(ab.na)*ab.nb;
        else {
            for(int c:ab.nf){if(!c)throw std::runtime_error("no successor");h[0]+=c;}
            for(int c:ab.np)if(!c)throw std::runtime_error("no predecessor");
        }
    } else {
        for(int u=0;u<ab.na;u++) for(int v=0;v<ab.nb;v++){
            if(!ab.has(u,v))continue;
            int inner=0;
            for(int k=i+1;k<j && inner<4;k++)
                inner+=count_middle(*links[i][k],*links[k][j],u,v,4-inner);
            if(inner<4)h[inner]++;
        }
    }
    return cache[key]=h;
}

int main(){
    int id,level,L;
    while(std::cin>>id>>level>>L){
        if(L!=5 && L!=9)return 2;
        std::vector<int> n(L);
        int events=0;
        for(int &a:n){if(!(std::cin>>a)||a<1||a>14)return 2;events+=a*a*a;}
        Matrix links(L,std::vector<const Relation*>(L));
        for(int i=0;i<L;i++)for(int j=i+1;j<L;j++){
            int cut;if(!(std::cin>>cut)||cut<0)return 2;
            links[i][j]=block(n[i],n[j],cut);
        }
        Hist counts{};
        for(int i=0;i<L;i++)for(int j=i+1;j<L;j++){
            Hist h=count_span(links,n,i,j);
            for(int r=0;r<4;r++)counts[r]+=h[r];
        }
        auto q=events-counts[0]+9*counts[1]-16*counts[2]+8*counts[3];
        std::cout<<id<<' '<<level<<' '<<events;
        for(auto c:counts)std::cout<<' '<<c;
        std::cout<<' '<<q<<'\n';
    }
}
