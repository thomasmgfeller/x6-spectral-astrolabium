import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parent
with (root/'primary_input.json').open() as f:rows=json.load(f)['levels'][0]['histories']
def value(x):
    from fractions import Fraction
    return float(Fraction(x))
time=np.array([0,.4,.8,1.2,1.6])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'pdf.fonttype':42})
fig,(a,b)=plt.subplots(1,2,figsize=(7.4,2.4),gridspec_kw={'width_ratios':[1.32,1]})
fig.subplots_adjust(left=.083,right=.98,bottom=.22,top=.86,wspace=.42)
special={'5-4-3-4-5':('#006b63','Aufgelöste Umkehr'),'5-4-3-2-1':('#b25b31','Weitere Kontraktion')}
for row in sorted(rows,key=lambda r:r['id'] in special):
    vol=[value(x[0]) for x in row['volumes']]
    color,label=special.get(row['id'],('#bcc5c9',None))
    if label:a.plot(time,vol,'o-',c=color,lw=1.7,ms=3,label=label)
    else:a.plot(time,vol,c=color,lw=.8,alpha=.6)
a.set(title='Zulässige Fortsetzungen',xlabel='Staubeigenzeit',ylabel='Volumen / Anfangsvolumen',xticks=time)
a.legend(loc='upper left',frameon=False,fontsize=7)
data=json.loads((root/'audit.json').read_text())['primary']
codes=[float(k['epsilon'].split()[0][1:]) for k in data]+[2/37]
b.barh([2,1,0],codes,color=['#4b6878','#11766e','#9a755c'],height=.55)
b.axvline(1/21,color='#833627',linestyle='--',lw=1.3)
b.set(yticks=[2,1,0],yticklabels=['Grob','Fein','Nullmodell'],xlabel='Interferenz ε',title='Primäre Endaufzeichnung',xlim=(0,.35))
b.text(1/21+.006,2.48,'Grenze 1/21',fontsize=7,color='#833627')
b.set_ylim(-.5,2.75)
for ax in (a,b):ax.spines[['top','right']].set_visible(False)
fig.savefig(root/'figure.pdf')
