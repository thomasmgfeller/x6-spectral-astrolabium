"""Physical-clock cubulated homogeneous history candidate, with unmodified PR 217 decision."""
import csv
from fractions import Fraction as F
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from flint import arb,acb,ctx
from geometry import ROOT,support,prepare,layers,readings,bounce
sys.path.insert(0,str(ROOT/'gate_v01'))
import gate

ctx.prec=160
BASIS=11


def write(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2,default=str)+'\n')


def enumerate_orders(data,tmp):
    exe=Path(tmp)/'intervals'
    subprocess.run(['g++','-std=c++17','-O3','-march=native',str(ROOT/'intervals.cpp'),'-o',str(exe)],check=True)
    lines=[' '.join(map(str,[d['no'],d['level'],len(d['n']),*d['n'],*d['cuts']])) for d in data]
    proc=subprocess.run([exe],input='\n'.join(lines)+'\n',text=True,capture_output=True,check=True)
    result={}
    for line in proc.stdout.splitlines():
        i,l,events,*other=map(int,line.split())
        ns,q=other[:4],other[4]
        assert q==events-ns[0]+9*ns[1]-16*ns[2]+8*ns[3]
        result[(i,l)]=(events,*ns,q)
    assert len(result)==len(data)
    return result


def certified_phase(residue):
    if residue in (0,5):return (F(1 if residue==0 else -1,27),F(0)),F(0)
    z=acb(0,arb.pi()*residue/5).exp()/27
    def round_coord(x):
        n=int(float(x)*2**50)
        exact=F(n,2**50)
        assert abs(x-arb(exact.numerator)/exact.denominator)<arb(1)/2**49
        return exact
    return (round_coord(z.real),round_coord(z.imag)),F(1,2**48)


def entry(q,level,bin_id,dim):
    code=(q*(4 if level==0 else 1))%10
    coords,radius=certified_phase(code)
    dyn=[[0,0] for _ in range(dim)];dyn[bin_id]=list(map(str,coords))
    null=[[0,0] for _ in range(dim)];null[bin_id]=['1/27',0]
    return dict(a=dyn,radius=str(radius)),dict(a=null,radius='0')


def make_input(paths,orders,silent):
    dim=1 if silent else BASIS
    design=dict(times=['0','2/5','4/5','6/5','8/5'],physical_time_unit='one early side length, c=1',
        region='periodic marked unit comoving three-torus',clock='synchronous comoving proper-time ticks',
        early_input='side length 1 then 4/5 at T=2/5, same linear contraction, constant comoving dust mass',
        early_volume_scale='Vref=1 fixed by early unit cube',observable='spatial event count times s^3 in a full dust-clock layer',
        dynamics='4D interval action Q, g0=4pi/5; g1=pi/5; common comoving dust phase removed; no boundary correction',
        measure='uniform 1/27 on the reduced move histories',null='turn off BDG phase only',
        records=dict(basis='orthonormal',dimension=dim,
                     instrument='silent projection' if silent else 'ideal final volume pointer floor(4*Vend/Vref)'),
        support_policy='full 3^3 open continuations; identical continuum interpolant at both samplings',
        joint_error_budget='exact lattice volumes, integer intervals and certified complex Euclidean radii; physical model error outside these bounds')
    sha=gate.digest(design)
    document=dict(scope='candidate',contract_sha256=gate.VERSION,design=design,design_sha256=sha,levels=[])
    for level in (0,1):
        rows=[]
        for i,path in enumerate(paths):
            v=readings(layers(path,level),level);q=orders[i,level][-1]
            dyn,null=entry(q,level,0 if silent else int(4*v[-1]),dim)
            rows.append(dict(id='-'.join(map(str,path)),volumes=[[str(value),str(value)] for value in v],dynamic=dyn,null=null))
        document['levels'].append(dict(ell=str(F(1,5*(level+1))),design_sha256=sha,
            inventory_sha256=gate.digest(sorted(r['id'] for r in rows)),histories=rows))
    return document


def run():
    paths,data,inventory=prepare()
    write('support.json',inventory)
    with TemporaryDirectory() as tmp: orders=enumerate_orders(data,tmp)
    with (ROOT/'intervals.csv').open('w',newline='') as stream:
        wr=csv.writer(stream,lineterminator='\n');wr.writerow(['path','level','side_counts','events','N0','N1','N2','N3','Q'])
        for (i,l),vals in sorted(orders.items()):
            wr.writerow(['-'.join(map(str,paths[i])),l,','.join(map(str,layers(paths[i],l))),*vals])
    for silent,name in ((False,'primary'),(True,'silent')):
        doc=make_input(paths,orders,silent);write(name+'_input.json',doc)
        answer=gate.run(doc);assert answer['numeric_status']!='INVALID'
        write(name+'_result.json',answer)
        print(name,answer['numeric_status'],answer['reasons'])
        for level in answer['levels']:
            print(level['ell'],[(ch,float(level[ch]['q']['B'][0]),float(level[ch]['epsilon_upper'])) for ch in ('dynamic','null')])


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Enable assertions')
    run()
