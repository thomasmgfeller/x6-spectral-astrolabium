"""Generate open width histories and exact light-cone predicates for the periodic lattice."""
import hashlib
import itertools
import json
from collections import Counter
from fractions import Fraction as F
from functools import cache
from pathlib import Path
from flint import arb,ctx

ROOT=Path(__file__).resolve().parent
HASH='b7ff0aa471d7c7518600e8e3ee2696ea7eafa46d231f545cacf1ea138b5b6a16'
ctx.prec=160


def support():
    if hashlib.sha256((ROOT/'plan.json').read_bytes()).hexdigest()!=HASH: raise ValueError('Plan hash')
    histories=[]
    for moves in itertools.product((-1,0,1),repeat=3):
        widths=[5,4]
        for move in moves: widths.append(widths[-1]+move)
        histories.append(tuple(widths))
    # Independent exhaustive enumeration from the adjacent-width condition.
    brute={(5,4,i,j,k) for i,j,k in itertools.product(range(1,8),repeat=3)
           if max(abs(i-4),abs(j-i),abs(k-j))<=1}
    assert set(histories)==brute and len(histories)==27
    return histories


def layers(w,level):
    if level==0: return tuple(w)
    values=[2*w[0]]
    for a,b in zip(w,w[1:]):values.extend((a+b,2*b))
    return tuple(values)


def readings(n,level):
    spacing=F(1,5*(level+1))
    return [(count**3)*spacing**3 for count in n[::(level+1)]]


def bounce(v):
    return min(v[0]-v[1],v[1]-v[2],v[3]-v[2],v[4]-v[3],v[2])>=F(1,20)


@cache
def threshold(span):
    n,m=span[0],span[-1]
    denom=n*m
    cap=3*(denom//2)**2
    if len(set(span))==1:
        x=(F(2*(len(span)-1),n)*denom)**2
        return min(x.numerator//x.denominator,cap)
    length=arb(0)
    for a,b in zip(span,span[1:]):
        length+=arb(2)/a if a==b else 2*(arb(b)/a).log()/(b-a)
    x=(length*denom)**2
    if x>cap: return cap
    floor=int(float(x))
    if not (x>floor and x<floor+1): raise ArithmeticError('Unresolved light cone')
    return floor


def prepare():
    allw=support()
    data=[]; tally=Counter(); bins={'B':set(),'N':set()}
    for no,w in enumerate(allw):
        v=readings(layers(w,0),0)
        assert v==readings(layers(w,1),1)
        kind='B' if bounce(v) else 'N'
        tally[kind]+=1
        bins[kind].add(int(4*v[-1]))
        for level in (0,1):
            n=layers(w,level)
            assert all(a*2==b for a,b in zip(w,layers(w,1)[::2]))
            data.append(dict(no=no,level=level,n=n,
                 cuts=[threshold(n[i:j+1]) for i in range(len(n)) for j in range(i+1,len(n))]))
    assert (5,4,3,2,1) in allw and (5,4,3,4,5) in allw and all(tally[v]>0 for v in ('B','N'))
    assert bins['B']&bins['N']
    return allw,data,dict(by_class=tally,terminal_bins={k:sorted(v) for k,v in bins.items()},
                         common_bins=sorted(bins['B']&bins['N']))


if __name__=='__main__':
    _,_,s=prepare()
    print(json.dumps(s,indent=2))
