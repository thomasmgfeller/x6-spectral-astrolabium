"""Two time-slab Poisson count responses for the fixed dust mass estimator.

Run with Python 3 and NumPy. Only deterministic quadratures are evaluated.
The original model inputs are recorded in reference_inputs.json.
"""
from functools import lru_cache
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
INPUT = json.loads((HERE/'reference_inputs.json').read_text())
MU = INPUT['mu']
S = INPUT['cut']
LAM = INPUT['lambda']


@lru_cache(maxsize=None)
def rule(n):
    x, w = np.polynomial.legendre.leggauss(n)
    return (x+1)/2, w/2


def eta(t):
    return -3*np.expm1(np.log1p(-t)/3)


def signal(z):
    return np.exp(-z)*(1+z*(-9+z*(8-4*z/3)))


def signal_prime(z):
    return np.exp(-z)*(-10+z*(25+z*(-12+4*z/3)))


def lens_part(start, end, y_eta, d, v):
    # u is normalized conformal time within the interval and v the normalized
    # separation in space. The two light cones enclose concentric or intersecting balls.
    out = 0.
    x, w = rule(6)
    for zone, (a, b) in enumerate(((0., (1-v)/2), ((1-v)/2, (1+v)/2), ((1+v)/2, 1.))):
        lo = np.maximum(start, a)
        width = np.maximum(0., np.minimum(end,b) - lo)
        subtotal = 0.
        for node, weight in zip(x, w):
            u = lo + width*node
            if zone == 0:
                volume = 4*u**3/3
            elif zone == 2:
                volume = 4*(1-u)**3/3
            else:
                volume = (1-v)**2*(v*v+2*v-3*(2*u-1)**2)/(12*v)
            subtotal += weight*(1-(y_eta+d*u)/3)**8*volume
        out += width*subtotal
    return np.pi*d**4*out


def halo_volume(lo, hi, top):
    x, w = rule(24)
    t = lo+(hi-lo)*x
    radius = (3/(4*np.pi))**(1/3) + eta(top)-eta(t)
    return float((hi-lo)*np.dot(w,(1-t)**2*4*np.pi/3*radius**3))


def integrate(case,n):
    P, F = case['past'],case['future']
    nodes, weights = rule(n)
    radial = nodes[None,None,:]
    h = 0.0002
    changes = [(h,0),(-h,0),(0,h),(0,-h),(h,h),(-h,-h)]
    total = np.zeros(3+len(changes))
    # Split time at eta(x)-eta(s) == eta(s)-eta(y), where the angular break switches sign.
    # Split the outer y range as well if the switching point crosses the upper x boundary.
    reflect = lambda e: -np.expm1(3*np.log1p(-e/3))
    ybreak = float(np.clip(reflect(2*eta(S)-eta(S+F)), S-P, S))
    for yl,yh in ((S-P,ybreak),(ybreak,S)):
        if yh<=yl:
            continue
        y=yl+(yh-yl)*nodes[None,:,None]
        ey=eta(y)
        xb=np.clip(reflect(2*eta(S)-ey),S,S+F)
        for xl,xh in ((S,xb),(xb,S+F)):
            for first in range(0,n,4):
                ix=slice(first,min(n,first+4))
                x=xl+(xh-xl)*nodes[ix,None,None]
                d=eta(x)-ey
                split=(eta(S)-ey)/d
                boundary=np.abs(1-2*split)
                wxy=(yh-yl)*(xh-xl)*weights[None,:,None]*weights[ix,None,None]
                for low,high in ((0.,boundary),(boundary,1.)):
                    v=low+(high-low)*radial
                    a=MU*lens_part(0.,split,ey,d,v)
                    b=MU*lens_part(split,1.,ey,d,v)
                    z=a+b
                    base=wxy*(high-low)*weights[None,None,:]*(x-y)*(1-y)**2*d**3*v**2
                    k=signal(z)
                    kp=signal_prime(z)
                    total[:3]+= [np.sum(base*k),np.sum(base*(k+a*kp)),np.sum(base*(k+b*kp))]
                    for i,(u,t) in enumerate(changes,3):
                        total[i]+=np.sum(base*(1+u)*(1+t)*signal((1+u)*a+(1+t)*b))
    total *= -8*np.pi*MU**1.5/(math.sqrt(6)*case['Rpred'])
    mean,pre,post=total[:3]
    fd=(total[3::2]-total[4::2])/(2*h)
    halo=np.array([halo_volume(S-P,S,S+F),halo_volume(S,S+F,S+F)])
    terms=np.array([pre,post])**2/(LAM*halo)
    return dict(n=n,mean=float(mean),pre=float(pre),post=float(post),
                finite_difference=fd.tolist(),halo_volumes=halo.tolist(),
                sd_projection=float(np.sqrt(np.sum(terms))),
                uniform_count_sd=float(abs(pre+post)/np.sqrt(LAM*sum(halo))))


def main():
    result={}
    for key,case in INPUT['windows'].items():
        seq=[integrate(case,n) for n in (48,64,80)]
        a,b=seq[-2:]
        assert abs(b['mean']-case['mean']) < 1e-7, (key,b)
        assert abs(sum(b['halo_volumes'])*LAM-case['expected_halo']) < .02
        for v in ('mean','pre','post','sd_projection'):
            assert abs(a[v]-b[v]) < 2e-6, (key,v, a[v],b[v])
        assert max(abs(x-y) for x,y in zip(b['finite_difference'],(b['pre'],b['post'],b['pre']+b['post'])))<3e-6
        assert b['sd_projection']>=b['uniform_count_sd'] and b['sd_projection']>0
        result[key]=seq
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
