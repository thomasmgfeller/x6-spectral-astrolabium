# Staubball: Projektionsuntergrenzen der Massestreuung

Die beiden Auswertungen gelten für den mathematischen, ungekürzt geglätteten Massestrom im räumlich unbeschränkten Referenzmodell. Eine deterministische Neuberechnung benötigt Python 3 und NumPy. Getestet mit Python 3.12.14 und NumPy 2.3.5. Im entpackten Ordner ausführen.

```sh
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 python3 count_response.py > results.json
OPENBLAS_NUM_THREADS=1 python3 four_slabs.py > four_results.json
```

Die Skripte prüfen Konvergenz, Referenzmittelwerte, Dichteableitungen durch zentrale Differenzen und die Konsistenz zwischen den Partitionen. Alle Referenzparameter und SHA-256-Werte der drei publizierten Eingabetabellen sind in `reference_inputs.json` dokumentiert. Die Resultate enthalten die Einzelwerte bei 48, 64 und 80 bzw. 64, 80 und 96 Gauss-Legendre-Knoten je Koordinate und Teilbereich. Erwartet wird numerische Übereinstimmung innerhalb der im Code angegebenen Toleranzen. Die letzten Stellen hängen von der Plattform ab. `refine_design.json` dokumentiert die lokale Festlegung der zweiten Auswertung im Anschluss an die erste. Es gibt keine neue Zufallsstichprobe oder externe Präregistrierung.

Die Zahlen sind keine intervallarithmetisch zertifizierten Ausgaben. Die frühere Schranke aus dem Endbereichstest beruht auf der dort veröffentlichten statistischen Absicherung. Die Herleitung und die Grenzen der Interpretation stehen im beigefügten PDF.
