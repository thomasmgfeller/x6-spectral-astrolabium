"""Predefined refinement of the two Poisson counts into four time slabs."""
from functools import lru_cache
import json
import math
import numpy as np
from count_response import HERE, INPUT, MU, LAM, S, eta, halo_volume, lens_part, rule, signal, signal_prime


@lru_cache(maxsize=None)
def moment(j,k):
    f=math.factorial
    m=192*f(2*j)*f(2*k+3)/(f(2*j+2*k+4)*2**(2*j+2*k+4)*(2*k+1)*(2*k+3))
    return m*f(8)/(f(8-2*j-2*k)*f(2*j)*f(2*k))


def full_argument(ey,d,v):
    # Published moment-polynomial representation (common.py and reference.py).
    am=1-(ey+d/2)/3
    e=(d/(3*am))**2
    poly=[sum(moment(j,k)*e**(j+k) for j in range(5-k)) for k in range(5)]
    h=poly[-1]
    for c in poly[-2::-1]:
        h=c+v*v*h
    return (np.pi/24)*MU*d**4*am**8*((1-v)*(1+v))**2*h


def prefix(case,cut,n):
    # B(cut) = response to a relative density change at all times T < cut.
    # Partition at endpoint indicators and where the angular lens split switches side.
    lo,hi=S-case['past'],S+case['future']
    nodes,w=rule(n)
    yc=eta(cut)
    inv=lambda u: -np.expm1(3*np.log1p(-u/3))
    y_edges=sorted(set(float(np.clip(z,lo,S)) for z in
                       (lo,S,cut,inv(2*yc-eta(S)),inv(2*yc-eta(hi)))))
    x_edges=sorted(set((S,float(np.clip(cut,S,hi)),hi)))
    ans=np.zeros(4)
    step=0.0002
    for yl,yh in zip(y_edges,y_edges[1:]):
        y=yl+(yh-yl)*nodes[None,:,None]
        ey=eta(y)
        for xa,xb in zip(x_edges,x_edges[1:]):
            mid=np.clip(inv(2*yc-ey),xa,xb)
            for xl,xh in ((xa,mid),(mid,xb)):
                if np.all(xh==xl):
                    continue
                for first in range(0,n,4):
                    ix=slice(first,min(n,first+4))
                    x=xl+(xh-xl)*nodes[ix,None,None]
                    d=eta(x)-ey
                    frac=np.clip((yc-ey)/d,0,1)
                    inside=(y<cut).astype(int)+(x<cut).astype(int)
                    angular_break=np.abs(1-2*frac)
                    wxy=(yh-yl)*(xh-xl)*w[None,:,None]*w[ix,None,None]
                    for a,b in ((0.,angular_break),(angular_break,1.)):
                        if np.all(a==b):
                            continue
                        v=a+(b-a)*nodes[None,None,:]
                        z=full_argument(ey,d,v)
                        if yh<=cut and xb<=cut:
                            z1=z
                        elif yl>=cut:
                            z1=0.
                        else:
                            z1=MU*lens_part(0.,frac,ey,d,v)
                        base=wxy*(b-a)*w[None,None,:]*(x-y)*(1-y)**2*d**3*v**2
                        k=signal(z)
                        ans[0]+=np.sum(base*k)
                        ans[1]+=np.sum(base*(inside*k+z1*signal_prime(z)))
                        for i,delta in ((2,step),(3,-step)):
                            ans[i]+=np.sum(base*(1+delta)**inside*signal(z+delta*z1))
    ans*=-8*np.pi*MU**1.5/(math.sqrt(6)*case['Rpred'])
    return dict(mean=float(ans[0]),response=float(ans[1]),finite_difference=float((ans[2]-ans[3])/(2*step)))


def main():
    two=json.loads((HERE/'results.json').read_text())
    out={}
    for name,case in INPUT['windows'].items():
        original=two[name][-1]
        edges=[S-case['past'],S-case['past']/2,S,S+case['future']/2,S+case['future']]
        vol=np.array([halo_volume(l,h,edges[-1]) for l,h in zip(edges,edges[1:])])
        runs=[]
        for n in (64,80,96):
            ps=[prefix(case,t,n) for t in (edges[1],edges[2],edges[3],edges[4])]
            response=np.diff([0]+[p['response'] for p in ps])
            sd=float(np.sqrt(np.sum(response**2/(LAM*vol))))
            runs.append(dict(n=n,prefixes=ps,slab_responses=response.tolist(),sd_projection=sd))
        fine=runs[-1]; prev=runs[-2]
        for p in fine['prefixes']:
            assert abs(p['mean']-case['mean'])<1e-7, (name,p)
            assert abs(p['response']-p['finite_difference'])<3e-4, (name,p)
        assert np.allclose(fine['slab_responses'],prev['slab_responses'],rtol=0,atol=2e-5)
        assert abs(sum(fine['slab_responses'][:2])-original['pre'])<1e-6
        assert abs(sum(fine['slab_responses'][2:])-original['post'])<1e-6
        assert fine['sd_projection']>=original['sd_projection']
        out[name]=dict(edges=edges,volumes=vol.tolist(),runs=runs)
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
