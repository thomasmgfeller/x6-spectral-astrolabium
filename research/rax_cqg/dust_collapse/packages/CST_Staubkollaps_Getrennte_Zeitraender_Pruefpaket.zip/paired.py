"""Common-cloud check of past-only, future-only and corner contributions."""
import csv
import ctypes
import json
import math
import subprocess
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer

spec=json.loads(Path('design.json').read_text())
cfg=spec['direct']
s=cfg['center']; lam=cfg['intensity']; side=cfg['side']
lo,hi=spec['widths'][0],spec['widths'][-1]
radius=(3/(4*math.pi))**(1/3)
assert 2*radius<side
subprocess.run(['g++','-std=c++17','-O3','-fPIC','-shared','paired.cpp','previous_poset.cpp','-o','paired.so'],check=True)
lib=ctypes.CDLL(str(Path('paired.so').resolve()))
arr=ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
common=[ctypes.c_int,arr,arr,arr,arr,ctypes.c_double,ctypes.c_double,ctypes.c_double]
lib.flux_parts.argtypes=common+[ctypes.c_double,arr];lib.flux_parts.restype=None
lib.cut_flux.argtypes=common;lib.cut_flux.restype=ctypes.c_double
records=[];summary=[];regression=0.
for g,geo in enumerate(cfg['geometries']):
    dust=geo=='dust'
    a,b=s-hi,s+hi
    duration=3*((1-a)**(1/3)-(1-b)**(1/3)) if dust else b-a
    assert 2*duration<side
    measure=((1-a)**3-(1-b)**3)/3 if dust else b-a
    rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],g]))
    sample=[]
    for run in range(cfg['reps']):
        n=rng.poisson(lam*side**3*measure)
        t=1-np.cbrt(rng.uniform((1-b)**3,(1-a)**3,n)) if dust else rng.uniform(a,b,n)
        t.sort()
        eta=-3*np.expm1(np.log1p(-t)/3) if dust else t
        xyz=rng.uniform(0,side,(n,3))
        inside=np.sum((xyz-side/2)**2,axis=1)<radius**2
        sig=inside/(1-t)**2 if dust else inside.astype(float)
        parts=np.zeros(4);lib.flux_parts(n,t,eta,xyz,sig,side,s,lam,lo,parts)
        core,past,future,corner=parts
        values=[core,core+past,core+future,sum(parts),past,future,corner,past-future]
        if run<8:
            for (p,f),value in zip([(lo,lo),(hi,lo),(lo,hi),(hi,hi)],values):
                keep=(t>=s-p)&(t<s+f)
                reconstructed=lib.cut_flux(int(keep.sum()),t[keep],eta[keep],xyz[keep],sig[keep],side,s,lam)
                regression=max(regression,abs(reconstructed-value))
        sample.append(values)
        records.append([geo,run,n,*values])
    mat=np.asarray(sample)
    for j,name in enumerate(['ss','ls','sl','ll','past','future','mixed','asym']):
        summary.append([geo,name,mat[:,j].mean(),mat[:,j].std(ddof=1)/math.sqrt(cfg['reps'])])
assert regression<1e-9
for path,header,rows in [('paired.csv',['geo','run','count','ss','ls','sl','ll','past','future','mixed','asym'],records),
                         ('paired_summary.csv',['geo','contrast','mean','se'],summary)]:
    with open(path,'w',newline='') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)
Path('paired_check.json').write_text(json.dumps({'histories':len(records),'nested_regression_max':regression},indent=2)+'\n')
print('max nested residual',regression)
print(*summary,sep='\n')
