GETRENNTE ZEITRÄNDER BEIM DISKRETEN MASSESTROM
Reproduktion des Berichts CST_Staubkollaps_Getrennte_Zeitraender.pdf · 2.11.2026

Nach dem Entpacken im Paketverzeichnis ausführen
  OPENBLAS_NUM_THREADS=1 python3 means.py
  OPENBLAS_NUM_THREADS=1 python3 paired.py
  OPENBLAS_NUM_THREADS=1 python3 flat_limit.py
  python3 figure.py

Benötigt werden Python 3.12, NumPy, SciPy, für die optionale Grafik matplotlib
und für den direkten Ordnungsaufbau ein C++17-Compiler (g++). Getestet mit
NumPy 2.3.5 und SciPy 1.17.0 unter Linux. Es werden keine externen Daten geladen.
paired.py kompiliert die lokalen C++-Quelldateien zu paired.so.

design.json definiert die vor der Rasterauswertung gewählten Parameter, die
primäre Zelle und die Toleranzen. Die ursprüngliche Kalibrierung dient als
Vergleich. previous_flux.py ist ihr Integrator mit einem angepassten Pfad zur
mitgelieferten previous_design.json. previous_poset.cpp und previous_symmetric.csv
stammen ebenfalls aus dem vorausgehenden Prüfstand. Die separate analytische
Hochdichteprüfung im flachen Raum wurde im Anschluss ausgeführt.

cells.csv: Alle 144 Erwartungswerte, Vergleich der Quadraturordnungen und
ergänzende Endpunktdiagnose. R bezeichnet den unveränderten Strom.
contrasts.csv: Vier Randkombinationen und ihre Differenzen. In Kürzeln wie
ls oder sl steht der erste Buchstabe für die Vergangenheit, der zweite für die
Zukunft (s=kurz, l=lang). mixed ist das Rechteck beider neu erfasster Endpunkte.
asym_mid und asym_endpoint sind die explizite Messdefinitionsdiagnose.
quadrature_checks.json: Maximalabweichungen der Rechenwege und Symmetriechecks.
paired.csv: Alle 4096 direkt erzeugten 4D-Historien mit gepaarten Randbeiträgen.
paired_summary.csv und paired_check.json: direkte Mittelwerte und Standardfehler,
Vergleich mit unabhängigen Neuaufbauten aller vier Teilordnungen.
flat_limit.csv: finite flache Erwartungswerte und führender analytischer Randterm.
flat_limit.log: Normierungskontrolle und Vergleich mit dem 3D-Integrator.
SHA256SUMS.txt: SHA-256 der gelieferten Dateien ausser dieser Prüfsummenliste.

Die räumliche Materiemarkierung ist eine Kugel von komovierendem Volumen eins.
Der Umgebungswürfel der direkten Simulation ist periodisch und im verwendeten
Zeitausschnitt gross genug, um zusätzliche Umlaufpfade auszuschliessen.
Die Fehler der deterministischen Integrationen sind numerische Methodenvergleiche.
Empirische Standardfehler der direkten Stichprobe sind separat ausgewiesen.
