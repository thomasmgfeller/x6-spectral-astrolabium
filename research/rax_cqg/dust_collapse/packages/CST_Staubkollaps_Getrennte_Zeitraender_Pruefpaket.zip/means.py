"""Factorial boundary calibration, with independent FLRW interval constructions."""
import csv
import json
import math
from functools import cache
from itertools import product
from pathlib import Path
import numpy as np
from previous_flux import eta, interval_volume, unit_gauss

design=json.loads(Path('design.json').read_text())
factorial=math.factorial

@cache
def moment_coeff(j,k):
    # Even mixed moments of rest time and one spatial component in a unit diamond.
    beta=factorial(2*j)*factorial(2*k+3)/factorial(2*j+2*k+4)
    moment=192*beta/(2**(2*j+2*k+4)*(2*k+1)*(2*k+3))
    return moment*factorial(8)/(factorial(8-2*j-2*k)*factorial(2*j)*factorial(2*k))

def diamond(ey,d,v,dust):
    flat=math.pi/24*(d**2*(1-v)*(1+v))**2
    if not dust: return flat
    a0=1-(ey+d/2)/3
    b=(d/(3*a0))**2
    poly=0.0
    for degree in range(5):
        coeff=sum(moment_coeff(degree-k,k)*v**(2*k) for k in range(degree+1))
        poly=poly+coeff*b**degree
    return flat*a0**8*poly

def rectangle(s,p_range,f_range,dust,n,method=diamond):
    grid,weights=unit_gauss(n)
    pw=p_range[1]-p_range[0]
    fw=f_range[1]-f_range[0]
    u=p_range[0]+pw*grid[None,:,None]
    f=f_range[0]+fw*grid[:,None,None]
    y=s-u
    x=s+f
    radial=grid[None,None,:]
    v=1-(1-radial)**3
    ey=eta(y,dust)
    d=eta(x,dust)-ey
    iv=method(ey,d,v,dust)
    base=(weights[:,None,None]*weights[None,:,None]*weights[None,None,:]*
          (pw*fw)*(f+u)*(4*math.pi)*d**3*v**2*3*(1-radial)**2)
    late_factor=(1-y)**2 if dust else 1.0
    early_factor=(1-x)**2 if dust else 1.0
    result=[]
    for intensity in design['intensities']:
        z=intensity*iv
        kernel=np.exp(-z)*(1+z*(-9+z*(8-4*z/3)))
        scaled=-2*intensity**1.5/math.sqrt(6)*base*kernel
        result.append((float(np.sum(scaled*late_factor)),float(np.sum(scaled*early_factor))))
    return result

def write_csv(name,rows):
    with open(name,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def run():
    geometry=['flat','dust']
    widths=design['widths'];densities=design['intensities']
    orders=design['quadrature']['orders']
    historical={(r['geo'],float(r['t']),float(r['pad']),int(r['lam'])):float(r['q112'])
                for r in csv.DictReader(open('previous_symmetric.csv'))}
    cells=[]
    for geo,s,p,f in product(geometry,design['centers'],widths,widths):
        out=[rectangle(s,(0,p),(0,f),geo=='dust',o) for o in orders]
        corner=geo=='dust' and p in [widths[0],widths[-1]] and f in [widths[0],widths[-1]]
        ref=rectangle(s,(0,p),(0,f),True,orders[-1],interval_volume) if corner else None
        for j,lam in enumerate(densities):
            a,b=out[0][j][0],out[1][j][0]
            earlier=out[1][j][1]
            prev=historical.get((geo,s,p,lam)) if p==f else None
            cells.append(dict(geo=geo,s=s,past=p,future=f,lam=lam,q80=a,R=b,early_endpoint=earlier,
               mid_endpoint=(b+earlier)/2,gap=abs(b-a),lens_diff=abs(b-ref[j][0]) if ref else '',
               historical_diff=abs(prev-b) if prev is not None else '',mass_within=abs(b-1)<=design['mass_tolerance']))
    write_csv('cells.csv',cells)
    mapping={(r['geo'],r['s'],r['past'],r['future'],r['lam']):r for r in cells}
    short,long=widths[0],widths[-1]
    def contrasts(values):
        ss,ls,sl,ll=values
        return dict(ss=ss,ls=ls,sl=sl,ll=ll,past=ls-ss,future=sl-ss,mixed=ll-ls-sl+ss,
                    past_given_long=ll-sl,future_given_long=ll-ls,asym=ls-sl,total=ll-ss)
    cons=[]
    for geo,s,lam in product(geometry,design['centers'],densities):
        rows=[mapping[geo,s,p,f,lam] for p,f in [(short,short),(long,short),(short,long),(long,long)]]
        con=contrasts([r['R'] for r in rows])
        mid=contrasts([r['mid_endpoint'] for r in rows])
        cons.append(dict(geo=geo,s=s,lam=lam,**con,asym_mid=mid['asym'],asym_endpoint=con['asym']-mid['asym']))
    write_csv('contrasts.csv',cons)
    checks={}
    for key in ('gap','lens_diff','historical_diff'):
        checks[key]=max(r[key] for r in cells if r[key]!='')
    checks['flat_exchange']=max(abs(r['R']-mapping['flat',r['s'],r['future'],r['past'],r['lam']]['R'])
                             for r in cells if r['geo']=='flat')
    checks['flat_translation']=max(abs(r['R']-mapping['flat',0.4,r['past'],r['future'],r['lam']]['R'])
                             for r in cells if r['geo']=='flat')
    # Integrate past strip, future strip and corner directly without subtracting large means.
    rects=[((short,long),(0,short)),((0,short),(short,long)),((short,long),(short,long))]
    residuals=[]
    for s in design['centers']:
        full=[rectangle(s,p,f,True,orders[-1]) for p,f in rects]
        for j,lam in enumerate(densities):
            con=next(c for c in cons if c['geo']=='dust' and c['s']==s and c['lam']==lam)
            residuals.extend(abs(full[i][j][0]-con[key]) for i,key in enumerate(['past','future','mixed']))
    checks['direct_strips']=max(residuals)
    Path('quadrature_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    assert max(checks.values())<design['quadrature']['allowed_change']
    for r in cons:
        if r['geo']=='dust':
            print(r['s'],r['lam'],*[round(r[k],7) for k in ['ss','ls','sl','ll','past','future','mixed','asym','asym_mid','asym_endpoint']])
    print(checks)

if __name__=='__main__':
    run()
