import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
rows=list(csv.DictReader(open('cells.csv')))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(6.25,2.45))
cmap=LinearSegmentedColormap.from_list('ink',['#e5f2ec','#aacfc2','#367f76','#154c52'])
for ax,s in zip(axes,[.4,.65]):
    r=[v for v in rows if v['geo']=='dust' and int(v['lam'])==100000 and float(v['s'])==s]
    z=np.array([float(v['R']) for v in r]).reshape(3,3)
    ax.imshow(z,cmap=cmap,vmin=1.,vmax=3.65,aspect='auto',interpolation='none')
    ax.set_xticks(range(3),['0,12','0,18','0,24']);ax.set_yticks(range(3),['0,12','0,18','0,24'])
    ax.set_xlabel('Zukunft F');ax.set_ylabel('Vergangenheit P')
    ax.set_title('Schnitt s = '+str(s).replace('.',','),fontsize=10)
    for i in range(3):
        for j in range(3):
            ax.text(j,i,f'{z[i,j]:.3f}'.replace('.',','),ha='center',va='center',
                    color='white' if z[i,j]>2.47 else '#102e36',fontsize=9)
    for edge in ax.spines.values(): edge.set_visible(False)
    ax.tick_params(length=0,pad=3)
fig.subplots_adjust(left=.09,bottom=.23,right=.99,top=.87,wspace=.46)
fig.savefig('raster.pdf')
