"""Cross-check of the flat boundary theorem by stable one-dimensional radial moments."""
import csv
import math
import warnings
import numpy as np
from scipy.integrate import quad, IntegrationWarning
from scipy.special import roots_legendre
from functools import cache
warnings.simplefilter('error',IntegrationWarning)
alpha=math.pi/24
@cache
def nodes(n):
    u,w=roots_legendre(n)
    return (u+1)/2,w/2

def poly(z):
    w=z*z
    return np.exp(-w)*(1+w*(-9+w*(8-4*w/3)))

def k_scaled(t,n=80):
    # lambda=1 by scaling. q=z/(sqrt(alpha)*t^2). Analytically remove zero moments.
    b=math.sqrt(alpha)*t*t
    nodes01,w=nodes(n)
    if t<2:
        # Unsubtracted compact integral with q=1-v^2, no endpoint square root.
        v=nodes01
        return -8*math.pi/math.sqrt(6)*t**4*np.dot(w,v*v*poly(b*(1-v*v)))
    # For z<b use z=b*(1-v^2) when b<15 (the square-root endpoint is then in range).
    # For larger b the exponentially small discarded tail is numerically immaterial.
    cap=min(15.,b)
    if b<=15:
        v=nodes01
        z=b*(1-v*v)
        q=z/b
        h=q/(1+v)
        integral=np.dot(w,2*b*v*poly(z)*h**3*(h-4)/8)
        z=b+(15-b)*nodes01
        q=z/b
        integral+=(15-b)*np.dot(w,poly(z)*(-1+q/2+q*q/8))
    else:
        z=cap*nodes01;q=z/b
        h=q/(1+np.sqrt(1-q))
        integral=cap*np.dot(w,poly(z)*h**3*(h-4)/8)
    return -4*math.pi/math.sqrt(6*alpha)*t*t*integral

# Scale t=lambda^(1/4)*w. A finite window has a trapezoidal weight as function of t.
def finite_rect(p,f,lam):
    a,b=sorted((p*lam**.25,f*lam**.25))
    edges=sorted(set([0.,a,b,a+b]+[v for v in [2.,math.sqrt(15/math.sqrt(alpha))] if v<a+b]))
    total=0.
    for left,right in zip(edges,edges[1:]):
        total+=quad(lambda t:max(0,min(t,a)-max(0,t-b))*k_scaled(t),left,right,
                    epsrel=1e-10,epsabs=8e-11,limit=120)[0]
    return total
def leading(p,f,lam):
    return 2*math.sqrt(6)/math.pi/math.sqrt(lam)*(1/p**2+1/f**2-1/(p+f)**2)

if __name__=='__main__':
    rows=[]
    errors=[]
    ref={(float(r['past']),float(r['future']),int(r['lam'])):float(r['R'])
        for r in csv.DictReader(open('cells.csv')) if r['geo']=='flat' and float(r['s'])==.4}
    for p,f in [(.12,.12),(.12,.24),(.24,.24)]:
        for lam in (10**3,10**4,10**5,10**6,10**7,10**8,10**9):
            r=finite_rect(p,f,lam)
            theory=leading(p,f,lam)
            rows.append(dict(p=p,f=f,lam=lam,R=r,leading_bias=theory,bias_over_leading=(r-1)/theory))
            if (p,f,lam) in ref: errors.append(abs(r-ref[p,f,lam]))
    with open('flat_limit.csv','w',newline='') as file:
        w=csv.DictWriter(file,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    z1=math.sqrt(15/math.sqrt(alpha))
    norm=sum(quad(lambda t:t*k_scaled(t),l,r,epsrel=1e-10,epsabs=1e-10)[0]
             for l,r in [(0.,2.),(2.,z1),(z1,np.inf)])
    print('Full flat normalization',norm,'max grid discrepancy',max(errors))
    assert abs(norm-1)<1e-8 and max(errors)<1e-6
    for r in rows:
        if r['p']==.12 and r['f']==.24 and r['lam']>=1e6: print(r)
