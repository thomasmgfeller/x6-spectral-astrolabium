"""Direct exact oracle and replay of fixed *historical* controls."""
from fractions import Fraction as F
from pathlib import Path
import csv,io,json,math,tempfile,zipfile
import numpy as np
from pair_core import (HERE,UNIT,H,EARLY,NORM,initialise,bins,before,category,physical,
                       weights,score,clouds,support,need,mass,MU,BoundaryReview)

def exact_oracle(kernel):
    # Exactly null, nextafter to each side, equal times, shuffled equal-time points.
    q=np.array([0.,.25,.25,.5, .75,.75, .875])
    xyz=np.zeros((len(q),3));xyz[1,0]=.25;xyz[2,0]=np.nextafter(.25,0.)
    xyz[3,0]=np.nextafter(.5,1.);xyz[4,0]=.25;xyz[5,1]=.5
    ids=np.flatnonzero(q>EARLY).astype(np.int32)
    totals=0;fallbacks=0
    rng=np.random.default_rng(1917)
    examples=[(q,xyz,ids)]
    for _ in range(5):
        q=np.sort(rng.integers(1,30,20)/32)
        pos=rng.integers(-7,8,(len(q),3))/32.
        examples.append((q,pos,np.flatnonzero(q>EARLY).astype(np.int32)))
    for q,pos,ids in examples:
        relation=[[before(q,pos,i,j) for j in range(len(q))] for i in range(len(q))]
        for J in (1,3,7):
            hist,ds,checks=bins(kernel,q,pos,ids,J)
            truth=np.zeros_like(hist); ticks=np.rint(H*(q*(1-q/3+q*q/27))).astype(np.int64)
            times=tuple(physical(F(float(e))) for e in q)
            for i in range(len(q)):need(abs(times[i]*H-int(ticks[i]))<1,'time envelope')
            sums=np.zeros_like(hist)
            for t,x in enumerate(ids):
                for y in range(len(q)):
                    if times[y]>=F(47,100) or not relation[y][x]: continue
                    k=sum(relation[y][z] and relation[z][x] for z in range(len(q)))
                    if k<J:
                        truth[t,k]+=1;sums[t,k]+=ticks[x]-ticks[y]
            need(np.array_equal(truth,hist) and np.array_equal(sums,ds),'direct all-triples mismatch')
            totals+=1;fallbacks+=checks
    need(fallbacks>0,'exact fallback was not exercised')
    return dict(cases=totals,exact_fallback_calls=fallbacks)

def exact_chain(kernel):
    # Analytic order y<z<x on a monotone timelike chain, including layers beyond both cutoffs.
    q=np.arange(1,414)/512.; pos=np.zeros((len(q),3))
    ids=np.asarray([len(q)-2,len(q)-1],dtype=np.int32)
    ts=[physical(F(float(e))) for e in q]
    checks=[]
    for lam in (1200000,6000000):
        p=F(MU,lam); J=weights(lam)[0]; count_tail=0
        total=F(0)
        for x0 in ids:
            x=int(x0)
            for y in range(x):
                if ts[y]>=F(47,100):continue
                k=x-y-1; count_tail+=k>=J
                w=sum(c*math.comb(k,j)*p**j*(1-p)**(k-j) for j,c in enumerate((1,-9,16,-8)) if j<=k)
                total+=w*(ts[x]-ts[y])/(1-ts[x])**2
        unscaled=-2*p*p*total/NORM
        a,b=[F(m,UNIT) for m in mass(kernel,q,pos,ids,lam)['interval']]
        squared=unscaled*abs(unscaled)/(6*MU)
        need(count_tail>0 and a*abs(a)<=squared<=b*abs(b),'untruncated exact oracle')
        checks.append(dict(density=lam,omitted_pairs=count_tail,interval_width=float(b-a)))
    return checks

def main():
    with tempfile.TemporaryDirectory() as folder:
        geom,kernel=initialise(Path(folder))
        direct=exact_oracle(kernel)
        with zipfile.ZipFile(HERE/'input_model.zip') as src:
            old=list(csv.DictReader(io.StringIO(src.read('extension.csv').decode())))
            small={int(r['run']):r for r in csv.DictReader(io.StringIO(src.read('caps.csv').decode()))
                   if r['j']=='1' and r['lam']=='6000000'}
        data=[]
        for large,idx in [(True,0),(True,1),(False,0),(False,1)]:
            lam,seed=(1200000,20261102861) if large else (6000000,20261102751)
            c=clouds(geom,seed,idx,lam,large)
            row=score(kernel,c,lam);origin=old[idx] if large else small[idx]
            keys=('a','b') if large else ('sm0','sm1')
            numbers=[F(origin[k])/NORM for k in keys]
            for n,ref in zip(row['parts'],numbers):
                a,b=n['interval'];need(F(a,UNIT)<=ref<=F(b,UNIT),'archived point outside interval')
            label='separated' if abs(numbers[0]-numbers[1])>F(1,5) else 'within'
            need(row['category']==label,'archived comparison mismatch')
            row.update(case='large_low' if large else 'small_high',index=idx)
            data.append(row)
        # Endpoints around 1/5: bracket touches or crosses it, or is strictly beyond.
        k=UNIT//5
        need(category([k,k+1],[0,0])=='ambiguous' and category([k+1,k+1],[0,0])=='separated'
             and category([-k,-k],[0,0])=='within','threshold edges')
        chain=exact_chain(kernel)
        try:
            support((np.array([.5]),np.zeros((1,3))),[(np.array([.7]),np.array([[.9,.9,.9]]))],True,6000000)
        except BoundaryReview:
            pass
        else:raise ValueError('invalid cap membership accepted')
        return dict(oracle=direct,chain=chain,history=data,scope='no target IDs used')
if __name__=='__main__':print(json.dumps(main(),indent=2))
