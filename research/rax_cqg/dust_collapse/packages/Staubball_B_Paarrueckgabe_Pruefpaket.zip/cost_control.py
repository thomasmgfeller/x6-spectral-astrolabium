"""One endpoint per time quartile on each archived cost fixture (no target IDs)."""
import ctypes,json,os,subprocess,tempfile,time,zipfile
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer
from pair_core import HERE,MU,EARLY,H,CALLBACK,before,initialise,clouds,weights,need

def run(tmp):
    geom,cert=initialise(tmp)
    with zipfile.ZipFile(HERE/'input_model.zip') as z:
        (tmp/'old.cpp').write_bytes(z.read('smooth_layers.cpp'))
    out=tmp/'old.so'
    subprocess.run(['g++','-O3','-march=native','-fopenmp-simd','-ffp-contract=off','-std=c++17',
                    '-shared','-fPIC',str(tmp/'old.cpp'),'-o',str(out)],check=True)
    old=ctypes.CDLL(str(out)).endpoints
    arr=ndpointer(dtype='float64',flags='C_CONTIGUOUS')
    i=ctypes.c_int
    old.argtypes=[i,arr,arr,arr,ndpointer(dtype='int32',flags='C_CONTIGUOUS'),i,ctypes.c_double,arr,i,arr]
    old.restype=None
    seed=202611041602;lam=6000000
    J,ws,den,_=weights(lam);wf=np.array([w/den for w in ws])
    result=[]
    for idx in range(2):
        groups=[]
        start=time.process_time()
        data=clouds(geom,seed,idx,lam)
        setup=time.process_time()-start
        rng=np.random.default_rng(np.random.SeedSequence([seed,1,lam,idx,97]))
        for q,xyz,ids in data:
            ticks=np.rint(H*(q*(1-q/3+q*q/27))).astype(np.int64)
            ts=geom.time_of_eta(q)
            @CALLBACK
            def exact(a,b):return int(before(q,xyz,a,b))
            for j,g in enumerate(np.array_split(ids,4)):
                # Same draw as the archived two-per-quartile cost setup; use the first draw.
                selected=np.array(rng.choice(g,2,replace=False)[:1],dtype=np.int32)
                sums=np.zeros((1,J),np.int64);counts=np.zeros_like(sums);fallback=np.zeros(1,np.int64)
                dst=np.zeros(2)
                def checked():
                    return cert(len(q),q,xyz,ticks,EARLY,selected,1,J,exact,counts,sums,fallback)
                def original(): old(len(q),ts,q,xyz,selected,1,.47,wf,J,dst)
                timings={}
                methods=[('original',original),('interval',checked)]
                if (j+idx)%2:methods.reverse()
                for name,func in methods:
                    start=time.process_time();status=func();timings[name]=time.process_time()-start
                    if name=='interval':need(status==0,'kernel failure')
                groups.append(dict(population=len(g),selected=1,**timings))
        estimates={name:(setup+sum(g[name]*g['population'] for g in groups))*149/3600
                   for name in ('original','interval')}
        result.append(dict(fixture=idx,groups=groups,shared_generation_cpu_seconds=setup,
                           projected_core_hours_for_149=estimates))
        print('timing fixture',idx,'complete',file=__import__('sys').stderr,flush=True)
    return dict(results=result,sampling='One selected endpoint per time quartile and interior; excludes compiler, IO, rational postprocessing, and independent replay. Two extrapolations only.',
                cpu=next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')))
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as d: print(json.dumps(run(Path(d)),indent=2))
