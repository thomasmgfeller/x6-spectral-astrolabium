# Fenster B · Einzelrückgaben für den festen Paartest

Der dreiseitige Bericht beschreibt das Rechenverfahren, seine Grenzen und die Kostenmessung. Der Zielplan und das Modellarchiv sind die unveränderten Referenzen aus PR 207. Alle Befehle laufen lokal. Für das Projekt gilt CHF 0. Dieses Paket enthält ausschliesslich geprüfte Entwicklungs- und Kontrollresultate. Keine der 149 Zielziehungen wurde hier verwendet.

## Voraussetzungen und Kontrollen

Getestet unter Linux/x86-64 mit Python 3.12.14, NumPy 2.3.5 und GNU g++ 13.3.0. Benötigt werden eine beschreibbare lokale Platte, Bash und ein C++17-Compiler mit OpenMP-SIMD. SciPy 1.17.0 ist die Vergleichsversion des Vorgängerpakets; der neue Kontrollkern importiert nur NumPy und die Standardbibliothek. Für das lokale Register wird das in Python mitgelieferte SQLite verwendet.

Im entpackten Verzeichnis ausführen. Die Standardeinstellung von Python mit aktivierten numerischen Prüfungen verwenden.

```sh
sha256sum -c SHA256SUMS
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python3 controls.py > meine-kontrollen.json
python3 protocol_controls.py > mein-protokolltest.json
```

`controls.py` enthält historische Paare und kleine, vollständig nachzählbare Ordnungen. Vergleichen Sie Status, Intervallgrenzen und Geometriekontrollen mit `control_results.json`. Unterschiedliche Bibliotheks- oder Systemversionen können zu abweichenden generierten Binärkoordinaten führen. Bitte solche Fälle mit den beiden Hashwerten und Softwareversionen melden. Der Ablauf bricht bei fehlerhaften Kontrollmassen ab. `protocol_controls.py` untersucht nur eigens konstruierte, temporäre Einträge für die beiden Entscheidungsgrenzen 23 und 24. `cost_control.py` ist optional und verwendet nur den veröffentlichten Kosten-Startbereich; der Vergleich mit `cost_results.json` betrifft die Grössenordnung der Laufzeit.

## Ein später beauftragtes Paar berechnen

Die Kennungen laufen von 0 bis 148. Pro Rechner wird nur die tatsächlich vereinbarte Kennung übergeben. Das folgende Beispiel verwendet die Shell-Variable `PAIR_ID`; sie ist bewusst nicht vorbelegt. Erst bei verfügbarem gespendetem Budget eine Kennung zuteilen.

```sh
python3 run_pairs.py run --id "${PAIR_ID:?zuerst die vereinbarte Kennung setzen}" --out rueckgaben
```

Der Name enthält die dreistellig formatierte Kennung. Die JSON-Datei als unveränderte Datei oder ZIP weitergeben, zusammen mit den verwendeten Versionen. Ihre grossen Ganzzahlen sind absichtliche Festkommawerte. Der Nenner ist 2^64. Ein Lauf schreibt atomar und überschreibt bei einem Konflikt keine frühere Rückgabe. Nach einem technischen Fehler wird dieselbe Kennung wiederholt. Numerisch ungeklärte, reproduzierbare Kegelzuordnungen können als eigener negativer Zählstatus eingetragen werden. Fehlgeschlagene und fehlende Läufe bleiben bis zur Klärung offen.

## Eine Rückgabe prüfen und einmalig verbuchen

Für die Prüfstelle eine eigene lokale Datenbank verwenden. Eingehende SQLite-Dateien werden nicht als vertrauenswürdige Register verwendet. `verify` akzeptiert die JSON-Datei erst nach einer vollständig neu berechneten, identischen Rückgabe. Eine bereits bestätigte identische Datei kostet bei erneutem Import keine weitere Rechnung. Eine fremde Kennung, ein abweichender Koordinaten-Hash oder eine manipulierte Ausgabe dürfen nicht durch Überschreiben aufgelöst werden.

```sh
python3 run_pairs.py verify "${PAIR_JSON:?Pfad zur erhaltenen JSON-Datei setzen}" --db bestaetigt.sqlite
python3 run_pairs.py final --db bestaetigt.sqlite
```

Der Abschluss zeigt bei unvollständigem Bestand nur Umfang und fehlende Kennungen. Ab 149 verifizierten Paaren meldet er die Zahlen der Klassifikationen. Nur `separated` zählt positiv; mindestens 24 sind für `THRESHOLD_MET` erforderlich. Dieser Status bezieht sich auf die endlichen erzeugten Daten. Die Übertragung auf das ideale Poisson-Modell benötigt die im Bericht diskutierten Annahmen zum Generator. Ein Replay auf demselben Computer prüft die Reproduzierbarkeit, eine zweite Implementierung oder eine externe Reproduktion ist eine weitergehende Prüfung.

## Numerische Konventionen

- Geometrie. Die C++-Auswertung berechnet die strikte Minkowski-Relation direkt in den ursprünglichen Koordinaten. Bei gerundeter Marge im Bereich ±2^-44 übernimmt ein rationaler Vergleich der gespeicherten Binärzahlen. Es gibt keinen toleranzbasierten Ausschluss eines echt zeitartigen oder lichtartigen Paares. Die Reihenfolge bei gleichen Zeiten ändert keine strikte Relation.
- Gebiet. Die konformen Grenzzeiten der archivierten Geometrie werden durch rationale Potenzprüfungen eingeschlossen. Zur Bereichsprüfung der zurückbehaltenen Punkte wird die Hülle um 2^-40 nach innen verkleinert und die Zugehörigkeit zum Aussengebiet entsprechend abgesichert. Die Intervallbreiten der als Float benutzten Grenzen liegen unter 2^-50. Im unterstützten Bereich betragen die Koordinatenbeträge höchstens eins und die verglichenen Radien höchstens zwei. Der Puffer deckt die Endpunkt- und Rechenfehler dieser Zeit- und Quadrattests ab. Unklare Zugehörigkeiten dürfen nie als positives Paar zählen.
- Schichten. Die diskrete Zeiteinheit beträgt 2^-40. Bei n < 2^21 und Zeitdifferenzen von höchstens einer Zeiteinheit des physikalischen Modells passt die Summe der Ticks pro Schicht in einen vorzeichenbehafteten 64-Bit-Zähler. Python verwendet anschliessend beliebig grosse Ganzzahlen. Normierung und Restschranke sind im Code festgelegt.
- Generator. Das Mitlesen der gespeicherten Binärwerte liefert keine Fehlereinschliessung für jede verworfene oder ursprünglich aus kontinuierlichen Zufallszahlen erzeugte Raumzeitkoordinate. Deshalb gibt das Register automatisch nur einen Status für endliche Eingaben aus.
- Aufwand. Die bisherigen seriellen Zeitmessungen in Issue 206 gelten für das frühere Skript. Die neue Vergleichsmessung umfasst 16 ausgewählte Endpunkte aus zwei Kostenfällen. Für 149 Paare wurden rund 26 Kernstunden für den Kern geschätzt, plus etwa denselben Aufwand für das hier vorgesehene vollständige zweite Nachrechnen und zusätzlicher Aufwand für Nachsummieren und Ein-/Ausgabe. Die beiden technischen Hochrechnungen sind keine garantierten Laufzeiten.

[Festgelegter Plan, PR 207](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/207) · [Community-Zeitvergleich](https://github.com/thomasmgfeller/x6-spectral-astrolabium/issues/206) · [Separate Einzelordnungen A und B](https://github.com/thomasmgfeller/x6-spectral-astrolabium/issues/192)
