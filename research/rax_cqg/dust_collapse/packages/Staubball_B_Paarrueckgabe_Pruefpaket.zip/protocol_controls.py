"""Isolated, in-memory protocol tests. No generator or target namespace is sampled."""
import copy, json, sqlite3, tempfile
from unittest.mock import patch
from pathlib import Path
from run_pairs import algorithm,canonical,accept,final,initialise_db,publish,load_return
from pair_core import PLAN_HASH,TARGET_SEED,UNIT,need

def dummy(i,cut):
    vals=[{'interval':[0,0],'targets':1,'events':4,'exact_predicates':0,
           'cloud_sha256':'a'*64} for _ in range(2)]
    if i<cut:vals[0]['interval']=[UNIT,UNIT]
    r=dict(format='x6.dust.pair/1',index=i,algorithm=algorithm(),design_sha256=PLAN_HASH,
           seed_namespace=TARGET_SEED,scale=UNIT,parts=vals,category='separated' if i<cut else 'within')
    if i==140:
        k=UNIT//5
        r['parts'][0]['interval']=[k,k+1];r['category']='ambiguous'
    elif i==141:
        del r['parts']
        r.update(category='boundary_review',reason='synthetic ambiguous label',clouds=['c'*64,'d'*64])
    return r

def fails(f):
    try:f()
    except ValueError:return
    raise RuntimeError('an invalid return was accepted')

def main():
    labels=[]
    for cut in (23,24):
        db=sqlite3.connect(':memory:');initialise_db(db)
        replay=lambda i:dummy(i,cut)
        need(final(db)['status']=='INCOMPLETE','empty')
        a=replay(0)
        need(accept(db,a,replay)=='replayed and verified','first')
        need(accept(db,a,lambda i: (_ for _ in ()).throw(RuntimeError()))=='already verified','retry')
        bad=copy.deepcopy(a);bad['parts'][0]['events']+=1
        fails(lambda:accept(db,bad,replay))
        fake=replay(1);fake['parts'][0]['cloud_sha256']='e'*64
        fails(lambda:accept(db,fake,replay))
        wrong=replay(1);wrong['seed_namespace']=202611041602
        fails(lambda:accept(db,wrong,replay))
        invalid=replay(1);invalid['category']='within'
        fails(lambda:accept(db,invalid,replay))
        for i in range(1,148):accept(db,replay(i),replay)
        incomplete=final(db)
        need(incomplete==dict(status='INCOMPLETE',verified=148,missing=[148]),'no interim release')
        accept(db,replay(148),replay)
        outcome=final(db);need(outcome['counts']['separated']==cut and outcome['counts']['ambiguous']==1 and
                              outcome['counts']['boundary_review']==1,'final counts')
        need(outcome['finite_input_outcome']==('THRESHOLD_MET' if cut==24 else 'UNRESOLVED'),'cutoff')
        labels.append(outcome['finite_input_outcome'])
        db.execute("UPDATE verified SET digest='invalid' WHERE id=0")
        fails(lambda:final(db));db.close()
    with tempfile.TemporaryDirectory() as d:
        path=Path(d)/'test.json'
        with patch('run_pairs.os.fsync',side_effect=OSError('simulated write failure')):
            try:publish(path,a)
            except OSError:pass
            else:raise AssertionError('write failure ignored')
        need(not path.exists() and not any(Path(d).iterdir()),'failed output leaked')
        publish(path,a);publish(path,a);fails(lambda:publish(path,bad))
        need(load_return(path)==a,'atomic publish')
        path.write_text('{"index":0,"index":1}')
        fails(lambda:load_return(path))
    return dict(synthetic_ledger_boundaries=labels,missing_id_held=True,duplicate_idempotent=True,
                conflict_rejected=True,replay_tampering_rejected=True,wrong_seed_rejected=True,
                wrong_category_rejected=True,damaged_ledger_rejected=True,duplicate_json_key_rejected=True,
                partial_file_not_published=True,scope='In-memory and temporary fixtures only.')
if __name__=='__main__':print(json.dumps(main(),indent=2))
