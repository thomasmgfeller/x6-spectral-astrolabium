"""Exact input predicates and conservative mass bounds for archived binary64 clouds."""
import ctypes
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import importlib.util
import math
from pathlib import Path
import subprocess
import zipfile

import numpy as np
from numpy.ctypeslib import ndpointer

HERE=Path(__file__).resolve().parent
ARCHIVE_HASH='293abfb2a6854b1a33982d6accc5354838b0573fc2958b9e7212599ba78fe585'
PLAN_HASH='dccee08ae93ba0396c1bcd0df5a192e0b87f3058a459156f72fb282c31ec1dcf'
H=2**40
UNIT=2**64
NORM=F('1.2871411680612763')
NORM_PAD=F(1,10**15)
TARGET_SEED=202611041701
MU=600000
CALLBACK=ctypes.CFUNCTYPE(ctypes.c_int,ctypes.c_int,ctypes.c_int)

def need(ok,reason):
    if not ok: raise ValueError(reason)

def initialise(tmp):
    archive=HERE/'input_model.zip'
    need(hashlib.sha256(archive.read_bytes()).hexdigest()==ARCHIVE_HASH,'model archive hash')
    need(hashlib.sha256((HERE/'pair_design.json').read_bytes()).hexdigest()==PLAN_HASH,'design hash')
    with zipfile.ZipFile(archive) as arc:
        p=tmp/'cap_geometry.py'
        p.write_bytes(arc.read('cap_geometry.py'))
    spec=importlib.util.spec_from_file_location('frozen_cap_geometry',p)
    geom=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(geom)
    lib=tmp/'kernel.so'
    subprocess.run(['g++','-O3','-march=native','-std=c++17','-fPIC','-shared','-fopenmp-simd',
                    '-fno-fast-math','-ffp-contract=off',str(HERE/'kernel.cpp'),'-o',str(lib)],check=True)
    kernel=ctypes.CDLL(str(lib)).histogram
    def arr(t):return ndpointer(dtype=t,flags='C_CONTIGUOUS')
    i=ctypes.c_int
    kernel.argtypes=[i,arr('float64'),arr('float64'),arr('int64'),ctypes.c_double,arr('int32'),i,i,
                     CALLBACK,arr('int64'),arr('int64'),arr('int64')]
    kernel.restype=i
    return geom,kernel

def physical(q):
    return 1-(1-q/3)**3

def last_early():
    bound=3*(1-(1-.47)**(1/3))
    while physical(F(bound))>=F(47,100): bound=math.nextafter(bound,-math.inf)
    while physical(F(math.nextafter(bound,math.inf)))<F(47,100): bound=math.nextafter(bound,math.inf)
    return bound
EARLY=last_early()

def before(q,xyz,a,b):
    dt=F(float(q[b]))-F(float(q[a]))
    return dt>0 and dt*dt>sum((F(float(xyz[b,i]))-F(float(xyz[a,i])))**2 for i in range(3))

@lru_cache(maxsize=None)
def weights(lam):
    den=lam//MU
    need(lam%MU==0 and den in (2,10),'unsupported density')
    J={2:63,10:403}[den]
    c=(1,-9,16,-8)
    common=den**(J-1)
    def term(k,i):
        return math.comb(k,i)*(den-1)**(k-i)
    ws=[sum(c[i]*term(k,i) for i in range(min(3,k)+1))*den**(J-1-k) for k in range(J)]
    eps=16*F(sum(term(J,i) for i in range(4)),den**J)
    need(eps<F(1,10**13),'cutoff error')
    return J,ws,common,eps

def ceil(x):return -((-x.numerator)//x.denominator)
def enclosing_int(x,y,scale):
    return (x*scale).__floor__(),ceil(y*scale)

def cloud_hash(q,xyz,ids):
    h=hashlib.sha256()
    for array,dtype in [(q,'<f8'),(xyz,'<f8'),(ids,'<i4')]:
        h.update(len(array).to_bytes(8,'big'))
        h.update(np.asarray(array,dtype=dtype).tobytes('C'))
    return h.hexdigest()

def encode(ext,cap):
    q=np.concatenate((ext[0],cap[0]))
    ordered=np.argsort(q,kind='stable')
    return q[ordered],np.concatenate((ext[1],cap[1]))[ordered],np.flatnonzero(ordered>=len(ext[0])).astype(np.int32)

def bins(kernel,q,xyz,ids,J):
    n=len(q)
    need(q.dtype==np.float64 and xyz.dtype==np.float64 and xyz.shape==(n,3),'input arrays')
    need(n < 2**21 and len(ids)<4096,'outside supported work size')
    need(np.all(np.isfinite(q)) and np.all(np.isfinite(xyz)) and np.all(np.abs(xyz)<=1)
         and np.all((q>=0)&(q<=1)) and np.all(q[1:]>=q[:-1]),'coordinate or order range')
    need(ids.ndim==1 and np.all((ids>=0)&(ids<n)) and np.all(ids[1:]>ids[:-1]),'invalid target IDs')
    # On 0<=q<=1 the polynomial evaluation differs from the exact T(q)
    # by < 2^-48 in binary64. With nearest integer rounding, error is < 1 tick.
    ticks=np.rint(H*(q*(1-q/3+q*q/27))).astype(np.int64)
    counts=np.zeros((len(ids),J),np.int64);sums=np.zeros_like(counts)
    calls=np.zeros(1,np.int64);failure=[]
    @CALLBACK
    def exact(a,b):
        try: return int(before(q,xyz,a,b))
        except Exception as e:
            failure.append(str(e));return 0
    status=kernel(n,np.ascontiguousarray(q),np.ascontiguousarray(xyz),ticks,EARLY,
                  np.ascontiguousarray(ids,dtype=np.int32),len(ids),J,exact,counts,sums,calls)
    need(status==0 and not failure,'geometry evaluation failed')
    return counts,sums,int(calls[0])

def mass(kernel,q,xyz,ids,lam):
    J,ws,common,eps=weights(lam)
    counts,sums,calls=bins(kernel,q,xyz,ids,J)
    early=int(np.count_nonzero(q<=EARLY))
    low=0;high=0
    for i,x in enumerate(ids):
        active=np.flatnonzero(counts[i])
        total=sum(ws[k]*int(sums[i,k]) for k in active)
        abs_weight=sum(abs(ws[k])*int(counts[i,k]) for k in active)
        # All true T(q) are in [0,1]. The remaining (outside or truncated)
        # early endpoints, at most this many, cost <= eps per endpoint.
        tail=eps*(early-int(counts[i].sum()))
        mid=F(total,H*common);err=F(2*abs_weight,H*common)+tail
        sigma=(1-F(float(q[x]))/3)**-6
        a,b=enclosing_int((mid-err)*sigma,(mid+err)*sigma,UNIT)
        low+=a;high+=b
    root=math.isqrt(6*MU*UNIT**2)
    fac=2*F(MU,lam)**2*UNIT
    scales=(-fac/(root*(NORM-NORM_PAD)),-fac/((root+1)*(NORM+NORM_PAD)))
    values=[F(v,UNIT)*c for v in (low,high) for c in scales]
    a,b=enclosing_int(min(values),max(values),UNIT)
    return dict(interval=[a,b],cloud_sha256=cloud_hash(q,xyz,ids),events=len(q),
                targets=len(ids),exact_predicates=calls)

def category(left,right):
    dl=left[0]-right[1];du=left[1]-right[0]
    if 5*max(dl,-du)>UNIT:return 'separated'
    if 5*max(abs(dl),abs(du))<=UNIT:return 'within'
    return 'ambiguous'

def root_bounds(x,k):
    """An exact rational bracket of a positive real root."""
    den=2**80; a=0; b=den
    value=x*den**k
    while b**k<value: b*=2
    while b-a>1:
        m=(a+b)//2
        if m**k<=value: a=m
        else: b=m
    return F(a,den),F(b,den)

def eta_bounds(tlo,thi):
    a,_=root_bounds(1-thi,3);_,b=root_bounds(1-tlo,3)
    return 3*(1-b),3*(1-a)

@lru_cache(maxsize=None)
def support_edges(large,lam):
    density=1200000 if large else lam
    coef=F(11,4) if large else F(3,2)
    a,b=root_bounds(F(density),4)
    top=F(58,100); start=F(23,100)
    result=[]
    for lo,hi in (eta_bounds(start,start),eta_bounds(top,top),eta_bounds(top-coef/a,top-coef/b)):
        m=float((lo+hi)/2)
        need(max(abs(F(m)-lo),abs(F(m)-hi))<F(1,2**50),'support bracket')
        result.append(m)
    return result

class BoundaryReview(ValueError):
    pass

def safe_boundary(ok,message):
    if not ok:raise BoundaryReview(message)

def support(ext,caps,large,lam):
    q0,q1,qb=support_edges(large,lam)
    guard=2.**(-40)
    for index,(q,pos) in enumerate([ext,*caps]):
        need(np.all(np.isfinite(q)) and np.all(np.isfinite(pos)) and np.all(np.abs(pos)<=1),
             'invalid support coordinates')
        safe_boundary(np.all(q>q0+guard) and np.all(q<q1-guard),'unresolved outer time boundary')
        radii=np.sum(pos*pos,axis=1)
        if index==0:
            outer=(q1-qb)+(q1-q)
            safe_boundary(np.all(radii<outer*outer-guard),'unresolved exterior support')
            safe_boundary(np.all((q<qb-guard) | (radii>np.maximum(q-qb,0)**2+guard)),
                 'ambiguous exterior/cap label')
        else:
            safe_boundary(np.all(q>qb+guard) and np.all(radii<(q-qb)**2-guard),'ambiguous cap label')

def clouds(geom,seed,index,lam,large=True):
    rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed,1,lam,index])))
    height=2.75*1200000**(-.25) if large else 1.5*lam**(-.25)
    s=.47; end=s+.11
    q0,q1,qb=geom.eta(s-.24),geom.eta(end),geom.eta(end-height)
    ext=geom.draw_exterior(rng,q0,qb,q1,q1-qb,lam)
    # Generate both interiors before scoring. External point set is identical.
    caps=[geom.draw_cap(rng,qb,q1,lam) for _ in range(2)]
    data=[encode(ext,cap) for cap in caps]
    try:
        support(ext,caps,large,lam)
    except BoundaryReview as problem:
        problem.digests=[cloud_hash(*d) for d in data]
        raise
    return data

def score(kernel,clouds,lam):
    vals=[mass(kernel,*data,lam) for data in clouds]
    return dict(parts=vals,category=category(*(p['interval'] for p in vals)))

def target_pair(geom,kernel,index):
    need(type(index) is int and 0<=index<149,'invalid pair ID')
    # Pin the NumPy version for generator replay; cross-platform differences
    # in generated coordinates are caught by both digests during verification.
    need(np.__version__=='2.3.5','target replay requires NumPy 2.3.5')
    try:
        result=score(kernel,clouds(geom,TARGET_SEED,index,6000000),6000000)
    except BoundaryReview as problem:
        result=dict(category='boundary_review',reason=str(problem),clouds=problem.digests)
    return dict(format='x6.dust.pair/1',index=index,seed_namespace=TARGET_SEED,
                design_sha256=PLAN_HASH,scale=UNIT,**result)
