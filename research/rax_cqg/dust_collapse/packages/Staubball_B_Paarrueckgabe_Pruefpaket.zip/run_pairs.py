"""Individual donated computations; independent replay and final, fixed-sample classification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile

from pair_core import HERE,PLAN_HASH,TARGET_SEED,UNIT,category,initialise,need,target_pair

def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def digest(buf):return hashlib.sha256(buf).hexdigest()

def algorithm():
    return digest(canonical({n:digest((HERE/n).read_bytes()) for n in
                             ('run_pairs.py','pair_core.py','kernel.cpp','pair_design.json')}))

def validate(record):
    need(type(record) is dict and type(record.get('index')) is int and 0<=record['index']<149,'target ID')
    need(record.get('format')=='x6.dust.pair/1' and record.get('algorithm')==algorithm() and
         record.get('design_sha256')==PLAN_HASH and record.get('seed_namespace')==TARGET_SEED
         and record.get('scale')==UNIT,'not this target protocol')
    status=record.get('category')
    if status=='boundary_review':
        need(isinstance(record.get('reason'),str) and len(record.get('clouds',[]))==2,'boundary evidence')
    else:
        parts=record['parts']
        need(len(parts)==2,'pair required')
        for part in parts:
            a,b=part['interval']
            need(type(a) is int and type(b) is int and a<=b,'invalid interval')
            need(len(part['cloud_sha256'])==64,'cloud digest')
        need(status==category(*(v['interval'] for v in parts)),'incorrect classification')
    return record['index']

def replay(index):
    with tempfile.TemporaryDirectory() as d:
        geom,kernel=initialise(Path(d))
        obj=target_pair(geom,kernel,index)
        obj['algorithm']=algorithm()
        return obj

def publish(path,record):
    data=canonical(record)+b'\n'
    path.parent.mkdir(exist_ok=True,parents=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:
        tmp=Path(f.name)
        try:
            f.write(data);f.flush();os.fsync(f.fileno())
        except BaseException:
            tmp.unlink(missing_ok=True);raise
    try:
        try: os.link(tmp,path)
        except FileExistsError:need(path.read_bytes()==data,'conflicting result file; retained earlier version')
    finally:tmp.unlink(missing_ok=True)

def initialise_db(db):
    db.execute('CREATE TABLE IF NOT EXISTS verified (id INTEGER PRIMARY KEY, digest TEXT NOT NULL, record BLOB NOT NULL)')

def accept(db,record,replay_one):
    i=validate(record); raw=canonical(record); sha=digest(raw)
    existing=db.execute('SELECT digest,record FROM verified WHERE id=?',(i,)).fetchone()
    if existing:
        need(existing==(sha,raw),'conflicting return for verified ID')
        return 'already verified'
    expected=canonical(replay_one(i))
    need(expected==raw,'independent replay differs; no entry added')
    with db:
        db.execute('INSERT OR IGNORE INTO verified(id,digest,record) VALUES(?,?,?)',(i,sha,raw))
        need(db.execute('SELECT digest,record FROM verified WHERE id=?',(i,)).fetchone()==(sha,raw),
             'concurrent conflicting return')
    return 'replayed and verified'

def final(db):
    rows=list(db.execute('SELECT id,digest,record FROM verified ORDER BY id'))
    ids=[r[0] for r in rows]
    if ids!=list(range(149)):
        return dict(status='INCOMPLETE',verified=len(ids),missing=sorted(set(range(149))-set(ids)))
    totals=dict(separated=0,within=0,ambiguous=0,boundary_review=0)
    for i,sha,raw in rows:
        record=json.loads(raw)
        need(digest(raw)==sha and canonical(record)==raw and validate(record)==i,'invalid stored record')
        totals[record['category']]+=1
    return dict(status='COMPLETE',counts=totals,threshold=24,
                finite_input_outcome='THRESHOLD_MET' if totals['separated']>=24 else 'UNRESOLVED',
                physical_claim='Ideal continuous Poisson interpretation requires the sampling assumptions and generator validation.')

def load_return(path):
    need(path.stat().st_size<=100_000,'oversize return')
    def unique(pairs):
        result={}
        for key,val in pairs:
            need(key not in result,'duplicate JSON field');result[key]=val
        return result
    return json.loads(path.read_bytes(),object_pairs_hook=unique)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='mode',required=True)
    single=sub.add_parser('run');single.add_argument('--id',type=int,choices=range(149),required=True,metavar='0..148')
    single.add_argument('--out',required=True,type=Path)
    verify=sub.add_parser('verify');verify.add_argument('return_file',type=Path)
    verify.add_argument('--db',type=Path,required=True)
    close=sub.add_parser('final');close.add_argument('--db',type=Path,required=True)
    a=p.parse_args()
    if a.mode=='run':
        record=replay(a.id); validate(record); publish(a.out/('pair-%03d.json'%a.id),record)
        print('Result saved for ID',a.id)
    else:
        with sqlite3.connect(a.db,timeout=60) as db:
            initialise_db(db)
            print(accept(db,load_return(a.return_file),replay) if a.mode=='verify' else json.dumps(final(db),indent=2))
