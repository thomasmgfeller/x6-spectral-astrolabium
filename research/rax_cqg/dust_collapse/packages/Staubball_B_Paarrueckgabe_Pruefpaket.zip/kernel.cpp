// Strict Minkowski comparisons on the supplied binary64 coordinates.
#include <algorithm>
#include <array>
#include <cfenv>
#include <cmath>
#include <cstdint>
#include <limits>
#include <vector>

using Exact = int (*)(int, int);
static_assert(std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::digits == 53);
constexpr double guard = 0x1p-44;

// For all input coordinates of magnitude <=1, the absolute error is < guard.
// Exact orientation (earlier -> later) is checked separately by the caller.
inline double margin(double dt, double dx, double dy, double dz) {
    return dt*dt - ((dx*dx + dy*dy) + dz*dz);
}

extern "C" int histogram(int n, const double* q, const double* xyz, const int64_t* ticks,
                         double last_early, const int* targets, int nt, int layers, Exact exact,
                         int64_t* counts, int64_t* sums, int64_t* fallbacks) {
    if(std::fegetround()!=FE_TONEAREST) return 1;
    std::vector<double> qt,xs,ys,zs;
    std::vector<int> ids;
    auto direct = [&](int a, int b) {
        if(q[a]>=q[b]) return false;
        const double g=margin(q[b]-q[a],xyz[3*b]-xyz[3*a],
                              xyz[3*b+1]-xyz[3*a+1],xyz[3*b+2]-xyz[3*a+2]);
        if(std::abs(g)>guard) return g>0;
        ++*fallbacks;
        return exact(a,b)==1;
    };
    for(int t=0;t<nt;++t) {
        const int x=targets[t];
        if(q[x]<=last_early) return 2;
        qt.clear();xs.clear();ys.clear();zs.clear();ids.clear();
        for(int y=x-1;y>=0;--y) {
            if(!direct(y,x)) continue;
            const double ey=q[y],xx=xyz[3*y],yy=xyz[3*y+1],zz=xyz[3*y+2];
            int k=0, size=static_cast<int>(ids.size());
            for(int start=0;start<size && k<layers;start+=64) {
                int positive=0,maybe=0,stop=std::min(start+64,size);
                #pragma omp simd reduction(+:positive,maybe)
                for(int i=start;i<stop;++i) {
                    const double g=margin(qt[i]-ey,xs[i]-xx,ys[i]-yy,zs[i]-zz);
                    // Frontier times are >= ey; an equal-time pair has margin <= 0.
                    positive+=(g>guard);
                    maybe+=(std::abs(g)<=guard);
                }
                if(maybe) {
                    for(int i=start;i<stop;++i) {
                        const double g=margin(qt[i]-ey,xs[i]-xx,ys[i]-yy,zs[i]-zz);
                        if(std::abs(g)<=guard && qt[i]>ey) {
                            ++*fallbacks;
                            positive+=exact(y,ids[i])==1;
                        }
                    }
                }
                k+=positive;
            }
            if(k>=layers)continue;
            qt.push_back(q[y]);xs.push_back(xx);ys.push_back(yy);zs.push_back(zz);ids.push_back(y);
            if(q[y]<=last_early) {
                const size_t bin=static_cast<size_t>(t)*layers+k;
                ++counts[bin];sums[bin]+=ticks[x]-ticks[y];
            }
        }
    }
    return 0;
}
