"""Vector figure of the interference gate. The proof is in path_certificate.json."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from path_certificate import HERE,endpoints

def complex_vec(arr):return np.asarray([complex(float(z.real.mid()),float(z.imag.mid())) for z in arr])
(u0,v0),(u1,v1)=endpoints();u0,v0,u1,v1=map(complex_vec,(u0,v0,u1,v1))
t=np.linspace(0,1,251);f=t[:,None]
u=(1-f)*u0+f*u1;v=(1-f)*v0+f*v1
eps=2*abs(np.sum(u.conjugate()*v,axis=1))/np.sum(abs(u)**2+abs(v)**2,axis=1)
bounds=json.loads((HERE/'path_certificate.json').read_text())['interference_switches'][0]['decimal_bracket']
tr=sum(bounds)/2
fig,ax=plt.subplots(figsize=(6.25,1.8));fig.subplots_adjust(left=.11,bottom=.30,right=.98,top=.96)
ax.axvspan(0,tr,color='#e6f3ef');ax.axhline(1/21,color='#8c5328',ls='--',lw=1.1)
ax.plot(t,eps,color='#075b5a',lw=2)
ax.plot([tr],[1/21],'o',ms=4,color='#075b5a')
ax.text(.56,1/21+.006,'Grenze 1/21',fontsize=8,color='#784321')
ax.set(xlim=(0,1),ylim=(0,.17),yticks=[0,.05,.10,.15],xticks=[0,tr,.5,.75,1],
       xticklabels=['0','0,225','0,50','0,75','1'],yticklabels=['0','0,05','0,10','0,15'],
       ylabel='Interferenz ε',xlabel='Mischparameter t')
ax.tick_params(labelsize=8);ax.xaxis.label.set_size(8);ax.yaxis.label.set_size(8)
for s in ('right','top'):ax.spines[s].set_visible(False)
fig.savefig(HERE/'interferenz.pdf');plt.close(fig)
