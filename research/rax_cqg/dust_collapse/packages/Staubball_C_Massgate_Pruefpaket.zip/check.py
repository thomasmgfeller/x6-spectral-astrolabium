"""Check sample path values against PR 210 interval arithmetic and compute a distance on measures."""
from fractions import Fraction as F
import csv,json,math,tempfile
from pathlib import Path
from main_gate import HERE,reference,require
from path_certificate import raw,ball

def main():
    tables=[{},{}]
    for r in csv.DictReader((HERE/'coefficients.csv').open()):
        key=tuple(int(r[k]) for k in ['k','signature','h','residue'])
        tables[int(r['measure']=='orbit')][key]=F(r['weight'])
    totals=list(map(lambda a:sum(a.values()),tables))
    cert=json.loads((HERE/'path_certificate.json').read_text())
    switch=cert['interference_switches'][0]; bounds=[F(switch[k]) for k in ('lower','upper')]
    with tempfile.TemporaryDirectory() as d:
        old=reference(Path(d))
        wg=[F(c,24*math.factorial(k)) for k in (1,2,3) for c in old.orbits(k,4).values()]
        require(sum(wg)==totals[0] and len(wg)==totals[1],'orbit inventory')
        tv=sum(abs(w/totals[0]-1/totals[1]) for w in wg)/2
        pts=list(map(F,('0','1/8','0.22','0.23','0.25','1/2','3/4','1')))+bounds
        require(tables[0].keys()==tables[1].keys(),'coefficient support')
        for t in pts:
            mixed={k:(1-t)*tables[0][k]/totals[0]+t*tables[1][k]/totals[1] for k in tables[0]}
            result=old.scores(mixed,'primary')
            for val,name in zip(raw(t),('q23','epsilon')):
                lo,hi=map(ball,result[name])
                require(val>=lo and val<=hi,'path value disagreement')
        # Retain the complete explicit partition, and verify contiguity and order.
        for name,rows in cert['sign_certificates'].items():
            end=F(0); state=[]
            for row in rows:
                k=row['path'];width=F(1,2**len(k));lo=int(k or '0',2)*width
                require(lo==end,'gap or overlap: '+name);end=lo+width
                if not state or state[-1]!=row['sign']:state.append(row['sign'])
            require(end==1,'incomplete')
            required=['positive','one_downward_crossing','negative'] if name=='interference' else ['positive']
            require(state==required,'sign regions: '+name)
    return dict(direct_fixed_point_checks=len(pts),both_measures_orbits=len(wg),endpoint_total_variation=str(tv),
                transition_total_variation=[str(tv*x) for x in bounds],partition_checked=True)
if __name__=='__main__':print(json.dumps(main(),indent=2))
