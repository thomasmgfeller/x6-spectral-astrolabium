"""Finite measure comparison; exact coefficient accumulation on the fixed C ensemble."""
from collections import Counter
from fractions import Fraction as F
import csv
import hashlib
import json
import math
from pathlib import Path
import sys
import tempfile
import zipfile

HERE=Path(__file__).resolve().parent
def require(ok,msg):
    if not ok: raise ValueError(msg)

def reference(base):
    pack=HERE/'reference_C.zip'
    for p,sha in [(pack,'53666ad0aab5fcee9ac102f562f83c7b380954c2356844fab7af8cfe4f793c39'),
                  (HERE/'design.json','1acdade057e192c1ec8e5f7693026f78efc99ce16e695eb69218f6936361e635')]:
        require(hashlib.sha256(p.read_bytes()).hexdigest()==sha,'input checksum '+p.name)
    with zipfile.ZipFile(pack) as z:z.extractall(base)
    sys.path.insert(0,str(base))
    import run as old
    old.reference(base/'prior')
    return old

def accumulate(old,independent=False):
    from enumerate_records import lift,read_routes,history_poly
    from audit import orbit_size,twin_deltas,trace
    totals=[Counter(),Counter()]
    for k in (1,2,3):
        for key,size in old.orbits(k,4).items():
            require(orbit_size(k,4,key)==size,'orbit size')
            edges=old.graph(old.PREPS['original'],k,4,key)
            sink=len(edges)-1
            marks=[(u,v) for u in range(3,sink) for v in edges[u]]
            one=Counter()
            if independent: new_q=twin_deltas(edges)
            else: routes=[read_routes(edges,s) for s in range(3)]
            for d in marks:
                if independent:
                    terms,den=trace(edges,d)
                    q=new_q(d)
                else:
                    terms=history_poly(routes,d,sink)
                    den=1
                    q=old.action(lift(edges,d)[0])
                for (s,h),val in terms.items():one[k,s,h,q%5]+=F(val,den)
            for out,weight in zip(totals,(F(size,math.factorial(k)*24),F(1))):
                for ky,val in one.items():out[ky]+=weight*val/len(marks)
    return totals

def by_class(coeff):
    return [sum(w for (j,*_),w in coeff.items() if j==k) for k in (1,2,3)]

def run():
    with tempfile.TemporaryDirectory() as d:
        base=Path(d);old=reference(base)
        first=accumulate(old);second=accumulate(old,True)
        require(first==second,'independent coefficient mismatch')
        with (base/'coefficients.csv').open() as f:
            known={tuple(int(r[z]) for z in ['k','signature','h','residue']):F(r['weight'])
                   for r in csv.DictReader(f) if r['family']=='C' and r['preparation']=='original'}
        require(first[0]==known,'PR 210 coefficient mismatch')
        require(by_class(first[0])==[F(1,24),F(553,48),F(54025,144)],'old masses')
        require(by_class(first[1])==[1,47,792],'new masses')
        with (HERE/'coefficients.csv').open('w',newline='') as f:
            wr=csv.writer(f,lineterminator='\n')
            wr.writerow(['measure','k','signature','h','residue','weight'])
            for measure,co in zip(('symmetry','orbit'),first):
                for key,val in sorted(co.items()):wr.writerow([measure,*key,val])
        cases={};controls={}
        for i,m in enumerate(first):
            for j,c in enumerate(first):
                # v_k = M_k * E[conditional amplitude | k]. Global scale cancels.
                ma,mc=by_class(m),by_class(c)
                fact={key:w*ma[key[0]-1]/mc[key[0]-1] for key,w in c.items()}
                cases[str(i)+str(j)]=old.scores(fact,'primary')
        for i,c in enumerate(first):
            controls[str(i)]={mode:old.scores(c,mode) for mode in ['gravity_off','no_phases','count_only']}
        (HERE/'endpoint_results.json').write_text(json.dumps(dict(cells=cases,controls=controls,
            rational_coefficients_per_measure=list(map(len,first)),fully_rechecked=True),indent=2)+'\n')
        for n,v in cases.items():print(n,v['q23_mid'],v['epsilon_mid'],v['status'])
if __name__=='__main__':
    require(__debug__,'normal Python mode required')
    run()
