# Familie C: Gate zur Abhängigkeit vom Mass der Geometrien

Der Bericht behandelt die binäre Alternativfrage k in {2,3} gegen k=1 in der Randfamilie C von PR 210. Alle Anfangsdaten, Geometrien, Markierungen und Phasen bleiben für die Hauptrechnung fest. Der neue Gewichtungsunterschied betrifft die unmarkierte Ausgangsgeometrie. Die bedingte Markierung innerhalb jeder Geometrie bleibt gleich.

## Reproduktion

Getestet mit Python 3.12.14 und python-flint 0.9.0 unter Linux. Das mitgelieferte Referenzarchiv ist die bitgleiche publizierte ZIP-Datei aus PR 210. Nach Installation der Abhängigkeit laufen beide Rechnungen offline. Für die optionale Neuzeichnung der Abbildung ist zusätzlich Matplotlib mit NumPy nötig.

```sh
sha256sum -c SHA256SUMS
python3 -m venv .venv
.venv/bin/python -m pip install python-flint==0.9.0
.venv/bin/python main_gate.py
.venv/bin/python path_certificate.py > replay-path.json
.venv/bin/python check.py > replay-audit.json
cmp replay-path.json path_certificate.json
cmp replay-audit.json audit.json
sha256sum -c SHA256SUMS
```

Der letzte Prüflauf vergleicht auch den durch main_gate.py neu erzeugten Inhalt von coefficients.csv und endpoint_results.json. Für abweichende Bibliotheksversionen können sich angezeigte Ballintervalle in den letzten Stellen unterscheiden. Die Referenzarithmetik verlangt normale Python-Ausführung mit aktivierten Assertions.

## Daten

- design.json und DESIGN_SHA256 dokumentieren die örtliche Festlegung vor der neuen Rechnung. Der Hash belegt die benutzte Fassung. Eine externe Präregistrierung hat nicht stattgefunden.
- main_gate.py verwendet die beiden Transport- und Wirkungsberechnungen aus dem verschachtelten Prüfpaket. Einmal werden die Unterteilung und die Routen ausgewertet, einmal die Änderung des Wirkungszählers durch den zusätzlichen Zwischenpunkt und die Vorwärtsausbreitung von ganzzahligen Strömen. Alle rationalen Gruppenkoeffizienten beider Masse müssen übereinstimmen.
- In endpoint_results.json bedeutet bei den vier Zellen die erste Ziffer die Herkunft der Klassengewichte und die zweite die Herkunft der bedingten Verteilung. 0 bezeichnet das bisherige Symmetriegewicht, 1 die Gleichzählung der 840 Geometrien. Die Kontrollrechnungen unter controls verwenden jeweils nur eines der beiden Masse.
- path_certificate.py berechnet für die ursprüngliche Präparation die Bernstein-Koeffizienten der beiden Gateresiduen auf dem normierten linearen Mischweg. Der Zusatztest für q > 99 % ist eine nachträgliche Beschreibung; die vorab festgelegte Freigabegrenze bleibt 80 %. Im Baum stehen die Bits 0 und 1 für die linke und rechte Hälfte. Die eindeutige Nullstelle liegt strikt innerhalb ihres angegebenen dyadischen Intervalls; bei Gleichheit mit der Interferenzschwelle besteht das Gate.
- check.py prüft die lückenlose Überdeckung, die Vorzeichenabfolge und zehn Intervallwerte mit der älteren Festkommaarithmetik. Zudem berechnet es die Totalvariationsdistanz der positiven Geometriemasse, keine Distanz von Quantenzuständen.
- figure.py erzeugt die Illustration anhand der Amplituden. Das Ganzbereichsergebnis folgt aus den zertifizierten Vorzeichen, unabhängig von der Abbildung.
- Die frühere Konzentrationskontrolle mit künstlich gleichen Gesamtgewichten je k ist eine andere Massänderung. Das Ergebnis gilt für den hier spezifizierten Mischweg und liefert keine physikalische Wahl des richtigen Masses.

[PR 210 · Randfamilie C](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/210)
