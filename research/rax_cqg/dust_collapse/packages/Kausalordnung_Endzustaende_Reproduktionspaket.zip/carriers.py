"""Compare a path-carried defect flag and its joint readout with terminal coincidences."""
import csv,math,json,itertools
from fractions import Fraction as F
from collections import Counter,defaultdict
from enumerate_records import ROOT,old_ensemble,new_ensemble,read_routes,local_channels,signature,csvout
from certify_records import fifth_roots
from bounds import bound,plus,scale,lower_mod,upper_mod,S

def main():
    existing={(r['ensemble'],int(r['id']),int(r['tail']),int(r['head'])):r for r in csv.DictReader((ROOT/'history_records.csv').open())}
    weights=defaultdict(F)
    for name,gen in [('published',old_ensemble()),('fixed',new_ensemble())]:
        for idx,k,l,edges in gen:
            sink=len(edges)-1;routes=[read_routes(edges,s) for s in range(3)]
            for u in range(3,sink):
                for v in edges[u]:
                    row=existing[name,idx,u,v]
                    W=F(row['prior']);Q=int(row['Q'])%5
                    parts=[local_channels(s,(u,v),sink) for s in routes]
                    den=math.prod(d for _,d in parts);terms=Counter()
                    for a,b,c in itertools.product(*(z for z,_ in parts)):
                        s=signature(a[0],b[0],c[0]);f=a[1]+2*b[1]+4*c[1]
                        terms[s,f]+=a[2]*b[2]*c[2]
                    assert sum(terms.values())==den
                    original={tuple(map(int,key.split('.'))):F(val) for key,val in (word.split('=') for word in row['polynomial'].split())}
                    reduced=defaultdict(F)
                    for (sig,flag),w in terms.items():
                        reduced[sig,flag.bit_count()]+=F(w,den)
                        weights[name,k,sig,flag,Q]+=W*F(w,den)
                    assert dict(reduced)==original
    csvout(ROOT/'carrier_coefficients.csv',[dict(ensemble=y,k=k,sig=s,flag=f,residue=j,w=str(w)) for (y,k,s,f,j),w in sorted(weights.items())])
    results=[];roots=fifth_roots()
    for name in ('published','fixed'):
        for kind in ('flags','flags_and_arrivals'):
            for g in (0,1):
                coeff=defaultdict(lambda:[F(0)]*5)
                for (y,k,s,f,j),w in weights.items():
                    if y==name:coeff[k,f,s if kind=='flags_and_arrivals' else -1][j]+=w
                records=sorted({(f,s) for k,f,s in coeff})
                # Exact coefficient of each fifth root in D_ij.
                D={}
                for i,j in itertools.combinations_with_replacement([1,2,3],2):
                    residues=[F(0)]*5
                    for f,s in records:
                        for n,a in enumerate(coeff[i,f,s]):
                            for p,b in enumerate(coeff[j,f,s]):residues[(n-p)%5]+=a*b
                    value=(bound(0),bound(0))
                    for w,z in zip(residues,roots if g else [roots[0]]*5):value=plus(value,scale(z,bound(w)))
                    D[i,j]=value
                upper=F(sum(D[i,i][0][1] for i in (1,2,3)),S)
                lower=F(sum(D[i,i][0][0] for i in (1,2,3)),S);assert lower>0
                epslo=2*sum(lower_mod(D[i,j]) for i,j in itertools.combinations([1,2,3],2))/upper
                mid=lambda a:complex(sum(a[0])/(2*S),sum(a[1])/(2*S))
                diag=sum(mid(D[i,i]).real for i in (1,2,3))
                q=[mid(D[i,i]).real/diag for i in (1,2,3)]
                epsilon=2*sum(abs(mid(D[i,j])) for i,j in itertools.combinations([1,2,3],2))/diag
                epshi=2*sum(upper_mod(D[i,j]) for i,j in itertools.combinations([1,2,3],2))/lower
                qlo=max(F(D[i,i][0][0],S)/upper for i in (1,2,3))
                qhi=max(F(D[i,i][0][1],S)/lower for i in (1,2,3))
                if epslo>F(1,21) or qhi<F(4,5): issued=False
                elif epshi<=F(1,21) and qlo>=F(4,5): issued=True
                else:issued=None
                results.append(dict(ensemble=name,mode=kind,gravity_on=g,q=q,epsilon=epsilon,
                        epsilon_certified_lower=str(epslo),issue=issued,n_records=len(records)))
    (ROOT/'carriers.json').write_text(json.dumps(results,indent=2)+'\n')
    print([(r['ensemble'],r['mode'],r['q'],r['epsilon']) for r in results if r['gravity_on']])
if __name__=='__main__':main()
