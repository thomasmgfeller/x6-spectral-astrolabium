"""Prove an interference bound for all matter phases and all comparison readout strengths."""
import csv,json
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
from math import comb
from pathlib import Path
from bounds import S,bound,add,neg,mul,root,plus,scale,times,rot,lower_mod
from enumerate_records import ROOT,csvout

ZERO=(bound(0),bound(0))
PAIRS=((0,1),(0,2),(1,2))

def fifth_roots():
    v=root(bound(5));quarter=bound(F(1,4))
    zeta=(mul(neg(add(bound(1),v)),quarter),mul(root(add(bound(10),neg(mul(bound(2),v)))),quarter))
    values=[(bound(1),bound(0))]
    for i in range(4):values.append(times(values[-1],zeta))
    return values

def exact_laurent(label):
    rows=[defaultdict(F) for _ in range(3)]
    for r in csv.DictReader((ROOT/'coefficients.csv').open()):
        if r['ensemble']==label:
            rows[int(r['k'])-1][int(r['sig']),int(r['h']),int(r['residue'])]+=F(r['w'])
    # First three polynomials are off-diagonal entries, the fourth their common normalization (trace).
    L=[defaultdict(F) for _ in range(4)]
    for k,l in (*PAIRS,(0,0),(1,1),(2,2)):
        target=PAIRS.index((k,l)) if k!=l else 3
        for (s,h,p),a in rows[k].items():
            for (t,m,q),b in rows[l].items():
                L[target][(s^t).bit_count(),h-m,(p-q)%5]+=a*b
    return L

def integer_numerator(n,quad):
    # Gaussian-integer coefficients; multiplication by (1+u^2)^3 clears all denominators.
    a=[(1,0)]
    for j in range(3):
        if j<abs(n):poly=[(1,0),(0,2 if n>0 else -2),(-1,0)]
        else:poly=[(1,0),(0,0),(1,0)]
        b=[(0,0)]*(len(a)+2)
        for i,(x,y) in enumerate(a):
            for k,(z,w) in enumerate(poly):
                p,q=b[i+k];b[i+k]=(p+x*z-y*w,q+x*w+y*z)
        a=b
    for _ in range((quad*n)%4):a=[(-y,x) for x,y in a]
    return a

def bernstein(terms,quad,roots):
    power=[[ZERO for _ in range(4)] for _ in range(7)]
    laurent={(d,n):ZERO for d in range(4) for n in range(-3,4)}
    for (d,n,r),weight in terms.items():
        laurent[d,n]=plus(laurent[d,n],scale(roots[r],bound(weight)))
    for (d,n),c in laurent.items():
        for i,(x,y) in enumerate(integer_numerator(n,quad)):
            power[i][d]=plus(power[i][d],plus(scale(c,bound(x)),scale(rot(c),bound(y))))
    result=[]
    for i in range(7):
        row=[]
        for j in range(4):
            v=ZERO
            for p in range(i+1):
                for d in range(j+1):
                    f=F(comb(i,p)*comb(j,d),comb(6,p)*comb(3,d))
                    v=plus(v,scale(power[p][d],bound(f)))
            row.append(v)
        result.append(row)
    return result

def avg(a,b):
    return tuple(((x[0]+y[0])//2,-((-x[1]-y[1])//2)) for x,y in zip(a,b))
def subdivide_line(pts):
    left=[pts[0]];right=[pts[-1]]
    while len(pts)>1:
        pts=[avg(a,b) for a,b in zip(pts,pts[1:])];left.append(pts[0]);right.append(pts[-1])
    return left,right[::-1]
def subdivide(mat,axis):
    if axis==0:
        a,b=subdivide(list(zip(*mat)),1)
        return list(zip(*a)),list(zip(*b))
    both=[subdivide_line(row) for row in mat]
    return [x for x,y in both],[y for x,y in both]
def enclosure(mat):
    vals=[v for row in mat for v in row]
    return tuple((min(x[j][0] for x in vals),max(x[j][1] for x in vals)) for j in (0,1))
def cover(label):
    roots=fifth_roots();L=exact_laurent(label);leaves=[]
    for quadrant in range(4):
        matrices=[bernstein(terms,quadrant,roots) for terms in L]
        stack=[('',matrices)]
        while stack:
            path,mats=stack.pop();est=[enclosure(m) for m in mats]
            low,hi=est[3][0];assert hi>0
            ratio=2*sum(lower_mod(x) for x in est[:3])/F(hi,S)
            ok=(ratio>F(1,21) and low>0)
            if ok or len(path)==18:
                leaves.append(dict(ensemble=label,quadrant=quadrant,path='r'+path,
                          lower=str(ratio),trace_lower=str(F(low,S)),verified=int(ok)))
            else:
                both=[subdivide(m,len(path)%2) for m in mats]
                stack.extend((path+str(side),[a[side] for a in both]) for side in (0,1))
        paths=sorted(x['path'][1:] for x in leaves if x['quadrant']==quadrant)
        assert sum(F(1,2**len(p)) for p in paths)==1
        assert all(not b.startswith(a) for a,b in zip(paths,paths[1:]))
    return leaves
def main():
    leaves=[];summary=[]
    for name in ['published','fixed']:
        cover_rows=cover(name);leaves.extend(cover_rows)
        info=dict(ensemble=name,boxes=len(cover_rows),verified=sum(x['verified'] for x in cover_rows),
                  lower=float(min(F(x['lower']) for x in cover_rows)),max_depth=max(len(x['path'])-1 for x in cover_rows))
        summary.append(info)
    csvout(ROOT/'detector_boxes.csv',leaves)
    (ROOT/'certificate.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(summary)
if __name__=='__main__':main()
