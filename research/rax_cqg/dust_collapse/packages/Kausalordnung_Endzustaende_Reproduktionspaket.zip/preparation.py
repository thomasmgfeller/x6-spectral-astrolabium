"""Change just the early source incidence; preserve labelled late completions and their weights."""
import csv,json,math,itertools
from fractions import Fraction as F
from collections import defaultdict,Counter
import numpy as np
from enumerate_records import ROOT,old_ensemble,new_ensemble,read_routes,history_poly,q_integer,lift,csvout
from evaluate import amplitudes,evaluate,SIGNATURES

def main():
    expected={(r['ensemble'],int(r['id']),int(r['tail']),int(r['head'])):r for r in csv.DictReader((ROOT/'history_records.csv').open())}
    coef=defaultdict(F);raw=[];out=[]
    for y,gen in [('published',old_ensemble()),('fixed',new_ensemble())]:
        for idx,k,l,edges in gen:
            assert edges[:3]==[[3],[3,4],[4]]
            edges[2]=[3];sink=len(edges)-1
            routes=[read_routes(edges,s) for s in (0,1,2)]
            for u in range(3,sink):
                for v in edges[u]:
                    old=expected[y,idx,u,v]
                    assert int(old['k'])==k and int(old['two_back'])==l
                    g,_=lift(edges,(u,v));Q,_,_=q_integer(g);weights=history_poly(routes,(u,v),sink)
                    w=F(old['prior'])
                    for (s,h),val in weights.items():coef[y,k,l,s,h,Q%5]+=w*val
                    raw.append(dict(ensemble=y,id=idx,tail=u,head=v,old_Q=old['Q'],Q=Q,k=k,l=l,
                                polynomial=' '.join(f'{s}.{h}={weights[s,h]}' for s,h in sorted(weights))))
    assert len(raw)==len(expected)
    csvout(ROOT/'changed_histories.csv',raw)
    csvout(ROOT/'changed_coefficients.csv',[dict(ensemble=y,k=k,b=b,sig=s,h=h,residue=j,w=str(w)) for (y,k,b,s,h,j),w in sorted(coef.items())])
    frozen_orig=list(csv.DictReader((ROOT/'scores.csv').open()))
    for y in ('published','fixed'):
        C=np.zeros((3,4,5,4,5))
        for (model,k,b,s,h,j),w in coef.items():
            if model==y:C[k-1,b,SIGNATURES.index(s),h,j]=float(w)
        for g,eta in itertools.product((0,1),(0,1)):
            A=amplitudes(C,g,eta)
            for mode,gamma in [('silent',1.),('arrivals',0.)]:
                score,pairs=evaluate(A,mode,gamma)
                D=np.array([complex(r['real'],r['imag']) for r in pairs]).reshape(3,3)
                row=dict(ensemble=y,gravity_on=g,eta=eta,record=mode,**score)
                for i in range(3):
                    j,l=[x for x in range(3) if x!=i]
                    a=D[i,i].real;b=(D[j,j]+D[l,l]+D[j,l]+D[l,j]).real
                    prob=a/(a+b);eps=2*abs(D[i,j]+D[i,l])/(a+b)
                    row[f'binary_q{i+1}']=prob;row[f'binary_eps{i+1}']=eps
                    row[f'binary_issue{i+1}']=int(max(prob,1-prob)>=.8 and eps<=1/21)
                out.append(row)
                old=next(r for r in frozen_orig if r['ensemble']==y and r['record']==mode and int(r['eta'])==eta and int(r['gravity_on'])==g and float(r['gamma'])==gamma)
                if g==0 and eta==0 and mode=='silent':assert abs(float(old['q1'])-score['q1'])<1e-13
    csvout(ROOT/'changed_scores.csv',out)
    print([(r['ensemble'],round(max(r['q1'],r['q2'],r['q3']),4),round(r['epsilon'],4),round(r['binary_eps1'],4),r['binary_issue1']) for r in out if r['gravity_on']==r['eta']==1 and r['record']=='arrivals'])
if __name__=='__main__':main()
