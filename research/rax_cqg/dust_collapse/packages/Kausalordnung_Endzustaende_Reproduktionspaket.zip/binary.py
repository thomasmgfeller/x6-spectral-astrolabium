"""Certified binary coarse grainings for the fixed primary coupling and phase strength."""
import csv,json,itertools
from math import factorial
from fractions import Fraction as F
from collections import defaultdict
from bounds import S,bound,add,neg,mul,root,plus,scale,times,lower_mod,upper_mod
from enumerate_records import ROOT,csvout
from certify_records import fifth_roots

def atan_bounds(n):
    # Alternating rational series at 1/n and its first omitted term.
    t=sum((-1)**k*F(1,(2*k+1)*n**(2*k+1)) for k in range(20))
    return t,t+F(1,41*n**41)
def phase_interval():
    a,b=atan_bounds(5);c,d=atan_bounds(239)
    pi_lo=16*a-4*d;pi_hi=16*b-4*c
    x=root(root((bound(F(24,1)/pi_hi)[0],bound(F(24,1)/pi_lo)[1])))
    delta=mul(x,add(root(root(bound(2))),neg(bound(1))))
    assert 0<delta[0]<=delta[1]<S
    val=(bound(1),bound(0));p=(bound(1),bound(0));m=(bound(0),neg(delta))
    for j in range(1,19):
        p=times(p,m);val=plus(val,scale(p,bound(F(1,factorial(j)))))
    err=bound(F(1,factorial(19)))[1]
    return tuple((lo-err,hi+err) for lo,hi in val)
def inner(a,b):
    v=(bound(0),bound(0))
    for x,y in zip(a,b):v=plus(v,times(x,(y[0],neg(y[1]))))
    return v
def exact_binary(coefficients,destination):
    roots=fifth_roots();z=phase_interval();powers=[(bound(1),bound(0))]
    for _ in range(3):powers.append(times(powers[-1],z))
    states=defaultdict(lambda:(bound(0),bound(0)));out=[]
    for r in csv.DictReader((ROOT/coefficients).open()):
        term=scale(times(roots[int(r['residue'])],powers[int(r['h'])]),bound(F(r['w'])))
        k=int(r['k']);s=int(r['sig']);y=r['ensemble']
        for mode,idx in [('silent',0),('arrivals',s)]:
            key=(y,mode,k,idx);states[key]=plus(states[key],term)
    for y,mode in itertools.product(('published','fixed'),('silent','arrivals')):
        V={k:[states[y,mode,k,s] for s in (0,1,2,4,7)] for k in (1,2,3)}
        for i in (1,2,3):
            j,l=[k for k in (1,2,3) if k!=i]
            A=V[i];B=[plus(x,y0) for x,y0 in zip(V[j],V[l])]
            a=inner(A,A)[0];b=inner(B,B)[0];off=inner(A,B)
            low,high=add(a,b);assert low>0
            qlo=F(a[0],high);qhi=F(a[1],low)
            epslo=2*lower_mod(off)/F(high,S);epshi=2*upper_mod(off)/F(low,S)
            qmaxlo=max(qlo,1-qhi);qmaxhi=max(qhi,1-qlo)
            if epshi<=F(1,21) and qmaxlo>=F(4,5):result='issue'
            elif epslo>F(1,21) or qmaxhi<F(4,5):result='withhold'
            else:result='undecided'
            out.append(dict(ensemble=y,record=mode,singleton=i,q_single_min=str(qlo),q_single_max=str(qhi),
                            epsilon_min=str(epslo),epsilon_max=str(epshi),decision=result))
    csvout(ROOT/destination,out)
    return out

def main():
    out=exact_binary('coefficients.csv','binary.csv')
    exact_binary('changed_coefficients.csv','changed_binary.csv')
    masses=defaultdict(F)
    for r in csv.DictReader((ROOT/'history_records.csv').open()):
        masses[r['ensemble'],int(r['k'])]+=F(r['prior'])
    controls=[]
    for name in ('published','fixed'):
        a=masses[name,1];b=masses[name,2]+masses[name,3];norm=a*a+b*b
        controls.append(dict(ensemble=name,masses=[str(masses[name,k]) for k in (1,2,3)],
                        q_rest=str(b*b/norm),epsilon=str(2*a*b/norm),issue=2*a*b/norm<=F(1,21) and b*b/norm>=F(4,5)))
    (ROOT/'kinematic.json').write_text(json.dumps(controls,indent=2)+'\n')
    for x in out:
        if x['record']=='arrivals':print(x['ensemble'],x['singleton'],float(F(x['q_single_min'])),float(F(x['epsilon_min'])),x['decision'])
if __name__=='__main__':main()
