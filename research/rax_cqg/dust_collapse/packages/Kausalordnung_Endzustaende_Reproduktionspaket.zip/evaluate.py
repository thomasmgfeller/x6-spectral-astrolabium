"""Calculate the record-state Gram matrix and the original PR201 release rule."""
import csv,json,math,itertools
from collections import defaultdict
from fractions import Fraction
import numpy as np
from enumerate_records import ROOT,csvout

SIGNATURES=(0,1,2,4,7)
DELTA=(48/math.pi)**.25-(24/math.pi)**.25

def polynomials():
    series=defaultdict(lambda:np.zeros((3,4,5,4,5)))
    for r in csv.DictReader((ROOT/'coefficients.csv').open()):
        y,k,b,s,h,j=r['ensemble'],int(r['k']),int(r['b']),int(r['sig']),int(r['h']),int(r['residue'])
        series[y][k-1,b,SIGNATURES.index(s),h,j]=float(Fraction(r['w']))
    return series

def amplitudes(coeff,gravity,eta):
    roots=np.exp(1j*gravity*4*math.pi*np.arange(5)/5)
    return np.einsum('kbshj,h,j->kbs',coeff,np.exp(-1j*eta*DELTA*np.arange(4)),roots)

def pointer(sig,gamma):
    v=np.array([1.])
    for j in range(3):
        state=np.array([gamma,math.sqrt(max(0,1-gamma**2))]) if sig>>j&1 else np.array([1.,0.])
        v=np.kron(v,state)
    return v

def evaluate(amps,kind,gamma):
    if kind in ('silent','shell'):gamma=1.
    shell=kind in ('shell','joint')
    memory=np.stack([pointer(s,gamma) for s in SIGNATURES])
    kernel=np.array([[gamma**(s^t).bit_count() for t in SIGNATURES] for s in SIGNATURES])
    assert np.allclose(memory@memory.T,kernel,rtol=0,atol=1e-14)
    grouped=amps if shell else amps.sum(axis=1,keepdims=True)
    D=np.einsum('kbs,st,lbt->kl',grouped,kernel,grouped.conj())
    vectors=(grouped@memory).reshape(3,-1)
    assert np.max(abs(D-vectors@vectors.conj().T))<1e-10
    assert np.linalg.eigvalsh(D).min()>-1e-10
    diag=np.sum(abs(vectors)**2,axis=1);total=diag.sum()
    if not total>0:raise ValueError('No branch norm; the release rule is undefined.')
    q=diag/total
    eps=2*sum(abs(D[i,j]) for i,j in itertools.combinations(range(3),2))/total
    denom=np.sqrt(diag[:,None]*diag[None,:])
    overlap=np.divide(abs(D),denom,out=np.full((3,3),np.nan),where=denom>0)
    out=dict(q1=q[0],q2=q[1],q3=q[2],epsilon=eps,c12=overlap[0,1],c13=overlap[0,2],c23=overlap[1,2],
             peak=int(q.argmax()+1),issue=int(eps<=1/21 and max(q)>=.80),trace=float(total),
             score_concentration=int(max(q)>=.80),score_interference=int(eps<=1/21))
    pairs=[dict(i=i+1,j=j+1,real=float(D[i,j].real),imag=float(D[i,j].imag)) for i in range(3) for j in range(3)]
    return out,pairs

def main():
    models=polynomials();out=[];overlaps=[]
    baseline=json.loads((ROOT/'input/defect_result.json').read_text())['cases']
    for name,coeff in models.items():
        for g,eta in itertools.product((0,1),(0,1)):
            amps=amplitudes(coeff,g,eta)
            modes=[('silent',1.),('shell',1.),('arrivals',0.),('arrivals',2**-.5),('arrivals',1.),('joint',0.)]
            for kind,gamma in modes:
                score,pairs=evaluate(amps,kind,gamma)
                keys=dict(ensemble=name,gravity_on=g,eta=eta,record=kind,gamma=gamma)
                out.append(dict(**keys,**score))
                overlaps.extend(dict(**keys,**pair) for pair in pairs)
                if name=='published' and kind=='silent':
                    old=next(r for r in baseline if int(r['gravity_on'])==g and r['eta']==eta)
                    assert max(abs(score[f'q{i+1}']-old['q'][i]) for i in range(3))<1e-11
                    assert abs(score['epsilon']-old['eps'])<1e-11
    csvout(ROOT/'scores.csv',out);csvout(ROOT/'gram.csv',overlaps)
    for row in out:
        if row['gravity_on']==row['eta']==1:
            print(row['ensemble'],row['record'],round(row['gamma'],3),*[round(row[k],4) for k in ('q1','q2','q3','epsilon','c12','c13','c23')],row['issue'])
if __name__=='__main__':main()
