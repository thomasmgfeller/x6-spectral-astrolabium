"""Enumerate source-marked endpoint signatures on two finite causal-order ensembles."""
import csv
import hashlib
import itertools
import json
import math
import sys
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'prior'))
from lift import lift,paths
from defect import q_integer

INPUT_HASH={'geometry_flux.csv':'2b1e3373a2631a48ca9519dd76983c75897e3d1c24be620e87add2a6547ede86',
            'defect_histories.csv':'888f08372f6d95931e905c8edcd78f87869564f8fe64f9e31a3cafe173547bd9',
            'defect_result.json':'c2166d6ed59fa5ddc0c0fc981413dec912ece1a44e37a8f7f3ea48db21022046'}

def csvout(path,rows):
    with path.open('w',newline='') as f:
        out=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        out.writeheader();out.writerows(rows)

def covers(m,n):
    for rows in itertools.product(range(1,1<<n),repeat=m):
        cols=0
        for mask in rows:cols|=mask
        if cols==(1<<n)-1:yield rows

def new_ensemble():
    idx=0
    for k in (1,2,3):
        l=2
        for a,b in itertools.product(covers(2,k),covers(k,l)):
            sizes=(3,2,k,l,1)
            edges=[]
            for j,rows in enumerate(((1,3,2),a,b,(1,)*l)):
                offset=sum(sizes[:j+1])
                edges.extend([[offset+i for i in range(sizes[j+1]) if mask>>i&1] for mask in rows])
            idx+=1
            yield idx,k,l,edges+[[]]

def old_ensemble():
    for r in csv.DictReader((ROOT/'input/geometry_flux.csv').open()):
        edges=[[int(t) for t in x.split(',') if t] for x in r['edges'].split('|')]
        yield int(r['id']),int(r['k']),4-int(r['k']),edges

def read_routes(edges,s):
    return [(list(zip(path,path[1:])),Fraction(1,math.prod(len(edges[u]) for u in path[:-1])))
            for path in paths(edges,s)]

def local_channels(routes,defect,sink):
    # Immediate predecessor of the terminal event = inserted event on the final cover.
    terms=defaultdict(Fraction)
    for route,weight in routes:
        last=route[-1][0]
        exponent=int(defect in route)
        if defect==(last,sink):
            terms[last,exponent]+=weight/2
            terms[-1,exponent]+=weight/2  # the additional incoming port
        else:
            terms[last,exponent]+=weight
    assert sum(terms.values())==1
    den=math.lcm(*(w.denominator for w in terms.values()))
    return [(p,h,int(w*den)) for (p,h),w in terms.items()],den

def signature(i,j,k):
    return int(i==j)+2*int(i==k)+4*int(j==k)

def history_poly(routes,defect,sink):
    alternatives=[local_channels(source,defect,sink) for source in routes]
    den=math.prod(d for _,d in alternatives)
    coeff=Counter()
    for a,b,c in itertools.product(*(terms for terms,_ in alternatives)):
        s=signature(a[0],b[0],c[0]);h=a[1]+b[1]+c[1]
        coeff[s,h]+=a[2]*b[2]*c[2]
    assert sum(coeff.values())==den
    return {k:Fraction(v,den) for k,v in coeff.items()}

def main():
    for name,expected in INPUT_HASH.items():
        assert hashlib.sha256((ROOT/'input'/name).read_bytes()).hexdigest()==expected
    published={(int(r['id']),int(r['tail']),int(r['head'])):r for r in
               csv.DictReader((ROOT/'input/defect_histories.csv').open())}
    out=[];coefficients=defaultdict(Fraction);groups=[]
    for label,ensemble in [('published',old_ensemble()),('fixed',new_ensemble())]:
        ngeom=0; nhist=0
        for idx,k,l,edges in ensemble:
            ngeom+=1;sink=len(edges)-1
            routes=[read_routes(edges,s) for s in (0,1,2)]
            defects=[(i,j) for i in range(3,sink) for j in edges[i]]
            weight=Fraction(1,len(defects)*math.factorial(k)*math.factorial(l))
            for u,v in defects:
                expanded,index=lift(edges,(u,v))
                Q,_,_=q_integer(expanded)
                final=index['old',sink]
                children=[i for i,targets in enumerate(expanded) if final in targets]
                grandparents={a for a,targets in enumerate(expanded) if any(x in targets for x in children)}
                b=len(grandparents)
                assert b==l and len(children)==l+int(v==sink)
                coef=history_poly(routes,(u,v),sink)
                if label=='published':
                    prev=published[idx,u,v]
                    assert int(prev['Q'])==Q and int(prev['ways'])==len(defects)
                    p=Counter({0:Fraction(1)})
                    for key in ('r0','r1','r2'):
                        f=Fraction(prev[key]);n=Counter()
                        for h,value in p.items():n[h]+=value*(1-f);n[h+1]+=value*f
                        p=n
                    assert all(sum(coef.get((s,h),0) for s in (0,1,2,4,7))==p[h] for h in range(4))
                for (s,h),f in coef.items():coefficients[label,k,b,s,h,Q%5]+=weight*f
                out.append(dict(ensemble=label,id=idx,k=k,tail=u,head=v,Q=Q,two_back=b,ports=len(children),
                          prior=str(weight),polynomial=' '.join(f'{s}.{h}={coef[s,h]}' for s,h in sorted(coef))))
                nhist+=1
        groups.append(dict(ensemble=label,geometries=ngeom,histories=nhist))
    csvout(ROOT/'history_records.csv',out)
    csvout(ROOT/'coefficients.csv',[dict(ensemble=y,k=k,b=b,sig=s,h=h,residue=j,w=str(f)) for (y,k,b,s,h,j),f in sorted(coefficients.items())])
    (ROOT/'inventory.json').write_text(json.dumps(groups,indent=2)+'\n');print(groups)
if __name__=='__main__':main()
