# Endzustände im endlichen Staubmodell

Diese Rechnung prüft, welche Informationen über die späte Schichtbreite k den gemeinsamen Endpunkt erreichen. Drei markierte Quellen werden auf den Routen des konservierten Transportmodells von [PR 201](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/201) transportiert. Ein lokales Endsystem schreibt nur Vergleiche der Ankunftsports in drei Speicherbits. Das konkrete Endzustandsprodukt und die kontrollierte Speicheroperation sind zusätzliche mikroskopische Annahmen.

## Offline-Reproduktion

Verwendet wurden Python 3.12.14 und NumPy 2.3.5. Die Untersuchung zählt alle beschrifteten Historien und Routen der spezifizierten Familien auf. Die Zertifikate verwenden gerichtet gerundete Ganzzahlarithmetik und rationale Gewichte. Bei numerischen Kontrolltabellen können Plattformen in letzten Gleitkommastellen abweichen.

    sha256sum -c SHA256SUMS
    export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
    python3 enumerate_records.py
    python3 evaluate.py
    python3 certify_records.py
    python3 carriers.py
    python3 preparation.py
    python3 binary.py
    python3 verify.py
    sha256sum -c SHA256SUMS

Die Laufzeit hängt vor allem von der erneuten Aufzählung der beiden Präparationen ab. Für eine schnelle unabhängige Prüfung der kontinuierlichen Ausschlussschranken auf Basis der mitgelieferten rationalen Koeffizienten genügt `python3 certify_records.py`. Die PDF-Quelle liegt in `paper/report.tex` und kann mit pdfLaTeX zweimal gesetzt werden.

## Versuchspläne und Grenzen

| Datei | Gegenstand | SHA-256 |
|---|---|---|
| design.json | Primäre Ankunftsvergleiche, Randkontrolle, Geometriefamilien, gemeinsame Regel | 7b2550758efe10f025d24eef8e54b3f717dd1a502ab96dbf4d5d5aaee47b32fa |
| carrier_design.json | Zusätzliche mitgeführte Wegmerkmale, nach Sichtung der primären Ankunftsergebnisse | 7d6d515df8c6ed042043722295301d7ad8da48ef74e751a39fa437d615a659c9 |
| binary_design.json | Alle 3 binären Grobkörnigkeiten der ursprünglichen Präparation, getrennt vom vollen Drei-Klassen-Test | b0a54c9fa0f19a4ef062ed9d9b439f5ac6a632a919705ee64a737f4ea5745832 |
| preparation_design.json | Paarvergleich bei Änderung genau einer frühen Inzidenz, gleiche späte Komplettierungen | b64bf27fb8b4c537b14136af0cb7d96d19e2c6c593c010e1ba153be01d772b48 |

Die Versuchspläne wurden lokal vor der zugehörigen Auswertung fixiert. Der zweidimensionale Ganzbereichsbeweis und das Gegenbeispiel bei z=-1 sind nachträgliche mathematische Untersuchungen. Es gibt kein extern verblindetes Volumenziel und keine statistischen Konfidenzintervalle. Der binäre Bereichstest ist eine separate Neuberechnung der Gram-Matrix, keine Addition der Diagonalgewichte aus dem Drei-Klassen-Test.

## Tabellen und Rechenwege

- `input/` enthält die 75 alten Ausgangsgeometrien und die publizierten 588 Ein-Defekt-Historien sowie die Ergebnisse mit gemeinsamem Endzustand aus PR 201. Die SHA-256-Werte dieser Inputs werden geprüft. `prior/` liefert die unveränderten Aufzählungs-, Verfeinerungs- und Gravitationsroutinen aus diesem Paket.
- `history_records.csv` enthält je Geometrie und gewählter doppelter Kante Q, die Anzahl der eintreffenden Ports, die Zahl verschiedener Vorfahren zwei Überdeckungskanten zurück und ein exakt rationales Polynom. `s.h=w` bezeichnet einen Koeffizienten mit Ankunftsmuster s, Durchgangszahl h und Routenanteil w. Die Bits von s (Werte 1, 2 und 4) vergleichen die Quellenpaare (0,1), (0,2), (1,2). Muster 0 bedeutet drei verschiedene Ports, 7 einen gemeinsamen Port aller drei Quellen. Bei der Dopplung der letzten Kante zählen deren beiden Zwischenelemente als verschiedene Ports.
- `coefficients.csv` enthält die zusammengefassten rationalen Koeffizienten der Zweigamplituden, nach Schichtbreite k, Randzahl b, Ankunftsmuster s, Potenz h von z und Rest Q modulo fünf. `inventory.json` gibt die vollständigen Familiengrössen an. Die Referenzbelegung k=2 stimmt in beiden Familien überein.
- `scores.csv` und `gram.csv` enthalten für beide Familien und beide Ein-/Ausschaltungen der Wirkungen die drei Diagonalgewichte, Interferenzkennzahl, normierte Paarüberlappungen, Entscheidungen und sämtliche komplexen Matrixeinträge. Die gemeinsame Materiephase ist ausklammerbar.
- `bounds.py` enthält die einschliessende Festkomma-Arithmetik; `certify_records.py` erzeugt die Koeffizienten der Bernstein-Polynome über (Phasenquadrant, Auslesestärke). In `detector_boxes.csv` beginnt jeder Pfad mit r. Jedes nächste Bit wählt die untere oder obere Hälfte, abwechselnd in u und gamma, beginnend mit u. Die Spuruntergrenze ist für die mit (1+u²)^3 skalierte Spur notiert. `certificate.json` weist die lückenlose Deckung für jede der zwei ursprünglichen Familien aus.
- `carrier_coefficients.csv` zerlegt die Ankünfte weiter nach den drei Quellenbits für den Durchgang durch die doppelte Kante. `carriers.json` vergleicht Durchgangsbits allein und zusammen mit Ankunftsmustern bei idealem Speicher. Die Interferenzuntergrenzen sind rationale Zahlen.
- `binary.csv` und `changed_binary.csv` enthalten garantierte Intervalle für jede der drei binären Fragen. `q_single` gehört zur einzelnen Klasse. Für das Gegenereignis ist der komplementäre Wert zu verwenden. `kinematic.json` dokumentiert die stumme Referenz ohne Wirkungsphasen und die tatsächlich summierten Klassengewichte.
- `changed_histories.csv`, `changed_coefficients.csv` und `changed_scores.csv` enthalten die gepaarten Ergänzungen nach Umlegen der frühen Verbindung der dritten Quelle. `verify.py` kontrolliert direkte Mikrorouten und Umnummerierungen, 195 Punkte des kontinuierlichen Zertifikats, den identischen k=2-Sektor und das ausdrücklich retrospektive Gegenbeispiel mit geometrischem Randregister. Ergebnisse in `validation.json`.
- `Pruefbericht.pdf` enthält die Herleitung der Endzustände, die Grenzen der Prognose und die Quellen.

Der globale Ausschluss gilt für die ursprüngliche frühe Präparation, die beiden genannten späten Familien, deren Gewichte, g=4*pi/5 und den spezifizierten Ankunftsvergleich. Die zusätzliche gespeicherte Randzahl ist nur in der Familie mit festem l wirkungslos. Für die geänderte frühe Präparation werden punktweise Ergebnisse und zertifizierte binäre Entscheidungen angegeben. Eine Lösung der Singularitätsfrage oder die Ableitung der vierdimensionalen Staubbewegung ist damit nicht gegeben.
