"""Independent track tracing, relabeling, and numerical spot checks of the interval proof."""
import csv,itertools,json,math
from collections import Counter
from fractions import Fraction as F
import numpy as np
from enumerate_records import ROOT,old_ensemble,new_ensemble,lift,signature
from evaluate import polynomials,amplitudes,DELTA
from certify_records import fifth_roots
from bounds import bound,plus,scale,times,lower_mod,S

def explicit(edges,sources,sink):
    # Work directly with arbitrary vertex IDs. Each original two-link interval is one move.
    def walk(a):
        if a==sink:return [(None,0,F(1))]
        targets={}
        for mid in edges[a]:
            for b in edges[mid]:targets.setdefault(b,[]).append(mid)
        out=[]
        for b,mids in targets.items():
            weight=F(1,len(targets)*len(mids))
            for mid in mids:
                for port,h,w in walk(b):
                    out.append((mid if b==sink else port,h+int(len(mids)==2),w*weight))
        return out
    branches=[walk(a) for a in sources]
    coeff=Counter()
    for a,b,c in itertools.product(*branches):
        s=signature(a[0],b[0],c[0]);f=a[1]+2*b[1]+4*c[1]
        coeff[s,f]+=a[2]*b[2]*c[2]
    assert sum(coeff.values())==1
    return coeff

def witness(coeff):
    # z=-1, orthogonal b and orthogonal equality signatures. Group norms rigorously.
    roots=fifth_roots();diag=[]
    for k in range(3):
        norms=[]
        for b in range(1,4):
            for s in range(5):
                val=(bound(0),bound(0))
                for h in range(4):
                    for j in range(5):val=plus(val,scale(roots[j],bound(coeff.get((k,b,s,h,j),0)*(-1)**h)))
                # Orthonormal record. Use outward squares through interval product.
                re,im=val; z=times(val,(re,(-im[1],-im[0])))[0];norms.append(z)
        diag.append((sum(v[0] for v in norms),sum(v[1] for v in norms)))
    lo=F(diag[1][0],sum(v[1] for v in diag));hi=F(diag[1][1],sum(v[0] for v in diag))
    assert lo>F(9,10)
    return dict(phase='z=-1',ensemble='published',detector='joint, gamma=0',eps=0,q2_lower=str(lo),q2_upper=str(hi))

def main():
    tables={(r['ensemble'],int(r['id']),int(r['tail']),int(r['head'])):r for r in csv.DictReader((ROOT/'history_records.csv').open())}
    rng=np.random.default_rng(2026110403)
    checked=0
    for y,gen in [('published',old_ensemble()),('fixed',new_ensemble())]:
        for idx,k,l,edges in gen:
            if y=='published' and idx%12!=1:continue
            if y=='fixed' and idx%93!=1:continue
            defects=[(u,v) for u in range(3,len(edges)) for v in edges[u]]
            for u,v in (defects[0],defects[len(defects)//2],defects[-1]):
                graph,labels=lift(edges,(u,v));sources=[labels['old',j] for j in (0,1,2)]
                sink=labels['old',len(edges)-1];raw=explicit(graph,sources,sink)
                perm=rng.permutation(len(graph));new=[[] for _ in graph]
                for j,succ in enumerate(graph):new[perm[j]]=[perm[z] for z in succ]
                assert explicit(new,[perm[z] for z in sources],perm[sink])==raw
                row=tables[y,idx,u,v]
                reduced=Counter()
                for (s,f),w in raw.items():reduced[s,f.bit_count()]+=w
                stored={tuple(map(int,key.split('.'))):F(v) for key,v in (t.split('=') for t in row['polynomial'].split())}
                assert dict(reduced)==stored
                checked+=1
    models=polynomials();keys=(0,1,2,4,7)
    cols={}
    for r in csv.DictReader((ROOT/'coefficients.csv').open()):
        if r['ensemble']=='published':
            cols[int(r['k'])-1,int(r['b']),keys.index(int(r['sig'])),int(r['h']),int(r['residue'])]=F(r['w'])
    example=witness(cols)
    count=0
    for r in csv.DictReader((ROOT/'detector_boxes.csv').open()):
        u0,u1,v0,v1=0.,1.,0.,1.
        for i,bit in enumerate(r['path'][1:]):
            if i%2==0:
                m=(u0+u1)/2
                if bit=='0':u1=m
                else:u0=m
            else:
                m=(v0+v1)/2
                if bit=='0':v1=m
                else:v0=m
        for u,gamma in (((u0+u1)/2,(v0+v1)/2),(u0,v1),(u1,v0)):
            angle=int(r['quadrant'])*math.pi/2+2*math.atan(u)
            A=amplitudes(models[r['ensemble']],1,-angle/DELTA)
            mem=np.array([[gamma**(s^t).bit_count() for t in keys] for s in keys])
            M=A.sum(axis=1);D=M@mem@M.conj().T
            eps=2*sum(abs(D[i,j]) for i,j in itertools.combinations(range(3),2))/np.trace(D).real
            assert eps+1e-11>=float(F(r['lower']))
            count+=1
    # Every exact k=2 contribution agrees across ensembles (same measure and same geometry).
    assert np.array_equal(models['published'][1],models['fixed'][1])
    (ROOT/'validation.json').write_text(json.dumps(dict(direct_and_permuted=checked,certificate_checks=count,
               identical_k2=True,retrospective_example=example),indent=2)+'\n')
    print(checked,count,float(F(example['q2_lower'])),float(F(example['q2_upper'])))
if __name__=='__main__':main()
