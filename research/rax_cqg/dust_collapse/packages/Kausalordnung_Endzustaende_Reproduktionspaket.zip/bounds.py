"""Fixed-point outward arithmetic from the PR201 certificate."""
from fractions import Fraction as F
from math import isqrt
S=10**15
def ceil(n,d):return -((-n)//d)
def bound(x):
    x=F(x)
    return (x.numerator*S//x.denominator,ceil(x.numerator*S,x.denominator))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def mul(a,b):
    vals=[v*w for v in a for w in b]
    return (min(vals)//S,ceil(max(vals),S))
def root(a):
    assert a[0]>=0
    return (isqrt(a[0]*S),isqrt(a[1]*S)+1)
def plus(a,b):return (add(a[0],b[0]),add(a[1],b[1]))
def times(a,b):return (add(mul(a[0],b[0]),neg(mul(a[1],b[1]))),add(mul(a[0],b[1]),mul(a[1],b[0])))
def scale(z,s):return(mul(z[0],s),mul(z[1],s))
def rot(z):return(neg(z[1]),z[0])
def lower_mod(z):
    x,y=(max(a[0],-a[1],0) for a in z)
    return F(isqrt(x*x+y*y),S)
def upper_mod(z):
    x,y=(max(abs(a[0]),abs(a[1])) for a in z)
    return F(isqrt(x*x+y*y)+1,S)
