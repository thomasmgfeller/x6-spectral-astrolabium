"""Uniform cover subdivision and the original single-channel finite-sum gate."""
import csv,math,json,cmath
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
from height import ROOT,audit

def lift(edges, extra=None):
    # Keep a fresh vertex for every cover. Original vertices get even topological ranks.
    vertices=[('old',u) for u in range(len(edges))]
    records=[(u,v) for u,row in enumerate(edges) for v in row]
    vertices+=records
    rank=[0]*len(edges)
    for u in range(len(edges)):
        for v in edges[u]:rank[v]=max(rank[v],rank[u]+1)
    if extra is not None:vertices.append((*extra, 'second'))
    level=lambda x: 2*rank[x[1]] if x[0]=='old' else 2*rank[x[0]]+1
    vertices.sort(key=level)
    index={key:i for i,key in enumerate(vertices)}
    new=[[] for _ in vertices]
    for u,v in records:
        mid=index[u,v]
        new[index['old',u]].append(mid)
        new[mid].append(index['old',v])
    if extra is not None:
        u,v=extra
        mid=index[u,v,'second']
        new[index['old',u]].append(mid)
        new[mid].append(index['old',v])
    return new,index

def closure(edges):
    reach=[set() for _ in edges]
    for u in reversed(range(len(edges))):
        for v in edges[u]:
            reach[u].add(v);reach[u].update(reach[v])
    return reach

def paths(edges,u):
    if not edges[u]:
        yield (u,);return
    for v in edges[u]:
        for path in paths(edges,v):yield (u,)+path

def norm_exact(residues,divisor,on):
    # Return |A|^2 as a+b*sqrt(5), with the common matter phase divided out.
    if not on:return F(sum(residues)**2,divisor**2),F(0)
    a=F(0);b=F(0)
    for j,n in enumerate(residues):
        for k,m in enumerate(residues):
            d=(j-k)%5
            cos=(F(1),F(0)) if not d else ((F(-1,4),F(-1,4)) if d in (1,4) else (F(-1,4),F(1,4)))
            a+=n*m*cos[0];b+=n*m*cos[1]
    return a/divisor**2,b/divisor**2

def prod(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def positive(a,b):
    if a>=0 and b>=0:return a>0 or b>0
    if a<=0 and b<=0:return False
    if a>0:return a*a>5*b*b
    return 5*b*b>a*a
def main():
    records=[];groups={k:Counter() for k in (1,2,3)}
    for row in csv.DictReader((ROOT/'input/geometry_flux.csv').open()):
        edges=[list(map(int,s.split(','))) if s else [] for s in row['edges'].split('|')]
        new,index=lift(edges);future=closure(new);past=[{u for u in range(len(new)) if v in future[u]} for v in range(len(new))]
        layers=Counter(len(future[u]&past[v]) for u,z in enumerate(future) for v in z)
        Q=len(new)-layers[0]+9*layers[1]-16*layers[2]+8*layers[3]
        span,support,total=audit(new);assert span==9 and support>0
        routes=0
        for u in range(3):
            weight=F(0)
            for path in paths(new,index['old',u]):
                assert len(path)==9 and path[-1]==index['old',9]
                assert [len(future[p]&past[q]) for p,q in zip(path[::2],path[2::2])]==[1]*4
                weight+=F(1,math.prod(len(new[v]) for v in path[:-1]));routes+=1
            assert weight==1
        assert routes==sum(map(int,row['path_count_by_source'].split('/')))
        k=int(row['k']);groups[k][Q%5]+=1
        records.append(dict(id=row['id'],k=k,n=len(new),height=span,Q=Q,positive_endpoint_pairs=support,routes=routes))
    with (ROOT/'lifted_histories.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=records[0],lineterminator='\n');w.writeheader();w.writerows(records)
    out=[]
    for on in (False,True):
        norms={};amplitudes=[];coeff={}
        for k,cnt in groups.items():
            numbers=[cnt[j] for j in range(5)];div=math.factorial(k)*math.factorial(4-k)
            norms[k]=norm_exact(numbers,div,on)
            coeff[k]=dict(residues=numbers,squared_norm=[str(x) for x in norms[k]])
            amp=sum(n*cmath.exp(1j*(4*math.pi*j/5 if on else 0)) for j,n in enumerate(numbers))/div
            amplitudes.append(amp)
            assert abs(abs(amp)**2-(float(norms[k][0])+float(norms[k][1])*math.sqrt(5)))<1e-11
        s=tuple(sum(x[i] for x in norms.values()) for i in range(2));ss=prod(s,s)
        witness=None
        for k,l in combinations(norms,2):
            pair=prod(norms[k],norms[l]);a,b=[42**2*pair[i]-ss[i] for i in (0,1)]
            if positive(a,b):witness=(k,l);break
        diag=sum(abs(z)**2 for z in amplitudes)
        eps=2*sum(abs(z*w) for z,w in combinations(amplitudes,2))/diag
        q=[abs(z)**2/diag for z in amplitudes]
        issue=eps<1 and 2*eps/(1-eps)<=.10 and max(q)>=.8
        assert not (issue and witness is not None)
        out.append(dict(gravity_on=on,q=q,epsilon=eps,issue=issue,exact_exclusion_pair=witness,coefficients=coeff))
    summary=dict(histories=len(records),routes=sum(r['routes'] for r in records),
                 common_length=4*(24/math.pi)**.25,cases=out)
    (ROOT/'lift_result.json').write_text(json.dumps(summary,indent=2)+'\n')
    print([(r['q'],r['epsilon'],r['issue'],r['exact_exclusion_pair']) for r in out])
if __name__=='__main__':main()
