"""Exact representability check on all published 75 finite causal histories."""
import csv,hashlib
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def audit(edges):
    n=len(edges)
    assert all(0<=u<v<n for u,e in enumerate(edges) for v in e)
    future=[set() for _ in edges]
    longest=[1]*n
    for u in reversed(range(n)):
        for v in edges[u]:
            future[u].add(v);future[u].update(future[v])
            longest[u]=max(longest[u],1+longest[v])
    @lru_cache(None)
    def possible(a,b,depth):
        inside=[v for v in future[a] if b in future[v]]
        if depth==0:return bool(inside)
        return any(possible(a,v,depth-1) and possible(v,b,depth-1) for v in inside)
    pairs=[(a,b) for a in range(n) for b in future[a]]
    return max(longest),sum(possible(a,b,2) for a,b in pairs),len(pairs)

def main():
    infile=ROOT/'input'/'geometry_flux.csv'
    assert hashlib.sha256(infile.read_bytes()).hexdigest()=='2b1e3373a2631a48ca9519dd76983c75897e3d1c24be620e87add2a6547ede86'
    rows=[]
    for record in csv.DictReader(infile.open()):
        edges=[list(map(int,s.split(','))) if s else [] for s in record['edges'].split('|')]
        h,support,total=audit(edges)
        rows.append(dict(id=record['id'],height=h,pairs=total,admissible_four=support))
    with (ROOT/'finite_height.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys(),lineterminator='\n');w.writeheader();w.writerows(rows)
    assert len(rows)==75 and all(int(r['height'])==5 and not r['admissible_four'] for r in rows)
    for n in (8,9,10):
        h,s,total=audit([[j+1] if j+1<n else [] for j in range(n)])
        assert h==n and s==(n-8)*(n-7)//2
    print('75 orders, all height 5;',sum(r['pairs'] for r in rows),'ordered endpoint pairs, zero support')
if __name__=='__main__':main()
