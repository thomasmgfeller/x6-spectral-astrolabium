"""Sum over one unresolved pair of parallel events on each possible late cover."""
import cmath,csv,json,math
from fractions import Fraction as F
from itertools import combinations
from lift import ROOT,lift,closure,paths

def q_integer(edges):
    reach=closure(edges);past=[{j for j in range(len(edges)) if i in reach[j]} for i in range(len(edges))]
    coeff=(-1,9,-16,8)
    result=len(edges)+sum(coeff[h] for i,S in enumerate(reach) for j in S if (h:=len(S&past[j]))<4)
    # Independent bitset closure using Boolean row union and transitive successors.
    masks=[sum(1<<j for j in successors) for successors in edges]
    for i in reversed(range(len(edges))):
        for j in edges[i]:masks[i]|=masks[j]
    b=len(edges)
    for i,m in enumerate(masks):
        for j in range(len(edges)):
            if (m>>j)&1:
                h=sum(((m>>s)&1)*((masks[s]>>j)&1) for s in range(len(edges)))
                if h<4:b+=coeff[h]
    assert b==result
    return result,reach,past

def main():
    scores=[];maxdiff=0.;f1=(24/math.pi)**.25;delta=f1*(2**.25-1)
    classes={(g,e):{k:[] for k in (1,2,3)} for g in (0,1) for e in (0,1)}
    for base in csv.DictReader((ROOT/'input/geometry_flux.csv').open()):
        k=int(base['k'])
        edges=[list(map(int,s.split(','))) if s else [] for s in base['edges'].split('|')]
        covers=[(u,v) for u in range(3,len(edges)) for v in edges[u]]
        for u,v in covers:
            new,index=lift(edges,(u,v));Q,future,past=q_integer(new)
            hit=[]
            original={index['old',j]:j for j in range(len(edges))}
            for source in range(3):
                prob=F(0);total=F(0);ph=0j
                for route in paths(edges,source):
                    weight=F(1,math.prod(len(edges[j]) for j in route[:-1]))
                    used=(u,v) in zip(route,route[1:])
                    total+=weight;prob+=weight*used
                assert total==1;hit.append(prob)
                mass=F(0)
                for path in paths(new,index['old',source]):
                    pairs=list(zip(path[::2],path[2::2]))
                    counts=[len(future[a]&past[b]) for a,b in pairs]
                    assert len(counts)==4 and all(n in (1,2) for n in counts) and counts.count(2)<=1
                    den=math.prod(len(edges[original[a]]) for a,b in pairs)*math.prod(counts)
                    weight=F(1,den);mass+=weight
                    length=sum((24*n/math.pi)**.25 for n in counts)
                    ph+=float(weight)*cmath.exp(-1j*length)
                assert mass==1
                fact=cmath.exp(-4j*f1)*(1-float(prob)+float(prob)*cmath.exp(-1j*delta))
                maxdiff=max(maxdiff,abs(ph-fact));assert abs(ph-fact)<2e-13
            scores.append(dict(id=base['id'],k=k,tail=u,head=v,Q=Q,n=len(new),r0=str(hit[0]),r1=str(hit[1]),r2=str(hit[2]),ways=len(covers)))
            for (g,e),parts in classes.items():
                W=math.prod(1-float(r)+float(r)*cmath.exp(-1j*e*delta) for r in hit)
                # Overall matter phase exp(-12 i eta f1) is common and cancels in the gate.
                term=cmath.exp(1j*g*4*math.pi*(Q%5)/5)*W/(len(covers)*math.factorial(k)*math.factorial(4-k))
                parts[k].append(term)
    out=[]
    for (g,e),parts in classes.items():
        amps=[complex(math.fsum(z.real for z in terms),math.fsum(z.imag for z in terms)) for terms in parts.values()]
        diag=sum(abs(z)**2 for z in amps);qs=[abs(z)**2/diag for z in amps]
        eps=2*sum(abs(z*w) for z,w in combinations(amps,2))/diag
        issue=eps<1 and 2*eps/(1-eps)<=.1 and max(qs)>=.8
        out.append(dict(gravity_on=g,eta=e,q=qs,eps=eps,issue=issue,amplitudes=[[z.real,z.imag] for z in amps]))
    with (ROOT/'defect_histories.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=scores[0].keys(),lineterminator='\n');w.writeheader();w.writerows(scores)
    result=dict(histories=len(scores),varying=sum(any(0<F(r[s])<1 for s in ('r0','r1','r2')) for r in scores),
                delta=delta,max_factorization_error=maxdiff,cases=out)
    (ROOT/'defect_result.json').write_text(json.dumps(result,indent=2)+'\n');print([(r['q'],r['eps'],r['issue']) for r in out])
if __name__=='__main__':main()
