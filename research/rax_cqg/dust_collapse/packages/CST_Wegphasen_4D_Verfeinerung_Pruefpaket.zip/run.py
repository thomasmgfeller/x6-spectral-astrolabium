"""Paired subdivision experiment; all masks and partitions see one process per realization."""
import csv,json,math
from functools import lru_cache
import numpy as np
from scipy.stats import beta
from geometry import ROOT,C,LEVELS,MASKS,LAMBDAS,sample_counts,volume_tree,phase_values

REPS=32768;TARGET=8.;S=.10;A=.20;FAMILY=324
def csvout(name,rows):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)

@lru_cache(maxsize=None)
def pow_mean(lam):
    # Stable conditional expectation on a window numerically exhausting Poisson mass.
    mode=int(lam);span=math.ceil(16*math.sqrt(lam)+80)
    left=max(0,mode-span);right=mode+span
    w=np.ones(right-left+1);k=mode-left
    if mode>left:w[:k]=np.cumprod(np.arange(mode,left,-1)/lam)[::-1]
    w[k+1:]=np.cumprod(lam/np.arange(mode+1,right+1))
    w/=w.sum()
    return float(w @ np.arange(left,right+1)**.25)

def cp(k,n):
    alpha=.01/(2*FAMILY)
    lower=beta.ppf(alpha,k,n-k+1) if k else 0.
    upper=beta.isf(alpha,k+1,n-k) if k<n else 1.
    return (lower,upper,'pass' if lower>=.95 else 'fail' if upper<.95 else 'unresolved')
def main():
    cells=[];mom=[];trace=[];streams=np.random.SeedSequence(2026110307).spawn(12)
    for gi,model in enumerate(('flat','dust')):
        for li,lam in enumerate(LAMBDAS):
            rho=lam/C
            span,counts=sample_counts(model,rho,REPS,np.random.default_rng(streams[gi*6+li]))
            phi={n:phase_values(counts[n],rho) for n in LEVELS}
            for n in LEVELS:
                for mi,mask in enumerate(MASKS):
                    a=phi[n][:,mi];v=span[n][:,mi]
                    geometric=float(sum((v/C)**.25))
                    expected=sum(pow_mean(float(rho*b)) for b in v)/(rho*C)**.25
                    sd=a.std(ddof=1);z=(np.mean(a)-expected)/(sd/math.sqrt(REPS))
                    mom.append(dict(model=model,mask=mask,lam=lam,segments=n,min_interval_mean=min(rho*v),
                                    max_interval_mean=max(rho*v),population_volume_phase=geometric,
                                    geometry_mask_bias=geometric-8,expected_phase=expected,
                                    counting_bias=expected-geometric,measured_mean=a.mean(),sd=sd,mean_check_z=z))
                    for sample,value in enumerate(a[:16]):
                        trace.append(dict(model=model,lam=lam,sample=sample,mask=mask,segments=n,phase=value))
            for n in (1,2,4):
                for mi,mask in enumerate(MASKS):
                    coarse,fine=phi[n][:,mi],phi[n*2][:,mi]
                    delta=fine-coarse;stable=abs(delta)<=S
                    accurate=np.maximum(abs(coarse-TARGET),abs(fine-TARGET))<=A
                    row=dict(model=model,mask=mask,lam=lam,coarse=n,fine=n*2,reps=REPS,mean_delta=delta.mean(),
                             sd_delta=delta.std(ddof=1),q95_abs_delta=np.quantile(abs(delta),.95))
                    for key,flag in [('stability',stable),('accuracy',accurate),('joint',stable&accurate)]:
                        k=int(np.count_nonzero(flag));lb,ub,verdict=cp(k,REPS)
                        row.update({key+'_hits':k,key+'_lb':lb,key+'_ub':ub,key+'_decision':verdict})
                    cells.append(row)
    assert len(cells)*3==FAMILY
    csvout('gates.csv',cells);csvout('phase_means.csv',mom);csvout('sample_trace.csv',trace)
    maxz=max(abs(x['mean_check_z']) for x in mom);assert maxz<=7
    summary=dict(independent_realizations=12*REPS,paired_cells=len(cells),probability_intervals=FAMILY,
                 largest_standardized_mean_error=maxz,decisions={s:sum(x['joint_decision']==s for x in cells)
                                   for s in ('pass','fail','unresolved')})
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(summary)
if __name__=='__main__':main()
