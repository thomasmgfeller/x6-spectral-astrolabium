# Wegphasen unter Verfeinerung in vier Dimensionen

Ein Test auf bekannten vierdimensionalen Raumzeiten mit extern markierten, mitbewegten Wegpunkten. Die Zeit- und Phasenlänge sind in beiden Fällen exakt bekannt. Untersucht wird, wie genau und unterteilungsstabil sich die Phase aus den Zählungen auf derselben Poisson-Realisierung bestimmen lässt.

## Reproduktion

Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0 wurden eingesetzt. Die Rechnung läuft offline. Für einen schnellen und vergleichbaren Wiederholungslauf im entpackten Verzeichnis:

    sha256sum -c SHA256SUMS
    export OPENBLAS_NUM_THREADS=1
    python3 run.py
    python3 check_points.py
    python3 curvature.py
    python3 check_half.py

Die Prüfsummen beziehen sich auf die gelieferten Dateien. Andere Mathematikbibliotheken können letzte Gleitkommastellen verändern. Die 4D-Kontrollrechnung verwendet einige Millionen Punkte, die pro Realisierung verworfen werden. Die Hauptrechnung erzeugt die exakte Zählverteilung der disjunkten Poisson-Gebiete direkt.

## Inhalt

- design.json wurde vor der Hauptrechnung fixiert. half_design.json betrifft allein die separat geplante und mit frischen Stichproben geprüfte Halbebenenkorrektur. Die beiden Konfidenzfamilien sind getrennt.
- geometry.py implementiert Minkowski und die klassische Staubkontraktion, die beobachteten Vierervolumina und die gekoppelte Ziehung sämtlicher Unterteilungen und Masken.
- gates.csv enthält pro Geometrie, Dichte, Grenzlage und Unterteilungspaar sämtliche Trefferzahlen, zweiseitigen simultanen Grenzen und Entscheidungen sowie das empirische 95%-Quantil des absoluten Unterschieds. lambda_ref ("lam") ist die erwartete Anzahl im vollständigen flachen Intervall der Dauer eins, kein gemessenes Ereignisbudget der ganzen Region.
- phase_means.csv enthält die Spanne der tatsächlichen Intervallmittel, die Phase aus exakten Vierervolumina, den Poisson-Erwartungswert und die empirischen Einzelmittel und Streuungen. geometry_mask_bias fasst den Geometrie- und Beschnittanteil zusammen; der Randanteil bei gleichem Hintergrund ergibt sich durch Differenz zum vollen Gebiet.
- sample_trace.csv enthält gepaarte Phaseneinzelwerte der ersten 16 Realisierungen je Dichte und Geometrie. Die vollständigen Trefferzählungen stehen in gates.csv. Alle Realisierungen sind aus Design, Code und Seed reproduzierbar.
- point_counts.csv und point_check.json protokollieren unabhängige explizite Punktwolken, einen Boost-Test für flache Raumzeit und eine getrennte Volumenintegration. Ein band-Index von 0 steht für x<=0, 1 für 0<x<=0.5, 2 für x>0.5. Jeder Eintrag zählt Punkte im Teil des betreffenden Diamanten ausserhalb beider Kinddiamanten, bzw. im ganzen Blattdiamanten.
- curvature.csv gibt die direkte Integration und die geschlossene Staubformel numerisch gegeneinander. half_correction.csv enthält den unabhängigen Test des mittigen, symmetrischen Halbraums. summary.json zählt die Entscheidungen der Hauptprüfung.
- Pruefbericht.pdf enthält Ableitung, Reichweite und die nachgewiesene Skalengrenze. Der Versuch liefert keine Bewegung eines Staubballs aus einer Summe über Geometrien.

Vorgänger: [PR #198](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/198).
