"""Separate exact check of unclipped dust-diamond volumes via conformal midpoint moments."""
import math,json
from geometry import ROOT,C,LEVELS,eta,a_eta,volumes
from run import csvout
def main():
    rows=[]
    for n in LEVELS:
        for j in range(n):
            t0,t1=j*8/n,(j+1)*8/n;tau=t1-t0
            e0,e1=float(eta(t0,'dust')),float(eta(t1,'dust'));ec=(e0+e1)/2
            b=(e1-e0)/(2*(36-ec))
            U=12*(1-ec/36)**3
            assert abs(tau-(e1-e0)*a_eta(ec,'dust')*(1+b*b/3))<2e-13
            num=sum(math.comb(8,2*p)*b**(2*p)*24/math.prod(range(2*p+1,2*p+5)) for p in range(5))
            ratio=num/(1+b*b/3)**4
            V=volumes(t0,t1,'dust')[0]
            assert abs(V/(C*tau**4)-ratio)<2e-13
            rows.append(dict(n=n,j=j,tau=tau,U=U,b=b,exact_ratio=ratio,
                             volume_check_error=V/(C*tau**4)-ratio,first_order_ratio=1+2/135*(tau/U)**2))
    csvout('curvature.csv',rows);print('exact ratio max absolute disagreement',max(abs(x['volume_check_error']) for x in rows))
if __name__=='__main__':main()
