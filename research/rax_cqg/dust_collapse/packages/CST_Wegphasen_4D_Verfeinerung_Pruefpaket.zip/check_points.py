"""Independent explicit 4D Poisson point clouds for validation only, no fitting."""
import math,json
import numpy as np
from geometry import ROOT,C,LEVELS,eta,a_eta,volume_tree
from run import csvout
REPS=128;LAMBDA=4
def cloud(model,rho,rng):
    stop=float(eta(8.,model))
    n=rng.poisson(rho*C*stop**4)
    rt=stop/2*rng.random(n)**.25
    t=np.where(rng.random(n)<.5,rt,stop-rt)
    v=rng.normal(size=(n,3));v/=np.linalg.norm(v,axis=1)[:,None]
    xyz=v*(rt*rng.random(n)**(1/3))[:,None]
    if model=='dust':
        keep=rng.random(n)<a_eta(t,model)**4
        t=t[keep];xyz=xyz[keep]
    return t,xyz
def main():
    rows=[];checks={};seeds=np.random.SeedSequence(2026110317).spawn(2)
    for gi,model in enumerate(('flat','dust')):
        volumes,atoms,volerr=volume_tree(model);rho=LAMBDA/C
        counts={n:np.zeros((n,3),dtype=np.int64) for n in LEVELS}
        rng=np.random.default_rng(seeds[gi]);net=0
        for rep in range(REPS):
            t,xyz=cloud(model,rho,rng);net+=len(t)
            radius=np.linalg.norm(xyz,axis=1); total={}
            for n in LEVELS:
                arr=[]
                for j in range(n):
                    start,end=(float(eta(i*8/n,model)) for i in (j,j+1))
                    inside=(radius<t-start)&(radius<end-t)
                    if model=='flat':
                        # Boost in x by 0.6, with both endpoints transformed.
                        v=.6;gamma=1.25
                        tb=gamma*(t-v*xyz[:,0]);xb=gamma*(xyz[:,0]-v*t)
                        trans=xyz[:,1]**2+xyz[:,2]**2
                        iv=(tb-gamma*start>np.sqrt((xb+gamma*v*start)**2+trans))&(gamma*end-tb>np.sqrt((xb+gamma*v*end)**2+trans))
                        assert np.array_equal(iv,inside)
                    x=xyz[inside,0]
                    arr.append([np.count_nonzero(x<=0),np.count_nonzero((x>0)&(x<=.5)),np.count_nonzero(x>.5)])
                total[n]=np.array(arr,dtype=np.int64)
            assert int(total[1].sum())==len(t)
            for n in LEVELS:
                arr=total[n].copy()
                if n<8:arr-=total[2*n].reshape(n,2,3).sum(axis=1)
                assert np.all(arr>=0);counts[n]+=arr
        peak=0.
        for n in LEVELS:
            for j in range(n):
                for band in range(3):
                    obs=int(counts[n][j,band]);mean=float(rho*atoms[n][j,band]*REPS)
                    if mean<1e-12:assert obs==0
                    z=(obs-mean)/math.sqrt(mean) if mean>1e-12 else 0.
                    peak=max(peak,abs(z))
                    rows.append(dict(model=model,segments=n,slot=j,band=band,count=obs,expected=mean,z=z))
        assert peak<=7
        checks[model]=dict(reps=REPS,explicit_points=net,max_abs_atom_z=peak,volume_quad_relative_error=volerr,
                           boost_membership_checked=(model=='flat'))
    csvout('point_counts.csv',rows)
    (ROOT/'point_check.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(checks)
if __name__=='__main__':main()
