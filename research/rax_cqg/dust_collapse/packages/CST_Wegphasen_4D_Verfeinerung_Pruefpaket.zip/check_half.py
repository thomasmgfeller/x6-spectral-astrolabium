"""Secondary independent validation of the analytically specified centered-plane correction."""
import json
import numpy as np
from scipy.stats import beta
from geometry import ROOT,C,sample_counts,phase_values
from run import csvout
REPS=32768
def main():
    rows=[];seeds=np.random.SeedSequence(2026110327).spawn(4)
    for gi,model in enumerate(('flat','dust')):
        for li,lam in enumerate((128,512)):
            rho=lam/C
            _,n=sample_counts(model,rho,REPS,np.random.default_rng(seeds[2*gi+li]))
            a,b=[2**.25*phase_values(n[m],rho)[:,2] for m in (4,8)]
            hits=int(np.count_nonzero((abs(b-a)<=.10)&(np.maximum(abs(a-8),abs(b-8))<=.20)))
            tail=.01/(2*4)
            lo=beta.ppf(tail,hits,REPS-hits+1) if hits else 0.
            hi=beta.isf(tail,hits+1,REPS-hits) if hits<REPS else 1.
            decision='pass' if lo>=.95 else 'fail' if hi<.95 else 'unresolved'
            rows.append(dict(model=model,lam=lam,effective_lam=lam/2,reps=REPS,hits=hits,
                             lower=lo,upper=hi,predicted='fail' if lam==128 else 'pass',decision=decision))
    csvout('half_correction.csv',rows);print(rows)
if __name__=='__main__':main()
