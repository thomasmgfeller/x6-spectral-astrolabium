"""Volumes for a comoving marked geodesic on two four-dimensional backgrounds."""
import math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parent
C=math.pi/24
LEVELS=(1,2,4,8)
MASKS=('full','near','half')
LAMBDAS=(1,4,16,64,256,1024)
G,W=np.polynomial.legendre.leggauss(8)
def eta(t,model):
    if model=='flat':return np.asarray(t)
    return -36*np.expm1(np.log1p(-np.asarray(t)/12)/3)
def t_of(e,model):
    if model=='flat':return np.asarray(e)
    return -12*np.expm1(3*np.log1p(-np.asarray(e)/36))
def a_eta(e,model):
    return 1. if model=='flat' else (1-np.asarray(e)/36)**2
def cross_section(r,mask):
    sphere=(4*math.pi/3)*r**3
    if mask=='full':return sphere
    if mask=='half':return .5*sphere
    delta=.5
    return sphere-math.pi/3*np.maximum(0.,r-delta)**2*(2*r+delta)

def volumes(ti,tf,model):
    lo,hi=float(eta(ti,model)),float(eta(tf,model))
    knots={lo,hi,(lo+hi)/2}
    if .5<(hi-lo)/2:knots.update((lo+.5,hi-.5))
    knots=sorted(knots);result=np.zeros(3)
    for x,y in zip(knots,knots[1:]):
        e=(x+y)/2+(y-x)*G/2
        R=np.minimum(e-lo,hi-e)
        for m,mask in enumerate(MASKS):
            result[m]+=(y-x)/2*np.dot(W,cross_section(R,mask)*a_eta(e,model)**4)
    return result

def physical_quad(ti,tf,model,mask):
    # Alternate variable and independent expression for the clipped section.
    def et(t):
        return t if model=='flat' else 36*(1-(1-t/12)**(1/3))
    lo,hi=et(ti),et(tf)
    def back(e):
        return e if model=='flat' else 12*(1-(1-e/36)**3)
    def integrand(t):
        r=min(et(t)-lo,hi-et(t))
        cut=r if mask=='full' else 0. if mask=='half' else min(.5,r)
        disk=math.pi*(r*r*cut-cut**3/3+2*r**3/3)
        a=1 if model=='flat' else (1-t/12)**(2/3)
        return a**3*disk
    knots=[(lo+hi)/2]
    if mask=='near' and hi-lo>1:knots+=[lo+.5,hi-.5]
    return quad(integrand,ti,tf,points=sorted(set(back(e) for e in knots)),epsabs=1e-11)[0]

def volume_tree(model):
    spans={};bands={};atoms={};maxerr=0.
    for n in LEVELS:
        spans[n]=np.array([volumes(j*8/n,(j+1)*8/n,model) for j in range(n)])
        for j,values in enumerate(spans[n]):
            for m,mask in enumerate(MASKS):
                other=physical_quad(j*8/n,(j+1)*8/n,model,mask)
                maxerr=max(maxerr,abs(other-values[m])/values[m])
                assert abs(other-values[m])<1e-10*values[m]
            assert abs(values[2]-.5*values[0])<=1e-12*values[0]
            if model=='flat':assert abs(values[0]-C*(8/n)**4)<1e-12*values[0]
        full,near,half=spans[n].T
        bands[n]=np.stack((half,near-half,full-near),axis=1)
    for n in LEVELS:
        unit=bands[n].copy()
        if 2*n in bands:unit-=bands[2*n].reshape(n,2,3).sum(axis=1)
        assert unit.min()>=-1e-11
        atoms[n]=np.maximum(0.,unit)
    return spans,atoms,maxerr

def sample_counts(model,rho,reps,rng):
    span,atoms,_=volume_tree(model);counts={}
    for n in reversed(LEVELS):
        local=rng.poisson(rho*atoms[n],size=(reps,n,3))
        if 2*n in counts:local+=counts[2*n].reshape(reps,n,2,3).sum(axis=2)
        counts[n]=local
    return span,counts

def phase_values(counts,rho):
    all_counts=np.stack((counts.sum(axis=2),counts[:,:,:2].sum(axis=2),counts[:,:,0]),axis=2)
    return (all_counts.astype(float)**.25).sum(axis=1)/(C*rho)**.25
