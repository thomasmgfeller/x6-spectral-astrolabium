"""Independent cylindrical sections, end-to-end cross-check and summary."""
import json
import math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from run_spatial import HERE, R, cfg, temporal, build, solve


def overlap_validation():
    worst=0.
    for s in (0,.01,.25,.7,1.,1.2,1.99,2.,2.1):
        # Units with R=1. Two identical caps cut at the midplane.
        upper=min(s,2)
        both=2*quad(lambda z:np.pi*(1-z*z),upper/2,1)[0]/(4*np.pi/3)
        out=.75*s-s**3/16 if s<2 else 1.
        worst=max(worst,abs((1-both)-out))
    assert worst<1e-13
    return worst


def main():
    geom=overlap_validation()
    shell,cyl=build(),build(cylindrical=True)
    worst=0.; checked=0
    for u in (0.,.005,.1,.31,.49,.5,.79,.94,1.):
        for v in (0.,.0001,.11,1/3,.55,.89,.999,1.):
            for d in (.12,.5,.599):
                a,b=np.zeros(2),np.zeros(2)
                shell.section(u,v,d,a);cyl.section(u,v,d,b)
                assert a[0]>=-1e-14 and -1e-14<=a[1]<=a[0]+1e-14
                worst=max(worst,float(np.max(abs(a-b))))
                checked+=1
    assert worst<1e-12, worst
    cases=[json.loads(s) for s in (HERE/'spatial.jsonl').read_text().splitlines()]
    result={}
    for name in 'AB':
        by={r['order']:r for r in cases if r['window']==name}
        check=solve(cyl,name,40)
        last=by[72]
        def vector(r):return np.array(r['inside']+r['outside'])
        kernel_gap=float(np.max(abs(vector(check)-vector(by[40]))))
        finer_gap=float(np.max(abs(vector(last)-vector(by[56]))))
        assert kernel_gap<1e-7 and finer_gap<1e-7
        assert last['max_time_response_delta']<1e-7 and abs(last['mean_delta'])<1e-7
        a,b,I,O=(np.array(last[k]) for k in ('inside','outside','volumes_inside','volumes_outside'))
        gains=I*O/(I+O)*(a/I-b/O)**2/cfg['lambda']
        assert abs(sum(gains)-(last['sd']**2-last['sd_time']**2))<1e-15
        result[name]=dict(spatial_sd=last['sd'],temporal_sd=temporal[name]['sd'],
                          cap_sd=cfg['windows'][name]['published_sd_floor'],
                          ratio_time=last['sd']/temporal[name]['sd'],
                          gain_shares=(gains/sum(gains)).tolist(),refinement_gap=finer_gap,
                          all_responses_cylinder_gap=kernel_gap,cylinder=check)
    print(json.dumps(dict(section_cases=checked,section_max_abs_error=worst,
                          overlap_max_abs_error=geom,windows=result),indent=2))


if __name__=='__main__':
    main()
