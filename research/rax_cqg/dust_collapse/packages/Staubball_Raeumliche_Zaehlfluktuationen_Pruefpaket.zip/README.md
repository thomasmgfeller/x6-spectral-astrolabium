# Räumliche Zählfluktuationen des normierten Staubmassestroms

Dieser lokale Rechenversuch folgt auf PR 204 im Repository thomasmgfeller/x6-spectral-astrolabium. Betrachtet werden die beiden ursprünglichen Zeitfenster und die vier vorab übernommenen Zeitabschnitte. Pro Zeitabschnitt werden das Innere der mitbewegten Kugel und das übrige endliche Einflussgebiet getrennt gezählt. Die Gleichungen, Ergebnisse und Grenzen sind im PDF zusammengefasst.

## Reproduktion

Benötigt werden Linux, g++ mit C++17 und OpenMP sowie Python, NumPy und für die Geometriekontrolle SciPy. Getestet wurde mit GCC 13.3.0, Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0. Beide Skripte bauen die lokal benötigten Rechenkerne. Alle Quadraturen laufen ohne Netzwerk und ohne neue Punktwolken. Im entpackten Verzeichnis ausführen.

```sh
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4 python3 run_spatial.py > spatial.jsonl
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4 python3 check_spatial.py > checks.json
```

Die Prüfsummen gelten für den Auslieferungsstand. Eine andere Plattform kann in den letzten Gleitkommastellen abweichen. Das zweite Skript prüft mit Toleranzen und benötigt den vollständigen Standardlauf des ersten Skripts.

## Inhalt

- `design.json` legt die Partition fest. `reference_inputs.json` übernimmt die Parameter der Zeitrechnung, `temporal_values.json` die vier publizierten Zeitantworten aus der feinsten Auflösung je Fenster.
- `spatial.cpp` berechnet die Antworten und die räumlich gewichteten Lichtkegellinsen in Kugelschalen. `cylinder.inc` integriert die Linsen unabhängig über axiale Kreisscheiben. Die äusseren Zeit- und Paarintegrale sind gemeinsam.
- `spatial.jsonl` protokolliert fünf Quadraturgrade für beide Fenster einschliesslich der groben Kontrollstufe. Grad 72 dient der Ergebnisangabe. `checks.json` umfasst die 216 Geometriekontrollen, den vollständigen Vergleich beider Integrationsmethoden bei Grad 40 und die Anteile der vier Zeitabschnitte am zusätzlichen Varianzbeitrag.
- `spatial_report.tex` ist die Quelle des dreiseitigen Berichts.

Die Zahlen sind konvergenzgeprüfte Auswertungen einer exakten Projektionsungleichung. Eine garantierte numerische Fehlereinschliessung und die Band-Trefferwahrscheinlichkeit sind weiterhin offen.

[Zeitliche Referenz, PR 204](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/204)
