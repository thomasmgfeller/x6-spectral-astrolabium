"""Compute the eight count responses. Run from this directory; Linux, g++ and NumPy."""
import ctypes
import json
import math
import os
import subprocess
import sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OMP_DYNAMIC','FALSE')
cfg=json.loads((HERE/'reference_inputs.json').read_text())
temporal=json.loads((HERE/'temporal_values.json').read_text())
R=(3/(4*np.pi))**(1/3)

def build(cylindrical=False):
    so=HERE/('cylinder_native.so' if cylindrical else 'spatial_native.so')
    flags=['-DX6_CYLINDRICAL'] if cylindrical else []
    subprocess.run(['g++',*flags,'-std=c++17','-O3','-fPIC','-shared','-fopenmp','-ffp-contract=off',
                    str(HERE/'spatial.cpp'),'-o',str(so)],check=True)
    dll=ctypes.CDLL(str(so))
    arr=np.ctypeslib.ndpointer(dtype=np.float64,ndim=1,flags='C_CONTIGUOUS')
    dll.solve.argtypes=[ctypes.c_int,arr,arr,ctypes.c_int,arr,arr,arr,ctypes.c_double,arr,arr]
    dll.solve.restype=None
    dll.section.argtypes=[ctypes.c_double,ctypes.c_double,ctypes.c_double,arr]
    dll.section.restype=None
    return dll

def moment_table():
    f=math.factorial
    a=np.zeros((5,5))
    for j in range(5):
        for k in range(5-j):
            m=192*f(2*j)*f(2*k+3)/(f(2*j+2*k+4)*2**(2*j+2*k+4)*(2*k+1)*(2*k+3))
            a[j,k]=m*f(8)/(f(8-2*j-2*k)*f(2*j)*f(2*k))
    return a.ravel()

def rule(n):
    nodes,w=np.polynomial.legendre.leggauss(n)
    return (1+nodes)/2,w/2

def solve(dll,name,n):
    case=cfg['windows'][name]
    old=temporal[name]
    edges=np.array(old['edges'])
    xs,ws=rule(n)
    ts,wt=rule(8)
    out=np.zeros(9)
    T=edges[-1]
    eta=lambda t:-3*np.expm1(np.log1p(-t)/3)
    assert eta(T)-eta(edges[0])<2*R
    dll.solve(n,xs,ws,len(ts),ts,wt,edges,case['Rpred'],moment_table(),out)
    inside=out[1:5];outside=out[5:]
    vi=((1-edges[:-1])**3-(1-edges[1:])**3)/3
    gx,gw=rule(24)
    t=edges[:-1,None]+np.diff(edges)[:,None]*gx
    vo=np.diff(edges)*(((1-t)**2*((1+(eta(T)-eta(t))/R)**3-1))@gw)
    assert np.all(vi>0) and np.all(vo>0)
    assert np.max(abs(vi+vo-np.array(old['volumes'])))<1e-12
    sd=float(np.sqrt(np.sum(inside**2/vi+outside**2/vo)/cfg['lambda']))
    sd_time=float(np.sqrt(np.sum((inside+outside)**2/(vi+vo))/cfg['lambda']))
    assert sd>=sd_time-1e-14
    return dict(order=n,mean=out[0],inside=inside.tolist(),outside=outside.tolist(),
                volumes_inside=vi.tolist(),volumes_outside=vo.tolist(),sd=sd,sd_time=sd_time,
                max_time_response_delta=float(np.max(abs(inside+outside-np.array(old['slab_responses'])))),
                mean_delta=float(out[0]-case['mean']))

if __name__=='__main__':
    dll=build()
    for rank in map(int,sys.argv[1:] or (20,30,40,56,72)):
        for name in 'AB':
            record={'window':name,**solve(dll,name,rank)}
            print(json.dumps(record),flush=True)
