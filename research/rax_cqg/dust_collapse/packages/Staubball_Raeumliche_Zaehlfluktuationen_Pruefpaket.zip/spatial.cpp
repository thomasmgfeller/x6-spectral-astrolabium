// Deterministic integral for first derivatives of the fixed smoothed dust mass.
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

namespace {
constexpr double pi = 3.14159265358979323846, mu = 600000.;
const double R = std::cbrt(3./(4*pi));
double sq(double x) { return x*x; }
double cube(double x) { return x*x*x; }
double eta(double t) { return -3*std::expm1(std::log1p(-t)/3); }
double power8(double a) { double b=sq(sq(a)); return b*b; }
double outside(double length) {
    const double r=length/R;
    return r < 2 ? r*(.75-r*r/16) : 1.;
}
struct Measures { double all, out; };
// Normalized radial coordinate w=|z-x|/d; returned volumes exclude pi*d^3.
Measures shell(double u, double v, double d) {
    const double xx=1-u, yy=u, small=std::min(xx, yy);
    const double all = v <= std::abs(1-2*u) ? (4./3)*cube(small)
        : sq(1-v)*(sq(v)+2*v-3*sq(2*u-1))/(12*v);
    const double full=std::min(xx,std::max(0.,yy-v));
    const double lin=.75*d/R, cubic=cube(d/R)/16;
    double out=4*sq(sq(full))*(lin/4-cubic*sq(full)/6);
    const double low=std::abs(yy-v), high=std::min(xx,yy+v);
    if (low < high && v>0) {
        // Four-point Gauss integrates the degree-six radial polynomial exactly.
        constexpr double t[4]={.06943184420297371,.33000947820757187,.6699905217924281,.9305681557970262};
        constexpr double w[4]={.17392742256872693,.32607257743127307,.32607257743127307,.17392742256872693};
        double part=0;
        for(int k=0;k<4;++k) {
            const double rho=low+(high-low)*t[k];
            part+=w[k]*sq(rho)*(lin-cubic*sq(rho))*(yy-(rho-v))*(yy+(rho-v));
        }
        out+=part*(high-low)/v;
    }
    return {all,out};
}
#ifdef X6_CYLINDRICAL
#include "cylinder.inc"
#endif
Measures slice(double u,double v,double d) {
#ifdef X6_CYLINDRICAL
    return cylinder(u,v,d);
#else
    return shell(u,v,d);
#endif
}
using Sum=std::array<long double,9>; // mean, inner responses, outer responses
}
extern "C" void section(double u,double v,double d,double *output){
    auto a=slice(u,v,d);output[0]=a.all;output[1]=a.out;
}
extern "C" void solve(int n,const double *nodes,const double *weights,
                      int nt,const double *tn,const double *tw,const double *edge,
                      double norm,const double *mom,double *answer) {
    std::array<double,5> e;
    for(int j=0;j<5;++j)e[j]=eta(edge[j]);
    std::vector<Sum> per_y(2*n,Sum{});
    #pragma omp parallel for schedule(dynamic,1)
    for(int yi=0;yi<2*n;++yi) {
        int yj=yi/n, iy=yi%n;
        double y=edge[yj]+nodes[iy]*(edge[yj+1]-edge[yj]), ey=eta(y);
        auto &result=per_y[yi];
        for(int xj=2;xj<4;++xj) for(int ix=0;ix<n;++ix) {
            const double x=edge[xj]+nodes[ix]*(edge[xj+1]-edge[xj]), d=eta(x)-ey;
            const double tm=1-(ey+d/2)/3, ratio=sq(d/(3*tm));
            double poly[5]={};
            for(int k=0;k<5;++k)for(int j=0;j<5-k;++j)
                poly[k]+=mom[5*j+k]*std::pow(ratio,j+k);
            const double zfac=mu*pi/24*sq(sq(d))*power8(tm);
            const double factor=(edge[yj+1]-edge[yj])*(edge[xj+1]-edge[xj])*weights[iy]*weights[ix]
                        *(x-y)*sq(1-y)*cube(d);
            std::array<double,5> slab{};
            for(int j=0;j<5;++j)slab[j]=std::clamp((e[j]-ey)/d,0.,1.);
            std::array<double,14> abreak{};
            int na=3;
            abreak[0]=0; abreak[1]=1./3; abreak[2]=1;
            for(int j=yj+1;j<=xj;++j) {
                abreak[na++]=std::abs(1-2*slab[j]);
                abreak[na++]=slab[j];
            }
            std::sort(abreak.begin(),abreak.begin()+na);
            for(int h=1;h<na;++h) {
                double vl=abreak[h-1], width=abreak[h]-vl;
                if(width==0)continue;
                for(int iv=0;iv<n;++iv) {
                    const double v=vl+width*nodes[iv],v2=v*v;
                    double pol=poly[4];
                    for(int k=3;k>=0;--k)pol=pol*v2+poly[k];
                    const double z=zfac*sq((1-v)*(1+v))*pol, ez=std::exp(-z);
                    if(ez==0) continue;
                    const double K=ez*(1+z*(-9+z*(8-4*z/3)));
                    const double Kp=ez*(-10+z*(25+z*(-12+4*z/3)));
                    const double weight=factor*width*weights[iv]*v2;
                    result[0]+=weight*K;
                    const double hy=outside(d*v);
                    result[1+xj]+=weight*K;
                    result[1+yj]+=weight*(1-hy)*K;
                    result[5+yj]+=weight*hy*K;
                    const double zscale=mu*pi*sq(sq(d));
                    std::array<double,3> shape{{(1-v)/2,(1+v)/2,v}};
                    std::sort(shape.begin(),shape.end());
                    for(int j=yj;j<=xj;++j) {
                        double left=slab[j], stop=slab[j+1], zin=0, zout=0;
                        auto interval=[&](double right) {
                            double span=right-left;
                            for(int t=0;t<nt;++t) {
                                double u=left+span*tn[t];
                                double jac=span*tw[t]*power8(1-(ey+d*u)/3);
                                auto s=slice(u,v,d);
                                zin+=jac*(s.all-s.out);
                                zout+=jac*s.out;
                            }
                            left=right;
                        };
                        for(double p:shape)if(left<p&&p<stop)interval(p);
                        if(left<stop)interval(stop);
                        result[1+j]+=weight*Kp*zscale*zin;
                        result[5+j]+=weight*Kp*zscale*zout;
                    }
                }
            }
        }
    }
    for(int k=0;k<9;++k) {
        long double s=0;
        for(const auto &row:per_y)s+=row[k];
        answer[k]=static_cast<double>(-8*pi*std::pow(mu,1.5)/(std::sqrt(6.)*norm)*s);
    }
}
