"""Timing only: the mass sums stay internal to the kernel and are discarded."""
import csv, ctypes, hashlib, json, math, os, subprocess, sys, tempfile, time, zipfile
from pathlib import Path
import numpy as np
from numpy.ctypeslib import ndpointer

HERE=Path(__file__).resolve().parent
def estimate(root, archive):
    assert hashlib.sha256(archive.read_bytes()).hexdigest()=='293abfb2a6854b1a33982d6accc5354838b0573fc2958b9e7212599ba78fe585'
    with zipfile.ZipFile(archive) as z:z.extractall(root)
    os.chdir(root);sys.path.insert(0,str(root))
    from cap_geometry import eta, time_of_eta, draw_cap, draw_exterior
    from cap_run import compile_kernel,load
    from weights import layer_table
    compile_kernel(); kernel=load()
    plan=json.loads((HERE/'pair_design.json').read_text())
    seed=plan['cost_only_namespace']; lam=plan['input_density']; s=plan['cut']
    top=s+plan['future']; base=top-2.75*1200000**(-.25)
    q0,q1,qb=eta(s-plan['past']),eta(top),eta(base)
    radius=q1-qb
    assert base>s and radius<(3/(4*math.pi))**(1/3)
    w,_=layer_table(plan['effective_density']/lam)
    runs=[]
    for i in range(2):
        rng=np.random.default_rng(np.random.SeedSequence([seed,1,lam,i]))
        sample_rng=np.random.default_rng(np.random.SeedSequence([seed,1,lam,i,97]))
        start=time.process_time()
        qe,pos=draw_exterior(rng,q0,qb,q1,radius,lam); caps=[draw_cap(rng,qb,q1,lam) for _ in range(2)]
        setup=time.process_time()-start; support=[]; estim=0.
        for qc,xx in caps:
            start=time.process_time()
            ix=np.argsort(np.r_[qe,qc]); q=np.r_[qe,qc][ix];t=time_of_eta(q)
            xyz=np.r_[pos,xx][ix]; ids=np.flatnonzero(ix>=len(qe))
            setup+=time.process_time()-start
            for group in np.array_split(ids,4):
                pick=np.asarray(sorted(sample_rng.choice(group,2,replace=False)),dtype=np.int32)
                ignored=np.zeros(2)
                start=time.process_time()
                kernel(len(q),t,q,xyz,pick,len(pick),s,w,len(w),ignored)
                elapsed=time.process_time()-start
                support.append(dict(population=len(group),timed=2,cpu_seconds=elapsed))
                estim+=len(group)*elapsed/2
        runs.append(dict(cost_index=i,exterior=len(qe),cap_sizes=[len(c[0]) for c in caps],
                         groups=support,setup_cpu=setup,projected_pair_cpu_seconds=setup+estim,
                         projected_149_core_hours=(setup+estim)*149/3600))
        print('Cost fixture',i,'complete',file=sys.stderr,flush=True)
    return dict(cases=runs,method='Stratified endpoint extrapolation on the archived sequential cap kernel; two fixtures; not a guaranteed runtime.',
                cpu=next((l.split(':',1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),None))
if __name__=='__main__':
    archive=Path(sys.argv[1]).resolve()
    with tempfile.TemporaryDirectory() as tmp:
        old=Path.cwd()
        try: results=estimate(Path(tmp),archive)
        finally:os.chdir(old)
    print(json.dumps(results,indent=2))
