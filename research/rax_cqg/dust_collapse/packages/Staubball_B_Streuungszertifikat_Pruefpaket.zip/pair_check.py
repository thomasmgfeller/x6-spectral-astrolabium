"""Audit archived cap controls and construct an exact fixed-sample binomial design."""
import csv, hashlib, io, json, sys, zipfile
from fractions import Fraction as F
from math import comb
from pathlib import Path
from scipy.stats import beta

def tail(n,k,p):
    return sum(F(comb(n,j))*p**j*(1-p)**(n-j) for j in range(k,n+1))

def main(archive):
    assert hashlib.sha256(archive.read_bytes()).hexdigest()=='293abfb2a6854b1a33982d6accc5354838b0573fc2958b9e7212599ba78fe585'
    with zipfile.ZipFile(archive) as z:
        def rows(name): return list(csv.DictReader(io.StringIO(z.read(name).decode())))
        e=next(r for r in rows('expectations.csv') if r['j']=='1' and r['lam']=='600000')
        norm=F(e['Rpred']); caps=rows('caps.csv'); ext=rows('extension.csv')
    cases={}
    for name,records in [('small_low',[r for r in caps if r['j']=='1' and r['lam']=='1200000']),
                         ('small_high',[r for r in caps if r['j']=='1' and r['lam']=='6000000']),
                         ('large_low',ext)]:
        lo=hi=0
        assert len({int(r['run']) for r in records})==len(records)
        for r in records:
            if 'a' in r:
                d=abs(F(r['a'])-F(r['b']));err=F(r['error'])
            else:
                d=abs(F(r['sm0'])-F(r['sm1']));err=F(r['err0'])+F(r['err1'])
            lo+=d-err>norm/5
            hi+=d+err>norm/5
        cases[name]=dict(n=len(records),definite=lo,possible=hi)
    assert cases['small_high']==dict(n=128,definite=0,possible=0)
    assert cases['large_low']==dict(n=40,definite=20,possible=20)
    n=149;k=24;p0=F(39,400)
    assert p0==1-F(95,100)**2
    error=tail(n,k,p0);power=tail(n,k,F(1,5))
    assert error<F(1,100)<tail(n,k-1,p0) and power>F(9,10)
    return dict(archive_cases=cases,n=n,cutoff=k,alpha_null=float(error),
                power_if_q_20pct=float(power),power_if_q_15pct=float(tail(n,k,F(15,100))),
                single_study_cp_lower_if_24=float(beta.ppf(.01,k,n-k+1)),
                small_high_one_sided_99pct_upper=1-.01**(1/128),
                basis='Fixed cap geometry, iid pairs, one-sided size 1%; historical different-density controls do not supply power in the new cell.')
if __name__=='__main__':
    if not __debug__: raise SystemExit('Run without -O.')
    print(json.dumps(main(Path(sys.argv[1])),indent=2))
