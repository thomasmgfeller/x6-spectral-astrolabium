"""Check the boosted-diamond polynomial against direct light-cone slices."""
import json
from fractions import Fraction as F
from certify import A, ball, F0, F6, CF, CENTER, SCALE, P_BALL, MU, horner, lens_coeff, rule

def compare():
    cases=0; widest=A(0)
    for y0,x0 in (('0.26','0.58'),('0.48','0.64'),('0.55','0.75'),('0.56','0.58')):
        y=ball(y0);x=ball(x0);m=(x+y)/2;d=x-y
        for speed in ('0','0.13','0.5','0.91','0.999'):
            v=ball(speed);v2=v**2
            pref=CF*d**4*(1-v2)**2
            target=[pref*horner(lens_coeff(f,m,d),v2) for f in (F0,F6)]
            integral=[A(0),A(0)]
            bounds=[F(0),(1-F(speed))/2,(1+F(speed))/2,F(1)]
            for zone,(a,b) in enumerate(zip(bounds,bounds[1:])):
                if a==b: continue
                for node,w in rule(10,1):
                    u=ball(a)+ball(b-a)*node
                    if zone==0: geom=4*u**3/3
                    elif zone==2: geom=4*(1-u)**3/3
                    else: geom=(1-v)**2*(v2+2*v-3*(2*u-1)**2)/(12*v)
                    t=y+d*u
                    term=MU*A.pi()*d**4*ball(b-a)*w*geom*(1-t/3)**8
                    integral[0]+=term
                    integral[1]+=term*horner(P_BALL,(t-CENTER)/SCALE)
            for direct,boosted in zip(integral,target):
                diff=direct-boosted
                assert diff.contains(0) and abs(diff)<ball('1e-24')
                widest=widest.max(abs(diff).upper())
            cases+=1
    return dict(geometries=cases,paired_moments=2*cases,max_difference_enclosure_abs=str(widest))
if __name__=='__main__':
    if not __debug__: raise SystemExit('Run without -O.')
    print(json.dumps(compare(),indent=2))
