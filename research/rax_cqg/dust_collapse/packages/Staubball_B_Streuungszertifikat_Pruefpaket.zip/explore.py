import math,numpy as np
from scipy.special import roots_legendre
from numpy.polynomial import Polynomial as P
from numpy.polynomial.legendre import Legendre
from math import factorial as f,comb
def eta(T): return 3*(-np.expm1(np.log1p(-T)/3))
def time(t): return 1-(1-t/3)**3
L,S,H=map(eta,(.23,.47,.58))
# rational centering and scaling near endpoints
center=.49; scale=.255
mu=600000; lam=6000000; norm=1.2871411680612763
def mjk(j,k):
 return 192*f(2*j)*f(2*k+3)/(f(2*j+2*k+4)*2**(2*j+2*k+4)*(2*k+1)*(2*k+3))
def nodes(n):
 v,w=roots_legendre(n);return (1+v)/2,w/2
def run(n=75,deg=7):
 v,w=nodes(n); y=L+(S-L)*v[None,:,None];x=S+(H-S)*v[:,None,None];r=v[None,None,:];d=x-y;m=(x+y)/2
 # physical time Jacobians (1-e/3)^2, earlier physical-volume measure (1-Ty)^2
 base=-8*np.pi/math.sqrt(6)*mu**1.5/norm*(H-S)*(S-L)*w[:,None,None]*w[None,:,None]*w[None,None,:]*(time(x)-time(y))*(1-y/3)**8*(1-x/3)**2*d**3*r**2
 powers=[sum(comb(2*q,2*k)*mjk(q-k,k)*r**(2*k) for k in range(q+1)) for q in range((deg+8)//2+1)]
 def moment(poly):
  u=(m-center)/scale
  return mu*np.pi/24*d**4*(1-r*r)**2*sum(poly.deriv(2*q)(u)/f(2*q)*(d/scale)**(2*q)*powers[q] for q in range(poly.degree()//2+1))
 den=P([1-center/3,-scale/3])**8
 z=moment(den);K=np.exp(-z)*(1+z*(-9+z*(8-4*z/3)))
 Kp=np.exp(-z)*(-10+z*(25+z*(-12+4*z/3)))
 ex=np.sum(base*K)
 def Leg(i): return Legendre.basis(i).convert(kind=P)
 B=np.array([np.sum(base*((Leg(i)((x-center)/scale)+Leg(i)((y-center)/scale))*K+moment(den*Leg(i))*Kp)) for i in range(deg+1)])
 t=L+(H-L)*v;R=(3/4/np.pi)**(1/3);vhalo=(H-L)*(1-t/3)**8*(1+(H-t)/R)**3
 phi=np.array([Leg(i)((t-center)/scale) for i in range(deg+1)])
 G=(phi*(vhalo*w))@phi.T
 print('mean',ex,'basis',B)
 for i in range(1,deg+2):
  a=np.linalg.solve(G[:i,:i], B[:i]);print(i-1,'sd',math.sqrt(a@B[:i]/lam),'coef',np.round(a/max(abs(a))*10))
 return B,G
if __name__=='__main__':run()
