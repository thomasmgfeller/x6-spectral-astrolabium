"""Outward-rounded Gauss quadrature for the window-B Poisson count witness."""
import argparse
import json
from fractions import Fraction as F
from functools import lru_cache
from math import comb, factorial
from pathlib import Path
from flint import arb, acb, ctx, __version__

ctx.prec = 128
A=arb
def ball(q):
    q=F(q)
    return A(q.numerator)/q.denominator

def conv(a,b):
    result=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): result[i+j]+=x*y
    return result

def horner(a,x):
    value=a[-1]
    for c in reversed(a[:-1]): value=value*x+c
    return value

def moments(j,k):
    f=factorial
    return F(192*f(2*j)*f(2*k+3), f(2*j+2*k+4)*2**(2*j+2*k+4)*(2*k+1)*(2*k+3))

MU=600000
LAM=6000000
# y, x and their midpoint are conformal coordinates. All integrations use [0,1].
ETA=lambda t: 3*(1-(1-ball(t)).root(3))
LO,CS,HI=map(ETA,('0.23','0.47','0.58'))
CENTER=ball('0.49'); SCALE=ball('0.255')
# Fixed published normalizer: enclosure contains both stored decimal and binary64.
NORM=A('1.2871411680612763 +/- 0.000000000000001')
P=[F(-5,16),0,F(105,16),0,F(-315,16),0,F(231,16)]
P_BALL=list(map(ball,P))
weight8=[comb(8,i)*(1-F('0.49')/3)**(8-i)*(-F('0.255')/3)**i for i in range(9)]
def series(f):
    return [[ball(c*comb(i,2*j)) for i,c in enumerate(f) if i>=2*j] for j in range((len(f)+1)//2)]
F0=series(weight8)
F6=series(conv(weight8,P))
MOM=[[ball(comb(2*j,2*k)*moments(j-k,k)) for k in range(j+1)] for j in range(len(F6))]
def lens_coeff(polys,m,d):
    # Taylor coefficients of polynomial f about midpoint, integrated over a boosted diamond.
    u=(m-CENTER)/SCALE
    delta=(d/SCALE)**2
    terms=[horner(p,u)*delta**j for j,p in enumerate(polys)]
    return [sum(terms[j]*MOM[j][k] for j in range(k,len(terms))) for k in range(len(terms))]

FAC=-8*A.pi()*MU*A(MU).sqrt()/(A(6).sqrt()*NORM)*(CS-LO)*(HI-CS)
CF=MU*A.pi()/24
def xy(x,y):
    d=x-y; m=(x+y)/2
    c0=lens_coeff(F0,m,d);c6=lens_coeff(F6,m,d)
    # Physical time difference as a difference of cubes, factored.
    ax,ay=1-x/3,1-y/3
    dt=d*(ay**2+ay*ax+ax**2)/3
    factor=FAC*dt*ay**8*ax**2*d**3
    ends=horner(P_BALL,(x-CENTER)/SCALE)+horner(P_BALL,(y-CENTER)/SCALE)
    return factor,ends,CF*d**4,c0,c6

def func(cache,v2,edge):
    factor,ends,scale,c0,c6=cache
    common=scale*edge
    z=common*horner(c0,v2); z6=common*horner(c6,v2)
    exp=(-z).exp()
    base=factor*v2*exp
    k=1+z*(-9+z*(8-F43*z))
    kp=-10+z*(25+z*(-12+F43*z))
    return base*k,base*(ends*k+z6*kp)
F43=A(4)/3

# Holomorphic supremum on the one-coordinate complex ellipse rectangles.
# Use verified absolute coordinate maxima and triangle inequalities for polynomial factors.
def polynomial_majorant(xx,yy,vs):
    def maximum(items):
        h=A(0)
        for x in items: h=h.max(abs(x).upper())
        return h.upper()
    v=maximum(vs); d=maximum(x-y for x in xx for y in yy)
    u=maximum(((x+y)/2-CENTER)/SCALE for x in xx for y in yy)
    ax=maximum(1-x/3 for x in xx); ay=maximum(1-y/3 for y in yy)
    end_u=maximum((t-CENTER)/SCALE for t in xx+yy)
    bound=[]
    for pol in (F0,F6):
        vals=[horner([abs(c) for c in p],u)*(d/SCALE)**(2*j)*horner(MOM[j],v*v)
              for j,p in enumerate(pol)]
        bound.append(sum(vals))
    scale=CF*d**4*maximum((1-vv*vv)**2 for vv in vs)
    z,z6=[scale*x for x in bound]
    k=1+9*z+8*z*z+F43*z**3
    kp=10+25*z+12*z*z+F43*z**3
    ends=2*horner([abs(c) for c in P_BALL],end_u)
    base=abs(FAC)*d*(ay**2+ay*ax+ax**2)/3*ay**8*ax**2*d**3*v*v
    return (base*(k+ends*k+z6*kp)).upper()

def rects(panels,active,slices):
    # Bernstein ellipse rho=2 has semi-axes 5/4 and 3/4 on [-1,1].
    for i in range(panels):
        l=ball(F(i,panels)); h=ball(F(i+1,panels))
        if active:
            pad=ball(F(1,8*panels)); l-=pad; h+=pad
            imag=A(0,ball(F(3,8*panels)))
        else: imag=A(0)
        for j in range(slices):
            a=l+(h-l)*j/slices;b=l+(h-l)*(j+1)/slices
            yield acb(a.union(b),imag)

def magnitude_exponent(axis,panels):
    # Sharper enclosure of the exponent using the original positive coefficients
    # in powers of d/(3*am) and v^2. Other factors use the global majorant.
    # Complexification in one coordinate only; the product-rule error telescopes.
    cc=[[ball(moments(j,k)*F(factorial(8),factorial(8-2*j-2*k)*factorial(2*j)*factorial(2*k)))
        for j in range(5-k)] for k in range(5)]
    ranges=[list(rects(p,i==axis,max(1,(16+p-1)//p))) for i,p in enumerate(panels)]
    yy=[LO+(CS-LO)*t for t in ranges[0]]
    xx=[CS+(HI-CS)*t for t in ranges[1]]
    vs=[(v**2,(1-v)**2*(1+v)**2) for v in ranges[2]]
    assert all(abs(v)<2 for v in yy+xx+ranges[2])
    upper=A(0)
    for y in yy:
        for x in xx:
            d=x-y;am=1-(x+y)/6
            e=(d/(3*am))**2
            c=[e**k*horner(p,e) for k,p in enumerate(cc)]
            scaled=CF*d**4*am**8
            for v2,edge in vs:
                z=scaled*edge*horner(c,v2)
                upper=upper.max((-z.real).upper())
    return upper.upper(),polynomial_majorant(xx,yy,ranges[2])

def choose_orders(panels):
    orders=[];errors=[];limits=[]
    for axis in range(3):
        exponent,major=magnitude_exponent(axis,panels)
        m=major*exponent.exp()
        n=4
        # For intervals rescaled to unit length, positive composite weights.
        while not (32*m/(15*A(2)**(2*n-1)) < ball('0.000005')): n+=1
        orders.append(n);errors.append(32*m/(15*A(2)**(2*n-1))); limits.append(dict(minus_real_z=str(exponent),prefactor=str(major)))
    return orders,errors,limits

@lru_cache(maxsize=None)
def rule(n,p):
    raw=[A.legendre_p_root(n,k,weight=True) for k in range(n)]
    return [((2*j+1+t)/(2*p),w/(2*p)) for j in range(p) for t,w in raw]

def partial(args):
    panels,orders,start,stride=args
    return integral_subset(panels,orders,start,stride)

def integrate(panels,orders,workers):
    from multiprocessing import Pool
    with Pool(workers) as pool:
        terms=pool.map(partial,[(panels,orders,i,workers) for i in range(workers)])
    return tuple(sum(A(a[k]) for a in terms) for k in range(2))

def integral_subset(panels,orders,start,stride):
    ys=[(LO+(CS-LO)*t,w) for t,w in rule(orders[0],panels[0])]
    xs=[(CS+(HI-CS)*t,w) for t,w in rule(orders[1],panels[1])]
    vs=[(v*v,(1-v*v)**2,w) for v,w in rule(orders[2],panels[2])]
    total0=A(0);total6=A(0)
    for y,wy in ys[start::stride]:
        for x,wx in xs:
            cache=xy(x,y)
            s0=A(0);s6=A(0)
            for v2,edge,w in vs:
                a,b=func(cache,v2,edge)
                s0+=a*w;s6+=b*w
            total0+=wy*wx*s0;total6+=wy*wx*s6
    return str(total0),str(total6)

def gram():
    radius=(3/(4*A.pi())).root(3)
    result=A(0)
    # Polynomial degree 8+3+12=23. The 12-point rule is exact.
    for s,w in rule(12,1):
        t=LO+(HI-LO)*s
        result+=w*(1-t/3)**8*(1+(HI-t)/radius)**3*horner(P_BALL,(t-CENTER)/SCALE)**2
    return (HI-LO)*result

if __name__=='__main__':
    if not __debug__:
        raise SystemExit('Run without -O so all certificate comparisons are checked.')
    ap=argparse.ArgumentParser()
    ap.add_argument('--panels',nargs=3,type=int,default=[2,1,4])
    ap.add_argument('--bounds-only',action='store_true')
    ap.add_argument('--workers',type=int,default=5)
    ap.add_argument('--output',default='certificate.json')
    args=ap.parse_args()
    orders,errs,limits=choose_orders(args.panels)
    print('orders',orders,'exponent upper',limits,flush=True)
    if not args.bounds_only:
        a,b=integrate(args.panels,orders,args.workers)
        error=sum(errs).upper()
        mean=a+A(0,error);cov=b+A(0,error);g=gram()
        sd=abs(cov)/(LAM*g).sqrt()
        # Test the specific symmetric Chebyshev guarantee around the mean.
        needed=(ball('1.1')-mean)/A(20).sqrt()
        assert mean>1 and mean<ball('1.1') and sd>ball('0.001') and sd>needed
        assert sd>ball('0.00156') and needed<ball('0.000884')
        # L2 transfer to ideal exact arithmetic with interval-layer cutoff J=403.
        p=F(1,10); J=403
        eps=16*sum(comb(J,i)*p**i*(1-p)**(J-i) for i in range(4))
        assert eps<F(1,10**13)
        halo=A(0)
        radius=(3/(4*A.pi())).root(3)
        for u,w in rule(6,1):  # polynomial degree 11
            t=LO+(HI-LO)*u
            halo+=w*(1-t/3)**8*(1+(HI-t)/radius)**3
        population=LAM*(HI-LO)*halo
        n4=population**4+6*population**3+7*population**2+population
        tail=2*ball(p*p)*ball(eps)*ball('0.35')/(ball('0.42')**2*A(6*MU).sqrt()*NORM)*n4.sqrt()/4
        truncated_lower=sd-tail
        truncated_needed=(ball('1.1')-mean+tail)/A(20).sqrt()
        assert mean-tail>1 and mean+tail<ball('1.1') and truncated_lower>ball('0.00155') and truncated_lower>truncated_needed
        result=dict(engine=__version__,precision_bits=ctx.prec,orders=orders,panels=args.panels,
                    exponent_upper=limits,
                    tensor_remainder=str(error),mean=str(mean),covariance=str(cov),weight_norm_squared=str(g),
                    sd_lower_expression=str(sd),chebyshev_sd_threshold=str(needed),
                    cutoff_J=J,tail_weight_majorant=str(ball(eps)),l2_cutoff_error=str(tail),
                    cutoff_sd_lower_expression=str(truncated_lower),cutoff_chebyshev_threshold_upper=str(truncated_needed),
                    sd_at_least_0p10_percent=True,symmetric_chebyshev_excluded=True)
        Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
