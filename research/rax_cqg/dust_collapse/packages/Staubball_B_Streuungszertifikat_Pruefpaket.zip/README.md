# Fenster B: Zertifikat zur Massenstreuung und Entwurf eines Paartests

Die Rechnung prüft die Verteilung des vorgegebenen Massestroms auf dem homogenen, räumlich unbeschränkten Staubmodell. Die Aussage über die Standardabweichung gilt bei der publizierten festen Normierung. Die Abschätzung für den Schichtenabbruch gilt bei mathematisch exakter Auswertung der verbleibenden Gewichte und Kausalvergleiche. Eine Garantie für beliebige maschinelle Vergleichsfehler in einem späteren C++-Zielversuch ist davon getrennt.

## Rechenbeweis

Getestet unter Linux mit Python 3.12.14 und python-flint 0.9.0. Der Rechenbeweis und die Linsenkontrolle benötigen ausser python-flint nur die Standardbibliothek. NumPy 2.3.5 und SciPy 1.17.0 wurden für die gesonderte Versuchsplanung verwendet.

```sh
sha256sum -c SHA256SUMS
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python certify.py --output wiederholung.json
.venv/bin/python certify.py --panels 2 2 3 --output wiederholung_zwei.json
.venv/bin/python lens_controls.py
.venv/bin/python pair_check.py input_model.zip
```

Aktivierte Python-Prüfaussagen sind erforderlich. Standardmässig arbeitet die Quadratur lokal mit fünf Prozessen. Mit `--workers 1` läuft sie seriell. Die SHA-256-Werte gelten für den ausgelieferten Stand. Die Intervalle zweier Aufteilungen müssen dieselben im Programm geprüften Schwellen überschreiten; Darstellungen und Intervallbreiten können zwischen Laufzeitumgebungen abweichen. Ein Intervall für den Ausdruck `sd_lower_expression` schliesst die berechnete Projektionsgrösse ein. Die tatsächliche Standardabweichung ist nach unten durch diese Grösse begrenzt, ihr oberes Ende ist keine Varianzobergrenze.

- `certify.py` erzeugt die gerichteten Kugelintervalle für die vollständige Quadratur und ihre Fehler. `certificate.json` und `cross_certificate.json` enthalten die zwei geprüften Aufteilungen. Die positive Gewichtsformel in `magnitude_exponent` und die Taylorformel in `lens_coeff` stellen dasselbe Polynom für das ungestörte Intervallvolumen dar.
- `lens_controls.py` prüft 40 Polynomauswertungen gegen die direkte Linsenintegration auf 20 Paargeometrien. `explore.py` dokumentiert die vorgängige nichtzertifizierte numerische Suche nach einem Gewichtszeugen. Sie gehört nicht zum Beweis.
- `pair_design.json` hält den zukünftigen, lokal festgelegten Entwurf fest. `pair_check.py` kontrolliert die archivierten Paardaten und die beiden binomialen Entscheidungswahrscheinlichkeiten am Nullrand und unter der Planungsalternative mit rationaler Arithmetik. Die ergänzende Clopper-Pearson-Grenze wird numerisch bestimmt.
- `budget.py` reproduziert ausschliesslich zwei technische Laufzeitproben. GNU g++ mit C++17/OpenMP-SIMD sowie NumPy und SciPy sind erforderlich. Optional lokal mit `OPENBLAS_NUM_THREADS=1 .venv/bin/python budget.py input_model.zip` starten. Die gemessenen Zeiten im mitgelieferten `budget.json` sind hardwareabhängig. Weder die 149 Zielpaare noch einer der zwei vollständigen Community-Piloten werden von diesen Befehlen gestartet.
- `input_model.zip` ist eine unveränderte Kopie des publizierten Staubball-Referenzpakets (SHA-256: 293abfb2a6854b1a33982d6accc5354838b0573fc2958b9e7212599ba78fe585). `report.tex` enthält die Quelle zum beiliegenden PDF.

[Astrolabium-Referenzmodell](https://github.com/thomasmgfeller/x6-spectral-astrolabium/blob/d982a078c48079d86634ddbcccc3f9f23772acfd/research/rax_cqg/dust_collapse/packages/CST_Staubkollaps_Geglaetteter_Massestrom_Pruefpaket.zip) · [Räumliche Projektion, PR 205](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/205) · [Validierte Gauss-Fehlerschranke](https://flintlib.org/doc/acb_calc.html)
