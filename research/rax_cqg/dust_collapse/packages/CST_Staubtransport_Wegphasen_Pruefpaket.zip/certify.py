"""Exact integer interval certificate for the entire unit circle, at g=4*pi/5."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
from itertools import product
from math import isqrt,prod
import csv,json
ROOT=Path(__file__).resolve().parent
S=10**15
def ceil(n,d):return -((-n)//d)
def bound(x):
    x=F(x)
    return (x.numerator*S//x.denominator,ceil(x.numerator*S,x.denominator))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def mul(a,b):
    vals=[v*w for v in a for w in b]
    return (min(vals)//S,ceil(max(vals),S))
def root(a):
    assert a[0]>=0
    return (isqrt(a[0]*S),isqrt(a[1]*S)+1)
def plus(a,b):return (add(a[0],b[0]),add(a[1],b[1]))
def times(a,b):return (add(mul(a[0],b[0]),neg(mul(a[1],b[1]))),add(mul(a[0],b[1]),mul(a[1],b[0])))
def scale(z,s):return(mul(z[0],s),mul(z[1],s))
def rot(z):return(neg(z[1]),z[0])
def lower_mod(z):
    x,y=(max(a[0],-a[1],0) for a in z)
    return F(isqrt(x*x+y*y),S)
def direct_coefficients():
    rows=csv.DictReader((ROOT/'previous/geometry_flux.csv').open())
    result=Counter()
    for g in rows:
        if g['k']!='2':continue
        e=[list(map(int,s.split(','))) if s else [] for s in g['edges'].split('|')]
        walks=[]
        for source in range(3):
            local=[]
            for a in e[source]:
                for b in e[a]:
                    for c in e[b]:
                        assert e[c]==[9]
                        n=sum(b in e[v] for v in e[source])
                        m=sum(9 in e[v] for v in e[b])
                        assert n in (1,2) and m in (1,2)
                        local.append(((n==2)+(m==2),F(1,len(e[source])*len(e[a])*len(e[b]))))
            walks.append(local)
        triples=[(sum(h for h,_ in t),prod(w for _,w in t)) for t in product(*walks)]
        j=int(g['Q'])%5
        for h,w in triples:result[1,h,j]+=w/4
        for x,y in product(triples,repeat=2):
            result[2,x[0]+y[0],j]+=x[1]*y[1]/4
    return result
def certify():
    exact=direct_coefficients()
    with (ROOT/'coefficients.csv').open() as f:
        stored={(int(t['r']),int(t['power']),int(t['residue'])):F(t['coefficient']) for t in csv.DictReader(f)}
    assert exact==stored
    v=root(bound(5));quarter=bound(F(1,4))
    zeta=(mul(neg(add(bound(1),v)),quarter),
          mul(root(add(bound(10),neg(mul(bound(2),v)))),quarter))
    powers=[(bound(1),bound(0))]
    for _ in range(4):powers.append(times(powers[-1],zeta))
    leaves=[]
    for r in (1,2):
        coeff=[(bound(0),bound(0)) for _ in range(6*r+1)]
        for (rr,h,j),w in stored.items():
            if r==rr:coeff[h]=plus(coeff[h],scale(powers[j],bound(w)))
        assert sum(w for (rr,h,j),w in stored.items() if rr==r)==F(49,4)
        lip=F(6*r*49,4)
        for quadrant in range(4):
            stack=[(F(0),F(1),0)]
            while stack:
                lo,hi,depth=stack.pop();u=(lo+hi)/2
                z=(bound((1-u*u)/(1+u*u)),bound(2*u/(1+u*u)))
                for _ in range(quadrant):z=rot(z)
                val=coeff[-1]
                for c in reversed(coeff[:-1]):val=plus(times(val,z),c)
                lower=lower_mod(val)-lip*(hi-lo)
                if lower>F(1,20):
                    leaves.append(dict(r=r,quadrant=quadrant,lo=str(lo),hi=str(hi),lower=str(lower),depth=depth))
                else:
                    assert depth<18, 'No certificate at chosen subdivision limit'
                    stack.extend([(lo,u,depth+1),(u,hi,depth+1)])
    with (ROOT/'certificate_arcs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(leaves[0]),lineterminator='\n');w.writeheader();w.writerows(leaves)
    stats=[]
    for r in (1,2):
        part=[x for x in leaves if x['r']==r]
        for k in range(4):
            intervals=sorted((F(x['lo']),F(x['hi'])) for x in part if x['quadrant']==k)
            assert intervals[0][0]==0 and intervals[-1][1]==1
            assert all(a[1]==b[0] for a,b in zip(intervals,intervals[1:]))
        stats.append(dict(r=r,leaves=len(part),max_depth=max(x['depth'] for x in part),
                          minimum_validated_lower=float(min(F(x['lower']) for x in part))))
    (ROOT/'certificate.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(stats)
if __name__=='__main__':certify()
