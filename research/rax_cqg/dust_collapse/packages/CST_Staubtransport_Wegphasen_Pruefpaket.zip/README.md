# Wegabhängige Staubphasen

Dieser endliche Folgetest prüft eine Zweiblockdauer, die von offenen Intervallzahlen derselben Kausalordnung abhängt. Das Kernresultat ist ein rechnergestützter Ausschlusssatz bei g=4*pi/5 unter festgelegten Transport- und Endraumbedingungen. Die Dateien lassen sich offline überprüfen.

## Reproduktion

Im entpackten Verzeichnis:

    sha256sum -c SHA256SUMS
    python3 calibrate.py
    python3 phase.py
    python3 certify.py

Für die ersten beiden Rechnungen werden NumPy und SciPy benötigt; das Zertifikat verwendet ausschliesslich die Python-Standardbibliothek und die beiliegenden rationalen Daten. Die Prüfsummen beziehen sich auf die gelieferten Dateien. Rechnerabhängige Unterschiede in letzten Gleitkommastellen sind möglich.

## Definitionen und Daten

- design.json ist die vor der Auswertung festgehaltene lokale Versuchsdefinition. Der geplante kontinuierliche Test für eta in [0,2] wurde nach der Polynomreduktion auf den gesamten Einheitskreis erweitert. Die Auswahl der Zielklasse und die Freigaberegel wurden nicht geändert.
- previous/ enthält die für diese Rechnung erforderlichen unveränderten Teile des Massenfluss-Prüfpakets aus [PR 197](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/197). geometry_flux.csv ist die vollständige Kantenliste mit Q für jede der 75 Ordnungen. phase.py prüft die Q-Werte unabhängig aus der transitiven Hülle und jeden verwendeten Intervallwert gegen den direkten Zwei-Schritt-Test.
- calibration.csv dokumentiert Poisson-Mittelwerte, die deterministisch summierte Kontrastvorhersage, Restschranke, Stichprobenzahl, Vorzeichentreffer und simultane einseitige Untergrenzen. Der Pseudozufallszahlengenerator wird nur für die unabhängige Vorzeichenkontrolle benutzt. Das gemeinsame Volumen wurde auf zwei Wegen berechnet. Die Modellendpunkte werden extern gesetzt.
- paths.csv enthält pro Weg die zwei Blockzählungen, das rationale Routinggewicht und die Länge in Einheiten von ell. source_spreads.csv zeigt die Unterschiede bei festem Anfang, Ende und fester Geometrie.
- matter_factors.csv, branches.csv und window.csv enthalten gesamte komplexe Materiefaktoren, Klassenamplituden und Entscheidungen. model=blocks benutzt die einzelnen Pfade. model=mean behält pro Quelle und Geometrie nur die mittlere Weglänge. q ist ein diagonales Hilfsgewicht.
- arcs.csv vergleicht den kleinsten Winkelradius über die Gesamtphasen der zugelassenen Pakethistorien mit der Vorgängerschranke. Die Spalten delta_lower und delta_upper sind numerische Gitterschranken für den Abstand des Materiefaktors zur bestmöglichen gemeinsamen Phase (16384 Winkel, Lipschitz-Korrektur). Diese Gleitkommawerte sind vom rational abgesicherten Zertifikat getrennt.
- coefficients.csv registriert die exakten rationalen Koeffizienten der Konkurrenzklasse k=2 nach Potenz h und Q mod 5. certify.py erstellt sie noch einmal durch direkte Tupelzählung und prüft Gleichheit. certificate_arcs.csv enthält pro Quadrant die rationalen lückenlosen Teilintervalle und die jeweilige geprüfte untere Amplitudenschranke. Wegen |A1| <= 1/6 und der unveränderten Freigabeobergrenze für |A2| ist die Schranke > 1/20 auf dem ganzen Kreis hinreichend, um Ziel 1 auszuschliessen.
- summary.json, certificate.json und calibration.json fassen die drei getrennten Tests zusammen. Pruefbericht.pdf enthält Voraussetzungen, Ableitungen und physikalische Grenzen.

Ein zusätzlicher Freiheitsgrad pro Geometrie, ein anderer Endraum oder eine andere Wegwirkung liegt ausserhalb des Satzes. Die enthaltenen Daten sind endliche Modell- und Kalibrierrechnungen, keine Beobachtungsdaten.
