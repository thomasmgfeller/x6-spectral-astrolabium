"""Fixed external 4D Minkowski probes. Exact overlap volume, paired Poisson experiments."""
from pathlib import Path
from fractions import Fraction as F
import csv,json,math
import numpy as np
from scipy.integrate import quad
from scipy.stats import beta,poisson

ROOT=Path(__file__).resolve().parent
MEANS=(1,2,4,16,64,256,1024)
REPS=65536
def lens_over_pi(t):
    r=min(t,2-t);R=2-t;d=F(6,5)
    if r+R<=d:return F(0)
    if d<=R-r:return F(4,3)*r**3
    return (r+R-d)**2*(d*d+2*d*(r+R)-3*(r-R)**2)/(12*d)
def overlap_over_pi():
    ends=[F(0),F(2,5),F(1),F(7,5),F(2)]
    # Piecewise cubic integrands: Simpson is exact.
    return sum((b-a)*(lens_over_pi(a)+4*lens_over_pi((b+a)/2)+lens_over_pi(b))/6
               for a,b in zip(ends,ends[1:]))
def other_overlap():
    # Integrate in the direction of the displacement, then over time.
    def slice_volume(t):
        r=min(t,2-t);R=2-t;d=1.2
        lo=max(-r,d-R);hi=min(r,d+R)
        if hi<=lo:return 0.
        join=(r*r-R*R+d*d)/(2*d)
        return quad(lambda x:math.pi*max(0,min(r*r-x*x,R*R-(x-d)**2)),lo,hi,
                    points=[join] if lo<join<hi else [],epsabs=1e-11)[0]
    return quad(slice_volume,0,2,points=[.4,1,1.4],epsabs=1e-11)[0]
def plug_mean(mean,rho):
    limit=math.ceil(mean+14*math.sqrt(mean)+80)
    n=np.arange(limit+1)
    mean_length=(24/(math.pi*rho))**.25*np.dot(n**.25,poisson.pmf(n,mean))
    upper_tail=(24*mean/(math.pi*rho))**.25*math.sqrt(poisson.sf(limit,mean))
    return float(mean_length),upper_tail

def main():
    shared=overlap_over_pi()
    assert abs(other_overlap()-float(shared)*math.pi)<1e-10
    rows=[];streams=np.random.SeedSequence(20261103).spawn(len(MEANS))
    for mean,stream in zip(MEANS,streams):
        rho=mean/(math.pi*2**4/24)
        bent=mean*.8**4; common=rho*float(shared)*math.pi
        rng=np.random.default_rng(stream)
        both=rng.poisson(common,size=(REPS,2))
        ns=both+rng.poisson(mean-common,size=(REPS,2))
        nb=both+rng.poisson(bent-common,size=(REPS,2))
        delta=((ns**.25).sum(axis=1)-(nb**.25).sum(axis=1))*(24/(math.pi*rho))**.25
        npos=int(np.count_nonzero(delta>0))
        lower=float(beta.ppf(.01/len(MEANS),npos,REPS-npos+1)) if npos else 0.
        s,es=plug_mean(mean,rho);b,eb=plug_mean(bent,rho)
        expected=2*(s-b); tail=2*(es+eb);rel_bias=abs(expected-.8)/.8
        passed=rel_bias+tail/.8<=.10 and lower>=.95
        rows.append(dict(mean_straight=mean,mean_bent=bent,mean_shared=common,rho=rho,
                         expected_delta=expected,tail_bound=tail,relative_bias=rel_bias,
                         sign_positive=npos,sign_ties=int(np.count_nonzero(delta==0)),
                         reps=REPS,sign_lower=lower,decision='pass' if passed else 'fail'))
    with (ROOT/'calibration.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
    result=dict(overlap_volume_over_pi=str(shared),max_mean_tail_bound=max(x['tail_bound'] for x in rows),
                first_tested_passing_mean=next((x['mean_straight'] for x in rows if x['decision']=='pass'),None))
    print(result)
    (ROOT/'calibration.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
