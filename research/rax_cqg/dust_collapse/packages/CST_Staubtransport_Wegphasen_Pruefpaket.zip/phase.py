"""Two-block volume distance on the published geometries. No late target in this calculation."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product
import csv,json,math,cmath,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'previous'))
import transport as prior

def rows(name): 
    with (ROOT/'previous'/name).open() as f:return list(csv.DictReader(f))
def write(name,data):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]),lineterminator='\n');w.writeheader();w.writerows(data)
def convolve(a,b):
    c=Counter()
    for h,v in a.items():
        for t,w in b.items():c[tuple(x+y for x,y in zip(h,t))]+=v*w
    return c
def future(edges):
    reach=[set() for _ in edges]
    for v in reversed(range(len(edges))):
        for y in edges[v]:reach[v].add(y);reach[v].update(reach[y])
    return reach
def geometry_data():
    data=[];source_rows=[];path_rows=[]
    for row in rows('geometry_flux.csv'):
        k=int(row['k']);gid=int(row['id']);edge=[list(map(int,t.split(','))) if t else [] for t in row['edges'].split('|')]
        paths=[prior.paths(edge,s) for s in range(3)]
        reach=future(edge);past=[{x for x in range(len(edge)) if y in reach[x]} for y in range(len(edge))]
        q=len(edge)-sum(prior.old.C[j] if j<4 else 0 for x,R in enumerate(reach) for y in R for j in [len(R&past[y])])
        assert q==int(row['Q'])
        dist=[];lengths=[]
        for src,pp in enumerate(paths):
            hist=Counter(); lp=[]
            for path in pp:
                counts=[]
                for i in (0,2):
                    x,y=path[i],path[i+2]
                    n=len(reach[x]&past[y])
                    assert n==len({v for v in edge[x] if y in edge[v]}) and 1<=n<=3
                    counts.append(n)
                h=tuple(counts.count(j) for j in (1,2,3))
                prob=F(1,math.prod(len(edge[v]) for v in path[:-1]))
                L=sum(TAU[j]*count for j,count in enumerate(h))
                hist[h]+=prob;lp.append((L,prob))
                path_rows.append(dict(id=gid,k=k,source=src,path='-'.join(map(str,path)),
                                      left=counts[0],right=counts[1],route_weight=str(prob),duration=L))
            assert sum(hist.values())==1
            span=max(l for l,_ in lp)-min(l for l,_ in lp)
            source_rows.append(dict(id=gid,k=k,source=src,paths=len(pp),spread=span))
            dist.append(hist);lengths.append(lp)
        data.append(dict(id=gid,k=k,Q=q,dist=dist,lengths=lengths))
    return data,source_rows,path_rows
def parcel_hist(d,r):
    h=Counter({(0,0,0):F(1)})
    for hist in d['dist']:
        for _ in range(r):h=convolve(h,hist)
    return h
def arc_radius(angles):
    a=np.sort(np.mod(angles,2*math.pi));gaps=np.diff(np.append(a,a[0]+2*math.pi))
    return max(0.,float(math.pi-np.max(gaps)/2))
def minimax_factor(ws):
    grid=16384
    unit=np.exp(2j*np.pi*np.arange(grid)/grid)
    upper=float(np.min(np.max(abs(np.array(ws)[:,None]-unit[None,:]),axis=0)))
    return max(0.,upper-np.pi/grid),upper
TAU=[(24*j/math.pi)**.25 for j in (1,2,3)]
ETA=[0.,.5,1.,2.]
def main():
    assert hashlib.sha256((ROOT/'previous/geometry_flux.csv').read_bytes()).hexdigest()=='2b1e3373a2631a48ca9519dd76983c75897e3d1c24be620e87add2a6547ede86'
    data,source_rows,path_rows=geometry_data()
    write('source_spreads.csv',source_rows);write('paths.csv',path_rows)
    results=[];arcs=[];branches=[];coeffs=[];factors=[]
    baseline={(row['g'],int(row['k'])):complex(float(row['Re']),float(row['Im'])) for row in rows('branches.csv')
              if row['alpha']=='1.0' and row['parcels_per_source']=='1'}
    maxerr=0.;direct_count=0
    for r in [1,2]:
        coeff=Counter(); histograms=[]
        for d in data:
            hist=parcel_hist(d,r);histograms.append(hist)
            if d['k']==2:
                for h,p in hist.items():
                    assert h[2]==0 and sum(h)==6*r
                    coeff[h[1],d['Q']%5]+=p/F(4)
        assert sum(coeff.values())==F(49,4)
        coeffs.extend(dict(r=r,power=h,residue=j,coefficient=str(w)) for (h,j),w in sorted(coeff.items()))
        for eta in ETA:
            vals={'blocks':[],'mean':[]};angles=[]
            for d,hist in zip(data,histograms):
                vals_hist=[(sum(TAU[j]*c for j,c in enumerate(h))/r,p) for h,p in hist.items()]
                W=prior.csum(float(p)*cmath.exp(-1j*eta*L) for L,p in vals_hist)
                angles.extend(-eta*L for L,p in vals_hist)
                z=math.prod(prior.csum(float(p)*cmath.exp(-1j*eta*L/r) for L,p in lp)**r for lp in d['lengths'])
                m=cmath.exp(-1j*eta*sum(sum(float(p)*L for L,p in lp) for lp in d['lengths']))
                maxerr=max(maxerr,abs(W-z));assert abs(W-z)<2e-13 and abs(W)<1+1e-14
                if eta==1:
                    tuples=product(*(d['lengths']*r))
                    direct=[]
                    for t in tuples:
                        direct.append(math.prod(float(p) for _,p in t)*cmath.exp(-1j*sum(L for L,_ in t)/r))
                    zz=prior.csum(direct);direct_count+=len(direct)
                    maxerr=max(maxerr,abs(zz-z));assert abs(zz-z)<2e-13
                vals['blocks'].append(W);vals['mean'].append(m)
                factors.append(dict(r=r,eta=eta,id=d['id'],k=d['k'],Re=W.real,Im=W.imag,absW=abs(W),
                                    mean_Re=m.real,mean_Im=m.imag))
            low,high=minimax_factor(vals['blocks'])
            arcs.append(dict(r=r,eta=eta,radius=arc_radius(angles),delta_lower=low,delta_upper=high))
            for name,ws in vals.items():
                for gname,g in prior.COUPLINGS.items():
                    amps=[prior.csum(w*cmath.exp(1j*g*d['Q']) for d,w in zip(data,ws) if d['k']==k)/(math.factorial(k)*math.factorial(4-k)) for k in (1,2,3)]
                    if eta==0: assert max(abs(a-baseline[gname,k]) for k,a in enumerate(amps,1))<1e-12
                    results.append(dict(model=name,r=r,eta=eta,g=gname,**prior.diagnostics(amps)))
                    branches.extend(dict(model=name,r=r,eta=eta,g=gname,k=k,Re=a.real,Im=a.imag) for k,a in enumerate(amps,1))
    write('coefficients.csv',coeffs);write('window.csv',results);write('arcs.csv',arcs)
    write('branches.csv',branches);write('matter_factors.csv',factors)
    summary=dict(geometries=len(data),sources=len(source_rows),sources_vary=sum(x['spread']>1e-12 for x in source_rows),
                 geometries_vary=len({x['id'] for x in source_rows if x['spread']>1e-12}),
                 max_single_source_spread=max(x['spread'] for x in source_rows),counts_used=sorted({x[t] for x in path_rows for t in ('left','right')}),
                 joint_path_tuples_crosschecked=direct_count,max_crosscheck_error=maxerr,
                 grid_cells=sum(x['model']=='blocks' for x in results),issued_blocks=sum(x['model']=='blocks' and x['decision']=='issue' for x in results),
                 issued_mean=sum(x['model']=='mean' and x['decision']=='issue' for x in results))
    print(json.dumps(summary,indent=2))
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__':main()
