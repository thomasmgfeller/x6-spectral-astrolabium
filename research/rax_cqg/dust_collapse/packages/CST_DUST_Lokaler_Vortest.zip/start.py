"""Run the archived causal-set clock replay and small independent controls."""
import csv
import json
import math
import shutil
import subprocess
import sys
import tempfile
from fractions import Fraction as F
from itertools import permutations, product
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "daten"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def clock_replay():
    with tempfile.TemporaryDirectory() as directory:
        # The upstream replay writes its own verification record.
        work = Path(directory) / "uhr"
        shutil.copytree(ROOT / "uhr", work)
        subprocess.run([sys.executable, "-B", "-O", "replay.py"], cwd=work,
                       check=True, capture_output=True, text=True)
        report = json.loads((work / "results/replay.json").read_text())
    require(report["isolated_replay"] == "PASS" and report["result_files"] == 6,
            "Uhr-Replay fehlgeschlagen")
    print("N <= 6: 6/6 archivierte Ergebnisdateien bytegleich.")


def end_time_and_orbits():
    archive = json.loads((DATA / "candidates.json").read_text())
    family = archive["roots"]["one"]["families"]["rooted_parent_capped_incidence_4"]
    shift = family["six_order_mask_first"]["pure_orbit_transfer_A_to_B"]
    require(shift["end_types"] == [1790, 5374], "N14-Orbits")
    require(shift["equal_column_positive_prefixes"] == [1564, 4195868, 134219292],
            "identische N13-Spalten")
    a, b = map(F, shift["witness_orbit_masses"])
    require(a == b == F(1, 49_000_000), "Zeugenmasse")
    for theta in (F(-1, 2), F(0), F(1, 2)):
        t = theta*a
        require(a-t > 0 and b+t > 0 and (a-t)+(b+t) == a+b, "Orbittransfer")
    # N<=2, alpha=z=1. Empty prefix and final reference horizon h.
    def z(h):
        return 1 + h + h*h/2
    early = F(1, 4)
    probabilities = [z(h-early)/z(h) for h in (early, F(1, 2))]
    require(probabilities == [F(32, 41), F(41, 52)], "Endrand-Gegenprobe")
    print("N14: 3 positive Transfers bei gleichen Präfixspalten. Uhr: Differenz",
          probabilities[1]-probabilities[0])


def pilot_p3():
    plan = json.loads((DATA / "plan.json").read_text())
    require(plan["family"]["total"] == 524, "P3-Plan")
    names = ("r", "rho_over_rho0", "H_times_Tend", "acceleration_times_Tend_squared")
    expected = set(product([F(i, 4) for i in range(5)], names))
    errors = []
    with (DATA / "reference_comparisons.csv").open(newline="") as stream:
        for row in csv.DictReader(stream):
            if F(row["M"]) != 1 or int(row["steps"]) != 128:
                continue
            x, name = F(row["x"]), row["observable"]
            expected.remove((x, name))
            lo, hi = F(row["ODE_enclosure_lo"]), F(row["ODE_enclosure_hi"])
            s = 1-x/4
            if name == "r":
                inside = lo**3 <= s*s <= hi**3
            else:
                value = {names[1]: 1/s**2, names[2]: -1/(6*s), names[3]: -1/(72*s**2)}[name]
                inside = lo <= value <= hi
            require(inside, f"Referenz ausserhalb der Hülle: {x}, {name}")
            errors.append(max(abs(F(row[key])) for key in ("relative_error_lo", "relative_error_hi")))
    require(not expected and len(errors) == 20 and max(errors) <= F(1, 200), "P3-Referenzpilot")
    print(f"M=1, 128 klassische Schritte: 20/20 Referenzhüllen, Maximum {float(100*max(errors)):.6f} %.")


def audit():
    data = json.loads((DATA / "clock_packet_results.json").read_text())
    runs = data["finest_grid"]["fixed_clocks"]
    require({r["T3_offset"] for r in runs} == {-1/16, 0, 1/16} and len(runs) == 3, "N11-Uhren")
    max_delta = 0
    for run in runs:
        low, high = [run[c]["joint_left_middle_right_failure"] for c in ("rho_1_8", "rho_1_4")]
        require(len(low) == len(high) == 4 and min(low+high) >= 0, "N11-Records")
        require(max(abs(math.fsum(values)-1) for values in (low, high)) < 1e-14, "N11-Norm")
        max_delta = max(max_delta, *(abs(a-b) for a,b in zip(low, high)))
    require(max_delta < 1e-14, "N11-Nullkontrolle")
    paths = tuple(product((0, 1), repeat=2))
    def measures(rows, phases):
        sums = [F(0), F(0)]
        for a, b in rows:
            sums[b] += F((-1)**(a*b) if phases else 1, 2)
        return tuple(s*s for s in sums)
    require(all(measures(perm, True) == (1, 0) for perm in permutations(paths)), "Record-Reihenfolge")
    require(measures(paths, False) == (1, 1), "Phasen-Negativkontrolle")
    for n in range(1, 21):
        v = F(1, 2**n)
        # Two-point spectral law: mass v^a at volume v, remaining mass at 1.
        require([v**a / v**2 for a in (1, 2, 3)] == [1/v, 1, v], "Kleinvolumen-Gegenprobe")
    print(f"N11-Nullkontrolle: maximale Archivdifferenz {max_delta:.3g}.")
    print("24 Speicherreihenfolgen invariant. Zweischrittbeispiel ohne Phasen: Gesamtgewicht 2.")
    print("Kleinvolumen-Kontrollen: divergenter, konstanter und verschwindender Rest erkannt.")


if __name__ == "__main__":
    clock_replay()
    end_time_and_orbits()
    pilot_p3()
    audit()
    print("Physikalischer P3-Lauf: NOT_RUN. Neue CST-Ensembles: 0.")
