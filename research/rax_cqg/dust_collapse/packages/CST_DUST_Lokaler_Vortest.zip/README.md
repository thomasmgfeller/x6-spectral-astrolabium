# CST-DUST · Lokaler Vortest

Das Paket enthält einen wiederholbaren kleinen Kausalset-Lauf und Prüfungen für den Einstieg in die Arbeit an einem physikalischen Transport. Es benutzt Python 3.10 oder neuer und die Standardbibliothek. Nach dem Entpacken kann man es ohne Netzwerk ausführen.

```sh
python3 -B start.py
```

Der Lauf arbeitet in einem temporären Ordner. Bei einer verletzten Prüfbedingung endet er mit einer Fehlermeldung. Die Laufzeit hängt vom Gerät ab.

## Was berechnet wird

1. Der archivierte Uhrintervall-Replay enumeriert kleine Kausalordnungen und vergleicht sechs frisch berechnete Ergebnisdateien bytegenau mit den archivierten Ergebnissen. Seine normerhaltende Konstruktion setzt einen gemeinsamen Enduhrwert voraus. Die Referenz enthält bis zu sechs innere Ereignisse.
2. Auf Basis der archivierten identischen Präfixspalten prüft der Vortest drei Transfers der Orbitmasse im positiven N14-Zeugen. Er berechnet separat die Abhängigkeit der frühen Keine-Geburt-Auslese vom Enduhrwert der diagonalen Referenz.
3. Der analytische Staubball für M=1 wird mit 20 gespeicherten klassischen Euler-Einschliessungen auf der Stufe mit 128 Schritten verglichen. Die Zahl 128 bezeichnet die Zeitintegration der klassischen Referenz.
4. Zur Auslese gehören die feste N11-Uhrkontrolle für zwei Präparationen mit allen vier Ausgängen, sämtliche 24 Speicherpermutationen eines Vierhistorienbeispiels und dessen gesamtes Gewicht nach Entfernung der Phasen. Drei bekannte Zweipunktverteilungen prüfen das Verhalten der Auswertung bei kleinen Volumina. Der physikalische Rückwirkung-aus-Vergleich und die physikalische Kleinvolumen-Schranke stehen aus.

## Herkunft

Die Quelldateien im Ordner `uhr/` sind der für den Replay benötigte Ausschnitt aus [clock_intervals_v0_1](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/2770f280ddcab063b925813170dc87c58a8b3821/research/rax_cqg/dust_collapse/clock_intervals_v0_1). `daten/` enthält unveränderte Daten aus demselben Repository-Stand. Die SHA-256-Werte dieser Originaldateien wurden mit dem Quellenmanifest abgeglichen. Das Startskript bindet sie in diesen Vortest ein.

- `candidates.json` – [N14 · positive Wachstumsregel](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/2770f280ddcab063b925813170dc87c58a8b3821/research/rax_cqg/dust_collapse/history_measure_state_space_v0_2)
- `plan.json` und `reference_comparisons.csv` – [P3 · Plan und klassische Referenz](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/2770f280ddcab063b925813170dc87c58a8b3821/research/rax_cqg/dust_collapse/correspondence_v0_1)
- `clock_packet_results.json` – [N11 · feste Uhren und Anfangspräparation](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/2770f280ddcab063b925813170dc87c58a8b3821/research/rax_cqg/dust_collapse/initial_preparation_v0_1)
