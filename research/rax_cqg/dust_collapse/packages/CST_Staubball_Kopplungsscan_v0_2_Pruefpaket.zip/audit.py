"""Independent numerical audit of scan decisions and direct explicit-poset recount."""
import argparse, csv, cmath, json, math, sys
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
from scan import ROOT, LO, HI, S, grouped, load, metrics, record, show
sys.path.insert(0,str(ROOT/'source'))
import gate

def numerical(table,mode,k,level,phased):
    # Use table of Qs and original gate classifier, independently integrate the four linear segments.
    samples=[]
    for w,actions in table.items():
        a=[F(n,5) for n in w]
        vol=[x**3 for x in a]
        cls=gate.classify([[str(v),str(v)] for v in vol],F(1,20),F(1,20))
        assert cls in ('B','N') and cls==record(w)[0]
        h=F(2,5)
        e=[h/x**3 if x==y else h*(1/x**2-1/y**2)/(2*(y-x)) for x,y in zip(a,a[1:])]
        amp=cmath.exp(1j*math.pi*((actions[level]*(4 if level==0 else 1))%10)/5) if phased else 1.
        samples.append((cls,amp,int(4*vol[-1]),float(sum(e[:2])),float(sum(e[2:]))))
    blocks=defaultdict(complex)
    for cls,a,b,u,v in samples:
        for other,j,end,r,s in samples:
            if end==b:
                first,second=u-r,v-s
                dist=(first+second)**2 if mode=='total' else first**2+second**2
                blocks[cls,other]+=a.conjugate()*j*math.exp(-float(k)**2*dist/(8*0.4**2))
    trace=(blocks['B','B']+blocks['N','N']).real
    return blocks['B','B'].real/trace,2*abs(blocks['B','N'])/trace

def scores(out):
    scan=json.loads((out/'scan.json').read_text())
    original=json.loads((ROOT/'source/primary_bounds.json').read_text())
    checks={}
    for family,fdata in scan.items():
        table=load(family)
        for mode,r in fdata.items():
            gr=grouped(table,mode)
            for k,pt in r['points'].items():
                for l,channel,on in ((0,'coarse',True),(1,'fine',True),(0,'null',False)):
                    q,e=numerical(table,mode,F(k),l,on)
                    for key,num in [('qB',q),('epsilon',e)]:
                        a,b=map(F,pt['metrics'][channel][key])
                        assert float(a)-2e-12<=num<=float(b)+2e-12
                        if family=='development' and mode=='total' and k in ('0','1'):
                            p=original['on' if k=='1' else 'off'][('1/5','1/10')[l]]['dynamic' if on else 'null']['q_B' if key=='qB' else 'epsilon']
                            assert max(a,F(p[0]))<=min(b,F(p[1]))
            # Outward bounds for the entire family, taking the hull across certified subintervals.
            hulls={}
            for lo,hi,state in r['certified_leaf_partition']:
                for group,rows in gr.items():
                    m=metrics(rows,F(lo),F(hi))
                    for key,iv in m.items():
                        ix=group+'_'+key
                        old=hulls.get(ix,iv);hulls[ix]=(min(old[0],iv[0]),max(old[1],iv[1]))
            checks[family+'_'+mode]={ix:show(val) for ix,val in hulls.items()}
    predictions={'total':{'1':'HOLD','5/4':'FAIL'},'split':{'1':'HOLD','5/4':'HOLD'}}
    transfer=[dict(meter=m,lambda_value=k,prediction=val,actual=scan['holdout'][m]['points'][k]['gate'])
              for m,vals in predictions.items() for k,val in vals.items()]
    for t in transfer:
        assert t['prediction']==scan['development'][t['meter']]['points'][t['lambda_value']]['gate']
    return dict(full_band_enclosures=checks,transfer=transfer,
                transfer_agreements=sum(t['actual']==t['prediction'] for t in transfer),point_comparisons=120)

def recount():
    from explicit_order import explicit_order
    checked=[]
    with (ROOT/'source/holdout.csv').open() as fp:
        for row in csv.DictReader(fp):
            if row['level']=='1' and row['path']!='5-4-2-3-4':continue
            ans=explicit_order(list(map(int,row['side_counts'].split(','))))
            assert ans==[int(row[k]) for k in ('events','N0','N1','N2','N3','Q')]
            checked.append([row['path'],row['level']])
    assert len(checked)==18
    return checked

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Enable assertions')
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'results');p.add_argument('--recount',action='store_true')
    args=p.parse_args();d=scores(args.out)
    (args.out/'audit.json').write_text(json.dumps(d,indent=2)+'\n')
    if args.recount:
        (args.out/'recount.json').write_text(json.dumps(recount(),indent=2)+'\n')
    print('Passed direct pair sums, published baseline comparisons and predeclared prediction checks.')
