import itertools, math
from fractions import Fraction as F
import numpy as np
from scipy.integrate import quad

def explicit_order(n):
    # Generate the actual cartesian point sets. No C++ masks, interval cache or generator thresholds.
    xyz=[np.array(list(itertools.product(range(m),repeat=3)),dtype=np.int32) for m in n]
    offsets=list(itertools.accumulate((len(x) for x in xyz),initial=0))
    future=[0]*offsets[-1]; past=[0]*offsets[-1]
    optical=[quad(lambda u:2/(a+(b-a)*u),0.,1.,epsabs=2e-14)[0] for a,b in zip(n,n[1:])]
    for i,low in enumerate(xyz):
        for j in range(i+1,len(n)):
            product=n[i]*n[j]
            if len(set(n[i:j+1]))==1:
                sq=(F(2*(j-i),n[i])*product)**2;cut=sq.numerator//sq.denominator
            else:
                x=(sum(optical[i:j])*product)**2
                if x>=3*(product//2)**2+1.e-7:cut=3*(product//2)**2
                else:
                    assert abs(x-round(x))>1e-7
                    cut=math.floor(x)
            high=xyz[j];rel=np.empty((len(low),len(high)),dtype=bool)
            for start in range(0,len(low),32):
                delta=abs(low[start:start+32,None,:]*n[j]-high[None,:,:]*n[i])
                delta=np.minimum(delta,product-delta)
                rel[start:start+32]=np.einsum('...i,...i->...',delta,delta)<=cut
            if j==i+1: assert rel.any(axis=1).all() and rel.any(axis=0).all()
            for row,bits in enumerate(np.packbits(rel,axis=1,bitorder='little')):
                future[offsets[i]+row] |= int.from_bytes(bits.tobytes(),'little')<<offsets[j]
            for col,bits in enumerate(np.packbits(rel.T,axis=1,bitorder='little')):
                past[offsets[j]+col] |= int.from_bytes(bits.tobytes(),'little')<<offsets[i]
    remaining=(1<<len(future))-1;widths=[]
    while remaining:
        layer=[u for u,p in enumerate(past) if (remaining>>u)&1 and not (remaining&p)]
        assert layer
        widths.append(len(layer)); remaining-=sum(1<<u for u in layer)
    assert widths==[m**3 for m in n]
    bins=[0,0,0,0]
    for u,after in enumerate(future):
        # Iterate the future point labels; every open Alexandrov interval is the bitwise intersection.
        bits=after
        while bits:
            lowbit=bits & -bits
            j=lowbit.bit_length()-1
            num=(after & past[j]).bit_count()
            if num<4:bins[num]+=1
            bits^=lowbit
    return [len(future),*bins,len(future)-bins[0]+9*bins[1]-16*bins[2]+8*bins[3]]


