"""Generate the held-out orders. Standard Python plus a local C++17 compiler."""
import csv, hashlib, json, subprocess
from decimal import Decimal, localcontext
from fractions import Fraction as F
from functools import cache
from itertools import product, accumulate
from pathlib import Path
from tempfile import TemporaryDirectory
ROOT=Path(__file__).resolve().parent
PLAN='ede9339e038a3a6dbba8535edce007ddea316f6d91c57393db109dc26e82842d'

def seal():
    assert hashlib.sha256((ROOT/'plan.json').read_bytes()).hexdigest()==PLAN

@cache
def optical_step(a,b):
    if a==b: return F(2,a), F(0)
    with localcontext() as c:
        c.prec=90
        l,r=F(Decimal(a).ln()),F(Decimal(b).ln())
    # ln of integers <=16 is below 3. Each correctly rounded log errs by < 1e-88.
    return 2*(r-l)/(b-a),F(4,10**88*abs(b-a))

@cache
def cutoff(span):
    value,error=map(sum,zip(*(optical_step(a,b) for a,b in zip(span,span[1:]))))
    m=span[0]*span[-1]; cap=3*(m//2)**2
    floors=[min(cap,int(((value+sgn*error)*m)**2)) for sgn in (-1,1)]
    assert value>error and floors[0]==floors[1]
    return floors[0]

def layers(w,level):
    if level==0:return w
    return (2*w[0],)+tuple(t for a,b in zip(w,w[1:]) for t in (a+b,2*b))

def make_support():
    ws=[]
    for a,b,c in product((-2,2),(-1,0,1),(-1,0,1)):
        w=(5,*accumulate((4,a,b,c)))
        if min(w)>0:ws.append(w)
    independent={(5,4,i,j,k) for i,j,k in product(range(1,9),repeat=3)
                 if abs(i-4)==2 and abs(j-i)<=1 and abs(k-j)<=1}
    assert len(ws)==17 and set(ws)==independent
    return ws

def generate(out):
    seal()
    tasks=[]
    for i,w in enumerate(make_support()):
        for level in (0,1):
            n=layers(w,level)
            cuts=[cutoff(n[a:b+1]) for a in range(len(n)) for b in range(a+1,len(n))]
            tasks.append((i,level,w,n,cuts))
    lines=[' '.join(map(str,(i,l,len(n),*n,*cuts))) for i,l,w,n,cuts in tasks]
    with TemporaryDirectory() as tmp:
        exe=Path(tmp)/'counter'
        flags=['-std=c++17','-O3']
        cpuinfo=Path('/proc/cpuinfo')
        if cpuinfo.exists() and 'popcnt' in cpuinfo.read_text() and __import__('platform').machine() in ('x86_64','AMD64'):
            flags.append('-mpopcnt')
        subprocess.run(['g++',*flags,str(ROOT/'source/counter.cpp'),'-o',str(exe)],check=True)
        result=subprocess.run([exe],input='\n'.join(lines)+'\n',text=True,capture_output=True,check=True)
    output=result.stdout.splitlines()
    assert len(output)==len(tasks)
    with out.open('w',newline='') as fp:
        wr=csv.writer(fp,lineterminator='\n');wr.writerow(['path','level','side_counts','events','N0','N1','N2','N3','Q'])
        for task,line in zip(tasks,output):
            i,l,w,n,_=task
            ii,ll,v,n0,n1,n2,n3,q=map(int,line.split())
            assert (ii,ll)==(i,l) and v==sum(k**3 for k in n) and q==v-n0+9*n1-16*n2+8*n3
            wr.writerow(['-'.join(map(str,w)),l,','.join(map(str,n)),v,n0,n1,n2,n3,q])

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);generate(p.parse_args().output)
