# Robustheit der Dichtespur und Prüfung auf neuen Staubhistorien

## Befund

Der vor der neuen Auswertung versiegelte Plan steht in `plan.json`. Auf allen 17 neuen, disjunkten Pfaden ergeben die beiden Messvarianten für jede Kopplung im Band [32/45, 162/95] denselben numerischen Entscheid **FAIL**. Damit dominieren im definierten Zeitfenster die Verläufe ohne die festgelegte Umkehr. Auf der Entwicklungsfamilie mit 27 Pfaden wechselt das Gate für beide Zeiger von HOLD zu FAIL. Die einzeln vereinbarten Statusprognosen von der Entwicklungs- auf die neue Familie treffen in einem von vier Fällen zu. Der Bericht erläutert die modellierte Kalibrierung und den Geltungsbereich.

## Wiederholen

Für die Intervallsumme und die numerische Gegenprobe genügt Python 3.10 oder neuer ohne Zusatzmodule. Alle Befehle aus dem entpackten Verzeichnis ausführen. Die geprüfte Referenzausgabe liegt in `results/`.

```sh
sha256sum -c SHA256SUMS
python3 scan.py --out replay
python3 audit.py --out replay
diff results/scan.json replay/scan.json
diff results/audit.json replay/audit.json
```

Die vollständige Neuerzeugung der 34 Kausalordnungen verwendet zusätzlich einen lokalen C++17-Compiler (`g++`). Die optionale unabhängige explizite Nachzählung benötigt NumPy und SciPy. Die Ausgaben lassen sich separat mit den gelieferten Dateien vergleichen.

```sh
python3 generate.py replay/holdout.csv
diff source/holdout.csv replay/holdout.csv
python3 audit.py --recount --out replay
diff results/recount.json replay/recount.json
```

## Versuch und Auswertung

Die Grundgeometrie, die beiden regulierten Wirkungsphasen, der Endvolumenmesser, die festen Staubzeiten und die Gate-Kriterien stammen aus [PR 217](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/217), [PR 218](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/218) und [PR 219](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/219). Die neue Messannahme setzt die Breite des Zeigers gleich der frühen Dichtedosis während eines halben bis ganzen Markierungsintervalls. Der Test variiert die effektive Kopplung an die Aufzeichnung. Im Überlappungskern ist nur ihr Verhältnis zur Zeigerbreite identifizierbar. Die Gravitationsterme der Wirkung stehen fest.

In der Holdout-Familie beträgt die erste freie Breitenänderung nach derselben frühen Kontraktion exakt +2 oder −2, die letzten beiden Zuwächse je −1, 0 oder +1. Der Pfad (5,4,2,1,0) endet auf einer degenerierten Zelle und liegt ausserhalb des vorab festgelegten positiven Supports. Alle übrigen 17 vollständigen Pfade erhalten gleiches Amplitudengewicht. Es gibt auf beiden Gittern eine Bounce-Historie und 16 andere. Die Konstruktion bildet eine disjunkte Familie innerhalb des reduzierten Modells. Der Plan-Hash ist eine lokale Integritätskontrolle. Die Resultate der Entwicklungsfamilie waren bereits exploriert.

Das Gate verwendet dieselben Schwellen wie v0.1. Ohne unaufgelöste Klassen gilt ε = 2 |D_BN| / (D_BB + D_NN) und q_B = D_BB / (D_BB + D_NN). In Einheiten eines einzelnen Amplitudenquadrats gilt D_BB = 1 und D_NN ≥ 1. Ein allein besetzter orthogonaler Endkanal der Nicht-Bounce-Klasse garantiert die Untergrenze auch bei Interferenz in anderen Endkanälen. Damit ist PASS ausgeschlossen. FAIL erfordert zusätzlich für beide Gitter und die Nullkontrolle ausreichende Interferenzkontrolle, auf beiden Gittern q_N ≥ 0,80 sowie eine Drift von höchstens 0,05. Beide Messvarianten behalten den bisherigen Endvolumenmesser.

Der Scan gruppiert Paarterme nach exakten Dosisdifferenzen, Endkanälen, Klassenzugehörigkeit und Phasendifferenzen. Positive Gauß-Kerne werden mit monotonen Randwerten und Rundung nach aussen über das ganze Kopplungsteilintervall eingeschlossen. Intervallarithmetik erfasst auch komplexe Auslöschung und die Normierung. Die zehn Phasen folgen aus exakten Wurzel-Ausdrücken. Unentschiedene Zellen werden halbiert, bis eine einheitliche Gate-Aussage feststeht oder die vorab gesetzte minimale Zellbreite erreicht wird. In den maschinenlesbaren Ergebnissen bedeutet OPEN eine rechnerisch nicht weiter aufgelöste Zelle. Mehrere benachbarte OPEN-Zellen können gemeinsam ein breiteres Übergangsband bilden. Das physikalische HOLD des Gates und das numerische OPEN haben unterschiedliche Bedeutung.

## Dateien

- `generate.py` prüft die Plan-Prüfsumme, erzeugt regulierte Lichtkegel aus konservativ eingegrenzten logarithmischen Integralen und ruft den C++-Zähler auf.
- `source/development.csv` enthält die veröffentlichten und `source/holdout.csv` die neuen Wirkungsdaten. `source/provenance.json` nennt die Ausgangsarchive und übernommene Dateien. In `counter.cpp` wurde die maximal erlaubte kubische Gitterseitenzahl von 14 auf 16 erhöht. `explicit_order.py` enthält die eigenständig verwendbare Nachzählfunktion aus dem Ausgangspaket.
- `scan.py` erlaubt die kontinuierliche Prüfung auf beiden Auflösungen und kontrolliert die SHA-256-Prüfsumme des Gate-Vertrags. `audit.py` vergleicht eine andere Paarsumme mit den Punktwerten und den publizierten Ausgangsgrenzen. Für die explizite geometrische Kontrolle erstellt es alle 17 groben Ordnungen sowie den feinen Bounce-Pfad und zählt alle vier Intervallklassen nach.
- `results/scan.json` enthält die vollständigen Teilintervalle, zusammengefasste Bänder und Punktwerte. `results/audit.json` enthält konservative Grenzen über das ganze Band und das Protokoll der vier Statusvorhersagen. `results/recount.json` identifiziert alle 18 unabhängig nachgezählten Ordnungen. Bruchzeichenketten geben exakte Intervallgrenzen an.
- `report.tex` und der beiliegende PDF-Bericht dokumentieren die Ergebnisse auf Deutsch.
