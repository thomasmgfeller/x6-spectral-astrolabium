"""Outward interval decision over every coupling in a fixed band. Standard library."""
import argparse, csv, hashlib, json
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from functools import cache
from math import isqrt
from pathlib import Path
from generate import ROOT, seal, layers, make_support

# Fixed-point interval coordinates, with outward rounding after every operation.
S=10**38
ZERO=(0,0)
ONE=(S,S)
SIGMA=F(2,5)
LO,HI=F(32,45),F(162,95)
TOL=F(1,32768)

def upper(n,d): return -((-n)//d)
def iv(f):
    x=F(f)*S
    return x.numerator//x.denominator,upper(x.numerator,x.denominator)
def add(x,y): return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[1],-x[0]
def sub(x,y):return add(x,neg(y))
def mul(x,y):
    a=[m*n for m in x for n in y]
    return min(a)//S,upper(max(a),S)
def scale(x,n):return (n*x[0],n*x[1]) if n>=0 else (n*x[1],n*x[0])
def divide(x,y):
    assert y[0]>0
    candidates=[F(a,b) for a in x for b in y]
    return iv(min(candidates))[0],iv(max(candidates))[1]
def sqrt_iv(x):
    assert x[0]>=0
    a=isqrt(x[0]*S); b=isqrt(x[1]*S)
    return a,b+int(b*b != x[1]*S)
def mag(x):
    return max(0,x[0],-x[1]),max(abs(x[0]),abs(x[1]))
def sq(x):
    z=mag(x);return z[0]**2//S,upper(z[1]**2,S)
def hypot(x,y):return sqrt_iv(add(sq(x),sq(y)))
def le(x,f):return F(x[1],S)<=f
def gt(x,f):return F(x[0],S)>f
def show(x):return [str(F(i,S)) for i in x]

@cache
def kernel(t,k):
    if not t or not k:return ONE
    x=-t*k*k
    with localcontext() as ctx:
        ctx.prec=75
        arg=Decimal(x.numerator)/Decimal(x.denominator)
        value=F(arg.exp())
    # On the negative half-line exp is 1-Lipschitz, with rounded result <=1.
    err=abs(F(arg)-x)+F(1,10**74)
    return iv(max(0,value-err))[0],iv(min(1,value+err))[1]

def phases():
    r=sqrt_iv(iv(5))
    cos=mul(add(ONE,r),iv(F(1,4)))
    sin=mul(sqrt_iv(sub(iv(10),scale(r,2))),iv(F(1,4)))
    z=[(ONE,ZERO)]
    for _ in range(1,5):
        x,y=z[-1];z.append((sub(mul(x,cos),mul(y,sin)),add(mul(x,sin),mul(y,cos))))
    return z+[(neg(a),neg(b)) for a,b in z]
ROOTS=phases()

def dose(a,b):return F(25*(a+b),a*a*b*b)
def load(name):
    table={}
    with (ROOT/'source'/f'{name}.csv').open() as stream:
        for row in csv.DictReader(stream):
            w=tuple(map(int,row['path'].split('-')));l=int(row['level'])
            v,n0,n1,n2,n3,q=[int(row[x]) for x in ('events','N0','N1','N2','N3','Q')]
            n=tuple(map(int,row['side_counts'].split(',')))
            assert n==layers(w,l) and v==sum(x**3 for x in n) and q==v-n0+9*n1-16*n2+8*n3
            if w not in table:table[w]={}
            assert l not in table[w];table[w][l]=q
    assert all(set(q)=={0,1} for q in table.values())
    if name=='holdout':assert set(table)==set(make_support())
    else: assert len(table)==27 and all(max(abs(a-b) for a,b in zip(w,w[1:]))<=1 for w in table)
    return table

def record(w):
    v=[F(x**3,125) for x in w]
    label='B' if min(v[0]-v[1],v[1]-v[2],v[3]-v[2],v[4]-v[3],v[2])>=F(1,20) else 'N'
    d=[dose(a,b) for a,b in zip(w,w[1:])]
    return label,int(4*v[-1]),sum(d[:2]),sum(d[2:])

def grouped(table,mode):
    labels=Counter(record(w)[0] for w in table)
    ends=Counter(record(w)[1] for w in table)
    b=next(w for w in table if record(w)[0]=='B')
    # D_BB=1 in units of a single squared amplitude, D_NN>=1 due to the endpoint singleton.
    assert labels['B']==1 and ends[max(ends)]==1 and record(b)[1]!=max(ends)
    buckets=defaultdict(Counter)
    for w,q in table.items():
        c,e,a,b=record(w)
        for other,j in table.items():
            k,f,x,y=record(other)
            if f!=e or (c,k) in [('N','B'),('B','B')]:continue
            d= (a-x+b-y)**2 if mode=='total' else (a-x)**2+(b-y)**2
            exponent=d/(8*SIGMA**2)
            for group,r in (('coarse',4*(j[0]-q[0])),('fine',j[1]-q[1]),('null',0)):
                buckets[group,c+k,exponent][r%10]+=1
    output={'coarse':[],'fine':[],'null':[]}
    for (group,cls,d),mult in buckets.items():
        re=im=ZERO
        for r,num in mult.items():
            x,y=ROOTS[r];re=add(re,scale(x,num));im=add(im,scale(y,num))
        output[group].append((cls,d,re,im))
    return output

def metrics(rows,lo,hi):
    nn=re=im=ZERO
    for cls,d,a,b in rows:
        weight=(kernel(d,hi)[0],kernel(d,lo)[1])
        if cls=='NN':nn=add(nn,mul(a,weight))
        else:
            re=add(re,mul(a,weight));im=add(im,mul(b,weight))
    # Exact structural proof used above for this particular support and all couplings.
    nn=(max(S,nn[0]),nn[1]);assert nn[0]<=nn[1]
    tr=add(ONE,nn)
    return {'epsilon':divide(scale(hypot(re,im),2),tr),'qB':divide(ONE,tr)}

def classify(stats):
    # No U and q_B<=1/2, hence PASS is algebraically impossible in both families.
    coarse,fine=stats['coarse']['qB'],stats['fine']['qB']
    drift=mag(sub(coarse,fine))
    eps=[row['epsilon'] for row in stats.values()]
    if any(gt(e,F(1,21)) for e in eps):return 'HOLD'
    if gt(coarse,F(1,5)) or gt(fine,F(1,5)) or gt(drift,F(1,20)):return 'HOLD'
    if all(le(e,F(1,21)) for e in eps) and all(le(q,F(1,5)) for q in (coarse,fine)) and le(drift,F(1,20)):
        return 'FAIL'
    return 'OPEN'

def evaluate(table,mode):
    grouped_rows=grouped(table,mode)
    def get(lo,hi):
        return {k:metrics(rows,lo,hi) for k,rows in grouped_rows.items()}
    leaves=[]
    def split(lo,hi):
        status=classify(get(lo,hi))
        if status!='OPEN' or hi-lo<=TOL:
            leaves.append((lo,hi,status));return
        mid=(lo+hi)/2
        split(lo,mid);split(mid,hi)
    split(LO,HI)
    assert leaves[0][0]==LO and leaves[-1][1]==HI and all(l[1]==r[0] for l,r in zip(leaves,leaves[1:]))
    bands=[]
    for lo,hi,status in leaves:
        if bands and bands[-1][-1]==status:bands[-1][1]=hi
        else:bands.append([lo,hi,status])
    points={}
    for k in (F(0),LO,F(1),F(5,4),HI):
        m=get(k,k)
        points[str(k)]={'gate':classify(m),'metrics':{a:{b:show(z) for b,z in r.items()} for a,r in m.items()}}
    return dict(points=points,bands=[[str(a),str(b),s] for a,b,s in bands],
                certified_leaf_partition=[[str(a),str(b),s] for a,b,s in leaves])

def run(out):
    seal()
    path=ROOT/'source/contract.json'
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='46de9f779d345aa740758b4cac46e679624aa077e01aba331796bd221c606984'
    contract=json.loads(path.read_text())['arithmetic']
    assert {k:F(v) for k,v in contract.items()}==dict(minimum_branch_weight=F(4,5),maximum_unresolved_weight=F(1,20),maximum_interference=F(1,21),minimum_dynamic_excess_over_kinematic_control=F(1,10),maximum_two_level_weight_drift=F(1,20))
    dev,test=load('development'),load('holdout'); assert not dev.keys() & test.keys()
    # Independent early-time calibration via integral of (1-T/2)^(-3).
    E=lambda t:1/(1-t/2)**2-1
    assert LO==SIGMA/E(F(2,5)) and HI==SIGMA/E(F(1,5))
    out.mkdir(exist_ok=True,parents=True)
    results={}
    for name,table in [('development',dev),('holdout',test)]:
        results[name]={}
        for mode in ('total','split'):
            r=evaluate(table,mode);results[name][mode]=r
            print(name,mode,[(round(float(F(a)),7),round(float(F(b)),7),s) for a,b,s in r['bands']],
                  {k:p['gate'] for k,p in r['points'].items()},flush=True)
    (out/'scan.json').write_text(json.dumps(results,indent=2)+'\n')

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Enable assertions')
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'results');run(p.parse_args().out)
