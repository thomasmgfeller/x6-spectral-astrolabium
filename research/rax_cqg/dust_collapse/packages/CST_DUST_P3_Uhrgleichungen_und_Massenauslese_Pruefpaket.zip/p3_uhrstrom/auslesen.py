"""Two quadratures for each of four matched preparations; phase and marked mass estimates."""
from fractions import Fraction as F
import json
import math
from pathlib import Path
import sys


def analyse(rows,table):
    expected=('0','1/4','1','4')
    if set(rows)!=set(expected):
        raise ValueError('Vier Präparationen 0, 1/4, 1 und 4 erforderlich.')
    points={}
    boxes={}
    for label in expected:
        row=rows[label]
        n=row['n_per_axis']
        if type(n)!=int or n<1:raise ValueError('Positive ganzzahlige Stichprobengrösse erforderlich.')
        xy=row['positive_counts']
        if len(xy)!=2 or any(type(x)!=int or not 0<=x<=n for x in xy):
            raise ValueError('Zwei gültige Zählungen erforderlich.')
        x,y=(2*v/n-1 for v in xy)
        phi=math.atan2(y,x)
        norm=math.hypot(x,y)
        radius=math.sqrt(24/n)
        if norm<=radius:raise ValueError('Portkontrast reicht für eine Phase nicht aus.')
        err=radius/(norm-radius)+float(F(table[label]['phase_bias_max_rad']))+1e-12
        if abs(phi)+err>=math.pi:raise ValueError('Phasenzweig nicht gesichert.')
        points[label]=phi
        boxes[label]=(phi-err,phi+err)
    denominator=(boxes['1/4'][0]-boxes['0'][1],boxes['1/4'][1]-boxes['0'][0])
    if denominator[0]<=0:raise ValueError('Positivstandard und Nullpunkt nicht getrennt.')
    results={}
    for label in ('1','4'):
        numerator=(boxes[label][0]-boxes['0'][1],boxes[label][1]-boxes['0'][0])
        candidates=[.25*x/y for x in numerator for y in denominator]
        results[label]={'point':.25*(points[label]-points['0'])/(points['1/4']-points['0']),
                        'simultaneous_95pct_outer':[min(candidates)-1e-12,max(candidates)+1e-12]}
    return results


if __name__=='__main__':
    try:
        cert=json.loads((Path(__file__).resolve().parent/'zertifikat.json').read_text())
        print(json.dumps(analyse(json.load(sys.stdin),cert['outer']['individual']),indent=2))
    except (ValueError,TypeError,KeyError) as exc:
        sys.exit(str(exc))
