# P3 · Uhrgleichungen und Massenablesung auf derselben N15-Präparation

**Stand 25. November 2026.** Bei Typ 2324 lässt sich die frühere Abweichung der Schnittladung durch Ändern der Zukunftsuhren und Zukunftsdichten auf dem vorgegebenen Feldbereich nicht beseitigen, wenn dazu alle inneren Uhrgleichungen erfüllt werden sollen. Eine neue Auslese verwendet zwei gewöhnliche Auswertungen der Staubwirkung mit verschiedenen Argumenten am Eingangsrand. Ihre relative Phase bestimmt die gesamte markierte Verweildauerdosis. Ein zweiter Versuch am mittleren Ereignis 14 liest den dort transportierten Anteil. Die physikalische Ruhemasse und der dynamische Oberflächenradius bei P3 sind offen.

## Daten und Nachrechnung

Im entpackten Verzeichnis mit Python ab 3.12 ausführen. Die Standardbibliothek genügt.

    sha256sum -c SHA256SUMS
    python3 -B pruefen.py
    python3 -B auslesen.py < zaehlbeispiel.json

Der Offline-Prüfer stellt die analytischen Intervalle, die Katalogprüfung und zwei numerische Auflösungen wieder her. Die 14 rationalen Prüffälle nutzen die originale Wirkungs- und Gradientenroutine des Projekts. Das Zählbeispiel wurde mit einem festen Seed als aggregierte Binomialstichprobe erzeugt. Die Ausgabe der letzten Zeile liefert eine Massenschätzung je Ziel und eine simultane äussere 95-%-Einschliessung. Die archivierten Bruchgrenzen stehen in `zertifikat.json`, die unabhängigen Summen in `quadratur.json`. Die übernommenen Dateien sind in `Herkunft.json` auf einen Git-Stand und SHA-256 festgelegt. [GitHub-Ausgangsstand](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse)

## 1. Was eine Steuerung des Zukunftsrands an den Uhrgleichungen ändern kann

Auf dem ursprünglichen Typ 2324 sind 11, 12, 13 und 14 maximal im Inneren. Von jedem dieser Knoten zu den vier Zukunftsknoten hat die Wirkung dieselbe Zeile (1,−9,16,−8). Für die normierte Uhr Y=T/Δ mit Δ⁴=3/722 hat der Uhrgradient an solch einem j deshalb die Form

    19 ∂S/∂Yⱼ = wⱼ Σᵢ bᵢⱼ(Yᵢ−Yⱼ) + H − K Yⱼ.

Die Summe läuft hier über die Vorgänger. H=Σₖ bⱼₖ wₖYₖ und K=Σₖ bⱼₖ wₖ laufen über die Zukunft. Beide sind allen vier maximalen Knoten gemeinsam, selbst bei beliebigen unterschiedlichen Zukunftsdichten und -uhren. Die Eichung des früheren Transports scheiterte schon innerhalb der ursprünglichen Feldbox. Geprüft wird hier, ob eine geänderte Zukunft diese **selben vorbereiteten inneren Daten** zu einer freien stationären Uhrkonfiguration machen könnte.

Für einfallenden Versatz e sei d=4−e und uⱼ=(Yⱼ−Y₃)/d. Der normierte eingehende Anteil gⱼ ist der erste Term rechts geteilt durch MΔd. Der Störterm von der Zukunft ist affin in uⱼ. Daher muss für stationäre Uhren an 11, 12 und 14 gelten

    g₁₁ − g₁₂ − r (g₁₄ − g₁₂) = 0,       r=(u₁₁−u₁₂)/(u₁₄−u₁₂).

Der Nenner hat im ganzen Paket festen Abstand zu null. Der Prüfer verwendet die beiden Uhrfenster des Originals, alle sieben unabhängigen Uhrabweichungen mit Halbbreite 1/64 und alle relativen Dichteabweichungen bis 1 %. Über 128 Versatzintervalle je Lappen liegt die linke Seite im linken Lappen zwischen −5,130 und −3,449, im rechten zwischen −3,215 und −1,648. Mindestens einer der drei normierten Gradienten |19 ∂S/∂Yⱼ|/(MΔd) übersteigt links 1,401 und rechts 0,669. Der Ausschluss betrifft die Uhrgleichungen im gesamten deklarierten positiven Paket. Ein Quantenpfadintegral kann nichtstationäre Belegungen enthalten.

## 2. Zwei Stellungen der vier Eingangsuhren lesen die Gesamtdosis

Das neue Instrument verwendet zwei Quellenarme mit identischen sonstigen Feldern und demselben Hilfsmass. Die tatsächlich verwendeten Integrationsfenster und der unabhängige Dosierungsparameter werden bei der Quellenvariation festgehalten. Zum Vergleich hat die Vorstudie eine gemischte zweite Ableitung derselben Feinhistorie und eine zusätzlich definierte Kopplung des Zeigers an diese Ableitung verwendet. Hier wird jeder der beiden Arme mit einem einzelnen neuen Argument in der gewöhnlichen quadratischen Staubwirkung berechnet. Die gewählten Uhrenprofile und die kohärente Kontrolloperation sind zusätzliche Modellannahmen. [Vorstudie zur markierten Masse](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/n15_massenquelle_v0_1)

Setze z=(29,23,16,8), l=(47/1856,3/184,1/128,0), t=120 und s=3/8. Die neue Mitte der vier frühen Uhren ist Ȳᵢ=Y₃−t lᵢ, die beiden Arme verwenden Ȳᵢ±s zᵢ/(2d). Der Faktor d wird am ursprünglichen Rand gemessen. Kein Arm benötigt die Zieldosis oder eine innere Uhrablesung als Eingang. Die vier frühen Uhren bleiben auf beiden Armen streng geordnet und vor allen inneren Uhren der geprüften Feldbox. Die vergangenen Argumente unterscheiden sich von den früher fixierten Referenzwerten.

Für j mit 0, 1, 2 inneren Vorgängern sind die drei Eingangszeilen Bⱼ der Reihe nach (−8,16,−9,1), (0,−8,16,−9), (0,0,−8,16). Sie erfüllen Bⱼz=0 und −Σᵢ bᵢⱼ zᵢlᵢ=1. In der Differenz der beiden quadratischen Wirkungen verschwindet folglich die unbekannte Zieluhr Yⱼ, während der verbleibende Koeffizient t für alle inneren Dichten gleich ist. Auf jedem Arm wird der ausschliesslich aus den vier Vergangenheitsfeldern berechenbare Wirkungsanteil vor der Summation phasenkorrigiert. Dieser Schritt benötigt Zugriff auf die am Rand präparierte kollektive Dichte und Uhr. Im getesteten Modell hängen die restlichen Skalar- und Gravitationsfaktoren auf dem festen Typ nicht von diesen Staubuhrargumenten ab. Ein gemeinsamer Skalarfaktor muss für die normierte Auslese ungleich null sein.

    S₋ korrigiert − S₊ korrigiert = (ts/19d) Σⱼ wⱼ = λ M Σⱼ fⱼ(1+ξⱼ),
    λ = tsΔ/19 = 0,6013190… rad je Einheit markierter Masse.

Dabei ist wⱼ=MΔd fⱼ(1+ξⱼ), mit Verweildaueranteilen fⱼ≥0, Σ fⱼ=1. Auf dem exakten Verweilgraphen ist die Formel unabhängig von der Verteilung der Pfadgewichte. Auf dem endlich breiten Originalpaket schwanken die inneren Dichten um je bis zu 1 %. Eine rückwirkende Neuzentrierung der Felder nach dem Puls würde ein anderes Experiment ergeben.

**Reichweite.** Der Katalog enthält 23 von 1 048 Typen, deren innere Ereignisse sämtlich höchstens zwei innere Vorgänger besitzen. Auf allen 23 gilt dieselbe Wirkungsidentität. Bei 179 weiteren Typen tritt eine Zeile mit genau drei inneren Vorgängern auf. Dort erreicht nur eine frühe Uhr das Ziel mit von null verschiedenem Gewicht. Für zwei beliebige Eingangsstellungen zwingt die Eliminierung der unbekannten Zieluhr ihre Differenz an dieser einen frühen Uhr zu null. Damit verschwindet auch ihre Dichteantwort. Bei den übrigen 846 Typen existiert mindestens eine am Eingang vollständig unsichtbare Dichte. Das ist eine Grenze für eine punktweise, von unbekannten inneren Uhren unabhängige **Zweiarm-Messung der vollen, frei variierbaren Dichtesumme mit vier frühen Uhrargumenten**. Die kohärente Präzisionsprüfung dieser Arbeit wurde auf 2324 allein durchgeführt.

## 3. Kohärente Summe, Eichung und Fehler

Der ausgelesene Winkel ist arg(A₋A₊*), wobei jeder Arm seine eigene Summe über die vollständige Feldbox erhält. A₀ bezeichne die Amplitude aus dem Mittel der zwei korrigierten Wirkungen, und c eine untere Schranke für ihren Betrag pro Paketmass. Der gemeinsame Wirkungswinkel wird mit Taylorentwicklung der quadratischen Terme um jede Feldboxmitte und mit rationalen Intervallen eingeschlossen. Je Versatzlappen werden 32 Teilintervalle benutzt. Für eine Winkelspanne W genügt c≥1−W²/8. Bei den drei positiven Massen beträgt die untere Schranke mindestens 0,7368. Beide ursprünglichen Eingangsdichtezentren sind durch die identische armweise Phasenkorrektur der Vergangenheitsfelder erfasst.

Bei festen Uhren ist die gemeinsame Wirkung affin in den relativen Dichteabweichungen ξⱼ mit Koeffizienten aⱼ. Im vorgeschriebenen Produktmass sind die ξⱼ bedingt unabhängig und gleichverteilt in [−ε,ε], ε=0,01. Die Breite der Dichteintervalle geht als positiver, uhrabhängiger Faktor ins äussere Integral ein. Nach Abzug der erwarteten Armphase bleibt der Störwinkel vΣ fⱼξⱼ mit v=λM/2. Der bedingte Mittelwert der gewichteten Abweichung ist null, ihre Varianz höchstens ε²/3. Mit |exp(ix)−1|≤|x|, der quadratischen Restgliedschranke und Cauchy-Schwarz unterscheidet sich die korrigierte Armamplitude relativ zu A₀ um höchstens

    η ≤ ε² (|v| Σ|aⱼ| + v²/2) / (3c),      |Phasenfehler beider Arme| ≤ 2η/(1−η).

Hier wird die Differenz beider Winkel begrenzt. Die Bias-Grenzen am Eingang betragen für M=1/4, 1 und 4 jeweils weniger als 0,00000086, 0,0000141 und 0,000272 rad. Sie gelten für die verwendete positive flache Feldpräparation und den deklarierten gemeinsamen Endeffekt. Eine anders geformte oder mehrtypige Quantenpräparation benötigt eigene Schranken.

Der Nullpunkt wird im leeren Inneren und der Standard bei markierter Dosis 1/4 erzeugt. Für jeden Test gilt M̂=(1/4)(φ_test−φ₀)/(φ_ref−φ₀). Der Sollwert geht erst in den anschliessenden Vergleich ein. Bei höchstens 0,0002 rad Ablesefehler pro Winkel ergeben sich einschliesslich des Modellbias die folgenden nach aussen gerundeten Resultate.

| Markierte Dosis | M̂/M mit separater Null- und Positiveichung |
| --- | ---: |
| 1 | [0,99665; 1,00337] |
| 4 | [0,99706; 1,00296] |

Die eigentliche numerische Gegenprobe berechnet für beide Vorzeichen die quadratische Wirkung aus allen Kanten neu. Jeder der sieben uniformen Dichtejitter wird bei festen Uhren analytisch als Sinc-Faktor integriert. Über die Uhren und die beiden Randlappen laufen separat Halton-Reihen mit 512 und 1 024 Punkten je Lappen. Die Uhr- und Dichte-Jacobifaktoren bleiben im normierten Integral. Die numerische Genauigkeit dieser Reihen wird durch die Auflösungsänderung kontrolliert. Die ausgewiesenen Garantieintervalle stammen aus den separaten analytischen Schranken.

**Endliche Zählung.** Zwei orthogonale Analysatorstellungen geben die beiden Komponenten des Portkontrasts. Bei stabilem, balanciertem kohärentem Interferometer beträgt dessen Sichtbarkeit 2|A₊A₋|/(|A₊|²+|A₋|²). Aus den beiden Armgrenzen folgt für alle vier Präparationen ein Wert über 0,955. Nach Hoeffding und der Vereinigungsabschätzung für acht Binomialanteile ist der Vektorfehler pro Präparation simultan mit mindestens 95 % Wahrscheinlichkeit kleiner als √(24/n). Bei n=10⁹ unabhängigen angenommenen Ereignissen je Stellung und Präparation reicht das für die angenommene Winkelgenauigkeit. Das ist eine konservative **hinreichende** Zählung unter idealer Analysator- und Quellsteuerung. Im Offline-Beispiel werden nur acht Binomialzahlen erzeugt. Es wurden keine physischen Ereignisse gemessen. [Hoeffding-Schranke, CMU](https://www.stat.cmu.edu/~arinaldo/Teaching/36755/F16/Scribed_Lectures/160831AdvStatTheory.pdf)

## 4. Lokaler Gegenversuch am mittleren Ereignis

Ereignis 14 ist im Inneren isoliert. Es bildet einen vollständigen der fünf markierten Transportpfade, dessen Verweildaueranteil im ursprünglichen Modell genau 1/5 beträgt. Seine Eingangszeile lautet (−8,16,−9,1), seine Ausgangszeile (1,−9,16,−8). Beide summieren sich zu null. Mit den ursprünglichen Randuhren, gemeinsamer Zukunftsdichte F=1/8 und festgehaltenen übrigen Feldern gilt exakt

    19 ∂S/∂Y₁₄=(1+e)w₁₄−F,       ∂²S/∂Y₁₄²=0.

Das ist zugleich die Differenz der Ladungen der zwei unmittelbar benachbarten Ideale bis auf das vereinbarte Vorzeichen und den Faktor Δ. Eine neue interne Quelle verschiebt allein Y₁₄ um ±h/2, h=(1/8)/[(1+e)d]. Um beide Übersetzungen im ursprünglichen schmalen Uhrfenster zu halten, wird nur die mittlere Hälfte seines Y₁₄-Eingangsfensters präpariert. Jede maximale Verschiebung bleibt kleiner als 0,02730 in Y, die Mindestreserve beträgt 0,02836. Der bekannte Vakuumterm wird durch die armweise Randphase ±hF/38 kompensiert. Dann beträgt die relative Phase bei gleicher Fünfpfadaufteilung λ_lokal M (1+ξ₁₄) mit λ_lokal=Δ/760≈0,0003340661. Das Vorzeichen der abgegriffenen Interferenz ist gegenüber der ersten Quelle vertauscht. Mit einem hypothetischen Winkelbudget von 10⁻⁷ rad pro Ablesung lassen sich auch die lokal markierten Dosen 1 und 4 innerhalb von 2 % übertragen. Dieses viel kleinere Fehlerbudget wurde nicht gemessen. Die verwendeten ursprünglichen Phasenhüllen gelten auch auf dem Teilfenster; der analytische Dichtejittertest nutzt hier nur ξ₁₄.

Bei verändertem Anteil q₁₄ misst diese Quelle in Einheiten der ursprünglichen Eichung 5q₁₄M. Die zusätzliche numerische Gegenprobe setzt für (14) das Gewicht 1/4 und für jeden der anderen vier Pfade 3/16. Für M=4/5 ist dann auf (14) dieselbe Masse 1/5 unterwegs wie bei M=1 im ursprünglichen Routing. Entsprechend liegt die lokale Phase in beiden Fällen bei rund 0,00033407 rad, die Eingangsphasen liegen bei 0,48106 und 0,60132 rad. Bei festem M=1 und derselben Umverteilung liefert die lokale Quelle den Faktor 1,25, die Eingangsauslese weiterhin rund 1. Auf 120 der 1 048 Typen existiert genau ein im Inneren isoliertes Ereignis. Dessen lokale Auslese betrifft zunächst den dortigen Pfadanteil.

## Physischer Status

Auf dieser endlichen Präparation sind eine Gesamtdosierung und eine getrennte lokale Kontrolle aus der vorgegebenen Wirkung ausführbar. Der ursprüngliche Wirkungsstrom behält den früher gefundenen Schnittfehler. Die hier geprüften Quellen setzen kohärente Kontrolle über die geänderten Uhrargumente, die Phasenkorrektur, einen zugehörigen Endeffekt und eine bekannte Referenz voraus. P3 verlangt weiterhin eine unabhängige **physikalische** Ruhemasse-Eichung, die dynamische Zuordnung der materiellen Oberfläche zur P3-Eigenzeit und ihre Geometrie auf derselben Präparation. Alle 60 physischen Prüfpunkte stehen auf NOT_RUN.

[Originale synchronisierte Präparation](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/synchronized_distributed_dust_v0_1) · [P3-Prüfvertrag](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/correspondence_v0_1)
