# Anschluss an den Transporttest auf Typ 2324
25. November 2026. Lokaler prospektiver Rechenplan nach Einsicht in den früheren Transportbefund und die Struktur der Wirkungszeilen. Keine externe Vorregistrierung.

1. Die inneren Uhrgleichungen bei festgehaltenen Dichten auf der synchronisierten Fünfpfad-Präparation testen. Für die maximalen Ereignisse prüfen, welche Kombinationen durch allgemeine Zukunftsfelder verändert werden können. Einen Ausschluss auf volle Uhren- und Dichtefenster ausdehnen, falls die Einschliessung dies erlaubt.
2. Aus der Wirkung eine lokale, unabhängig vom Sollwert definierte Massenantwort am mittleren Uhrereignis suchen. Beide Uhrfenster, die Vergleichsdosen 0 und 1/4 sowie die zurückgehaltenen markierten Dosen 1 und 4 verwenden. Am Gesamtstrom und an alternativer Pfadverteilung prüfen, welche Grösse die Quelle tatsächlich abliest.
3. Beide Quellenarme kohärent summieren. Phasenstreuung, das endliche Dichteband, die Übertragung der Referenz und den nötigen Phasenfehler explizit begrenzen. Direkte Quadratur oder deterministische Stichprobe aus den ursprünglichen Amplituden als numerische Gegenprobe. Die physische Umsetzung des Eingriffs und der P3-Status sind getrennt auszuweisen.

Nach Sichtung der drei vorkommenden Eingangsschichten wurde zusätzlich eine Randquelle aus zwei neuen Stellungen der vier frühen Uhren konstruiert. Ihr gemeinsames Profil kompensiert die unbekannten inneren Uhren, ihr antisymmetrischer Anteil koppelt mit demselben Koeffizienten an alle sieben Dichten. Die Kataloggrenze, die Gegenproben mit umverteiltem Fluss und der synthetische Zähltest sind explorative Erweiterungen.

