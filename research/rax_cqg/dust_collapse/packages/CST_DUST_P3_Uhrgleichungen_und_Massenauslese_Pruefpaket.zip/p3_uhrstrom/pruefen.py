from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys

import auslesen
import gegenprobe
import randquelle
import rechnung


ROOT=Path(__file__).resolve().parent
def write(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

def read(name):
    return json.loads((ROOT/name).read_text())

def run(generate):
    if not __debug__ or sys.version_info<(3,12):
        raise SystemExit('Python ab 3.12 ohne -O erforderlich.')
    for name,meta in read('Herkunft.json')['files'].items():
        assert sha256((ROOT/name).read_bytes()).hexdigest()==meta['sha256'],name
    records=read('quellen/inputs/checkpoints.json')
    assert len(records)==60 and all(r['execution']=='NOT_RUN' and r['checkpoint_id']=='P3' for r in records)
    cert={'clock_equations':rechnung.boundary_test(),'isolated_event_census':rechnung.catalogue(),
          'local':rechnung.readout_bounds(),'outer':randquelle.calibrated(),
          'physical':{'execution':'NOT_RUN','records':60,'physical_mass':None,'physical_radius':None}}
    assert cert['outer']['order_types']=={'eligible':23,'one_visible_past_node':179,'invisible_density':846}
    assert cert['isolated_event_census']=={'0':928,'1':120}
    assert all(F(v['max_gradient_normalized_at_least'])>F(66,100) for v in cert['clock_equations'].values())
    # Conservative simultaneous phase error for n=10^9 per port axis and mass, all quadratures.
    floor=min(F(v['arm_modulus_floor']) for v in cert['outer']['individual'].values())
    vis=2*floor/(1+floor*floor)
    rho=F(155,10**6)
    assert rho*rho>=F(24,10**9) and rho/(vis-rho)<F(cert['outer']['phase_readout_absolute_error_rad'])
    cert['count_design']={'n_per_axis_and_mass':10**9,'n_axes':8,'visibility_floor':str(vis),'family_coverage':'at least 0.95'}
    direct=gegenprobe.run(1024)
    if generate:
        write('zertifikat.json',cert)
        write('quadratur.json',direct)
        write('zaehlbeispiel.json',{k:{a:b for a,b in row.items() if a!='phase_estimate'} for k,row in
              gegenprobe.synthetic_counts(direct['direct_integrals']['1024']['outer'])['counts'].items()})
    else:
        assert cert==read('zertifikat.json')
    for d in (direct,read('quadratur.json')):
        assert d['rational_direct_cases']==14
        for setting in ('local','outer'):
            q=cert[setting]
            lam=float(F(q['lambda'][0]))
            for size,v in d['direct_integrals'].items():
                for mass,row in v[setting].items():
                    if mass=='0':
                        assert abs(row['phase_rad'])<1e-12
                        continue
                    err=float(F(q['individual'][mass]['phase_bias_max_rad']))
                    assert abs(row['phase_rad']-lam*float(F(mass)))<=err+1e-12
            for mass in ('4/5','1'):
                target=lam*float(F(mass))*(1.25 if setting=='local' else 1.)
                assert abs(d['redistributed'][setting][mass]['phase_rad']-target)<1e-7
    fits=auslesen.analyse(read('zaehlbeispiel.json'),cert['outer']['individual'])
    for m,vals in fits.items():
        a,b=vals['simultaneous_95pct_outer']
        assert float(m)*.98<a<float(m)<b<float(m)*1.02
    try:
        rows=read('zaehlbeispiel.json')
        rows['1']['positive_counts']=[0,10**9+1]
        auslesen.analyse(rows,cert['outer']['individual'])
    except ValueError:pass
    else:raise AssertionError('Ungültige Zähldaten akzeptiert.')
    print('PASS – Uhrgleichungen, zwei Quellarme, Katalog, Fehlergrenzen und Zählauswertung. P3 60 NOT_RUN.')


if __name__=='__main__':
    run(sys.argv[1:]==['--generate'])
