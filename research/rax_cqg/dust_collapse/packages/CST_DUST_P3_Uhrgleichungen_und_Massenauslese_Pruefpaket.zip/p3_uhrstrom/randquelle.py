"""Two ordinary past-clock arguments with a common response to every interior density."""
from fractions import Fraction as F
from rechnung import (ROOT,I,PRE,FUT,ORDER,B,support,tube,profile,fix,add,sub,mul,recip,
                      magnitude,hull,saved,tiles,DENSITY_WIDTH)

Z=(29,23,16,8)
L=(F(47,1856),F(3,184),F(1,128),F(0))
T=F(120)
S=F(3,8)
MASS=(F(0),F(1,4),F(1),F(4))


def square(p):
    return (0 if p[0]<=0<=p[1] else min(v*v for v in p),max(v*v for v in p))


def constants():
    for j in I:
        row=[B.get((i,j),0) for i in PRE]
        assert sum(a*z for a,z in zip(row,Z))==0
        assert -sum(a*z*l for a,z,l in zip(row,Z,L))==1
    groups={}
    for code in support.catalogue():
        nodes,rel=support.geometry(code)
        highest=max(sum((w,v) in rel for w in nodes) for v in nodes)
        key='eligible' if highest<=2 else 'one_visible_past_node' if highest==3 else 'invisible_density'
        groups[key]=groups.get(key,0)+1
    return groups


def source(e,side):
    midpoint=-2+e
    return {i: midpoint-T*L[i]+side*S*Z[i]/(2*(4-e)) for i in PRE}


def coeff_boxes(e,u):
    dur=sub(fix(4),e)
    y3=add(fix(-2),e)
    y={i:sub(y3,fix(T*L[i])) for i in PRE}
    y.update({j:add(y3,mul(dur,u[j])) for j in I})
    y.update({j:fix(j-5) for j in FUT})
    center={j:(a+b)/2 for j,(a,b) in y.items()}
    deviations={j:sub(y[j],fix(center[j])) for j in y}
    h=mul(fix(S/2),recip(dur))
    # The four source arguments must remain ordered; every shifted past clock is earlier than every interior clock.
    assert min(T*(L[i]-L[i+1])-h[1]*abs(Z[i]-Z[i+1]) for i in range(3))>0
    assert min(v[0] for v in u.values())*dur[0]>h[1]*Z[-1]
    c={}
    for j in I+FUT:
        lin={k:F(0) for k in y}
        const=F(19)
        quad=fix(0)
        for i in y:
            b=B.get((i,j),0)
            if not b:continue
            diff=center[i]-center[j]
            const+=b*diff*diff
            lin[i]+=2*b*diff
            lin[j]-=2*b*diff
            quad=add(quad,mul(fix(b),square(sub(deviations[i],deviations[j]))))
        term=add(fix(const),quad)
        for i,weight in lin.items():
            term=add(term,mul(fix(weight),deviations[i]))
        correction=sum(B.get((i,j),0)*Z[i]**2 for i in PRE)
        c[j]=mul(fix(F(1,19)),add(term,mul(fix(correction),square(h))))
    return c


def phase_bounds():
    center,u,f=profile()
    _,_,_,_,flo,fhi=tube.template(2324)
    spans={m:[] for m in MASS}
    asums={m:[] for m in MASS}
    for win in support.WINDOWS:
        for tile in tiles(win,32):
            e=mul(tile,recip(support.DELTA))
            c=coeff_boxes(e,u)
            dur=mul(support.DELTA,sub(fix(4),e))
            future=fix(0)
            for j in FUT:future=add(future,mul(fix(-F(1,16)),c[j]))
            part=fix(0)
            asum=F(0)
            for j,lo,hi in zip(I,flo,fhi):
                a=mul(fix(-F(1,2)),mul(dur,mul((lo,hi),c[j])))
                part=add(part,mul((1-DENSITY_WIDTH,1+DENSITY_WIDTH),a))
                asum+=magnitude(a)
            for m in MASS:
                spans[m].append(add(future,mul(fix(m),part)))
                asums[m].append(m*asum)
    return {m:(hull(spans[m]),max(asums[m])) for m in MASS}


def calibrated():
    count=constants()
    phase=phase_bounds()
    lam=mul(fix(T*S/19),support.DELTA)
    individual={}
    for m,(phase_range,asum) in phase.items():
        width=phase_range[1]-phase_range[0]
        # Positive common measure. After rotation to the midpoint its real part is at least 1-width^2/8.
        contrast=1-width**2/8
        assert contrast>0,(m,float(width))
        t=m*lam[1]/2
        error=(t*asum+t*t/2)*DENSITY_WIDTH**2/(3*contrast)
        assert error<1
        bias=2*error/(1-error)
        individual[str(m)]={'phase_range':saved(phase_range),'common_contrast_lower':str(contrast),
                            'abs_action_slope_sum_max':str(asum),'phase_bias_max_rad':str(bias),
                            'arm_modulus_floor':str(contrast*(1-error))}
    rad_error=F(1,5000)
    gain={}
    for m in MASS[2:]:
        def rel(m):
            return (2*rad_error+F(individual[str(m)]['phase_bias_max_rad']))/(lam[0]*m)
        tar,ref=rel(m),rel(F(1,4))
        band=((1-tar)/(1+ref),(1+tar)/(1-ref))
        assert F(98,100)<=band[0]<=band[1]<=F(102,100)
        gain[str(m)]=saved(band)
    assert lam[1]*4+F(individual['4']['phase_bias_max_rad'])+rad_error<3
    return {'order_types':count,'lambda':saved(lam),'individual':individual,
            'phase_readout_absolute_error_rad':str(rad_error),'transfer_ratio_to_marked_mass':gain}
