"""Direct summation of both unmodified action arguments, with analytic density integration."""
import cmath
from fractions import Fraction as F
import math
import random
from rechnung import B,CODE,I,PRE,FUT,PATHS,BETA_PULSE,FUTURE_DENSITY,support,variation,profile
from randquelle import source,S,T,Z,L

DELTA=(3/722)**.25
PAIRS=tuple(B.items())


def direct_action(Y,w):
    # Archived matter_action uses Gamma= sum b*dY^2/2. Separate its constant and scale kinetic part to 1/19.
    s=variation.matter_action(CODE,15,Y,w)
    pure=-sum(w)/2
    return pure+(s-pure)*F(2,19)


def exact_comparison():
    cen=profile()[0]
    rng=random.Random(2324)
    checks=0
    for e in (-F(1,4),F(1,4)):
        for jtest in range(7):
            u={v:x+F(rng.randrange(-4,5),512) for v,x in cen.items()}
            y=[F(i-5) for i in range(15)]
            y[3]+=e
            for v in I:y[v]=y[3]+(4-e)*u[v]
            dens=[F(1,8) for v in y]
            for v in I:dens[v]=F(rng.randint(1,70),100)
            fixed=[dens[v] if v in PRE else F(0) for v in range(15)]
            arms=[]
            for sign in (-1,1):
                src=y.copy()
                for j,clock in source(e,sign).items():src[j]=clock
                arms.append(direct_action(src,dens)-direct_action(src,fixed))
            assert arms[0]-arms[1]==T*S*sum(dens[j] for j in I)/(19*(4-e))
            for v in I:
                weights=[F(int(i==v)) for i in range(15)]
                sy=y.copy();sy[14]+=F(1,17)
                dn=17*(direct_action(sy,weights)-direct_action(y,weights))
                assert dn==(1+e)/19 if v==14 else dn==0
            gradient=variation.current_and_gradient(CODE,15,y,dens)[1]
            assert gradient[14]*F(2,19)==((1+e)*dens[14]-FUTURE_DENSITY)/19
            checks+=1
    return checks


def halton(n,b):
    value=0.
    f=1/b
    while n:
        n,r=divmod(n,b)
        value+=r*f
        f/=b
    return value


def sinc(v):
    return math.sin(v)/v if v else 1.


def direct_arms(n,local,masses=(0.,.25,1.,4.),redistributed=False):
    center={i:float(v) for i,v in profile()[0].items()}
    accum={m:[0j,0j,0.] for m in masses}
    for k in range(1,n+1):
        h=[halton(k,b) for b in (2,3,5,7,11,13,17,19,23)]
        # Integrate both lobes with equal outer measure.
        for lobe in (-1,1):
            e=lobe*(1/32+h[0]/16)/DELTA
            span=4-e
            u={v:center[v]+(2*h[i+1]-1)/(128 if local and v==14 else 64) for i,v in enumerate(I)}
            fractions=dict.fromkeys(I,0.)
            for path in PATHS:
                cuts=[0.]+[(u[a]+u[b])/2 for a,b in zip(path,path[1:])]+[1.]
                weight=(.25 if len(path)==1 else 3/16) if redistributed else 1/len(PATHS)
                for v,lo,hi in zip(path,cuts,cuts[1:]):fractions[v]+=(hi-lo)*weight
            rad=1/8+(2*h[8]-1)/32
            for index,side in enumerate((-1,1)):
                y={v:float(v-5) for v in PRE+FUT}
                y[3]+=e
                y.update({v:-2+e+span*u[v] for v in I})
                if local:
                    eta=float(BETA_PULSE)/((1+e)*span)
                    y[14]+=side*eta/2
                    comp=side*eta/304  # +side*eta*(1/8)/(2*19)
                else:
                    for i in PRE:
                        y[i]=-2+e-float(T*L[i])+side*float(S)*Z[i]/(2*span)
                    comp=0.
                C=[1.]*15
                for (i,j),b in PAIRS:
                    C[j]+=b*(y[i]-y[j])**2/19
                exterior=-sum(C[j] for j in FUT)/16
                if local:exterior-=rad*sum(C[j] for j in PRE)/2
                for m,acc in accum.items():
                    a=[-.5*DELTA*span*m*fractions[v]*C[v] for v in I]
                    averaged=cmath.exp(1j*(comp+exterior+sum(a)))*math.prod(sinc(.01*x) for x in a)
                    jac=span**(14 if m else 7)*(math.prod(fractions.values()) if m else 1)
                    acc[index]+=jac*averaged
                    if index==0:acc[2]+=jac
    table={}
    for m,(a,b,total) in accum.items():
        a,b=a/total,b/total
        product=(b*a.conjugate()) if local else (a*b.conjugate())
        phase=cmath.phase(product)
        vis=2*abs(product)/(abs(a)**2+abs(b)**2)
        table[str(F(m).limit_denominator(10**6))]={'phase_rad':phase,'visibility':vis,'abs_minus':abs(a),'abs_plus':abs(b)}
    return table


def synthetic_counts(table,n=10**9):
    rng=random.Random(250112324)
    results={}
    for m,v in table.items():
        phi,vis=v['phase_rad'],v['visibility']
        x=rng.binomialvariate(n,(1+vis*math.cos(phi))/2)
        y=rng.binomialvariate(n,(1+vis*math.sin(phi))/2)
        results[m]={'n_per_axis':n,'positive_counts':[x,y],'phase_estimate':math.atan2(2*y/n-1,2*x/n-1)}
    estimates={}
    for m in ('1','4'):
        phi0=results['0']['phase_estimate']
        est=.25*(results[m]['phase_estimate']-phi0)/(results['1/4']['phase_estimate']-phi0)
        estimates[m]=est
    return {'counts':results,'calibrated_estimates':estimates}


def run(n=512):
    return {'rational_direct_cases':exact_comparison(),'redistributed':{label:direct_arms(n,local,(.8,1.),True) for label,local in [('outer',False),('local',True)]},
        'direct_integrals':{str(size):{'outer':direct_arms(size,False),'local':direct_arms(size,True)}
                            for size in (n//2,n)}}
