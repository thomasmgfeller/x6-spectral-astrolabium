"""Exact finite-window and coherent-source certificates for the marked five-path preparation."""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'quellen'))
import coherence
import support
import tube
import variation
from gluing import encode

I,ORDER=support.geometry(2324)
PATHS,_=support.paths_and_edges(ORDER)
CODE=encode(ORDER,15)
B={(a,b):k for a,b,k in variation.edges(CODE,15) if k}
PRE=support.PAST
FUT=support.FUTURE
FUTURE_DENSITY=F(1,8)
HALF_WIDTH=F(1,64)
DENSITY_WIDTH=F(1,100)
BETA_PULSE=F(1,8)
ZERO=(F(0),F(0))

def fix(x):return (F(x),F(x))
def add(x,y):return x[0]+y[0],x[1]+y[1]
def sub(x,y):return x[0]-y[1],x[1]-y[0]
def mul(x,y):
    v=[a*b for a,b in product(x,y)]
    return min(v),max(v)
def recip(x):
    if x[0]<=0<=x[1]:raise ValueError('Nenner enthält null')
    return 1/x[1],1/x[0]
def magnitude(x):return max(map(abs,x))
def hull(rows):return min(a for a,b in rows),max(b for a,b in rows)
def saved(x):return list(map(str,x))
def tiles(w,n):
    for i in range(n):
        yield tuple(w[0]+(w[1]-w[0])*F(j,n) for j in (i,i+1))


def profile():
    paths,center,r,eps,lo,hi=tube.template(2324)
    assert r==HALF_WIDTH and eps==DENSITY_WIDTH and list(paths)==list(PATHS)
    u={i:(center[i]-r,center[i]+r) for i in I}
    f={i:mul((1-eps,1+eps),(l,h)) for i,l,h in zip(I,lo,hi)}
    assert all(B.get((j,v),0)==b for j in (11,12,13,14) for v,b in zip(FUT,(1,-9,16,-8)))
    return center,u,f


def inner_target(j,e,u,f):
    # Incoming gradient divided by M*Delta*(4-e). Collect the coefficient of u_j first.
    dur=sub(fix(4),e)
    raw=ZERO
    for i in PRE[:-1]:
        raw=add(raw,mul(fix(B.get((i,j),0)),sub(fix(i-3),e)))
    drift=ZERO
    for i in I:
        drift=add(drift,mul(fix(B.get((i,j),0)),u[i]))
    total=sum(B.get((i,j),0) for i in PRE+I)
    return mul(f[j],add(raw,mul(dur,sub(drift,mul(fix(total),u[j])))))


def boundary_test():
    center,u,f=profile()
    r=mul(sub(u[11],u[12]),recip(sub(u[14],u[12])))
    out={}
    for tag,window in zip(('left','right'),support.WINDOWS):
        residuals=[]
        iso=[]
        for tile in tiles(window,128):
            e=mul(tile,recip(support.DELTA))
            g={j:inner_target(j,e,u,f) for j in (11,12,14)}
            residuals.append(sub(sub(g[11],g[12]),mul(r,sub(g[14],g[12]))))
            iso.append(mul(mul(add(fix(1),e),sub(fix(4),e)),mul(support.DELTA,f[14])))
        res=hull(residuals)
        assert res[1]<0
        bound=-res[1]/(1+magnitude(sub(fix(1),r))+magnitude(r))
        b=hull(iso)
        out[tag]={'affine_residual':saved(res),'max_gradient_normalized_at_least':str(bound),
                  'future_density_required_at_node_14_per_unit_mass':saved(b)}
    return out


def catalogue():
    counts=Counter(); example=None
    for code in support.catalogue():
        nodes,rel=support.geometry(code)
        paths,_=support.paths_and_edges(rel)
        isolated=[v for v in nodes if all((v,w) not in rel and (w,v) not in rel for w in nodes)]
        assert {p[0] for p in paths if len(p)==1}==set(isolated)
        counts[len(isolated)]+=1
        if isolated:
            for v in isolated:
                assert [sum((i,z) in rel and (z,v) in rel for z in range(15)) for i in PRE]==[3,2,1,0]
                assert [sum((v,z) in rel and (z,j) in rel for z in range(15)) for j in FUT]==[0,1,2,3]
    return {str(k):v for k,v in sorted(counts.items())}


def readout_bounds():
    # The two arms are allowed to translate Y14 within its archived clock window.
    # Restrict input Y14 to the central half of its interval, not the other clocks.
    e=mul((support.WINDOWS[0][0],support.WINDOWS[-1][1]),recip(support.DELTA))
    dur=sub(fix(4),e)
    h=mul(fix(BETA_PULSE),recip(mul(add(fix(1),e),dur)))
    assert h[1]/2<dur[0]*HALF_WIDTH/2
    lam=mul(fix(BETA_PULSE/95),support.DELTA)
    phasefile=json.loads((ROOT/'quellen/coherence.json').read_text())
    assert phasefile==coherence.run()
    rows={}
    for mass in (F(1,4),F(1),F(4)):
        contrast=min(F(phasefile['rows'][f'{mass};{rho}']['conditional_modulus_lower_exact']) for rho in ('1/8','1/4'))
        # C_14 = 1 + (19^-1) sum_i b_i(Y_i-Y_14)^2 . sum b=0 eliminates Y_14^2.
        # past moment sum b_i Y_i^2 = -21-4e+e^2 ; sum b_i Y_i=1+e.
        c=[]
        for win in support.WINDOWS:
            for tile in tiles(win,64):
                ee=mul(tile,recip(support.DELTA))
                # use the actual coefficient from the original four clock stamps
                y3=add(fix(-2),ee)
                mom=add(fix(-8*25+16*16-9*9),mul(y3,y3))
                y14=add(y3,mul(sub(fix(4),ee),(F(1,2)-HALF_WIDTH/2,F(1,2)+HALF_WIDTH/2)))
                C=add(fix(1),mul(fix(F(1,19)),sub(mom,mul(fix(2),mul(add(fix(1),ee),y14)))))
                c.append(mul(mul(fix(mass/10),mul(support.DELTA,sub(fix(4),ee))),C))
        a=magnitude(hull(c)) # slope magnitude of S in relative density jitter
        t=lam[1]*mass/2
        # For flat symmetric density jitter, conditional E[xi]=0, E[xi^2]=eps^2/3.
        # Bound |arg(1+z)| <= |z|/(1-|z|) for |z|<1.
        raw=(a*t+t*t/2)*DENSITY_WIDTH**2/(3*contrast)
        err=2*raw/(1-raw)
        arbitrary=t*DENSITY_WIDTH/contrast
        loose=2*arbitrary/(1-arbitrary)
        rows[str(mass)]={'contrast_lower':str(contrast),'abs_action_jitter_slope_max':str(a),
                'phase_bias_max_rad':str(err),'relative_phase_bias_max':str(err/(lam[0]*mass)),
                'relative_bias_without_jitter_symmetry':str(loose/(lam[0]*mass))}
    # phase measured relative to an independently determined vacuum, with per-phase error delta.
    budget=F(1,10**7)
    tests={}
    for m in (F(1),F(4)):
        def rel(m):
            return (F(rows[str(m)]['phase_bias_max_rad'])+2*budget)/(lam[0]*m)
        target,ref=rel(m),rel(F(1,4))
        band=((1-target)/(1+ref),(1+target)/(1-ref))
        assert F(98,100)<band[0]<=band[1]<F(102,100)
        tests[str(m)]={'ratio_to_marked_mass':saved(band)}
    return {'pulse_constant':str(BETA_PULSE),'lambda':saved(lam),'max_abs_shift_Y14_per_arm':str(h[1]/2),
            'guaranteed_remaining_half_window_Y':str(dur[0]*HALF_WIDTH/2),'individual':rows,
            'per_measured_phase_error_rad':str(budget),'calibrated_transfer':tests}
