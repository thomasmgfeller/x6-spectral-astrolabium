# CST-Staubball · Dichtespur v0.1

Sekundäranalyse der 27 offenen Staubhistorien aus [PR 218](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/218) auf den beiden Gittern des [CST Dynamic Bounce Gate v0.1](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/217). Alle für die Rechnung erforderlichen Dateien sind im Archiv enthalten. Der Bericht fasst die wissenschaftliche Interpretation zusammen.

## Wiederholen

Archiv in ein neues Verzeichnis entpacken. Python 3.10 oder neuer genügt, ohne Zusatzpakete. Aus dem entpackten Verzeichnis ausführen.

```sh
python3 run.py --out replay
```

Die Ausgabe meldet für den Endvolumenmesser und die zusätzliche Dichtespur jeweils HOLD. Die fünf Dateien in `replay/` entsprechen inhaltlich den gleichnamigen Referenzen in `results/`. Die beiden JSON-Dateien mit Intervallgrenzen speichern exakte Brüche. Die direkten Gleitkommawerte dienen der leichteren Auswertung. Bei anderen mathematischen Laufzeitbibliotheken können sich ihre letzten Dezimalstellen unterscheiden. Die Hashwerte der gelieferten Dateien lassen sich mit `sha256sum -c SHA256SUMS` prüfen.

## Festlegung vor dem Lauf

`protocol.json` und `PROTOCOL_SHA256` dokumentieren die vor der neuen Interferenzrechnung festgelegte Messregel. Die Präparation, Pfade, Signalabstände und bisherigen Ergebnisse waren aus der Entwicklungsserie bekannt. Der lokale Hash dient der Integritätskontrolle. Die Rechnung beansprucht weder eine rückwirkende Verblindung noch eine unabhängige Bestätigung.

Der Zeigerzustand hat eine gaußförmige Positionsverteilung mit Standardabweichung gleich dem Zeitabstand der ersten beiden Staubmarken geteilt durch das anfängliche Referenzvolumen. Sein Zentrum verschiebt sich um das entlang des Staubflusses integrierte Dichtesignal pro Masseneinheit. Bei der Normierung im Modell ist sigma = 2/5. Gemessen wird die durch den Zeiger modifizierte Interferenz ohne Auswahl einzelner Zeigerwerte. In beiden Versuchsarmen bleibt der ursprüngliche Endvolumenmesser erhalten. Das Modell vernachlässigt die Rückwirkung und setzt eine ideale Kopplung voraus.

## Ergebnisse

| Gitter und Modell | Interferenz vorher | Interferenz mit Dichtespur | Diagonalanteil Bounce mit Dichtespur |
|---|---:|---:|---:|
| Grob, dynamisch | 0,316112 | 0,062851 | 0,056319 |
| Fein, dynamisch | 0,209587 | 0,054013 | 0,028814 |
| Nullkontrolle auf beiden Gittern | 0,054054 | 0,033364 | 0,012685 |

Die Grenze von 1/21 wird mit Dichtespur in der Nullkontrolle unterschritten, im dynamischen Modell auf beiden Gittern überschritten. Deshalb bleibt die physikalische Interpretation dynamischer Diagonalanteile als Wahrscheinlichkeiten offen. Der untersuchte schriftlich definierte Bounce ist eine Abfolge von vier Mindeständerungen auf fünf Staubzeitflächen. N umfasst alle Pfade, die dieses konkrete Ereignis im gewählten Fenster ausschliessen.

## Inhalt und Gegenprüfungen

- `source/` enthält einen unveränderten Auszug des in `protocol.json` bezeichneten Ausgangsarchivs. Beim Erstellen wurde dessen SHA-256 geprüft. Die sechs Mitgliedsdateien wurden gegen seine interne Prüfliste verifiziert. `source/digests.json` sichert die lokalen Eingaben vor jeder Wiederholung.
- `run.py` prüft alle 27 zulässigen Pfade pro Gitter sowie die einzelnen Dichteintegrale anhand der Gitterdaten und reproduziert die vollständige frühere Gate-Ausgabe. Aus den Überlappungen der verschobenen Messzustände erzeugt es intervallbeschränkte Cholesky-Koordinaten pro Endkanal. Die ursprünglichen Amplitudenfehler und die Koordinatenfehler werden für jeden Pfad konservativ im euklidischen Normradius zusammengefasst.
- `gram_check.py` summiert die Historienpaare direkt mit Intervallarithmetik ohne Verwendung der Cholesky-Koordinaten. Die verwendeten Fehlergrenzen betreffen die Numerik des festgelegten Modells.
- `results/histories.csv` listet Pfade, Gate-Klasse, Endkanal, exaktes Dichtesignal und Überlappungsamplitude mit dem Bounce-Zustand auf.
- `results/pointer_input.json` und `pointer_result.json` enthalten Eingabe und Befund des unveränderten Gate-Codes. `results/certified_pairs.json` enthält die zweiseitigen direkten Grenzen für Interferenz und Diagonalanteil. `results/gram_audit.json` liefert lesbare Kontrollwerte für Zeiger aus, Zeiger an und ideal unterscheidbare Einzelpfade.
- `report.tex` ist der Quelltext des beiliegenden Berichts. Der numerische Lauf benötigt keine TeX-Installation.
