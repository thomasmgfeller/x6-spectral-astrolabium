"""Independent contraction of all amplitude pairs with interval error bounds."""
from collections import defaultdict
from fractions import Fraction as F
from math import isqrt


def plus(x, y):
    return x[0]+y[0], x[1]+y[1]


def minus(x, y):
    return x[0]-y[1], x[1]-y[0]


def abs_bounds(x):
    low, high = x
    return max(0, low, -high), max(abs(low), abs(high))


def direct_bounds(level, labels, mode, sigma, channel, energies, iv):
    prec, hull, prod, gaussian = iv
    result = {}
    for name in ('dynamic', 'null'):
        records = []
        for r in level['histories']:
            end = channel(r)
            amp = r[name]
            re, im = map(F, amp['a'][end])
            radius = F(amp['radius'])
            records.append((end, hull(re-radius,re+radius), hull(im-radius,im+radius)))
        zero = (0,0)
        norms = defaultdict(lambda: zero)
        cross_re, cross_im = zero, zero
        for i,(left, re, im) in enumerate(records):
            for j,(right, u, v) in enumerate(records):
                if left != right or (labels[i],labels[j]) == ('N','B'):
                    continue
                kernel = gaussian(energies[i]-energies[j],sigma) if mode=='on' else (prec,prec)
                real = prod(kernel,plus(prod(re,u),prod(im,v)))
                if labels[i] == labels[j]:
                    norms[labels[i]] = plus(norms[labels[i]],real)
                else:
                    cross_re = plus(cross_re,real)
                    cross_im = plus(cross_im,prod(kernel,minus(prod(re,v),prod(im,u))))
        x0,x1 = abs_bounds(cross_re)
        y0,y1 = abs_bounds(cross_im)
        a = isqrt(x0*x0+y0*y0)
        b = isqrt(x1*x1+y1*y1) + 1
        t0,t1 = plus(norms['B'],norms['N'])
        assert t0 > 0
        result[name] = dict(epsilon=[F(2*a,t1),F(2*b,t0)],
                            q_B=[F(norms['B'][0],t1), F(norms['B'][1],t0)])
    return result
