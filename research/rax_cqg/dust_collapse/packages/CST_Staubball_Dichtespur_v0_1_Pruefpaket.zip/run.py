"""Run the preregistered finite reanalysis (Python standard library only)."""
import argparse
import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from copy import deepcopy
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'source'
sys.path.insert(0, str(SRC / 'gate_v01'))
import gate
from gram_check import direct_bounds

PREC = 1 << 320
ONE = (PREC, PREC)
ZERO = (0, 0)


def read(path):
    return json.loads(path.read_text())


def write(path, doc):
    path.write_text(json.dumps(doc, indent=2, default=str) + '\n')


def ceiling(n, d):
    return -((-n) // d)


# Interval endpoints are integers in units of 2^-320. Every operation encloses.
def hull(lo, hi):
    lo, hi = F(lo)*PREC, F(hi)*PREC
    return lo.numerator // lo.denominator, ceiling(hi.numerator, hi.denominator)


def prod(x, y):
    products = [a*b for a in x for b in y]
    return min(products)//PREC, ceiling(max(products), PREC)


def sqrt_iv(x):
    if x[0] <= 0:
        raise ValueError('Cholesky pivot not certified positive')
    lo, hi = math.isqrt(x[0]*PREC), math.isqrt(x[1]*PREC)
    return lo, hi + int(hi*hi != x[1]*PREC)


def div_pos(x, y):
    assert y[0] > 0
    q = [F(a, b) for a in x for b in y]
    return hull(min(q), max(q))


def gaussian_iv(delta, sigma):
    if delta == 0:
        return ONE
    x = -delta**2/(8*sigma**2)
    with localcontext() as ctx:
        ctx.prec = 150
        t = Decimal(x.numerator) / Decimal(x.denominator)
        value = F(t.exp())  # Decimal.exp is correctly rounded (half even).
    # exp is 1-Lipschitz on negative inputs and its result is at most one.
    error = abs(x-F(t)) + F(1, 10**149)
    return hull(max(F(0), value-error), min(F(1), value+error))


def gaussian_basis(centres, sigma):
    """Enclose exact Cholesky rows of the Gaussian Gram matrix of distinct centres."""
    rows = []
    for i, centre in enumerate(centres):
        row = []
        for j in range(i+1):
            low, high = gaussian_iv(centre-centres[j], sigma)
            for k in range(j):
                a, b = prod(row[k], (row if i == j else rows[j])[k])
                low, high = low-b, high-a
            entry = sqrt_iv((low, high)) if i == j else div_pos((low, high), rows[j][j])
            row.append(entry)
        rows.append(row)
    return dict(zip(centres, rows))


def widths(row):
    return tuple(map(int, row['id'].split('-')))


def exposure(w):
    return sum(F(25*(i+j), i*i*j*j) for i, j in zip(w, w[1:]))


def check_regulators(data):
    expected = {(5, 4, 4+d, 4+d+e, 4+d+e+f) for d,e,f in product((-1,0,1), repeat=3)}
    with (SRC/'intervals.csv').open() as stream:
        raw = list(csv.DictReader(stream))
    by_id = {(r['path'], int(r['level'])):r for r in raw}
    assert len(by_id) == len(raw) == 54
    for level_index, level in enumerate(data['levels']):
        assert len(level['histories']) == 27
        assert {widths(row) for row in level['histories']} == expected
        s = F(level['ell'])
        for row in level['histories']:
            w = widths(row)
            n = list(map(int, by_id[row['id'],level_index]['side_counts'].split(',')))
            scale = [s*i for i in n]
            assert scale[::level_index+1] == [F(i,5) for i in w]
            assert row['volumes'] == [[str(F(i,5)**3)]*2 for i in w]
            # Independent primitive, evaluated on the actual regulator ticks.
            dt = 2*s
            total = sum(dt/a**3 if a == b else
                        dt*(1/a**2-1/b**2)/(2*(b-a)) for a,b in zip(scale,scale[1:]))
            assert total == exposure(w)


def channel(row):
    slots = [k for k,v in enumerate(row['null']['a']) if any(map(F,v))]
    assert len(slots) == 1 and slots[0] == int(4*F(row['volumes'][-1][0]))
    return slots[0]


def make_input(original, sigma):
    first = original['levels'][0]['histories']
    grouped = defaultdict(set)
    for row in first:
        grouped[channel(row)].add(exposure(widths(row)))
    pointers = {}
    dimension = 0
    for end, energies in sorted(grouped.items()):
        basis = gaussian_basis(sorted(energies), sigma)
        for energy, coords in basis.items():
            # Exact dyadic midpoints, sum of halfwidths bounds the Euclidean error.
            mids = [F(lo+hi,2*PREC) for lo,hi in coords]
            err = sum(F(hi-lo,2*PREC) for lo,hi in coords)
            assert err < F(1, 1 << 110)
            pointers[end,energy] = (dimension, mids, err)
        dimension += len(basis)
    doc = deepcopy(original)
    design = doc['design']
    design['records'] = dict(basis='orthonormal', dimension=dimension,
        instrument='archived end bin tensor Gaussian density pointer with sigma=2/5, '
                   'analytic Gram factor in the occupied subspace; common basis on both levels')
    design['joint_error_budget'] += '; rigorously enclosed Gaussian Gram Cholesky factors'
    doc['design_sha256'] = gate.digest(design)
    for level in doc['levels']:
        level['design_sha256'] = doc['design_sha256']
        for row in level['histories']:
            end = channel(row)
            start, mids, err = pointers[end, exposure(widths(row))]
            for name in ('dynamic','null'):
                old = row[name]
                assert all(not any(map(F,v)) for i,v in enumerate(old['a']) if i != end)
                re, im = map(F,old['a'][end])
                values = [[0,0] for _ in range(dimension)]
                for k, mid in enumerate(mids, start):
                    values[k] = [str(re*mid), str(im*mid)]
                # Exact normalized pointer multiplies old amplitude error isometrically.
                radius = F(old['radius']) + (abs(re)+abs(im))*err
                row[name] = dict(a=values,radius=str(radius))
    return doc


def baseline_equal(actual, archived):
    assert json.loads(json.dumps(actual, default=str)) == archived


def crosscheck(level, metrics, sigma, mode):
    labels = [gate.classify(r['volumes'],F(1,20),F(1,20)) for r in level['histories']]
    rows = level['histories']
    assert Counter(labels) == {'B':1,'N':26}
    summary = {}
    for name in ('dynamic', 'null'):
        amplitudes = [complex(*map(F, r[name]['a'][channel(r)])) for r in rows]
        blocks = defaultdict(complex)
        for i, r in enumerate(rows):
            for j, other in enumerate(rows):
                if channel(r) != channel(other):
                    continue
                overlap = 1.
                if mode == 'on':
                    d = float(exposure(widths(r))-exposure(widths(other)))
                    overlap = math.exp(-(d/float(sigma))**2/8)
                elif mode == 'orthogonal':
                    overlap = float(i == j)
                blocks[labels[i],labels[j]] += amplitudes[i].conjugate()*amplitudes[j]*overlap
        d_b = blocks['B','B'].real
        d_n = blocks['N','N'].real
        trace = d_b + d_n
        q = d_b/trace
        eps = 2*abs(blocks['B','N'])/trace
        if mode == 'orthogonal':
            assert abs(q-1/27) < 1e-13 and eps == 0
        else:
            val = metrics[name]
            lo,hi = map(float,val['q']['B'])
            assert lo-1e-13 <= q <= hi+1e-13
            assert abs(float(val['epsilon_upper']) - eps) < 2e-11
            assert hi < 0.5
        summary[name] = dict(epsilon_direct=eps, q_B_direct=q,
            abs_D_BN=abs(blocks['B','N']), D_BB=d_b, D_NN=d_n)
    return summary


def main(out):
    protocol = read(ROOT/'protocol.json')
    assert hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest() == (ROOT/'PROTOCOL_SHA256').read_text().split()[0]
    for name, digest in read(SRC/'digests.json').items():
        assert hashlib.sha256((SRC/name).read_bytes()).hexdigest() == digest
    original = read(SRC/'primary_input.json')
    check_regulators(original)
    sigma = F(protocol['sigma'])
    assert sigma == F(original['design']['times'][1])-F(original['design']['times'][0])
    off = gate.evaluate(original)
    baseline_equal(off, read(SRC/'primary_result.json'))
    doc = make_input(original,sigma)
    on = gate.evaluate(doc)
    checks = {}
    out.mkdir(parents=True,exist_ok=True)
    for mode, result in [('off',off),('on',on),('orthogonal',None)]:
        checks[mode] = {}
        for i, level in enumerate(original['levels']):
            checks[mode][level['ell']] = crosscheck(level,result['levels'][i] if result else None,sigma,mode)
    certified = {}
    for mode, result in [('off',off),('on',on)]:
        certified[mode] = {}
        for level, decision in zip(original['levels'],result['levels']):
            rows = level['histories']
            labels = [gate.classify(r['volumes'],F(1,20),F(1,20)) for r in rows]
            energies = [exposure(widths(r)) for r in rows]
            direct = direct_bounds(level,labels,mode,sigma,channel,energies,
                                   (PREC,hull,prod,gaussian_iv))
            for name, bounds in direct.items():
                epsilon = bounds['epsilon']
                q_b = bounds['q_B']
                assert epsilon[0] <= decision[name]['epsilon_upper']
                q_lo, q_hi = decision[name]['q']['B']
                assert q_b[0] <= q_hi and q_lo <= q_b[1]
                for low, high in (epsilon,q_b):
                    assert 0 <= high-low < F(1,10**11)
            certified[mode][level['ell']] = direct
    write(out/'certified_pairs.json',certified)
    rows = original['levels'][0]['histories']
    b = next(r for r in rows if gate.classify(r['volumes'],F(1,20),F(1,20))=='B')
    unique = [r['id'] for r in rows if channel(r)==10]
    assert unique == ['5-4-5-6-7'] and channel(b) != 10
    with (out/'histories.csv').open('w', newline='') as stream:
        w = csv.writer(stream,lineterminator='\n')
        w.writerow(['path','class','end_bin','E_exact','overlap_with_B'])
        for r in rows:
            en = exposure(widths(r))
            ov = math.exp(-float((en-exposure(widths(b)))**2/(8*sigma**2))) if channel(r)==channel(b) else 0
            w.writerow([r['id'],gate.classify(r['volumes'],F(1,20),F(1,20)),channel(r),str(en),format(ov,'.14g')])
    write(out/'pointer_result.json',on)
    write(out/'gram_audit.json',checks)
    write(out/'pointer_input.json',doc)
    print('off:',off['numeric_status'],'on:',on['numeric_status'],'physical:',on['physical_status'])
    for mode in ['off','on']:
        for ell, row in checks[mode].items():
            print(mode,ell,[(k,round(v['epsilon_direct'],8),round(v['q_B_direct'],8)) for k,v in row.items()])


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Run without -O to enable verification')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    main(parser.parse_args().out)
