"""CST Dynamic Bounce Gate v0.1. Stand-alone, conservative rational enclosures."""
import hashlib
import json
import sys
from fractions import Fraction as F
from math import isqrt
from pathlib import Path

ROOT=Path(__file__).resolve().parent
VERSION='46de9f779d345aa740758b4cac46e679624aa077e01aba331796bd221c606984'
CLASSES=('B','N','U')


def require(ok,reason):
    if not ok:
        raise ValueError(reason)


def rational(x):
    require(type(x) in (str,int),'use integer or quoted rational')
    return F(x)


def sqrt_bounds(x):
    scale=1<<80
    lo=F(isqrt((x.numerator*scale**2)//x.denominator),scale)
    return lo, lo if lo*lo==x else lo+F(1,scale)


def digest(obj):
    data=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False)
    return hashlib.sha256(data.encode()).hexdigest()


def classify(volumes,floor,step):
    if volumes is None: return 'U'
    require(isinstance(volumes,list) and len(volumes)==5,'five simultaneous volume readouts required')
    if any(x is None for x in volumes): return 'U'
    box=[]
    for lo,hi in volumes:
        lo,hi=rational(lo),rational(hi)
        require(0<=lo<=hi,'invalid physical volume interval')
        box.append((lo,hi))
    criteria=[(box[2][0]-floor,box[2][1]-floor)]
    for high,low in ((0,1),(1,2),(3,2),(4,3)):
        criteria.append((box[high][0]-box[low][1]-step,box[high][1]-box[low][0]-step))
    if all(lo>=0 for lo,hi in criteria): return 'B'
    if any(hi<0 for lo,hi in criteria): return 'N'
    return 'U'


def aggregate(rows,labels,channel,dim,complete=False):
    classes=('B','N') if complete else CLASSES
    vectors={c:[[F(0),F(0)] for _ in range(dim)] for c in classes}
    error={c:F(0) for c in classes}
    for row,c in zip(rows,labels):
        record=row[channel]
        require(len(record['a'])==dim,'end-record dimension differs')
        rad=rational(record['radius'])
        require(rad>=0,'negative vector error')
        coords=[(rational(re),rational(im)) for re,im in record['a']]
        if complete and c=='U':
            amount=rad+sqrt_bounds(sum(re**2+im**2 for re,im in coords))[1]
            for target in classes: error[target]+=amount
            continue
        error[c]+=rad
        for v,(re,im) in zip(vectors[c],coords):
            v[0]+=re
            v[1]+=im
    squares={c:sum(re**2+im**2 for re,im in vectors[c]) for c in classes}
    norms={c:sqrt_bounds(squares[c]) for c in classes}
    diagonal={c:(max(0,norms[c][0]-error[c])**2,(norms[c][1]+error[c])**2) for c in classes}
    s_lo=sum(b[0] for b in diagonal.values())
    s_hi=sum(b[1] for b in diagonal.values())
    if s_lo<=0: return None
    q={c:(F(diagonal[c][0])/s_hi,min(F(1),F(diagonal[c][1])/s_lo)) for c in classes}
    interference=F(0)
    for i,c in enumerate(classes):
        for d in classes[:i]:
            re=sum(x*u+y*v for (x,y),(u,v) in zip(vectors[c],vectors[d]))
            im=sum(x*v-y*u for (x,y),(u,v) in zip(vectors[c],vectors[d]))
            cross=sqrt_bounds(re**2+im**2)[1]
            interference+=cross+norms[c][1]*error[d]+norms[d][1]*error[c]+error[c]*error[d]
    return dict(q=q,epsilon_upper=2*interference/s_lo,trace=(s_lo,s_hi))


def evaluate(data):
    text=(ROOT/'contract.json').read_bytes()
    require(hashlib.sha256(text).hexdigest()==VERSION,'gate contract hash mismatch')
    rule=json.loads(text);cut={k:F(v) for k,v in rule['arithmetic'].items()}
    floor,step=[F(rule['ratios_to_early_reference_volume'][k]) for k in ('minimum_resolved_volume','minimum_change_per_step')]
    require(data['scope'] in ('synthetic','candidate'),'unknown evidence scope')
    design=data['design']
    require(data['contract_sha256']==VERSION and data['design_sha256']==digest(design),'design mismatch')
    for key in ('times','physical_time_unit','region','clock','early_input','early_volume_scale','observable','dynamics','measure','null','records','support_policy','joint_error_budget'):
        require(bool(design.get(key)),'missing design field '+key)
    times=[rational(t) for t in design['times']]
    require(len(times)==5 and all(a<b for a,b in zip(times,times[1:])),'ordered times required')
    levels=data['levels']
    require(len(levels)==2,'two matched resolutions required')
    require(rational(levels[0]['ell'])>rational(levels[1]['ell'])>0,'lengths must decrease')
    dim=design['records']['dimension']
    require(type(dim) is int and dim>0 and design['records']['basis']=='orthonormal','orthonormal end-record basis required')
    reasons=[]; checks=[]
    for level in levels:
        require(level['design_sha256']==data['design_sha256'],'level comparison mismatch')
        rows=level['histories']
        ids=[r['id'] for r in rows]
        require(bool(ids) and all(type(x) is str and x for x in ids) and len(ids)==len(set(ids)),'empty or duplicate history list')
        require(digest(sorted(ids))==level['inventory_sha256'],'provided inventory mismatch')
        labels=[classify(r['volumes'],floor,step) for r in rows]
        numbers={c:labels.count(c) for c in CLASSES}
        if not numbers['B'] or not numbers['N']: reasons.append('both alternatives must be exhibited')
        stats={name:aggregate(rows,labels,name,dim) for name in ('dynamic','null')}
        for name,s in stats.items():
            if s is None: reasons.append(name+' norm unresolved')
            elif s['epsilon_upper']>cut['maximum_interference']: reasons.append(name+' interference unresolved')
            elif s['q']['U'][1]>cut['maximum_unresolved_weight']: reasons.append(name+' unresolved weight too large')
        for name in ('dynamic','null'):
            safe=aggregate(rows,labels,name,dim,complete=True)
            if safe is None or safe['epsilon_upper']>cut['maximum_interference']:
                reasons.append(name+' possible assignments of unresolved histories not controlled')
            # Simultaneously cover the recorded partition and any binary completion.
            if safe is not None and stats[name] is not None:
                for c in ('B','N'):
                    lo,hi=stats[name]['q'][c]
                    sl,sh=safe['q'][c]
                    stats[name]['q'][c]=(min(lo,sl),max(hi,sh))
            stats[name+'_completion']=safe
        checks.append(dict(ell=level['ell'],counts=numbers,**stats))
    state='HOLD'
    if not reasons:
        d=[x['dynamic']['q'] for x in checks]
        n=[x['null']['q'] for x in checks]
        def stable(c):
            return max(d[0][c][1]-d[1][c][0],d[1][c][1]-d[0][c][0])<=cut['maximum_two_level_weight_drift']
        if all(q['B'][0]>=cut['minimum_branch_weight'] for q in d):
            if not stable('B'): reasons.append('bounce weight changes with resolution')
            if any(q['B'][0]-p['B'][1]<cut['minimum_dynamic_excess_over_kinematic_control'] for q,p in zip(d,n)):
                reasons.append('dynamic excess over null unestablished')
            if not reasons: state='PASS'
        elif all(q['N'][0]>=cut['minimum_branch_weight'] for q in d) and stable('N'):
            state='FAIL'
            reasons.append('resolved non-bounce dominates at both levels in this window')
        else: reasons.append('no stable dominant outcome')
    return dict(scope=data['scope'],numeric_status=state,physical_status='NOT_APPLICABLE' if data['scope']=='synthetic' else 'HOLD_PENDING_EVIDENCE_REVIEW',
                reasons=sorted(set(reasons)),levels=checks)


def run(data):
    try:
        return evaluate(data)
    except (ValueError,TypeError,KeyError,ZeroDivisionError,IndexError,AttributeError) as exc:
        return dict(numeric_status='INVALID',physical_status='NO_DECISION',reason=str(exc))


if __name__=='__main__':
    result=run(json.loads(Path(sys.argv[1]).read_text()))
    print(json.dumps(result,default=str,indent=2))
    if result['numeric_status']=='INVALID':sys.exit(2)
