"""Check all C coefficients independently of the primary gravity and routing routines."""
from collections import Counter,defaultdict
import csv,itertools,json,math,tempfile
from fractions import Fraction as F
from pathlib import Path
from run import HERE,PREPS,orbits,graph,reference,require

def twin_deltas(edges):
    from enumerate_records import lift
    g,idx=lift(edges)
    future=[set() for _ in g]; past=[set() for _ in g]
    for u in reversed(range(len(g))):
        for v in g[u]:future[u].add(v);future[u].update(future[v])
    for u,successors in enumerate(future):
        for v in successors:past[v].add(u)
    interval={(u,v):len(s & past[v]) for u,s in enumerate(future) for v in s}
    weight=lambda n:(-1,9,-16,8)[n] if n<4 else 0
    base=len(g)+sum(map(weight,interval.values()))
    def action_after_duplicate(edge):
        m=idx[edge]
        return base+1+sum(weight(interval[a,m]) for a in past[m])+sum(weight(interval[m,b]) for b in future[m])+sum(
            weight(interval[a,b]+1)-weight(interval[a,b]) for a in past[m] for b in future[m])
    return action_after_duplicate

def trace(edges,defect):
    from enumerate_records import lift
    g,idx=lift(edges,defect)
    # Read two-cover moves directly on the refined graph and transport integer currents forward.
    L=24
    contracts={}
    for a in range(len(edges)-1):
        i=idx['old',a]
        dest=defaultdict(list)
        for port in g[i]:
            for j in g[port]:dest[j].append(port)
        moves=[]
        for j,ports in dest.items():
            divisor=len(dest)*len(ports)
            require(L%divisor==0,'integer transfer unit')
            moves.extend((j,p,int(len(ports)==2),L//divisor) for p in ports)
        contracts[i]=moves
    terms=[]
    for source in range(3):
        state={(idx['old',source],0):1}
        for stage in range(4):
            nxt=Counter()
            for (i,h),val in state.items():
                for j,p,dh,w in contracts[i]:
                    nxt[p if stage==3 else j,h+dh]+=val*w
            state=nxt
        require(sum(state.values())==L**4,'source normalization')
        terms.append(state)
    out=Counter()
    for ((a,h1),v1),((b,h2),v2),((c,h3),v3) in itertools.product(*(c.items() for c in terms)):
        s=(a==b)+2*(a==c)+4*(b==c)
        out[s,h1+h2+h3]+=v1*v2*v3
    return out,L**12

def orbit_size(k,ell,key):
    a,b,cols=key
    def transform(mask,p):return sum(1<<p[j] for j in range(k) if mask&(1<<j))
    keep=0
    for p in itertools.permutations(range(k)):
        if transform(a,p)==a and transform(b,p)==b and sorted(transform(c,p) for c in cols)==list(cols):
            keep+=1
    denom=keep*math.prod(math.factorial(n) for n in Counter(cols).values())
    quotient,rem=divmod(math.factorial(k)*math.factorial(ell),denom)
    require(rem==0,'stabilizer divisor')
    return quotient

def main():
    expected={(r['preparation'],int(r['k']),int(r['signature']),int(r['h']),int(r['residue'])):F(r['weight'])
              for r in csv.DictReader((HERE/'coefficients.csv').open()) if r['family']=='C'}
    check=Counter(); direct=0; reps=0
    for k in (1,2,3):
        for key,size in orbits(k,4).items():
            require(orbit_size(k,4,key)==size,'automorphism weights');reps+=1
            for pre,early in PREPS.items():
                e=graph(early,k,4,key);q=twin_deltas(e)
                defects=[(i,j) for i in range(3,len(e)) for j in e[i]]
                for edge in defects:
                    Q=q(edge);t,den=trace(e,edge)
                    w=F(size,math.factorial(k)*math.factorial(4)*len(defects)*den)
                    for (s,h),n in t.items():check[pre,k,s,h,Q%5]+=n*w
                    direct+=1
    require(check==expected,'independent coefficient table')
    r=json.loads((HERE/'results.json').read_text())['C']['original']
    qlo,qhi=map(F,r['primary']['q23']);elo,ehi=map(F,r['primary']['epsilon'])
    # Enclose r and overlap using exact rational squares; q(1-q) decreases above 1/2.
    require(qlo>F(1,2),'expected numerically dominant branch')
    require(qlo/(1-qlo)>137**2 and qhi/(1-qhi)<138**2,'norm ratio')
    require(elo**2>F(964,1000)**2*4*qlo*(1-qlo) and ehi**2<F(966,1000)**2*4*qhi*(1-qhi),'overlap')
    exact=F(7,2)*(3**4-2)+F(25,6)*(7**4-3*3**4+3)
    require(F(r['count_only']['epsilon'][0])==2*exact/(1+exact**2),'count control')
    return dict(orbit_sizes_checked=reps,marked_representatives_checked_both_preparations=direct,
                rational_C_coefficients_checked=len(expected),new_family_distinct=True,
                norm_ratio_open_interval=[137,138],normalized_overlap_open_interval=['0.964','0.966'],
                count_only_amplitude_ratio=str(exact),all_checks_pass=True)

if __name__=='__main__':
    require(__debug__,'run without -O')
    with tempfile.TemporaryDirectory() as d:
        reference(Path(d))
        print(json.dumps(main(),indent=2))
