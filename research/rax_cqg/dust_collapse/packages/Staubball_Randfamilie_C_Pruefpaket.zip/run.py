"""Full finite boundary-family test using exact rational symmetry multiplicities."""
from collections import Counter, defaultdict
import csv
from fractions import Fraction as F
from functools import reduce
from operator import or_
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
import tempfile
import zipfile

HERE=Path(__file__).resolve().parent
PREPS={'original':(1,3,2),'changed':(1,3,1)}
PLAN_SHA='d4e29e9ba585e147042f27fce5632603320c072f0516823a44a15341b1005f8f'
ARCHIVE_SHA='82230266ff128334660ea03c49be766770358e98828c2e5f38c3fa451b5a0190'

def require(ok, message):
    if not ok: raise ValueError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def reference(folder):
    require(sha(HERE/'design.json')==PLAN_SHA, 'test plan changed')
    require(sha(HERE/'reference_PR202.zip')==ARCHIVE_SHA,'reference archive changed')
    with zipfile.ZipFile(HERE/'reference_PR202.zip') as archive:archive.extractall(folder)
    sys.path.insert(0,str(folder))

def count_matrices(m,n):
    # Columns are nonempty; inclusion-exclusion enforces nonempty rows.
    return sum((-1)**i*math.comb(m,i)*((1<<(m-i))-1)**n for i in range(m+1))

def orbits(k,ell):
    full=(1<<k)-1
    perms=[[sum(1<<p[i] for i in range(k) if mask>>i&1) for mask in range(full+1)]
           for p in itertools.permutations(range(k))]
    result=Counter()
    for cols in itertools.combinations_with_replacement(range(1,full+1),ell):
        if reduce(or_,cols,0)!=full:continue
        mult=math.factorial(ell)//math.prod(math.factorial(n) for n in Counter(cols).values())
        for a,b in itertools.product(range(1,full+1),repeat=2):
            if a|b!=full:continue
            key=min((p[a],p[b],tuple(sorted(p[c] for c in cols))) for p in perms)
            result[key]+=mult
    require(sum(result.values())==count_matrices(2,k)*count_matrices(k,ell),'geometry count')
    return result

def graph(prep,k,ell,key):
    a,b,cols=key
    source=[[3+i for i in range(2) if mask>>i&1] for mask in prep]
    beginning=[[5+i for i in range(k) if mask>>i&1] for mask in (a,b)]
    middle=[[5+k+j for j,c in enumerate(cols) if c>>i&1] for i in range(k)]
    return source+beginning+middle+[[5+k+ell] for _ in range(ell)]+[[]]

def action(g):
    n=len(g);future=[0]*n;past=[0]*n
    for a in reversed(range(n)):
        for b in g[a]:future[a]|=(1<<b)|future[b]
    for a in range(n):
        for b in g[a]:past[b]|=(1<<a)|past[a]
    q=n;weights=(-1,9,-16,8)
    for mask in future:
        bits=mask
        while bits:
            bit=bits&-bits
            j=bit.bit_length()-1
            h=(mask & past[j]).bit_count()
            if h<4:q+=weights[h]
            bits-=bit
    return q

def direct_check(edges,g,labels,expected,q):
    from verify import explicit
    from defect import q_integer
    require(q_integer(g)[0]==q,'action mismatch')
    raw=explicit(g,[labels['old',i] for i in range(3)],labels['old',len(edges)-1])
    collapsed=Counter()
    for (sig,mask),w in raw.items():collapsed[sig,mask.bit_count()]+=w
    require(collapsed==expected,'direct route mismatch')

def enumerate_one(k,ell,preparation):
    from enumerate_records import lift,read_routes,history_poly
    counts=Counter(); nh=0; samples=0
    reps=orbits(k,ell)
    for idx,(key,mult) in enumerate(sorted(reps.items())):
        edges=graph(PREPS[preparation],k,ell,key);sink=len(edges)-1
        routes=[read_routes(edges,s) for s in range(3)]
        defects=[(u,v) for u in range(3,sink) for v in edges[u]]
        nh+=mult*len(defects)
        prior=F(mult,len(defects)*math.factorial(k)*math.factorial(ell))
        for di,d in enumerate(defects):
            g,labels=lift(edges,d);q=action(g)
            terms=history_poly(routes,d,sink)
            if idx in {0,len(reps)//2,len(reps)-1} and di in {0,len(defects)//2,len(defects)-1}:
                direct_check(edges,g,labels,terms,q);samples+=1
            for (sig,h),p in terms.items():counts[k,sig,h,q%5]+=prior*p
    # Independent labelled inventory of marks via incidence counts, no orbit quotient.
    from enumerate_records import covers
    aa=list(covers(2,k));bb=list(covers(k,ell))
    ea=sum(v.bit_count() for rows in aa for v in rows)
    eb=sum(v.bit_count() for rows in bb for v in rows)
    independent_histories=ea*len(bb)+eb*len(aa)+ell*len(aa)*len(bb)
    require(independent_histories==nh,'history total')
    mass=F(len(aa)*len(bb),math.factorial(k)*math.factorial(ell))
    require(sum(counts.values())==mass,'route normalization')
    return counts,dict(k=k,geometries=sum(reps.values()),histories=nh,representatives=len(reps),
                       direct_checks=samples,amplitude_measure=str(mass))

def archive_coeff(ref,prep,family):
    p=ref/('coefficients.csv' if prep=='original' else 'changed_coefficients.csv')
    return {tuple(int(r[x]) for x in ['k','sig','h','residue']):F(r['w']) for r in csv.DictReader(p.open())
            if r['ensemble']==family}

def scores(coeff,mode,equalize=False):
    from bounds import S, bound,plus,scale,times,lower_mod,upper_mod,add
    from binary import inner,phase_interval
    from certify_records import fifth_roots
    one=(bound(1),bound(0));zero=(bound(0),bound(0))
    za=phase_interval();zp=[one]
    for _ in range(3):zp.append(times(zp[-1],za))
    roots=fifth_roots()
    mass={k:sum(c for (j,s,h,r),c in coeff.items() if j==k) for k in (1,2,3)}
    xs=defaultdict(lambda:zero)
    for (k,s,h,r),c in coeff.items():
        phase=one if mode in ('no_phases','count_only') else zp[h]
        gravity=roots[r] if mode=='primary' else one
        w=c/mass[k] if equalize else c
        cell=(k,0 if mode=='count_only' else s)
        xs[cell]=plus(xs[cell],scale(times(phase,gravity),bound(w)))
    f=[xs[1,s] for s in (0,1,2,4,7)]
    t=[plus(xs[2,s],xs[3,s]) for s in (0,1,2,4,7)]
    left=inner(f,f)[0];right=inner(t,t)[0];cross=inner(f,t)
    lo,hi=add(left,right);require(lo>0,'branch norm')
    q=(F(right[0],hi),F(right[1],lo))
    eps=(2*lower_mod(cross)/F(hi,S),2*upper_mod(cross)/F(lo,S))
    passes=q[0]>=F(4,5) and eps[1]<=F(1,21)
    fails=q[1]<F(4,5) or eps[0]>F(1,21)
    if mode=='count_only':
        a,b=(F(1),F(2)) if equalize else (mass[1],mass[2]+mass[3])
        qe=b*b/(a*a+b*b);ee=2*a*b/(a*a+b*b)
        require(q[0]<=qe<=q[1] and eps[0]<=ee<=eps[1],'exact count-only control')
        q=(qe,qe);eps=(ee,ee)
        passes=qe>=F(4,5) and ee<=F(1,21);fails=not passes
    return dict(q23=[str(v) for v in q],epsilon=[str(v) for v in eps],
                q23_mid=float(sum(q)/2),epsilon_mid=float(sum(eps)/2),
                status='passes' if passes else 'fails' if fails else 'unresolved')

def run(ref):
    ans={};inv={};rows=[]
    for ell in (2,4):
        family={2:'B',4:'C'}[ell]
        ans[family]={};inv[family]={}
        for prep in PREPS:
            total=Counter();audit=[]
            for k in (1,2,3):
                c,item=enumerate_one(k,ell,prep);total.update(c);audit.append(item)
            if ell==2:require(total==archive_coeff(ref,prep,'fixed'),'archived coefficients not reproduced')
            for (k,s,h,r),c in sorted(total.items()):
                rows.append(dict(family=family,preparation=prep,k=k,signature=s,h=h,residue=r,weight=str(c)))
            inv[family][prep]=audit
            ans[family][prep]={m:scores(total,m) for m in ('primary','gravity_off','no_phases','count_only')}
            ans[family][prep]['equal_measure']=scores(total,'primary',True)
    ans['A']={}
    for prep in PREPS:
        total=archive_coeff(ref,prep,'published')
        ans['A'][prep]={m:scores(total,m) for m in ('primary','gravity_off','no_phases','count_only')}
        ans['A'][prep]['equal_measure']=scores(total,'primary',True)
    for f,tag in [('A','published'),('B','fixed')]:
        for prep in PREPS:
            path=ref/('binary.csv' if prep=='original' else 'changed_binary.csv')
            old=next(row for row in csv.DictReader(path.open()) if row['ensemble']==tag and row['record']=='arrivals'
                     and row['singleton']=='1')
            sc=ans[f][prep]['primary'];ep=list(map(F,sc['epsilon']));qp=list(map(F,sc['q23']))
            require(max(ep[0],F(old['epsilon_min']))<=min(ep[1],F(old['epsilon_max'])),'old interference')
            require(max(qp[0],1-F(old['q_single_max']))<=min(qp[1],1-F(old['q_single_min'])),'old weight')
    with (HERE/'coefficients.csv').open('w',newline='') as dst:
        w=csv.DictWriter(dst,fieldnames=rows[0],lineterminator='\n');w.writeheader();w.writerows(rows)
    for path,data in [('inventory.json',inv),('results.json',ans)]:
        (HERE/path).write_text(json.dumps(data,indent=2)+'\n')
    for f in 'ABC':
        print(f,[(p,round(ans[f][p]['primary']['q23_mid'],8),round(ans[f][p]['primary']['epsilon_mid'],8),
                 ans[f][p]['primary']['status']) for p in PREPS],flush=True)

if __name__=='__main__':
    require(__debug__,'Assertions in the reference modules require normal Python mode.')
    with tempfile.TemporaryDirectory() as folder:
        ref=Path(folder);reference(ref);run(ref)
