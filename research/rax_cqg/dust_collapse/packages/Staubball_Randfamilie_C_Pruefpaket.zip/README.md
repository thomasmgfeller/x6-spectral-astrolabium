# Neue Randfamilie C im endlichen Staubmodell

Geprüft wurde die einzelne vorher benannte Alternative k in {2,3} gegen k=1. C hat eine feste vorletzte Breite von vier. Die früheren Familien A und B verwendeten nur Breiten von eins bis drei. Parameter und Auslesemodell folgen dem eigenständigen Endzustandszweig in PR 202. Buchstaben für Randfamilien bezeichnen hier keine Zeitfenster der Massestrom-Piloten.

## Reproduktion

Im entpackten Verzeichnis mit Python 3.12 und NumPy ausführen. NumPy wird von den unveränderten Prüfroutinen des Referenzarchivs importiert. Die primäre Summe und ihre Grenzen verwenden Ganzzahlen und rationale Arithmetik.

```sh
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 python3 run.py
OPENBLAS_NUM_THREADS=1 python3 audit.py > neue_pruefung.json
cmp audit.json neue_pruefung.json
sha256sum -c SHA256SUMS
```

Getestet mit Python 3.12.14 und NumPy 2.3.5. Die Skripte führen nur endliche lokale Rechnungen aus. Der im Code festgelegte Hash des lokalen Plans dient der Reproduktion; er ist kein extern beglaubigter Zeitstempel. Dieser Modelltest erhebt keine Beobachtungsdaten.

- `design.json` und `DESIGN_SHA256` legen Familie, frühe Daten, Hauptprognose, Gegenproben und Grenzen vor Berechnung der C-Ergebnisse fest.
- `reference_PR202.zip` ist das bytegleiche [publizierte Archiv](https://github.com/thomasmgfeller/x6-spectral-astrolabium/blob/58de0da37790231a96623fa93a0590271ef38d80/research/rax_cqg/dust_collapse/packages/Kausalordnung_Endzustaende_Reproduktionspaket.zip). Der Hauptlauf prüft seinen SHA-256, die früheren rationalen Koeffizienten in B und die Intervallentscheidungen für A und B.
- `coefficients.csv` enthält die rationalen Amplitudenkoeffizienten je Präparation, Familie B oder C, Schichtbreite, Ankunftssignatur, Wegpotenz und Gravitationsrestklasse. `inventory.json` enthält die Geometrie- und Historienzahlen samt repräsentativer direkten Prüfungen.
- `results.json` nennt für alle Bedingungen exakte rationale Endpunkte der Einschliessungen für Zweiggewicht und Interferenz. Die ergänzenden Mittelpunkte sind Anzeigegrössen. `gravity_off` und `no_phases` behalten den idealen Ankunftsspeicher, `count_only` verwendet stummen Speicher und beide Phasen null. `equal_measure` verwendet volles Phasenmodell und teilt jeden Klassenvektor durch das positive Gesamtmass seiner Klasse.
- `audit.py` überprüft alle 840 Orbitgrössen durch Stabilisatorzählung. Ausgehend vom einfach unterteilten Graphen berechnet es die Änderung des Wirkungszählers beim Hinzufügen eines unvergleichbaren Zwillings. Die ganzzahligen Routenströme werden unabhängig auf den verfeinerten Graphen vorwärts transportiert. Beide Algorithmen verwenden dieselben Modellaxiome und denselben Graph-Lift. `audit.json` protokolliert die exakten Übereinstimmungen.
- `report.tex` ist die Quelle des dreiseitigen Prüfberichts.
