"""Replay the finite order census, monotone-shell control experiment and input controls."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
from auslesen import estimate
import ordnungstest
import schalenprobe
import stromprobe

ROOT=Path(__file__).resolve().parent


def material_reference():
    # Fix a comoving dust/vacuum interface by positive interior and empty exterior;
    # get the starting mass by integrating the current on shells, then track the labels.
    measures={}
    for mass in schalenprobe.MASSES:
        count=128
        cells=[(F(i,count),F(i+1,count)) for i in range(count+2)]
        fluxes=[mass*(min(b,1)**3-min(a,1)**3) for a,b in cells]
        occupied=[b for (a,b),q in zip(cells,fluxes) if q>0]
        surface=max(occupied)
        assert surface==1
        for k in (0,1):
            for x in (F(0),F(1,4),F(1,2)):
                speed,h=schalenprobe.parameters(mass,k)
                cube=1000*(1-speed*x)**2
                rho_scaled=3*mass/cube  # 4*pi*rho on the positive side
                recovered=[rho_scaled*cube*(b**3-a**3)/3 if b<=surface else F(0) for a,b in cells]
                assert recovered==fluxes
                # In synchronous comoving coordinates the mass within every label is invariant.
        assert sum(fluxes)==mass
        measures[str(mass)]={'initial_current_mass':str(sum(fluxes)),'cut_current_mass':str(sum(recovered)),
                             'material_boundary_label':str(surface),'net_side_flux':'0',
                             'positive_cells':len(occupied),'exterior_empty_cells':len(cells)-len(occupied)}
    return measures


def run():
    provenance=json.loads((ROOT/'Herkunft.json').read_text())
    for path,meta in provenance['files'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==meta['sha256'],path
    records=json.loads((ROOT/'quellen/checkpoints.json').read_text())
    assert len(records)==60 and all(r['execution']=='NOT_RUN' and r['checkpoint_id']=='P3' for r in records)
    gate=json.loads((ROOT/'quellen/zulassung.json').read_text())
    assert gate['decision']=='HOLD_NOT_ELIGIBLE'
    order=ordnungstest.run()
    controls=schalenprobe.run()
    # The published endpoints for both extremes are a separate comparison after readout.
    archived=json.loads((ROOT/'quellen/geometrie_resultate.json').read_text())
    for mass in ('1/4','4'):
        for k in ('0','1'):
            known=archived['same_current_metric_controls']['radii'][mass][k]['bounds_exact']
            a,b=map(F,known)
            r,s=map(F,controls[f'M={mass},k={k}']['sizes']['1024']['with_input_bounds']['interval']['radius'])
            assert r<=a<=b<=s
    for k in (0,1):
        light,heavy=[list(map(F,controls[f'M={m},k={k}']['sizes']['256']['with_input_bounds']['interval']['radius'])) for m in ('1/4','4')]
        assert (heavy[1]<light[0] if k==0 else light[1]<heavy[0])
    x=controls['M=1,k=0']['sizes']['1024']['input_with_bounds']
    for replacement in ({'verified_assumptions':False}, {'log_L_drift_per_x':'100000'},
                        {'outside':dict(x['outside'],volume=['0','0'])}):
        try:
            estimate({**x,**replacement})
        except ValueError:
            pass
        else:
            raise RuntimeError('Ungeeignete Kontrolle wurde akzeptiert.')
    grids=schalenprobe.timing_scan(controls)
    assert [grids[str(n)]['first_sufficient_grid_bits_in_scan'] for n in schalenprobe.DENOMINATORS]==[None,None,12,12,13]
    quantized=schalenprobe.stamp_grid(controls['M=1,k=0']['sizes']['512']['input_with_bounds'],4096)
    assert quantized==json.loads((ROOT/'beispiel_m1.json').read_text())
    for k in (0,1):
        by_mass=[schalenprobe.stamp_grid(controls[f'M={m},k={k}']['sizes']['512']['input_with_bounds'],4096) for m in ('1/4','4')]
        l,h=[list(map(F,estimate(v)['radius'])) for v in by_mass]
        assert h[1]<l[0] if k==0 else l[1]<h[0]
    current=stromprobe.whole()
    assert all(F(v[0])>F(51,50) for lobe in current['matched_gain_M1_intervals'].values() for v in lobe.values())
    return {'finite_action_current':current,'marked_causal_histories':order,'same_preparation_continuum_transport':material_reference(),
            'shell_controls':controls,'quantized_clock_controls':grids,'physical':{'eligibility':gate['decision'],'checkpoints_not_run':len(records),
            'mass':None,'surface_at_P3_time':None,'area':None,'radius':None}}


def main():
    if not __debug__:
        raise SystemExit('Bitte ohne -O ausführen.')
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    data=json.dumps(run(),ensure_ascii=False,indent=2)+'\n'
    if args.out:
        args.out.write_text(data)
    else:
        if data!=(ROOT/'ergebnisse.json').read_text():
            raise SystemExit('Nachrechnung weicht vom gespeicherten Resultat ab.')
        print('PASS – Transport, Radarechos, Flächenintervalle und P3-Status reproduziert.')


if __name__=='__main__':
    main()
