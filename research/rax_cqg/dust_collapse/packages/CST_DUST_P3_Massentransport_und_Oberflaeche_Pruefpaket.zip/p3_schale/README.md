# Vom Staubstrom zur Oberfläche auf demselben Schnitt

CST-DUST · 25. November 2026 · [Ausgangsstand auf GitHub](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse)

Der markierte Positivstrom transportiert die Einheitsmasse auf Typ 2324 exakt bis zur Mitte seiner relativen Uhren. Die Ladung aus der vorhandenen Staubwirkung verfehlt dort unter Übernahme ihrer Anfangseichung das 2-%-Ziel auf der gesamten untersuchten synchronisierten Feldbox. Für die Fläche gibt es eine neue unabhängige Auslese aus vier geometrischen Messungen, je einem Schalenvolumen und einer radialen Eigendicke auf beiden Seiten der Grenze. In zwei metrischen Kontrollen schliesst sie den richtigen Radius ein. Auf dem physischen CST-Ensemble fehlen die gemeinsame Eichung sowie die Schalenbeobachtungen. Die 60 P3-Datensätze stehen auf NOT_RUN.

## Reproduzieren

Im entpackten Verzeichnis genügen Python ab 3.10 und die Standardbibliothek.

    sha256sum -c SHA256SUMS
    python3 -B pruefen.py
    python3 -B auslesen.py < beispiel_m1.json

Der Prüfer vergleicht eine vollständige Neuberechnung mit den archivierten Ergebnissen. Ergebnisse und Schranken mit Brüchen stehen in `ergebnisse.json`. `beispiel_m1.json` enthält allein die Eingaben der Flächenauslese für die klassische Kontrolle bei M=1. Das Ausleseprogramm erhält weder Masse noch Sollradius noch den Namen der verwendeten Geometrie. `Herkunft.json` bezeichnet jedes übernommene Daten- und Quelldokument mit Git-Pfad und SHA-256. Es gab keine neuen physischen Laufdaten oder externe Vorregistrierung.

## 1. Anfangsmasse, Transport und tatsächlicher Wirkungsstrom

Vom Kragenereignis 3 bis zum Kragenereignis 7 liegen auf Typ 2324 fünf maximale Pfade. Ihre inneren Folgen sind (4,11), (4,13), (5,12), (6,11) und (14). Wir übernehmen die vorbestehende gleiche positive Markermasse je Pfad. Die Summe der aus dem Anfangsideal auslaufenden Marken ist die Anfangsablesung. Bei M=1 lauten ihre vier Kantengewichte 2/5, 1/5, 1/5, 1/5. Die frühere und spätere Gruppe liegen bei relativer Uhr 1/3 bzw. 2/3; Ereignis 14 bei 1/2. Auf dem mittleren Schnitt durchqueren fünf Anteile zu je 1/5 die Grenze. Ob 14 in das Ideal aufgenommen wird, ändert eine überquerte Kante und lässt die Summe unverändert. Die beiden Varianten decken auch die Position von 14 bei den unabhängigen Uhrjittern ±1/64 ab. Für markierte M=1/4 und 4 ergibt sich dieselbe Bilanz proportional. Dies eicht weder die Ruhemasse noch die normierte N15-Uhr an P3-Eigenzeit. Jeder der fünf markierten Pfade schneidet jedes der betrachteten Ideale genau einmal.

Für die direkte Gegenrechnung wird auf derselben Belegung der fein aufgelöste Originalstrom der Wirkung abgelesen. Für ein Ideal C, die normierten Uhren Y=T/Δ, ihre Schichtgewichte b=(1,−9,16,−8) und das projektübliche Vorzeichen gilt

    p_C = −∂τ S(T+τ1_C) = (1/(19Δ)) Σ_{i∈C, j∉C} wⱼ bᵢⱼ(Yᵢ−Yⱼ).

Der ursprüngliche Zukunftskragen hat w=1/8. Die sieben inneren Verweildauerdichten haben die Form MΔ(4−e)fⱼ mal einen Faktor zwischen 0,99 und 1,01, bei e=δ/Δ und Δ⁴=3/722. Die Uhren, die relativen Feldoffsets und das äussere Paket sind bei den Dosierungen gepaart. Für diese Modellpräparation gilt exakt p_C=M a_C+b_C/Δ. Hier bedeutet b_C die Antwort mit leerem Inneren auf demselben Kragen. Das ist der passende Nullversuch für die jeweilige Schnittmessung. Für die Differenz a_C werden ausschliesslich Empfänger hinter dem Schnitt mit innerer Dichte benötigt. Die Rechnung bildet erst die Summe aller Quellenkoeffizienten eines Empfängers. So bleibt die Abhängigkeit der sieben Uhren vom gemeinsamen Randwert erhalten.

Eiche g am Anfang mit markiertem M=1/4 nach Abzug des passenden Nullwertes, sodass dort g a₀=1. Wir lassen beim Test auch ein negatives g zu. Bei gleicher relativer Feldbelegung liefert der gehaltene Eingang M=1 am späteren Schnitt genau a_C/a₀. Die zwei expliziten Punkte e=±1/4 liegen in den archivierten Uhrfenstern. Die beiden mittleren Ideale enthalten zusätzlich zum Anfangskragen entweder {4,5,6} oder {4,5,6,14}.

| Uhrbelegung | Anfang | Vor Einbezug von 14 | Nach Einbezug von 14 |
| --- | ---: | ---: | ---: |
| e=−1/4, innere Felder zentriert | 1 | 8/5 | 193/115 |
| e=+1/4, innere Felder zentriert | 1 | 48/23 | 53/23 |
| Ganzer linker Lappen, äussere Einschliessung | 1 | [1,1307; 2,3571] | [1,1872; 2,4730] |
| Ganzer rechter Lappen, äussere Einschliessung | 1 | [1,3833; 3,5208] | [1,5299; 3,8797] |

Die beiden Punktzeilen werden zusätzlich durch symmetrische Differenzen der quadratischen Wirkung geprüft. Die Schranken verwenden exakte Bruchrechnung, 64 Teilintervalle je Randuhrfenster, alle inneren Uhrabweichungen und das vollständige 1-%-Dichteband. Das jeweils unabhängige Einschliessen der möglichen Ideale bei Ereignis 14 vergrössert allenfalls die Hülle. Der Startkoeffizient ist durchgehend negativ. Damit gilt die gemeinsame Untergrenze von 1,1307 auch für einen Quotienten gemeinsamer positiver Mittelwerte, wenn dieselben Gewichte über die gepaarten Felder an beiden Schnitten verwendet werden. Der Quotient ist dann ein Mittel der Einzelquotienten mit Gewichten proportional zu |a₀|. Andere kohärente Paarungen und andere Massensektoren sind selbständige Fragen.

Auch der Originalstrom **vor** der Nullsubtraktion nimmt bei M=1 vom Anfang zu beiden mittleren Schnitten ab. Die Identität p_C−p₀=−Σ_{v∈C∖C₀} ∂S/∂Tᵥ verbindet den Befund mit der Staubuhrgleichung bei festgehaltenen übrigen Feldern. Vor Einbezug von 14 ist der Betrag mindestens einer der drei lokalen Ableitungen im linken Lappen grösser als 0,1005 und im rechten grösser als 0,0984 (Projekt-Normierung). Auf diesem Feldbereich kann daher kein freier stationärer Zustand aller dieser Uhren liegen. Im Pfadintegral sind nichtstationäre Beiträge zulässig. Der Test entscheidet über diese auf einer festen Historie ausgewertete Stromdefinition und ihre Anfangseichung.

## 2. Geometrische Flächenablesung

Sei am selben Zeitpunkt eine materielle, sphärische Grenze unabhängig über den Rand des Staubsupports identifiziert. Ihr innerer und äusserer Nachbarschnitt begrenzen zwei vollständige, konzentrische räumliche Schalen. Auf dem gewählten Eigenzeitschnitt sei s radiale Eigenlänge, A(s) die Kugelfläche. Bei einer im betrachteten Streifen nach aussen nicht abnehmenden Fläche gilt

    V = ∫ A(s) ds,         V_in / ℓ_in ≤ A_Rand ≤ V_out / ℓ_out.
    R_ar = √[A_Rand/(4π)].

Es werden räumliche Eigenvolumina am Schnitt benötigt. Insbesondere hat auch eine staubfreie äussere Schale ein geometrisches Volumen. Die Methode setzt als Eingabe eine räumlich und zeitlich zugeordnete Materialgrenze voraus. Bei umkehrender Flächenmonotonie, fehlender Kugelsymmetrie oder nicht senkrechter Radarmessung ist die angegebene Auslese unzureichend.

In der synchronen Geometrie mit radialem Linienelement L(x,u)du trägt die Grenze bei u=1 einen mitbewegten Beobachter. In jeder Richtung reflektiert der benachbarte mitbewegte Marker das radiale Lichtsignal genau bei x*=1/2. Der Beobachter registriert Emission xₑ und Empfang xᵣ. Seine Radarentfernung beträgt d=T_end(xᵣ−xₑ)/2 (c=1). Diese Länge bezieht sich auf zwei Lichtwege in einer zeitabhängigen Geometrie. Zur Überführung auf die Schnittdicke sei |∂ₓ log L|≤K auf dem ganzen Streifen zertifiziert und w=max(x*−xₑ,xᵣ−x*). Entlang jeder Lichtstrecke unterscheidet sich L vom Wert am Reflexionsschnitt um einen Faktor in [exp(−Kw),exp(Kw)]. Integration beider Wege und 1−Kw≤exp(−Kw) liefern für Kw<1 die konservative Einschliessung

    (1−Kw)d ≤ ℓ(x*) ≤ d/(1−Kw).

Alle Intervallgrenzen für Zeit, Volumen und Uhrskala werden nach aussen fortgepflanzt. Die Eingabe `verified_assumptions` ist eine explizite Erklärung des Datenlieferanten. Die unabhängige Begründung der Voraussetzungen ist Teil des jeweiligen Versuchs.

## 3. Auf zwei Geometrien getestet

Wir übernehmen aus der Studie zum materiellen Strom die beiden zeitabhängigen Innenmetriken mit B=10(1−√M x/4)^(2/3), h=k(8M−17)/15, S=Bu(1+hx³u²), L=B/(1+hx³u²)². k=0 ist die klassische Staubkontrolle. k=1 ist eine geometrische Gegenprobe mit derselben Eigenzeit, allen gleichen mitbewegten Volumina und entsprechend gleichem Strom, jedoch geänderter tangentialer Geometrie. Der dort veröffentlichte Endmassenvergleich wird hier um M=1 ergänzt. Für die kurze äussere Radarstrecke wird L,S im schmalen Streifen mit denselben Formeln fortgesetzt und der Staubstrom ausserhalb von u=1 auf null gesetzt. Für diesen hinzugefügten Streifen wird keine dynamische Vakuumlösung beansprucht. Die Massennormierung wird über die 128 positiven radialen Materialzellen kontrolliert. Zwei angrenzende Zellen haben keinen Staub. Die Grenze bleibt bei u=1, ihre materiellen Labels und ihre gesamte eingeschlossene Masse bleiben von x=0 bis x*=1/2 erhalten.

Für jede Geometrie und jede Masse kommen beide Volumina und beide Lichtlaufzeiten aus dieser einen Präparation. Geprüft werden δu=1/64 bis 1/1024. Im betrachteten Bereich x∈[3/8,5/8], u∈[31/32,33/32] gilt |dx/du|<6, |∂ₓ log L|<5 und ∂ᵤS>0. Der Prüfer leitet diese drei Schranken aus den Funktionen auf dem ganzen Rechteck ab. Die Lichtgleichung dx/du=±L/T_end wird in 24 Teilschritten mit rational nach aussen gerundeten Werten eingeschlossen. Der erste Überschlagswert 6δu hält sämtliche Wege innerhalb des geprüften Zeitstreifens. Eine getrennte RK4-Integration prüft beide Wege. Für k=0 liegt zusätzlich die analytische Lösung der Lichtgleichung in jeder numerischen Einschliessung.

Für die folgende unveränderte Auslese gilt δu=1/512, ein relatives Eingabeintervall von ±0,5 % je Schalenvolumen, je ±10⁻⁶ Unsicherheit für die Zeitstempel in x und anschliessend Abrundung/Aufrundung auf das Gitter 2⁻¹². Die angegebenen Grenzen sind nach aussen gerundet. Sie sind deterministische Bereiche der Testdaten, keine statistischen Konfidenzintervalle.

| Masse | Radius, klassische Kontrolle | Radius, Gegenmetrik |
| --- | ---: | ---: |
| 1/4 | [9,3236; 9,8738] | [8,1118; 8,6156] |
| 1 | [8,9225; 9,4490] | [8,2107; 8,7048] |
| 4 | [8,0717; 8,5516] | [9,0101; 9,5784] |

Beide möglichen Vorzeichen des publizierten Kontrasts R₄−R₁/₄ werden korrekt getrennt. Der ungünstigste Radiusendpunkt aller sechs Kontrollen weicht weniger als 3,60 % vom zugehörigen bekannten geometrischen Radius ab. Unter den getesteten gleichmässigen Gittern mit 8 bis 20 Binärstellen reichen bei δu=1/256 und 1/512 erstmals 12 Stellen für die gemeinsame 5-%-Einschliessung. Bei 1/1024 werden 13 benötigt. Bei 1/64 und 1/128 erreicht dieser konservative Ausleser das Ziel auf keinem der getesteten Gitter. Diese Zahlen setzen synthetische Volumina, einen bekannten Uhrmassstab und die ausgewiesene Metrikdrift voraus. Sie sind keine Mindestanforderung an jede mögliche physische Messung.

## 4. Wie viel die veröffentlichten N15-Uhrmarken verraten

Auf jedem der 1 048 Typen verwenden wir exakt die publizierte Wahl der zentralen relativen Uhren aus der synchronisierten Präparation. Für ein Ereignis q auf der halben Uhr und jeden maximalen anders verlaufenden Pfad durch Quelle und Senke klammern die letzten vorausgehenden und ersten nachfolgenden Pfadmarken die beiden unbekannten Lichtkontakte ein. Am Beobachterpfad ist der letzte kausal vor q liegende Zeitpunkt eine Untergrenze der Emissionszeit. Die nächste Pfadmarke und die Uhr von q begrenzen diese von oben. Analog begrenzen die erste kausale Nachfolgemarke und ihre Vorgängerin die Empfangszeit. Das setzt eine getreue Einbettung der Ordnung, einen kontinuierlichen zeitartigen Beobachter, monotone synchrone Zeit und für metrische Einheiten eine Uhrkalibrierung voraus.

599 Typen liefern ein solches mittleres Ereignis abseits eines Beobachterpfads. Von den 5 119 Paaren liefern 3 597 eine strikt positive untere Radargrenze. Das kleinste Verhältnis obere/untere Radargrenze ist 7/5. Für die Übertragung eines einzelnen solchen Dickenintervalls in R proportional zu ℓ^(−1/2), selbst bei ideal bekanntem V und statischer dünner Schale, wäre für eine gemeinsame ±5-%-Einschliessung höchstens (1,05/0,95)²≈1,2217 zulässig. Keine einzelne Klammer erreicht das. Eine gemeinsame Inferenz aus mehreren korrelierten Pfaden, anderen Schnittzeiten oder zusätzlichen Geometriedaten ist durch diesen Befund nicht ausgeschlossen. Die Quote beschreibt die Grobheit der Klammer. Sie ist keine untere Fehlerschranke für jeden denkbaren Radiusoperator.

Das beste Beispiel hat Typ 375775. Die sechs inneren Beobachtermarken liegen in einer flachen Realisierung bei räumlicher Koordinate 0 zu Zeiten 1/7,…,6/7, die gemeinsamen Enden bei 0 und 1. Ereignis 14 liegt bei T=1/2 und bei räumlichem Abstand r. Für **jedes** 5/14<r<1/2 ist es von den sechs inneren Marken raumartig getrennt und mit beiden Enden zeitartig verbunden. Seine Radarentfernung ist exakt r, während alle abgelesenen Ordnungsrelationen gleich bleiben. Die zwei rationalen Zeugen r=9/25 und 49/100 werden paarweise mit der Minkowski-Ungleichung geprüft. Diese lokale Realisierung verifiziert die Schärfe der Endpunkte für die gegebene Beobachterordnung. Eine zweite vierdimensionale Staubballlösung oder ein P3-Eigenzeitnachweis wird dadurch nicht konstruiert. Auf Typ 2324 ergibt die konkrete Beobachterlinie 3→4→11→7 gegenüber Ereignis 14 am Zentrum das Intervall [1/6,1/2] in Einheiten der gesamten relativen Uhrspanne.

## Physischer Anschluss

Für einen physischen Lauf müssen der unabhängige Null- und Positivstandard des Staubstroms auf derselben Präparation, die mitbewegte Grenze mit Nachbarschaft auf beiden Seiten, ihre P3-Eigenzeit, die zwei geometrischen Volumina, die radiale Längeninformation sowie ein belastbares Drift- und Gesamtfehlerbudget vorliegen. Ein Abgleich des gemessenen Radars mit einer unabhängig bestimmten Schnittmetrik kann die Driftschranke ersetzen. Im kohärenten Programm müssen zudem die Auslese und die gemeinsame physikalische Paarung feststehen. Die neue Rechnung isoliert eine konkrete Schwäche des bisherigen Stroms und einen getrennt überprüfbaren Weg zur Fläche.

- [Schnittstrom und materielle Oberfläche](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/material_current_surface_v0_1)
- [Synchronisierte Präparation und Uhrenbereiche](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/synchronized_distributed_dust_v0_1)
- [Definition und Verlauf des Wirkungsstroms](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/n15_stromtransport_ward_v0_1)
- [P3-Vertrag und Freigabe](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/dcda14fa2206ad87c04bd0e0966a86a6ba067241/research/rax_cqg/dust_collapse/correspondence_v0_1)
- [Volker Perlick, On the radar method in general-relativistic spacetimes](https://arxiv.org/abs/0708.0170)
