# Massentransport und Arealradius am frühen Staubschnitt

Lokaler explorativer Prüfplan vom 25. November 2026 nach Durchsicht der veröffentlichten Vorarbeiten. Keine externe Vorregistrierung.

1. Dieselbe markierte Anfangspräparation auf dem veröffentlichten Typ 2324 bis zur halben normierten Uhrzeit verfolgen. Anfangsmasse, Fluss über den Schnitt und Mehrdeutigkeit der Oberflächenzuordnung getrennt erfassen. Die Zuordnung dieser Uhr zur P3-Eigenzeit ist eine zu prüfende Zusatzvoraussetzung.
2. Für jeden zugelassenen N15-Typ und die vorhandenen mittleren Uhren prüfen, wie weit Vorgänger und Nachfolger eines mittleren Ereignisses auf jeder anderen maximalen Staublinie eine Radarzeit einklammern. Beide gemeinsamen Kragenenden zulassen, Ergebnisse als reine Ordnungsinformation führen.
3. Am eingefrorenen P3-Zeitpunkt x=1/2 eine ein- und eine auswärtige Schale um den Rand der Materie verfolgen. Bei monoton nach aussen wachsender Fläche A die beiden Volumen-pro-Eigendicke-Quotienten als Flächenschranken verwenden. Eigendicke über Lichtlaufzeit und eine unabhängige Schranke für die zeitliche Drift der radialen Metrik eingrenzen. Klassenreferenz und vorhandene Gegenmetrik mit unveränderter Auslese prüfen, auch bei der zurückgehaltenen Massendosis M=1.
4. Kleinere Schalen und das Einbeziehen von Volumen- und Zeitunsicherheiten vergleichen. Den klassischen Sollradius erst zur Validierung nach der Auswertung verwenden. Die P3-Felder ohne gemeinsamen physischen Datensatz fehlend lassen.

Nach der ersten Schalen- und Ordnungsrechnung ergänzten wir eine abgestufte Rundung der Echos auf feste Uhrgitter, eine scharfe flache Realisierung des engsten Radarintervalls und die Auswertung des tatsächlichen Wirkungsstroms auf den zwei mittleren Idealen von Typ 2324. Die Aussagen sind nachgerechnete explorative Ergebnisse.
