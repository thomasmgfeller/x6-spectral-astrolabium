"""Read the current of the unmodified dust action and its matched vacuum on type 2324."""
from fractions import Fraction as F
from itertools import product
from ordnungstest import clock_map,ROOT
from quellen import support


def bounds(v):
    return v,v


def plus(a,b):
    return a[0]+b[0],a[1]+b[1]


def times(a,b):
    vals=[x*y for x,y in product(a,b)]
    return min(vals),max(vals)


def minus(a,b):
    return a[0]-b[1],a[1]-b[0]


def whole():
    nodes,order=support.geometry(2324)
    paths,_=support.paths_and_edges(order)
    clock=clock_map(nodes,order,paths)
    fraction=support.fractions_on_paths(paths,clock)
    coeff={}
    for i,j in order:
        n=sum((i,v) in order and (v,j) in order for v in range(15))
        if n<4:
            coeff[i,j]=(1,-9,16,-8)[n]
    past=set(support.PAST)
    cuts={'start':past,'mid_before':past|{v for v in nodes if clock[v]<F(1,2)},
          'mid_after':past|{v for v in nodes if clock[v]<=F(1,2)}}
    jitter=F(1,64)
    u={v:(clock[v]-jitter,clock[v]+jitter) for v in nodes}
    _,rows,_=support.system(2324)
    fwide={}
    for v,f,row in zip(nodes,fraction,rows[-7:]):
        dev=jitter*sum(abs(c) for c in row[:7])
        fwide[v]=times((F(99,100),F(101,100)),(f-dev,f+dev))
    def slopes(e,ui,weights):
        duration=minus(bounds(4),e)
        out={}
        for name,cut in cuts.items():
            value=bounds(0)
            for j in set(nodes)-cut:
                clockpart=bounds(0)
                for i in sorted(past-{3}):
                    clockpart=plus(clockpart,times(bounds(coeff.get((i,j),0)),minus(bounds(i-3),e)))
                inner=bounds(0)
                for i in cut-past:
                    inner=plus(inner,times(bounds(coeff.get((i,j),0)),ui[i]))
                inner=minus(inner,times(bounds(sum(coeff.get((i,j),0) for i in cut)),ui[j]))
                value=plus(value,times(weights[j],plus(clockpart,times(duration,inner))))
            out[name]=times(times(duration,bounds(F(1,19))),value)
        return out
    def vacuum(e,ui):
        Y={v:bounds(F(v-5)) for v in support.PAST+support.FUTURE}
        Y[3]=plus(Y[3],e)
        Y.update({v:plus(Y[3],times(minus(bounds(4),e),ui[v])) for v in nodes})
        out={}
        for key,cut in cuts.items():
            total=bounds(0)
            for i in cut:
                row=[(coeff.get((i,j),0),F(j-5)) for j in support.FUTURE]
                total=plus(total,minus(times(Y[i],bounds(sum(b for b,_ in row))),
                                       bounds(sum(b*t for b,t in row))))
            out[key]=times(total,bounds(F(1,152)))
        return out
    exact={}
    full={}
    ratios={}
    residual={}
    for label,window,e0 in zip(('left','right'),support.WINDOWS,(-F(1,4),F(1,4))):
        central=slopes(bounds(e0),{v:bounds(clock[v]) for v in nodes},dict(zip(nodes,map(bounds,fraction))))
        assert all(a==b for a,b in central.values())
        Y={v:F(v-5) for v in support.PAST+support.FUTURE}
        Y[3]+=e0
        Y.update({v:Y[3]+(4-e0)*clock[v] for v in nodes})
        w_slope={v:(4-e0)*f for v,f in zip(nodes,fraction)}
        unit_dens={v:F(1,8) for v in support.PAST+support.FUTURE}
        def variation(ys,w):
            return -sum(w.get(v,0) for v in range(15))/2-sum(w.get(j,0)*b*(ys[i]-ys[j])**2 for (i,j),b in coeff.items())/38
        def difference(cut,w):
            z=F(1,73)
            return (variation({v:T-(z/2 if v in cut else 0) for v,T in Y.items()},w)
                   -variation({v:T+(z/2 if v in cut else 0) for v,T in Y.items()},w))/z
        exact[label]={}
        for name,cut in cuts.items():
            a=central[name][0]
            b=sum((F(coeff.get((i,j),0),152)*(Y[i]-Y[j]) for i in cut for j in support.FUTURE),F(0))
            assert difference(cut,w_slope)==a and difference(cut,unit_dens)==b
            exact[label][name]={'mass_slope':str(a),'vacuum_times_Delta':str(b),
                         'M1_using_initial_gain_after_local_vacuum_subtraction':str(a/central['start'][0])}
        tiles=[]
        zeros=[]
        for k in range(64):
            band=tuple(window[0]+(window[1]-window[0])*F(j,64) for j in (k,k+1))
            e=times(band,(1/support.DELTA[1],1/support.DELTA[0]))
            tiles.append(slopes(e,u,fwide))
            zeros.append(vacuum(e,u))
        ratios[label]={}
        residual[label]={}
        for name in ('mid_before','mid_after'):
            tile_ratios=[]
            differences=[]
            for row,zero in zip(tiles,zeros):
                a,b=row['start']
                assert a<=b<0 and row[name][1]<0
                tile_ratios.append(times(row[name],(1/b,1/a)))
                assert zero['start']==(0,0) and zero[name][1]<0
                diff=plus(minus(row[name],row['start']),times(zero[name],(1/support.DELTA[1],1/support.DELTA[0])))
                differences.append(diff)
            total_lo,total_hi=min(d[0] for d in differences),max(d[1] for d in differences)
            assert total_hi<0
            residual[label][name]={'p_cut_minus_p_start_M1':list(map(str,(total_lo,total_hi))),
                    'number_of_new_nodes':len(cuts[name]-past),
                    'some_abs_clock_gradient_at_least':str(-total_hi/len(cuts[name]-past))}
            ratios[label][name]=list(map(str,(min(v[0] for v in tile_ratios),max(v[1] for v in tile_ratios))))
        full[label]={name:list(map(str,(min(row[name][0] for row in tiles),max(row[name][1] for row in tiles)))) for name in cuts}
    assert exact['left']['start']['mass_slope']=='-391/912' and exact['right']['start']['mass_slope']=='-69/304'
    return {'formula':'p_A = M*a_A + b_A/Delta; matched empty-interior baseline on identical clocks and collar; full-width slopes allow proportional matched density perturbations.','point':exact,'full_slope_intervals':full,'matched_gain_M1_intervals':ratios,'raw_clock_gradient_M1':residual}
