"""Generate two-sided geometric observations on the two published synchronous interior metrics."""
from fractions import Fraction as F
from functools import lru_cache
from math import sqrt
from auslesen import SCALE,PI,root_bound,estimate

XSTAR = F(1,2)
TUNIT = root_bound(F(125,9),2)
MASSES = (F(1,4),F(1),F(4))
DENOMINATORS = (64,128,256,512,1024)
STEPS = 24


def outward(q, upper):
    n = q.numerator*SCALE
    d = q.denominator
    return F(-((-n)//d) if upper else n//d, SCALE)


def parameters(mass, k):
    a,b = root_bound(mass,2)
    assert a==b
    return a/4,k*(8*mass-17)/15


@lru_cache(maxsize=65536)
def base(speed,x):
    return root_bound(1000*(1-speed*x)**2,3)


def speed_box(speed,h,xlo,xhi,ulo,uhi):
    # Synchronous radial light cone |dx/du| = B/(T_end (1+h*x^3*u^2)^2).
    if not F(3,8)<=xlo<=xhi<=F(5,8) or not F(31,32)<=ulo<=uhi<=F(33,32):
        raise ValueError('Aussenbereich des zertifizierten Lichtkegels.')
    c = sorted((h*xlo**3*ulo**2,h*xhi**3*uhi**2))
    lo = base(speed,xhi)[0]/(TUNIT[1]*(1+c[1])**2)
    hi = base(speed,xlo)[1]/(TUNIT[0]*(1+c[0])**2)
    return lo,hi


def check_global_bounds():
    # Valid for all three masses, both geometries and both extended radial shells.
    xmin,xmax,umax = F(3,8),F(5,8),F(33,32)
    min_s = 1-xmax**3*umax**2
    min_dSdu_factor = 1-3*xmax**3*umax**2
    assert min_s>0 and min_dSdu_factor>0
    assert 10/(TUNIT[0]*min_s**2)<6
    assert (F(1,3)/(1-xmax/2)+6*xmax**2*umax**2/min_s)<5
    assert F(6,64)<min(XSTAR-xmin,xmax-XSTAR)


def null_stamp(speed,h,side,delta,branch):
    # At x*, reflection on the adjacent shell. Integrate both light legs back to u=1.
    dx = delta/STEPS
    lo = hi = XSTAR
    for i in range(STEPS):
        start = 1+side*(delta-i*dx)
        end = start-side*dx
        ula,uha = sorted((start,end))
        boxlo = lo-(6*dx if branch<0 else 0)
        boxhi = hi+(6*dx if branch>0 else 0)
        vmin,vmax = speed_box(speed,h,boxlo,boxhi,ula,uha)
        if branch<0:
            lo,hi = lo-vmax*dx,hi-vmin*dx
        else:
            lo,hi = lo+vmin*dx,hi+vmax*dx
        lo,hi = outward(lo,False),outward(hi,True)
    return lo,hi


def rk4_stamp(speed,h,side,delta,branch):
    # Separate floating point integration of the light ray, with no interval updates.
    delta, speed, h = map(float,(delta,speed,h))
    dt = delta/120
    unit = sqrt(125/9)
    def rhs(v,x):
        u = 1+side*(delta-v)
        return branch*10*(1-speed*x)**(2/3)/(unit*(1+h*x**3*u*u)**2)
    x = .5
    for j in range(120):
        v = j*dt
        a = rhs(v,x)
        b = rhs(v+dt/2,x+dt*a/2)
        c = rhs(v+dt/2,x+dt*b/2)
        d = rhs(v+dt,x+dt*c)
        x += dt*(a+2*b+2*c+d)/6
    return x


def phase_row(speed,h,side,delta):
    ul,ur = sorted((F(1),1+side*delta))
    # Volume on the fixed-time cut. The same formula holds in both fixtures.
    volume_factor = 4*1000*(1-speed*XSTAR)**2*(ur**3-ul**3)/3
    row = {'volume':[str(PI[0]*volume_factor),str(PI[1]*volume_factor)]}
    for leg,branch in [('emission',-1),('reception',1)]:
        lo,hi = null_stamp(speed,h,side,delta,branch)
        if h==0:
            # Closed-form conformal travel time on the homogeneous collapsing reference.
            a,b = root_bound(1-speed*XSTAR,3)
            shift = sorted(branch*10*speed*delta/(3*t) for t in TUNIT)
            clo,chi = a-shift[1],b-shift[0]
            analytic = (1-chi**3)/speed,(1-clo**3)/speed
            assert lo<=analytic[0]<=analytic[1]<=hi
        rk = rk4_stamp(speed,h,side,delta,branch)
        assert float(lo)<=rk<=float(hi)
        row[leg] = list(map(str,(lo,hi)))
    return row


def run():
    check_global_bounds()
    rows = {}
    for m in MASSES:
        for k in (0,1):
            speed,h = parameters(m,k)
            true_radius = [v*(1+h*XSTAR**3) for v in base(speed,XSTAR)]
            label = f'M={m},k={k}'
            by_size = {}
            for n in DENOMINATORS:
                delta = F(1,n)
                sample = {'verified_assumptions':True,'clock_unit':list(map(str,TUNIT)),
                          'reflection_x':str(XSTAR),'log_L_drift_per_x':'5'}
                for tag,side in [('inside',-1),('outside',1)]:
                    sample[tag] = phase_row(speed,h,side,delta)
                def checked(data):
                    result = estimate(data)
                    rl,rh = map(F,result['radius'])
                    assert rl <= true_radius[0] <= true_radius[1] <= rh
                    worst = max(1-rl/true_radius[1],rh/true_radius[0]-1)
                    return {'interval':result,'max_relative_error_upper':str(worst)}
                baseline = checked(sample)
                noisy = dict(sample)
                for tag,side in [('inside',-1),('outside',1)]:
                    timed = sample[tag]
                    wrapped = {}
                    a,b = map(F,timed['volume'])
                    wrapped['volume'] = list(map(str,(a*F(199,200),b*F(201,200))))
                    for leg in ('emission','reception'):
                        a,b = map(F,timed[leg])
                        wrapped[leg] = list(map(str,(a-F(1,10**6),b+F(1,10**6))))
                    noisy[tag] = wrapped
                by_size[str(n)] = {'nominal':baseline,'with_input_bounds':checked(noisy),
                                   'input_with_bounds':noisy}
            rows[label] = {'expected_radius':list(map(str,true_radius)),'sizes':by_size}
    return rows


def stamp_grid(original,grid):
    sample = dict(original)
    for tag in ('inside','outside'):
        row = dict(sample[tag])
        for leg in ('emission','reception'):
            lo,hi = map(F,row[leg])
            row[leg] = [str(F((lo*grid)//1,grid)),str(-F((-hi*grid)//1,grid))]
        sample[tag] = row
    return sample


def timing_scan(controls):
    # Quantize observer statements outwards to an independent regular clock grid.
    # The input already includes the previously declared instrument tolerances.
    result = {}
    for n in DENOMINATORS:
        scores = {}
        for bits in range(8,21):
            grid = 2**bits
            max_error = F(0)
            worst_case = None
            for label,case in controls.items():
                original = case['sizes'][str(n)]['input_with_bounds']
                sample = stamp_grid(original,grid)
                try:
                    bounds = estimate(sample)
                except ValueError:
                    max_error = None
                    break
                a,b = map(F,case['expected_radius'])
                rl,rh = map(F,bounds['radius'])
                assert rl<=a<=b<=rh
                error = max(1-rl/b,rh/a-1)
                if error>max_error:
                    max_error,worst_case = error,label
            scores[str(bits)] = {'worst_fraction':None if max_error is None else str(max_error),
                                 'worst_case':None if max_error is None else worst_case}
        good = [int(b) for b,v in scores.items() if v['worst_fraction'] and F(v['worst_fraction'])<=F(1,20)]
        result[str(n)]={'first_sufficient_grid_bits_in_scan':min(good) if good else None,'scores':scores}
    return result
