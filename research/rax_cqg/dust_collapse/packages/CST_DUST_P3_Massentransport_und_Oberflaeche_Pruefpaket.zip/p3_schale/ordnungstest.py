"""Comoving marked transport and order-only radar brackets on the frozen finite catalogue."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
from quellen import support

ROOT = Path(__file__).resolve().parent
MID = F(1,2)


def clock_map(nodes,relation,paths):
    height = max(map(len,paths))
    stamps = {v:F(max(p.index(v)+1 for p in paths if v in p),height+1) for v in nodes}
    for v in nodes:
        if all((v,w) not in relation and (w,v) not in relation for w in nodes):
            stamps[v]=MID
    return {3:F(0),7:F(1),**stamps}


def radar_section(path,q,order,clock):
    before = max(i for i,v in enumerate(path) if (v,q) in order)
    after = min(i for i,v in enumerate(path) if (q,v) in order)
    e_lo = clock[path[before]]
    e_hi = min(clock[q],clock[path[before+1]])
    r_lo = max(clock[q],clock[path[after-1]])
    r_hi = clock[path[after]]
    assert e_lo<=e_hi<=clock[q]<=r_lo<=r_hi
    return (r_lo-e_hi)/2, (r_hi-e_lo)/2


def transport(paths,order,clock,mass):
    edges = Counter()
    normalized_paths = [(3,*p,7) for p in paths]
    weight = mass/len(paths)
    for path in normalized_paths:
        for a,b in zip(path,path[1:]):
            edges[a,b] += weight
    for v in support.I:
        assert sum(w for (a,b),w in edges.items() if a==v)==sum(w for (a,b),w in edges.items() if b==v)
    cuts = {}
    for tag,selected in [('start',{3}),('mid_before',{v for v,t in clock.items() if t<MID}),
                         ('mid_after',{v for v,t in clock.items() if t<=MID})]:
        assert all(a in selected for a,b in order if a in clock and b in selected)
        crossing = {(a,b):w for (a,b),w in edges.items() if a in selected and b not in selected}
        assert not any(a not in selected and b in selected for a,b in edges)
        assert sum(crossing.values())==mass
        # Independent path-level count, including paths with a vertex exactly on the cut.
        for path in normalized_paths:
            assert sum(a in selected and b not in selected for a,b in zip(path,path[1:]))==1
        cuts[tag]={'mass':str(sum(crossing.values())),
                   'crossings':{f'{a}->{b}':str(w) for (a,b),w in sorted(crossing.items())}}
    return cuts


def run():
    count = Counter()
    best = None
    best_examples = []
    for code in support.catalogue():
        nodes,order = support.geometry(code)
        paths,_ = support.paths_and_edges(order)
        clock = clock_map(nodes,order,paths)
        any_target = False
        any_positive = False
        for q in nodes:
            if clock[q]!=MID:
                continue
            for p in paths:
                if q in p:
                    continue
                any_target=True
                lo,hi = radar_section((3,*p,7),q,order,clock)
                count['path_event_pairs'] += 1
                if lo:
                    any_positive=True
                    count['positive_lower_pairs'] += 1
                    ratio=hi/lo
                    if best is None or ratio<best:
                        best,best_examples = ratio,[]
                    if ratio==best and len(best_examples)<5:
                        best_examples.append({'code':code,'event':q,'chain':p,'range':list(map(str,(lo,hi)))})
                if lo and hi/lo <= (F(105,95))**2:
                    count['pairs_satisfying_five_percent_radius_ratio'] += 1
        count['types']+=1
        count['types_with_pairs']+=any_target
        count['types_with_positive_lower']+=any_positive
    code=2324
    nodes,order=support.geometry(code)
    paths,_=support.paths_and_edges(order)
    clock=clock_map(nodes,order,paths)
    archived=json.loads((ROOT/'quellen/uhren.json').read_text())
    assert archived['clock_center']=={str(v):str(clock[v]) for v in nodes}
    assert [list(p) for p in paths]==archived['chains_excluding_inlet_and_exit']
    case = {}
    for m in (F(1,4),F(1),F(4)):
        case[str(m)]=transport(paths,order,clock,m)
    observer=(3,4,11,7)
    assert radar_section(observer,14,order,clock)==(F(1,6),F(1,2))
    # For the best bracket construct two exact, causal-order-equivalent flat embeddings.
    best_code=375775
    best_nodes,best_order=support.geometry(best_code)
    best_paths,_=support.paths_and_edges(best_order)
    stamps=clock_map(best_nodes,best_order,best_paths)
    assert best==F(7,5) and radar_section((3,4,5,6,11,12,13,7),14,best_order,stamps)==(F(5,14),MID)
    for radius in (F(9,25),F(49,100)):
        xpos={v:(radius if v==14 else F(0)) for v in stamps}
        observed={(v,w) for v in stamps for w in stamps if stamps[w]-stamps[v]>abs(xpos[v]-xpos[w])}
        assert {(u,v) for u,v in best_order if u in stamps and v in stamps}==observed
        assert all(abs(stamps[w]-stamps[v])!=abs(xpos[v]-xpos[w]) for v in stamps for w in stamps if v!=w)
    j=F(archived['clock_halfwidth'])
    count.setdefault('pairs_satisfying_five_percent_radius_ratio',0)
    return {'census':dict(count),'minimum_finite_upper_to_lower_ratio':str(best),
            'sharp_flat_example':{'type':best_code,'distinct_radar_distances':['9/25','49/100'],'open_realization_range':['5/14','1/2']},'examples_at_minimum':best_examples,'case_2324':{'paths':paths,'cut':case,
            'path_4_11_event_14':{'nominal_radar_interval':['1/6','1/2'],
            'uniform_under_independent_clock_jitter':[str(F(1,6)-j),'1/2']}},
            'conditional_assumptions':'continuous timelike observer, causal fidelity of sampled relations, monotone synchronous time and known clock scale; no common identification with the P3 time on N15'}
