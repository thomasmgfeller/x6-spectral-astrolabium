"""Blind decision using only the marked causal incidence counts and two calibration constants."""
import numpy as np


def classify(counts, rho, width):
    # Axes: three chronological windows, outgoing/incoming, ordered sphere identifiers.
    counts=np.asarray(counts)
    if counts.ndim!=3 or counts.shape[:2]!=(3,2) or (counts<0).any():
        raise ValueError("Invalid marked window counts")
    radius=np.cbrt(3*counts[1].mean(axis=0)/(4*np.pi*rho*width))
    out,inc=counts[2]-counts[0]
    if np.all(inc<0):
        if np.all(out>0): return "CLEAR",None
        negative=np.flatnonzero(out<0)
        if negative.size:
            j=int(negative[0])
            if j>0 and np.all(out[:j]>0) and np.all(out[j:]<0) and radius[j]>radius[j-1]:
                fraction=out[j-1]/(out[j-1]-out[j])
                return "DETECTED",float(radius[j-1]+fraction*(radius[j]-radius[j-1]))
    return "UNRESOLVED",None
