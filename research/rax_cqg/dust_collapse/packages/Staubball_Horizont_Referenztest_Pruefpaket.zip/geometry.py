"""Projected marked-order cells and independent exact-law coordinate sampling."""
import math
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad

BALL=1.55
CUTS=(-2.,-1.6)
LEVELS=((2**15,1/16,1/32,10),(2**21,1/32,1/64,5))
NODES,WEIGHTS=leggauss(6)
V_UNIT=4*math.pi/3


def scale(t,dust): return t*t/4 if dust else np.ones_like(t)
def tau(t,dust): return t**3/12 if dust else t
def eta(t,dust): return np.cbrt(12*t) if dust else t


def grid(step):
    return np.arange(35,136,step)/100


def windows(cut,d,width,dust):
    return [(float(eta(tau(cut,dust)+i*d-width/2,dust)),
             float(eta(tau(cut,dust)+i*d+width/2,dust))) for i in (-1,0,1)]


def cells(lo,hi,cut,s,dust):
    # Work in x = eta - cut. Linear radial boundaries are b+m*x.
    left,right=lo-cut,hi-cut
    assert min(s[0]-max(abs(left),abs(right)),BALL-s[-1]-max(abs(left),abs(right)))>0
    # Only intersections of one outgoing and one incoming shell change radial ordering.
    crossings=(s[:,None]-s[None,:])/2
    points=sorted({left,right,*[float(x) for x in np.unique(np.round(crossings,13)) if left<x<right]})
    intercept=np.r_[0,s,s,BALL]
    slope=np.r_[0,np.ones(len(s)),-np.ones(len(s)),0]
    masks=[];volumes=[]
    for a,b in zip(points,points[1:]):
        xm=(a+b)/2
        order=np.argsort(intercept+slope*xm,kind="stable")
        nodes=xm+(b-a)*NODES/2
        r=intercept[order,None]+slope[order,None]*nodes
        low,high=r[:-1],r[1:]
        shell=(high-low)*(high**2+high*low+low**2)
        assert np.min(shell)>-1e-11
        vol=V_UNIT*(b-a)/2*(shell@(WEIGHTS*scale(nodes+cut,dust)**4))
        mid=(intercept[order]+slope[order]*xm)
        sample=(mid[:-1]+mid[1:])/2
        membership=np.c_[sample[:,None]<s[None,:]+xm,sample[:,None]<s[None,:]-xm]
        volumes.extend(vol);masks.extend(membership)
    volumes=np.array(volumes); masks=np.array(masks,dtype=np.int64)
    assert np.all(volumes>0)
    return volumes,masks


def verify_cells(vol,masks,lo,hi,cut,s,dust):
    """Integrate each pairwise intersection separately in proper time, including clipped rays."""
    projections=np.r_[s,s]
    signs=np.repeat([1,-1],len(s))
    totals=masks.T@(vol[:,None]*masks)
    def integral(i,j):
        def value(T):
            e=eta(T,dust)
            r=min(BALL,projections[i]+signs[i]*(e-cut),projections[j]+signs[j]*(e-cut))
            return V_UNIT*(max(r,0)*float(scale(e,dust)))**3
        cross=[]
        if signs[i]!=signs[j]:
            where=cut+(projections[j]-projections[i])/(signs[i]-signs[j])
            if lo<where<hi: cross=[tau(where,dust)]
        return quad(value,tau(lo,dust),tau(hi,dust),points=cross,epsabs=1e-12)[0]
    # All self-marginals, all paired cones and all mixed intersections.
    errors=[abs(totals[i,j]-integral(i,j)) for i in range(len(signs)) for j in range(i+1)]
    total_ref=quad(lambda T: V_UNIT*(BALL*scale(eta(T,dust),dust))**3,tau(lo,dust),tau(hi,dust))[0]
    maxerr=max(abs(vol.sum()-total_ref),max(errors))
    if maxerr>2e-12:raise ArithmeticError("Cell overlap check")
    return float(maxerr)


def explicit_window(rng,lo,hi,cut,s,dust,rho):
    integral=(hi**9-lo**9)/(9*256) if dust else hi-lo
    num=int(rng.poisson(rho*V_UNIT*BALL**3*integral))
    counted=np.zeros((2,len(s)),dtype=np.int64)
    emit=cut-s;receive=cut+s
    for start in range(0,num,8192):
        n=min(8192,num-start)
        u=rng.random(n)
        t=-((-lo)**9-u*((-lo)**9-(-hi)**9))**(1/9) if dust else lo+u*(hi-lo)
        radius=BALL*np.cbrt(rng.random(n))
        direction=rng.normal(size=(n,3))
        xyz=direction*(radius/np.linalg.norm(direction,axis=1))[:,None]
        dist2=np.einsum("ij,ij->i",xyz,xyz)[:,None]
        dt1=t[:,None]-emit;dt2=receive-t[:,None]
        direct=np.array([((dt1>0)&(dt1**2>dist2)).sum(axis=0),((dt2>0)&(dt2**2>dist2)).sum(axis=0)])
        # Alternative radial implementation, reverse the point labels as an invariance check.
        keys=(radius-(t-cut),radius+(t-cut))
        radial=np.array([np.cumsum(np.bincount(np.searchsorted(s,v[::-1],side="right"),minlength=len(s)+1))[:-1] for v in keys])
        if not np.array_equal(direct,radial): raise ArithmeticError("Explicit relation mismatch")
        counted+=direct
    return num,counted
