"""Separate classifier and continuous cone checks; replay every trial from bare counts."""
import csv
import json
import math
from collections import Counter
from pathlib import Path
import numpy as np
from scipy.integrate import quad

ROOT=Path(__file__).resolve().parent


def independent(count,rho,w):
    early,central,late=count
    states=[]
    for j in range(len(central[0])):
        if late[1,j]>=early[1,j]:return 'UNRESOLVED',None
        states.append(int(np.sign(late[0,j]-early[0,j])))
    if set(states)=={1}:return 'CLEAR',None
    for j in range(1,len(states)):
        if states!=[1]*j+[-1]*(len(states)-j):continue
        radius=[(3*(central[0,i]+central[1,i])/(8*math.pi*rho*w))**(1/3) for i in (j-1,j)]
        if radius[0]>=radius[1]:break
        u=late[0,j-1]-early[0,j-1]; v=early[0,j]-late[0,j]
        return 'DETECTED',(v*radius[0]+u*radius[1])/(u+v)
    return 'UNRESOLVED',None


def run():
    with (ROOT/'individual.csv').open() as stream:
        rows={(r['geometry'],int(r['level']),float(r['eta_cut']),int(r['replicate'])):r for r in csv.DictReader(stream)}
    data=json.loads((ROOT/'results.json').read_text())
    total=0; explicit=0; points=0; errors=[]; references=[]
    with np.load(ROOT/'marked_counts.npz',allow_pickle=False) as raw:
        for level,(rho,d,w) in enumerate([(2**15,1/16,1/32),(2**21,1/32,1/64)]):
            for g,name in enumerate(('dust','flat')):
                for cutno,cut in enumerate((-2.,-1.6)):
                    case=data['levels'][str(level)]['cases'][name][cutno]
                    counts=raw[f'g{g}_level{level}_cut{cutno}']
                    totals=Counter()
                    for i,sample in enumerate(counts):
                        status,r=independent(sample,rho,w)
                        row=rows[name,level,cut,i]
                        assert status==row['decision']
                        if r is not None: assert abs(r-float(row['estimated_radius']))<1e-12
                        totals[status]+=1
                        total+=1
                    assert [totals[k] for k in ('CLEAR','DETECTED','UNRESOLVED')]==[case['statuses'][k] for k in ('clear','detected','unresolved')]
                    est=independent(np.array(case['explicit_counts']),rho,w)
                    assert est[0]==case['explicit_decision'][0]
                    if est[1] is not None: assert abs(est[1]-case['explicit_decision'][1])<1e-12
                    explicit+=1
                    points+=sum(case['explicit_points_in_slabs'])
                    # Compute means from V(T) integrated over the windows, independent of radial cell partition.
                    s=np.arange(35,136,10 if level==0 else 5)/100
                    def rad(t,r,direction):
                        e=np.cbrt(12*t) if g==0 else t
                        factor=e**2/4 if g==0 else 1
                        return factor*(r+direction*(e-cut))
                    tc=cut**3/12 if g==0 else cut
                    means=np.array([[[rho*quad(lambda t:4*math.pi/3*rad(t,chi,direction)**3,
                        tc+step*d-w/2,tc+step*d+w/2)[0] for chi in s] for direction in (1,-1)] for step in (-1,0,1)])
                    reference=independent(means,rho,w)
                    assert reference[0]==case['expected_decision'][0]
                    if reference[1] is not None:
                        assert abs(reference[1]-case['expected_decision'][1])<1e-12
                        a=cut**2/4
                        density=3*(8/cut**3)**2/(8*math.pi)  # G=1
                        R=case['target']
                        mass=4*math.pi*R**3*density/3
                        assert abs(2*mass/R-1)<1e-13 and abs(R/a+cut/2)<1e-13
                        references.append(reference[1])
                    errors.append(case['overlap_integral_max_abs_error'])
    assert total==4096 and explicit==8 and len(rows)==total
    return dict(all_trial_decisions=total,explicit_cases=explicit,explicit_spacetime_points=points,
                independent_expected_dust_radii=references,max_abs_overlap_volume_error=max(errors))


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Assertions required')
    print(json.dumps(run(),indent=2))
