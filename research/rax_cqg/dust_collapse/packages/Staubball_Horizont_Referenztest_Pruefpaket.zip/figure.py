"""Reference null diagram and recovery scatter summaries, read from the completed run."""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parent
r=json.loads((root/'results.json').read_text())['levels']
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(1,2,figsize=(7.7,2.85),gridspec_kw={'width_ratios':[1.05,1]})
fig.subplots_adjust(left=.105,right=.97,bottom=.22,top=.86,wspace=.47)
a,b=ax
t=np.linspace(-2.24,-1.38,180)
a.fill_betweenx(t,-t/2,1.45,color='#f5e1d5')
a.plot(-t/2,t,color='#743715',linewidth=1.6,label='Referenzgrenze')
for i,c in enumerate(r['1']['cases']['dust']):
    cut=c['eta']; chi=-cut/2
    v=np.linspace(cut-.18,cut+.18,20)
    a.plot(chi+v-cut,v,color='#0b6a69',linewidth=1.4)
    a.plot(chi-v+cut,v,color='#5d7084',linewidth=1.4,linestyle='--')
    a.scatter(c['detected_radius_quantiles'][1]/(cut**2/4),cut,s=28,facecolor='white',edgecolor='#142c34',zorder=4)
a.set(xlim=(.52,1.36),ylim=(-2.24,-1.38),xlabel='Mitbewegter Radius χ',ylabel='Konforme Zeit η')
a.set_aspect('equal',adjustable='box')
a.set_title('Lichtstrahlen im Staubinneren',fontsize=10,loc='left',weight='bold')
a.text(1.10,-1.51,'beide\nkonvergieren',color='#743715',ha='center',va='center',fontsize=7.7)
a.text(.555,-2.17,'auslaufend\nexpandierend',color='#264e54',fontsize=7.5)
b.axvspan(.90,1.10,color='#d7ece6')
b.axvline(1,color='#1f5961',linewidth=1)
names=[]
for row,(level,idx) in enumerate([(0,0),(0,1),(1,0),(1,1)]):
    c=r[str(level)]['cases']['dust'][idx];lo,med,hi=np.array(c['detected_radius_quantiles'])/c['target']
    color='#986345' if level==0 else '#09695e'
    b.plot([lo,hi],[row,row],color=color,linewidth=2.8,solid_capstyle='round')
    b.plot(med,row,'o',markersize=5,color=color)
    names.append(('grob' if level==0 else 'fein')+(', früh' if idx==0 else ', spät'))
b.set(yticks=range(4),yticklabels=names,xlim=(.79,1.21),ylim=(3.6,-.6),xlabel='Geschätzter Radius / Sollradius')
b.set_title('Ortsfehler bei Erkennung',fontsize=10,loc='left',weight='bold')
for chart in ax:
    chart.spines[['right','top']].set_visible(False)
    chart.tick_params(labelsize=8)
    chart.spines[['left','bottom']].set_color('#84939b')
fig.savefig(root/'figure.pdf')
