"""Run all frozen cases, store individual decisions and a compact summary."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.stats import beta
from geometry import CUTS,LEVELS,grid,windows,cells,verify_cells,explicit_window
from readout import classify

ROOT=Path(__file__).resolve().parent
PLAN="628369d35bb4bc0b013d03af11e81ceaf0272828d9acec865823073b8aa416bc"
REPS=512


def interval(n):
    tail=.05/(2*12)
    return [0. if n==0 else float(beta.ppf(tail,n,REPS-n+1)),1. if n==REPS else float(beta.isf(tail,n+1,REPS-n))]


def run_case(geo,level,cutno,writer,raw):
    dust=geo==0
    cut=CUTS[cutno]
    rho,d,w,step=LEVELS[level]
    s=grid(step)
    rng,explicit_rng=[np.random.Generator(np.random.PCG64(np.random.SeedSequence([2026110447,geo,level,cutno,tag]))) for tag in (0,1)]
    sample=[];mean=[];point_counts=[];exposure=[];errors=[]
    for lo,hi in windows(cut,d,w,dust):
        vol,mask=cells(lo,hi,cut,s,dust)
        errors.append(verify_cells(vol,mask,lo,hi,cut,s,dust))
        mean.append(((rho*vol)@mask).reshape(2,-1))
        sample.append((rng.poisson(rho*vol,(REPS,len(vol)))@mask).reshape(REPS,2,-1))
        n,counts=explicit_window(explicit_rng,lo,hi,cut,s,dust,rho)
        point_counts.append(n);exposure.append(counts)
    sample=np.stack(sample,axis=1)
    raw[f"g{geo}_level{level}_cut{cutno}"]=sample
    continuum=classify(mean,rho,w)
    explicit=classify(exposure,rho,w)
    truth=abs(cut)**3/8 if dust else None
    systematic=(continuum[0]=='DETECTED' and abs(continuum[1]/truth-1)<.03) if dust else continuum[0]=='CLEAR'
    decisions=[classify(counts,rho,w) for counts in sample]
    found=[r for status,r in decisions if status=='DETECTED']
    clear=sum(status=='CLEAR' for status,r in decisions)
    for i,(status,r) in enumerate(decisions):
        writer.writerow([('dust','flat')[geo],level,cut,i,status,'' if r is None else format(r,'.15g')])
    scores={"localized":sum(abs(r/truth-1)<=.1 for r in found)} if dust else {"clear":clear,"false_detect":len(found)}
    stats={key:dict(n=n,ci=interval(n)) for key,n in scores.items()}
    return dict(eta=cut,target=truth,expected_decision=continuum,systematic_pass=bool(systematic),
                overlap_integral_max_abs_error=max(errors),explicit_decision=explicit,
                explicit_points_in_slabs=point_counts,explicit_counts=np.asarray(exposure).tolist(),
                statuses=dict(detected=len(found),clear=clear,unresolved=REPS-clear-len(found)),
                rates=stats,detected_radius_quantiles=np.quantile(found,[.025,.5,.975]).tolist() if found else [],
                absolute_relative_error_quantiles=np.quantile(abs(np.array(found)/truth-1),[.5,.95,1]).tolist() if dust and found else [])


def main():
    if hashlib.sha256((ROOT/'design.json').read_bytes()).hexdigest()!=PLAN:raise ValueError("Plan hash mismatch")
    out={}
    raw={}
    with (ROOT/'individual.csv').open('w',newline='') as stream:
        writer=csv.writer(stream,lineterminator='\n')
        writer.writerow(['geometry','level','eta_cut','replicate','decision','estimated_radius'])
        for level in (0,1):
            cases={}
            pass_checks=[];fail_checks=[]
            for geo,label in enumerate(('dust','flat')):
                cases[label]=[]
                for j in (0,1):
                    case=run_case(geo,level,j,writer,raw)
                    cases[label].append(case)
                    pass_checks.append(case['systematic_pass']);fail_checks.append(not case['systematic_pass'])
                    for key,rate in case['rates'].items():
                        lo,hi=rate['ci']
                        pass_checks.append(hi<=.02 if key=='false_detect' else lo>=.95)
                        fail_checks.append(lo>.02 if key=='false_detect' else hi<.95)
            out[str(level)]=dict(cases=cases,decision="PASS" if all(pass_checks) else "FAIL" if any(fail_checks) else "UNRESOLVED")
    np.savez_compressed(ROOT/"marked_counts.npz",**raw)
    print(json.dumps(dict(design_sha256=PLAN,replicates=REPS,levels=out),indent=2))


if __name__=='__main__':
    if not __debug__:raise RuntimeError("Assertions required")
    main()
