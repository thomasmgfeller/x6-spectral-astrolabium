"""Certified gate map for the positive geometry measures in PR 211."""
import csv
import json
from fractions import Fraction
from itertools import product
from math import comb
from pathlib import Path

from flint import acb, arb, ctx
from path_certificate import ball, inner

ROOT = Path(__file__).resolve().parent
ctx.prec = 160
SIGNATURES = (0, 1, 2, 4, 7)


def endpoint_amplitudes():
    """Four tensor control points for the two bilinear branch vectors."""
    weights = {"symmetry": [], "orbit": []}
    with (ROOT / "coefficients.csv").open() as stream:
        for row in csv.DictReader(stream):
            entry = (int(row["k"]) - 1, SIGNATURES.index(int(row["signature"])),
                     int(row["h"]), int(row["residue"]), Fraction(row["weight"]))
            weights[row["measure"]].append(entry)
    totals, conditionals = [], []
    phase_g = acb(0, 4 * arb.pi() / 5).exp()
    phase_z = acb(0, -((48 / arb.pi()).root(4) - (24 / arb.pi()).root(4))).exp()
    for rows in weights.values():
        mass = [sum(w for j, _, _, _, w in rows if j == k) for k in range(3)]
        totals.append([w / sum(mass) for w in mass])
        v = [[acb(0) for _ in SIGNATURES] for _ in mass]
        for k, s, h, r, w in rows:
            v[k][s] += ball(w / mass[k]) * phase_z**h * phase_g**r
        conditionals.append(v)

    def branches(i, j):
        v = [[ball(totals[i][k]) * item for item in vector]
             for k, vector in enumerate(conditionals[j])]
        return v[0], [x + y for x, y in zip(v[1], v[2])]

    return [grid(2, lambda i, j: branches(i, j)[branch]) for branch in (0, 1)]


def grid(size, value):
    return [[value(i, j) for j in range(size)] for i in range(size)]


def combine(a, b, operation):
    return grid(len(a), lambda i, j: operation(a[i][j], b[i][j]))


def bernstein_product(a, b, operation):
    """Product of two square tensor Bernstein nets, with a paired coefficient rule."""
    n, m = len(a) - 1, len(b) - 1

    def factor(i, j):
        return ball(Fraction(comb(n, i) * comb(m, j), comb(n + m, i + j)))

    def coefficient(i, j):
        value = arb(0)
        for k in range(max(0, i - m), min(i, n) + 1):
            for l in range(max(0, j - m), min(j, n) + 1):
                value += (factor(k, i-k) * factor(l, j-l)
                          * operation(a[k][l], b[i-k][j-l]))
        return value

    return grid(n + m + 1, coefficient)


def split_curve(points, t):
    left, right = [], []
    while len(points) > 1:
        left.append(points[0])
        right.append(points[-1])
        points = [(1 - t) * a + t * b for a, b in zip(points, points[1:])]
    return left + [points[0]], [points[0]] + right[::-1]


def split_alpha(net, alpha):
    splits = [split_curve(column, alpha) for column in zip(*net)]
    return [list(zip(*(pair[side] for pair in splits))) for side in (0, 1)]


def certify_sign(net, sign, remaining=4):
    """Bernstein convex-hull bound, with alternating de Casteljau splits."""
    if all(sign * value > 0 for row in net for value in row):
        return True
    if remaining == 0:
        return False
    return all(certify_sign(list(zip(*half)), sign, remaining - 1)
               for half in split_alpha(net, arb(1) / 2))


def at(net, alpha, beta):
    controls = [split_curve(row, beta)[0][-1] for row in net]
    return split_curve(controls, alpha)[0][-1]


def run():
    u, v = endpoint_amplitudes()
    real_inner = lambda x, y: inner(x, y).real
    imag_inner = lambda x, y: inner(x, y).imag
    square = lambda a: bernstein_product(a, a, lambda x, y: x*y)
    a = bernstein_product(u, u, real_inner)
    b = bernstein_product(v, v, real_inner)
    real_h = bernstein_product(u, v, real_inner)
    imag_h = bernstein_product(u, v, imag_inner)
    trace = combine(a, b, lambda x, y: x+y)
    concentration = combine(a, b, lambda x, y: y-99*x)
    interference = combine(square(trace), combine(square(real_h), square(imag_h), lambda x,y: x+y),
                           lambda trace2, h2: trace2-1764*h2)
    deriv = [[4*(hi-lo) for lo,hi in zip(row1,row2)]
             for row1,row2 in zip(interference, interference[1:])]
    signs = {
        "trace_positive": certify_sign(trace, 1),
        "q_above_99_percent": certify_sign(concentration, 1),
        "residual_positive_at_alpha_zero": all(x > 0 for x in interference[0]),
        "residual_negative_at_alpha_one": all(x < 0 for x in interference[-1]),
        "residual_strictly_decreasing_in_alpha": certify_sign(deriv, -1)
    }
    if not all(signs.values()):
        raise ValueError("Missing whole-domain certificate")

    published = json.loads((ROOT / "endpoint_results.json").read_text())["cells"]
    for i,j in product((0,1), repeat=2):
        x,y = arb(i),arb(j)
        denom = at(trace,x,y)
        q = at(b,x,y)/denom
        epsilon = 2*(at(real_h,x,y)**2 + at(imag_h,x,y)**2).sqrt()/denom
        for key, result in (("q23", q), ("epsilon", epsilon)):
            lo, hi = map(lambda s: ball(Fraction(s)), published[f"{i}{j}"][key])
            if not (lo <= result <= hi):
                raise ValueError("Published corner differs")

    # Independent direct complex-vector evaluation throughout the square.
    for i,j in product(range(5), repeat=2):
        alpha,beta = arb(i)/4,arb(j)/4
        def interpolate(net):
            return [sum((p*q*net[s][t][h] for s,p in enumerate((1-alpha,alpha))
                         for t,q in enumerate((1-beta,beta))), acb(0)) for h in range(5)]
        left,right = interpolate(u),interpolate(v)
        h = inner(left,right)
        norm = inner(left,left).real + inner(right,right).real
        direct = norm**2 - 1764*(h.real**2+h.imag**2)
        if not direct.overlaps(at(interference,alpha,beta)):
            raise ValueError("Direct evaluation differs")

    # Certify full strips, including every beta, at stated sufficient bounds.
    left = split_alpha(interference,ball(Fraction(212,1000)))[0]
    right = split_alpha(interference,ball(Fraction(239,1000)))[1]
    if not (certify_sign(left,1) and certify_sign(right,-1)):
        raise ValueError("Strip test failed")
    brackets = []
    for percent in range(101):
        beta = arb(percent)/100
        controls = [split_curve(row,beta)[0][-1] for row in interference]
        lo, hi = Fraction(0), Fraction(1)
        for _ in range(30):
            mid = (lo+hi)/2
            residual = split_curve(controls,ball(mid))[0][-1]
            if residual > 0:
                lo = mid
            elif residual < 0:
                hi = mid
            else:
                raise ValueError("Bisection unresolved")
        brackets.append(dict(beta_percent=percent, alpha_lo=str(lo), alpha_hi=str(hi)))
    return dict(precision_bits=ctx.prec, whole_square=signs, published_corners=4,
                direct_evaluations=25, pass_through="212/1000", fail_from="239/1000",
                boundary=brackets)


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
