"""Certify the whole globally normalized measure path in Bernstein coordinates."""
from fractions import Fraction as F
import csv,json,math
from pathlib import Path
from flint import arb,acb,ctx,__version__
ctx.prec=160
HERE=Path(__file__).resolve().parent
def ensure(ok,why):
    if not ok:raise ValueError(why)

def ball(x):
    x=F(x);return arb(x.numerator)/x.denominator

def inner(v,w):
    return sum((a*b.conjugate() for a,b in zip(v,w)),acb(0))

def endpoints():
    coeff={name:{} for name in ['symmetry','orbit']}
    with (HERE/'coefficients.csv').open() as f:
        for r in csv.DictReader(f):coeff[r['measure']][tuple(int(r[key]) for key in ['k','signature','h','residue'])]=F(r['weight'])
    pi=arb.pi();g=acb(0,4*pi/5).exp()
    z=acb(0,-((48/pi).root(4)-(24/pi).root(4))).exp()
    result=[]
    for table in coeff.values():
        v={k:[acb(0) for _ in range(5)] for k in (1,2,3)}
        mass=sum(table.values())
        for (k,s,h,r),w in table.items():
            v[k][(0,1,2,4,7).index(s)]+=ball(w/mass)*z**h*g**r
        result.append((v[1],[x+y for x,y in zip(v[2],v[3])]))
    return result

def product(a,b):
    n=len(a)-1;m=len(b)-1
    return [sum((ball(F(math.comb(n,i)*math.comb(m,k-i),math.comb(n+m,k)))*a[i]*b[k-i]
                 for i in range(max(0,k-m),min(k,n)+1)),arb(0)) for k in range(n+m+1)]

def coeffs():
    (u,v),(w,x)=endpoints()
    a=[inner(u,u).real,inner(u,w).real,inner(w,w).real]
    b=[inner(v,v).real,inner(v,x).real,inner(x,x).real]
    cross=[inner(u,v),(inner(u,x)+inner(w,v))/2,inner(w,x)]
    s=[i+j for i,j in zip(a,b)]
    h=[z.real for z in cross];t=[z.imag for z in cross]
    return s,[j-4*i for i,j in zip(a,b)],[j-99*i for i,j in zip(a,b)],[j-1764*(a+b) for j,a,b in zip(product(s,s),product(h,h),product(t,t))]

def half(c):
    left=[c[0]];right=[c[-1]]
    while len(c)>1:
        c=[(a+b)/2 for a,b in zip(c,c[1:])];left.append(c[0]);right.append(c[-1])
    return left,list(reversed(right))

def split_sign(c,key='',depth=22):
    if all(x>0 for x in c):return [(key,'positive',None)]
    if all(x<0 for x in c):return [(key,'negative',None)]
    if len(key)>=depth:
        derivative=[y-x for x,y in zip(c,c[1:])]
        if c[0]>0 and c[-1]<0 and all(x<0 for x in derivative):mark='one_downward_crossing'
        elif c[0]<0 and c[-1]>0 and all(x>0 for x in derivative):mark='one_upward_crossing'
        else:mark='unresolved'
        return [(key,mark,None)]
    l,r=half(c)
    return split_sign(l,key+'0',depth)+split_sign(r,key+'1',depth)

def interval(key):
    a=int(key or '0',2); n=2**len(key)
    return F(a,n),F(a+1,n)

def raw(t):
    (u,v),(w,x)=endpoints()
    f=ball(t); a=[(1-f)*i+f*j for i,j in zip(u,w)];b=[(1-f)*i+f*j for i,j in zip(v,x)]
    n=inner(a,a).real;m=inner(b,b).real;h=inner(a,b)
    return m/(n+m),2*abs(h)/(n+m)

def main():
    s,d,d99,f=coeffs()
    data={}
    for name,coeff in [('positive_denominator',s),('concentration',d),('descriptive_q_above_99pct',d99),('interference',f)]:
        pieces=split_sign(coeff)
        ensure(sum(hi-lo for lo,hi in (interval(k) for k,_,_ in pieces))==1,'domain cover')
        data[name]=[dict(path=k,sign=mark) for k,mark,_ in pieces]
    ensure(all(x['sign']=='positive' for x in data['positive_denominator']),'denominator sign')
    ensure(all(x['sign']=='positive' for x in data['concentration']),'concentration gate')
    switches=[]
    for x in data['interference']:
        if 'crossing' in x['sign']:
            l,h=interval(x['path']);switches.append(dict(direction=x['sign'],lower=str(l),upper=str(h),
                                     decimal_bracket=[float(l),float(h)],q_and_eps_at_edges=[
                                         [str(v) for v in raw(t)] for t in (l,h)]))
    ensure(len(switches)==1 and switches[0]['direction']=='one_downward_crossing','single gate transition')
    ensure(all(x['sign']!='unresolved' for x in data['interference']),'incomplete path certificate')
    old=json.loads((HERE/'endpoint_results.json').read_text())
    for t,key in [(0,'00'),(1,'11')]:
        for current,name in zip(raw(t),('q23','epsilon')):
            lo,hi=map(ball,old['cells'][key][name])
            ensure(current>=lo and current<=hi,'old arithmetic disagreement')
    return dict(precision_bits=ctx.prec,software=__version__,sign_certificates=data,interference_switches=switches,
                samples=[dict(t=str(t),q23=str(raw(t)[0]),epsilon=str(raw(t)[1])) for t in map(F,('0','1/4','1/2','3/4','1'))])
if __name__=='__main__':print(json.dumps(main(),indent=2))
