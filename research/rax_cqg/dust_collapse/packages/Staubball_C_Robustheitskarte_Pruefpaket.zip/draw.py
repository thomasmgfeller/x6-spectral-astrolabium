"""Draw an A4 summary from the certified boundary brackets."""
import json
from fractions import Fraction
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

root = Path(__file__).resolve().parent
data = json.loads((root / "certificate.json").read_text())
x = [r["beta_percent"] for r in data["boundary"]]
y = [50 * float(Fraction(r["alpha_lo"]) + Fraction(r["alpha_hi"])) for r in data["boundary"]]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "pdf.fonttype": 42})
fig = plt.figure(figsize=(8.27, 11.69), facecolor="white")
ink, muted, teal = "#182a37", "#455e69", "#09675f"
def text(x, y, s, size=11, **kw):
    fig.text(x, y, s, size=size, color=kw.pop("color",ink), va="top", **kw)

text(.09,.947,"ASTROLABIUM    /    ENDLICHE KAUSALORDNUNGEN",10,color=teal,weight="bold")
text(.09,.908,"Wann kippt die Prognose in C?",26,weight="bold")
text(.09,.851,"Zwei unabhängig veränderte Gewichte zeigen, bei welcher Mischung die\nInterferenz die Grenze 1/21 überschreitet. Das Zweiggewicht für eine späte\nSchichtbreite von zwei oder drei bleibt im gesamten Quadrat über 99 %.",11.8,linespacing=1.5)
text(.09,.755,"ZWEIDIMENSIONALE ROBUSTHEITSKARTE",10,color=teal,weight="bold")
for pos, limits, title in [([.11,.45,.35,.235],(0,100),"Gesamter Bereich"),([.59,.45,.335,.235],(20,25),"Ausschnitt der Grenzkurve")]:
    ax=fig.add_axes(pos)
    ax.fill_between(x,limits[0],y,color="#cce9e1")
    ax.fill_between(x,y,limits[1],color="#f7e1d9")
    ax.plot(x,y,color=ink,lw=2)
    ax.set(xlim=(0,100),ylim=limits,xticks=[0,25,50,75,100],yticks=([0,25,50,75,100] if limits[1]==100 else [20,21,22,23,24,25]))
    ax.set_title(title,fontsize=12,loc="left",weight="bold",pad=10,color=ink)
    ax.set_xlabel("Verteilung innerhalb der Klassen β (%)",fontsize=8.6,labelpad=5)
    ax.set_ylabel("Gesamtgewichte der Klassen α (%)",fontsize=8.6,labelpad=4)
    ax.tick_params(labelsize=8,length=3,color=muted)
    ax.spines[["right","top"]].set_visible(False)
    for s in ax.spines.values():s.set_color(muted)
    if limits[1]==100:
        ax.text(50,65,"Gate scheitert",ha="center",color="#743329",weight="bold")
        ax.text(50,8,"Gate besteht",ha="center",color=teal,weight="bold")
    else:
        ax.scatter([0,50,100],[y[0],y[50],y[100]],s=17,color=ink,clip_on=False,zorder=3)
text(.09,.389,"Wie die Achsen zu lesen sind",14,weight="bold")
text(.09,.358,"0 % steht jeweils für die ursprüngliche Symmetriegewichtung, 100 % für den\nentsprechenden Anteil aus der Gleichzählung der 840 Geometrien. α mischt die\nGesamtgewichte der Breitenklassen, β die Gewichte der Geometrien innerhalb\njeder Klasse. Für jedes β gibt es genau eine Grenze. Auf der Grenze besteht das Gate.",10.5,linespacing=1.55)
text(.09,.242,"Was die Rechnung absichert",14,weight="bold")
text(.09,.211,"Für jedes β besteht das Gate bis mindestens α = 21,2 %. Ab α = 23,9 % scheitert es\nfür jedes β. Die Kurve verbindet 101 einzeln eingeschlossene Grenzpunkte. Die\nAussagen über die ganze Fläche folgen aus Bernstein-Koeffizienten in 160-Bit-\nIntervallarithmetik. Alle vier publizierten Eckwerte wurden reproduziert.",10.5,linespacing=1.55)
text(.09,.094,"Modellgrenze",9,color=teal,weight="bold")
text(.09,.073,"Feste Randfamilie C und feste Dynamik aus PR 211. Die Achsen sind diagnostische Eingriffe.\nEin physikalisches Fortsetzungsmass und eine kalibrierte Einzelordnungsobservable bleiben offen.",8.8,color=muted,linespacing=1.4)
fig.savefig(root/"Staubball_C_Robustheitskarte.pdf")
