# Zweidimensionale Robustheitskarte für Randfamilie C

Die drei Eingaben coefficients.csv, endpoint_results.json und path_certificate.py stammen bytegleich aus dem Mass-Gate-Paket von [PR 211](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/211). Die Nachanalyse verwendet dessen ursprüngliche Präparation und Dynamik einschließlich g=4π/5. Der grosse Enumerationslauf ist im Referenzarchiv reproduzierbar. Die Karte benötigt nur die Koeffiziententabellen. Die vier Ecken waren bekannt, bevor die Fläche berechnet wurde.

## Definition

Für jede Breitenklasse k und Geometrie G darin schreiben wir das global normierte positive Amplitudenmass als M(k) p(G|k). Index 0 bezeichnet die Symmetriegewichtung, Index 1 die Gleichzählung unmarkierter Geometrien. Im Quadrat 0 ≤ α, β ≤ 1 verwenden wir

    Mα(k) = (1−α) M0(k) + α M1(k)
    pβ(G|k) = (1−β) p0(G|k) + β p1(G|k)
    μαβ(G) = Mα(k) pβ(G|k)

Wir mischen positive Gewichte vor der Amplitudensumme. Der diagonal parametrisierte Produktansatz ist im Allgemeinen ein anderer Weg als der in PR 211 geprüfte lineare Weg durch die Gesamtmasse. Die Konstruktion verwendet k zur Diagnose der Abhängigkeit und bestimmt kein physikalisches Fortsetzungsmass.

## Beweis und Kontrolle

Mit u=v1, v=v2+v3, A=||u||², B=||v||², H=<u,v> ist T=A+B die Normierung. Die Gate-Regel verlangt q=B/T ≥ 4/5 und ε=2|H|/T ≤ 1/21. Bei positiver Normierung ist die Interferenzregel gleichbedeutend mit R=T²−1764|H|² ≥ 0. Die Zweigvektoren sind bilinear, R hat je Achse Grad höchstens vier. Der Code multipliziert die Tensor-Bernstein-Koeffizienten exakt kombinatorisch mit einschliessender 160-Bit-Arithmetik. Gleiches Vorzeichen aller Koeffizienten auf einem Rechteck zertifiziert das Vorzeichen des Polynoms dort. Falls nötig wird das Rechteck in Teilbereiche zerlegt.

Positive T und B−99A, strikte Negativität von ∂R/∂α und entgegengesetzte Vorzeichen auf den beiden α-Rändern gelten für das ganze Quadrat. Daher existiert zu jedem β genau ein Wechsel und der Randpunkt gehört zum freigegebenen Bereich. Zusätzliche Vorzeichentests gelten für die beiden vollständigen Streifen α ≤ 0,212 und α ≥ 0,239. Diese beiden Schranken sind hinreichend. 101 Grenzpunkte sind auf eine Intervallbreite von 2^-30 eingeschlossen. Die Verbindungslinie im Bild ist interpoliert. Unabhängig vom Tensorprodukt wurden die vier Referenzecken mit PR 211 verglichen und die direkte Auswertung der bilinearen Zweigvektoren an 25 Punkten geprüft. Die gleichen Eingangsdaten werden jeweils wiederverwendet.

## Reproduktion

Getestet mit Python 3.12 und python-flint 0.9.0. Für die optionale PDF-Ausgabe wurde Matplotlib 3.10.8 verwendet.

    sha256sum -c SHA256SUMS
    python3 -m venv .venv
    .venv/bin/python -m pip install python-flint==0.9.0
    .venv/bin/python map_gate.py > replay.json
    cmp certificate.json replay.json

## Offene Tests

Ein klassisches Wachstumsmodell liefert einen separat zu begründenden positiven Masskandidaten. Festzulegen sind frühe Konditionierung, Summation über kompatible Geburtsfolgen, die Stoppregel über verschiedene Endgrössen und die Abbildung klassischer Gewichte auf die Amplitudensumme. Die ursprüngliche Markierung und Phasenregel bleiben zunächst fix. Die Parameterwahl darf keine spätere Zielbreite oder die vorliegende Karte zur Anpassung verwenden.

Ein weiterer Randbreitentest bei fester Schichtenstruktur prüft Transfer. Für eine physikalische Skalierung braucht es eine festgehaltene makroskopische Region, ein konsistentes beobachtbares Volumenfenster und eine Folge zunehmender Auflösungen. Auch eine stabile Ensemblekarte würde noch keine Fehlergrenze an einzelnen Ordnungen liefern.
