"""Software controls and source-anchored readiness audit. No new physical histories."""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

from gate import ROOT,VERSION,digest,run,require


def design():
    return dict(times=[-2,-1,0,1,2],physical_time_unit='synthetic clock unit',region='same unit cell',
                clock='synthetic dust stamps',early_input='fixed unit initial volume and contraction',
                early_volume_scale='Vearly=1, all readings in this unit',
                observable='five simultaneous certified synthetic volumes',
                dynamics='controlled signs per history',measure='equal base amplitude per prototype',
                null='all signs plus in the same fixed basis and with the same support',
                records={'basis':'orthonormal','dimension':3},support_policy='three B and three N prototypes',
                joint_error_budget='exact rational fixture unless explicitly widened')


def fixture():
    d=design()
    sha=digest(d)
    levels=[]
    for i,sub in enumerate((1,2)):
        rows=[]
        for kind,seq,channel in [('B',(1,'4/5','3/5','4/5',1),0),('N',(1,'4/5','3/5','2/5','1/5'),1)]:
            for j in range(3):
                for n in range(sub):
                    row=dict(id=f'{kind}-{j}-{n}',volumes=[[s,s] for s in seq])
                    for tag,sign in [('dynamic',-1 if kind=='N' and j==2 else 1),('null',1)]:
                        vector=[[0,0] for _ in range(3)]
                        vector[channel]=[str(F(sign,sub)),0]
                        row[tag]=dict(a=vector,radius=0)
                    rows.append(row)
        levels.append(dict(ell=('1','1/2')[i],design_sha256=sha,
                           inventory_sha256=digest(sorted(r['id'] for r in rows)),histories=rows))
    return dict(scope='synthetic',contract_sha256=VERSION,design=d,design_sha256=sha,levels=levels)


def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,indent=2,default=str)+'\n')


def controls():
    base=fixture()
    write('example.json',base)
    summary={}
    def test(name,case,expected):
        result=run(case)
        require(result['numeric_status']==expected,(name,result['numeric_status']))
        summary[name]=dict(numeric=result['numeric_status'],physical=result['physical_status'],
                           reason=result.get('reasons',result.get('reason','')))
        return result
    positive=test('resolvable_dynamic_bounce',base,'PASS')
    assert all(l['dynamic']['q']['B']==(F(9,10),F(9,10)) and l['null']['q']['B']==(F(1,2),F(1,2)) for l in positive['levels'])
    case=deepcopy(base)
    for level in case['levels']:
        for r in level['histories']:
            if r['id'].split('-')[1]=='2':
                for z in r['dynamic']['a']:z[0]=str(-F(z[0]))
    test('sustained_contraction_dominates',case,'FAIL')
    case=deepcopy(base)
    for level in case['levels']:
        for row in level['histories']:
            row['dynamic']=deepcopy(row['null'])
    test('no_dominant_branch',case,'HOLD')
    case=deepcopy(base)
    for level in case['levels']:
        for row in level['histories']:
            row['null']=deepcopy(row['dynamic'])
            for z in row['dynamic']['a']: z[0],z[1]=str(-F(z[1])),z[0]
    response=test('only_a_common_phase_over_the_null',case,'HOLD')
    require('dynamic excess over null unestablished' in response['reasons'],'kinematic gate unchecked')
    case=deepcopy(base)
    for level in case['levels']:
        for r in level['histories']:
            if r['id'].startswith('N'):
                for tag in ('dynamic','null'):
                    a=r[tag]['a'];a[0],a[1]=a[1],a[0]
    test('B_and_N_share_record',case,'HOLD')
    case=deepcopy(base)
    for level in case['levels']:
        for r in level['histories']:
            if r['id'].startswith('N'):r['volumes']=deepcopy(level['histories'][0]['volumes'])
    test('boundary_forces_dip',case,'HOLD')
    case=deepcopy(base)
    for level in case['levels']:
        for r in level['histories']:r['volumes'][1:4]=[None]*3
    test('early_and_terminal_data_only',case,'HOLD')
    case=deepcopy(base)
    for level in case['levels']:
        for r in level['histories']:
            if r['id'].startswith('B-0'):
                r['volumes'][2]=['1/5','1']
                for tag in ('dynamic','null'):
                    a=r[tag]['a'];a[0],a[2]=a[2],a[0]
    test('uncertain_minimum_is_retained',case,'HOLD')
    case=deepcopy(base)
    for level in case['levels']:
        for i,sign in enumerate((1,-1)):
            row=dict(id=f'ambiguous-{i}',volumes=None)
            for tag in ('dynamic','null'):row[tag]=dict(a=[[0,0],[0,0],[sign,0]],radius=0)
            level['histories'].append(row)
        level['inventory_sha256']=digest(sorted(r['id'] for r in level['histories']))
    guarded=test('unresolved_cancellation_before_binary_split',case,'HOLD')
    require(guarded['levels'][0]['dynamic']['q']['U'][1]==0,'coherent U cancellation missing')
    case=deepcopy(base)
    for level in case['levels']:
        row=dict(id='ambiguous-negligible',volumes=None)
        for tag in ('dynamic','null'):row[tag]=dict(a=[[0,0],[0,0],['1/10000',0]],radius=0)
        level['histories'].append(row)
        level['inventory_sha256']=digest(sorted(r['id'] for r in level['histories']))
    test('certified_tiny_unresolved_history',case,'PASS')
    case=deepcopy(base)
    for r in case['levels'][1]['histories']:
        if r['id'].startswith('N-2'):r['dynamic']['a'][1]=['-2/5','3/10']
    test('two_level_drift',case,'HOLD')
    case=deepcopy(base)
    for r in case['levels'][0]['histories']:r['dynamic']['radius']='1'
    test('uncertain_amplitude',case,'HOLD')
    case=deepcopy(base)
    for r in case['levels'][0]['histories']:r['dynamic']['a']=[[0,0]]*3
    test('zero_norm',case,'HOLD')
    case=deepcopy(base);case['levels'][1]['ell']='1'
    test('identical_resolution',case,'INVALID')
    case=deepcopy(base);case['levels'][0]['histories'].pop()
    test('missing_listed_history',case,'INVALID')
    case=deepcopy(base);case['design']['times'][3]='1/2'
    test('altered_common_design',case,'INVALID')
    case=deepcopy(base);case['scope']='candidate'
    reviewed=test('numeric_pass_cannot_self_certify_physics',case,'PASS')
    require(reviewed['physical_status']=='HOLD_PENDING_EVIDENCE_REVIEW','type boundary')
    return summary


def present_evidence():
    folder=ROOT/'evidence'
    for item in json.loads((folder/'sources.json').read_text()):
        require(hashlib.sha256((folder/item['file']).read_bytes()).hexdigest()==item['sha256'],item['file'])
    catalogue=json.loads((folder/'catalogue.json').read_text())
    terminal=json.loads((folder/'terminal.json').read_text())
    geo=json.loads((folder/'geometric.json').read_text())
    classical=json.loads((folder/'classical.json').read_text())
    sums={key:sum(row['orbits'].get(key,0) for row in catalogue['catalogue']) for key in ('strict','plateau')}
    require(sums=={'strict':793,'plateau':47},'catalogue changed')
    require(terminal['reference_geometry']=='HOLD_NO_ORBIT_WEIGHTS','orbit status changed')
    require(geo['geometry']['dust']['stratum_C_hits']==[0,0,0],'pilot changed')
    require(all(s['1']['decision']=='PASS' for s in classical['results'].values()),'classical readout changed')
    return dict(candidate='archived family C',physical_status='HOLD',numerical_mass_for_B=None,
                rank_minima=sums,dust_pilot_hits=[0,0,0],fine_classical_readout='PASS on prescribed backgrounds',
                missing=['independently calibrated joint five-time physical volumes in the same dynamic histories',
                         'four-dimensional matched dynamic refinements and justified histories/weights with controlled uncertainty',
                         'kinematically open support and same-support comparator for this proposed physical event'],
                regularity='outside the scope of this gate')


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Assertions required')
    write('controls.json',controls())
    write('current_status.json',present_evidence())
