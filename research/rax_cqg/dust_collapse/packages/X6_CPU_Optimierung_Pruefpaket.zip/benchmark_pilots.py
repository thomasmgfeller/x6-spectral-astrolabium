"""Re-run only the published endpoint cost samples and low-density controls."""
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import tempfile
import time
import zipfile


def check(ok, what):
    if not ok:
        raise ValueError(what)


def run(repo, temp, repeats):
    import numpy as np
    import scipy
    archive = repo/'research/rax_cqg/dust_collapse/packages/CST_Staubkollaps_Geglaetteter_Massestrom_Pruefpaket.zip'
    check(hashlib.sha256(archive.read_bytes()).hexdigest() ==
          '293abfb2a6854b1a33982d6accc5354838b0573fc2958b9e7212599ba78fe585', 'archive hash')
    with zipfile.ZipFile(archive) as src:
        src.extractall(temp)
    parallel_source = temp/'whole_grid_parallel.cpp'
    with Path(__file__).with_name('parallel_endpoints.patch').open('rb') as patch:
        subprocess.run(['patch', '--batch', '-o', str(parallel_source), str(temp/'whole_grid.cpp')],
                       stdin=patch, stdout=subprocess.DEVNULL, check=True)
    for name in ('reference', 'parallel'):
        target = temp/name
        target.mkdir()
        source = temp/'whole_grid.cpp' if name == 'reference' else parallel_source
        omp = '-fopenmp-simd' if name == 'reference' else '-fopenmp'
        subprocess.run(['g++','-O3','-march=native',omp,'-ffp-contract=off','-std=c++17','-shared','-fPIC',
                        str(source),'-o',str(target/'whole_grid_native.so')],check=True)
    sys.path.insert(0, str(temp))
    os.chdir(temp)
    from full_run import load
    from halo_reference import halo_cloud
    from cap_run import cfg,mu,s
    from weights import layer_table
    kernels = {}
    for name in ('reference','parallel'):
        os.chdir(temp/name)
        kernels[name] = load()
    os.chdir(temp)
    def raw(kernel, args, table):
        sums = np.zeros(2)
        kernel(*args,table,len(table),sums)
        return sums
    def evaluate(args, eff):
        lam = args[7]
        w,_ = layer_table(eff/lam)
        ref, par = [raw(k, args, w) for k in kernels.values()]
        check(ref.tobytes() == par.tobytes(), 'low-density kernel parity')
        return -2*(eff/lam)**2*ref[0]/math.sqrt(6*eff)
    with open('halo_checks.csv') as f:
        controls = list(csv.DictReader(f))
    for row in controls:
        j, i, p = int(row['j']), int(row['run']), float(row['p'])
        args = halo_cloud(20261102891+j,1400,i,*cfg['windows'][j])
        check(abs(evaluate(args, p*1400)-float(row['nonperiodic_oracle']))<1e-10,'oracle')
    with open('high_cost.csv') as f:
        archived = list(csv.DictReader(f))
    results = {}
    for row in archived:
        j, lam, seed = int(row['j']), int(row['lam']), int(row['seed'])
        args = list(halo_cloud(seed, lam, j, *cfg['windows'][j]))
        n, t, _, _, sigma, *_ = args
        idx = np.flatnonzero((t >= s) & (sigma > 0))
        check(n == int(row['halo_points']) and len(idx) == int(row['marked_future']), 'archive counts')
        rng = np.random.default_rng([seed,j,1])
        selected = np.sort(np.concatenate([rng.choice(a,4,replace=False) for a in np.array_split(idx,8)]))
        check(len(selected) == int(row['tested']), 'sample size')
        mark = np.zeros_like(sigma)
        mark[selected] = sigma[selected]
        args[4] = mark
        table,_ = layer_table(mu/lam)
        elapsed = {name: [] for name in kernels}
        for rep in range(repeats):
            results_pair = {}
            for name in (list(kernels) if rep % 2 == 0 else reversed(kernels)):
                start = time.perf_counter()
                results_pair[name] = raw(kernels[name], args, table)
                elapsed[name].append(time.perf_counter()-start)
            check(results_pair['reference'].tobytes()==results_pair['parallel'].tobytes(), 'partial sum parity')
            partial = -2*(mu/lam)**2*results_pair['reference'][0]/math.sqrt(6*mu)
            check(abs(partial-float(row['partial_raw'])) < 1e-12, 'archived partial sum')
        med = {key:statistics.median(val) for key,val in elapsed.items()}
        results['AB'[j]] = dict(n=n,marked_total=len(idx),tested=len(selected),partial_raw=partial,
                                  seconds=elapsed,median_seconds=med,speedup=med['reference']/med['parallel'])
    return dict(windows=results, reference_threads=1, parallel_threads=int(os.environ['OMP_NUM_THREADS']),
                low_density_controls=len(controls), python=platform.python_version(),
                numpy=np.__version__,scipy=scipy.__version__, compiler=subprocess.check_output(
                    ['g++','-dumpfullversion'],text=True).strip())


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo', type=Path)
    p.add_argument('--repeats', default=3, type=int)
    a = p.parse_args()
    check(a.repeats>0,'positive repeats')
    os.environ.update(OMP_NUM_THREADS='4', OMP_DYNAMIC='FALSE', OPENBLAS_NUM_THREADS='1')
    with tempfile.TemporaryDirectory() as t:
        original = Path.cwd()
        try:
            summary = run(a.repo.resolve(), Path(t), a.repeats)
        finally:
            os.chdir(original)
        print(json.dumps(summary,indent=2))
