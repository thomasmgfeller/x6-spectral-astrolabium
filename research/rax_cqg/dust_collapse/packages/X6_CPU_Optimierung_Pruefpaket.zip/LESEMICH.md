# Drei CPU-Vergleiche für Staubball und Eigenzeit

4. November 2026 · X6 Spectral Astrolabium · lokale Vergleichsrechnung

## Reproduktion

Vorausgesetzt werden eine lokale Arbeitskopie von thomasmgfeller/x6-spectral-astrolabium und ein Linux-Rechner mit Python 3.12, NumPy, SciPy, GNU patch und g++ mit OpenMP. Alle Eingaben kommen aus dem öffentlichen Repository. Der geprüfte Stand ist Commit `58de0da37790231a96623fa93a0590271ef38d80`. Beide Skripte prüfen die verwendeten Eingabedateien per SHA-256. Die Tests laufen in temporären Verzeichnissen. Im Pilotskript bedeutet ein fehlerfreier Durchlauf, dass alle im Folgenden beschriebenen Vergleiche bestanden wurden.

Im entpackten Benchmark-Verzeichnis ausführen. Den Beispielpfad durch die lokale Arbeitskopie ersetzen.

```sh
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
python x6_cpu_benchmark.py /pfad/zum/x6-spectral-astrolabium --part dust --repeats 3
python x6_cpu_benchmark.py /pfad/zum/x6-spectral-astrolabium --part proper --repeats 7
python benchmark_pilots.py /pfad/zum/x6-spectral-astrolabium --repeats 3
```

Die JSON-Dateien enthalten die hier gemessenen Einzelzeiten in Sekunden, ihren Median und das Verhältnis der beiden Mediane. Gemessen wurde verstrichene Zeit mit `time.perf_counter()` auf einer x86-64-VM mit AMD EPYC 9V74, Python 3.12.14 und NumPy 2.3.5. Die Reihenfolge wechselt zwischen Referenz und Kandidat mit jeder Wiederholung. Die Werte beschreiben diesen Rechner und diese Eingaben.

## Was verglichen wurde

**Endliche Staubhistorien.** Das publizierte `enumerate_records.py` zählt die beiden Familien mit 588 und 6 734 Historien vollständig auf. Seine erste Rechnung des ganzzahligen Gravitationszählers Q verwendet Python-Mengen. Der Prototyp behält diese Rechnung bei. Für die zweite Rechnung konstruiert er Vergangenheit und Zukunft nochmals aus den Kanten und zählt pro Intervall die gemeinsamen gesetzten Bits. Die von `lift` gelieferte topologische Sortierung ist eine Voraussetzung. Die Gegenprüfung vergleicht beide Werte für jede Historie. Nach jedem Durchlauf müssen `history_records.csv`, `coefficients.csv` und `inventory.json` bytegleich zum veröffentlichten Archiv sein. Die Zeit enthält die gesamte Aufzählung einschliesslich des Schreibens dieser Dateien. Spätere Auswertungen und Zertifikate sind eigene Schritte.

**Eigenzeit im flachen 1+1-Referenzmodell.** Beide Varianten lesen dieselben 24 Eingabepakete aus den bestehenden Zufallsströmen für je 258 Ereignisse. Verwendet wurden die Indizes 0 bis 11 der uniformen Kalibrierung und des publizierten Gittertests. Die Wahl dient dem Laufzeitvergleich. Sie liefert keine neue unabhängige Bewertung des Schätzers. Für die Transitivitätsprüfung muss jede Zukunft eines Nachfolgers von i in der Zukunft von i enthalten sein. Die bitweise Vereinigung der Nachfolgerzeilen muss deshalb eine Teilmenge der Zeile von i sein. Mit NumPy lässt sich das auf gepackten Bytes prüfen. Quelle, Schätzer, Merkmale und Kettenberechnung bleiben dieselben. Der Timer umfasst die Merkmalsextraktion einschließlich Eingabevalidierung, ohne Erzeugung, Fit oder Bootstrap. Verglichen wurden die sechs Ausgaben N, m, R, H, K und ell sowie Annahme oder Ablehnung aller 512 binären Dreipunktmatrizen mit festem geordnetem Markierungspaar (0,1). Die Optimierung legt weiterhin eine dichte Matrix an.

**Massestrom-Piloten.** Das Paket von Issue 192 enthält einen eigenen Laufzeitversuch mit Startwert 20261102911. Pro Zeitfenster werden dieselben 32 markierten Endpunkte wie im veröffentlichten Versuch gewählt, vier aus jedem von acht Zeitbereichen. Für jeden Endpunkt werden alle erforderlichen Vorfahren berücksichtigt. Der Prototyp teilt die Endpunkte dynamisch auf vier OpenMP-Threads auf. Ein Thread bearbeitet jeweils einen ganzen Endpunkt. Alle Beiträge werden danach in der ursprünglichen Reihenfolge addiert. Das Gitter wird einmal pro Kernelaufruf aufgebaut. Die gemessene Zeit umfasst Gitteraufbau, Endpunktarbeit und Addition. Erzeugung der Punktwolke und Kompilieren liegen ausserhalb der Messung.

Die geglättete und die lokale Rohsumme des parallelen Kerns müssen im selben Prozess bitgleich zur seriellen Referenz sein. Zusätzlich prüft das Skript die veröffentlichten geglätteten Teilsummen (absolute Toleranz 1e-12), die Ereigniszahlen sowie acht kleine Kontrollen gegen die direkte nichtperiodische Referenz (absolute Toleranz 1e-10). Die Messungen beziehen sich auf die Kostenstichprobe. Die beiden vollständigen Pilotläufe mit den Startwerten 20261102921 und 20261102922 wurden hier nicht ausgeführt. Die Zeiten erlauben keine Aussage zur Massengenauigkeit oder zu einer Reduktion der CPU-Stunden.

[Referenz-Commit](https://github.com/thomasmgfeller/x6-spectral-astrolabium/commit/58de0da37790231a96623fa93a0590271ef38d80) · [Pilotauftrag](https://github.com/thomasmgfeller/x6-spectral-astrolabium/issues/192)
