"""CPU-Vergleich für zwei publizierte Astrolabium-Rechenkerne (Python 3.12, NumPy).

Aufruf: python x6_cpu_benchmark.py /pfad/zum/x6-spectral-astrolabium
Die Ergebnisse erscheinen als JSON. Der Vergleich schreibt nur temporäre Dateien.
"""
import argparse
import csv
import hashlib
import itertools
import json
import os
import shutil
import statistics
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import numpy as np


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def checked_dust_counter(edges, closure):
    # The original set-based primary calculation and return values are retained.
    reach = closure(edges)
    n = len(edges)
    past = [{i for i in range(n) if j in reach[i]} for j in range(n)]
    weights = (-1, 9, -16, 8)
    primary = n + sum(weights[h] for i, row in enumerate(reach) for j in row
                      if (h := len(row & past[j])) < 4)
    # Independent check starting again at the cover edges in topological order.
    ancestors = [0] * n
    descendants = [0] * n
    for i, row in enumerate(edges):
        for j in row:
            ancestors[j] |= ancestors[i] | (1 << i)
    for i in reversed(range(n)):
        for j in edges[i]:
            descendants[i] |= descendants[j] | (1 << j)
    secondary = n
    for future in descendants:
        remaining = future
        while remaining:
            bit = remaining & -remaining
            j = bit.bit_length() - 1
            h = (future & ancestors[j]).bit_count()
            if h < 4:
                secondary += weights[h]
            remaining ^= bit
    require(primary == secondary, 'dust counter mismatch')
    return primary, reach, past


def packed_matrix(packet):
    require(type(packet) is dict and set(packet) == {'N', 'marks', 'relation_rows'}, 'fields')
    n, rows, marks = packet['N'], packet['relation_rows'], packet['marks']
    require(type(n) is int and n > 2, 'N')
    require(type(rows) is list and len(rows) == n and
            all(type(r) is str and len(r) == n and set(r) <= {'0', '1'} for r in rows), 'rows')
    require(type(marks) is list and len(marks) == 2 and
            all(type(i) is int and 0 <= i < n for i in marks) and marks[0] != marks[1], 'marks')
    matrix = (np.frombuffer(''.join(rows).encode(), dtype=np.uint8) - 48).reshape(n, n).astype(bool)
    require(not matrix.diagonal().any(), 'diagonal')
    require(matrix[marks[0], marks[1]], 'endpoints')
    packed = np.packbits(matrix, axis=1)
    for i, row in enumerate(packed):
        union = np.bitwise_or.reduce(packed[matrix[i]], axis=0, initial=0)
        require(not (union & ~row).any(), 'transitivity')
    return matrix


def compare(functions, check, repeats):
    times = {name: [] for name in functions}
    for trial in range(repeats):
        order = list(functions)
        if trial % 2:
            order.reverse()
        for name in order:
            start = time.perf_counter()
            result = functions[name]()
            times[name].append(time.perf_counter() - start)
            check(result)
    medians = {k: statistics.median(v) for k, v in times.items()}
    return dict(seconds=times, median_seconds=medians, speedup=medians['reference']/medians['candidate'])


def dust(repo, tmp, repeats):
    path = repo/'research/rax_cqg/dust_collapse/packages/Kausalordnung_Endzustaende_Reproduktionspaket.zip'
    require(hashlib.sha256(path.read_bytes()).hexdigest() ==
            '82230266ff128334660ea03c49be766770358e98828c2e5f38c3fa451b5a0190', 'source archive')
    src = tmp/'source'
    with zipfile.ZipFile(path) as z:
        z.extractall(src)
    sys.path.insert(0, str(src))
    import enumerate_records as er
    from lift import closure
    original = er.q_integer
    names = ('history_records.csv', 'coefficients.csv', 'inventory.json')
    expected = {name: (src/name).read_bytes() for name in names}

    def run(fun):
        er.q_integer = fun
        er.main()

    work = tmp/'results'
    work.mkdir()
    shutil.copytree(src/'input', work/'input')
    er.ROOT = work

    def check(_):
        for name in names:
            require((work/name).read_bytes() == expected[name], name)
    # Silence the module's summary; timings include the same CSV I/O on both paths.
    from contextlib import redirect_stdout
    with open(os.devnull, 'w') as sink, redirect_stdout(sink):
        results = compare({'reference': lambda: run(original),
                           'candidate': lambda: run(lambda edges: checked_dust_counter(edges, closure))},
                          check, repeats)
    results['histories'] = len(list(csv.DictReader(expected[names[0]].decode().splitlines())))
    results['identical_files'] = names
    return results


def proper(repo, repeats):
    inputs = {
        'research/lorentz_proper_time/proper_core.py': '3165631ae9de0ae6b30e4277e4f67449c9e16705c51d8cf918c6dad424a66eb6',
        'research/lorentz_proper_time/proper_common.py': '8762bfbf545fd79c23ffc46ea3669bfec20ef201dffada51c91cd6fd46b00793',
        'research/lorentz_matching_geometry/core.py': 'ee9a96bdba32e93b092e89ce81a76a524a0dbaa05cf905e293b319eefb50f0f7',
    }
    for name, expected in inputs.items():
        require(hashlib.sha256((repo/name).read_bytes()).hexdigest() == expected, name)
    sys.path.insert(0, str(repo/'research/lorentz_proper_time'))
    import proper_common as common
    import proper_core as core
    original = core.matrix
    packets = [common.packet(common.sample(family, 256, 'calibration' if family == 'uniform' else 'test', draw))
               for family in ('uniform', 'jittered_grid') for draw in range(12)]
    # All 512 binary three-node relations, including non-transitive and cyclic inputs.
    for bits in itertools.product('01', repeat=9):
        rows = [''.join(bits[i:i+3]) for i in (0, 3, 6)]
        p = {'N': 3, 'marks': [0, 1], 'relation_rows': rows}
        outputs = []
        for impl in (original, packed_matrix):
            try:
                outputs.append(impl(p).tobytes())
            except ValueError:
                outputs.append(None)
        require(outputs[0] == outputs[1], 'three-node validity mismatch')
    expected = [core.features(p) for p in packets]

    def run(fun):
        core.matrix = fun
        return [core.features(p) for p in packets]

    try:
        result = compare({'reference': lambda: run(original), 'candidate': lambda: run(packed_matrix)},
                         lambda v: require(v == expected, 'feature mismatch'), repeats)
    finally:
        core.matrix = original
    result.update(packets=len(packets), events_per_packet=258, three_node_controls=512)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=Path)
    parser.add_argument('--part', choices=['dust','proper','both'], default='both')
    parser.add_argument('--repeats', type=int, default=3)
    args = parser.parse_args()
    require(__debug__ and args.repeats > 0, 'activate assertions and use positive repeats')
    root = args.repo.resolve()
    with tempfile.TemporaryDirectory() as t:
        result = {}
        if args.part in ('dust', 'both'):
            result['dust'] = dust(root, Path(t), args.repeats)
        if args.part in ('proper', 'both'):
            result['proper'] = proper(root, args.repeats)
        print(json.dumps(result, indent=2))
