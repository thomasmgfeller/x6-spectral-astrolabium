# Frühe Staubmasse und erhaltener Massenfluss

Endlicher Test auf den 75 bereits veröffentlichten Fenstergeometrien. Der Bericht erläutert den Beweis, die Modellannahmen und die Schranke für zusätzliche wegabhängige Phasen. Die Reproduktion benötigt Python 3.10+ und NumPy. Verwendet wurden Python 3.12.14 und NumPy 2.3.5. Die Skripte laufen ohne Netzwerk und ohne Zufallsziehungen.

## Ausführen

Im entpackten Verzeichnis:

    sha256sum -c SHA256SUMS
    python3 transport.py
    python3 score.py

Die numerischen Gegenprüfungen haben explizite Toleranzen. Die letzten Nachkommastellen der CSV-Dateien können auf anderen Systemen abweichen.

## Versuchsdefinition und Daten

- design.json wurde vor der Auswertung festgelegt. Die zusätzlich in score.py berechnete Phasenschranke wurde erst nach der Auswertung als analytische Ergänzung hergeleitet.
- baseline/ enthält unveränderten Code, Parameterdatei und Fensterergebnisse aus dem vorherigen [Prüfpaket](https://github.com/thomasmgfeller/x6-spectral-astrolabium/blob/dfccb8706d7119f8a68a52970b14e234f6aecc68/research/rax_cqg/dust_collapse/packages/CST_Staubkopplung_Endliche_Summe_Pruefpaket.zip). transport.py verwendet die Geometrieerzeugung und die unabhängigen Intervallzählungen dieses Codes. Den historischen Lauf braucht man für die neue Rechnung nicht erneut auszuführen.
- geometry_flux.csv beschreibt jede der 75 Geometrien. edges listet je Knoten die Nummern seiner Nachfolger auf den Nachbarkanten. Zulässige Schnitte schliessen die drei Anfangsquellen ein und den Endpunkt aus.
- path_weights.csv enthält alle reellen Geometriegewichte nach Entfernen der gemeinsamen Phase exp(-12i). alpha=1 ist der normierte lokale Transport, alpha=0 reine Wegzählung. r=2 teilt jede frühe Masseneinheit in zwei unterscheidbare Halbpakete.
- branches.csv enthält komplexe Amplituden je k, window.csv die Diagonalgewichte q, die Interferenz epsilon, das Maximum D über alle acht Teilmengen und die Freigabe. q ist ein Hilfsgewicht, keine nachgewiesene Wahrscheinlichkeit. Bei epsilon>=1 bleibt das Feld bound leer.
- split_sensitivity.csv misst den Gesamtabstand der beiden diagonalen Vergleichsverteilungen bei gleicher Gesamtmasse für r=1 und r=2 (halbe L1-Distanz).
- checks.json protokolliert die Massenflüsse, die Verlustkontrolle, die Zahl zulässiger Schnitte und die numerischen Gegenprüfungen. score.json wertet den bereits bekannten Referenzzählwert aus und enthält die notwendige Schranke für die neue Wegphase in dem festgelegten Modell.
- Pruefbericht.pdf ist der lesbare Ergebnisbericht.

Die Handhabung der Schnitte folgt aus dem vorgeschriebenen lokalen Flusserhaltungsgesetz. Das Modell bestimmt aus diesem Gesetz allein weder den Volumenverlauf noch die relativistische Staubbewegung. Das Prüfpaket enthält keine Messungen an einer realen Raumzeit.
