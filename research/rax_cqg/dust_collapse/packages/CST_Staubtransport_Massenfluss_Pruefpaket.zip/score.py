"""Score known comparator only after transport.py; analytic bound for normalized phase variations."""
from pathlib import Path
import csv,json,math
root=Path(__file__).resolve().parent
rows=list(csv.DictReader((root/'window.csv').open()))
issued=[r for r in rows if r['decision']=='issue']
x=2/(10+math.sqrt(100-16/3))
ref=1+2*x
data=dict(reference_average=ref,target_bin=round(ref),total_cells=len(rows),issued=len(issued),
          issued_correct=sum(int(r['peak'])==round(ref) for r in issued))
amps=list(csv.DictReader((root/'branches.csv').open()))
bounds=[]
for row in amps:
    if not (row['alpha']=='1.0' and row['parcels_per_source']=='1' and row['k']=='2'):continue
    a2=abs(complex(float(row['Re']),float(row['Im'])))
    # q1 >= .8 and epsilon <= 1/21 imply |A2|/|A1| <= 5/168.
    # A single history in bin 1 and |W_C| <= 1 give |A1| <= 1/6.
    delta=max(0.,(a2-(5/168)/6)/(49/4))
    bounds.append(dict(g=row['g'],baseline_abs_A2=a2,needed_sup_complex_distance=delta,
                       needed_phase_radius_radians=2*math.asin(delta/2)))
data['normalized_phase_only_bounds']=bounds
(root/'score.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
