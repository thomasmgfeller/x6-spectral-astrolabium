"""Conserved positive current on the published 75 geometries. Python 3.10+."""
import cmath
import csv
import hashlib
import itertools as it
import json
import math
from pathlib import Path
from fractions import Fraction
from baseline import run as old

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'design.json').read_text())
COUPLINGS={'0':0., '2.4':2.4, '4*pi/5':4*math.pi/5, '2.6':2.6}
ALPHAS=(0.,.5,1.)
def csum(items):
    items=list(items)
    return complex(math.fsum(z.real for z in items),math.fsum(z.imag for z in items))
def write_csv(name,rows):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        w.writeheader();w.writerows(rows)

def graph(sizes, matrices):
    n=sum(sizes); edges=[[] for _ in range(n)]
    off=0
    for rowm,next_size in zip(matrices,sizes[1:]):
        right=off+len(rowm)
        for j,mask in enumerate(rowm):
            edges[off+j]=[right+i for i in range(next_size) if mask & 1<<i]
        off=right
    return edges

def paths(edges,x):
    if not edges[x]:
        return [(x,)]
    return [(x,)+p for y in edges[x] for p in paths(edges,y)]

def all_cuts(edges):
    # Every order ideal enclosing the sources but excluding the endpoint.
    endpoint=len(edges)-1
    for middle in range(1<<(endpoint-3)):
        mask=7+(middle<<3)
        if all(not (mask & 1<<y) or (mask & 1<<x)
               for x,targets in enumerate(edges) for y in targets):
            yield mask

def crossing(path,mask):
    return sum(bool(mask & 1<<x) and not (mask & 1<<y)
               for x,y in zip(path,path[1:]))

def backwards(edges,alpha):
    h=[0.]*len(edges);h[-1]=1.
    for x in reversed(range(len(edges)-1)):
        h[x]=math.fsum(h[y] for y in edges[x])/len(edges[x])**alpha
    return math.prod(h[:3])

def forwards(edges,alpha,geom_paths):
    single=[]
    for x in range(3):
        single.append([math.prod(len(edges[v])**(-alpha) for v in p[:-1])
                       for p in geom_paths[x]])
    # All distinguishable three-parcel tuples.
    weights=[math.prod(terms) for terms in it.product(*single)]
    return math.fsum(weights), math.fsum(x*y for x,y in it.product(weights,repeat=2))

def diagnostics(branch):
    diag=sum(abs(a)**2 for a in branch);coh=abs(csum(branch))**2
    assert min(diag,coh)>0
    q=[abs(a)**2/diag for a in branch]
    eps=math.fsum(abs(a*b) for i,a in enumerate(branch)
                  for j,b in enumerate(branch) if i!=j)/diag
    discrepancies=[]
    for mask in range(8):
        group=[i for i in range(3) if mask & 1<<i]
        discrepancies.append(abs(abs(csum(branch[i] for i in group))**2/coh-sum(q[i] for i in group)))
    bound=2*eps/(1-eps) if eps<1 else None
    d=max(discrepancies)
    if bound is not None:assert d<=bound+1e-11
    peak=q.index(max(q))+1
    issued=(bound is not None and bound<=.10 and max(q)>=.80)
    return dict(q1=q[0],q2=q[1],q3=q[2],epsilon=eps,bound=bound,D=d,peak=peak,
                decision='issue' if issued else 'withhold')

def main():
    assert hashlib.sha256((ROOT/'baseline/run.py').read_bytes()).hexdigest()=='5f2bc34f7ba9b47e79eee1a740cc7be9cc3380156b22efaa6f14e36d79280007'
    geometries=[];mass_rows=[];negative=[];detail_rows=[]
    path_cut_count=0;tuple_count=0;split_tuple_count=0;max_weight_diff=0.;max_split_error=0.
    for k in (1,2,3):
        sizes=(3,2,k,4-k,1)
        for b,c,d in it.product(old.covers(2,k),old.covers(k,4-k),old.covers(4-k,1)):
            matrices=((1,3,2),b,c,d)
            q,_=old.relation_scores(sizes,matrices)
            assert q==old.independent_window(sizes,matrices)[0]
            edges=graph(sizes,matrices)
            p=[paths(edges,a) for a in range(3)]
            cuts=list(all_cuts(edges))
            geom_id=len(geometries)+1
            npaths=[len(pp) for pp in p];tuples=math.prod(npaths);tuple_count+=tuples
            split_tuple_count+=tuples**2
            for mask in cuts:
                for parcel_paths in p:
                    for path in parcel_paths:
                        assert len(path)==5 and path[-1]==9 and crossing(path,mask)==1
                        path_cut_count+=1
            # Independent forward transport with integer ratios on the four level cuts.
            mass=[Fraction(i<3) for i in range(10)]
            cutflow=[Fraction() for _ in range(4)]
            times=[j for j,n in enumerate(sizes) for _ in range(n)]
            for x in range(9):
                amount=mass[x]/len(edges[x])
                for y in edges[x]:
                    mass[y]+=amount; cutflow[times[x]]+=amount
            assert cutflow==[3]*4 and mass[-1]==3
            mass_rows.append(dict(id=geom_id,k=k,Q=q,edges='|'.join(','.join(str(y) for y in t) for t in edges),
                                  hist_tuples=tuples,path_count_by_source='/'.join(map(str,npaths)),
                                  admissible_cuts=len(cuts),layer_fluxes='/'.join(map(str,cutflow)),terminal_mass=str(mass[-1])))
            # Lose the first unit immediately after it reaches layer 2.
            chosen=[p[0][0][:3],p[1][0],p[2][0]]
            measured=[sum(crossing(pp,(1<<sum(sizes[:j+1]))-1) for pp in chosen) for j in range(4)]
            assert measured==[3,3,2,2];negative.append(measured)
            weight={}
            for alpha in ALPHAS:
                u=backwards(edges,alpha);w,split=forwards(edges,alpha,p)
                max_split_error=max(max_split_error,abs(split-u*u))
                assert abs(split-u*u)<1e-10
                max_weight_diff=max(max_weight_diff,abs(u-w))
                assert abs(u-w)<1e-11
                if alpha==0:assert u==tuples
                if alpha==1:assert abs(u-1)<1e-14
                weight[alpha]=u
                detail_rows.append(dict(id=geom_id,k=k,Q=q,alpha=alpha,weight_one=u,weight_split=u*u))
            geometries.append((k,q,weight))
    assert [sum(k==j for k,_,_ in geometries) for j in (1,2,3)]==[1,49,25]
    rows=[];amplitudes=[]
    for alpha,r,(gname,g) in it.product(ALPHAS,(1,2),COUPLINGS.items()):
        branch=[csum(w[alpha]**r*cmath.exp(1j*g*q)
                     for k,q,w in geometries if k==b)/(math.factorial(b)*math.factorial(4-b)) for b in (1,2,3)]
        rows.append(dict(alpha=alpha,parcels_per_source=r,g=gname,**diagnostics(branch)))
        for k,a in enumerate(branch,1):
            amplitudes.append(dict(alpha=alpha,parcels_per_source=r,g=gname,k=k,Re=a.real,Im=a.imag))
    with (ROOT/'baseline/window_sums.csv').open() as f:
        previous={x['g']:x for x in csv.DictReader(f) if x['s']=='0'}
    err=max(abs(row[ours]-float(previous[row['g']][theirs])) for row in rows if row['alpha']==1
            for ours,theirs in [('q1','q1'),('q2','q2'),('q3','q3'),('epsilon','epsilon'),('D','max_subset_discrepancy')])
    assert err<1e-11
    shifts=[]
    for alpha,gname in it.product(ALPHAS,COUPLINGS):
        a,b=[row for row in rows if row['alpha']==alpha and row['g']==gname]
        tv=sum(abs(a['q'+str(k)]-b['q'+str(k)]) for k in (1,2,3))/2
        shifts.append(dict(alpha=alpha,g=gname,total_variation=tv))
    write_csv('geometry_flux.csv',mass_rows);write_csv('path_weights.csv',detail_rows)
    write_csv('window.csv',rows);write_csv('branches.csv',amplitudes)
    write_csv('split_sensitivity.csv',shifts)
    v1,v2=Fraction(8),Fraction(4)
    rho1,rho2=cutflow[1]/v1,cutflow[2]/v2
    assert rho2/rho1==2 and (rho2*v2)/(rho1*v1)==1
    out=dict(geometries=len(geometries),three_parcel_tuples=tuple_count,six_parcel_tuples=split_tuple_count,
             ideals_over_geometries=sum(x['admissible_cuts'] for x in mass_rows),
             individual_path_cut_checks=path_cut_count,layer_fluxes=[int(v) for v in cutflow],terminal_flux=int(mass[-1]),
             loss_control=negative[0],loss_controls_tested=len(negative),
             max_direct_vs_recursive_error=max_weight_diff,max_split_sum_error=max_split_error,max_normalized_vs_baseline_error=err,
             classical_volume_ratio=float(v2/v1),classical_density_ratio=float(rho2/rho1),classical_mass_ratio=float((rho2*v2)/(rho1*v1)))
    (ROOT/'checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':
    main()
