"""Independent checks for order selection, arbitrary FLRW diamonds and timelike references."""
import json,math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
import experiment as ex
def brute(x,marks):
    if not len(x):return (-1,0,0,0)
    dt=x[:,None,0]-x[None,:,0];d=x[:,None,1:]-x[None,:,1:]
    past=(dt>0)&((d*d).sum(axis=2)<dt**2)
    p=past.sum(axis=1);f=past.sum(axis=0);score=np.minimum(p,f)
    ties=np.flatnonzero(score==score.max());i=int(ties[np.argmin(marks[ties])])
    return i,int(p[i]),int(f[i]),len(ties)
def shell_area(t,L,R,d):
    # Integral of disks normal to the separation axis. L,R are the two radii.
    if d==0:return 4*math.pi/3*min(L,R)**3
    lo=max(-L,d-R);hi=min(L,d+R)
    if hi<=lo:return 0.
    j=(L*L-R*R+d*d)/(2*d)
    return quad(lambda x:math.pi*max(0.,min(L*L-x*x,R*R-(x-d)**2)),lo,hi,
                points=[j] if lo<j<hi else [],epsabs=1e-12)[0]
def other_volume(e1,e2,d,model):
    return quad(lambda e:shell_area(e,e-e1,e2-e,d)*ex.omega(e,model)**4,e1,e2,
                points=[(e1+e2-d)/2,(e1+e2+d)/2],epsabs=1e-12)[0]
def other_geodesic(e1,e2,d):
    t1,t2=ex.back(e1,'dust'),ex.back(e2,'dust')
    a=lambda t:(1-t/12)**(2/3)
    fun=lambda p:quad(lambda t:p/(a(t)*math.hypot(a(t),p)),t1,t2,epsabs=1e-12)[0]-d
    upper=1
    while fun(upper)<0:upper*=2
    p=brentq(fun,0,upper,xtol=1e-13)
    return quad(lambda t:a(t)/math.hypot(a(t),p),t1,t2,epsabs=1e-12)[0]
def main():
    for nu in ex.NU:
        assert abs(ex.density(nu)*ex.interval_volume(0,4,0,'flat')-nu)<1e-10
        assert abs(ex.density(nu)*ex.interval_volume(0,8,0,'flat')-16*nu)<1e-10
    ex.build();ex.load()
    rng=np.random.default_rng(2026110347);num=0;boosts=0;tied=0
    assert ex.choose(np.empty((0,4)),np.empty(0),8)==(-1,0,0,0)
    for g in ex.MODELS:
        H=float(ex.eta(8,g))
        for _ in range(64):
            x=ex.cloud(g,192/(ex.C*8**4),rng);u=rng.random(len(x));v=ex.choose(x,u,H)
            assert v==brute(x,u);num+=1;tied+=v[3]>1
            order=rng.permutation(len(u)); w=ex.choose(x[order],u[order],H)
            assert order[w[0]]==v[0] and w[1:]==v[1:]
            if g=='flat':
                y=x.copy();y[:,0]=1.25*(x[:,0]-.6*x[:,1]);y[:,1]=1.25*(x[:,1]-.6*x[:,0])
                assert ex.choose(y,u,H)==v;boosts+=1
    tri=np.array([[2.,-.5,0,0],[2.,.5,0,0],[4,0.,0,0],[4,1,0,0],[6,0,0,0]])
    assert ex.choose(tri,np.array([.8,.3,.9,.1,.4]),8)==brute(tri,np.array([.8,.3,.9,.1,.4]))
    cases=[];vmax=0.;tmax=0.
    for g in ex.MODELS:
        for t1,t2 in [(0,8),(0,3),(3,8)]:
            e1,e2=map(float,ex.eta([t1,t2],g))
            for fraction in (0.,.25,.75,.95):
                d=(e2-e1)*fraction
                v=ex.interval_volume(e1,e2,d,g); va=other_volume(e1,e2,d,g);err=abs(v-va)/v
                assert err<2e-11;vmax=max(vmax,err)
                tau=ex.geodesic(e1,e2,d,g)
                true=other_geodesic(e1,e2,d) if g=='dust' else math.sqrt((t2-t1)**2-d**2)
                tmax=max(tmax,abs(tau-true));assert abs(tau-true)<1e-10
                cases.append((g,t1,t2,fraction))
    out=dict(density_controls=len(ex.NU),brute_force_matches=num,relabelings=num,tied_controls=tied,lorentz_boosts=boosts,
             independent_reference_cases=len(cases),max_relative_volume_error=vmax,max_abs_geodesic_error=tmax)
    (ex.ROOT/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
