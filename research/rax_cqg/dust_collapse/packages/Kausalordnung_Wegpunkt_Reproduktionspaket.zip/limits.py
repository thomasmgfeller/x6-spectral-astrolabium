"""Continuum maximizer of the two smaller subinterval volumes."""
from scipy.optimize import brentq
from experiment import C,T,MODELS,eta,back,interval_volume
from score import write_table
def main():
    rows=[]
    for model in MODELS:
        H=float(eta(T,model))
        balance=lambda e:interval_volume(0,e,0,model)-interval_volume(e,H,0,model)
        e=brentq(balance,0,H)
        split=2*(interval_volume(0,e,0,model)/C)**.25
        coarse=(interval_volume(0,H,0,model)/C)**.25
        assert abs(split-coarse)<.10 and max(abs(split-T),abs(coarse-T))<.20
        rows.append(dict(model=model,eta_star=e,t_star=float(back(e,model)),
                         split=split,coarse=coarse,split_minus_coarse=split-coarse))
    write_table('limits.csv',rows)
if __name__=='__main__':main()
