"""Geometry-only diagnostic for a fixed off-plane waypoint in flat spacetime."""
import math
import numpy as np
from scipy.integrate import quad
from experiment import C
from score import write_table


def visible_fraction(duration, x1, x2):
    dx=x2-x1
    tau=math.sqrt(duration**2-dx**2)
    half=tau/2
    xm=(x1+x2)/2
    slope=dx/tau
    rownorm=math.hypot(1,slope)
    def area(u):
        radius=half-abs(u)
        h=(-xm-slope*u)/rownorm
        if h>=radius:return 4*math.pi*radius**3/3
        if h<=-radius:return 0.
        return math.pi*(radius+h)**2*(2*radius-h)/3
    # Split the integration where the cutting plane first touches a ball.
    points={0.}
    for side in (-1,1):
        for sign in (-1,1):
            den=sign*rownorm*side-slope
            if den:
                u=(sign*rownorm*half+xm)/den
                if 0<side*u<half:points.add(u)
    return quad(area,-half,half,points=sorted(points),epsabs=1e-12)[0]/(C*tau**4)


def main():
    data=[]
    for offset in (0.,.25,.5,1.,2.):
        fraction=visible_fraction(4,0,-offset)
        reverse=visible_fraction(4,-offset,0)
        complement=visible_fraction(4,0,offset)
        assert abs(reverse-fraction)<1e-12 and abs(1-fraction-complement)<1e-12
        k=(4+offset)/(4-offset)
        exact=1-2/(k*(k+1))+1/(2*k**2)
        assert abs(fraction-exact)<1e-12 and (offset==0 or fraction>.5)
        L=2*math.sqrt(16-offset**2)
        data.append(dict(offset=offset,visible_fraction=fraction,proper=L,
                 corrected=L*(2*fraction)**.25,corrected_minus_proper=L*((2*fraction)**.25-1)))
    write_table('boundary.csv',data)
if __name__=='__main__':main()
