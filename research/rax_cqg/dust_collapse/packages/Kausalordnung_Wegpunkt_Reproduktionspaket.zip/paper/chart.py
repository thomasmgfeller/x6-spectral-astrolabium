import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
here=Path(__file__).resolve().parent
with (here.parent/'gates.csv').open() as f: rows=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(7.1,2.55))
for method,name,color,mark,ls in [('fixed_B','Markierter Mittelpunkt · B','#71818b','s','--'),
    ('reuse_A','Gewählter Punkt · A','#cb743c','^',':'),('holdout_B','Gewählter Punkt · B','#00695f','o','-')]:
    data=[r for r in rows if r['model']=='dust' and r['method']==method]
    x=np.array([float(r['nu']) for r in data]);y=np.array([float(r['rate']) for r in data])*100
    ax.plot(x,y,label=name,color=color,marker=mark,linestyle=ls,lw=1.9,ms=5)
ax.axhline(95,color='#434b4a',lw=.9,ls='--',zorder=0)
ax.set_ylim(-3,104);ax.set_yticks([0,25,50,75,95]);ax.set_ylabel('Gemeinsame Treffer (%)')
ax.set_xscale('log',base=4);ax.set_xticks(x);ax.set_xticklabels([str(int(v)) for v in x]);ax.set_xlabel('Referenzbesetzung ν')
ax.spines[['right','top']].set_visible(False);ax.grid(axis='y',alpha=.18)
ax.legend(loc='lower right',fontsize=8,frameon=False)
fig.tight_layout(pad=.5);fig.savefig(here/'gate_chart.pdf');plt.close(fig)
