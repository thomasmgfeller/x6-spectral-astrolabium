// Exact maximin score for a coordinate realization of a 4D causal diamond.
// Rectangles provide conservative upper bounds only; all unpruned scores use strict order.
#include <algorithm>
#include <cmath>
#include <numeric>
#include <vector>

struct Search {
    const double* points;
    const double* priority;
    int score = -1, winner = -1, ties = 0, nminus = 0, nplus = 0;
    const double* at(int i) const { return points+4*i; }
    void counts(int i,const std::vector<int>& minus,const std::vector<int>& plus,int& p,int& f) const {
        const double* x=at(i);p=0;f=0;
        for(int j:minus) {
            const double* y=at(j);double dt=x[0]-y[0];
            if(dt>0) {
                double a=x[1]-y[1],b=x[2]-y[2],c=x[3]-y[3];
                p+=a*a+b*b+c*c<dt*dt;
            }
        }
        for(int j:plus) {
            const double* y=at(j);double dt=y[0]-x[0];
            if(dt>0) {
                double a=x[1]-y[1],b=x[2]-y[2],c=x[3]-y[3];
                f+=a*a+b*b+c*c<dt*dt;
            }
        }
    }
    static double gap(double x,double lo,double hi) {return std::max({lo-x,x-hi,0.0});}
    void visit(std::vector<int>& ids,int lo,int hi,const std::vector<int>& minus,const std::vector<int>& plus) {
        double minv[4],maxv[4];
        for(int d=0;d<4;++d) minv[d]=maxv[d]=at(ids[lo])[d];
        for(int j=lo+1;j<hi;++j)
            for(int d=0;d<4;++d) {minv[d]=std::min(minv[d],at(ids[j])[d]);maxv[d]=std::max(maxv[d],at(ids[j])[d]);}
        auto bound=[&](const std::vector<int>& old,bool past) {
            std::vector<int> possible;possible.reserve(old.size());
            for(int j:old) {
                const double* p=at(j);
                double dt=past?maxv[0]-p[0]:p[0]-minv[0];
                if(dt<0) continue;
                double a=gap(p[1],minv[1],maxv[1]),b=gap(p[2],minv[2],maxv[2]),c=gap(p[3],minv[3],maxv[3]);
                if(a*a+b*b+c*c<=dt*dt+1e-12) possible.push_back(j);
            }
            return possible;
        };
        auto p=bound(minus,true);if(int(p.size())<score)return;
        auto f=bound(plus,false);if(int(f.size())<score)return;
        if(hi-lo<=10) {
            for(int j=lo;j<hi;++j) {
                int i=ids[j],a,b; counts(i,p,f,a,b);int s=std::min(a,b);
                if(s>score){score=s;ties=0;winner=-1;}
                if(s==score) {
                    ++ties;
                    if(winner<0||priority[i]<priority[winner]){
                        winner=i;nminus=a;nplus=b;
                    }
                }
            }
            return;
        }
        int axis=0;
        for(int d=1;d<4;++d) if(maxv[d]-minv[d]>maxv[axis]-minv[axis])axis=d;
        int mid=(lo+hi)/2;
        std::nth_element(ids.begin()+lo,ids.begin()+mid,ids.begin()+hi,[&](int a,int b){return at(a)[axis]<at(b)[axis];});
        visit(ids,lo,mid,p,f);visit(ids,mid,hi,p,f);
    }
};
extern "C" void midpoint(const double* data,const double* priority,int n,double duration,int* out) {
    if(n==0){out[0]=-1;out[1]=out[2]=out[3]=0;return;}
    Search s{data,priority};std::vector<int> ids(n);std::iota(ids.begin(),ids.end(),0);
    std::vector<int> witnesses=ids;
    // Any scored candidate supplies a valid lower bound on the optimum.
    int pivot=0;double best=-1e99;
    for(int i:ids){
        const double* x=s.at(i);double t=std::min(x[0],duration-x[0]);
        double z=t*t-x[1]*x[1]-x[2]*x[2]-x[3]*x[3];if(z>best){best=z;pivot=i;}
    }
    int a,b;s.counts(pivot,witnesses,witnesses,a,b);s.score=std::min(a,b);
    s.visit(ids,0,n,witnesses,witnesses);
    out[0]=s.winner;out[1]=s.nminus;out[2]=s.nplus;out[3]=s.ties;
}
