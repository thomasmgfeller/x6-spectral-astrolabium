"""Replay every primary case plus two prespecified indices in each other cell."""
from concurrent.futures import ProcessPoolExecutor
import argparse
import csv
import json
import os
from pathlib import Path
import experiment as ex

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--save',type=Path,help='only generate a temporary replay for later comparison')
    parser.add_argument('--compare',type=Path,help='use a previously generated replay')
    opts=parser.parse_args()
    if opts.compare:
        reproduced=json.loads(opts.compare.read_text())
    else:
        ex.build()
        tasks=[(g,j,i,1) for g in range(2) for j in range(len(ex.NU))
               if (g,j)!=(1,3) for i in (0,997)]
        tasks.extend((1,3,i,min(16,ex.REPS-i)) for i in range(0,ex.REPS,16))
        with ProcessPoolExecutor(max_workers=int(os.getenv('WAYPOINT_REPLAY_WORKERS','2')),initializer=ex.load) as pool:
            reproduced=[{k:str(v) for k,v in row.items()} for rows in pool.map(ex.batch,tasks) for row in rows]
    if opts.save:
        opts.save.write_text(json.dumps(reproduced))
        print(len(reproduced),'regenerated rows');return
    with (ex.ROOT/'realizations.csv').open() as stream:
        source={(r['model'],r['nu'],r['rep']):r for r in csv.DictReader(stream)}
    for row in reproduced:
        expected=source[row['model'],row['nu'],row['rep']]
        assert all(expected[k]==value for k,value in row.items())
        assert all(k in row or value=='' for k,value in expected.items())
    assert len(reproduced)==1042
    print('1042 complete raw records reproduced field by field, including every primary replicate.')
if __name__=='__main__':main()
