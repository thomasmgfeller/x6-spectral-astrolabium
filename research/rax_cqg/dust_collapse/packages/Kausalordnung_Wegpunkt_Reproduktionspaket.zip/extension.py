"""One higher, independently tested dust density; held-out counts by their exact joint law."""
import csv
import json
import math
import os
from multiprocessing import Pool
import numpy as np
from scipy.stats import beta
import experiment as ex

PLAN=json.loads((ex.ROOT/'extension_design.json').read_text())
NU=PLAN['nu']; N=PLAN['repetitions']; MODEL=PLAN['model']
RHO=ex.density(NU); H=float(ex.eta(ex.T,MODEL))
V=ex.interval_volume(0,H,0,MODEL)

def trial(i):
    seeds=np.random.SeedSequence([PLAN['seed'],i]).spawn(3)
    x=ex.cloud(MODEL,RHO,np.random.default_rng(seeds[0]))
    mark=np.random.default_rng(seeds[1]).random(len(x))
    idx,left,right,ties=ex.choose(x,mark,H)
    row=dict(rep=i,nA=len(x),score=min(left,right),ties=ties,joint=0)
    if idx<0 or row['score']==0:return row
    event=x[idx]
    assert ex.counts(x,event)==(left,right)
    e=float(event[0]); d=float(np.linalg.norm(event[1:]))
    v1=ex.interval_volume(0,e,d,MODEL);v2=ex.interval_volume(e,H,d,MODEL)
    assert v1+v2<=V
    a,b,rest=np.random.default_rng(seeds[2]).poisson(RHO*np.array([v1,v2,V-v1-v2]))
    coarse=ex.phi(a+b+rest,RHO); split=ex.phi(a,RHO)+ex.phi(b,RHO)
    row.update(joint=int(abs(coarse-split)<=.10 and max(abs(coarse-8),abs(split-8))<=.20),
               eta=e,r=d,pA=left,fA=right,vol1=v1,vol2=v2,pB=int(a),fB=int(b),restB=int(rest),
               coarse=coarse,split=split)
    return row

def main():
    ex.build()
    with Pool(int(os.getenv('WAYPOINT_EXTENSION_WORKERS','7')),initializer=ex.load) as pool:
        rows=list(pool.imap(trial,range(N)))
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (ex.ROOT/'extension.csv').open('w',newline='') as f:
        out=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');out.writeheader();out.writerows(rows)
    k=sum(r['joint'] for r in rows)
    lo=float(beta.ppf(.005,k,N-k+1)) if k else 0.
    hi=float(beta.isf(.005,k+1,N-k)) if k<N else 1.
    out=dict(nu=NU,n=N,joint=k,rate=k/N,lo=lo,hi=hi,
             resolved=sum(r['score']>0 for r in rows),
             status='pass' if lo>=.95 else 'fail' if hi<.95 else 'undecided')
    (ex.ROOT/'extension_result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out)
if __name__=='__main__':main()
