# Ein Wegpunkt aus der Kausalordnung

Dieser Versuch untersucht die einmalige intrinsische Halbierung eines vollständigen vierdimensionalen Kausaldiamanten. Nur die beiden äusseren Enden sind vorgegeben. Er schliesst an [Astrolabium, PR 199](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/199) an. Der eigenständige Bericht liegt als `Pruefbericht.pdf` bei.

## Experiment reproduzieren

Verwendet wurden Linux, Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 und GCC/c++ 13.3.0 mit C++17. Der Versuch läuft offline. `experiment.py` baut den lokalen Suchkern selbst. Die 10240 Realisierungen der Hauptserie und die 256 des separat geplanten Zusatzversuchs werden in fester Reihenfolge ausgegeben. Die Zahl der Prozesse lässt sich einstellen. Die Laufzeit hängt vorwiegend von der Suche in den grossen Punktwolken ab.

    sha256sum -c SHA256SUMS
    export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 WAYPOINT_WORKERS=5
    python3 experiment.py
    python3 score.py
    python3 verify.py
    python3 boundary.py
    python3 limits.py
    python3 holdout_check.py
    python3 extension.py
    python3 replay.py
    sha256sum -c SHA256SUMS

Jede Realisierung verwendet `SeedSequence([2026110337, Geometrieindex, Dichteindex, Realisierungsindex]).spawn(3)` für Auswahlwolke A, Messwolke B und die Gleichstandsmarken. Verschiedene Methoden innerhalb einer Tabellenzeile sind gepaart. Verschiedene Realisierungen werden unabhängig gezogen. Andere Versionen von Mathematikbibliotheken können letzte Gleitkommastellen verändern. Die gesetzten Grenzwerte, das Primärziel und die Stichprobengrösse stehen in `design.json` (SHA-256 `cb648e92bfb42c1b23d1eefecb48a4a8160201b35f0d7e1134fb894e133b9b53`). Die empirische Hauptauswertung verwendet die dort definierte Dichte rho = nu / [(pi/24) 4^4]. Ein Vorlauf mit einer abweichenden Dichteskala wurde vor der Auswertung verworfen. `verify.py` prüft diese Umrechnung für alle fünf Dichten gegen das wahre Halb- und Gesamtvolumen.

## Was gerechnet wird

- `experiment.py` zieht physisch homogene vierdimensionale Poisson-Wolken im vollständigen Diamanten. Im Staubmodell wird ein konform homogener Vorschlag mit der Annahmewahrscheinlichkeit a(eta)^4 ausgedünnt. Aus einem radialen Geodätenintegral und dem Überlappungsvolumen der Lichtkegel folgen die Kontinuumsreferenzen.
- `select.cpp` bestimmt den Maximierer des kleineren der beiden offenen Intervallzählwerte in A. Unabhängige Marken brechen Gleichstände. Ein geometrisch günstiger Anfangskandidat liefert nur eine gültige untere Schranke. Teilbereiche werden allein bei einer strikten Unterschreitung durch eine konservative obere Zählschranke ausgelassen. Die Auswahl selbst berücksichtigt bei unveränderten Marken allein die kausalen Beziehungen.
- `score.py` bildet die drei vorab definierten gemeinsamen Trefferquoten und die Zerlegung der Wegeffekte. Im flachen Modell prüft es analytisch und empirisch die Chance, überhaupt einen nahezu mittigen Kandidaten vorzufinden. Die praktische Messung erhält diese Kontinuumsinformation nicht. Für die unabhängige bedingte Erwartung wird die Poisson-Masse relativ zu ihrem Modus berechnet, bis 16 Standardabweichungen plus 80 Ereignisse auf beiden Seiten.
- `verify.py` vergleicht Suchergebnisse mit vollständigen Ordnungsrelationen, Zufallsmarken unter Umnummerierung, einer flachen Lorentztransformation und unabhängigen numerischen Volumen- und Eigenzeitrechnungen.
- `limits.py` löst die Gleichheit der beiden wahren Volumina auf der mitbewegten Achse. `boundary.py` prüft ein nachgelagertes analytisches Gegenbeispiel für einen seitlich versetzten Weg im Halbraum. Eine unabhängige Kugelkappenintegration prüft die geschlossene Formel.
- `holdout_check.py` prüft diagnostisch die unabhängige Wolke am primären Wegpunkt durch 256 zusätzliche, bedingt unabhängige Ziehungen aus drei disjunkten Poisson-Zellen. Der gepaarte Standardfehler behandelt die 1024 unabhängigen Wegpunkte als Stichprobeneinheiten.
- `extension_design.json` wurde nach Sichtung der Hauptserie und vor den frischen Ziehungen festgeschrieben (SHA-256 `c7f437080b7435e215374754d59000967bdfebf5d1d996f6732bcd5786b871f5`). `extension.py` prüft allein Staub bei nu = 16384 mit 256 neuen unabhängigen Realisierungen. Die A-Wolke ist explizit; die drei zur B-Auswertung erforderlichen Zählungen werden bei gegebener A-Auswahl aus ihrer exakten gemeinsamen Verteilung gezogen. Die 99%-Entscheidung gehört zu einer eigenen Familie und wird nicht mit der Hauptserie zusammengelegt.
- `replay.py` wiederholt alle 1024 primären Realisierungen und zusätzlich die Fälle 0 und 997 in jeder der neun anderen Zellen. Alle gespeicherten Felder werden verglichen.

## Datentabellen

| Datei | Inhalt |
|---|---|
| `realizations.csv` | Eine Zeile pro Geometrie, Besetzung und Lauf. Anzahlen in A/B, maximale Mindestzählung (`score`), Zahl der Maxima (`ties`), gewählte kosmische Zeit und komovierender Radius, vier Teilzählwerte, beide Eigenzeiten und Volumina, grobe und geteilte Phasen. `oracle_min` ist in flacher Geometrie der grösste geometrisch erreichbare Wert der kleineren Teilzeit über alle Kandidaten. |
| `extension.csv`, `extension_result.json` | Alle 256 Zusatzrealisierungen mit den drei Zählungen in B sowie Trefferzahlen und separatem 99%-Intervall für die einzige vorab festgelegte Zusatzfrage. |
| `gates.csv` | Gemeinsame Treffer, Komponenten, Nenner, simultane Grenzen, Entscheidung. `reuse_A` zählt auf den Auswahldaten, `holdout_B` auf unabhängigen Daten am selben Punkt. `fixed_B` verwendet die markierte Referenz. Jeweils dieselbe Wolke liefert die zugehörige grobe und feine Phase. Unaufgelöste Auswahl zählt für die beiden ausgewählten Methoden als verfehlt. |
| `errors.csv` | Mittelwerte bedingt auf erfolgreiche Punktwahl. Gepaarte Fehlerzerlegung, zusätzlicher Vergleich mit dem exakten bedingten Poisson-Erwartungswert bei gegebenem Wegpunkt, Standardfehler des gepaarten Unterschieds und Treffer des feinen Werts gegen beide Weglängen. Letztere Spalten haben eine eigene Bedeutung gegenüber dem gemeinsamen Test. |
| `calibration.csv` | Beobachtete und erwartete mittlere Gesamtzählungen in A und B samt standardisierter Differenz. |
| `supply.csv` | Theoretische Verfügbarkeit eines Kandidaten mit beiden wahren Teilzeiten mindestens 3.95; beobachtete und gewählte Anzahlen. Der zweiseitige Binomialtest dient als Kontrolle und gehört nicht zur Familie der 30 Zielwahrscheinlichkeiten. |
| `holdout_check.json` | Direkt aus simulierten Kontinuumsvolumina ermittelte bedingte Trefferchance und Vergleich zur expliziten Wolke am primären Wegpunkt. |
| `limits.csv`, `boundary.csv`, `checks.json` | Numerischer Grenzpunkt und Phasengrenzen, ebene Randgeometrie, unabhängige Implementierungskontrollen. |

Die Unterlagen zur PDF-Fassung liegen im Ordner `paper`. Zum Neusetzen genügt dort `pdflatex report.tex` (zweimal); die fertige Vektorgrafik liegt bei. `chart.py` erzeugt sie bei Bedarf mit Matplotlib aus `gates.csv`.

Die Auswertung kostet zwei unabhängige Prozesse der Dichte rho. Eine zufällige Zweifärbung einer einzelnen Wolke von Gesamtdichte 2 rho liefert dieselbe Verteilung. Der Kandidat muss bei einer unabhängigen Zählung kein Ereignis von B sein. Seine Ordnungsrelationen zu B sind im gemeinsamen besprengten Kausalset verfügbar. Die Analyse gibt eine Phasendiagnose auf vorgegebenen Hintergründen. Eine dynamische vierdimensionale Kausalset-Summe und die Umgebung der Singularität bei t = 12 sind offene Anschlussprobleme.
