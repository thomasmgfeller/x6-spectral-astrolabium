"""Independent conditional check of B on primary selected points (diagnostic only)."""
import csv
import json
import math
import numpy as np
from experiment import ROOT, C, T, density, eta, interval_volume, REPS

MC=256

def check(rows):
    group=sorted((r for r in rows if r['model']=='dust' and int(r['nu'])==1024),
                 key=lambda r:int(r['rep']))
    assert len(group)==REPS
    rho=density(1024)
    parent=interval_volume(0,float(eta(T,'dust')),0,'dust')
    fresh=[];observed=[]
    for row in group:
        if int(row['resolved'])==0:
            fresh.append(0.);observed.append(0.);continue
        actual1,actual2=float(row['coarseB']),float(row['splitB'])
        observed.append(float(abs(actual2-actual1)<=.10 and max(abs(actual1-8),abs(actual2-8))<=.20))
        a,b=float(row['vol1']),float(row['vol2'])
        means=rho*np.array([a,b,parent-a-b])
        assert min(means)>=0
        rng=np.random.default_rng(np.random.SeedSequence([2026110359,int(row['rep'])]))
        counts=rng.poisson(means,size=(MC,3))
        coarse=(counts.sum(axis=1)/(rho*C))**.25
        split=((counts[:,:2]/(rho*C))**.25).sum(axis=1)
        hit=(abs(split-coarse)<=.10)&(abs(split-8)<=.20)&(abs(coarse-8)<=.20)
        fresh.append(float(hit.mean()))
    difference=np.array(observed)-fresh
    return dict(replicates=REPS,conditional_draws_per_point=MC,
                explicit_cloud_rate=np.mean(observed),conditional_draw_rate=np.mean(fresh),
                paired_difference=difference.mean(),SE_difference=difference.std(ddof=1)/math.sqrt(REPS))

if __name__=='__main__':
    with (ROOT/'realizations.csv').open() as stream: stats=check(csv.DictReader(stream))
    (ROOT/'holdout_check.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(stats)
