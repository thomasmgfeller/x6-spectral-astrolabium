"""Fixed joint gate, paired error decomposition, and a continuum supply control."""
import csv
import math
from collections import defaultdict
import numpy as np
from scipy.integrate import quad
from scipy.stats import beta, binomtest
from experiment import ROOT, MODELS, NU, T, C, REPS, density


def write_table(name, rows):
    with (ROOT/name).open('w', newline='') as stream:
        writer=csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def limits(k,n):
    tail=.01/(2*30)
    lo=0. if k==0 else float(beta.ppf(tail,k,n-k+1))
    hi=1. if k==n else float(beta.isf(tail,k+1,n-k))
    return lo,hi,'pass' if lo>=.95 else 'fail' if hi<.95 else 'undecided'


def poisson_root(lam):
    if lam==0: return 0.
    mode=int(lam)
    span=math.ceil(16*math.sqrt(lam)+80)
    lo=max(0,mode-span); hi=mode+span
    weight=np.ones(hi-lo+1); pivot=mode-lo
    if pivot:
        weight[:pivot]=np.cumprod(np.arange(mode,lo,-1)/lam)[::-1]
    weight[pivot+1:]=np.cumprod(lam/np.arange(mode+1,hi+1))
    return float(np.dot(weight,np.arange(lo,hi+1)**.25)/weight.sum())


def columns(rows,key):
    return np.array([float(r[key]) if r.get(key) else np.nan for r in rows])


def main():
    cells=defaultdict(list)
    with (ROOT/'realizations.csv').open() as stream:
        for row in csv.DictReader(stream):
            cells[row['model'],int(row['nu'])].append(row)
    gates=[]; errors=[]; supply=[]; calibration=[]
    W=8*math.pi/3*quad(lambda t: ((t-3.95)*(t+3.95))**1.5,3.95,T/2,epsabs=1e-14)[0]
    for g in MODELS:
        for nu in NU:
            rows=cells[g,nu]; n=len(rows); assert n==REPS and len({r['rep'] for r in rows})==n
            resolved=columns(rows,'resolved').astype(bool)
            for name,coarse,split in [('reuse_A','coarseA','splitA'),('holdout_B','coarseB','splitB'),('fixed_B','coarseB','external_B')]:
                whole=columns(rows,coarse); pieces=columns(rows,split)
                stable=np.abs(whole-pieces)<=.10
                accurate=(np.abs(whole-8)<=.20)&(np.abs(pieces-8)<=.20)
                joint=int(np.count_nonzero(stable&accurate))
                lo,hi,status=limits(joint,n)
                gates.append(dict(model=g,nu=nu,method=name,n=n,no_selected_point=int((~resolved).sum()),
                        stable=int(stable.sum()),accurate=int(accurate.sum()),joint=joint,rate=joint/n,lo=lo,hi=hi,status=status))
            get=lambda k: columns(rows,k)[resolved]
            rho=density(nu)
            A,B,V,L=map(get,['splitA','splitB','geom_phase','proper'])
            expected=np.array([sum(poisson_root(rho*float(r[k])) for k in ['vol1','vol2'])/(rho*C)**.25
                                  for r in rows if r['resolved']=='1'])
            means={k:float(np.mean(v)) for k,v in [('reuse_minus_B',A-B),('B_minus_volume',B-V),
                   ('volume_minus_broken',V-L),('broken_minus_8',L-8),('reuse_minus_expected_B',A-expected),
                   ('expected_B_minus_volume',expected-V),('B_minus_expected_B',B-expected),
                   ('split_A_minus_8',A-8),('split_B_minus_8',B-8)]}
            assert abs(sum(means[k] for k in ('reuse_minus_B','B_minus_volume','volume_minus_broken','broken_minus_8'))-means['split_A_minus_8'])<1e-12
            assert np.all(L<=8+1e-11)
            errors.append(dict(model=g,nu=nu,resolved=int(resolved.sum()),ties=int((get('ties')>1).sum()),**means,
                    SE_reuse_minus_B=float(np.std(A-B,ddof=1)/np.sqrt(len(B))),
                    q95_proper_loss=float(np.quantile(8-L,.95)),
                    B_near_broken=float(np.mean(abs(B-L)<=.2)),
                    B_near_original=float(np.mean(abs(B-8)<=.2))))
            if g=='flat':
                # If a non-resolved row is present, regenerate A for its (geometry, density, replicate).
                oracle=columns(rows,'oracle_min')
                for j in np.flatnonzero(np.isnan(oracle)):
                    from experiment import cloud
                    rng=np.random.default_rng(np.random.SeedSequence([2026110337,0,NU.index(nu),int(rows[j]['rep'])]).spawn(3)[0])
                    x=cloud(g,rho,rng)
                    oracle[j]=(float(np.sqrt(np.maximum(0,np.minimum(x[:,0],T-x[:,0])**2-(x[:,1:]**2).sum(axis=1))).max()) if len(x) else 0.)
                good=int((oracle>=3.95).sum()); chosen=int((np.minimum(get('tau1'),get('tau2'))>=3.95).sum())
                prob=-math.expm1(-rho*W)
                assert chosen<=good
                supply.append(dict(nu=nu,n=n,W=W,theory=prob,available=good,chosen=chosen,
                                   binomial_p=binomtest(good,n,prob).pvalue))
            from experiment import interval_volume,eta
            ref=rho*interval_volume(0,float(eta(T,g)),0,g)
            for proc in ('nA','nB'):
                data=columns(rows,proc)
                z=(np.mean(data)-ref)/math.sqrt(ref/n)
                assert abs(z)<6
                calibration.append(dict(model=g,nu=nu,process=proc,mean=float(np.mean(data)),expected=ref,z=z))
    write_table('gates.csv',gates);write_table('errors.csv',errors)
    write_table('supply.csv',supply);write_table('calibration.csv',calibration)
    print('10 cells, 30 gate probabilities')

if __name__=='__main__':main()
