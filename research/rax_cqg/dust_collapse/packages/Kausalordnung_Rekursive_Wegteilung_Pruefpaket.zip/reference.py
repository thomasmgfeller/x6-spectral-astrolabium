"""Select by strict order; evaluate on the same and a fresh Poisson realization."""
from pathlib import Path
import math,ctypes,os,subprocess
import numpy as np
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parent
T=8.;C=math.pi/24
GL,GW=np.polynomial.legendre.leggauss(24)
GV,WV=np.polynomial.legendre.leggauss(8)
def eta(t,geom):
    return np.asarray(t) if geom=='flat' else -36*np.expm1(np.log1p(-np.asarray(t)/12)/3)
def back(e,geom):return e if geom=='flat' else -12*np.expm1(3*np.log1p(-np.asarray(e)/36))
def omega(e,geom):return 1. if geom=='flat' else (1-np.asarray(e)/36)**2

def density(nu):
    return nu/(C*(T/2)**4)

def cloud(geom,rho,rng):
    # The conformal Minkowski proposal has volume C*H**4. Dust uses a^4 thinning.
    H=float(eta(T,geom));n=rng.poisson(rho*C*H**4)
    # The slice volume scales as radius cubed on either side of the diamond.
    radius=H/2*rng.random(n)**.25;e=np.where(rng.random(n)<.5,radius,H-radius)
    xyz=rng.normal(size=(n,3));xyz/=np.linalg.norm(xyz,axis=1)[:,None]
    xyz*= (radius*rng.random(n)**(1/3))[:,None]
    x=np.column_stack((e,xyz))
    return np.ascontiguousarray(x[rng.random(n)<omega(e,geom)**4]) if geom=='dust' else x

def build():
    target=ROOT/f'midpoint.{os.getpid()}.tmp.so'
    try:
        subprocess.run(['c++','-std=c++17','-O3','-fPIC','-shared',str(ROOT/'select.cpp'),'-o',str(target)],check=True)
        target.replace(ROOT/'midpoint.so')
    finally:
        target.unlink(missing_ok=True)
def load():
    global lib
    lib=ctypes.CDLL(str(ROOT/'midpoint.so'))
    ar=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    lib.midpoint.argtypes=[ar,ar,ctypes.c_int,ctypes.c_double,np.ctypeslib.ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')]
    lib.midpoint.restype=None
def choose(x,mark,H):
    out=np.zeros(4,dtype='int32');lib.midpoint(x,mark,len(x),H,out);return tuple(int(v) for v in out)
def counts(x,m):
    diff=x-m;d=np.sum(diff[:,1:]**2,axis=1);timelike=d<diff[:,0]**2
    return int(np.count_nonzero(timelike&(diff[:,0]<0))),int(np.count_nonzero(timelike&(diff[:,0]>0)))
def interval_volume(e1,e2,d,geom):
    H=e2-e1
    if geom=='flat':return C*((H-d)*(H+d))**2
    # The smaller ball lies inside the larger one on the outer two slices.
    # In the middle their intersection is a spherical lens. Its area in 3D
    # times the dust volume factor is polynomial of degree at most eleven.
    knots=[0.,(H-d)/2,(H+d)/2,H]
    total=0.
    for j,(a,b) in enumerate(zip(knots,knots[1:])):
        if b<=a:continue
        s=(a+b)/2+(b-a)*GV/2
        if j==0:area=4*math.pi/3*s**3
        elif j==2:area=4*math.pi/3*(H-s)**3
        else:area=math.pi/12*(H-d)**2*(2*H+d-3*d*GV**2)
        total+=(b-a)/2*np.dot(WV,area*omega(e1+s,geom)**4)
    return float(total)
def geodesic(e1,e2,d,geom):
    H=e2-e1
    if geom=='flat':return math.sqrt((H-d)*(H+d))
    if d==0:return float(back(e2,geom)-back(e1,geom))
    e=(e1+e2)/2+H*GL/2;a=omega(e,geom)
    distance=lambda p:H/2*np.dot(GW,p/np.hypot(p,a))
    # This upper bound gives at least d in the same quadrature as distance().
    top=float(a.max()*d/math.sqrt((H-d)*(H+d))*1.001)
    p=brentq(lambda v:distance(v)-d,0,top,xtol=1e-13)
    return float(H/2*np.dot(GW,a*a/np.hypot(a,p)))
def phi(n,rho):return (n/(rho*C))**.25
