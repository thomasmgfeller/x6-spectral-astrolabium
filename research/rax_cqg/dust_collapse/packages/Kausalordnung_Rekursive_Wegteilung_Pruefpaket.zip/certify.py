"""Outward-rounded all-phase interference test for the single-defect finite model."""
from fractions import Fraction as F
from math import isqrt,factorial
from itertools import combinations
from collections import Counter
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
S=10**15
def ceil(n,d):return -((-n)//d)
def bound(x):
    x=F(x)
    return (x.numerator*S//x.denominator,ceil(x.numerator*S,x.denominator))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def mul(a,b):
    vals=[v*w for v in a for w in b]
    return (min(vals)//S,ceil(max(vals),S))
def root(a):
    assert a[0]>=0
    return (isqrt(a[0]*S),isqrt(a[1]*S)+1)
def plus(a,b):return (add(a[0],b[0]),add(a[1],b[1]))
def times(a,b):return (add(mul(a[0],b[0]),neg(mul(a[1],b[1]))),add(mul(a[0],b[1]),mul(a[1],b[0])))
def scale(z,s):return(mul(z[0],s),mul(z[1],s))
def rot(z):return(neg(z[1]),z[0])
def lower_mod(z):
    x,y=(max(a[0],-a[1],0) for a in z)
    return F(isqrt(x*x+y*y),S)
def upper_mod(z):
    x,y=(max(abs(a[0]),abs(a[1])) for a in z)
    return F(isqrt(x*x+y*y)+1,S)
def coefficient_table():
    c=Counter()
    for r in csv.DictReader((ROOT/'defect_histories.csv').open()):
        k=int(r['k']);j=int(r['Q'])%5;T=[F(1)]
        for s in ('r0','r1','r2'):
            p=F(r[s]);U=[F(0)]*(len(T)+1)
            for h,v in enumerate(T):
                U[h]+=v*(1-p);U[h+1]+=v*p
            T=U
        weight=F(1,int(r['ways'])*factorial(k)*factorial(4-k))
        for h,v in enumerate(T):c[k,h,j]+=v*weight
    return c
def main():
    c=coefficient_table()
    v=root(bound(5));quarter=bound(F(1,4))
    unity=(bound(1),bound(0))
    zeta=(mul(neg(add(bound(1),v)),quarter),mul(root(add(bound(10),neg(mul(bound(2),v)))),quarter))
    roots=[unity]
    for _ in range(4):roots.append(times(roots[-1],zeta))
    coeff={};lip={}
    for k in (1,2,3):
        coeff[k]=[]
        for h in range(4):
            term=(bound(0),bound(0))
            for j in range(5):term=plus(term,scale(roots[j],bound(c[k,h,j])))
            coeff[k].append(term)
        lip[k]=sum(h*c[k,h,j] for h in range(4) for j in range(5))
    leaves=[]
    for quadrant in range(4):
        stack=[(F(0),F(1),0)]
        while stack:
            lo,hi,depth=stack.pop();u=(lo+hi)/2
            z=(bound((1-u*u)/(1+u*u)),bound(2*u/(1+u*u)))
            for _ in range(quadrant):z=rot(z)
            low={};up={}
            for k in (1,2,3):
                val=coeff[k][-1]
                for t in reversed(coeff[k][:-1]):val=plus(times(val,z),t)
                allowance=lip[k]*(hi-lo)
                low[k]=max(F(0),lower_mod(val)-allowance)
                up[k]=upper_mod(val)+allowance
            diag=sum(t*t for t in up.values())
            ratio=max(2*low[i]*low[j]/diag for i,j in combinations(low,2))
            if ratio>F(1,21) or depth==12:
                leaves.append(dict(quadrant=quadrant,lo=str(lo),hi=str(hi),epsilon_lower=str(ratio),
                                   certified=int(ratio>F(1,21)),depth=depth))
            else:stack.extend([(lo,u,depth+1),(u,hi,depth+1)])
    for j in range(4):
        boxes=sorted((F(x['lo']),F(x['hi'])) for x in leaves if x['quadrant']==j)
        assert boxes[0][0]==0 and boxes[-1][1]==1 and all(a[1]==b[0] for a,b in zip(boxes,boxes[1:]))
    with (ROOT/'phase_arcs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=leaves[0],lineterminator='\n');w.writeheader();w.writerows(leaves)
    out=dict(arcs=len(leaves),certified=sum(r['certified'] for r in leaves),max_depth=max(r['depth'] for r in leaves),
             global_lower=float(min(F(r['epsilon_lower']) for r in leaves)),required=1/21)
    (ROOT/'phase_certificate.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
