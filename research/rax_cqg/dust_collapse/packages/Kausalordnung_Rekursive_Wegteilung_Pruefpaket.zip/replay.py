"""Regenerate selected complete same-seed replicates independently of the main run."""
import argparse,csv,json
from pathlib import Path
from run import ROOT,PLAN,trial
import reference as ref

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--save',type=Path)
    p.add_argument('--compare',type=Path)
    opts=p.parse_args()
    if opts.compare:
        new=json.loads(opts.compare.read_text())
    else:
        ref.build();ref.load()
        new=[{k:str(v) for k,v in trial((nu,i)).items()} for nu in PLAN['nu'] for i in (0,127,255)]
    if opts.save:opts.save.write_text(json.dumps(new));return
    rows={(r['nu'],r['rep']):r for r in csv.DictReader((ROOT/'runs.csv').open())}
    for r in new:
        old=rows[r['nu'],r['rep']]
        assert all(old[k]==s for k,s in r.items()) and all(v=='' or k in r for k,v in old.items())
    print('Six full raw rows reproduced.')
if __name__=='__main__':main()
