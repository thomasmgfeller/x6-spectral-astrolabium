"""Externally fixed quarters, deterministic large-density limits, and small-cloud order checks."""
import json
import numpy as np
from scipy.optimize import brentq
from run import ROOT,PLAN,G,cut,between,past,future,geometry,phases,gate,cell_counts
import reference as ref

def axis(t):return np.array([float(ref.eta(t,G)),0.,0.,0.])
def split(a,b):
    left,right=a[0],b[0]
    v=lambda e,f:ref.interval_volume(e,f,0.,G)
    m=brentq(lambda e:v(left,e)-v(e,right),left,right)
    return np.array([m,0.,0.,0.])

def direct(x,marks):
    if not len(x):return None
    scores=[]
    for row in x:
        low,high=ref.counts(x,row);scores.append(min(low,high))
    best=max(scores)
    if not best:return None
    choices=np.flatnonzero(np.array(scores)==best)
    return x[choices[np.argmin(marks[choices])]]

def main():
    ref.build();ref.load()
    p,q=axis(0),axis(8);mid=split(p,q);ordered=[p,split(p,mid),mid,split(mid,q),q]
    cells,L2,L4=geometry(ordered)
    limits=np.array(phases(cells,1.))
    assert gate(limits[1],limits[2]) and abs(L2-8)<1e-10 and abs(L4-8)<1e-10
    fixed=[axis(t) for t in (0,2,4,6,8)]
    cells0,*_=geometry(fixed);external=[]
    for nu in PLAN['nu']:
        rho=ref.density(nu);rng=np.random.default_rng(np.random.SeedSequence([2026110385,nu]))
        counts=rng.poisson(rho*cells0,size=(32768,7))
        half=counts[:,:4].reshape(-1,2,2).sum(axis=2)+counts[:,4:6]
        p2=ref.phi(half,rho).sum(axis=1);p4=ref.phi(counts[:,:4],rho).sum(axis=1)
        hits=((abs(p4-p2)<=.10)&(abs(p4-8)<=.20)&(abs(p2-8)<=.20))
        external.append(dict(nu=nu,n=len(hits),hits=int(hits.sum())))
    rng=np.random.default_rng(2026110386);tested=0;resolved=0
    for _ in range(48):
        A=ref.cloud(G,256/ref.interval_volume(p[0],q[0],0,G),rng);marks=rng.random(len(A))
        Y=ref.cloud(G,256/ref.interval_volume(0,q[0],0,G),rng)
        todo=[(A,marks,p,q)];nodes=[]
        for ix in range(3):
            if not todo:break
            cloud,labels,a,b=todo.pop(0)
            result=cut(cloud,labels,a,b);oracle=direct(cloud,labels);tested+=1
            assert (result is None)==(oracle is None)
            if oracle is None:continue
            m=result[0];assert np.array_equal(oracle,m)
            perm=rng.permutation(len(cloud));assert np.array_equal(cut(cloud[perm],labels[perm],a,b)[0],m)
            nodes.append(m)
            if ix==0:
                for mask,lo,hi in [(past(cloud,m),a,m),(future(cloud,m),m,b)]:
                    todo.append((cloud[mask],labels[mask],lo,hi))
        if len(nodes)==3:
            m,v,w=nodes;path=[p,v,m,w,q]
            c=cell_counts(Y,path);assert min(c)>=0 and c.sum()==len(Y)
            mask=[between(Y,a,b) for a,b in zip(path,path[1:])]
            assert all(not np.any(mask[a]&mask[b]) for a in range(4) for b in range(a))
            resolved+=1
    out=dict(limit_times=[float(ref.back(x[0],G)) for x in ordered],limiting_phases=limits.tolist(),
             marked_controls=external,brute_subproblems=tested,complete_small_paths=resolved)
    (ROOT/'controls.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out)
if __name__=='__main__':main()
