"""Recursive midpoint selection in one cloud; evaluate nested counts on an independent cloud."""
import csv
import json
import os
from multiprocessing import Pool
from pathlib import Path
import numpy as np
import reference as ref

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'design.json').read_text())
G='dust'

def future(points, anchor):
    delta=points-anchor
    return (delta[:,0]>0) & (np.einsum('ij,ij->i',delta[:,1:],delta[:,1:])<delta[:,0]**2)

def past(points, anchor):
    delta=points-anchor
    return (delta[:,0]<0) & (np.einsum('ij,ij->i',delta[:,1:],delta[:,1:])<delta[:,0]**2)

def between(points,a,b):
    return future(points,a) & past(points,b)

def cut(x,marks,a,b):
    # Translation only seeds the exact search. The maximin score uses the induced order.
    local=np.ascontiguousarray(x-a)
    idx,l,r,t=ref.choose(local,np.ascontiguousarray(marks),float(b[0]-a[0]))
    if idx<0 or min(l,r)==0:return None
    assert ref.counts(x,x[idx])==(l,r)
    return x[idx],l,r,t

def stats(a,b):
    d=float(np.linalg.norm(a[1:]-b[1:]))
    return (ref.interval_volume(a[0],b[0],d,G),ref.geodesic(a[0],b[0],d,G))

def geometry(nodes):
    fine=[stats(a,b) for a,b in zip(nodes,nodes[1:])]
    coarse=[stats(nodes[i],nodes[i+2]) for i in (0,2)]
    full=stats(nodes[0],nodes[-1])[0]
    volumes=np.array([v for v,t in fine])
    halves=np.array([v for v,t in coarse])
    cells=np.r_[volumes,halves-volumes.reshape(2,2).sum(axis=1),full-halves.sum()]
    assert min(cells)>=0 and abs(cells.sum()-full)<1e-9
    return cells,np.sum([t for v,t in coarse]),np.sum([t for v,t in fine])

def phases(cells,rho):
    counts=np.asarray(cells)
    p1=ref.phi(counts.sum(),rho)
    p2=ref.phi(counts[:4].reshape(2,2).sum(axis=1)+counts[4:6],rho).sum()
    p4=ref.phi(counts[:4],rho).sum()
    return p1,p2,p4

def gate(a,b):
    return abs(b-a)<=.10 and max(abs(a-8),abs(b-8))<=.20

def cell_counts(cloud,nodes):
    parent=[between(cloud,nodes[i],nodes[i+2]).sum() for i in (0,2)]
    fine=np.array([between(cloud,a,b).sum() for a,b in zip(nodes,nodes[1:])])
    return np.r_[fine,np.asarray(parent)-fine.reshape(2,2).sum(axis=1),len(cloud)-sum(parent)]

def trial(task,explicit=False):
    nu,i=task;rho=ref.density(nu)
    seeds=np.random.SeedSequence([PLAN['seed'],nu,i]).spawn(4)
    x=ref.cloud(G,rho,np.random.default_rng(seeds[0]))
    marks=np.random.default_rng(seeds[1]).random(len(x))
    p=np.zeros(4);q=np.array([float(ref.eta(8,G)),0.,0.,0.])
    row=dict(nu=nu,rep=i,nA=len(x),resolved=0,hit=0)
    mid=cut(x,marks,p,q)
    if mid is None:return row
    m,l,r,t=mid
    left=past(x,m);right=future(x,m)
    assert left.sum()==l and right.sum()==r
    leftcut=cut(x[left],marks[left],p,m)
    rightcut=cut(x[right],marks[right],m,q)
    if leftcut is None or rightcut is None:return row
    v,ll,lr,lt=leftcut;w,rl,rr,rt=rightcut
    nodes=[p,v,m,w,q]
    cells,L2,L4=geometry(nodes)
    B=np.random.default_rng(seeds[2]).poisson(rho*cells)
    b1,b2,b4=phases(B,rho)
    assert L4<=L2+1e-10 and L2<=8+1e-10
    row.update(resolved=1,hit=int(gate(b2,b4)),stable=int(abs(b4-b2)<=.10),
          accurate=int(max(abs(b4-8),abs(b2-8))<=.20),first=int(gate(b1,b2)),
          L2=L2,L4=L4,volume2=phases(cells,1.)[1],volume4=phases(cells,1.)[2],
          A2=ref.phi(l,rho)+ref.phi(r,rho),A4=sum(ref.phi(j,rho) for j in (ll,lr,rl,rr)),
          B1=b1,B2=b2,B4=b4,ties_root=t,ties_left=lt,ties_right=rt)
    for k,middle in zip(('left','root','right'),nodes[1:4]):
        for name,value in zip(('eta','x','y','z'),middle):row[k+'_'+name]=float(value)
    for j,(volume,n) in enumerate(zip(cells,B),1):
        row[f'V{j}']=float(volume);row[f'N{j}']=int(n)
    for k,value in zip(('l','r','ll','lr','rl','rr'),(l,r,ll,lr,rl,rr)):row['nA_'+k]=int(value)
    if explicit:
        Y=ref.cloud(G,rho,np.random.default_rng(seeds[3]))
        exact=cell_counts(Y,nodes)
        assert np.all(exact>=0) and exact.sum()==len(Y)
        return row,exact
    return row

def write(name,rows):
    with (ROOT/name).open('w',newline='') as s:
        w=csv.DictWriter(s,fieldnames=list(dict.fromkeys(k for row in rows for k in row)),lineterminator='\n')
        w.writeheader();w.writerows(rows)

def main():
    ref.build()
    tasks=[(nu,i) for nu in PLAN['nu'] for i in range(PLAN['n'])]
    rows=[]
    with Pool(int(os.getenv('RECURSIVE_WORKERS','7')),initializer=ref.load) as pool:
        for row in pool.imap(trial,tasks):
            rows.append(row)
            if len(rows)%64==0:print('Completed',len(rows),'of',len(tasks),flush=True)
    write('runs.csv',rows)
if __name__=='__main__':main()
