"""Score the predeclared two-to-four gate and separate length, volume and count effects."""
import csv,json
import numpy as np
from scipy.stats import beta
from run import ROOT,PLAN,phases,gate,geometry,cell_counts
import reference as ref

def main():
    rows=list(csv.DictReader((ROOT/'runs.csv').open()))
    assert len(rows)==len(PLAN['nu'])*PLAN['n'] and len({(r['nu'],r['rep']) for r in rows})==len(rows)
    results=[]; calibration=[]
    for nu in PLAN['nu']:
        group=[r for r in rows if int(r['nu'])==nu];n=len(group);assert n==PLAN['n']
        good=[r for r in group if r['resolved']=='1']
        h=lambda k:np.array([float(r[k]) for r in good])
        k=sum(int(r['hit']) for r in group)
        tail=.01/(2*len(PLAN['nu']))
        lo=float(beta.ppf(tail,k,n-k+1)) if k else 0.
        hi=float(beta.isf(tail,k+1,n-k)) if k<n else 1.
        rho=ref.density(nu)
        for r in good:
            b=np.array([int(r[f'N{i+1}']) for i in range(7)])
            ph=phases(b,rho)
            assert max(abs(ph[i]-float(r[f'B{level}'])) for i,level in enumerate([1,2,4]))<1e-11
            assert gate(ph[1],ph[2])==bool(int(r['hit']))
        a2,a4=h('A2'),h('A4');b2,b4=h('B2'),h('B4')
        g2,g4=h('volume2'),h('volume4');L2,L4=h('L2'),h('L4')
        terms=[(L4-L2).mean(),((g4-L4)-(g2-L2)).mean(),((b4-g4)-(b2-g2)).mean()]
        assert abs(sum(terms)-(b4-b2).mean())<1e-11
        results.append(dict(nu=nu,n=n,resolved=len(good),hits=k,rate=k/n,lo=lo,hi=hi,
               result='pass' if lo>=.95 else 'fail' if hi<.95 else 'undecided',
               stable=int(h('stable').sum()),accurate=int(h('accurate').sum()),first=int(h('first').sum()),
               both=int(sum(int(r['first'])*int(r['hit']) for r in good)),
               reuse=int(sum(gate(a,b) for a,b in zip(a2,a4))),
               movement=terms[0],geometry=terms[1],count=terms[2],mean_delta=float((b4-b2).mean()),
               proper_loss=float((8-L4).mean()),A4_minus_B4=float((a4-b4).mean()),
               fine_broken=int((abs(b4-L4)<=.2).sum()),fine_reference=int((abs(b4-8)<=.2).sum())))
        # First 24 seeds in each setting; no selection on success or outcome.
        exp=np.zeros(7);obs=np.zeros(7);direct=0;used=0
        for r in group[:24]:
            if r['resolved']!='1':continue
            nodes=[np.zeros(4)]+[np.array([float(r[k+'_'+s]) for s in ('eta','x','y','z')])
                for k in ('left','root','right')]+[np.array([float(ref.eta(8,'dust')),0.,0.,0.])]
            V,_,_=geometry(nodes)
            rng=np.random.default_rng(np.random.SeedSequence([2026110393,nu,int(r['rep'])]))
            cloud=ref.cloud('dust',rho,rng)
            samples=cell_counts(cloud,nodes)
            assert np.all(samples>=0) and samples.sum()==len(cloud)
            assert max(abs(V[j]-float(r[f'V{j+1}'])) for j in range(7))<1e-9
            exp+=rho*V;obs+=samples;_,p2,p4=phases(samples,rho);direct+=gate(p2,p4);used+=1
        calibration.append(dict(nu=nu,planned=24,resolved=used,direct_hits=int(direct),
              expected=exp.tolist(),observed=obs.tolist(),standardized=((obs-exp)/np.sqrt(exp)).tolist()))
    (ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    (ROOT/'explicit_B.json').write_text(json.dumps(calibration,indent=2)+'\n')
    for r in results: print(r)
if __name__=='__main__':main()
