# Von zwei auf vier Wegabschnitte

Die Hauptserie prüft die zweite rekursive Halbierung auf demselben vorgegebenen Staubhintergrund wie [PR 200](https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/200). Ein separater endlicher Modellversuch prüft, ob die Methode in der bisher untersuchten Kausalset-Summe einen späten Zählwert freigeben kann.

## Reproduktion

Python 3.12, NumPy 2.3.5, SciPy 1.17 und ein C++17-Compiler wurden verwendet. Die Punktwolkenrechnung beansprucht mehrere Prozessorkerne und ist bei kleinerer Parallelität entsprechend langsamer. Alle Rechnungen laufen offline. Die Anzahl der Prozesse kann mit RECURSIVE_WORKERS gesetzt werden. Alle Replikate werden in fester Reihenfolge ausgegeben. Zahlen im PDF sind gerundet. Für die Entscheidungen zählen die ungerundeten Grenzen.

    sha256sum -c SHA256SUMS
    export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
    python3 run.py
    python3 score.py
    python3 control.py
    python3 height.py
    python3 lift.py
    python3 defect.py
    python3 certify.py
    python3 replay.py
    sha256sum -c SHA256SUMS

Eine schnelle Kontrolle auf Basis der gelieferten Rohdaten beginnt mit score.py und lässt run.py und replay.py aus. Andere Versionen von Mathematikbibliotheken können letzte Gleitkommastellen ändern. Für das Neusetzen des Berichts genügt pdfLaTeX im Ordner paper. Das PDF gehört zum Archiv.

## Versuchsgrenzen

- design.json wurde vor den Ziehungen fixiert. SHA-256 ist `b5435bc01eef7aa5ed4260c2f6705988170857c16acdd06bf41a9c79eada8854`. Die alleinige bestätigende Familie besteht aus dem unabhängigen Zwei-auf-vier-Gesamttest bei zwei Dichten. Unaufgelöste Auswahl zählt als verfehlt. Die erste Teilung ist eine gepaarte Diagnose, keine Voraussetzung für den Zwei-auf-vier-Test.
- Die Hintergrunddichte in A und B ist jeweils nu/[(pi/24) 4^4]. Beide Prozesse kosten zusammen das Doppelte. Eine Einheit der angegebenen Referenzbesetzung entspricht dem mittleren Zählwert in einem flachen Halbintervall von vier Zeiteinheiten. Der Halteprozess B wird bei gewählten A-Punkten durch seine exakte gemeinsame Poisson-Zählverteilung realisiert.
- Das Höhenargument sowie lift_design.json und defect_design.json sind getrennte deterministische Modellversuche. Die beiden Designs wurden nacheinander vor der jeweiligen Modellrechnung festgelegt. Ihre SHA-256-Werte sind `85d46fd56ffaca9fc3bc9bdcae963fb0aaea9855c33753f79ef8eccb43172e70` und `87761d3498f5cbaf3c528d74cf3efe4b0727ad2614bb1f8e033ee0db67d0c3dc`. Das nachgeschaltete Interferenzzertifikat prüft alle reellen Materiephasenstärken bei der festgelegten Hauptkopplung. Es ist ein deterministischer Beweis, kein zusätzlicher statistischer Test.
- Die erweiterten endlichen Ordnungen sind neue mikroskopische Modelle. Der späte Zählwert k ist die Breite der ursprünglichen festgelegten Schicht, keine physisch kalibrierte Staubvolumenmessung. Die frühe Präparation, der normierte Strom, die geometrischen Klassengewichte und der gemeinsame Endkanal sind fixiert. Es wird keine Blindzielmessung behauptet.

## Daten und Implementierung

| Datei | Inhalt |
|---|---|
| `reference.py`, `select.cpp` | Punktwolke, FLRW-Geometrie und exakter beschleunigter Mittelpunktkern aus PR 200. Das Kontinuum stellt Referenz und Simulator. Die Auswahl maximiert die kleinere offene Intervallzählung über alle Kandidaten und nutzt einmal vergebene Zufallsprioritäten bei Gleichstand. |
| `run.py`, `runs.csv` | Drei ausgewählte Wegpunkte, A-Zählungen, sieben B-Zellvolumina V1…V7 und unabhängige Poisson-Zählwerte N1…N7, wahre Längen und gemessene Phasen. Zellen 1…4 sind die feinen Intervalle, 5 und 6 die beiden Halbreste, 7 der äussere Rest. B1, B2 und B4 stehen für Phasensummen, nicht für Zellzählungen. Startstrom `[2026110371, nu, rep]`, separate Seeds für Auswahl, Prioritäten und B. |
| `score.py`, `results.json`, `explicit_B.json` | Beide vorab bestimmten Binomialentscheidungen und deskriptive Diagnosen, mittlere Differenzzerlegung. Die ersten 24 Realisierungen je Dichte werden mit einer zusätzlichen expliziten Messwolke geprüft; die sieben Zellensummen werden gegen die bedingten Volumenerwartungen gehalten. |
| `control.py`, `controls.json` | Reine Ordnungsvergleiche in kleinen Wolken, externe Marken als separate Kontrolle mit 32768 frischen Messungen pro Dichte und numerische Grenzwerte auf der Achse. |
| `input/geometry_flux.csv`, `height.py`, `finite_height.csv` | Originale 75 Geometrien aus PR 197/198, SHA-256 `2b1e3373a2631a48ca9519dd76983c75897e3d1c24be620e87add2a6547ede86`. Endpunktsuche und Gegenprobe an Ketten mit 8, 9 und 10 Ereignissen. |
| `lift.py`, `lifted_histories.csv`, `lift_result.json` | Gleichmässig eingefügte Ereignisse, Routen, exakte Betragsquadrate in Q(sqrt(5)) und Ausschluss durch zwei konkurrierende Klassen. |
| `defect.py`, `defect_histories.csv`, `defect_result.json` | Ein zusätzliches Parallelereignis auf jeder zulässigen späteren Kante. Herkunftsgeometrie, eigener Gravitationszähler, rationale Auftreffwahrscheinlichkeiten von jeder Quelle, Zweigamplituden nach Abziehen der gemeinsamen Phase und Freigabeentscheidungen. |
| `certify.py`, `phase_arcs.csv`, `phase_certificate.json` | Rationale Koeffizienten aus den Routenwahrscheinlichkeiten, alle vier Quadranten der Phase mit lückenlos überdeckenden rationalen Teilbögen, exakte untere Interferenzschranken. Ganzzahlintervalle runden nach aussen. Das Verfahren zur Kreisbedeckung entspricht dem veröffentlichten Zweiblock-Zertifikat aus PR 198. |
| `replay.py` | Wiederholt die vollständigen Einzelrealisierungen 0, 127 und 255 je Dichte und vergleicht jedes gespeicherte Feld. |

Die hier ausgeführten Rechnungen unterscheiden zwischen einem Messergebnis auf einem vorgegebenen Hintergrund und der Aussage der endlichen dynamischen Modellfamilie. Der Beweis der Singularitätsauflösung und die Ableitung einer vierdimensionalen Staubbewegung bleiben offen.
