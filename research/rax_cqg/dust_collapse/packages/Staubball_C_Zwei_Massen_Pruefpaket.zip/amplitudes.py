"""Interval test of mass dependence in the archived family C amplitude polynomials."""
import csv
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from flint import acb, arb, ctx

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'inputs'
SIGNATURES = (0, 1, 2, 4, 7)
PLAN = 'ca4a60f8b854b4ad2ea3f3011a9daab91b5196db07b388afaa6a0a5a924c4660'


def inputs():
    if hashlib.sha256((ROOT/'design.json').read_bytes()).hexdigest() != PLAN:
        raise ValueError('Test design hash mismatch')
    for item in json.loads((DATA/'provenance.json').read_text()):
        if hashlib.sha256((DATA/item['local']).read_bytes()).hexdigest() != item['sha256']:
            raise ValueError(item['local'])
    tables = {}
    for file, tag, weight in [('symmetry_orbit.csv','measure','weight'),('growth.csv','scenario','conditional_weight')]:
        with (DATA/file).open() as stream:
            for row in csv.DictReader(stream):
                name = row[tag]
                if name not in ('symmetry','orbit','p_half_flat'):
                    continue
                key = tuple(int(row[k]) for k in ('k','signature','h','residue'))
                tables.setdefault(name,{})[key]=Fraction(row[weight])
    for name,table in tables.items():
        norm = sum(table.values())
        if len(table)!=230 or not all(x>0 for x in table.values()):
            raise ValueError('Coefficient support')
        tables[name] = {k:v/norm for k,v in table.items()}
    if set(tables)!={'symmetry','orbit','p_half_flat'}:
        raise ValueError('Missing measure')
    return tables


def ball(f):
    f = Fraction(f)
    return arb(f.numerator)/f.denominator


def inner(x,y):
    return sum((a.conjugate()*b for a,b in zip(x,y)),acb(0))


def branches(table,eta,kind):
    p = arb.pi()
    delta = (48/p).root(4)-(24/p).root(4)
    matter = acb(0,-eta*delta).exp() if kind!='blind' else acb(1)
    gravity = acb(0,4*p/5).exp() if kind!='g_zero' else acb(1)
    bins = [[acb(0) for _ in SIGNATURES] for _ in range(3)]
    for (k,s,h,r),w in table.items():
        bins[k-1][SIGNATURES.index(s)] += ball(w)*gravity**r*matter**h
    return bins[0], [x+y for x,y in zip(bins[1],bins[2])]


def score(pair):
    u,v = pair
    u2,v2 = inner(u,u).real,inner(v,v).real
    norm = u2+v2
    if not norm>0:raise ValueError('Vanishing norm')
    return v2/norm,2*abs(inner(u,v))/norm


def projective(first,last):
    a,b = first[0]+first[1],last[0]+last[1]
    return 1-abs(inner(a,b))**2/(inner(a,a).real*inner(b,b).real)


def gate(q,eps):
    if q>=ball('4/5') and eps<=ball('1/21'): return 'PASS'
    if q<ball('4/5') or eps>ball('1/21'): return 'FAIL'
    return 'UNRESOLVED'


def run():
    ctx.prec=160
    end=json.loads((DATA/'old_endpoints.json').read_text())['cells']
    prev={'symmetry':end['00'],'orbit':end['11'],'p_half_flat':json.loads((DATA/'old_growth.json').read_text())['results']['p_half_flat']['scores']['primary']}
    results={}
    for name,table in inputs().items():
        modes={}
        for mode in ('full','g_zero','blind'):
            pairs = {eta:branches(table,eta,mode) for eta in (1,4,2)}
            scores={eta:score(pair) for eta,pair in pairs.items()}
            dist=projective(pairs[1],pairs[4])
            if mode=='full':
                for x,field in zip(scores[1],('q23','epsilon')):
                    lo,hi=map(ball,prev[name][field])
                    if not (lo<=x<=hi):raise ValueError('Old result mismatch')
            if mode=='blind' and (not dist.contains(0) or not all(x.overlaps(y) for x,y in zip(scores[1],scores[4]))):
                raise ValueError('Blind control')
            modes[mode]=dict(scores={str(m):dict(q23=str(q),epsilon=str(e),gate=gate(q,e)) for m,(q,e) in scores.items()},
                             distance=str(dist),delta_q=str(scores[4][0]-scores[1][0]),
                             delta_eps=str(scores[4][1]-scores[1][1]),nonproportional=bool(dist>0))
        results[name]=modes
    return dict(plan=PLAN,bits=160,reference_geometry='HOLD_NO_ORBIT_WEIGHTS',results=results)


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
