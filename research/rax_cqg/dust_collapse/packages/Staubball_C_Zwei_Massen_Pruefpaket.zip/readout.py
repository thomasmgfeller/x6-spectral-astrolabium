"""Single-realization counter calibration on prescribed GR backgrounds; no history dynamics."""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.stats import beta

ROOT=Path(__file__).resolve().parent
TIMES=np.array([0.,1/8,1/4])
COUNT=256
TOL=0.05


def mean_count(rho,width,centre,m):
    # Exact integral as a polynomial before floating-point evaluation.
    return rho*width*((1-np.sqrt(m)*centre)**2+m*width**2/12)


def summarize(core,wing,rho,h,m):
    estimate=(7*core-wing)/(3*rho*h)
    good_row=np.all(estimate>0,axis=1)
    y=np.sqrt(estimate.clip(min=0))
    differences=y[:,1:]-y[:,:1]+np.sqrt(m)*TIMES[None,1:]
    hits=int(np.sum(good_row & np.all(abs(differences)<=TOL,axis=1)))
    tail=.05/(2*6)
    lo=0.0 if hits==0 else float(beta.ppf(tail,hits,COUNT-hits+1))
    hi=1.0 if hits==COUNT else float(beta.isf(tail,hits+1,COUNT-hits))
    classification='PASS' if lo>=.95 else 'FAIL' if hi<.95 else 'UNRESOLVED'
    return dict(hits=hits,trials=COUNT,nonpositive_rows=int(np.sum(~good_row)),
                success_interval=[lo,hi],decision=classification,
                max_abs_residual=float(abs(differences[good_row]).max()))


def run():
    results={}
    with (ROOT/'readout_counts.csv').open('w',newline='') as stream:
        wr=csv.writer(stream,lineterminator='\n')
        wr.writerow(['mass_ratio','level','realization','time_eighths','core','wing'])
        for m in (1,4,2):
            settings={}
            for level,(rho,h) in enumerate(((2**16,1/32),(2**18,1/64))):
                full=mean_count(rho,h,TIMES,m)
                inner=mean_count(rho,h/2,TIMES,m)
                wing=full-inner
                assert np.allclose((7*inner-wing)/(3*rho*h),(1-np.sqrt(m)*TIMES)**2,
                                   rtol=0,atol=5e-15)
                rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([2026110431,m,level])))
                core_draw=rng.poisson(inner,(COUNT,len(TIMES)))
                wing_draw=rng.poisson(wing,(COUNT,len(TIMES)))
                for i in range(COUNT):
                    for t in range(len(TIMES)):
                        wr.writerow([m,level,i,t,core_draw[i,t],wing_draw[i,t]])
                settings[str(level)]=dict(rho=rho,h=h,**summarize(core_draw,wing_draw,rho,h,m))
            results[str(m)]=settings
    return dict(times=TIMES.tolist(),absolute_tolerance=TOL,simultaneous_confidence=.95,results=results)


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
