"""Independent outward fixed-point intervals; compute noncollinearity via all minors."""
from collections import defaultdict
import csv
from fractions import Fraction as F
import json
from math import factorial
from pathlib import Path
import sys

from flint import arb, ctx
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'inputs'))
from bounds import S, bound, plus, add, neg, mul, root, times, scale, lower_mod, upper_mod

ZERO=(bound(0),bound(0))
ONE=(bound(1),bound(0))


def powers(z,n):
    out=[ONE]
    for _ in range(n):
        out.append(times(out[-1],z))
    return out


def phase_bases():
    def atan_reciprocal(n):
        s=sum(F((-1)**j,(2*j+1)*n**(2*j+1)) for j in range(20))
        return s,s+F(1,41*n**41)
    a,b=atan_reciprocal(5)
    c,d=atan_reciprocal(239)
    plo,phi=16*a-4*d,16*b-4*c
    length=root(root((bound(F(24)/phi)[0],bound(F(24)/plo)[1])))
    delta=mul(length,add(root(root(bound(2))),neg(bound(1))))
    assert 0 < delta[0] <= delta[1] < S
    factor=(bound(0),neg(delta))
    series=ZERO
    for j,term in enumerate(powers(factor,18)):
        series=plus(series,scale(term,bound(F(1,factorial(j)))))
    rem=bound(F(1,factorial(19)))[1]
    z=tuple((lo-rem,hi+rem) for lo,hi in series)
    sqrt5=root(bound(5))
    g=(mul(neg(add(bound(1),sqrt5)),bound(F(1,4))),
       mul(root(add(bound(10),neg(mul(bound(2),sqrt5)))),bound(F(1,4))))
    return powers(z,12),powers(g,4)


def class_vectors(rows,eta,mode,phase,gravity):
    weights=[F(r.get('weight') or r['conditional_weight']) for r in rows]
    total=sum(weights)
    bins=defaultdict(lambda:ZERO)
    for r,w in zip(rows,weights):
        key=(int(r['k'])!=1,int(r['signature']))
        mat=phase[0 if mode=='blind' else eta*int(r['h'])]
        grav=gravity[0 if mode=='g_zero' else int(r['residue'])]
        bins[key]=plus(bins[key],scale(times(mat,grav),bound(w/total)))
    return [bins[group,s] for group in (False,True) for s in (0,1,2,4,7)]


def mod2(z):
    return lower_mod(z)**2,upper_mod(z)**2


def sum_norm(v):
    terms=[mod2(z) for z in v]
    return sum(x for x,_ in terms),sum(y for _,y in terms)


def ratio(x,y):
    assert y[0]>0
    return x[0]/y[1],x[1]/y[0]


def record(interval, expected):
    lo,hi=interval
    a=arb(lo.numerator)/lo.denominator
    b=arb(hi.numerator)/hi.denominator
    assert a<arb(expected)<b
    return [str(lo),str(hi)]


def run():
    ctx.prec=192
    base=json.loads((ROOT/'amplitudes.json').read_text())['results']
    rows=defaultdict(list)
    for file in ('symmetry_orbit.csv','growth.csv'):
        with (ROOT/'inputs'/file).open() as stream:
            for r in csv.DictReader(stream): rows[r.get('measure') or r['scenario']].append(r)
    phases,gravity=phase_bases()
    audit={}
    for name,modes in base.items():
        audit[name]={}
        for mode,ref in modes.items():
            vectors={}
            by_mass={}
            for mass in (1,2,4):
                vec=class_vectors(rows[name],mass,mode,phases,gravity)
                vectors[mass]=vec
                total=sum_norm(vec);cross=ZERO
                for u,v in zip(vec[:5],vec[5:]):
                    cross=plus(cross,times(u,(v[0],neg(v[1]))))
                score=ref['scores'][str(mass)]
                by_mass[str(mass)]={'q23':record(ratio(sum_norm(vec[5:]),total),score['q23']),
                                     'epsilon':record(ratio((2*lower_mod(cross),2*upper_mod(cross)),total),score['epsilon'])}
            a,b=vectors[1],vectors[4]
            minors=[]
            for i in range(len(a)):
                for j in range(i+1,len(a)):
                    x,y=times(a[j],b[i])
                    minors.append(plus(times(a[i],b[j]),(neg(x),neg(y))))
            n1,n4=sum_norm(a),sum_norm(b)
            d=ratio(sum_norm(minors),(n1[0]*n4[0],n1[1]*n4[1]))
            if mode=='blind':
                assert d[0]==0 and arb(ref['distance']).contains(0) and a==b
                interval=list(map(str,d))
            else:
                assert d[0]>0
                interval=record(d,ref['distance'])
            audit[name][mode]=dict(scores=by_mass,distance=interval)
    return audit


if __name__=='__main__':
    if not __debug__:raise RuntimeError('Use Python without -O')
    print(json.dumps(run(),indent=2))
