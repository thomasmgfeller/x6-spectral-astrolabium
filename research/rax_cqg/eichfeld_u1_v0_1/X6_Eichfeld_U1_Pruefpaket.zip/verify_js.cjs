const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const data = process.argv[2] || 'data';
function lines(name) {
  return fs.readFileSync(path.join(data,name),'utf8').trim().split('\n').map(JSON.parse);
}
const math = vm.runInNewContext(fs.readFileSync('field_math.js','utf8')+'\n({predict4D,fourEvents})');
const cases = lines('cases.jsonl'), predictions = lines('predictions.jsonl');
const C = JSON.parse(fs.readFileSync(path.join(data,'calibration.json'))).C;
let worst = 0;
for (let i=0;i<cases.length;i++) {
  const expected=predictions[i], result=math.predict4D(cases[i],C);
  assert.equal(cases[i].id,expected.id);
  assert.equal(result.counts.join(','),expected.paths.join(','));
  assert.equal(result.J===null,expected.J===null);
  if (result.J!==null) worst=Math.max(worst,Math.abs(result.J-expected.J));
}
assert.ok(worst<1e-9);
for (const e of [0,-1.25,19,1]) for (const reverse of [true,false]) {
  assert.ok(math.fourEvents(e,[1.7,.1,.8,-2.2],reverse).residual<1e-12);
}
console.log(JSON.stringify({checked:cases.length,worst_abs_error:worst}));
