import json
from pathlib import Path
import sys


def build(data, out):
    def read(n):return json.loads((data/n).read_text())
    results=read('summary.json')['classes']
    table=[]
    for k,label in [('E','Elektrisch'),('B','Magnetisch')]:
        cells=[]
        for g in ['sign_hit','magnitude_hit']:
            row=results[k][g]
            cls='good' if row['decision']=='PASS' else 'bad'
            cells.append(f"<td class='{cls}'>{row['k']} / {results[k]['n']} · {row['decision']}</td>")
        table.append('<tr><th scope="row">'+label+'</th>'+''.join(cells)+'</tr>')
    records=dict(C=read('calibration.json')['C'],
                 cases=[json.loads(x) for x in (data/'cases.jsonl').read_text().splitlines()],
                 answers=[dict(J=g['J']) for g in read('sealed/key.json')])
    html=Path('ui.html').read_text()
    for key,body in [('TABLE',''.join(table)),('RECORDS',json.dumps(records,separators=(',',':'))),
                     ('MATH',Path('field_math.js').read_text()),('UI',Path('ui.js').read_text())]:
        html=html.replace('__'+key+'__',body)
    out.write_text(html)


if __name__=='__main__':
    build(Path(sys.argv[1]),Path(sys.argv[2]))
