# X6 Eichfeld-Labor 0.1

Zwei abgeschlossene Prüfungen auf festen endlichen Kausalordnungen. Die Datei `X6_Eichfeld_Labor.html` ist vollständig eigenständig und lässt sich nach dem Herunterladen im Browser öffnen. Links führen ausschliesslich zu freiwillig aufrufbaren Fachquellen. Die Seite berechnet die beiden Wegphasen sowie jede der 256 archivierten 4D-Vorhersagen lokal. Die Auswahl im Browser ist eine Wiedergabe des bereits aufgelösten Tests.

## Resultate

Der Vier-Ereignis-Vergleich stimmt in 6 144 Kombinationen aus lokaler Eichwahl und Umnummerierung bis 1,76 × 10⁻¹⁵ mit der kontinuierlichen Flussphase überein. Im Einzelordnungstest erreicht der eingefrorene Schätzer folgende Trefferzahlen. Je zwei Enthaltungen pro Feldtyp zählen als Fehlschläge.

| Feld | richtiges Vorzeichen von J | relativer Fehler von J höchstens 25 % |
| --- | --- | --- |
| Elektrisch | 65/128, FAIL | 1/128, FAIL |
| Magnetisch | 126/128, PASS | 86/128, FAIL |

Hier ist J = E² − B² die doppelte klassische Maxwell-Lagrangedichte in natürlichen Einheiten. Die angegebenen Vergleiche prüfen die Stärke von J. E und B bezeichnen in dieser Formel die Beträge der jeweiligen Feldvektoren. Das Gesamtverfahren verfehlt beide klassenübergreifenden Ziele. Die einfache, vorab festgelegte Regel mit nur D₂ erreicht 126/128 korrekte Feldtypen je Gruppe. Bei reinem B verschwindet die Zweischritt-Flussdifferenz wegen der speziellen Spitzengeometrie. Diese Vergleichsregel schätzt keine Feldstärke. Bei einem reinen elektrischen Feld verstärkt die ungünstige Differenz zweier grosser Beiträge die geometrische Streuung. Ein Nachfolger würde neue Kalibrierungs- und Testordnungen brauchen.

## Reproduktion

Getestet unter Linux mit Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 und Node.js. Der Python-Rechenkern benötigt keine GPU, keine API und keinen Rechendienst. Für identische letzte Float64-Stellen dieselbe numerische Umgebung verwenden. Der Browser braucht keine Zusatzpakete. Alle Befehle im entpackten Verzeichnis ausführen.

```sh
sha256sum -c SHA256SUMS
sha256sum -c frozen.sha256
export OPENBLAS_NUM_THREADS=1

# Ergebnis aus den fixierten Daten prüfen
python controls.py
python evaluate.py data
python audit.py
node verify_js.cjs data

# Vollständiger Replay in einem noch nicht vorhandenen Verzeichnis
python generate.py replay --seed "$(cat data/sealed/master.txt)"
python blind_run.py replay
cmp data/predictions.jsonl replay/predictions.jsonl
cmp data/sealed/key.json replay/sealed/key.json
python evaluate.py replay

# Eigenständige Browserdatei reproduzieren
python build_html.py data replay/X6_Eichfeld_Labor.html
cmp X6_Eichfeld_Labor.html replay/X6_Eichfeld_Labor.html
```

## Daten und Verblindung

- `design.json` definiert die beiden Pfadfamilien, feste Kalibrierung, Felder, Stichprobengrössen und Grenzen. `frozen.sha256` sichert die bei der Erzeugung fixierten Methoden.
- `generate.py` verwendet den unveränderten Sampler und die Hasse-Kanten des RAX-CQG-Benchmarks. Im festen 4D-Diamanten werden 64 Innenereignisse gezogen und zwei zeitartige Randspitzen hinzugefügt. Alle Holdout-Ordnungen verwenden voneinander und von der Kalibrierung getrennte Geometrie-Startwerte. Festgelegte Fenstergrösse und Dimension sind Teil des Modells.
- `data/calibration.json` enthält die feste Antwortmatrix C. Die Zeilen sind D₂/D₃, die Spalten Einheits-E/Einheits-B. Je Pfad ist P das Produkt seiner U(1)-Kantenvariablen. D ist die Stichprobenstreuung der komplexen Produkte mit Nenner n−1, äquivalent zu mittleren paarweisen Phasendifferenzen in der Metrik 1−cos.
- `data/cases.jsonl` enthält die 256 anonymisierten Eingaben. Jede Zeile enthält ID, Ereigniszahl und gerichtete Hasse-Kanten `[u,v,phase]` in Radiant. Die lokalen Phasen wurden zufällig transformiert. Der Vorhersageprozess erhält neben diesen Daten nur die bekannte Kalibrierung. Er läuft als eigener Prozess in einem neuen Arbeitsverzeichnis. Bei einer neuen synthetischen Prüfung ohne festen Seed erzeugt `generate.py` neue Systementropie.
- `data/commitments.json` bindet Eingaben, Kalibrierung, Lösungsschlüssel und Master-Seed vor der Vorhersage. `data/prediction_lock.json` bindet die Vorhersagen vor der Aufdeckung. Dies war eine innerhalb des Projekts ausgeführte Verblindung ohne externen Zeitstempel.
- `data/predictions.jsonl` enthält Vorhersagen, Merkmale, Wegzahlen und einfache Vergleichsregel. `data/sealed/` enthält die nach der Vorhersage freigegebenen Referenzen. `data/scores.csv` gibt alle Ergebnisse einschliesslich der vier Enthaltungen an. `data/summary.json` enthält exakte Binomialgrenzen mit Bonferroni-Absicherung für die vier primären Kriterien, bedingt auf C. Die 256 Zeilen sind die statistischen Einheiten.
- `controls.json`, `js_check.json` und `audit.json` dokumentieren unabhängige Zählung der Wegpaare, Eichwechsel, Umnummerierungen, Browser/Python-Parität, Binomialgrenzen und die nachträgliche Fehlerdiagnose. Diese Diagnose verändert keine Testentscheidung.
- `report.tex` ist die Druckquelle des deutschen Berichts. Mit pdfLaTeX und den dort deklarierten Paketen lässt sich das PDF neu setzen.

## Herkunft und wissenschaftliche Reichweite

`vendor/rax_cqg_twin.py` stammt aus dem RAX-CQG Causal-Set Benchmark 0.2.0 des X6 Spectral Astrolabium. Der Quellstand ist auf Git-Commit `070cc6a7a9adc9103d9253e2c95680b0c1adfb65` fixiert. Lizenz und Hinweise zu PCG32 liegen unter `vendor/`. Die neuen Python-/JavaScript-Quellen dieser Versuchsausgabe stehen unter Apache-2.0. [Quellstand auf GitHub](https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/070cc6a7a9adc9103d9253e2c95680b0c1adfb65/research/rax_cqg/benchmark-v0.2.0)

Die Holonomie-Idee hat publizierte Vorläufer. Der kalibrierte Schätzer aus D₂ und D₃ ist eine eigene Testkonstruktion. Diese Serie beurteilt konstante klassische Testfelder auf vorgegebener Geometrie. Ein Kontinuumlimes, eine Feldentwicklung, die Rückwirkung auf die Geometrie und eine quantengravitative Pfadsumme sind in dieser Ausgabe offen. [Sverdlov 2008](https://arxiv.org/abs/0807.2066) · [Sverdlov und Bombelli 2009](https://arxiv.org/abs/0905.1506)
