"""Independent polygon flux and direct-loop oracles. No holdout truth is needed."""
import itertools
import json
import numpy as np
from generate import geometry, planted, save
from estimator import features
from pathlib import Path


def stage_one():
    rng = np.random.default_rng(42139)
    v = np.array([[-.5,0.],[0.,-.2],[0.,.2],[.5,0.]])
    edges = [(0,1),(1,3),(0,2),(2,3)]
    max_gap = orient_gap = pure_gap = bad_gap = 0.
    for test in range(256):
        field = [0., 0.75, -1.25, 19.][test % 4]
        phi = rng.uniform(-np.pi,np.pi,4)
        alpha = np.array([.5*field*(v[i,0]*v[j,1]-v[i,1]*v[j,0])+phi[j]-phi[i] for i,j in edges])
        u = np.exp(1j*alpha)
        for p in itertools.permutations(range(4)):
            U = dict(zip([(p[i],p[j]) for i,j in edges], u))
            first = U[p[0],p[1]]*U[p[1],p[3]]
            second = U[p[0],p[2]]*U[p[2],p[3]]
            h = first*second.conjugate()
            expected = np.exp(1j*.2*field)
            max_gap=max(max_gap,abs(h-expected))
            orient_gap=max(orient_gap,abs(second*first.conjugate()-expected.conjugate()))
            if field==0: pure_gap=max(pure_gap,abs(h-1))
        bad_gap=max(bad_gap,abs(first*second-expected))
    injected=abs(np.exp(.27j)-1)
    assert max(max_gap,orient_gap,pure_gap)<1e-12 and bad_gap>.5 and injected>.25
    return dict(gauges=256,permutations_each=24,comparisons=256*24,max_flux_complex_error=float(max_gap),
                max_reversal_error=float(orient_gap),max_pure_gauge_error=float(pure_gap),
                wrong_conjugation_max_error=float(bad_gap),one_edge_fault_distance=float(injected))


def oracle(case):
    # Enumerate paths via dictionaries, then explicitly compare every distinct pair.
    edges={(int(i),int(j)):angle for i,j,angle in case['edges']}
    nodes=set(range(case['n']))
    start,=(nodes-{j for _,j in edges});end,=(nodes-{i for i,_ in edges})
    def visit(node,total,depth):
        if node==end:
            if depth in (2,3):allp[depth].append(total)
        elif depth<3:
            for (i,j),a in edges.items():
                if i==node:visit(j,total+a,depth+1)
    allp={2:[],3:[]}
    visit(start,0.,0)
    def pair_mean(values):
        return float(np.mean([2*np.sin((a-b)/2)**2 for a,b in itertools.combinations(values,2)]))
    return [pair_mean(allp[k]) for k in (2,3)]


def regressions():
    rng=np.random.default_rng(11855)
    max_oracle=max_gauge=0.
    for index in range(12):
        g=geometry(52400+index)
        n=len(g[0]);vec=rng.normal(size=3)
        kind='EB'[index%2]
        base=planted(g,kind,vec,'control',np.arange(n),np.zeros(n))
        case=planted(g,kind,vec,'control',rng.permutation(n),rng.uniform(-np.pi,np.pi,n))
        sizes,feat=features(case)
        if feat is None: continue
        max_oracle=max(max_oracle,float(np.max(np.abs(np.array(feat)-oracle(case)))))
        max_gauge=max(max_gauge,float(np.max(np.abs(np.array(feat)-features(base)[1]))))
    assert max_oracle<1e-12 and max_gauge<1e-12
    return dict(max_oracle_error=max_oracle,max_relabel_gauge_error=max_gauge)


if __name__=='__main__':
    save(Path('controls.json'),dict(diamond=stage_one(), paths=regressions()))
