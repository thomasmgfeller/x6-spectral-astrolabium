const $ = id => document.getElementById(id);
const num = (x,n=4) => x.toLocaleString('de-DE',{minimumFractionDigits:n,maximumFractionDigits:n});
const archive = JSON.parse($('records').textContent);
let gauge = [0,0,0,0], reversed = false, revealed = false;

function updateDiamond() {
  const field = Number($('field').value);
  const value = fourEvents(field,gauge,reversed);
  $('fval').textContent = num(field,2);
  $('flux').textContent = 'Gemessene Flussphase  '+num(value.measured)+' rad';
  $('expect').textContent = 'Analytische Referenz  '+num(value.reference)+' rad';
  $('open').textContent = 'Über a: '+num(value.left)+' rad · über b: '+num(value.right)+' rad';
  $('reverse').setAttribute('aria-pressed',String(reversed));
}

$('field').addEventListener('input',updateDiamond);
$('regauge').addEventListener('click',() => {
  gauge = Array.from({length:4},()=> (2*Math.random()-1)*Math.PI);
  updateDiamond();
});
$('zero').addEventListener('click',() => { $('field').value=0; updateDiamond(); });
$('reverse').addEventListener('click',() => { reversed=!reversed; updateDiamond(); });

for (let i=0;i<archive.cases.length;i++) {
  const item = document.createElement('option');
  item.value=i; item.textContent=String(i+1).padStart(3,'0')+' / '+archive.cases.length;
  $('case').append(item);
}
function updateCase() {
  const index=Number($('case').value);
  const value=predict4D(archive.cases[index],archive.C);
  const ref=archive.answers[index];
  $('blind').textContent = value.J===null ? 'Enthaltung · zu wenige Wege' : 'Geschätztes J = '+num(value.J);
  $('paths').textContent='Zweigliedrige Wege: '+value.counts[0]+' · dreigliedrige Wege: '+value.counts[1];
  $('reveal').setAttribute('aria-pressed',String(revealed));
  $('reveal').textContent=revealed ? 'Sollwert verbergen' : 'Sollwert aufdecken';
  $('gold').textContent=revealed ? (ref.J>0?'Elektrisch':'Magnetisch')+' · Sollwert J = '+num(ref.J)+(value.J===null?' · als Fehlschlag gezählt': ' · relativer Fehler '+num(100*Math.abs((value.J-ref.J)/ref.J),1)+' %') : 'Der Sollwert ist verborgen.';
}
$('case').addEventListener('change',()=>{revealed=false;updateCase();});
$('reveal').addEventListener('click',()=>{revealed=!revealed;updateCase();});
updateDiamond(); updateCase();
