"""Predict in a separate process and empty working directory; no gold, seeds, or generator copied."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(data):
    data=Path(data).resolve()
    commitments=json.loads((data/'commitments.json').read_text())
    for line in (ROOT/'frozen.sha256').read_text().splitlines():
        ref,name=line.split('  ',1)
        if digest(ROOT/name)!=ref:raise ValueError('Frozen method changed: '+name)
    for name in ('cases.jsonl','calibration.json'):
        if digest(data/name)!=commitments[name]:raise ValueError('Blind input changed')
    if (data/'prediction_lock.json').exists() or (data/'predictions.jsonl').exists():
        raise FileExistsError('Predictions already recorded. Use a new directory for a replay.')
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp)
        shutil.copyfile(ROOT/'estimator.py',work/'estimator.py')
        for name in ('cases.jsonl','calibration.json'):
            shutil.copyfile(data/name,work/name)
        subprocess.run([sys.executable,'-I','estimator.py'],cwd=work,check=True,
                       env={**os.environ,'OPENBLAS_NUM_THREADS':'1'})
        shutil.copyfile(work/'predictions.jsonl',data/'predictions.jsonl')
    lock={name:digest(data/name) for name in ('predictions.jsonl','commitments.json')}
    lock['frozen.sha256']=digest(ROOT/'frozen.sha256')
    (data/'prediction_lock.json').write_text(json.dumps(lock,indent=2)+'\n')


if __name__=='__main__':
    run(sys.argv[1])
