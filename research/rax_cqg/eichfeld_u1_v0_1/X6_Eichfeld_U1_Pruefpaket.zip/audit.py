"""Post-unblinding diagnostics. Independent exact-binomial inversion and negative control."""
import json
from pathlib import Path
import numpy as np
from scipy.stats import binom
from estimator import features
from generate import planted,geometry
from controls import oracle

root=Path('data')
summary=json.loads((root/'summary.json').read_text())
for cls in summary['classes'].values():
    for key in ['sign_hit','magnitude_hit']:
        g=cls[key];k=g['k'];n=cls['n'];a=summary['per_side_alpha']
        if k:assert abs(binom.sf(k-1,n,g['lo'])-a)<1e-11
        if k<n:assert abs(binom.cdf(k,n,g['hi'])-a)<1e-11
pred=[json.loads(s) for s in (root/'predictions.jsonl').read_text().splitlines()]
truth=json.loads((root/'sealed/key.json').read_text())
C=np.array(json.loads((root/'calibration.json').read_text())['C'])
weights=np.array([1.,-1.])@np.linalg.inv(C)
diag={}
for cls in 'EB':
    rows=[(r,g) for r,g in zip(pred,truth) if g['kind']==cls and r['D'] is not None]
    terms=[weights*r['D']/abs(g['J']) for r,g in rows]
    diag[cls]=np.median(np.abs(terms),axis=0).tolist()
# Explicit changed link experiment, compared with the unchanged flux reference.
u=np.exp(1j*np.array([.375,-.19,.44,-.455]))
before=u[0]*u[1]*np.conj(u[2]*u[3])
u[0]*=np.exp(.27j)
after=u[0]*u[1]*np.conj(u[2]*u[3])
assert abs(after/before-np.exp(.27j))<1e-14 and abs(after-before)>.25
tested=0
for seed in range(52400,52412):
    g=geometry(seed);n=len(g[0])
    case=planted(g,'E',np.ones(3),'',np.arange(n),np.zeros(n))
    _,d=features(case)
    if d is not None:
        assert np.max(np.abs(np.array(d)-oracle(case)))<1e-12
        tested+=1
assert tested>0
print(json.dumps(dict(inverse_weights=weights.tolist(),median_absolute_terms_over_target=diag,
                      explicit_fault_distance=float(abs(after-before)),eligible_oracle_geometries=tested),indent=2))
