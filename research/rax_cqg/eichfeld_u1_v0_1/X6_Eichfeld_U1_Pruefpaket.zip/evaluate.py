"""Open the numerical answer key only after checking the locked blind predictions."""
import csv
import json
from pathlib import Path
import sys
import numpy as np
from scipy.stats import beta
from blind_run import ROOT,digest


def interval(k,n,a):
    return (0. if k==0 else float(beta.ppf(a,k,n-k+1)),
            1. if k==n else float(beta.isf(a,k+1,n-k)))


def evaluate(data):
    data=Path(data)
    lock=json.loads((data/'prediction_lock.json').read_text())
    for name,value in lock.items():
        path=(ROOT if name=='frozen.sha256' else data)/name
        if digest(path)!=value:raise ValueError('Lock mismatch '+name)
    manifest=json.loads((data/'commitments.json').read_text())
    for name,value in manifest.items():
        if digest(data/name)!=value:raise ValueError('Commitment mismatch '+name)
    pred=[json.loads(s) for s in (data/'predictions.jsonl').read_text().splitlines()]
    gold=json.loads((data/'sealed/key.json').read_text())
    cfg=json.loads((ROOT/'design.json').read_text())
    gates=cfg['gates'];a=gates['family_alpha']/8
    assert len(pred)==len(gold)==len({r['id'] for r in gold})==2*cfg['holdout_per_class']
    rows=[]
    for order,(r,g) in enumerate(zip(pred,gold)):
        assert r['id']==g['id']
        v=r['J'];true=g['J']
        err=None if v is None else abs(v-true)/abs(true)
        rows.append(dict(case=order+1,id=g['id'],kind=g['kind'],true=true,estimate=v,
                         sign_hit=r['predicted']==g['kind'],relative_error=err,
                         magnitude_hit=err is not None and err<=gates['relative_error'],
                         baseline_hit=r['baseline']==g['kind'],paths2=r['paths'][0],
                         paths3=r['paths'][1]))
    summary={'cases':len(rows),'per_side_alpha':a,'classes':{}}
    for kind in ['E','B']:
        obs=[r for r in rows if r['kind']==kind];n=len(obs)
        assert n==cfg['holdout_per_class']
        errors=[r['relative_error'] for r in obs if r['relative_error'] is not None]
        result=dict(n=n,abstained=n-len(errors),baseline_hits=sum(r['baseline_hit'] for r in obs),
                    median_relative_error=float(np.median(errors)) if errors else None)
        for key,target in [('sign_hit',gates['sign_probability']),('magnitude_hit',gates['amplitude_hit_probability'])]:
            k=sum(r[key] for r in obs);lo,hi=interval(k,n,a)
            decision='PASS' if lo>=target else 'FAIL' if hi<target else 'HOLD'
            result[key]=dict(k=k,lo=lo,hi=hi,gate=target,decision=decision)
        summary['classes'][kind]=result
    with (data/'scores.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    (data/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    return summary


if __name__=='__main__':
    print(json.dumps(evaluate(sys.argv[1]),indent=2))
