"""Generate archived calibration, blind challenge and separate answer key."""
import argparse
import hashlib
import json
import secrets
from pathlib import Path
import numpy as np
from vendor.rax_cqg_twin import sample_diamond_points, PCG32, CausalSet
from estimator import features

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT/'design.json').read_text())
SEEDS = ['train_geometry', 'test_geometry', 'fields', 'shuffle', 'blinding', 'ids']


def save(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry(seed):
    interior = sample_diamond_points(CFG['N'], 4, PCG32(seed))
    pts = np.vstack(([-0.5, 0, 0, 0], interior, [0.5, 0, 0, 0]))
    delta = pts[None, :, :] - pts[:, None, :]
    dt = delta[:, :, 0]
    dx2 = np.sum(delta[:, :, 1:]**2, axis=-1)
    order = CausalSet.from_matrix((dt > 0) & (dt**2 >= dx2))
    i, j = np.where(order.link_matrix())
    return pts, i, j


def planted(g, field, vector, case_id, perm, gauge):
    pts, i, j = g
    x, y = pts[i], pts[j]
    if field == 'E':
        area = x[:, :1]*y[:, 1:] - y[:, :1]*x[:, 1:]
    else:
        area = np.cross(x[:, 1:], y[:, 1:])
    angle = (area @ vector)/2 + gauge[j]-gauge[i]
    phases = np.arctan2(np.sin(angle), np.cos(angle))
    edges = sorted((int(u), int(v), float(a)) for u,v,a in zip(perm[i], perm[j], phases))
    return dict(id=case_id, n=len(pts), edges=edges)


def training(rng, target, used):
    observations = []
    for k in range(CFG['train_orders']):
        seed = int(rng.integers(0,2**32))
        if seed in used: raise ValueError('Duplicate geometry seed')
        used.add(seed)
        g = geometry(seed)
        n = len(g[0])
        responses = [features(planted(g, kind, axis, '', np.arange(n), np.zeros(n)))[1]
                     for kind in ('E','B') for axis in np.eye(3)]
        if responses[0] is not None:
            observations.append(np.array(responses).reshape(2,3,2).mean(axis=1).T)
    if len(observations) < CFG['train_orders']*.90:
        raise ValueError('Insufficient qualifying calibration geometries')
    C = np.mean(observations, axis=0)
    cond = float(np.linalg.cond(C))
    if not np.isfinite(cond) or cond > 1000:
        raise ValueError('Unstable calibration')
    save(target/'calibration.json', dict(C=C.tolist(), condition=cond, used=len(observations),
                                         requested=CFG['train_orders']))


def generate(out, seed):
    out.mkdir(parents=True)
    (out/'sealed').mkdir()
    rngs = dict(zip(SEEDS, [np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(len(SEEDS))]))
    used = set()
    training(rngs['train_geometry'], out, used)
    kinds = np.array(['E','B']*CFG['holdout_per_class'])
    rngs['shuffle'].shuffle(kinds)
    gold = []
    with (out/'cases.jsonl').open('x') as f:
        for kind in kinds:
            gseed = int(rngs['test_geometry'].integers(0,2**32))
            if gseed in used: raise ValueError('Duplicate geometry seed')
            used.add(gseed)
            g = geometry(gseed)
            n = len(g[0])
            vec = rngs['fields'].normal(size=3)
            vec /= np.linalg.norm(vec)
            amp = float(rngs['fields'].uniform(.55,1.35))
            tag = rngs['ids'].bytes(8).hex()
            perm = rngs['blinding'].permutation(n)
            gauge = rngs['blinding'].uniform(-np.pi,np.pi,n)
            case = planted(g, kind, amp*vec, tag, perm, gauge)
            f.write(json.dumps(case, separators=(',',':'), allow_nan=False)+'\n')
            gold.append(dict(id=tag, kind=str(kind), amplitude=amp,
                             direction=vec.tolist(), seed=gseed, J=amp**2*(1 if kind=='E' else -1)))
    assert len({r['id'] for r in gold}) == len(gold)
    save(out/'sealed'/'key.json', gold)
    (out/'sealed'/'master.txt').write_text(str(seed)+'\n')
    files = ['cases.jsonl','calibration.json','sealed/key.json','sealed/master.txt']
    save(out/'commitments.json', {n:sha(out/n) for n in files})


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('--seed',type=int)
    args=parser.parse_args()
    generate(args.output, secrets.randbits(128) if args.seed is None else args.seed)
