/* Independent browser calculation. Input to predict4D is only the blinded case and calibration. */
function phase(a) {
  return Math.atan2(Math.sin(a), Math.cos(a));
}

function fourEvents(field, gauge, reverse) {
  const coordinates = [[-.5, 0], [0, -.2], [0, .2], [.5, 0]];
  function angle(i, j) {
    const [t, x] = coordinates[i], [u, y] = coordinates[j];
    return phase(field * (t*y - x*u) / 2 + gauge[j] - gauge[i]);
  }
  const left = phase(angle(0,1) + angle(1,3));
  const right = phase(angle(0,2) + angle(2,3));
  const sign = reverse ? -1 : 1;
  const measured = phase(sign*(left-right));
  const reference = phase(sign*.2*field);
  return {left,right,measured,reference,residual:Math.abs(phase(measured-reference))};
}

function predict4D(test, c) {
  const n = test.n, incoming = Array(n).fill(0);
  const next = Array.from({length:n}, () => []);
  for (const [i,j,a] of test.edges) {
    next[i].push([j,a]); incoming[j]++;
  }
  const tip = incoming.indexOf(0), end = next.findIndex(edges => !edges.length);
  const families = [[],[]];
  function walk(node, depth, theta) {
    if (node === end) {
      if (depth >= 2) families[depth-2].push([Math.cos(theta),Math.sin(theta)]);
      return;
    }
    if (depth < 3) {
      for (const [j,a] of next[node]) walk(j,depth+1,theta+a);
    }
  }
  walk(tip,0,0);
  const counts = families.map(f => f.length);
  if (Math.min(...counts) < 2) return {counts, J:null};
  const d = families.map(paths => {
    const n = paths.length;
    const mx = paths.reduce((s,p) => s+p[0],0)/n;
    const my = paths.reduce((s,p) => s+p[1],0)/n;
    return paths.reduce((s,p) => s+(p[0]-mx)**2+(p[1]-my)**2,0)/(n-1);
  });
  const det = c[0][0]*c[1][1] - c[0][1]*c[1][0];
  const electric = (c[1][1]*d[0]-c[0][1]*d[1])/det;
  const magnetic = (c[0][0]*d[1]-c[1][0]*d[0])/det;
  return {counts,J:electric-magnetic};
}
