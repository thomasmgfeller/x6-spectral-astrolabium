"""Three fixed looks. Cell sets shrink to the endpoints of still-open directed pairs."""
import argparse,json,sys
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'previous'))
import selective as old

D=json.loads((ROOT/'design.json').read_text())
J,L,IDS=old.J,old.L,old.IDS
NS=D['cumulative_per_active_cell']
INCREMENTS=[b-a for a,b in zip([0]+NS,NS)]
CLEAR=list(map(F,D['clear_margins']))
HOLD=list(map(F,D['early_hold_levels']))
EVIDENCE=['prespecified_three_looks_and_recorded_decisions' if k=='prespecified_two_looks_and_recorded_first_decision' else k for k in old.EVIDENCE]
PAIRS=tuple((i,j) for i in range(J) for j in range(J) if i!=j)


def endpoints(pairs):
    return sorted({v for e in pairs for v in e})


def step(counts,pairs,look):
    n=NS[look-1]
    if look<3 and any(counts[i]>=L*counts[j]+n*HOLD[look-1] for i,j in pairs):
        return 'HOLD_COUNTS',()
    unresolved=tuple((i,j) for i,j in pairs if counts[i]>L*counts[j]-n*CLEAR[look-1])
    if not unresolved:
        return 'GO',()
    return ('CONTINUE',unresolved) if look<3 else ('HOLD_COUNTS',())


def evaluate(packet,science_count=None):
    if not isinstance(packet,dict) or packet.get('design_id')!=D['id'] or packet.get('route')!=D['route']:
        raise ValueError('unknown design or route')
    stages=packet.get('stages'); mode=packet.get('mode')
    evidence,caps=packet.get('evidence'),packet.get('contrast_caps')
    if mode not in ('field','synthetic') or not isinstance(stages,list) or len(stages)>3:
        raise ValueError('invalid mode or stage count')
    if not isinstance(evidence,dict) or not isinstance(caps,dict):
        raise ValueError('expected evidence and contrast caps')
    missing=[k for k in EVIDENCE if not isinstance(evidence.get(k),str) or not evidence[k].strip()]
    for k in ('S','D','C'):
        if not isinstance(caps.get(k),str) or not 1<=F(caps[k])<=F(old.baseline.prior.DESIGN[k]):
            missing.append(k)
    result=dict(mode=mode,status='AWAIT_FIRST_LOOK',look=None,evaluated_attempts=0,geometry=None)
    if missing:
        return dict(result,status='HOLD_ASSUMPTIONS',missing_or_ineligible=missing,geometry=old.baseline.prior.full_family())
    pairs=PAIRS;active=list(range(J));counts=[0]*J
    for look,stage in enumerate(stages,1):
        if not active:
            raise ValueError('additional observations after terminal decision')
        inc=old.read_stage(stage,look,active,INCREMENTS[look-1])
        for i,x in inc.items():counts[i]+=x
        result['evaluated_attempts']+=len(active)*INCREMENTS[look-1]
        status,pairs=step(counts,pairs,look)
        active=endpoints(pairs)
        result.update(status=status,look=look)
    if result['status'] in ('AWAIT_FIRST_LOOK','CONTINUE'):
        if science_count is not None:raise ValueError('calibration pending')
        result['next_cells']=[IDS[i] for i in active]
        result['next_attempts_per_required_cell']=INCREMENTS[len(stages)]
        if stages:result['unresolved_pairs']=[[IDS[i],IDS[j]] for i,j in pairs]
    elif result['status']=='HOLD_COUNTS':
        result['geometry']=old.baseline.prior.full_family()
    elif science_count is not None:
        sys.path.insert(0,str(old.baseline.prior.ROOT/'reference'))
        from robust import infer
        result['geometry']=infer(old.baseline.prior.DESIGN['geometry']['protocol'],science_count)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('packet',type=Path);p.add_argument('--count',type=int)
    args=p.parse_args()
    try:print(json.dumps(evaluate(json.loads(args.packet.read_text()),args.count),indent=2))
    except (ValueError,TypeError,KeyError,ZeroDivisionError) as e:p.exit(2,f'Invalid input: {e}\n')
