"""Independent cross-checks of risk envelopes, input protocol and all paired pilot decisions."""
from copy import deepcopy
from fractions import Fraction as F
from itertools import product,permutations
from math import erfc,sqrt,ceil,lcm
import json,hashlib
import numpy as np
from scipy.stats import binom
from three_look import ROOT,D,L,J,IDS,NS,CLEAR,HOLD,PAIRS,INCREMENTS,evaluate,step,old
from bounds_three import certificate,scalar_survival,gaussian_upper,UNIT
from trial import PLAN


def coef(n,t):
    den=lcm(L.denominator,t.denominator)
    return den,int(L*den),int(n*t*den)


def integer_cuts(xs,coeff,upper=False):
    den,a,b=coeff
    if upper:return [-(-(a*x-b)//den) for x in xs]
    return [(a*x-b)//den for x in xs]


def independent_pilot(arrays,pilot):
    cuts=[coef(n,t) for n,t in zip(NS,CLEAR)]
    stop=[coef(n,-h) for n,h in zip(NS,HOLD)]
    v8c,v8s=coef(old.N1,old.T1),coef(old.N1,-old.STOP)
    assert CLEAR[2]==old.T2
    total=0
    keys=('first_go','first_hold','middle_go','middle_hold','final_go','final_hold','go','no_middle_go','v08_go',
          'middle_only_go','middle_only_hold','v09_only_go','v08_only_go','cost_above_v08')
    for name in PLAN['cases']:
        a=arrays[name];r=pilot[name];nr=len(a[0]);cc=dict.fromkeys(keys,0);hist=[[0]*17,[0]*17];sums=[0]*3
        for p,q,u,v in zip(*a):
            x=list(map(int,p));o=[y+int(z) for y,z in zip(x,q)];y=[i+int(j) for i,j in zip(o,u)];z=[i+int(j) for i,j in zip(y,v)]
            xc=integer_cuts(x,cuts[0]);oc=integer_cuts(o,v8c)
            yc=integer_cuts(y,cuts[1]);zc=integer_cuts(z,cuts[2])
            fhold=max(x)>=min(integer_cuts(x,stop[0],True))
            e=[] if fhold else [(i,j) for j,b in enumerate(xc) for i,xx in enumerate(x) if xx>b and i!=j]
            m1=len({i for pair in e for i in pair});fg=not e and not fhold
            yh=integer_cuts(y,stop[1],True)
            mhold=any(y[i]>=yh[j] for i,j in e)
            f=[] if mhold else [(i,j) for i,j in e if y[i]>yc[j]]
            m2=len({i for pair in f for i in pair});mg=bool(e) and not mhold and not f
            lh=any(z[i]>zc[j] for i,j in f);lg=bool(f) and not lh
            go=fg or mg or lg
            control=not fhold and all(z[i]<=zc[j] for i,j in e)
            oh=max(o)>=min(integer_cuts(o,v8s,True))
            oe=[] if oh else [(i,j) for j,b in enumerate(oc) for i,xx in enumerate(o) if xx>b and i!=j]
            og=not oh and all(z[i]<=zc[j] for i,j in oe)
            n=J*NS[0]+m1*INCREMENTS[1]+m2*INCREMENTS[2]
            c=J*NS[0]+m1*(NS[-1]-NS[0]);on=J*old.N1+len({i for p in oe for i in p})*(old.N2-old.N1)
            assert c-n==(m1-m2)*INCREMENTS[2]>=0
            for k,val in zip(keys,(fg,fhold,mg,mhold,lg,lh,go,control,og,go and not control,control and not go,
                                   go and not og,og and not go,n>on)):cc[k]+=val
            hist[0][m1]+=1;hist[1][m2]+=1
            sums[0]+=n;sums[1]+=c;sums[2]+=on
        assert all(r[k]==v for k,v in cc.items())
        assert hist==[r['selected_after_first_hist'],r['selected_after_middle_hist']]
        assert [F(q,nr) for q in sums]==[F(r[k]) for k in ('mean_trials','mean_no_middle','mean_v08')]
        assert hashlib.sha256(a.tobytes()).hexdigest()==r['raw_sha256']
        total+=nr
    return total


def toy():
    # Full potential vectors versus a masked, operational evaluation of the same three looks.
    ns=(3,5,7);inc=(3,2,2);marg=(F(1,8),F(1,6),F(1,5));hs=(F(1,3),F(1,5));ell=F(3,2)
    pairs=list(permutations(range(3),2));n=shrinks=0;states={}
    def look(data,edges,k):
        diff=lambda e:F(data[e[0]],ns[k])-ell*F(data[e[1]],ns[k])
        if k<2 and any(diff(e)>=hs[k] for e in edges):return 'H',[]
        pending=[e for e in edges if diff(e)>-marg[k]]
        if not pending:return 'G',[]
        return ('C',pending) if k<2 else ('H',[])
    for x in product(range(4),repeat=3):
        s1,e1=look(x,pairs,0);v1=sorted(set(i for e in e1 for i in e))
        for b in product(range(3),repeat=3):
            y=[a+j for a,j in zip(x,b)]
            s2,e2=look(y,e1,1) if s1=='C' else (s1,[])
            v2=sorted(set(i for e in e2 for i in e))
            for d in product(range(3),repeat=3):
                z=[a+j for a,j in zip(y,d)]
                s3,_=look(z,e2,2) if s2=='C' else (s2,[])
                history=(x,tuple(b[i] for i in v1),tuple(d[i] for i in v2))
                assert states.setdefault(history,s3)==s3
                assert set(v2)<=set(v1)
                if s3=='G':
                    assert all(any(F(data[i],nk)-ell*F(data[j],nk)<=-t for data,nk,t in zip((x,y,z),ns,marg)) for i,j in pairs)
                shrinks+=int(0<len(v2)<len(v1));n+=1
    assert shrinks>0
    return dict(potential_transcripts=n,observable_transcripts=len(states),strict_nesting_transcripts=shrinks)


def check_binomial(n,t,means):
    # Conditional probability of *all* neighbors in their nontrigger intervals for a given focal count.
    # Unordered comparisons and other pairs do not enter the endpoint event.
    total=0.
    for p in set(means):
        focal_count=means.count(p);others=list(means);others.remove(p)
        left=max(0,int(n*p)-ceil(5*sqrt(n)));right=min(n,int(n*p)+ceil(5*sqrt(n)))
        ks=np.arange(left,right+1)
        den,A,B=coef(n,t)
        lower=np.fromiter((-(-(int(k)*den+B)//A) for k in ks),dtype=np.int64,count=len(ks))
        upper=np.fromiter(((A*int(k)-B)//den for k in ks),dtype=np.int64,count=len(ks))
        contained=np.ones(len(ks))
        for q in set(others):
            prob=np.maximum(0,binom.cdf(upper,n,float(q))-binom.cdf(lower-1,n,float(q)))
            contained*=prob**others.count(q)
        total+=focal_count*(1-float(np.sum(binom.pmf(ks,n,float(p))*contained)))
    return total


def main():
    origin=json.loads((ROOT/'previous/ORIGIN-v08.json').read_text())
    for p,d in origin['files'].items():assert hashlib.sha256((ROOT/'previous'/p).read_bytes()).hexdigest()==d
    cert=certificate();assert cert==json.loads((ROOT/'records/certificate.json').read_text())
    for i in range(-601,602):
        q=.5*erfc(i/100/sqrt(2));g=gaussian_upper(i)/UNIT
        assert q<=g+1e-15 and g-q<4e-6
    samples=0
    for n in (NS[0],NS[1],old.N1):
        for p in (F(49,100),F(1,2),F(11,20),F(3,5)*F(5001,5000)):
            for j in range(-100,101,5):
                u=F(j,200000)
                a=binom.sf((n*(p+u)).__ceil__()-1,n,float(p))
                b=binom.cdf((n*(p-u)).__floor__(),n,float(p))
                assert max(a,b)<=scalar_survival(n,u)/UNIT+1e-13
                samples+=2
    references=[]
    for size,t,label in [(NS[0],CLEAR[0],'first_followup'),(NS[1],CLEAR[1],'second_followup'),(old.N1,old.T1,'prior_same_proof')]:
        for low,k in [(F(49,100),8),(F(1,2),0),(F(3,5),1),(F(4,5),8)]:
            ps=[low*F(5001,5000)]*k+[low]*(J-k)
            val=check_binomial(size,t,ps);limit=F(cert[label]['expected_active_upper'])
            assert val<=float(limit)+1e-7
            references.append(dict(n=size,min_p=str(low),high_count=k,expected_potential_cells=f'{val:.4f}'))
    read=lambda name:json.loads((ROOT/'examples'/(name+'.json')).read_text())
    a,b,g,h=[read(x) for x in ('after_first','after_middle','final_go','final_hold')]
    rx=evaluate(a);ry=evaluate(b);rg=evaluate(g,1157840);rh=evaluate(h)
    assert rx['next_cells']==IDS[:3] and ry['next_cells']==IDS[:2]
    assert (rx['evaluated_attempts'],ry['evaluated_attempts'],rg['evaluated_attempts'])==(352000000,379000000,409000000)
    assert rg['status']=='GO' and rh['status']=='HOLD_COUNTS'
    assert rg['geometry']==json.loads((ROOT/'previous/records/verification.json').read_text())['synthetic_geometry']
    field=evaluate(read('field_worksheet'));assert field['status']=='HOLD_ASSUMPTIONS' and field['geometry']==rh['geometry']
    early=deepcopy(a)
    for row in early['stages'][0]['cells']:row['detected']=NS[0]//2
    assert evaluate(early)['status']=='GO'
    stopped=deepcopy(early);stopped['stages'][0]['cells'][2]['detected']+=30000
    assert evaluate(stopped)['status']=='HOLD_COUNTS'
    middle=deepcopy(b);middle['stages'][1]['cells'][0]['detected']+=20000
    # Explicit forced HOLD on an open edge at the second look.
    middle['stages'][1]['cells'][1]['detected']+=90000
    assert evaluate(middle)['status']=='HOLD_COUNTS'
    invalid=[]
    for opt in ('stale_C03','missing','duplicate','cumulative','bool','float','negative','over','extra_look','no_first','reorder_looks','old_id'):
        q=deepcopy(g);rows=q['stages'][2]['cells']
        if opt=='stale_C03':rows.append(dict(rows[0],id=IDS[2]))
        if opt=='missing':rows.pop()
        if opt=='duplicate':rows[1]['id']=rows[0]['id']
        if opt=='cumulative':rows[0]['attempted']=NS[-1]
        if opt=='bool':rows[0]['detected']=True
        if opt=='float':rows[0]['detected']=1.
        if opt=='negative':rows[0]['detected']=-1
        if opt=='over':rows[0]['detected']=INCREMENTS[-1]+1
        if opt=='extra_look':q['stages'].append(q['stages'][-1])
        if opt=='no_first':q['stages'].pop(0)
        if opt=='reorder_looks':q['stages'].reverse()
        if opt=='old_id':q['design_id']=old.D['id']
        invalid.append(q)
    for q in (deepcopy(early),deepcopy(stopped),deepcopy(middle)):
        q['stages'].append(g['stages'][len(q['stages'])]);invalid.append(q)
    for q in invalid:
        try:evaluate(q)
        except ValueError:pass
        else:raise AssertionError('invalid history accepted')
    for q in (a,b):
        try:evaluate(q,1157840)
        except ValueError:pass
        else:raise AssertionError('science result while pending')
    for k,n in enumerate(NS):
        lo=n//2;boundary=(L*lo-n*CLEAR[k]).__floor__()
        assert step([boundary,lo],[(0,1)],k+1)[0]=='GO'
        assert step([boundary+1,lo],[(0,1)],k+1)[0]!='GO'
        if k<2:
            hcut=(L*lo+n*HOLD[k]).__ceil__()
            assert step([hcut,lo],[(0,1)],k+1)[0]=='HOLD_COUNTS' and step([hcut-1,lo],[(0,1)],k+1)[0]=='CONTINUE'
    with np.load(ROOT/'records/counts.npz',allow_pickle=False) as mats:
        n=independent_pilot(mats,json.loads((ROOT/'records/pilot.json').read_text()))
    return dict(status='PASS',previous_files=len(origin['files']),normal_grid_checks=1203,binomial_survival_checks=samples,
                fixed_profile_endpoint_references=references,independent_paired_replays=n,
                negative_history_checks=len(invalid)+2,exact_toy=toy(),field_status=field['status'],example_geometry=rg['geometry'])


if __name__=='__main__':print(json.dumps(main(),indent=2))
