"""Shared potential counts for the three-look rule, v0.8 and a no-middle-look control."""
import argparse,hashlib,io,json,os
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from three_look import ROOT,D,J,L,NS,CLEAR,HOLD,old
import experiment as previous_trial

PLAN=D['pilot'];BLOCKS=PLAN['nested_blocks']
assert np.cumsum(BLOCKS).tolist()==[NS[0],old.N1,NS[1],NS[2]] and NS[-1]==old.N2


def draw():
    result={}
    for i,name in enumerate(PLAN['cases']):
        ps=[float(p) for p in previous_trial.previous_pilot.truths()[name]]
        mats=[]
        for j,n in enumerate(BLOCKS):
            rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([PLAN['seed'],i,j])))
            mats.append(rng.binomial(n,ps,(PLAN['repetitions'],J)).astype('<u4'))
        result[name]=np.stack(mats)
    return result


def bad_pairs(counts,n,level):
    unique,idx=np.unique(counts,return_inverse=True)
    th=np.asarray([(L*int(x)+n*level).__ceil__() for x in unique])[idx.reshape(counts.shape)]
    bad=counts[:,:,None]>=th[:,None,:]
    diag=np.arange(J);bad[:,diag,diag]=False
    return bad


def any_edge(edges):
    return edges.any(axis=(1,2))


def cells(edges):
    return (edges.any(axis=1)|edges.any(axis=2)).sum(axis=1,dtype=np.int64)


def score(arrays):
    results={};reps=PLAN['repetitions']
    if set(arrays)!=set(PLAN['cases']):raise ValueError('wrong cases')
    for name in PLAN['cases']:
        raw=arrays[name]
        if raw.dtype!=np.dtype('<u4') or raw.shape!=(4,reps,J) or any(raw[j].max()>n for j,n in enumerate(BLOCKS)):
            raise ValueError('invalid counts or stage inventory')
        a,b,c,d=raw.cumsum(axis=0,dtype=np.uint32)
        opens=previous_trial.relations
        first_hold=any_edge(bad_pairs(a,NS[0],HOLD[0]))
        active1=opens(a,NS[0],CLEAR[0]);active1[first_hold]=False
        n1=cells(active1);first_go=(n1==0)&~first_hold
        middle_hold=any_edge(active1&bad_pairs(c,NS[1],HOLD[1]))
        active2=active1&opens(c,NS[1],CLEAR[1]);active2[middle_hold]=False
        n2=cells(active2);assert np.all(n2<=n1)
        middle_go=(n1>0)&(n2==0)&~middle_hold
        final_open=opens(d,NS[2],CLEAR[2])
        last_hold=any_edge(active2&final_open)
        last_go=(n2>0)&~last_hold
        go=first_go|middle_go|last_go
        # Identical first and last looks without the new middle decision.
        control_go=~(first_hold|any_edge(active1&final_open))
        control_cost=J*NS[0]+(NS[2]-NS[0])*n1
        cost=J*NS[0]+(NS[1]-NS[0])*n1+(NS[2]-NS[1])*n2
        assert np.array_equal(control_cost-cost,(NS[2]-NS[1])*(n1-n2))
        prior_hold=any_edge(bad_pairs(b,old.N1,old.STOP))
        old_open=opens(b,old.N1,old.T1);old_open[prior_hold]=False
        prior_go=~(prior_hold|any_edge(old_open&final_open))
        prior_cost=J*old.N1+(old.N2-old.N1)*cells(old_open)
        group=dict(first_go=first_go,first_hold=first_hold,middle_go=middle_go,middle_hold=middle_hold,
                   final_go=last_go,final_hold=last_hold,go=go,no_middle_go=control_go,v08_go=prior_go,
                   middle_only_go=go&~control_go,middle_only_hold=~go&control_go,v09_only_go=go&~prior_go,
                   v08_only_go=~go&prior_go,cost_above_v08=cost>prior_cost)
        results[name]=dict(repetitions=reps,**{k:int(v.sum()) for k,v in group.items()},
                selected_after_first_hist=np.bincount(n1,minlength=J+1).tolist(),
                selected_after_middle_hist=np.bincount(n2,minlength=J+1).tolist(),
                mean_selected_first=str(F(int(n1.sum()),reps)),mean_selected_middle=str(F(int(n2.sum()),reps)),
                mean_trials=str(F(int(cost.sum()),reps)),mean_no_middle=str(F(int(control_cost.sum()),reps)),
                mean_v08=str(F(int(prior_cost.sum()),reps)),raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest())
    return results


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['generate','score','replay']);p.add_argument('file',type=Path)
    args=p.parse_args()
    if args.mode=='generate':
        b=io.BytesIO();np.savez_compressed(b,**draw());temp=args.file.with_suffix('.tmp')
        temp.write_bytes(b.getvalue());os.replace(temp,args.file)
    else:
        with np.load(args.file,allow_pickle=False) as inp:
            if args.mode=='replay':
                for name,raw in draw().items():
                    if not np.array_equal(raw,inp[name]):raise ValueError('seed replay differs in '+name)
            print(json.dumps(score(inp),indent=2))
