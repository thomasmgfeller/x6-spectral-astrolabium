# Eigenzeit v0.9 · Lohnt sich ein dritter Messstand?

Die relative Referenzkalibrierung prüft dieselben 16 Zellen und Fehlerziele wie v0.8. Nach 22 Millionen Versuchen je Zelle erhalten nur die Endpunkte noch offener gerichteter Vergleiche weitere 9 Millionen. Nach diesem Blick können die verbliebenen Zellen nochmals 15 Millionen erhalten. Höchstens fallen 736 Millionen Referenzversuche an. Für jedes günstige Profil ist der erwartete Verbrauch höchstens **418.670.605**. v0.8 benötigt bereits für seinen ersten Blick 432 Millionen Versuche. Das garantiert für jedes günstige Profil mindestens **3,08 % Einsparung im Mittel**. Ein einzelner Durchlauf kann auch teurer werden.

## Inhalte

- **Bericht.pdf** enthält Messablauf, Kosten- und Fehlergrenzen, die Vergleichspläne und die beobachtete Ausnahme bei niedriger Effizienz.
- **BEWEIS.md** begründet den Dreistufentest, die unbedingte Kontrolle aller drei Fehlergelegenheiten und die verbesserte Berechnung der Nachmesskosten für Zellen mit gemeinsamen Vergleichen.
- **design.json** fixiert Stufen, Schwellen und Pilot. **three_look.py** ist der Feldprüfer. **bounds_three.py** berechnet das rationale Zertifikat, die 17 Gruppenschranken je Blick und die Gegenrechnung für die unveränderte v0.8-Regel. Ergebnisse stehen in **records/certificate.json**.
- **trial.py** generiert und wertet die gepaarten Zählungen aus. **records/counts.npz** enthält je Szenario ein Array (4, 10000, 16), Datentyp uint32 little-endian. Die vier potentiellen Zusatzblöcke sind 22, 5, 4 und 15 Millionen Versuche pro Zelle. So lassen sich v0.9 mit kumuliert 22/31/46 Millionen und v0.8 mit 27/46 Millionen auf identischen Beobachtungsfolgen vergleichen. In die Kosten gehen ausschließlich die operativ benötigten Zählungen ein.
- **records/pilot.json** gibt je Profil die Abgänge mit GO/HOLD an allen drei Blicken, Häufigkeiten der ausgewählten Zellzahlen, mittlere Kosten und gepaarte Abweichungen gegenüber v0.8 und dem Plan ohne Mittelblick an. **mean_selected_first** und **mean_selected_middle** sind über sämtliche Wiederholungen gemittelt einschließlich null nach einem terminalen Entscheid.
- **verify.py** und **records/verification.json** enthalten eine unabhängige skalare Auswertung aller 80.000 Pfade, Normal- und Binomialkontrollen, zwölf numerische Festprofilprüfungen und ein kleines exakt enumeriertes Dreistufenexperiment. **records/environment.json** dokumentiert die Softwareversionen. Die Daten sind vollständig synthetisch.
- **previous/** enthält bytegleiche Bestandteile aus dem veröffentlichten v0.8-Original mit den dort benutzten Vorgängern. **previous/ORIGIN-v08.json** identifiziert Archiv, Merge-Commit und alle übernommenen Dateien. **FREEZE.sha256** belegt den lokalen Stand von Entwurf, Regel, Risikorechnung und Pilotgenerator vor Erzeugung der neuen Pilotdaten. Das ist keine öffentliche Vorregistrierung. **MANIFEST.sha256** umfasst alle übrigen Paketdateien.

## Feldanwendung

Im entpackten Verzeichnis ausführen. Die Kalibrierentscheidung ohne wissenschaftlichen Zähler und die Berechnung der rationalen Schranken benötigen nur Python 3. Für Geometrie, unabhängige Kontrollrechnung und Pilot sind NumPy/SciPy vorgesehen. Die getesteten Versionen stehen im Umgebungsprotokoll.

```sh
python -B three_look.py examples/field_worksheet.json
python -B three_look.py examples/after_first.json
python -B three_look.py examples/after_middle.json
python -B three_look.py examples/final_go.json --count 1157840
python -B three_look.py examples/final_hold.json --count 1157840
```

Die leere Vorlage benötigt bestätigte externe Dichtezusagen und fachlich geprüfte Nachweisverweise. Im Feld **contrast_caps** sind S, D und C als rationale Zeichenketten anzugeben. Die maximalen Werte sind jeweils 1,0001. Grundlage der Theorie ist die unveränderte Effizienz jeder Zelle während aller Blicke. Vor dem ersten Versuch müssen die vollständige Partition, die unabhängige Erhebung aller markierten Referenzsignale einschließlich Ausfällen, der Transfer zur Wissenschaftsordnung und die gesamte dreistufige Auswahl feststehen. Zwischenstände und daraus resultierende Auswahlentscheidungen sind vor der Fortsetzung extern verbindlich festzuhalten. Die Datei allein belegt die Gültigkeit dieser Voraussetzungen nicht.

Bei **AWAIT_FIRST_LOOK** oder **CONTINUE** verlangen die Felder **next_cells** und **next_attempts_per_required_cell** genau die IDs und Zahlen der neuen Versuche für den nächsten Block. Die Zähler im Eingabeprotokoll bleiben je Stufe **inkrementell**. Bei CONTINUE liefert **unresolved_pairs** auch die gerichtete Vergleichsliste. Die Software berechnet die aktive Menge neu aus den bisherigen Daten. Sie verwirft zusätzliche Zellen oder Folgeversuche nach einem terminalen Entscheid. GO ohne Wissenschaftszähler beendet die Kalibrierung, die Geometrieauswertung steht noch aus. HOLD_COUNTS und HOLD_ASSUMPTIONS ergeben den vollen h-/q-Bereich. Der optionale Wissenschaftszähler entsteht aus der unabhängigen v0.4-Anordnung mit disjunkten Achtergruppen.

Beispiel: Nach Blick 1 sind C01, C02 und C03 aktiv. Bei Blick 2 werden für diese drei Zellen je 9 Millionen neue Versuche eingelesen. Danach bleibt nur C02→C01 offen. Die beiden letzten Zellen benötigen je 15 Millionen weitere Versuche. Bei insgesamt 409 Millionen ergibt eine Fortsetzung GO und die andere HOLD. Bei identischem wissenschaftlichem Zähler bleibt im ersten Fall nur der Rasterpunkt h=1/2. Im zweiten bleiben alle drei Kandidaten zulässig.

## Frischer gepaarter Vergleich

Acht Szenarien mit je 10.000 Wiederholungen verwenden die v0.7-v0.8-Zellmittel und neue unabhängige Seeds. Sie umfassen homogene Nachweisrate 0,5, günstige Randprofile mit einer oder acht hohen Zellen, ein Paar am statistischen Grenzverhältnis, ein physisch unsicheres Profil mit kleinen Teilgebieten, ein deutlich unsicheres Profil, ein Zwischenprofil und sichere homogene Effizienz 0,1 unter konstanten sonstigen Faktoren. Die genaue Konstruktion steht in der archivierten v0.8-Herleitung und in den übernommenen Simulationsdefinitionen. Sowohl das günstige als auch das physisch unsichere Modell erfordern unabhängig geprüfte äußere Annahmen.

Der Kontrollplan **no_middle** benutzt die v0.9-Schwellen bei 22 und 46 Millionen. Nach Blick 1 bleiben die offenen Paare samt Endpunkten bis zum letzten Blick vorgesehen. Sein Vergleich mit v0.9 isoliert das Hinzufügen des mittleren Blicks. Die feste v0.8-Referenz hat ihren eigenen ersten Messzeitpunkt. Die beiden Kontrollen beantworten unterschiedliche Fragen. Kein Kontrollplan dient einer nachträglichen Wahl der Feldregel.

## Reproduktion

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B bounds_three.py > /tmp/x6-v09-cert.json
cmp records/certificate.json /tmp/x6-v09-cert.json
python -B trial.py score records/counts.npz > /tmp/x6-v09-score.json
cmp records/pilot.json /tmp/x6-v09-score.json
python -B trial.py replay records/counts.npz > /tmp/x6-v09-replay.json
cmp records/pilot.json /tmp/x6-v09-replay.json
python -B verify.py > /tmp/x6-v09-checks.json
cmp records/verification.json /tmp/x6-v09-checks.json
```

Der reale Aufbau bleibt **HOLD**. Es fehlen markierte Feldzählungen und unabhängige Belege für die externen Kontrastgrenzen.
