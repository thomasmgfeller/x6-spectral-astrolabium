"""Directed finite-sample bounds, including conditional probabilities of a shared endpoint."""
from fractions import Fraction as F
from functools import lru_cache
import json
from three_look import ROOT,D,J,L,NS,CLEAR,HOLD,old
from selective_bounds import endpoint_bound
from sequential_bounds import tail, good_bound, rounded, P, R
from budgets import sqrt_lower

UNIT=10**12
VLO=F(239,1000)
CUTS=tuple(F(j,200000) for j in range(-100,101))
OFFSETS=(F(0),(R-1)/2,R-1)
SMALL_M_MAX=F(3,5)


def ceil_unit(x):
    return min(UNIT,(x*UNIT).__ceil__())


@lru_cache(None)
def gaussian_upper(index):
    # Grid on [-6,6]. exp(-s) integrated term by term, odd/even polynomials bound the integral.
    if index < -600:return UNIT
    index=min(index,600)
    x=F(abs(index),100);term=x;integral=x
    for k in range(1,83):
        term*=-x*x*F(2*k-1,2*k*(2*k+1))
        integral+=term
        if k==81:lo=integral
    assert lo<=integral
    prob=F(1,2)-F(398941,10**6)*lo if index>=0 else F(1,2)+F(398944,10**6)*integral
    return ceil_unit(prob)


@lru_cache(None)
def scalar_survival(n,u):
    # Lower normal argument, upper BE error; same envelope for either noise sign.
    sc=sqrt_lower(F(n,1)/(F(1,4) if u>=0 else VLO))
    if u<0:sc+=F(1,UNIT)
    idx=(100*u*sc).__floor__()
    error=ceil_unit(F(56,100)/sqrt_lower(n*VLO))
    return min(UNIT,gaussian_upper(idx)+error)


@lru_cache(None)
def no_hit_lower(success,number):
    if number==0:return UNIT
    return (UNIT-success)**number//UNIT**(number-1)


@lru_cache(None)
def integrated(n,g0,g1,own,other,number0,number1):
    # All entries use scale UNIT. E[F(Z)] is bounded by summation by parts over a fixed grid.
    last=None;upper=0
    for z in CUTS:
        s0=scalar_survival(n,(g0-own*z)/other)
        s1=scalar_survival(n,(g1-own*z)/other)
        f=UNIT-no_hit_lower(s0,number0)*no_hit_lower(s1,number1)//UNIT
        if last is None:upper=f*UNIT
        else:
            assert f>=last
            upper+=(f-last)*survival
        last=f;survival=scalar_survival(n,z)
    upper+=(UNIT-last)*survival
    return F(-(-upper//UNIT),UNIT)


def coarse(n,t,m):
    g=m*(L-1);w=m*(R-1)
    a,b,c=[tail(n,g-d-t) for d in (w,w/2,0)]
    results=[]
    for k in range(J+1):
        low=J-k
        hi=min(1,2*(k-1)*b+low*(a+c)) if k else 0
        lo=min(1,2*(low-1)*b+k*(a+c)) if low else 0
        results.append(k*hi+low*lo)
    return max(results)


def refined(n,t):
    # k is the number of high cells. Only the focal cell is further subdivided in the proof.
    by_k=[]
    for k in range(J+1):
        total=F(0)
        for group,size in enumerate((J-k,k)):
            if not size:continue
            number0=J-k-(group==0);number1=k-(group==1)
            candidates=[]
            for sub in range(4):
                alo=OFFSETS[group]+sub*(R-1)/8
                ahi=alo+(R-1)/8
                out=[P*(L-1+L*b-ahi)-t for b in OFFSETS[:2]]
                inc=[P*(L-1+L*alo-b)-t for b in OFFSETS[1:]]
                assert min(*out,*inc)>0
                a=integrated(n,*out,F(1),L,number0,number1)
                b=integrated(n,*inc,L,F(1),number0,number1)
                candidates.append(min(F(1),a+b))
            total+=size*max(candidates)
        by_k.append(total)
    high=coarse(n,t,SMALL_M_MAX)
    simple=endpoint_bound(n,t)[0]
    bound=min(simple,max(high,max(by_k)))
    return bound,dict(expected_active_upper=str(bound),near_half_by_k=list(map(str,by_k)),high_efficiency_upper=str(high),pair_union_upper=str(simple))


def certificate():
    prev=json.loads((ROOT/'previous/records/certificate.json').read_text())
    geom=json.loads((ROOT/'previous/previous/previous/previous/certificate.json').read_text())
    fs=[tail(n,t) for n,t in zip(NS,CLEAR)]
    hs=[good_bound(n,-s)[0] for n,s in zip(NS,HOLD)]+[good_bound(NS[-1],CLEAR[-1])[0]]
    false=sum(fs);hold=sum(hs)
    assert false<=F(prev['false_go_upper']) and hold<=F(prev['good_hold_upper'])
    first,e1=refined(NS[0],CLEAR[0]);second,e2=refined(NS[1],CLEAR[1])
    second=min(first,second)
    upper=J*NS[0]+(NS[1]-NS[0])*first+(NS[2]-NS[1])*second
    old_active,old_calc=refined(old.N1,old.T1)
    old_upper=J*old.N1+(old.N2-old.N1)*old_active
    gap=F(old.baseline.D['bad_pair_gap'])
    q1=tail(NS[0],gap-HOLD[0])
    q2=min(q1,tail(NS[0],gap+CLEAR[0])+tail(NS[1],gap-HOLD[1]))
    return dict(design=D['id'],min_trials=J*NS[0],max_trials=J*NS[-1],first_followup=e1,second_followup=e2,
                expected_good_upper=upper.__ceil__(),prior_same_proof=old_calc,prior_same_proof_cost_upper=old_upper.__ceil__(),
                prior_original_cost_upper=prev['expected_total_good_upper'],prior_floor=prev['first_total'],
                favorable_saving_vs_prior_mean_lower=str(rounded(1-upper/prev['first_total'],upper=False)),
                false_go_upper=str(false),good_hold_upper=str(hold),false_go_terms=list(map(str,fs)),good_hold_terms=list(map(str,hs)),
                coverage_lower=str(min(1-false,F(geom['v04_coverage_lower']))),
                good_grid_singleton_lower=str(rounded((1-hold)*F(geom['v04_grid_correct_lower']),upper=False)),
                separated_bad_expected_upper=(J*(NS[0]+(NS[1]-NS[0])*q1+(NS[2]-NS[1])*q2)).__ceil__())


if __name__=='__main__':print(json.dumps(certificate(),indent=2))
