"""Independent matrix and nonlinear propagation controls for the published C01 example."""
import json
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
from itertools import product
import numpy as np
from scipy.stats import t
from gum import calculate
from c01 import loads
from evaluate import evaluate
HERE=Path(__file__).resolve().parent
EX=HERE/'examples'

def need(x,msg):
    if not x:raise RuntimeError(msg)

def verify():
    source=loads((EX/'gum_synthetic.json').read_text())
    g=calculate(source)
    arr=np.array(source['paired_blocks'],dtype=float)
    v=np.zeros((4,4));v[:2,:2]=np.cov(arr.T,ddof=1)/arr.shape[0]
    v[2,2]=(1.6e-7/2)**2;v[3,3]=(1.0e-7)**2/12
    a=1.0000001
    jac=np.array([1,-a,-arr[:,1].mean(),1])
    u=np.sqrt(jac@v@jac)
    need(abs(u*1e6-g['uc_first_order_ppm'])<2e-10,'independent covariance')
    contrast=(arr[:,0]-a*arr[:,1]).var(ddof=1)/len(arr)
    nu=u**4*(len(arr)-1)/contrast**2
    U=u*t.ppf(.975,int(nu))*1e6
    need(abs(nu-g['effective_dof'])<1e-6 and abs(U-g['expanded_U_ppm'])<1e-8,'expanded uncertainty')
    # Exact nonlinear product-moment check with correlated Y,P and independent A,C.
    # Shared signs generate Cov(Y,P) exactly; numerical assumption of normality is unnecessary.
    rows=[]
    for s,b,h,l in product((-1,1),repeat=4):
        P=F(1,2)+F(s,100); Y=F(1,2)+F(s,150)+F(b,400)
        A=1+F(h,1000); C=F(l,100000)
        rows.append((Y,P,A,C,Y-A*P+C))
    def mean(x):return sum(x)/len(x)
    def var(x):return mean([(j-mean(x))**2 for j in x])
    Y,P,A,C,D=zip(*rows)
    cov=mean([(i-mean(Y))*(j-mean(P)) for i,j in zip(Y,P)])
    formula=var(Y)+mean(A)**2*var(P)+mean(P)**2*var(A)-2*mean(A)*cov+var(C)+var(A)*var(P)
    need(formula==var(D) and mean(D)==mean(Y)-mean(A)*mean(P)+mean(C),'exact nonlinear moments')
    unsupported=deepcopy(source);unsupported["transfer_rectangular"].update(low='-0.05',high='0.05')
    need(calculate(unsupported)['expanded_U_ppm'] is None,'dominant rectangular component')
    big=deepcopy(source)
    big["paired_blocks"]=[["0.400001","0.40"],["0.600002","0.60"]]*8
    big["gain_certificate"]["expanded_U"]="0.004"
    nonlin=calculate(big)
    need(nonlin["uc_exact_moments_ppm"]-nonlin["uc_first_order_ppm"]>.001
         and nonlin["expanded_U_ppm"] is None,"nonlinear output must be held")
    unsafe=deepcopy(source);unsafe['model']='unknown_correlation'
    try:calculate(unsafe)
    except ValueError:pass
    else:raise RuntimeError('unjustified independence')
    expect={'qualified_synthetic':'SYNTHETIC_MODEL_ONLY','common_bias':'HOLD_2PPM','coverage_95_only':'HOLD_RISK'}
    for key,val in expect.items():
        result=evaluate(EX/'gum_synthetic.json',EX/key/'anchor.json')
        need(result['status']==val and result['geometry_release'] is False,key)
    need(evaluate(EX/'field_gum.json',EX/'field_anchor.json')['status']=='HOLD_GUM_INPUT','field hold')
    return dict(exact_nonlinear_states=len(rows),exact_nonlinear_variance=str(formula),matrix_check="PASS",
                effective_dof_check="PASS",significant_product_nonlinearity="HOLD_COVERAGE_METHOD",unknown_correlations="HOLD",dominant_uniform="HOLD_COVERAGE_METHOD",
                combined_examples=expect,field="HOLD_GUM_INPUT",scipy_version=__import__('scipy').__version__)
if __name__=="__main__":
    print(json.dumps(verify(),sort_keys=True,indent=2))
