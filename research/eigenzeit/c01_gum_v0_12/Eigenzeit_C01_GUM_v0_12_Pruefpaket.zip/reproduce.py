"""Verify all publication hashes and replay numerical results from fresh processes."""
from pathlib import Path
import argparse, hashlib,json,subprocess,sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent

def main(previous):
    rows=(HERE/'MANIFEST.sha256').read_text().splitlines()
    entries={}
    for line in rows:
        h,path=line.split(None,1)
        if path in entries or hashlib.sha256((HERE/path).read_bytes()).hexdigest()!=h:
            raise ValueError(path)
        entries[path]=h
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual!=set(entries)|{'MANIFEST.sha256'}:raise ValueError('inventory')
    if previous:
        expected=json.loads((HERE/'previous/ORIGIN-v11.json').read_text())
        if hashlib.sha256(previous.read_bytes()).hexdigest()!=expected['archive_sha256']:raise ValueError('previous archive')
        with ZipFile(previous) as z:
            for name in expected['files']:
                if (HERE/'previous'/name).read_bytes()!=z.read(name):raise ValueError(name)
    jobs=[('verification',['check.py']),('gum',['gum.py','examples/gum_synthetic.json']),('gum_verification',['check_gum.py']),
          ('field',['evaluate.py','examples/field_gum.json','examples/field_anchor.json']),
          ('synthetic_evaluation',['evaluate.py','examples/gum_synthetic.json','examples/qualified_synthetic/anchor.json'])]
    for rec,cmd in jobs:
        data=subprocess.check_output([sys.executable,'-B',*cmd],cwd=HERE)
        if data!=(HERE/'records'/(rec+'.json')).read_bytes():raise ValueError(rec)
        print('PASS',rec)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--previous-archive',type=Path)
    main(p.parse_args().previous_archive)
