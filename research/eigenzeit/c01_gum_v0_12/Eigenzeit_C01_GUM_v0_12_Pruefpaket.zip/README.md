# Eigenzeit v0.12 · C01 nach GUM

Das Paket legt den ersten Referenzpunkt aus v0.11 und die vollständige Reihenfolge der Unsicherheitsauswertung nach JCGM 100:2008 §8 einschließlich Amd.1:2026 für das gewählte Messmodell fest. Die optische Zielreferenz ist vorläufig. Reale Anlage: HOLD_GUM_INPUT / HOLD_EVIDENCE. Das Paket enthält ausschließlich Entwurfsunterlagen und synthetische Beispiele.

## Einstieg

- **Bericht.pdf** enthält das Ergebnis, den Messpunkt, die GUM-Bilanz und den Entscheid für die reale Anlage.
- **GUM_BILANZ.md** enthält die acht Schritte, alle maßgeblichen Gleichungen, das ausgefüllte synthetische Budget, die Anwendbarkeitsgrenzen und die offiziellen Quellen.
- **MESSVERTRAG.md** definiert den Treffer, die gewählte Betriebsvariable, die vorgeschlagenen Geräte und den noch ausstehenden Transfer auf die wissenschaftliche Zelle.
- **NACHWEIS.md** trennt den konservativen 2-ppm-Entscheid und sein Fehlerbudget von der Standard- und erweiterten Messunsicherheit.
- **LABORANFRAGE.md** enthält die fachlichen Anforderungen für eine Anfrage an ein Metrologielabor.

## Nachrechnen

Python 3.12, NumPy 2.3.5 und SciPy 1.17.0 für die vollständige Reproduktion. Feldschnittstelle c01.py ohne externe Pakete. Im entpackten Verzeichnis ausführen.

```sh
sha256sum -c MANIFEST.sha256
python -B evaluate.py examples/field_gum.json examples/field_anchor.json
python -B evaluate.py examples/gum_synthetic.json examples/qualified_synthetic/anchor.json
python -B gum.py examples/gum_synthetic.json
python -B c01.py events examples/bench_prefix/plan.json examples/bench_prefix/TAG.jsonl examples/bench_prefix/X.jsonl examples/bench_prefix/Y.jsonl
python -B reproduce.py
```

Der Haupteinstieg evaluate.py verlangt zuerst die GUM-Bilanz und prüft dann die zusätzliche Intervallbedingung mit eigenem Risikobudget für denselben Geltungsbereich. Das synthetische Rechenbeispiel erhält SYNTHETIC_MODEL_ONLY, die leere Feldvorlage HOLD_GUM_INPUT. Das Werkzeug unterstützt die in GUM_BILANZ.md definierten Korrelationen und Verteilungen. Andere gemeinsame Einflüsse verlangen ein erweitertes Modell. Ein formell vollständiger Feldeintrag geht zur metrologischen Fachprüfung. Der Zusatzbefehl c01.py anchor prüft isoliert die Intervallarithmetik. Kein Programm gibt eine Geometrie frei.

### Format der optischen Nachweise

Die vier Eingänge für die Intervallkontrolle sind target (P), gain (A), comparator (Y) und transfer (absolute Schranke b). Wahrscheinlichkeiten, Gain und Risiken stehen als rationale Zeichenketten in dimensionslosen Einheiten, beispielsweise 0.000002. Ein Hash bindet jede Intervallangabe an eine lokale Nachweisdatei. Diese trägt Modus, scope_id, Messpunkt und je Behauptung bound sowie alpha. Das synthetische Beispiel zeigt das Format. Im Feld muss die fachliche Prüfung die tatsächlichen signierten Laborunterlagen, Rohdaten, Rückführung, Abhängigkeiten und Deckungsbegründung einsehen. Ein Hash authentifiziert weder die Herkunft noch die metrologische Aussage. Der Transferkorrektur C aus der GUM-Bilanz und der betragsmäßigen Schranke b liegt derselbe physikalische Effekt zugrunde.

### Format der Ereignisdateien

Drei getrennte JSONL-Dateien führen je einen Kopf (Rolle TAG/X/Y, Modus, Knoten, Lauf-ID, scope_id, Design-ID). Danach kommt je angesetzter Gelegenheit genau ein geschlossener Eintrag pro Datei, einschließlich beider Nullantworten. TAG trägt id, t_ps und complete. X und Y tragen id, edge_ps und complete. Ihre steigenden Flanken liegen in einer gemeinsam synchronisierten, kalibrierten Epoche. Der Adapter erwartet pro Kanal das vollständige Erfassungsfenster [tᵢ+τ−3000 ps, tᵢ+τ+3000 ps). Flanken außerhalb dieser Vorselektion verbleiben im ursprünglichen Hardwarearchiv. Die Auswertung muss die Vollständigkeit der Vorselektion, reale Markierungsrate, Quelle und Rohdaten unabhängig prüfen. Das boolesche complete ist eine zu belegende Aussage des Erfassungswegs.

Der Versuchsplan gibt first_id, Anzahl der erwarteten Zeilen (scheduled), separat bestimmte Verzögerungen τ und die Unsicherheitsgrenze des relativen Zeitstempels je Kanal vor. Diese Grenze muss auch Markerunsicherheit, Restsynchronisation und Drift abdecken. Der Prüfer verlangt disjunkte Erfassungsfenster und ein vollständiges vorab bezeichnetes ID-Intervall. Mehrfachflanken im Trefferfenster zählen einmal, sichere Leerfenster null. Wenn ein Fehlerintervall eine Entscheidungsgrenze überlappt, eine Zeile fehlt oder ein Datensatz doppelt erscheint, gibt es HOLD_INPUT. Markierte Testreihen sind vollständig; ein exportierter Präfix kann den ersten Stop rekonstruieren, aber keine frühe positive Freigabe auslösen. Das Beispiel stop_26 enthält zu Prüfzwecken auch eine aufgenommene Fortsetzung nach der ersten negativen Entscheidung. counts bezieht sich auf die exportierte Datei; first_stop_id benennt den frühesten irreversiblen Abbruch.

## Herkunft und Prüfstand

previous/ enthält fünf prüfsummengleiche Dateien aus dem v0.11-Originalarchiv. records/project_sources.json nennt die verwendeten Repository-Dateien mit standfesten Links und SHA-256. Die frei zugänglichen JCGM-Originale sind in GUM_BILANZ.md verlinkt. records/ enthält sowohl die vollständig reproduzierbare synthetische Bilanz als auch die unabhängigen Gegenprüfungen. Für reproduzierbare Gleitkomma-Ausgaben gelten die genannten Bibliotheksstände. Der physikalische Nachweis ist offen.
