"""Replay C01 synthetic fixtures, external-bound arithmetic, and count diagnostics."""
from copy import deepcopy
from decimal import Decimal as D, localcontext, ROUND_CEILING
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import math
import sys

from c01 import anchored,events,loads,signature,NODE

HERE=Path(__file__).resolve().parent
EX=HERE/"examples"
sys.path.insert(0,str(HERE/"previous"))
from screen import screen as previous_screen
from audit import DESIGN_ID as PREVIOUS_ID

def need(condition,name):
    if not condition:
        raise RuntimeError(name)

def apply(record):
    return anchored(loads(record.read_text()),record.parent)

def case(folder):
    p=EX/folder
    plan=loads((p/"plan.json").read_text())
    rows=[[loads(s) for s in (p/(k+".jsonl")).read_text().splitlines()] for k in ("TAG","X","Y")]
    return plan,rows

def run(plan,rows):
    return events(plan,[iter(map(json.dumps,seq)) for seq in rows])

def minimum_zero_n(e,alpha):
    # Outward integer enclosure of (1-e)^n using 55 decimal places.
    scale=10**55
    def mul(x,y):
        return x[0]*y[0]//scale,-(-(x[1]*y[1])//scale)
    def bounds(n):
        x=((1-e)*scale)
        power=(math.floor(x),math.ceil(x))
        ans=(scale,scale)
        while n:
            if n&1: ans=mul(ans,power)
            power=mul(power,power)
            n//=2
        return tuple(F(v,scale) for v in ans)
    with localcontext() as ctx:
        ctx.prec=65
        dec=lambda v:D(v.numerator)/v.denominator
        n=int((dec(alpha).ln()/(1-dec(e)).ln()).to_integral_value(rounding=ROUND_CEILING))
    need(bounds(n-1)[0]>alpha>=bounds(n)[1],"zero-trial boundary")
    return n

def verify():
    origin=loads((HERE/"previous/ORIGIN-v11.json").read_text())
    for name,h in origin["files"].items(): need(signature(HERE/"previous"/name)==h,name)
    report={}
    for name,expect in [('qualified_synthetic','SYNTHETIC_BOUND_OK'),('common_bias','HOLD_2PPM'),('coverage_95_only','HOLD_RISK')]:
        val=apply(EX/name/'anchor.json');need(val['status']==expect and val['geometry_release'] is False,name)
        report[name]=val
    field=apply(EX/'field_anchor.json');need(field['status']=='HOLD_EVIDENCE','blank field')
    report["field"]=field
    checked=0
    g=loads((EX/'qualified_synthetic/anchor.json').read_text()); doc=loads((EX/'qualified_synthetic/evidence.json').read_text())
    with TemporaryDirectory() as t:
        root=Path(t)
        def bound_test(b):
            test=deepcopy(g);receipt=deepcopy(doc)
            for k,v in b.items():test['bounds'][k]=v;receipt['claims'][k]['bound']=v
            rp=root/'receipt.json';rp.write_text(json.dumps(receipt))
            for k in test['evidence']:test['evidence'][k]={'file':rp.name,'sha256':signature(rp)}
            return anchored(test,root),test
        for mid,spread,shift,transport in product(('0.1','0.49','0.5','0.96'),('0','0.0000007'),('-0.000002','0','0.000003'),('0','0.0000003')):
            m,s,o=map(F,(mid,spread,shift));p=[m-s,m+s];y=[m+o-s,m+o+s];a=[F(9999999,10**7),F(10000001,10**7)]
            change,t=bound_test(dict(target=list(map(str,p)),gain=list(map(str,a)),comparator=list(map(str,y)),transfer=transport))
            corners=max(abs(Y-A*P) for Y,A,P in product(y,a,p))+F(transport)
            need(F(change['worst_ppm'])==corners*10**6,"corner enclosure"); checked+=1
        for eps,status in [('0.000002','SYNTHETIC_BOUND_OK'),('0.000002000000001','HOLD_2PPM')]:
            result,t=bound_test(dict(target=['0.5','0.5'],gain=['1','1'],comparator=['0.5','0.5'],transfer=eps))
            need(result['status']==status,'inclusive boundary')
        (root/'receipt.json').write_text('{}')
        try: anchored(t,root)
        except ValueError: pass
        else:raise RuntimeError('changed file accepted')
    prefix={}
    for folder,expect in [('bench_prefix','PREFIX_VALID_NO_RELEASE'),('stop_26','STOP_DISCORDANCE')]:
        plan,rows=case(folder);res=run(plan,rows)
        need(res['status']==expect and not res['geometry_release'],folder)
        ref=previous_screen(dict(design=PREVIOUS_ID,mode=res['mode'],scope_id=res['scope_id'],node=NODE,counts=res['counts']))
        need((ref['status']=='STOP_DISCORDANCE')==(res['status']=='STOP_DISCORDANCE'),folder+' v0.11')
        prefix[folder]=res
    need(prefix['stop_26']['first_stop_id']==26 and prefix['bench_prefix']['counts']=={'00':39,'01':1,'10':1,'11':39},'pair counts')
    plan,rows=case('bench_prefix')
    rejected=[]
    def fail_case(label,fn):
        p,r=deepcopy(plan),deepcopy(rows)
        fn(p,r)
        try:run(p,r)
        except ValueError: rejected.append(label)
        else: raise RuntimeError('accepted '+label)
    fail_case('interior_missing',lambda p,r:r[0].pop(5))
    fail_case('end_truncated',lambda p,r:[s.pop() for s in r])
    fail_case('duplicate_id',lambda p,r:r[1][3].update(id=2))
    fail_case('wrong_run',lambda p,r:r[2][0].update(run_id='wrong'))
    fail_case('missing_readout',lambda p,r:r[2][2].update(complete=False))
    fail_case('unknown_precision',lambda p,r:p['timestamp_bound_ps'].update(X=None))
    fail_case('ambiguous_edge',lambda p,r:r[1][1].update(edge_ps=[r[0][1]['t_ps']+p['delay_ps']['X']+1000]))
    fail_case('outside_acquisition',lambda p,r:r[1][2].update(edge_ps=[r[0][1]['t_ps']+p['delay_ps']['X']]))
    fail_case('overlap',lambda p,r:r[0][2].update(t_ps=r[0][1]['t_ps']+2000))
    fail_case('missing_zero',lambda p,r:r[1].pop(5))
    # Same analog events and therefore perfect digital agreement in both optical worlds.
    identical=deepcopy(rows);identical[2]=deepcopy(identical[1]);identical[2][0]['role']='Y'
    aligned=deepcopy(plan);aligned['delay_ps']['Y']=aligned['delay_ps']['X']
    blind=run(aligned,identical);need(blind['counts']['01']==blind['counts']['10']==0,'common-mode blindness')
    from c01 import bit
    for dt,expected in [(-1001,0),(-1000,1),(999,1),(1000,0)]:
        need(bit({'edge_ps':[10000+dt]},10000,0,0)==expected,'gate boundary')
    a=F(2,10**6)
    prior=F(loads((HERE/'previous/records/certificate.json').read_text())['combined_false_go_upper_additive'])
    with localcontext() as ctx:
        ctx.prec=65
        upper=(1-(D('0.000002').ln()/3300000).exp())*10**6
    return dict(anchors=report,interval_corner_checks=checked,threshold_checks=2,raw_prefixes=prefix,
                raw_rejections=rejected,half_open_boundary_checks=4,common_mode_identical_counts=blind['counts'],
                minimum_zero_disagreements_iid={str(e):minimum_zero_n(F(e,10**6),a) for e in (1,2)},
                ideal_zero_disagreement_upper_ppm_at_3300000=str(upper.quantize(D('0.000000001'),rounding=ROUND_CEILING)),
                joint_node_risk_32=str(32*a),remaining_external_risk=str(F(1,100)-prior-32*a),
                physical_status="HOLD_EVIDENCE")
if __name__=="__main__":
    print(json.dumps(verify(),sort_keys=True,indent=2))
