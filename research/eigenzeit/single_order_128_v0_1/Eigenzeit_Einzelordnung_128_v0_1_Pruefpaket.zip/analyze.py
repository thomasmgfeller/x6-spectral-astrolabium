"""Read only the frozen calibration ranges and packed observed orders. Compare to truth last."""
import hashlib
import json
import sys
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import numpy as np
from scipy.stats import beta
from decision import candidate_mask, classify
from information import bounds
from run import dump, HERE
sys.path.insert(0,str(HERE/'upstream'))
import exact

def cp(k,n,tail):
    return [float(beta.ppf(tail,k,n-k+1)) if k else 0.,
            float(beta.isf(tail,k+1,n-k)) if k<n else 1.]

def analyze(root):
    cfg=json.loads((HERE/'contract.json').read_text())
    bank=json.loads((root/'calibration.json').read_text())
    assert hashlib.sha256((root/'calibration.json').read_bytes()).hexdigest()==(root/'calibration.sha256').read_text().strip()
    hlist=cfg['grid_h']
    assert bank['grid_h']==hlist and bank['n']==cfg['n'] and len(bank['bands'])==len(hlist)
    n=cfg['n']; pairs=n*(n-1)//2
    tail=cfg['joint_error_budget']/(2*cfg['joint_cp_cells'])
    lookup=np.array([v.bit_count() for v in range(256)],dtype=np.uint8)
    profiles=[]; examples=[]; cells=[]
    for j,h in enumerate(hlist):
        counts={}
        for role, m in [('cal',cfg['calibration_clouds_per_model']),('test',cfg['test_clouds_per_model'])]:
            orders=np.load(root/f'{role}_{j}.npy',mmap_mode='r')
            assert orders.shape==(m,n*n//8)
            counts[role]=lookup[orders].sum(axis=1).astype(int)
            assert np.array_equal(counts[role],np.loadtxt(root/f'{role}_{j}_C2.csv',skiprows=1,dtype=int))
        k=cfg['rank_tail']; cal=np.sort(counts['cal'])
        assert bank['bands'][j]==[int(cal[k-1]),int(cal[-k])]
        m=len(counts['test'])
        masks=np.array([candidate_mask(int(v),bank['bands']) for v in counts['test']])
        hist=np.bincount(masks,minlength=2**len(hlist)).tolist()
        count_lists=[sum(num for mask,num in enumerate(hist) if mask.bit_count()==k) for k in range(len(hlist)+1)]
        first=np.unpackbits(orders[0],bitorder='little').reshape(n,n).astype(bool)
        example=classify(first,bank)
        assert example['C2']==counts['test'][0]
        examples.append(dict(truth=h,test_index=0,**example))
        forward=exact.probability(Q(h))
        mean=counts['test'].mean()/pairs
        sd=counts['test'].std(ddof=1)/pairs
        z=(mean-float(sum(forward)/2))/(sd/np.sqrt(m))
        q=exact.q_bounds(Q(h))
        profiles.append(dict(h=h,q=float(sum(q)/2),forward_p=float(sum(forward)/2),
                        forward_p_exact=[str(x) for x in forward],observed_mean=mean,within_cloud_U_sd=sd,
                        mean_z=z,mean_diagnostic=bool(abs(z)<=5),C2_band=bank['bands'][j],
                        histogram_mask=hist,histogram_size=count_lists,
                        true_singleton=hist[1<<j],false_singleton=count_lists[1]-hist[1<<j]))
        row=[]
        for col in range(len(hlist)):
            keep=int(np.count_nonzero(masks & (1<<col)))
            hits=keep if j==col else m-keep
            row.append(dict(statistic='retention' if j==col else 'exclusion',hits=hits,n=m,
                            rate=hits/m,simultaneous_interval=cp(hits,m,tail)))
        cells.append(row)
    audit=all(row[i]['simultaneous_interval'][0]>=cfg['holdout_coverage_lower_floor'] for i,row in enumerate(cells))
    comparisons=[]; theoretical=[]
    for i,j in combinations(range(len(hlist)),2):
        dirs=[cells[i][j]['simultaneous_interval'],cells[j][i]['simultaneous_interval']]
        goal=cfg['target_directed_power']
        status='RESOLVED' if audit and all(lo>=goal for lo,hi in dirs) else (
            'BELOW_TARGET' if any(hi<goal for lo,hi in dirs) else 'INCONCLUSIVE')
        comparisons.append(dict(i=i,j=j,status=status))
        theoretical.append(bounds(Q(hlist[i]),Q(hlist[j]),n))
    result=dict(protocol=cfg['id'],total_cal=cfg['calibration_clouds_per_model']*len(hlist),
        total_test=cfg['test_clouds_per_model']*len(hlist),profiles=profiles,cells=cells,
        examples=examples,pairs=comparisons,coverage_audit='PASS' if audit else 'HOLD',
        all_forward_diagnostics=all(p['mean_diagnostic'] for p in profiles),
        information_bounds=theoretical)
    dump(root/'result.json',result)
    return result

if __name__=='__main__':
    analyze(Path(sys.argv[1]))
