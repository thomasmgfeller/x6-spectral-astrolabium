#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -f FREEZE.sha256 ] || [ -e data ]; then echo 'Freeze already exists or output present' >&2; exit 1; fi
sha256sum contract.json run.py decision.py analyze.py information.py freeze.sh upstream/* > FREEZE.sha256
sha256sum FREEZE.sha256
