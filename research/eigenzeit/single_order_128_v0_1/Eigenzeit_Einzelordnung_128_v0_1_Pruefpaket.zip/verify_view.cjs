const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync('Ansicht.html','utf8');
const items=new Map();
for (const [,id] of html.matchAll(/\sid="([^"]+)"/g)){assert(!items.has(id));items.set(id,{addEventListener(name,fn){this[name]=fn},value:'',checked:false});}
const context={document:{getElementById:id=>{assert(items.has(id));return items.get(id)}}};
vm.createContext(context);vm.runInContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],context);
const get=id=>items.get(id);
assert.equal(get('index').value,4097);
const results=JSON.parse(fs.readFileSync('data/result.json'));
const all=results.profiles.map((_,i)=>fs.readFileSync('data/test_'+i+'_C2.csv','utf8').trim().split('\n').slice(1).map(Number)).flat();
const hists=results.profiles.map(()=>Array(8).fill(0));
for(let i=0;i<all.length;i++){
 context.render(i+1);let mask=0;assert(get('count').textContent.startsWith(new Intl.NumberFormat('de-CH').format(all[i])+' '));
 results.profiles.forEach((p,j)=>{const [lo,hi]=p.C2_band;const inside=lo<=all[i]&&all[i]<=hi;assert.equal(get('state'+j).textContent,inside?'zulässig':'verworfen');if(inside)mask|=1<<j});
 hists[Math.floor(i/4096)][mask]++;
}
assert.deepEqual(hists,results.profiles.map(p=>p.histogram_mask));
context.render(1);assert.equal(get('prev').disabled,true);get('next').click();assert.equal(get('index').value,2);
get('reveal').checked=true;get('reveal').change();assert(get('truth').textContent.includes('Minkowski'));get('index').value='12288';get('index').change();assert(get('truth').textContent.includes('1/2'));assert.equal(get('next').disabled,true);
console.log('All 12288 offline decisions, controls and class histograms verified in JS.');
