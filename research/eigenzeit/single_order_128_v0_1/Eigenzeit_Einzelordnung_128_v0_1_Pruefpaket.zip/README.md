# X6 Eigenzeit · Geometrie aus einer einzelnen Ordnung v0.1

**Fragestellung.** Mit 128 Elementen in einem vollständigen 4D-Kausaldiamanten
die drei Krümmungen RT²=0, 0,7579073 und 3,1313138 unterscheiden. Ergebnis und
vollständige Zahlen stehen in data/result.json. Alle drei Paare verfehlen das
80-%-Ziel. Auch für die vollständige Ordnung schließt eine analytische
Informationsschranke dieses Ziel aus.

## Einstieg

- Ansicht.html erlaubt die lokale Auswahl jeder der 12 288 Einzelordnungen und zeigt die zulässigen Modellalternativen.
- Bericht.pdf enthält Entscheidung, Grafiken und Reichweite.
- DERIVATION.md enthält die ausgearbeitete Begründung und die eingeschlossenen Restterme.
- contract.json und FREEZE.sha256 fixieren den ausgewerteten Entwurf vor der ersten Erzeugung. Die Fixierung war lokal. Sie ist keine externe Zeitstempelung.
- data/ enthält sämtliche 18 285 umnummerierten strikten Ordnungen sowie C2 je Ordnung, die unveränderte Kalibrierbank und den Prüfentscheid.
- audit.json enthält die separat gegengerechnete Affinität sowie die erst im Anschluss abgeleiteten notwendigen Elementzahlen.
- upstream/ enthält die unveränderten Projektquellen aus PR 54 und PR 48, deren Git-Objekt-IDs, Quelllinks und Lizenz.

## Reproduktion

Python, NumPy und SciPy werden benötigt. Die benutzten Versionen stehen in environment.json. Im entpackten Verzeichnis:

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python run.py replay
python analyze.py replay
cmp data/result.json replay/result.json
python audit.py replay
```

Der erste Befehl verifiziert die Auslieferung. Der zweite prüft die vor der
Zielauswertung fixierten Dateien. Das Zielverzeichnis von run.py muss neu sein.
audit.py schreibt audit.json in das Elternverzeichnis des Datenverzeichnisses.
Die sechs NPY-Dateien sind Bytefelder mit einer Zeile je Ordnung. Die strikte
128-mal-128-Matrix ist zeilenweise mit little-bitorder gepackt. Modellindex
0,1,2 steht für h=0,1/4,1/2. cal und test sind getrennte Zufallsströme.
Alle Seeds sind getrennt nach Phase, Modell, Index und Verwendungszweck aus SHA-256 ableitbar.

## Eine einzelne Ordnung prüfen

```sh
python - <<'PY'
import numpy as np
packed = np.load("data/test_1.npy", mmap_mode="r")[0]
np.save("one.npy", np.unpackbits(packed, bitorder="little").reshape(128,128).astype(bool))
PY
python decision.py one.npy
```

Die Ausgabe enthält C2=863 und alle drei Kandidaten. Für eigene Daten verlangt
der Einstieg die vollständige boolesche strikte Transitivhülle auf 128 Elementen,
beliebig beschriftet. Das Inferenzmodell setzt die im Protokoll erklärte Stichprobe
voraus. Eine bloße Liste von Hasse-Kanten erfordert zuerst deren Transitivhülle.

**Herkunft.** Modell und Vorwärtsrechnung stammen aus dem Repository
thomasmgfeller/x6-spectral-astrolabium, Fixierung c2f165953b846c69f1a23f641639cc0a3c4cdf25.
Die vorliegende Auswertung ist eine neue interne Modellprüfung. Es gab keine
externe Replikation und keine unabhängige Begutachtung.
