"""Generate an immutable rank bank then an independent holdout; archive every observed order."""
import argparse
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path
import numpy as np
from scipy.spatial.distance import pdist, squareform
from decision import observed_count

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/"upstream"))
import geometry

def generator(cfg, role, model, index, channel):
    key = f"{cfg['namespace']}/{role}/{model}/{index}/{channel}".encode()
    return np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(key).digest()[:16], 'big')))

def draw(cfg, role, model, i):
    n = cfg["n"]
    h = float(Fraction(model))
    x, _ = geometry.sample(generator(cfg, role, model, i, 'physical-volume'), n, {'h':h})
    dt = x[None,:,0] - x[:,None,0]
    dx2 = squareform(pdist(x[:,1:], metric='sqeuclidean'))
    relation = (dt > 0) & (dt**2 > dx2)
    perm = generator(cfg, role, model, i, 'anonymous-labels').permutation(n)
    order = relation[np.ix_(perm,perm)]
    count = int(order.sum())
    if i < 16:
        reference = geometry.relation(x)
        twin = geometry.flat_density_twin_relation(x,h)
        if not np.array_equal(relation, reference) or not np.array_equal(reference, twin):
            raise AssertionError("independent predicates or density twins disagree")
        if observed_count(order) != count or count != int(reference.sum()):
            raise AssertionError("order or relabelling failed")
    return count, np.packbits(order.ravel(), bitorder='little')

def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False)+'\n')

def run(root):
    root.mkdir(parents=True,exist_ok=False)
    cfg = json.loads((HERE/'contract.json').read_text())
    n = cfg['n']
    bands = []
    for role, repeats in [('cal', cfg['calibration_clouds_per_model']), ('test',cfg['test_clouds_per_model'])]:
        for j, model in enumerate(cfg['grid_h']):
            counts = []
            obs = np.lib.format.open_memmap(root/f'{role}_{j}.npy', mode='w+',dtype=np.uint8,
                                            shape=(repeats,(n*n+7)//8))
            for i in range(repeats):
                count, obs[i] = draw(cfg, role, model, i)
                counts.append(count)
            obs.flush()
            del obs
            np.savetxt(root/f'{role}_{j}_C2.csv',counts,fmt='%d',header='C2',comments='')
            if role == 'cal':
                ordered = sorted(counts)
                k = cfg['rank_tail']
                bands.append([ordered[k-1],ordered[-k]])
            print(role, model, repeats, flush=True)
        if role == 'cal':
            dump(root/'calibration.json',dict(n=n,grid_h=cfg['grid_h'],bands=bands))
            (root/'calibration.sha256').write_text(hashlib.sha256((root/'calibration.json').read_bytes()).hexdigest()+'\n')

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument('output',type=Path)
    run(p.parse_args().output)
