"""Single-order entry point. Model parameters enter only via a calibration table."""
import argparse
import json
from pathlib import Path
import numpy as np

def observed_count(order):
    a = np.asarray(order)
    if a.ndim != 2 or a.shape[0] != a.shape[1] or a.dtype != np.bool_:
        raise ValueError("expected a square Boolean strict transitive closure")
    if np.diag(a).any() or (a & a.T).any():
        raise ValueError("order must be strict and asymmetric")
    for j in range(len(a)):
        if np.any(a[:, j, None] & a[j, None, :] & ~a):
            raise ValueError("order is not transitively closed")
    return int(a.sum())

def candidate_mask(count, bands):
    return sum((1 << j) for j, (lo, hi) in enumerate(bands) if lo <= count <= hi)

def classify(order, bank):
    if np.shape(order) != (bank["n"], bank["n"]):
        raise ValueError("order size does not match bank")
    count = observed_count(order)
    mask = candidate_mask(count, bank["bands"])
    return dict(C2=count, h_candidates=[h for j,h in enumerate(bank["grid_h"]) if mask & (1<<j)])

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("order", help="square Boolean strict order in .npy format")
    parser.add_argument("--bank", default=str(Path(__file__).parent/"data"/"calibration.json"))
    args = parser.parse_args()
    print(json.dumps(classify(np.load(args.order, allow_pickle=False), json.loads(Path(args.bank).read_text()))))
