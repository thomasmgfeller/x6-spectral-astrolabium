"""Post-freeze independent checks and an explicitly labelled analytic budget consequence."""
import json
from fractions import Fraction as Q
from itertools import combinations
from math import sqrt
from pathlib import Path
import sys
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.stats import binom
from decision import observed_count, classify
from run import HERE, dump
from information import delta, cross
import geometry

def power_lower_cut(a):
    # Round the affinity-squared lower bound DOWN, then carry 30-place integer enclosures.
    den=10**30
    m=a.numerator*den//a.denominator
    def mul(u,v):
        return (u[0]*v[0]//den,(u[1]*v[1]+den-1)//den)
    def above(n):
        val=(den,den); factor=(m,m)
        while n:
            if n%2: val=mul(val,factor)
            factor=mul(factor,factor)
            n//=2
        if val[0]*16>7*den: return True
        if val[1]*16<=7*den: return False
        raise ArithmeticError('ambiguous boundary')
    lo,hi=0,1
    while above(hi): hi*=2
    while hi>lo+1:
        mid=(hi+lo)//2
        if above(mid): lo=mid
        else: hi=mid
    assert above(hi-1) and not above(hi)
    return hi

def f(s,k):
    return (s+k/4)/(1+k*s)

def k(h):
    return h/(1+sqrt(1-h*h/4))

def map_null(s,hi,hj):
    zi=f(s,-k(hi))
    end=f(zi,k(hj))
    deriv=(1-k(hi)**2/4)/(1-k(hi)*s)**2*(1-k(hj)**2/4)/(1+k(hj)*zi)**2
    return end,deriv

def quadrature_original(hi,hj):
    nodes,weights=leggauss(48)
    a=nodes[:,None]; b=nodes[None,:]
    w=weights[:,None]*weights[None,:]*3/8*(a-b)**2
    u,v=a/2,b/2
    x,du=map_null(u,hi,hj); y,dv=map_null(v,hi,hj)
    p=(1-hi*(u+v)/2)**(-4)
    q=((du*dv)**2)*(1-hj*(x+y)/2)**(-4)
    return float(np.sum(w*np.sqrt(p*q))**2/(np.sum(w*p)*np.sum(w*q)))

def audit(root):
    result=json.loads((root/'result.json').read_text())
    bank=json.loads((root/'calibration.json').read_text())
    checks=[]
    for record in result['information_bounds']:
        hi,hj=Q(record['h_i']),Q(record['h_j'])
        di,dj=delta(hi),delta(hj)
        lb=cross(di,dj)[0]**2/(cross(di,di)[1]*cross(dj,dj)[1])
        numeric=quadrature_original(float(hi),float(hj))
        assert abs(numeric-float(lb))<2e-13
        for label in range(12):
            rng=np.random.default_rng(2029950+label)
            cloud,_=geometry.sample(rng,128,{'h':float(hi)})
            t=cloud[:,0]; r=np.linalg.norm(cloud[:,1:],axis=1)
            u,_=map_null(t-r,float(hi),float(hj)); v,_=map_null(t+r,float(hi),float(hj))
            new=np.column_stack(((u+v)/2,cloud[:,1:]*((v-u)/(2*r))[:,None]))
            assert np.all(np.abs(new[:,0])+np.linalg.norm(new[:,1:],axis=1)<.5)
            assert np.array_equal(geometry.relation(cloud),geometry.relation(new))
        checks.append(dict(pair=[str(hi),str(hj)],minimum_not_excluded_N=power_lower_cut(lb),
                           independent_affinity_squared=numeric,absolute_gap=abs(numeric-float(lb))))
    for row in result['cells']:
        for cell in row:
            k,n=cell['hits'],cell['n']; l,u=cell['simultaneous_interval']
            assert abs(binom.sf(k-1,n,l)-0.05/18)<1e-11
            assert abs(binom.cdf(k,n,u)-0.05/18)<1e-11
    tests=0
    for j in range(3):
        arr=np.load(root/f'test_{j}.npy',mmap_mode='r')
        counts=np.loadtxt(root/f'test_{j}_C2.csv',skiprows=1,dtype=int)
        for i in np.linspace(0,len(arr)-1,20,dtype=int):
            a=np.unpackbits(arr[i],bitorder='little').reshape(128,128).astype(bool)
            expected=[h for h,(l,u) in zip(bank['grid_h'],bank['bands']) if l<=counts[i]<=u]
            perm=np.random.default_rng(11800+int(i)).permutation(128)
            assert classify(a[np.ix_(perm,perm)],bank)=={'C2':counts[i],'h_candidates':expected}
            tests+=1
    for bad in [np.eye(3,dtype=bool),np.array([[0,1,0],[0,0,1],[0,0,0]],dtype=bool),
                np.array([[0,1],[1,0]],dtype=bool),np.identity(3),np.ones((2,3),dtype=bool)]:
        try: observed_count(bad)
        except ValueError: pass
        else: raise AssertionError('invalid order accepted')
    out=dict(analytic_budget_status='post-freeze deterministic corollary; no further stochastic run used to fit a threshold',
             pairs=checks,intervals_checked=9,transformed_order_checks=36,
             fresh_permutation_rechecks=tests,rejected_invalid_inputs=5)
    dump(root.parent/'audit.json',out)

if __name__=='__main__': audit(Path(sys.argv[1]).resolve())
