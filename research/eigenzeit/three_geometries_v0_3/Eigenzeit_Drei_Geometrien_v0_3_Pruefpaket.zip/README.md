# Eigenzeit v0.3 · Drei Geometrien und ein kontinuierliches Krümmungsintervall

Für eine vollständige 4D-Kausalordnung unter gleichmäßiger Beprobung im physischen Volumen werden h=0,1/4,1/2 (q=RT² ungefähr 0, 0,758, 3,131) unterschieden. Die garantierte korrekte Einzelentscheidung beträgt für jedes der drei Modelle mindestens 80 %. Das kontinuierliche Intervall überdeckt für jedes feste h in [0,1/2] mit mindestens 95 % Wahrscheinlichkeit. Eine volle Paarzählung genügt bei N=600000, die zufällige Achtergruppenauswertung bei N=900000 und 3150000 Vergleichbarkeitsabfragen. Für das stärkere Dreifachziel sind mindestens 217347 Ereignisse notwendig.

## Ergebnis lesen

- Bericht.pdf fasst Ergebnis, Informationsgrenze und Beobachtungen zusammen.
- Ansicht.html läuft lokal im Browser. Sie zeigt jeden der 120 Pilotfälle und verarbeitet eigene Paarzahlen zu den zwei festgelegten Budgets.
- BEWEIS.md enthält die Annahmen, Herleitungen, Endpunktkonventionen und Begrenzung der Intervallbreite.
- records/certificate.json enthält die exakten rationalen Zahlengrenzen. records/controls.json enthält die Gegenrechnungen. records/pilot_audit.json weist alle vorab festgelegten Gruppen, Kontrollintervalle und einseitigen Konsistenztests aus.
- pilot/observations.npz enthält 120 × 112500 Gruppenzahlen (uint8, Werte von 0 bis 28). Die Summe einer Zeile ist der verwendete Zählwert. Simulationsparameter und Koordinatenhashes stehen getrennt in pilot/truth.json. In pilot/decisions.json stehen die Ausgaben vor der Zusammenführung mit der Wahrheit.
- reference/ enthält die benötigten Originalmodule aus v0.2, Quellnachweis und Lizenz. Die lokalen Primärquellen und ihre Prüfsummen wurden vor den Pilotdaten fixiert. Der Freeze ist keine öffentliche Vorregistrierung.

## Reproduktion

Im Paketverzeichnis mit Python, NumPy und SciPy (Versionen in records/environment.json). Für die Prüfung der Browseransicht wird zusätzlich Node benötigt. Die mathematischen Freigabeentscheidungen verwenden ganze Zahlen und Brüche.

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B theorem.py > /tmp/x6-v03-certificate.json
cmp /tmp/x6-v03-certificate.json records/certificate.json
python -B controls.py > /tmp/x6-v03-controls.json
cmp /tmp/x6-v03-controls.json records/controls.json
python -B score.py pilot/observations.npz > /tmp/x6-v03-scores.json
cmp /tmp/x6-v03-scores.json pilot/decisions.json
python -B pilot_audit.py pilot > /tmp/x6-v03-audit.json
cmp /tmp/x6-v03-audit.json records/pilot_audit.json
python -B visual/build.py /tmp/x6-v03-view.html --tests /tmp/x6-v03-view-checks.json
cmp /tmp/x6-v03-view.html Ansicht.html
node visual/verify.cjs /tmp/x6-v03-view-checks.json
```

Um alle 108 Millionen simulierten Ereignisse erneut zu erzeugen, ein **neues** Zielverzeichnis verwenden:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python -B simulate.py /tmp/x6-v03-pilot --workers 4
cmp pilot/observations.npz /tmp/x6-v03-pilot/observations.npz
cmp pilot/truth.json /tmp/x6-v03-pilot/truth.json
```

Die zweite lokale Ausführung mit anderer Workeranzahl reproduzierte die Dateien bytegleich. Plattformabhängige Gleitkommadetails können insbesondere die Koordinatenhashes auf anderen Rechnern beeinflussen. assert-Kontrollen bei einer Wiederholung aktiviert lassen.

## Eine eigene Ordnung prüfen

```sh
python rule.py blocks --count 320308
python rule.py full --outdegrees zeilensummen.txt
python rule.py blocks --packed relation.bin
```

Die Methoden passen nur zu ihrer jeweiligen festen Ereigniszahl. Bei der Vollzählung ist jede Zeilensumme die Anzahl der Nachfolger in der **gesamten** strikten transitiven Relation. Die Eingabe der kompakten Bitmatrix ist zeilenweise und little-bitorder pro Byte. Diese Schnittstelle setzt eine gültige Kausalordnung voraus; sie zertifiziert nicht deren Erzeugungsmodell. Ist eine Abfrageschnittstelle vorhanden, kann block_counts direkt mit einem booleschen Vergleichbarkeitsorakel und einem unabhängigen Zufallsgenerator benutzt werden. Die Paarabfrage ist ungerichtet. Bei einem nur gerichteten Orakel werden bis zu zwei Zugriffe benötigt. Die Berechnung der Transitivhülle aus Hasse-Kanten ist nicht eingepreist.

Die Achtergruppen werden nur einmal unabhängig von der Ordnung gebildet. Für vorab festgelegte Replays einer Gruppierung akzeptiert die Bitmatrix-Schnittstelle --seed. Die Garantien sind modellbedingt und gelten vor der Beobachtung. Wiederholtes Gruppieren, bis ein günstiger Ausgang entsteht, ist nicht abgedeckt.
