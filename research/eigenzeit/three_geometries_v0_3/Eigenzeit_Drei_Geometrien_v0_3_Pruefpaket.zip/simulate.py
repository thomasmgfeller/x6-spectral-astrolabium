"""Generate the fixed implementation pilot. The decision code only sees ordered-count records."""
import argparse
import hashlib
import json
import math
import multiprocessing
import os
from fractions import Fraction
from pathlib import Path
import numpy as np
from rule import CONFIG,block_counts

def seed(key,purpose):
    text=f"{CONFIG['pilot']['seed_namespace']}/{key}/{purpose}"
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:16],'big')

def rng(key,purpose):
    return np.random.Generator(np.random.PCG64(seed(key,purpose)))

def schedule():
    cfg=CONFIG['pilot'];cases=[]
    for h,number in cfg['cases'].items():
        if number%2:raise ValueError('balanced chart design')
        for i in range(number):cases.append((h,'original' if i%2==0 else 'aligned'))
    ids=rng('layout','shuffle').permutation(len(cases))
    return sorted([(int(idx),h,chart) for idx,(h,chart) in zip(ids,cases)])

def points(n,h,chart,stream):
    out=np.empty((n,4));filled=proposed=0
    delta=(h/(2*(1+math.sqrt(1-h*h/4))))**2
    while filled<n:
        size=min(131072,max(4096,n-filled))
        width=.5*stream.random(size)**.25
        t=(.5-width)*np.where(stream.integers(0,2,size=size)==0,-1.,1.)
        radius=width*np.cbrt(stream.random(size))
        if chart=='original':keep=stream.random(size)<=((1-h/2)/(1-h*t))**4
        elif chart=='aligned':keep=stream.random(size)<=((1-delta)/(1-delta*4*(t*t-radius*radius)))**4
        else:raise ValueError(chart)
        t=t[keep][:n-filled];radius=radius[keep][:n-filled];k=len(t)
        cosine=stream.uniform(-1.,1.,k);phi=stream.uniform(0.,2*np.pi,k)
        transverse=radius*np.sqrt((1-cosine)*(1+cosine))
        slot=out[filled:filled+k];slot[:,0]=t;slot[:,1]=transverse*np.cos(phi)
        slot[:,2]=transverse*np.sin(phi);slot[:,3]=radius*cosine
        if np.any(abs(t)+radius>.5+1e-15):raise ValueError('outside diamond')
        filled+=k;proposed+=size
    return out,proposed

def run_case(job):
    index,h,chart=job
    n=CONFIG['methods']['blocks']['N'];cloud,proposed=points(n,float(Fraction(h)),chart,rng(index,'volume'))
    def query(i,j):
        d=cloud[i]-cloud[j]
        return d[:,:,0]**2>np.einsum('...i,...i->...',d[:,:,1:],d[:,:,1:])
    def check(i,j):
        x=cloud[i];y=cloud[j]
        return abs(x[:,:,0]-y[:,:,0])>np.linalg.norm(x[:,:,1:]-y[:,:,1:],axis=2)
    counts=block_counts(n,query,rng(index,'groups'),check=check)
    truth=dict(id=index,h=h,chart=chart,proposals=proposed,coords_sha256=hashlib.sha256(cloud.astype('<f8',copy=False).tobytes()).hexdigest(),
               block_counts_sha256=hashlib.sha256(counts.tobytes()).hexdigest())
    return index,counts,truth

def run(dest,workers):
    dest.mkdir(parents=True,exist_ok=False)
    jobs=schedule();cfg=CONFIG['methods']['blocks'];data=np.empty((len(jobs),cfg['N']//cfg['b']),dtype=np.uint8);truth=[None]*len(jobs)
    with multiprocessing.get_context('spawn').Pool(workers) as pool:
        for i,counts,row in pool.imap_unordered(run_case,jobs):
            data[i]=counts;truth[i]=row
    if any(t is None for t in truth):raise RuntimeError('missing observation')
    # Separate data files; the scorer reads only counts. Truth is joined by audit.py.
    np.savez_compressed(dest/'observations.npz',blocks=data)
    (dest/'truth.json').write_text(json.dumps(truth,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('destination',type=Path);p.add_argument('--workers',type=int,default=1)
    a=p.parse_args();run(a.destination,a.workers)
