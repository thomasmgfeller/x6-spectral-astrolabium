"""No simulator labels or chart information are accepted by this stage."""
import argparse,json
from pathlib import Path
import numpy as np
from rule import CONFIG,infer_count

def score(path):
    cfg=CONFIG['methods']['blocks']
    with np.load(path,allow_pickle=False) as f:data=f['blocks']
    expected=(sum(CONFIG['pilot']['cases'].values()),cfg['N']//cfg['b'])
    if data.shape!=expected or data.dtype!=np.uint8 or np.any(data>28):
        raise ValueError('invalid block records')
    return [dict(id=i,count=int(k),**infer_count('blocks',cfg['N'],int(k))) for i,k in enumerate(data.sum(axis=1,dtype=np.uint64))]

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('observation',type=Path)
    print(json.dumps(score(p.parse_args().observation),indent=2))
