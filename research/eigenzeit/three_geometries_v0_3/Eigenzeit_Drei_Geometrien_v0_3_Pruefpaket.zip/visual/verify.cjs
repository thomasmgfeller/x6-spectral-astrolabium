const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const h=fs.readFileSync('Ansicht.html','utf8'),els=new Map();
for(const [,id] of h.matchAll(/\sid="([^"]+)"/g)) els.set(id,{style:{},checked:false,value:'',addEventListener(k,v){this[k]=v;}});
const get=id=>els.get(id);get('mode').value='pilot';get('case').value='4';get('method').value='blocks';
const ctx={document:{getElementById:get}};vm.createContext(ctx);vm.runInContext(h.match(/<script>([\s\S]*?)<\/script>/)[1],ctx);
let n=0;for(const [m,k,mask,q] of JSON.parse(fs.readFileSync(process.argv[2]))){assert.deepEqual(JSON.parse(JSON.stringify(ctx.decode(m,k))),{mask,q});n++}
const records=JSON.parse(fs.readFileSync('pilot/decisions.json'));for(const r of records){get('case').value=r.id+1;ctx.show();assert(!get('result').hidden);assert.equal(els.get('m0').className==='chip on',r.candidates.includes('0'));}
get('case').value=4;get('showtruth').checked=true;ctx.show();assert(!get('truthmark').hidden&&get('truthtext').textContent.includes('3/8'));get('prev').click();assert.equal(get('case').value,3);
get('mode').value='own';get('count').value='-1';ctx.show();assert(get('result').hidden);get('count').value='0';ctx.show();assert(get('segment').hidden);
console.log('PASS',n,'threshold checks and 120 viewer records');
