from pathlib import Path
import json,sys,math
from fractions import Fraction as Q
from itertools import chain
import argparse
parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);parser.add_argument('--tests',type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from rule import table,GRID,G,CONFIG,total_pairs,infer_count
hs,pl,pu,ql,qu=table();test=[];methods={}
for method,opt in CONFIG['methods'].items():
    d=total_pairs(method);r=Q(opt['radius'])
    lo=[math.ceil(d*(x-r)) for x in pl[:-1]];hi=[math.floor(d*(x+r)) for x in pu[1:]]
    grid=[[math.ceil(d*(pl[int(2*G*h)]-r)),math.floor(d*(pu[int(2*G*h)]+r))] for h in GRID]
    methods[method]=dict(total=d,lo=lo,hi=hi,grid=grid)
    for k in sorted(set([0,d]+[n+i for n in chain(lo,hi,*grid) for i in (-1,0,1) if 0<=n+i<=d])):
        a=infer_count(method,opt['N'],k);q=a['q_interval']
        test.append([method,k,sum(1<<i for i,h in enumerate(GRID) if str(h) in a['candidates']),None if not q else [int(Q(x)*10**9) for x in q]])
samples=[];r=root/'pilot'
for a,b in zip(json.loads((r/'decisions.json').read_text()),json.loads((r/'truth.json').read_text())):
    assert a['id']==b['id'];h=Q(b['h']);samples.append(dict(k=a['count'],h=str(h),q=48*math.atanh(float(h)/2)**2))
data=dict(ql=[int(x*10**9) for x in ql],qu=[int(x*10**9) for x in qu],methods=methods,samples=samples)
p=root/'visual/template.html';html=p.read_text().replace('__DATA__',json.dumps(data,separators=(',',':')))
args.output.write_text(html)
if args.tests:args.tests.write_text(json.dumps(test,separators=(',',':')))
print('boundary tests',len(test))
