"""Independent geometry, variance, inversion, risk and API checks."""
from fractions import Fraction as Q
from itertools import combinations,product,repeat,chain
from math import sqrt,erfc,log,ceil,comb
from pathlib import Path
import json
import numpy as np
from numpy.polynomial.legendre import leggauss
from geometry_model import GRID,ref,base,universal
from theorem import worst_width
from rule import CONFIG,BASE,G,table,infer_count,total_pairs,count_from_outdegrees,block_counts

def run(certificate):
    hs,pl,pu,ql,qu=table();params,third,cell_bounds=universal()
    # Midpoint sweep in addition to the analytical bounds over every cell.
    for j,(low,high) in enumerate(cell_bounds):
        sample=base.parameter_bounds(Q(2*j+1,256))
        if not low<=sample[2]<=sample[3]<=high:raise AssertionError('variance-cell midpoint')
    # Independent affinity quadrature on a shared chart and log-based budget crosscheck.
    x,w=leggauss(64);s=x[:,None]*x[None,:];mass=3/8*(x[:,None]-x[None,:])**2*w[:,None]*w[None,:]
    for row in certificate['necessary']:
        h=[float(Q(v)) for v in row['h']]
        den=[(1-(v/(2*(1+sqrt(1-v*v/4))))**2*s)**-4 for v in h]
        aff2=np.sum(mass*np.sqrt(den[0]*den[1]))**2/(np.sum(mass*den[0])*np.sum(mass*den[1]))
        if abs(float(Q(row['affinity_squared_lower']))-aff2)>2e-13 or ceil(log(.3025)/log(aff2))!=row['necessary_N']:
            raise AssertionError('independent affinity')
    # Finite population of iid draws from a small three-state point law, exact enumeration of b=4 block variance.
    prob=[Q(1,5),Q(3,10),Q(1,2)];kernel=lambda i,j: int((i,j) in [(0,1),(1,0),(0,2),(2,0)])
    p=sum(prob[i]*prob[j]*kernel(i,j) for i,j in product(range(3),repeat=2))
    v=sum(prob[i]*(sum(prob[j]*kernel(i,j) for j in range(3))-p)**2 for i in range(3))
    var=Q(0)
    for draw in product(range(3),repeat=4):
        weight=Q(1)
        for k in draw:weight*=prob[k]
        y=Q(sum(kernel(i,j) for i,j in combinations(draw,2)),6)
        var+=weight*(y-p)**2
    if var!=(2*p*(1-p)+8*v)/12:raise AssertionError('block variance identity')
    # Verify reported interval diameter by a separate exhaustive all-cell-pair sweep, using integer endpoints.
    pscale=10**13;qscale=10**9
    il,iu,al,au=[np.asarray([int(x*scale) for x in v],dtype=np.int64) for v,scale in [(pl,pscale),(pu,pscale),(ql,qscale),(qu,qscale)]]
    for method,rec in certificate['methods'].items():
        n=rec['n'];r=Q(rec['radius']);M=total_pairs(method)
        best=0
        for j in range(G):
            valid=il[j:G]-iu[j+1]<=int(2*r*pscale)
            best=max(best,int((au[j+1:G+1]-al[j])[valid].max()))
        if Q(best,qscale)!=Q(rec['returned_q_width_upper']):raise AssertionError('width enumeration')
        for i in range(257):
            k=(M*(Q(99,1000)+Q(i,256*150))).__floor__(); o=infer_count(method,n,k);u=Q(k,M)
            idx=[j for j in range(G) if pl[j]<=u+r and pu[j+1]>=u-r]
            h_range=[str(hs[idx[0]]),str(hs[idx[-1]+1])] if idx else None
            if h_range!=o['h_interval'] or o['candidates']!=[str(h) for h in GRID if pl[int(2*G*h)]<=u+r and pu[int(2*G*h)]>=u-r]:
                raise AssertionError('inverse vs scan')
        for h in [Q(0),Q(7,65),Q(3,8),Q(1,2)]:
            plo,phi=ref.probability(h);k=int(M*(plo+phi)/2)
            ans=infer_count(method,n,k);assert ans['h_interval'] and Q(ans['h_interval'][0])<=h<=Q(ans['h_interval'][1])
        assert infer_count(method,n,0)['q_interval'] is None and infer_count(method,n,M)['q_interval'] is None
        # Verify the directional tails independently with floating special functions, including BE and remainder.
        P,P1,V,V1=map(float,params[:4]);n=rec['n']
        for elem in rec['grid_performance']:
            for side in ['left','right']:
                d=float(Q(elem[side+'_margin']));bound=float(Q(elem[side+'_failure_upper']))
                if method=='blocks':
                    b=CONFIG['methods'][method]['b'];m=n//b
                    lo=(2*P*(1-P)+4*(b-2)*V)/(b*(b-1))
                    hi=(2*P1*(1-P1)+4*(b-2)*V1)/(b*(b-1))
                    numeric=.5*erfc(d*sqrt(m/(2*hi)))+.3328*((1-P)/sqrt(lo)+.429)/sqrt(m)
                else:
                    vr=2*(P1*(1-P1)-2*V)/(n*(n-1))
                    be=.3328*(float(third)/V**1.5+.429)/sqrt(n)
                    numeric=min(.5*erfc((d-k/100000)*sqrt(n/(8*V1)))+be+vr/(vr+(k/100000)**2) for k in range(1,41) if k/100000<d)
                if not numeric-2e-12<=bound<=numeric+1e-5:raise AssertionError('risk evaluation')
    n=CONFIG['methods']['full']['N'];a,b=120000,151000
    counted=count_from_outdegrees(n,chain(repeat(b,a),repeat(0,n-a)))
    assert counted==a*b
    actual=infer_count('full',n,counted)
    # Small actual strict orders: equality of a direct all-pair count and row summaries.
    for nsmall in (8,16,40):
        ids=np.arange(nsmall);am=(ids%3==0)[:,None] & (ids%3==1)[None,:]
        direct=sum(int(am[i,j] or am[j,i]) for i,j in combinations(range(nsmall),2))
        assert direct==count_from_outdegrees(nsmall,(int(x) for x in am.sum(axis=1)))
        pair=lambda i,j: am[i,j]|am[j,i]
        blocks=block_counts(nsmall,pair,np.random.default_rng(702))
        group=np.random.default_rng(702).permutation(nsmall).reshape(-1,8)
        assert list(map(int,blocks))==[sum(int(am[i,j] or am[j,i]) for i,j in combinations(sub,2)) for sub in group]
    for inp in [(-1,), (0,), (1,1,1), (True,0)]:
        try:count_from_outdegrees(2,inp)
        except ValueError:continue
        raise AssertionError('invalid outdegrees')
    return dict(status='PASS',variance_midpoints=64,affinity_quadratures=3,exact_toy_block_outcomes=81,
                exhaustive_width_cell_pairs_per_method=G*(G+1)//2,inversion_crosschecks=514,risk_crosschecks=12,
                full_synthetic_order=dict(n=n,outdegree_count=counted,output=actual),
                scope='Known synthetic order for full mode at 600000. No full-budget stochastic all-pairs campaign.')

if __name__=='__main__':
    print(json.dumps(run(json.loads((BASE/'records/certificate.json').read_text())),indent=2))
