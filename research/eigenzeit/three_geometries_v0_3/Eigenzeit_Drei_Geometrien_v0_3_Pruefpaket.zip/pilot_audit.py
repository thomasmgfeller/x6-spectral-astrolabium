"""Join truth only after scoring, check raw fingerprints and summarize all pilot outcomes."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from collections import Counter
from pathlib import Path
import hashlib,json
import numpy as np
from scipy.stats import beta,binom
from rule import CONFIG,GRID

def cp(k,n):
    alpha=.05/(2*8)
    return [float(beta.ppf(alpha,k,n-k+1)) if k else 0.,float(beta.isf(alpha,k+1,n-k)) if k<n else 1.]

def main(directory):
    truth=json.loads((directory/'truth.json').read_text())
    scores=json.loads((directory/'decisions.json').read_text())
    with np.load(directory/'observations.npz',allow_pickle=False) as f:obs=f['blocks']
    if not len(truth)==len(scores)==len(obs)==sum(CONFIG['pilot']['cases'].values()):raise ValueError('length')
    rows=[]
    for i,(t,s,blocks) in enumerate(zip(truth,scores,obs)):
        if t['id']!=s['id'] or i!=s['id'] or int(blocks.sum())!=s['count'] or hashlib.sha256(blocks.tobytes()).hexdigest()!=t['block_counts_sha256']:
            raise ValueError('wrong count, order or digest')
    for h,n in CONFIG['pilot']['cases'].items():
        samples=[s for t,s in zip(truth,scores) if t['h']==h]
        charts=Counter(t['chart'] for t in truth if t['h']==h)
        if len(samples)!=n or charts!={'original':n//2,'aligned':n//2}:raise ValueError('wrong sample or chart balance')
        k=sum(s['h_interval'] is not None and Q(s['h_interval'][0])<=Q(h)<=Q(s['h_interval'][1]) for s in samples)
        row=dict(h=h,n=n,coverage=k,coverage_CP_simultaneous=cp(k,n),coverage_consistency_p=float(binom.cdf(k,n,.95)),
                 first_case=samples[0],empty_grid=sum(not s['candidates'] for s in samples),
                 empty_continuous=sum(s['h_interval'] is None for s in samples))
        if Q(h) in GRID:
            k=sum(s['candidates']==[h] for s in samples)
            row.update(singleton=k,singleton_CP_simultaneous=cp(k,n),singleton_consistency_p=float(binom.cdf(k,n,.80)))
        rows.append(row)
    pvalues=[val for row in rows for k,val in row.items() if k.endswith('_consistency_p')]
    return dict(rows=rows,number_of_tests=len(pvalues),gate='FLAG' if min(pvalues)<=.05/8 else 'NO_FLAG',
                note='Prespecified one-sided consistency checks. A NO_FLAG does not qualify empirical performance.')
if __name__=='__main__':
    p=ArgumentParser();p.add_argument('directory',type=Path)
    print(json.dumps(main(p.parse_args().directory),indent=2))
