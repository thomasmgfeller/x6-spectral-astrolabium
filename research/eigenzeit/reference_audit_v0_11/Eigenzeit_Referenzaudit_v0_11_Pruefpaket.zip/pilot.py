"""Generate fixed sufficient statistics for independent synthetic campaigns."""
import argparse
from pathlib import Path
import json
import hashlib
import numpy as np
from audit import NODES, PAIRS, MAX_DISCORDANT

DESIGN = json.loads(Path(__file__).with_name("design.json").read_text())
SPEC = DESIGN["pilot"]
# All probabilities are for (01)+(10); signs and common bias do not enter the count rule.
def rates(profile):
    values = np.full(len(NODES), 3e-6)
    if profile == "one_14ppm":
        values[-1] = 14e-6
    elif profile == "one_21ppm":
        values[-1] = 21e-6
    elif profile == "balanced_30ppm":
        values[:] = 30e-6
    elif profile == "common_bias_50ppm":
        values[:] = 0
    elif profile != "all_3ppm":
        raise ValueError(profile)
    return values


def run():
    results = {}
    for i, profile in enumerate(SPEC["profiles"]):
        rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([SPEC["seed"], i])))
        counts = rng.binomial(PAIRS, rates(profile), (SPEC["repetitions"], len(NODES))).astype("<u4")
        accepted = (counts <= MAX_DISCORDANT).all(axis=1)
        results[profile] = dict(repetitions=len(accepted), pass_counts=int(accepted.sum()),
                                first_node_max=int(counts[:,0].max()),
                                sufficient_statistics_sha256=hashlib.sha256(counts.tobytes()).hexdigest())
    return results


if __name__ == "__main__":
    print(json.dumps(run(), sort_keys=True, indent=2))
