"""Post-design analytical controls and exact logical tests for the early stop."""
from decimal import Decimal as D, localcontext
from pathlib import Path
import json
from copy import deepcopy
from audit import read_json
from screen import screen

HERE=Path(__file__).resolve().parent


def cdf(ppm):
    p=D(ppm)/10**6
    mass=(1-p)**3300000
    total=mass
    for k in range(25):
        mass=mass*(3300000-k)*p/((k+1)*(1-p))
        total+=mass
    return total


def run():
    with localcontext() as ctx:
        ctx.prec=80
        safe=cdf(3)
        balanced=cdf(30)**32
        unsafe=safe**30*cdf(21)**2
        assert 0 < balanced < D("1e-400") and 0 < unsafe < D("1e-12")
        threshold=read_json(HERE/"examples/prefix_25.json")
        assert screen(threshold)["status"]=="NO_EARLY_STOP"
        assert screen(read_json(HERE/"examples/prefix_26.json"))["status"]=="STOP_DISCORDANCE"
        tested=0
        for k in range(28):
            prefix=deepcopy(threshold);prefix["counts"]={"00":100,"01":k,"10":0,"11":100}
            stop=screen(prefix)["status"]=="STOP_DISCORDANCE"
            for later in range(40):
                assert not stop or k+later>25
                tested+=1
        return dict(balanced_30ppm_probability_all_nodes_pass=format(balanced,'.10E'),
                    matched_stationary_unsafe_cell_both_nodes_21ppm_pass=format(unsafe,'.10E'),
                    future_only_undetectable_jump_ppm=30,shared_comparator_bias_ppm=50,
                    early_stop_extension_checks=tested,
                    expected_pairs_until_negative_screen_upper_at_half=52,
                    expected_pairs_until_negative_screen_upper_at_one_percent=2600)
if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
