"""Independent numerical and operational cross-checks for the v0.11 package."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
from copy import deepcopy
import scipy
from scipy.stats import binom
import numpy as np
from audit import NODES, PAIRS, MAX_DISCORDANT, OUTCOMES, assess, read_json
from certificate import binomial_cdf

HERE = Path(__file__).resolve().parent


def verify():
    record = read_json(HERE/"records/certificate.json")
    assert all(len(NODES) == s for s in (32,read_json(HERE/"design.json")["cells"]*2))
    bad = binom.cdf(25,3300000,14e-6)
    good = binom.sf(25,3300000,3e-6)
    assert abs(float(F(record["false_audit_pass_upper"]))-bad)<1.1e-12
    assert abs(float(F(record["audit_hold_good_class_upper"]))-32*good)<1.1e-12
    count = 0
    for n in range(1,20):
        for k in range(n):
            for p in (F(1,7),F(1,2),F(2,5)):
                exact = sum(math.comb(n,i)*p**i*(1-p)**(n-i) for i in range(k+1))
                lo,hi = binomial_cdf(n,k,p)
                assert lo <= exact <= hi
                count += 1
    # Both paired outcome laws have exactly the same distribution for the block total.
    d=F(30,10**6)
    world_a=[F(1,4)]*4
    world_b=[F(1,4), F(1,4)+d, F(1,4)-d, F(1,4)]
    def pooled(w):return [w[0], w[1]+w[2], w[3]]
    assert pooled(world_a) == pooled(world_b) and world_b[2]+world_b[3]==F(1,2)-d
    e=HERE/"examples"
    expected=dict(synthetic_pass="SYNTHETIC_PASS", one_node_26="HOLD_DISCORDANCE", all_at_or_below_25="SYNTHETIC_PASS",
                  relabeled_synthetic="HOLD_EVIDENCE", no_independent_anchor="HOLD_EVIDENCE", field_worksheet="HOLD_EVIDENCE")
    for name,status in expected.items():
        result=assess(read_json(e/(name+".json")),e)
        assert result["status"]==status and not result["geometry_release"]
    malformed=read_json(e/"synthetic_pass.json")
    for item in (None,-1,True,3.14,PAIRS+1):
        r=deepcopy(malformed)
        r["nodes"][NODES[0]]["01"]=item
        assert assess(r,e)["status"]=="HOLD_INPUT"
    r=deepcopy(malformed);r["nodes"].pop(NODES[-1]);assert assess(r,e)["status"]=="HOLD_INPUT"
    for badref in ({"file":"../design.json","sha256":hashlib.sha256((HERE/"design.json").read_bytes()).hexdigest()},
                   {"file":"synthetic_receipt.json","sha256":"0"*64}):
        r=deepcopy(malformed);r["evidence"][next(iter(r["evidence"]))]=badref
        assert assess(r,e)["status"]=="HOLD_EVIDENCE"
    # Check pilot vectorisation independently from its exact generating probabilities.
    pilot = read_json(HERE/"records/pilot.json")
    pcdf=lambda ppm: float(binom.cdf(25,3300000,ppm/1e6))
    good_node=pcdf(3)
    predictions=dict(all_3ppm=good_node**32,one_14ppm=good_node**31*pcdf(14),
                     one_21ppm=good_node**31*pcdf(21),balanced_30ppm=pcdf(30)**32,common_bias_50ppm=1.)
    intervals = {}
    for name,prob in predictions.items():
        r=pilot[name]
        lo,hi=binom.interval(.99999, r["repetitions"], prob)
        assert lo<=r["pass_counts"]<=hi
        intervals[name]=[int(lo),int(hi)]
    return dict(scipy=scipy.__version__,numpy=np.__version__,exact_small_cdf_tests=count,
                false_audit_at_boundary=format(bad,'.12g'), good_audit_union=format(32*good,'.12g'),
                exact_pooled_count_law=[str(x) for x in pooled(world_b)],first_trial_in_unsafe_world=str(F(1,2)-d),
                examples=expected,analytic_model_predicted_pass={k:format(v,'.10g') for k,v in predictions.items()},
                pilot_prediction_intervals_99999=intervals)

if __name__=="__main__":
    print(json.dumps(verify(),sort_keys=True,indent=2))
