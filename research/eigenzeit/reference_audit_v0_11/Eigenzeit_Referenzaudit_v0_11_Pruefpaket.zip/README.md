# Eigenzeit v0.11 · Ein Audit für die 20-ppm-Driftgrenze

Der Prüfling und ein separat auf das wissenschaftliche Ziel kalibrierter Standard liefern je markierter Gelegenheit zwei binäre Antworten. Ein fester Zähltest schließt unter sieben externen Zusagen zu große Abweichungen aus. Das Fehlerbudget für die Betriebsübertragung beträgt 6 ppm. Die verbleibenden 14 ppm prüft die Häufigkeit diskordanter Paare an zwei Stützstellen in jeder der 16 Zellen. Für einen unkalibrierten oder stark anders reagierenden Vergleichskanal kann das Verfahren keine Feldfreigabe liefern.

| Datei | Inhalt |
|---|---|
| Bericht.pdf | Forschungsbericht mit Entscheidung und Messplan |
| BEWEIS.md | Modell, Beweis, Risikoübertragung, zwei Ununterscheidbarkeitsargumente und Informationsuntergrenze |
| FELDPROTOKOLL.md und examples/field_worksheet.json | Erster Messpunkt, dokumentierte Voraussetzungen, Datenformat und Übergabe an v0.10 |
| audit.py und screen.py | Auswertung vollständiger Kampagnen und unwiderruflicher negativer Präfixe |
| design.json, certificate.py und records/certificate.json | Plan und gerichtete, reproduzierbare Fehlerschranken |
| pilot.py und records/pilot.json | 5 × 40.000 synthetische Kampagnen, Seeds und SHA-256 der hinreichenden diskordanten Zählungen |
| verify.py, controls.py und records/ | Unabhängige numerische Gegenrechnung, exakte kleine Fälle, Feldbeispiele und Kontrollen |
| previous/ | Vier bytegleiche Quellen aus dem veröffentlichten v0.10-Archiv samt Herkunft und Hashes |

## Ausführen

Python ab 3.11 für den Feldprüfer und das ganzzahlige Zertifikat. Der vollständige Wiederholungslauf wurde mit Python 3.12, NumPy 2.3.5 und SciPy 1.17.0 durchgeführt. Im entpackten Verzeichnis ausführen.

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B audit.py examples/field_worksheet.json
python -B audit.py examples/synthetic_pass.json
python -B audit.py examples/no_independent_anchor.json
python -B screen.py examples/prefix_26.json
python -B reproduce.py
```

Der Wiederholungslauf verifiziert die vier Quellübernahmen und vergleicht vier frisch berechnete Ergebnisdateien byteweise mit den archivierten Protokollen. Das eingefrorene Pilotprogramm simuliert direkt die hinreichenden Diskordanzzähler und erzeugt deren Hashes in Little-Endian-uint32-Darstellung (40.000 Zeilen, 32 Spalten). Die fünf Profile sind eine Modellprüfung. Es liegen keine Rohmessungen einer Anlage vor. Im 30-ppm-Kontrollfall unterschreitet die analytische Annahmewahrscheinlichkeit den normalen Gleitkommabereich der SciPy-Ausgabe. Die ergänzende Dezimalrechnung steht in records/controls.json.

Bei Bedarf lässt sich die Herkunft gegen das GitHub-Original mitprüfen. Dessen SHA-256 wird vor dem byteweisen Vergleich aller vier Dateien geprüft.

```sh
python -B reproduce.py --previous-archive /pfad/zum/Eigenzeit_Driftreserve_v0_10_Pruefpaket.zip
```

Der lokale Freeze erfolgte vor der Erzeugung der neuen Pilotzählungen. Der negative Präfixprüfer und die ergänzenden Dezimalkontrollen kamen danach hinzu und verändern die feste Zählentscheidung nicht. Ein öffentlicher Zeitstempel für die Vorregistrierung liegt nicht vor. Datumsstand 1. November 2026.
