"""Outward-rounded integer bounds. No third-party dependency."""
from fractions import Fraction as F
from pathlib import Path
from math import ceil, floor
import json
from audit import NODES, PAIRS, MAX_DISCORDANT

SCALE = 10 ** 55
HERE = Path(__file__).resolve().parent


def div_up(a, b):
    return -(-a // b)


def product(x, y):
    return (x[0] * y[0] // SCALE, div_up(x[1] * y[1], SCALE))


def power(x, n):
    result = (SCALE, SCALE)
    while n:
        if n & 1:
            result = product(result, x)
        x = product(x, x)
        n //= 2
    return result


def binomial_cdf(n, k, p):
    u, v = p.numerator, p.denominator
    value = power(((v-u)*SCALE//v, div_up((v-u)*SCALE, v)), n)
    lo, hi = value
    for j in range(k):
        a, b = (n-j)*u, (j+1)*(v-u)
        value = (value[0]*a//b, div_up(value[1]*a, b))
        lo += value[0]
        hi += value[1]
    return F(lo, SCALE), min(F(hi, SCALE), F(1))


def upper(q):
    return F(ceil(q * 10**12), 10**12)


def lower(q):
    return F(floor(q * 10**12), 10**12)


def certify():
    previous = json.loads((HERE / "previous/records/certificate.json").read_text())
    assert previous["id"] == "X6/v0.10/anchored-drift/20ppm"
    cdf_bad = binomial_cdf(PAIRS, MAX_DISCORDANT, F(14, 10**6))
    cdf_good = binomial_cdf(PAIRS, MAX_DISCORDANT, F(3, 10**6))
    a = upper(cdf_bad[1])
    b = upper(len(NODES) * (1 - cdf_good[0]))
    assert a < F(1,2000) and b < F(1,2000)
    alpha10, beta10 = map(F, (previous["false_go_upper"], previous["good_hold_upper"]))
    # Certify ln(1999) > 7.6 using a rational geometric majorant of the exp tail.
    x = F(38,5)
    term = total = F(1)
    for i in range(1,61):
        term *= x/i
        total += term
    assert total + term*x/61/(1-x/62) < 1999
    delta = F(20,10**6)
    kl_bound = 2*delta**2/(1-4*delta**2)
    per_cell = F(999,1000)*x/kl_bound
    return dict(design="X6/v0.11/paired-reference/20ppm", nodes=len(NODES),
                pairs_per_node=PAIRS, audit_pairs=PAIRS*len(NODES), maximum_discordant=MAX_DISCORDANT,
                deterministic_reserve_ppm=2+(8+4)*F(1,4)+1, statistical_remainder_ppm=14,
                false_audit_pass_upper=a, audit_hold_good_class_upper=b,
                combined_false_go_upper_additive=upper(a+alpha10),
                combined_good_hold_upper=upper(b+beta10),
                combined_coverage_lower_conservative=lower(F(previous["coverage_lower"])-a),
                combined_good_singleton_lower_conservative=lower(F(previous["good_singleton_lower"])-b),
                ideal_unpaired_expected_total_strictly_above=floor(16*per_cell),
                ideal_unpaired_expected_per_cell_strictly_above=floor(per_cell),
                max_audit_plus_v10_opportunities=PAIRS*len(NODES)+previous["max_trials"])


if __name__ == "__main__":
    print(json.dumps(certify(), default=str, indent=2, sort_keys=True))
