"""Recompute all four numerical records and verify inherited v0.10 inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile
HERE=Path(__file__).resolve().parent

def require(ok,label):
    if not ok:
        raise ValueError(label)

def main(archive):
    for name in ("FREEZE.sha256","MANIFEST.sha256"):
        rows=(HERE/name).read_text().splitlines()
        entries={}
        for line in rows:
            digest,path=line.split(None,1)
            require(path not in entries,path)
            entries[path]=digest
            require(hashlib.sha256((HERE/path).read_bytes()).hexdigest()==digest,path)
        if name=="MANIFEST.sha256":
            actual={str(p.relative_to(HERE)) for p in HERE.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
            require(actual==set(entries)|{name},"archive inventory")
    origin=json.loads((HERE/"previous/ORIGIN-v10.json").read_text())
    for path,digest in origin["files"].items():
        require(hashlib.sha256((HERE/"previous"/path).read_bytes()).hexdigest()==digest,path)
    if archive:
        require(hashlib.sha256(archive.read_bytes()).hexdigest()==origin["archive_sha256"],"v0.10 archive")
        with ZipFile(archive) as z:
            for path in origin["files"]:
                require(z.read(path)==(HERE/"previous"/path).read_bytes(),path)
    for script,rec in (("certificate","certificate"),("pilot","pilot"),("verify","verification"),("controls","controls")):
        result=subprocess.check_output([sys.executable,"-B",str(HERE/(script+".py"))],cwd=HERE)
        require(result==(HERE/"records"/(rec+".json")).read_bytes(),rec)
        print("PASS",rec)
if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--previous-archive",type=Path)
    main(cli.parse_args().previous_archive)
