"""Deterministic separation sweep, supplemental to the frozen simulation cells."""
import json
import sys
from pathlib import Path
from theory import one, export, A
b=one(A(2),A(1),A(.75),768,128)
rows=[]
for step in list(range(2,13))+[16,24,32]:
    d=A(step)/16
    a=one(A(2),A(1),d,768,128) if d<A(.75) else b
    rows.append({'delta':float(d),'sd':export((a[2][0]+b[2][0]).sqrt(), (a[2][1]+b[2][1]).sqrt()),
                 'p_both':export(a[0][0]*b[0][0],a[0][1]*b[0][1]),
                 'bias':[0,0] if d>=A(.75) else export(b[1][0]-a[1][1],b[1][1]-a[1][0])})
Path(sys.argv[1]).write_text(json.dumps(rows,indent=2)+'\n')
