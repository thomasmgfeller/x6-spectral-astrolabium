"""A priori statistical checks. Inputs are read from the original joint delays, not fitted."""
import argparse
import json
import math
from pathlib import Path
import numpy as np
from scipy.stats import beta
ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/'protocol.json').read_text())
def cp(n,k,alpha):
    return [float(beta.ppf(alpha/2,k,n-k+1)) if k else 0.,
            float(beta.ppf(1-alpha/2,k+1,n-k)) if n>k else 1.]
def eb(y,lo,hi,alpha):
    n=len(y);m=float(y.mean());v=float(y.var(ddof=1));z=math.log(4/alpha)
    radius=math.sqrt(2*v*z/n)+7*(hi-lo)*z/(3*(n-1))
    return [max(lo,m-radius),min(hi,m+radius)]
def compare(x,y):
    if x[0]>y[1] or x[1]<y[0]:return 'CONFLICT'
    if y[0]<=x[0] and x[1]<=y[1]:return 'MC_INSIDE_THEORY'
    return 'OVERLAP'
def analyse(data, theory):
    a=0.01/(3*len(SPEC['runs']))
    W=SPEC['W'];report={}
    for key,pred in theory.items():
        n,n1,n2,both=map(int,(data/(key+'.counts')).read_text().split())
        u=np.load(data/(key+'.npz'),allow_pickle=False)['delays']
        if u.shape!=(both,2) or not np.isfinite(u).all() or not ((0<=u)&(u<=W)).all():
            raise ValueError(key+' raw samples invalid')
        z=u[:,1]-u[:,0]
        ci=cp(n,both,a);mz=eb(z,-W,W,a);q=eb(z*z,0,W*W,a)
        minmean2=0 if mz[0]<=0<=mz[1] else min(v*v for v in mz)
        maxmean2=max(v*v for v in mz)
        sd=[math.sqrt(max(0,q[0]-maxmean2)),math.sqrt(max(0,q[1]-minmean2))]
        observed={'p_both':ci,'bias':mz,'sd':sd}
        report[key]={'trials':n,'hit_first':n1,'hit_second':n2,'double_hits':both,
                     'p_both':both/n,'bias':float(z.mean()),'sd':float(z.std(ddof=1)),
                     'cov_delays':float(np.cov(u.T)[0,1]),'corr_delays':float(np.corrcoef(u.T)[0,1]),
                     'intervals':observed,'comparison':{k:compare(v,pred[k]) for k,v in observed.items()}}
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dir',type=Path,required=True);args=p.parse_args()
    d=args.dir
    theory=json.loads((d/'theory.json').read_text())['rows']
    coarse=json.loads((d/'coarse.json').read_text())['rows']
    for case,row in theory.items():
        for stat,v in row.items():
            tol=1e-12
            if v[0]<coarse[case][stat][0]-tol or v[1]>coarse[case][stat][1]+tol:
                raise ValueError('mesh nesting '+case+' '+stat)
    result=analyse(d/'sim',theory)
    (d/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    for k,r in result.items():
        print(k,r['double_hits'], 'p %.6f,bias %.6f,sd %.6f'%(r['p_both'],r['bias'],r['sd']),
              r['intervals']['sd'],r['comparison'])
    if any(v=='CONFLICT' for r in result.values() for v in r['comparison'].values()):
        raise SystemExit('At least one interval is disjoint')
