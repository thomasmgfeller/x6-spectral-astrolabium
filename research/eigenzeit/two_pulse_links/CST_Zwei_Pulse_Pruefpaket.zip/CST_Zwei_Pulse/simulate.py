"""Execute the two independent samplers, saving joint samples and the lost-pair counts."""
import argparse
import json
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--jobs',type=int,default=2);args=parser.parse_args()
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    spec=json.loads((ROOT/'protocol.json').read_text())
    with tempfile.TemporaryDirectory() as t:
        exe=Path(t)/'sprinkle';subprocess.run(['g++','-std=c++17','-O3','-fno-fast-math',str(ROOT/'sprinkling.cpp'),'-o',str(exe)],check=True)
        def run(r):
            key=r['id'];args=[r['R'],r['rho'],r['delta'],spec['a'],spec['W'],spec['cos_half_angle'],r['trials'],r['seed'],
                               'whole' if key=='A_direct' else 'split',out/key,'yes' if key=='A' else 'no']
            subprocess.run([str(exe),*map(str,args)],check=True)
            for name in ([key,'A_unfiltered_gate'] if key=='A' else [key]):
                f=out/(name+'.bin');z=np.fromfile(f,dtype=np.float64).reshape(-1,2)
                np.savez_compressed(out/(name+'.npz'),delays=z)
                f.unlink()
            print(key,(out/(key+'.counts')).read_text().strip(),flush=True)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool: list(pool.map(run,spec['runs']))
