// Direct geometry simulation of one common 3+1 Poisson background per pulse pair.
// The simulator has no Alexandrov-volume formula, link probabilities, or quadrature.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <random>
#include <string>
#include <vector>

struct Point { double t,x,y,z; };
static double norm2(const Point& p){return p.x*p.x+p.y*p.y+p.z*p.z;}
static bool before(const Point& a,const Point& b){
    const double t=b.t-a.t,x=b.x-a.x,y=b.y-a.y,z=b.z-a.z;
    return t>0 && t*t>x*x+y*y+z*z;
}
struct Box {
    double start,du,dv,h;
    bool contains(const Point& p) const {
        const double u=p.t-p.x-start,v=p.t+p.x-start;
        return u>=0 && u<=du && v>=0 && v<=dv && std::abs(p.y)<=h && std::abs(p.z)<=h;
    }
};
struct Study {
    double R,rho,delta,a,W,k;
    bool gate(Point p,double start) const {
        double r2=norm2(p);
        return p.t>=start+R && p.t<=start+R+W && r2>=R*R && r2<=(R+a)*(R+a) &&
               p.x>=k*std::sqrt(r2);
    }
};
struct Cloud {
    std::mt19937_64 gen;
    std::vector<Point> points;
    std::vector<Box> boxes;
    std::vector<size_t> candidates;
    double unit(){return std::generate_canonical<double,53>(gen);}
    int poisson(double m){return std::poisson_distribution<int>(m)(gen);}
    void add_box(Box b,const Study& s,bool exclude_gates){
        const int count=poisson(s.rho*2*b.du*b.dv*b.h*b.h);
        for(int j=0;j<count;++j){
            const double u=b.du*unit(),v=b.dv*unit();
            Point p={b.start+(v+u)/2,(v-u)/2,(2*unit()-1)*b.h,(2*unit()-1)*b.h};
            if(exclude_gates && (s.gate(p,0)||s.gate(p,s.delta))) continue;
            if(std::any_of(boxes.begin(),boxes.end(),[&](const Box& old){return old.contains(p);}))continue;
            points.push_back(p);
        }
        boxes.push_back(b);
    }
    void gates_first(const Study& s){
        const double pi=std::acos(-1.0), ro=s.R+s.a;
        const double r3=s.R*s.R*s.R, width=ro*ro*ro-r3;
        for(double start:{0.0,s.delta}){
            int n=poisson(s.rho*(2*pi*(1-s.k))*s.W*width/3);
            for(int j=0;j<n;++j){
                const double r=std::cbrt(r3+width*unit()), mu=s.k+(1-s.k)*unit(), phi=2*pi*unit();
                double trans=r*std::sqrt(1-mu*mu);
                Point p={start+s.R+s.W*unit(),r*mu,trans*std::cos(phi),trans*std::sin(phi)};
                if(start>0 && s.gate(p,0))continue; // overlap already sampled
                candidates.push_back(points.size());points.push_back(p);
            }
        }
        for(size_t i:candidates){
            Point p=points[i];
            for(double start:{0.0,s.delta}){
                if(!s.gate(p,start)||!before({start,0,0,0},p))continue;
                double du=p.t-start-p.x,dv=p.t-start+p.x;
                add_box({start,du,dv,std::sqrt(du*dv)},s,true);
            }
        }
    }
    void whole_region(const Study& s){
        // Predetermined boxes enclose both full causal corridors before any detector query.
        const double du=s.W+s.R*(1-s.k),dv=2*s.R+s.W+s.a;
        for(double start:{0.0,s.delta})add_box({start,du,dv,std::sqrt(du*dv)},s,false);
        for(size_t i=0;i<points.size();++i)if(s.gate(points[i],0)||s.gate(points[i],s.delta))candidates.push_back(i);
    }
    std::array<double,4> trial(const Study& s,bool direct){
        points.clear();boxes.clear();candidates.clear();
        if(direct)whole_region(s);else gates_first(s);
        const double inf=std::numeric_limits<double>::infinity();
        std::array<double,4> time={inf,inf,inf,inf};
        Point source[2]={{0,0,0,0},{s.delta,0,0,0}};
        for(size_t i:candidates){
            Point p=points[i];
            for(int j=0;j<2;++j){
                const Point x=source[j],other=source[1-j];
                if(!s.gate(p,x.t)||!before(x,p))continue;
                double u=p.t-x.t-s.R;
                time[2+j]=std::min(time[2+j],u);
                if(u>=time[j]||(before(x,other)&&before(other,p)))continue;
                bool linked=true;
                for(size_t k=0;k<points.size();++k){
                    if(k!=i&&before(x,points[k])&&before(points[k],p)){linked=false;break;}
                }
                if(linked)time[j]=u;
            }
        }
        return time;
    }
};
struct Output {
    uint64_t first=0,second=0,both=0;
    std::ofstream data;
    explicit Output(const std::string& name):data(name,std::ios::binary){data.exceptions(std::ios::failbit|std::ios::badbit);}
    void add(double x,double y){
        if(std::isfinite(x))++first;
        if(std::isfinite(y))++second;
        if(std::isfinite(x)&&std::isfinite(y)){
            ++both;double z[2]={x,y};data.write(reinterpret_cast<const char*>(z),sizeof(z));
        }
    }
};
int main(int argc,char**argv){
    if(argc!=12){std::cerr<<"R rho delta a W mu trials seed mode output_base control\n";return 2;}
    Study s{std::stod(argv[1]),std::stod(argv[2]),std::stod(argv[3]),std::stod(argv[4]),std::stod(argv[5]),std::stod(argv[6])};
    int n=std::stoi(argv[7]); Cloud cloud{std::mt19937_64(std::stoull(argv[8])),{},{},{}};
    bool direct=std::string(argv[9])=="whole",control=std::string(argv[11])=="yes";
    std::string base=argv[10];Output output(base+".bin");
    std::unique_ptr<Output> unblocked;
    if(control)unblocked=std::make_unique<Output>(base+"_unfiltered_gate.bin");
    for(int j=0;j<n;++j){
        auto a=cloud.trial(s,direct);output.add(a[0],a[1]);if(control)unblocked->add(a[2],a[3]);
    }
    auto save=[&](const Output& o,const std::string& key){std::ofstream f(key+".counts");f<<n<<" "<<o.first<<" "<<o.second<<" "<<o.both<<"\n";};
    save(output,base);if(control)save(*unblocked,base+"_unfiltered_gate");
}
