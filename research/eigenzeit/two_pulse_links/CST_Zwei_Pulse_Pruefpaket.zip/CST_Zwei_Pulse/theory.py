"""Certified bounds for the first registered direct link. No sampled data used."""
import argparse
import json
import math
from pathlib import Path
from flint import arb, ctx

ctx.prec = 128
A = arb
ROOT = Path(__file__).resolve().parent
SPEC = json.loads((ROOT/'protocol.json').read_text())
def export(lo, hi):
    return [math.nextafter(float(lo.lower()), -math.inf),
            math.nextafter(float(hi.upper()), math.inf)]

def one(R, rho, delta, n, k, unrestricted=False):
    # All input lengths are binary rationals. Breakpoints a, delta, a+delta
    # coincide with time cell edges in the supplied study design.
    W, a = A(SPEC['W']), A(SPEC['a'])
    assert all((float(v)/float(W)*n).is_integer() for v in (a,delta,a+delta) if 0<v<W)
    omega = 2*A.pi()*(1-A(SPEC['cos_half_angle']))
    factor = rho*A.pi()/24
    def F(u):
        b = min(a,u)
        return u*(R**2*b+R*b*b+b**3/3)-(R**2*b*b/2+2*R*b**3/3+b**4/4)
    def count(u):
        return rho*omega*(F(u)-(0 if unrestricted else F(max(A(0),u-delta))))
    def radial(u):
        return (A(0) if unrestricted else max(A(0),u-delta), min(a,u))
    moments = [[A(0) for j in range(3)] for _ in range(2)]
    xs = [A(j)/k for j in range(k+1)]
    for i in range(n):
        lo,hi = W*i/n,W*(i+1)/n
        l0,h0=radial(lo); l1,h1=radial(hi)
        w0,w1=h0-l0,h1-l1
        if max(w0,w1)<=0: continue
        assert min(w0,w1)>=0
        small,large=A(0),A(0)
        def gap(u,s):
            return (u-s)*(2*R+u+s)
        if unrestricted:
            # Control: every causally reachable receiver point is a hit.
            small = (h0*(R**2+R*h0+h0*h0/3))
            large = (h1*(R**2+R*h1+h1*h1/3))
        else:
            for j in range(k):
                x0,x1=xs[j],xs[j+1]
                rlo=l0+x0*w0; rhi=l1+x1*w1
                gmin=gap(lo,l0+x1*w0); gmax=gap(hi,l1+x0*w1)
                small += (R+rlo)**2*(-factor*gmax*gmax).exp()
                large += (R+rhi)**2*(-factor*gmin*gmin).exp()
            small *= min(w0,w1)/k
            large *= max(w0,w1)/k
        # The earliest-hit subdensity is between these two constants throughout this cell.
        low_dens = rho*omega*small*(-count(hi)).exp()
        high_dens = rho*omega*large*((-count(lo)).exp() if unrestricted else 1)
        for j in range(3):
            du = (hi**(j+1)-lo**(j+1))/(j+1)
            moments[0][j]+=du*low_dens
            moments[1][j]+=du*high_dens
    (p0,m0,s0),(p1,m1,s1)=moments
    # Minimise the unnormalised squared deviations separately for each envelope.
    return ((p0,p1), (m0/p1,m1/p0), ((s0-m0*m0/p0)/p1,(s1-m1*m1/p1)/p0))

def calculate(r,n,k,control=False):
    R,rho,d,W=map(A,[r['R'],r['rho'],r['delta'],SPEC['W']])
    a=one(R,rho,d,n,k,control)
    b=a if d>=W else one(R,rho,W,n,k,control)
    # Control evaluated only for the two disjoint gates of case A.
    assert not control or d>=W
    p=export(a[0][0]*b[0][0],a[0][1]*b[0][1])
    mean=[0.0,0.0] if d>=W else export(b[1][0]-a[1][1],b[1][1]-a[1][0])
    sd=export((a[2][0]+b[2][0]).sqrt(),(a[2][1]+b[2][1]).sqrt())
    return {'p1':export(*a[0]),'p2':export(*b[0]),'p_both':p,'bias':mean,'sd':sd}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--coarse',action='store_true')
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    n,k=(384,64) if args.coarse else (768,128)
    table={}
    for r in SPEC['runs']:
        table[r['id']]=table['A'] if r['id']=='A_direct' else calculate(r,n,k)
    table['A_unfiltered_gate']=calculate(SPEC['runs'][0],n,k,True)
    args.out.write_text(json.dumps({'mesh':[n,k],'precision_bits':ctx.prec,'rows':table},indent=2)+'\n')
