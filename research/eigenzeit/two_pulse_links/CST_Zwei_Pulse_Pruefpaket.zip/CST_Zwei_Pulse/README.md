# Zwei Emissionen im skalaren Linkmodell · Rechen- und Prüfpaket 1.0

Der Bericht im Paket erklärt Herleitung, Abstandsverteilung, Selektionswirkung und Geltungsbereich. Die Zahlen beschreiben einen endlichen Empfänger in einer vierdimensionalen Poisson-Raumzeit. Quelle und Empfänger ruhen relativ zueinander. Die Ableseregel verwendet das erste verknüpfte Empfangselement, unter der Bedingung zweier Treffer. Die Mittelwerte und Streuungen sind dimensionslos gespeichert. Zur Umrechnung in Sekunden mit L0/c multiplizieren.

## Inhalt

- `protocol.json` legt Geometrie, Seeds, Fallzahlen, Kontrolle und Vergleichsregel fest. Der lokale SHA-256 vor dem Lauf steht in `results/protocol_before.sha256`. Das ist eine lokale Protokollierung, keine externe zeitgestempelte Präregistrierung.
- `theory.py` behandelt die Poisson-Leerwahrscheinlichkeit und die Erstdichte mit 128-Bit-Ballarithmetik. Beide Emitter werden als feste Ereignisse in genau einem Poisson-Hintergrund eingefügt.
- `sprinkling.cpp` erzeugt Koordinaten in 3+1 Dimensionen und prüft die kausale Ordnung sowie die Leere jedes benötigten offenen Intervalls. Der Code ruft das analytische Programm nicht auf. Die schnelle Methode zerlegt die Punktmenge exakt in Detektortore und deren Ergänzung. Bei überlappenden Toren zieht sie den gemeinsamen Anteil einmal. Jede Hüllbox nach der ersten liefert nur Punkte ausserhalb der vorherigen Boxen. Die grössere direkte Variante erzeugt erst die gesamte benötigte Wolke.
- `simulate.py` baut den C++17-Code mit g++, führt beide Methoden aus und speichert die gemeinsam registrierten Zeiten als Float64. Zufallsgenerator: mt19937_64; Poisson-Ziehungen verwenden die jeweilige C++-Standardbibliothek. Die publizierten Seeds wurden jeweils ein einziges Mal für die Ergebnisziehung verwendet. Ein erneuter Lauf mit denselben Seeds ist eine technische Reproduktion.
- `compare.py` prüft das statistische Fehlerbudget, die Verschachtelung der Gitter und die Theorieintervalle. `curve.py` ergänzt die analytischen Stützstellen für die Abbildung.
- `results` enthält die gespeicherten Resultate. In `results/sim/*.npz` stehen unter `delays` die Paare (U1, U2) aller doppelt registrierten Versuche ohne Zeitrundung. Die vier Werte jeder `.counts`-Datei sind Gesamtzahl, Treffer von Puls 1, Treffer von Puls 2, Doppeltreffer. Nur-Puls-1, nur-Puls-2 und beide ausgefallen sind damit eindeutig rekonstruierbar. Zeitreihen der Einzeltreffer, Ereigniskoordinaten und Generatorzustände werden nicht archiviert.
- `A_unfiltered_gate` ist die Kontrolle auf denselben Wolken von A und wird nicht als unabhängiger zusätzlicher Lauf gezählt. Die angegebenen Familienintervalle beziehen sich auf A bis E und A_direct.
- `results/comparison.json` unterscheidet disjunkte, überlappende und vollständig in der Theorieeinschliessung liegende Simulationsintervalle. Die Einzelpunkte sind Stichproben-Standardabweichungen. Die Vergleichsintervalle begrenzen den Populationsparameter.
- `SHA256SUMS` enthält Dateiprüfsummen. Sie prüfen die Integrität dieses Pakets, nicht dessen externe Urheberschaft.

## Die veröffentlichten Rohwerte erneut auswerten

Linux, g++ mit C++17, Python 3.12. Die veröffentlichte Umgebung nutzte g++ 13.3.0, libstdc++ und IEEE-754 binary64.

```sh
sha256sum -c SHA256SUMS
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
cp -r results replay_existing
.venv/bin/python compare.py --dir replay_existing
```

## Gesamten Versuch erneut rechnen

```sh
mkdir -p replay/sim
.venv/bin/python theory.py --out replay/theory.json
.venv/bin/python theory.py --coarse --out replay/coarse.json
.venv/bin/python simulate.py --out replay/sim --jobs 2
.venv/bin/python compare.py --dir replay
.venv/bin/python curve.py replay/curve.json
```

Die Ballarithmetik verwendet Intervalle für alle elementaren Rechenschritte und die Exponentialfunktion. Die geometrische Simulation verwendet übliche Gleitkomma-Vergleiche. Randgleichheiten haben im idealen Poisson-Modell Wahrscheinlichkeit null. Ein Wechsel von Compiler, Bibliotheken oder PRNG-Implementierung kann die gespeicherten Zufallsfolgen ändern.

## Warum die Hüllbox reicht

Für die Richtung der Detektorachse setze U=t−x, V=t+x. Ein Ereignis zwischen der Quelle und einem Ziel y liegt zwischen deren jeweiligen U- und V-Werten. Seine transversalen Komponenten haben Betrag höchstens sqrt(ΔU ΔV). Der Jacobian für dtdx ist 1/2. Damit ist das benötigte Vierervolumen der rechteckigen Hülle 2(ΔU ΔV)². Es wird nur als Vorschlagsvolumen zum Koordinatenziehen verwendet. Der zweite Generator verwendet für jedes Tor die im Voraus bestimmten Hüllweiten W+R(1−cosθ) und 2R+W+a. Auch er entfernt Doppelungen beider Hüllen. Diese Konstruktionen benötigen weder das Diamantvolumen πτ⁴/24 noch ein separat gezogenes Bernoulli-Ereignis pro Link.

## Primärquelle und Statistik

F. Dowker, J. Henson, R. D. Sorkin, *Discreteness and the transmission of light from distant sources*, Phys. Rev. D 82, 104048 (2010). [Publikation](https://doi.org/10.1103/PhysRevD.82.104048) · [Volltext](https://arxiv.org/abs/1009.3058).
Die Direktlink-Regel und der feldsummierende Detektor stammen aus dieser Arbeit. Das Experiment mit zwei fest eingesetzten Emissionen, den Schalenkappen und dem ersten Zeitstempel ist die hier untersuchte Spezifikation.

A. Maurer und M. Pontil, *Empirical Bernstein Bounds and Sample Variance Penalization*, Satz 4 (2009). [Volltext](https://arxiv.org/abs/0907.3740).
