"""Fresh nested binomial counts to compare targeted follow-up and the all-cell controls."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from selective import ROOT,D,N1,N2,T1,T2,STOP,J,L,baseline
import pilot as previous_pilot

PLAN=D['pilot']
STAGES=PLAN['stages']
assert STAGES==[N1,baseline.N1-N1,N2-baseline.N1] and N2==baseline.N2


def draw():
    result={}
    for i,name in enumerate(PLAN['cases']):
        ps=[float(p) for p in previous_pilot.truths()[name]]
        counts=[]
        for k,n in enumerate(STAGES):
            rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([PLAN['seed'],i,k])))
            counts.append(rng.binomial(n,ps,(PLAN['repetitions'],J)).astype('<u4'))
        result[name]=np.stack(counts)
    return result


def cutoffs(counts,n,t):
    # For distant or corrupted counts avoid allocating a table over all 46 million integers.
    unique,idx=np.unique(counts,return_inverse=True)
    caps=np.fromiter(((L*int(x)-n*t).__floor__() for x in unique),dtype=np.int64,count=len(unique))
    return caps[idx.reshape(counts.shape)]


def relations(counts,n,t):
    caps=cutoffs(counts,n,t)
    opened=counts[:,:,None]>caps[:,None,:]
    d=np.arange(J);opened[:,d,d]=False
    return opened


def scalar_count(mask):
    return int(np.count_nonzero(mask))


def score(arrays):
    if set(arrays)!=set(PLAN['cases']):
        raise ValueError('wrong cases')
    result={}
    for name in PLAN['cases']:
        raw=arrays[name];reps=PLAN['repetitions']
        if raw.dtype!=np.dtype('<u4') or raw.shape!=(3,reps,J) or any(raw[i].max()>n for i,n in enumerate(STAGES)):
            raise ValueError('invalid potential counts')
        a=raw[0];old_interim=a+raw[1];end=old_interim+raw[2]
        pending=relations(a,N1,T1);later=relations(end,N2,T2)
        eh=previous_pilot.extreme(a,N1,-STOP,'ge')
        eg=~pending.any(axis=(1,2))
        cont=~(eh|eg)
        selected=(pending.any(axis=1)|pending.any(axis=2))&cont[:,None]
        n_active=selected.sum(axis=1)
        sg=eg|(cont&~(pending&later).any(axis=(1,2)))
        dense=eg|(cont&~later.any(axis=(1,2)))
        assert not (eg&eh).any() and not (dense&~sg).any()
        v7eg=previous_pilot.extreme(old_interim,baseline.N1,baseline.T1,'le')
        v7eh=previous_pilot.extreme(old_interim,baseline.N1,baseline.H1,'ge')
        v7cont=~(v7eg|v7eh)
        v7go=v7eg|(v7cont&~later.any(axis=(1,2)))
        hist=[int(x) for x in np.bincount(n_active.astype(np.int64),minlength=J+1)]
        assert sum(hist)==reps and hist[1]==0
        sum_active=int(n_active.sum())
        total=J*N1*reps+(N2-N1)*sum_active
        dense_total=J*(N1*reps+(N2-N1)*scalar_count(cont))
        old_total=J*(baseline.N1*reps+(N2-baseline.N1)*scalar_count(v7cont))
        result[name]=dict(repetitions=reps,early_go=scalar_count(eg),early_hold=scalar_count(eh),continued=scalar_count(cont),
                          selected_cells_histogram=hist,mean_followup_cells=str(F(sum_active,reps)),
                          mean_cells_given_continue=str(F(sum_active,scalar_count(cont))) if cont.any() else None,
                          selective_go=scalar_count(sg),late_go=scalar_count(sg&cont),late_hold=scalar_count(~sg&cont),
                          same_times_retest_all_go=scalar_count(dense),cleared_only_by_pair_freeze=scalar_count(sg&~dense),
                          v07_go=scalar_count(v7go),v08_only_go=scalar_count(sg&~v7go),v07_only_go=scalar_count(~sg&v7go),
                          v08_cost_above_v07=scalar_count((J*N1+(N2-N1)*n_active)>(J*baseline.N1+J*(N2-baseline.N1)*v7cont)),
                          mean_attempts=str(F(total,reps)),mean_dense_same_times=str(F(dense_total,reps)),
                          mean_v07=str(F(old_total,reps)),raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest())
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=['generate','score','replay']);p.add_argument('file',type=Path)
    args=p.parse_args()
    if args.mode=='generate':np.savez_compressed(args.file,**draw())
    else:
        with np.load(args.file,allow_pickle=False) as data:
            if args.mode=='replay':
                for name,v in draw().items():
                    if not np.array_equal(v,data[name]):raise ValueError('seed replay: '+name)
            print(json.dumps(score(data),indent=2))
