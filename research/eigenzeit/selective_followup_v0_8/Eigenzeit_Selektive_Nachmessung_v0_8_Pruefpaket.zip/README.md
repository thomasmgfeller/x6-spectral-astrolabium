# Eigenzeit v0.8 · Gezielte Nachmessung offener Zellenpaare

Nach der ersten Messstufe erhalten nur die Endpunkte noch offener **gerichteter** Vergleiche einen zweiten Messblock. Der Maximalaufwand bleibt bei 736 Millionen Versuchen. In der günstigen Klasse beträgt der erwartete Aufwand höchstens **480.785.992** Versuche. Er liegt damit mindestens **8,94 %** unter dem Erwartungswert von v0.7 für dasselbe günstige Profil. Die separat verglichenen **Obergrenzen** sinken um 16,41 %. Die Analyse betrifft das relative Referenzverfahren und denselben vollständigen 4D-Kausaldiamanten wie die Vorversionen. Für reale Daten bleibt der Feldstatus **HOLD**.

## Orientierung

- **Bericht.pdf** enthält Messplan, Aufwand, Beispiel mit drei Zellen und den gepaarten Vergleich zur Vorversion.
- **BEWEIS.md** leitet die Auswahl- und Fehlerschranken, die erwartete Anzahl nachgemessener Zellen und die Konsequenz für die Geometrieauswertung her. **design.json** enthält alle festgelegten Schwellen und Budgets. Die Konfiguration wurde mit den analytischen Schranken verglichen. Sie ist kein Optimalitätsnachweis.
- **selective.py** ist die operative Entscheidung aus einem Feldprotokoll. **selective_bounds.py** und **records/certificate.json** enthalten die gerichtete Rechnung. Im Zertifikat sind die 17 Fälle mit null bis 16 wahren hohen Zellmitteln vollständig aufgeführt.
- **experiment.py** liefert Generator, v0.8-Auswertung und die Kontrollen. **records/counts.npz** enthält 8 Arrays mit jeweils (3, 10000, 16) inkrementellen Trefferzählungen (uint32, little-endian). Pro Zelle umfassen die Stufen 27, 6 und 13 Millionen potentielle Versuche. In v0.8 werden die letzten zwei Blöcke nur für ausgewählte Zellen operativ verbraucht. v0.7 verwendet die ersten zwei Blöcke für seinen Zwischenentscheid bei 33 Millionen und erhebt bei Fortsetzung den letzten für alle Zellen.
- **records/pilot.json** gibt je Szenario frühe, späte und gepaarte Entscheidungen, Kosten der drei Kontrollen sowie die Verteilung der zusätzlich gemessenen Zellen nach Anzahl von 0 bis 16 an. **verify.py** prüft die Ergebnisse unabhängig mit ganzzahligen skalaren Vergleichen. **records/verification.json** dokumentiert alle 80.000 nachgerechneten Läufe, 4.080 Paarprüfungen, 16 fehlerhafte Eingaben oder unzulässige Auswertungen sowie ein exakt enumeriertes Dreizellen-Beispiel mit 5.832 möglichen vollständigen Zählprotokollen. **records/environment.json** gibt die Softwareversionen an.
- **previous/** enthält die bytegleich aus v0.7 übernommenen Bestandteile mit dem Verzeichnis ihrer SHA-256-Prüfsummen **previous/ORIGIN-v07.json**. **FREEZE.sha256** dokumentiert den vor den neuen Simulationsbeobachtungen lokal fixierten Entwurf. Dies ist keine öffentliche Vorregistrierung. **MANIFEST.sha256** umfasst alle übrigen Paketdateien.

## Anwendung

Im entpackten Verzeichnis. Das Kalibrierprotokoll und die neue mathematische Zertifizierung lassen sich mit Python 3 ausführen. NumPy und SciPy werden für den v0.4-Geometriezähler und die vollständige Reproduktion verwendet.

```sh
python -B selective.py examples/field_worksheet.json
python -B selective.py examples/early_go.json
python -B selective.py examples/continue_three_cells.json
python -B selective.py examples/sparse_go.json --count 1157840
python -B selective.py examples/sparse_hold.json --count 1157840
```

Bei CONTINUE werden die nachzumessenden Zellen im Feld **second_stage_cells** und die gerichteten Paare als **unresolved_pairs** ausgegeben. Für den zweiten Block wird pro genannter ID eine Zeile mit **19.000.000 neu versuchten** Referenzsignalen und ihrer Zahl detektierter Treffer benötigt. Reihenfolge der Zeilen ist beliebig. Fehlende, doppelte, zusätzliche oder ungewählte Zellen sowie ein zweiter Block nach einem terminalen ersten Ergebnis werden abgelehnt. Der erste Stand muss zeitlich gesichert sein.

Die Feldvorlage enthält alle 16 Zell-IDs und leere Nachweise. Vor einer realen Anwendung sind die physikalischen Faktoren S, D, C außerhalb der Zählung nachzuweisen. Jeder darf maximal 1,0001 betragen. Die acht evidence-Felder dokumentieren zusätzlich u. a. unabhängige Referenzversuche und die vor der Messung vereinbarte Zellwahl. Leere Referenzen ergeben HOLD_ASSUMPTIONS. Nach GO kann die eingefrorene v0.4-Regel auf einen unabhängig erhobenen wissenschaftlichen Zähler angewandt werden. Bei HOLD bleiben alle Geometrien offen, bei CONTINUE wird kein öffentliches Geometrieergebnis erzeugt. Der Betrieb erfordert stabile Zellmittel auch nach der Auswahl. Das Programm prüft Form und Zähler, die Gültigkeit der Versuchsführung muss extern belegt sein.

## Frischer Pilot

Die acht Szenarien verwenden die in v0.7 festgelegten Zellmittel, neue Seeds und neue Zählungen. Jeder Vergleich benutzt dieselben potentiellen Daten. **mean_attempts** ist der operative v0.8-Aufwand. **mean_dense_same_times** belastet jeden fortgesetzten 27/46-Millionen-Durchlauf mit allen 16 Zellen. Damit lässt sich der Anteil der Einsparung isolieren, der allein durch das Auslassen nicht benötigter Zellen entsteht. Der zusätzliche Kontrollausgang **same_times_retest_all_go** prüft am Ende erneut alle 240 Paare. **mean_v07** und **v07_go** stammen aus dem vollständigen publizierten v0.7-Plan mit dessen eigener erster Stufe und Schwellen. Die drei Pläne sind getrennte Entwürfe. Eine Auswahl nach Sichtung ihrer Ergebnisse gehört nicht zum Test.

**mean_followup_cells** mittelt einschließlich Null bei frühem Stopp. **mean_cells_given_continue** mittelt nur tatsächlich fortgesetzte Durchläufe. **v08_cost_above_v07** zählt Fälle, die v0.8 mehr kosteten als v0.7. **cleared_only_by_pair_freeze** zählt zusätzliche Freigaben gegenüber dem Kontrollausgang mit erneuter Prüfung aller 240 Paare bei gleicher Stufenplanung. Ein tatsächliches unsicheres Profil mit kleinen Teilgebieten (unsafe_rare), ein gut separiertes unsicheres Profil (unsafe_clear), ein Zwischenprofil (indifference) und eine niedrige homogene, bei konstanten sonstigen Faktoren sichere Nachweisrate (safe_low) sind neben flat_50, good_edge_8, good_edge_1 und boundary_pair enthalten. Das Objekt boundary_pair liegt an der Schwelle der **Zellmittel** und ist für sich bei konstanter Effizienz innerhalb jeder Zelle kein Nachweis einer Verletzung der physikalischen Grenze. Die vollständigen Definitionen liegen in previous/pilot.py und im bisherigen Beweis.

## Reproduktion

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B selective_bounds.py > /tmp/x6-v08-cert.json
cmp records/certificate.json /tmp/x6-v08-cert.json
python -B experiment.py score records/counts.npz > /tmp/x6-v08-score.json
cmp records/pilot.json /tmp/x6-v08-score.json
python -B experiment.py replay records/counts.npz > /tmp/x6-v08-replay.json
cmp records/pilot.json /tmp/x6-v08-replay.json
python -B verify.py > /tmp/x6-v08-checks.json
cmp records/verification.json /tmp/x6-v08-checks.json
```

Die Simulation dient der Belastungsprüfung. Gegenstand der analytischen Schranken sind alle zugelassenen Profile, nicht nur die acht gewählten Szenarien.
