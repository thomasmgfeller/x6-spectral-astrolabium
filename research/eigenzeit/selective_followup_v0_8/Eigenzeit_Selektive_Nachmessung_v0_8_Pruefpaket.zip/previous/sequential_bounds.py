"""Two-look finite-sample bounds with exact rational inputs and directed errors."""
from functools import lru_cache
from fractions import Fraction as F
import json
from two_look import ROOT,D,L,J,N1,N2,T1,H1,T2,prior
from budgets import tail_slices,rounded

R=F(prior.DESIGN['relative']['good_ratio_max'])
P=F(prior.DESIGN['relative']['p_good_min'])


@lru_cache(None)
def tail(n,u):
    if u <= 0:
        raise ValueError('positive tail gap required')
    return max(tail_slices(n,u))


def good_bound(n, margin):
    # Split the true (unknown) cell means at the middle of [m, r*m].
    d0=P*(L-1)
    spread=P*(R-1)
    worst,within,reverse=(tail(n,d0-spread-margin),tail(n,d0-spread/2-margin),tail(n,d0-margin))
    totals=[]
    for high in range(J+1):
        cross=high*(J-high)
        totals.append(cross*(worst+reverse)+(J*(J-1)-2*cross)*within)
    return min(F(1),max(totals)),dict(high_count_worst=totals.index(max(totals)),
            worst=str(worst),same_half=str(within),opposite_direction=str(reverse))


def unit_log(x):
    z=(x-1)/(x+1)
    terms=30
    value=2*sum(z**(2*i+1)/(2*i+1) for i in range(terms))
    rest=2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    return value,value+rest


def log_interval(x):
    k=0
    while x<1:
        x*=2;k-=1
    while x>=2:
        x/=2;k+=1
    lo,hi=unit_log(x)
    a,b=unit_log(F(2))
    return (lo+min(k*a,k*b),hi+max(k*a,k*b))


def kl_interval(p,q):
    pos=log_interval(p/q)
    neg=log_interval((1-p)/(1-q))
    return [p*pos[i]+(1-p)*neg[i] for i in (0,1)]


def expected_lower():
    a,b=R/(1+R),L/(1+L)
    g=1-F(prior.DESIGN['good_hold_max'])
    delta=F(prior.DESIGN['wrong_go_max'])
    decision=kl_interval(g,delta)[0]
    sample=kl_interval(a,b)[1]
    assert decision>0 and sample>0
    return {'good_a':str(a),'unsafe_limit_b':str(b),'target_go_good':str(g),'target_go_bad':str(delta),
            'necessary_expected_total_floor':(8*decision/sample).__floor__(),
            'single_trial_kl_upper':str(rounded(sample,upper=True)),
            'decision_kl_lower':str(rounded(decision,upper=False))}


def cost_upper(cont):
    return (J*(N1+(N2-N1)*cont)).__ceil__()


def certificate():
    old=json.loads((ROOT/'previous/records/certificate.json').read_text())
    geom=json.loads((ROOT/'previous/previous/certificate.json').read_text())
    first_false,end_false=tail(N1,T1),tail(N2,T2)
    missed,first=good_bound(N1,T1)
    early_hold,stop=good_bound(N1,H1)
    final_hold,end=good_bound(N2,T2)
    false=first_false+end_false
    hold=early_hold+final_hold
    assert false<=F(old['false_go_upper']) and hold<=F(old['good_hold_upper'])
    far=tail(N1,F(D['bad_pair_gap'])+H1)
    pi=F(geom['v04_grid_correct_lower'])
    return {'design':D['id'],'minimum_total':J*N1,'maximum_total':J*N2,
            'v06_fixed_total':old['total'],'false_go_upper':str(false),'good_hold_upper':str(hold),
            'good_go_lower':str(1-hold),'good_early_go_lower':str(1-missed),
            'expected_total_good_upper':cost_upper(missed),
            'separated_bad_early_hold_lower':str(1-far),'expected_total_separated_bad_upper':cost_upper(far),
            'coverage_lower':str(min(F(geom['v04_coverage_lower']),1-false)),
            'good_correct_singleton_lower':str(rounded((1-hold)*pi,upper=False)),
            'false_go_terms':list(map(str,(first_false,end_false))),
            'good_hold_terms':list(map(str,(early_hold,final_hold))),
            'final_only_46m':{'false_go_upper':str(end_false),'good_hold_upper':str(final_hold),'total':J*N2},
            'group_bounds':{'early_missed_go':first,'early_hold':stop,'final_hold':end},
            'stopped_information_bound':expected_lower()}


if __name__=='__main__':
    print(json.dumps(certificate(),indent=2))
