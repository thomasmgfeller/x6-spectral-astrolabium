"""Finite two-look protocol. Stored stages contain incremental, per-cell counts."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'previous'))
import calibrate as prior

D = json.loads((ROOT/'design.json').read_text())
J,L = prior.J,prior.L
N1,N2 = D['first_per_cell'],D['cap_per_cell']
T1,H1,T2 = (F(D[key]) for key in ('early_go_margin','early_hold_margin','final_go_margin'))
IDS = [f'C{i:02d}' for i in range(1,J+1)]


def bound_for_minimum(minimum, n, margin):
    return L*minimum - n*margin


def decide_counts(counts, look):
    if type(look) is not int or look not in (1,2):
        raise ValueError('unknown look')
    n = N1 if look == 1 else N2
    if len(counts)!=J or any(type(x) is not int or not 0<=x<=n for x in counts):
        raise ValueError('invalid cumulative cell counts')
    low,high = min(counts),max(counts)
    if high <= bound_for_minimum(low,n,T1 if look==1 else T2):
        return 'GO'
    if look==2 or high >= bound_for_minimum(low,n,H1):
        return 'HOLD_COUNTS'
    return 'CONTINUE'


def increments(stage, look, size):
    if not isinstance(stage,dict) or type(stage.get('look')) is not int or stage['look']!=look:
        raise ValueError('stage sequence must start at look 1')
    rows=stage.get('cells')
    if not isinstance(rows,list) or len(rows)!=J or any(not isinstance(row,dict) for row in rows):
        raise ValueError('expected all 16 cells at every look')
    by_id={row.get('id'):row for row in rows}
    if set(by_id)!=set(IDS):
        raise ValueError('cell IDs must be unique and match the fixed partition')
    for row in rows:
        if type(row.get('attempted')) is not int or row['attempted']!=size:
            raise ValueError('stage must contain incremental attempted counts for its fixed budget')
        if type(row.get('detected')) is not int or not 0<=row['detected']<=size:
            raise ValueError('invalid detected count')
    return [by_id[i]['detected'] for i in IDS]


def evaluate(packet, science_count=None):
    if not isinstance(packet,dict) or packet.get('design_id')!=D['id'] or packet.get('route')!=D['route']:
        raise ValueError('wrong design or route')
    mode=packet.get('mode')
    if mode not in ('field','synthetic'):
        raise ValueError('invalid data mode')
    evidence=packet.get('evidence')
    caps=packet.get('contrast_caps')
    stages=packet.get('stages')
    if not isinstance(evidence,dict) or not isinstance(caps,dict) or not isinstance(stages,list) or len(stages)>2:
        raise ValueError('expected evidence, contrast caps and at most two stages')
    missing=[k for k in D['evidence_keys'] if not isinstance(evidence.get(k),str) or not evidence[k].strip()]
    for key in ('S','D','C'):
        v=caps.get(key)
        if not isinstance(v,str) or not 1<=F(v)<=F(prior.DESIGN[key]):
            missing.append(key)
    result={'mode':mode,'status':'HOLD_ASSUMPTIONS','look':None,'evaluated_attempts':0,
            'geometry':None}
    if missing:
        return dict(result,missing_or_ineligible=missing,geometry=prior.full_family())
    result['status']='AWAIT_FIRST_LOOK'
    cumulative=[0]*J
    for look,stage in enumerate(stages,1):
        if look==2 and result['status']!='CONTINUE':
            raise ValueError('second stage after terminal interim decision')
        n=N1 if look==1 else N2
        counts=increments(stage,look,N1 if look==1 else N2-N1)
        cumulative=[a+b for a,b in zip(cumulative,counts)]
        result.update(status=decide_counts(cumulative,look),look=look,evaluated_attempts=J*n)
    if result['status']=='GO' and science_count is not None:
        sys.path.insert(0,str(prior.ROOT/'reference'))
        from robust import infer
        result['geometry']=infer(prior.DESIGN['geometry']['protocol'],science_count)
    elif result['status']=='HOLD_COUNTS':
        result['geometry']=prior.full_family()
    elif result['status'] in ('AWAIT_FIRST_LOOK','CONTINUE'):
        if science_count is not None:
            raise ValueError('calibration pending')
        result['next_attempts_per_cell']=N1 if not stages else N2-N1
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('packet',type=Path)
    parser.add_argument('--count',type=int)
    args=parser.parse_args()
    try:
        print(json.dumps(evaluate(json.loads(args.packet.read_text()),args.count),indent=2))
    except (ValueError,KeyError,ZeroDivisionError,TypeError) as exc:
        parser.exit(2,f'Invalid input: {exc}\n')
