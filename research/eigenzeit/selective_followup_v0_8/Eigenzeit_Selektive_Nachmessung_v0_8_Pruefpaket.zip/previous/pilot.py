"""Paired potential count data for the interim rule and two fixed controls."""
import argparse, hashlib, json
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from two_look import ROOT,D,L,J,N1,N2,T1,H1,T2,prior

PLAN=D['pilot']
BASE=prior.DESIGN['relative']['n']
BASE_MARGIN=F(prior.DESIGN['relative']['margin'])
STAGES=(N1,N2-N1,BASE-N2)


def truths():
    p=F(49,100)
    r=F(prior.DESIGN['relative']['good_ratio_max'])
    rare=L*F(100001,100000)
    return {'flat_50':[F(1,2)]*J,
            'good_edge_8':[p*r]*8+[p]*8,
            'good_edge_1':[p*r]+[p]*15,
            'boundary_pair':[L/(1+L),1/(1+L)]+[F(1,2)]*14,
            'unsafe_rare':[rare/(1+rare),1/(1+rare)]+[F(1,2)]*14,
            'unsafe_clear':[F(10025,20025),F(10000,20025)]+[F(1,2)]*14,
            'indifference':[F(10011,20011),F(10000,20011)]+[F(1,2)]*14,
            'safe_low':[F(1,10)]*J}


def draw():
    out={}
    for i,name in enumerate(PLAN['cases']):
        ps=[float(p) for p in truths()[name]]
        rows=[]
        for j,n in enumerate(STAGES):
            rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([PLAN['seed'],i,j])))
            rows.append(rng.binomial(n,ps,(PLAN['repetitions'],J)).astype('<u4'))
        out[name]=np.stack(rows)
    return out


def extreme(arr,n,margin,direction):
    low,high=arr.min(axis=1),arr.max(axis=1)
    unique,idx=np.unique(low,return_inverse=True)
    thresholds=[L*int(v)-n*margin for v in unique]
    if direction=='le':
        return high<=np.asarray([t.__floor__() for t in thresholds])[idx]
    if direction=='ge':
        return high>=np.asarray([t.__ceil__() for t in thresholds])[idx]
    raise ValueError('unknown tail')


def score(arrays):
    if set(arrays)!=set(PLAN['cases']):
        raise ValueError('incomplete scenario set')
    out={}
    for name in PLAN['cases']:
        a=arrays[name]
        if (a.shape!=(3,PLAN['repetitions'],J) or a.dtype!=np.dtype('<u4')
                or any(a[j].max()>n for j,n in enumerate(STAGES))):
            raise ValueError('invalid stage observations')
        eg=extreme(a[0],N1,T1,'le')
        eh=extreme(a[0],N1,H1,'ge')
        assert not (eg&eh).any()
        cont=~(eg|eh)
        end=extreme(a[0]+a[1],N2,T2,'le')
        old=extreme(a.sum(axis=0),BASE,BASE_MARGIN,'le')
        go=eg|(cont&end)
        reps=len(go)
        used=J*(N1*reps+(N2-N1)*int(cont.sum()))
        out[name]=dict(repetitions=reps, early_go=int(eg.sum()), early_hold=int(eh.sum()),
                       continued=int(cont.sum()), late_go=int((cont&end).sum()),late_hold=int((cont&~end).sum()),
                       go=int(go.sum()),final_only_46m_go=int(end.sum()),v06_47m_go=int(old.sum()),
                       go_only_due_to_early=int((eg&~end).sum()),hold_only_due_to_early=int((eh&end).sum()),
                       total_attempts_used=used,mean_attempts=str(F(used,reps)),
                       raw_sha256=hashlib.sha256(a.tobytes()).hexdigest())
    return out


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['generate','score','replay'])
    parser.add_argument('file',type=Path)
    args=parser.parse_args()
    if args.mode=='generate':
        np.savez_compressed(args.file,**draw())
    else:
        with np.load(args.file,allow_pickle=False) as data:
            if args.mode=='replay':
                for name,expected in draw().items():
                    if not np.array_equal(expected,data[name]):
                        raise ValueError('replay differs: '+name)
            print(json.dumps(score(data),indent=2))
