"""Prespecified calibration rule and optional v0.4 order-count inference."""
import argparse
import json
import sys
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESIGN = json.loads((ROOT / "design.json").read_text())
J = DESIGN["cells"]
K, S, D, C = (F(DESIGN[k]) for k in ("K", "S", "D", "C"))
L = K / (S * D * C**2)
MARGIN = F(DESIGN["relative"]["margin"])
GRID = ["0", "1/4", "1/2"]


def count_threshold(min_detected):
    """Largest detected count allowed by the relative rule at this minimum."""
    return (L * min_detected - DESIGN["relative"]["n"] * MARGIN).__floor__()


def counts_pass(route, detected):
    if route not in ("absolute", "relative"):
        raise ValueError("unknown route")
    n = DESIGN[route]["n"]
    if len(detected) != J or any(type(k) is not int or not 0 <= k <= n for k in detected):
        raise ValueError("expected one integer count in [0,n] per cell")
    if route == "absolute":
        return min(detected) >= n - DESIGN[route]["max_losses"]
    return max(detected) <= count_threshold(min(detected))


def full_family():
    return {"grid": GRID.copy(), "h_interval": ["0", "1/2"],
            "q_interval": ["0", "626262763/200000000"],
            "q_exact_upper": "48*atanh(1/4)^2"}


def check(packet):
    """Input evidence consists of externally audited declarations, not truth verification."""
    route = packet.get("route")
    if packet.get("design_id") != DESIGN["id"] or route not in ("absolute", "relative"):
        raise ValueError("unknown design or route")
    mode = packet.get("mode")
    if mode not in ("field", "synthetic"):
        raise ValueError("mode must be field or synthetic")
    evidence = packet.get("evidence")
    if not isinstance(evidence, dict):
        raise ValueError("evidence must be an object")
    missing = [key for key in DESIGN["evidence_keys"]
               if not isinstance(evidence.get(key), str) or not evidence[key].strip()]
    limits = packet.get("contrast_caps")
    if not isinstance(limits, dict):
        raise ValueError("contrast_caps must be an object")
    for name in ("S", "D", "C"):
        value = limits.get(name)
        if value is None:
            missing.append(name)
        elif not isinstance(value, str) or not 1 <= F(value) <= F(DESIGN[name]):
            missing.append(name)
    if missing:
        return {"mode": mode, "status": "HOLD_ASSUMPTIONS", "missing_or_ineligible": missing,
                "geometry": full_family()}
    rows = packet.get("cells")
    if not isinstance(rows, list) or any(not isinstance(x, dict) for x in rows):
        raise ValueError("cells must be a list of records")
    n = DESIGN[route]["n"]
    expected = {f"C{i:02d}" for i in range(1, J + 1)}
    if len(rows) != J or {x.get("id") for x in rows} != expected:
        raise ValueError("expected every prespecified cell exactly once")
    if any(type(x.get("attempted")) is not int or x["attempted"] != n for x in rows):
        raise ValueError("incorrect number of attempted probes")
    if not counts_pass(route, [x.get("detected") for x in rows]):
        return {"mode": mode, "status": "HOLD_COUNTS", "geometry": full_family()}
    return {"mode": mode, "status": "GO", "geometry": None}


def apply(packet, count=None):
    result = check(packet)
    if result["status"] == "GO" and count is not None:
        sys.path.insert(0, str(ROOT / "reference"))
        from robust import infer
        result["geometry"] = infer(DESIGN["geometry"]["protocol"], count)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("packet", type=Path)
    parser.add_argument("--count", type=int, help="v0.4 comparable-pair count from its fixed disjoint groups")
    args = parser.parse_args()
    try:
        print(json.dumps(apply(json.loads(args.packet.read_text()), args.count), indent=2))
    except (ValueError, KeyError, TypeError, ZeroDivisionError) as exc:
        parser.exit(2, f"Invalid input: {exc}\n")
