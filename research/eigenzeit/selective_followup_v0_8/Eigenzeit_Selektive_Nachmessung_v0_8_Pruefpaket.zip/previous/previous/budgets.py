"""Finite-sample upper and lower certificates with outward rational arithmetic."""
from fractions import Fraction as F
from math import isqrt
import json
from calibrate import DESIGN, ROOT, L, MARGIN, J

UNIT = 10**12
SCALE = 1 << 192


def rounded(x, *, upper):
    v = x*UNIT
    return F(v.__ceil__() if upper else v.__floor__(), UNIT)


def sqrt_lower(x):
    return F(isqrt(x.numerator * UNIT**2 // x.denominator), UNIT)


def exp_minus_upper(x):
    # The positive Taylor partial sum lower-bounds exp(x), also for large x.
    term = total = F(1)
    for k in range(1, 65):
        term *= x/k
        total += term
    return 1/total


def tail_slices(n, u):
    vmax = (1+L**2)/4
    slices = DESIGN['variance_slices']
    bounds = []
    for j in range(slices):
        vl, vh = j*vmax/slices, (j+1)*vmax/slices
        den = vh+L*u/3
        lam = u/den
        prefactor = F(1)
        if vl:
            assert lam*L < 1
            sigma = sqrt_lower(n*vl*(1-lam*L))
            prefactor = min(F(1), (F(2,5)/lam + F(28,25)*L)/sigma)
        bound = rounded(prefactor * exp_minus_upper(n*u**2/(2*den)), upper=True)
        bounds.append(bound)
    return bounds


def binomial_cdf(m, p, cutoff, radius):
    """Mode-normalized weights, both tails bounded by monotonicity, no special functions."""
    mode = ((m+1)*p).__floor__()
    a = p.numerator
    b = p.denominator-a
    left, right = max(0,mode-radius), min(m,mode+radius)
    if not left <= cutoff <= right:
        raise ValueError('cutoff outside certification window')
    total = [SCALE, SCALE]
    part = [SCALE if mode <= cutoff else 0]*2
    extra = []
    for step, stop in ((-1,left),(1,right)):
        lo = hi = SCALE
        k = mode
        while k != stop:
            top,bottom = ((k*b,(m-k+1)*a) if step==-1 else ((m-k)*a,(k+1)*b))
            lo, hi = lo*top//bottom, -(-hi*top//bottom)
            k += step
            total[0] += lo
            total[1] += hi
            if k <= cutoff:
                part[0] += lo
                part[1] += hi
        extra.append((left if step==-1 else m-right)*hi)
    return (F(part[0],total[1]+sum(extra)), min(F(1),F(part[1]+extra[0],total[0])))


def lower_certificate():
    item = DESIGN['lower_witness']
    m,k,r = (item[s] for s in ('pair_total','cutoff','mode_radius'))
    good = F(DESIGN['relative']['good_ratio_max'])
    a,b = good/(1+good),L/(1+L)
    result = {}
    for label,p in (('favorable',a),('unsafe_limit',b)):
        low,high = binomial_cdf(m,p,k,r)
        result[label] = [str(rounded(low,upper=False)),str(rounded(high,upper=True))]
    assert F(result['favorable'][1]) < 1-F(DESIGN['good_hold_max'])
    assert F(result['unsafe_limit'][0]) > F(DESIGN['wrong_go_max'])
    return dict(**item, cdf=result, pair_min=m+1, equal_cell_min=m//2+1,
                total_fixed_min=J*(m+1)//2, total_equal_min=J*(m//2+1))


def certificate():
    rel = DESIGN['relative']
    n = rel['n']
    d = F(rel['p_good_min'])*(L-F(rel['good_ratio_max']))
    assert 0 < MARGIN < d
    false = tail_slices(n,MARGIN)
    holds = tail_slices(n,d-MARGIN)
    fp = max(false)
    hold = J*(J-1)*max(holds)
    assert fp <= F(DESIGN['wrong_go_max']) and hold <= F(DESIGN['good_hold_max'])
    prior = json.loads((ROOT/'previous/certificate.json').read_text())
    coverage = min(F(prior['v04_coverage_lower']),1-fp)
    correct = rounded((1-hold)*F(prior['v04_grid_correct_lower']),upper=False)
    lower = lower_certificate()
    return dict(id=DESIGN['id'],n_per_cell=n,total=J*n,margin=str(MARGIN),min_good_gap=str(d),
                false_go_upper=str(fp),good_hold_upper=str(hold),good_go_lower=str(1-hold),
                coverage_lower=str(coverage),good_correct_singleton_lower=str(correct),
                worst_slices_zero_based=[false.index(fp),holds.index(max(holds))],
                slice_false_go_upper=list(map(str,false)),slice_good_pair_hold_upper=list(map(str,holds)),
                necessary=lower, old_total=prior['routes']['relative']['attempts'])


if __name__ == '__main__':
    print(json.dumps(certificate(),indent=2))
