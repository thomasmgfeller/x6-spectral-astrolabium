"""Independent scalar, combinatorial, protocol and exact finite checks."""
from copy import deepcopy
from fractions import Fraction as F
from itertools import product,permutations
from math import lcm,exp,sqrt,pi
import hashlib,json
import numpy as np
from selective import ROOT,D,IDS,J,L,N1,N2,T1,T2,STOP,baseline,evaluate,first_decision,final_decision
from selective_bounds import certificate
from experiment import PLAN


def linear(n,t):
    scale=lcm(L.denominator,t.denominator)
    return scale,int(scale*L),int(scale*n*t)


def cap(low,coef):
    den,a,b=coef
    return (a*low-b)//den


def crossed_hold(xs,coef):
    den,a,b=coef
    return den*max(xs)>=a*min(xs)-b


def toy():
    # Every first and every possible second count vector, including all missing-cell completions.
    j=3;n=5;end=7;ell=F(3,2);t=F(1,10);stop=F(1,8);final=F(1,5)
    tested=open_cell_cases=extra_clear=0
    cache={}
    for xs in product(range(n+1),repeat=j):
        first_open=[(i,k) for i,k in permutations(range(j),2) if F(xs[i],n)-ell*F(xs[k],n)>-t]
        active=sorted({u for e in first_open for u in e})
        early_hold=F(max(xs),n)-ell*F(min(xs),n)>=stop
        for dy in product(range(end-n+1),repeat=j):
            s=[a+b for a,b in zip(xs,dy)]
            late={(i,k) for i,k in permutations(range(j),2) if F(s[i],end)-ell*F(s[k],end)>-final}
            continued=bool(first_open) and not early_hold
            go=not early_hold and not (late&set(first_open))
            dense=not early_hold and (not first_open or not late)
            assert not dense or go
            assert all(not go or e not in first_open or e not in late for e in permutations(range(j),2))
            key=xs,tuple(dy[i] for i in active) if continued else ()
            assert cache.setdefault(key,go)==go
            open_cell_cases+=int(continued and len(active)==2)
            extra_clear+=int(go and not dense);tested+=1
    assert extra_clear and open_cell_cases
    return dict(potential_transcripts=tested,distinct_operational_transcripts=len(cache),
                two_cell_continuations=open_cell_cases,extra_sparse_go=extra_clear)


def floating_tail(n,u):
    y=float(L);v=(1+y*y)/4;vals=[]
    for i in range(100):
        lo,hi=v*i/100,v*(i+1)/100;den=hi+y*u/3;lam=u/den
        f=exp(-n*u*u/(2*den))
        if lo:f*=min(1,(1/lam/sqrt(2*pi)+1.12*y)/sqrt(n*lo*exp(-lam*y)))
        vals.append(f)
    return max(vals)


def audit_pilot(arrays,record):
    cg,ce,ch=linear(N1,T1),linear(N2,T2),linear(N1,-STOP)
    og,oh,oe=linear(baseline.N1,baseline.T1),linear(baseline.N1,baseline.H1),linear(baseline.N2,baseline.T2)
    total_reps=0
    for name in PLAN['cases']:
        raw=arrays[name];r=record[name];h=[0]*(J+1)
        counters={k:0 for k in ('early_go','early_hold','continued','late_go','late_hold','selective_go',
                                'same_times_retest_all_go','cleared_only_by_pair_freeze','v07_go','v08_only_go',
                                'v07_only_go','v08_cost_above_v07')}
        cost=dense_cost=old_cost=0
        for first,mid,last in zip(*raw):
            xs=list(map(int,first));old=[v+int(m) for v,m in zip(xs,mid)];end=[v+int(e) for v,e in zip(old,last)]
            eh=crossed_hold(xs,ch);eg=max(xs)<=cap(min(xs),cg);cont=not(eh or eg)
            active=set();fail=False
            if cont:
                for k,v in enumerate(xs):
                    first_cap=cap(v,cg);end_cap=cap(end[k],ce)
                    for i,u in enumerate(xs):
                        if i!=k and u>first_cap:
                            active.update((i,k))
                            if end[i]>end_cap:fail=True
            sg=eg or (cont and not fail);dg=eg or (cont and max(end)<=cap(min(end),ce))
            old_g=max(old)<=cap(min(old),og);old_h=crossed_hold(old,oh);old_c=not(old_g or old_h)
            vg=old_g or (old_c and max(end)<=cap(min(end),oe))
            used=J*N1+(N2-N1)*len(active);old_used=J*(baseline.N1+(N2-baseline.N1)*old_c)
            cost+=used;old_cost+=old_used;dense_cost+=J*(N1+(N2-N1)*cont);h[len(active)]+=1
            vals=(eg,eh,cont,cont and sg,cont and not sg,sg,dg,sg and not dg,vg,sg and not vg,vg and not sg,used>old_used)
            for k,val in zip(counters,vals):counters[k]+=val
        assert h==r['selected_cells_histogram'] and all(r[k]==val for k,val in counters.items())
        assert [F(v,len(raw[0])) for v in (cost,dense_cost,old_cost)]==[F(r[k]) for k in ('mean_attempts','mean_dense_same_times','mean_v07')]
        assert hashlib.sha256(raw.tobytes()).hexdigest()==r['raw_sha256']
        total_reps+=len(raw[0])
    return total_reps


def main():
    origin=json.loads((ROOT/'previous/ORIGIN-v07.json').read_text())
    for name,h in origin['files'].items():assert hashlib.sha256((ROOT/'previous'/name).read_bytes()).hexdigest()==h
    cert=certificate();assert cert==json.loads((ROOT/'records/certificate.json').read_text())
    P=F(49,100);r=F('1.0002')
    df=lambda k:float(P*(L-1)-(P*(r-1)*k)-T1)
    tails=[floating_tail(N1,df(k)) for k in (1,F(1,2),0)]
    keys=['worst','same_half','opposite_direction']
    assert all(y<=float(F(cert['active_pair_terms'][k]))+1e-14 for y,k in zip(tails,keys))
    case_count=0
    for k in range(J+1):
        m=P;half=m*(1+r)/2
        p=[half+(m*r-half)*F(i+1,k) for i in range(k)]+[m+(half-m)*F(i,max(1,J-k-1)) for i in range(J-k)]
        per_cell=[0.]*J
        for i,j in permutations(range(J),2):
            kind=1 if (i<k)==(j<k) else (0 if i<k else 2)
            gap=float(L*p[j]-p[i]-T1);assert gap+1e-14>=df([1,F(1,2),0][kind])
            per_cell[i]+=tails[kind];per_cell[j]+=tails[kind];case_count+=1
        assert sum(min(1,b) for b in per_cell)<=float(F(cert['expected_followup_cells_by_high_count'][k]))+1e-12
    read=lambda name:json.loads((ROOT/'examples'/(name+'.json')).read_text())
    start=read('continue_three_cells');g=read('sparse_go');h=read('sparse_hold')
    assert evaluate(start)['unresolved_pairs']==[['C02','C01'],['C03','C01']]
    assert evaluate(start)['second_stage_cells']==IDS[:3]
    rg,rh=evaluate(g,1157840),evaluate(h)
    assert rg['status']=='GO' and rh['status']=='HOLD_COUNTS'
    assert rg['geometry']==json.loads((ROOT/'previous/records/verification.json').read_text())['late_go_geometry']
    assert rg['evaluated_attempts']==rh['evaluated_attempts']==489000000
    assert g['stages'][0]==h['stages'][0] and g['stages'][1]['cells'][:2]==h['stages'][1]['cells'][:2]
    e=read('early_go');assert evaluate(e)['status']=='GO'
    early_h=deepcopy(e);early_h['stages'][0]['cells'][0]['detected']+=40000
    assert evaluate(early_h)['status']=='HOLD_COUNTS'
    assert evaluate(read('field_worksheet'))['status']=='HOLD_ASSUMPTIONS'
    blank=deepcopy(start);blank['stages']=[];assert evaluate(blank)['status']=='AWAIT_FIRST_LOOK'
    neg=[]
    for terminal in (e,early_h):
        q=deepcopy(terminal);q['stages'].append(g['stages'][1]);neg.append(q)
    for kind in ['omit','unselected','add_unselected','duplicate','cumulative','old_id','float','bool','negative','over','third','no_first','bad_look']:
        q=deepcopy(g);stage=q['stages'][1];rows=stage['cells']
        if kind=='omit':rows.pop()
        if kind=='unselected':rows[2]['id']='C04'
        if kind=='add_unselected':rows.append(dict(rows[0],id='C04'))
        if kind=='duplicate':rows[1]['id']=rows[2]['id']
        if kind=='cumulative':rows[0]['attempted']=N2
        if kind=='old_id':q['design_id']=baseline.D['id']
        if kind=='float':rows[0]['detected']=9.
        if kind=='bool':rows[0]['detected']=True
        if kind=='negative':rows[0]['detected']=-1
        if kind=='over':rows[0]['detected']=N2-N1+1
        if kind=='third':q['stages'].append(stage)
        if kind=='no_first':q['stages']=[stage]
        if kind=='bad_look':stage['look']=1
        neg.append(q)
    for q in neg:
        try:evaluate(q)
        except ValueError:pass
        else:raise AssertionError('invalid stages accepted')
    try:evaluate(start,1157840)
    except ValueError:pass
    else:raise AssertionError('science output before GO')
    shuffled=deepcopy(g)
    for st in shuffled['stages']:st['cells'].reverse()
    assert evaluate(shuffled,1157840)==rg
    allactive=[N1//2-8000]*8+[N1//2+8500]*8
    assert first_decision(allactive)[0]=='CONTINUE' and len(first_decision(allactive)[2])==16
    for n,t in ((N1,T1),(N2,T2)):
        low=n//2;threshold=cap(low,linear(n,t))
        if n==N1:
            assert first_decision([low]*15+[threshold])[0]=='GO' and first_decision([low]*15+[threshold+1])[0]=='CONTINUE'
        else:
            vals=[N1//2]*16;inc={0:low-vals[0],1:threshold-vals[1]}
            assert final_decision(vals,inc,[(1,0)])=='GO'
            inc[1]+=1;assert final_decision(vals,inc,[(1,0)])=='HOLD_COUNTS'
    low=N1//2;lim=(L*low+N1*STOP).__ceil__()
    assert first_decision([low]*15+[lim])[0]=='HOLD_COUNTS' and first_decision([low]*15+[lim-1])[0]=='CONTINUE'
    with np.load(ROOT/'records/counts.npz',allow_pickle=False) as arrays:
        n=audit_pilot(arrays,json.loads((ROOT/'records/pilot.json').read_text()))
    return dict(status='PASS',previous_files_verified=len(origin['files']),independent_profile_pair_checks=case_count,
                paired_runs_recomputed=n, negative_protocol_cases=len(neg)+1,exact_toy=toy(),
                extremes_only_counterexample={'pairs':evaluate(start)['unresolved_pairs'],'selected':IDS[:3],
                    'same_extreme_data':True,'completion_A':rg['status'],'completion_B':rh['status'],
                    'total_attempts':rg['evaluated_attempts']}, synthetic_geometry=rg['geometry'])


if __name__=='__main__':
    print(json.dumps(main(),indent=2))
