"""Prespecified directed comparisons with a second block for unresolved endpoints."""
import argparse
from fractions import Fraction as F
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'previous'))
import two_look as baseline

D=json.loads((ROOT/'design.json').read_text())
IDS,J,L=baseline.IDS,baseline.J,baseline.L
N1,N2=D['first_per_cell'],D['final_per_selected_cell']
T1,STOP,T2=(F(D[k]) for k in ('early_clear_margin','early_hold_threshold','final_clear_margin'))
EVIDENCE=baseline.D['evidence_keys']+[D['additional_evidence']]


def open_pairs(counts):
    edges=[]
    for j,low in enumerate(counts):
        cap=baseline.bound_for_minimum(low,N1,T1).__floor__()
        edges.extend((i,j) for i,high in enumerate(counts) if i!=j and high>cap)
    return edges


def first_decision(counts):
    if len(counts)!=J or any(type(x) is not int or not 0<=x<=N1 for x in counts):
        raise ValueError('invalid first-stage counts')
    if max(counts)>=L*min(counts)+N1*STOP:
        return 'HOLD_COUNTS',[],[]
    edges=open_pairs(counts)
    if not edges:
        return 'GO',[],[]
    active=sorted({vertex for edge in edges for vertex in edge})
    return 'CONTINUE',edges,active


def final_decision(first, increments, edges):
    cumulative={i:first[i]+inc for i,inc in increments.items()}
    return 'GO' if all(cumulative[i]<=L*cumulative[j]-N2*T2 for i,j in edges) else 'HOLD_COUNTS'


def read_stage(stage,look,selected,n):
    if not isinstance(stage,dict) or type(stage.get('look')) is not int or stage['look']!=look:
        raise ValueError('invalid look or stage order')
    rows=stage.get('cells')
    if not isinstance(rows,list) or len(rows)!=len(selected) or any(not isinstance(r,dict) for r in rows):
        raise ValueError('stage must contain exactly the required cells')
    wanted={IDS[i] for i in selected}
    if {r.get('id') for r in rows}!=wanted:
        raise ValueError('wrong, missing or repeated cell ID')
    out={}
    for r in rows:
        if type(r.get('attempted')) is not int or r['attempted']!=n:
            raise ValueError('incorrect incremental stage budget')
        x=r.get('detected')
        if type(x) is not int or not 0<=x<=n:
            raise ValueError('invalid incremental detection count')
        out[IDS.index(r['id'])]=x
    return out


def evaluate(packet,science_count=None):
    if not isinstance(packet,dict) or packet.get('design_id')!=D['id'] or packet.get('route')!=D['route']:
        raise ValueError('unknown design or route')
    mode=packet.get('mode');stages=packet.get('stages')
    evidence=packet.get('evidence'); caps=packet.get('contrast_caps')
    if mode not in ('field','synthetic') or not isinstance(stages,list) or len(stages)>2:
        raise ValueError('invalid mode or stage count')
    if not isinstance(evidence,dict) or not isinstance(caps,dict):
        raise ValueError('missing evidence or contrast cap fields')
    missing=[k for k in EVIDENCE if not isinstance(evidence.get(k),str) or not evidence[k].strip()]
    for k in ('S','D','C'):
        if not isinstance(caps.get(k),str) or not 1<=F(caps[k])<=F(baseline.prior.DESIGN[k]):
            missing.append(k)
    result=dict(mode=mode,status='AWAIT_FIRST_LOOK',look=None,evaluated_attempts=0,geometry=None)
    if missing:
        return dict(result,status='HOLD_ASSUMPTIONS',missing_or_ineligible=missing,geometry=baseline.prior.full_family())
    if stages:
        rows=read_stage(stages[0],1,range(J),N1)
        first=[rows[i] for i in range(J)]
        status,edges,active=first_decision(first)
        result.update(status=status,look=1,evaluated_attempts=J*N1,
                      second_stage_cells=[IDS[i] for i in active],
                      unresolved_pairs=[[IDS[i],IDS[j]] for i,j in edges])
        if len(stages)==2:
            if status!='CONTINUE':
                raise ValueError('terminal first decision')
            inc=read_stage(stages[1],2,active,N2-N1)
            result.update(status=final_decision(first,inc,edges),look=2,
                          evaluated_attempts=J*N1+len(active)*(N2-N1))
    if result['status'] in ('AWAIT_FIRST_LOOK','CONTINUE'):
        if science_count is not None:raise ValueError('calibration pending')
        result['next_attempts_per_required_cell']=N1 if not stages else N2-N1
    elif result['status']=='HOLD_COUNTS':
        result['geometry']=baseline.prior.full_family()
    elif science_count is not None:
        sys.path.insert(0,str(baseline.prior.ROOT/'reference'))
        from robust import infer
        result['geometry']=infer(baseline.prior.DESIGN['geometry']['protocol'],science_count)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('packet',type=Path);parser.add_argument('--count',type=int)
    args=parser.parse_args()
    try:
        print(json.dumps(evaluate(json.loads(args.packet.read_text()),args.count),indent=2))
    except (TypeError,ValueError,KeyError,ZeroDivisionError) as exc:
        parser.exit(2,f'Invalid input: {exc}\n')
