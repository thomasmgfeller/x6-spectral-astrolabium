"""Directed finite-sample risk and endpoint-count bounds."""
from fractions import Fraction as F
import json
from selective import ROOT,D,L,J,N1,N2,T1,STOP,T2,baseline
from sequential_bounds import tail,good_bound,rounded


def endpoint_bound(n,margin):
    _,terms=good_bound(n,margin)
    worst,within,reverse=(F(terms[k]) for k in ('worst','same_half','opposite_direction'))
    bounds=[]
    for k in range(J+1):
        low=J-k
        high_prob=min(F(1),2*(k-1)*within+low*(worst+reverse)) if k else F(0)
        low_prob=min(F(1),2*(low-1)*within+k*(worst+reverse)) if low else F(0)
        bounds.append(k*high_prob+low*low_prob)
    return max(bounds),list(map(str,bounds)),terms


def certificate():
    old=json.loads((ROOT/'previous/records/certificate.json').read_text())
    geom=json.loads((ROOT/'previous/previous/previous/certificate.json').read_text())
    f1,f2=tail(N1,T1),tail(N2,T2)
    h1,_=good_bound(N1,-STOP);h2,_=good_bound(N2,T2)
    fp=f1+f2;hold=h1+h2
    assert fp<=F(old['false_go_upper']) and hold<=F(old['good_hold_upper'])
    act,per_k,terms=endpoint_bound(N1,T1)
    expected=J*N1+(N2-N1)*act
    prev_min=old['minimum_total'];prev_upper=old['expected_total_good_upper']
    far=tail(N1,F(baseline.D['bad_pair_gap'])-STOP)
    return dict(design=D['id'],first_total=J*N1, maximum_total=J*N2,expected_followup_cells_good_upper=str(act),
                expected_total_good_upper=expected.__ceil__(),expected_followup_cells_by_high_count=per_k,
                active_pair_terms=terms, false_go_terms=list(map(str,(f1,f2))),good_hold_terms=list(map(str,(h1,h2))),
                false_go_upper=str(fp),good_hold_upper=str(hold),good_go_lower=str(1-hold),
                coverage_lower=str(min(F(geom['v04_coverage_lower']),1-fp)),
                good_correct_singleton_lower=str(rounded((1-hold)*F(geom['v04_grid_correct_lower']),upper=False)),
                good_mean_saving_vs_v07_min_lower=str(rounded(1-expected/prev_min,upper=False)),
                good_upper_bound_reduction_vs_v07=str(rounded(1-expected/prev_upper,upper=False)),
                separated_bad_early_hold_lower=str(1-far),
                separated_bad_expected_upper=(J*N1+J*(N2-N1)*far).__ceil__(),
                v07_favorable_lower_witness=old['stopped_information_bound']['necessary_expected_total_floor'])


if __name__=='__main__':
    print(json.dumps(certificate(),indent=2))
