"""Independent checks of the stopped protocol, numerical bounds and paired pilot counts."""
from copy import deepcopy
from decimal import Decimal as Dec, localcontext
from fractions import Fraction as F
from itertools import permutations,product
from math import comb,exp,sqrt,pi,lcm,prod
from pathlib import Path
import hashlib,json
import numpy as np
from two_look import D,ROOT,IDS,J,L,N1,N2,T1,T2,H1,prior,evaluate,decide_counts,bound_for_minimum
from sequential_bounds import certificate,P,R
from pilot import PLAN,BASE,BASE_MARGIN,score,truths


def exact_toy(ps):
    # Independent enumeration at three cells, 3 draws at look 1, 5 cumulative at look 2.
    j=3;n=3;cap=5;mult=F(3,2);early=F(3,10);stop=F(0);final=F(1,5)
    def mass(xs,k):
        return prod(comb(k,x)*p**x*(1-p)**(k-x) for x,p in zip(xs,ps))
    def w(xs,k):return F(max(xs),k)-mult*F(min(xs),k)
    total=eg=eh=cont=end=go=cost=rescue=lost=F(0)
    increments=[(ys,mass(ys,cap-n)) for ys in product(range(cap-n+1),repeat=j)]
    for xs in product(range(n+1),repeat=j):
        first=w(xs,n);a=first<=-early;b=first>=-stop;c=not(a or b);mx=mass(xs,n)
        for ys,my in increments:
            weight=mx*my
            e=w([x+y for x,y in zip(xs,ys)],cap)<=-final
            total+=weight;eg+=weight*a;eh+=weight*b;cont+=weight*c;end+=weight*e
            go+=weight*(a or c and e);cost+=weight*(j*(cap if c else n))
            rescue+=weight*(a and not e);lost+=weight*(b and e)
    assert total==eg+eh+cont==1 and min(eg,eh,cont)>0
    assert go-end==rescue-lost and go<=eg+end and 1-go<=eh+1-end
    assert cost==j*(n+(cap-n)*cont)
    return {'early_go':str(eg),'early_hold':str(eh),'continue':str(cont),'mean_trials':str(cost),
            'sequential_go':str(go),'final_only_go':str(end)}


def numtail(n,u):
    # Float evaluation using exact exp variance adjustment and normal-density constant.
    V=(1+float(L)**2)/4
    out=[]
    for i in range(100):
        lo,hi=V*i/100,V*(i+1)/100
        den=hi+float(L)*u/3;lam=u/den
        a=exp(-n*u*u/(2*den))
        if lo:
            sig=sqrt(n*lo*exp(-lam*float(L)))
            a*=min(1, (1/lam/sqrt(2*pi)+1.12*float(L))/sig)
        out.append(a)
    return max(out)


def predicate(scale,margin):
    den=lcm(L.denominator,margin.denominator)
    return den,(L*den).__floor__(),(scale*margin*den).__floor__()


def main():
    origin=json.loads((ROOT/'previous/ORIGIN-v06.json').read_text())
    for file,d in origin['files'].items():
        assert hashlib.sha256((ROOT/'previous'/file).read_bytes()).hexdigest()==d
    cert=certificate()
    assert cert==json.loads((ROOT/'records/certificate.json').read_text())
    for n,margin,entry in [(N1,T1,'early_missed_go'),(N1,H1,'early_hold'),(N2,T2,'final_hold')]:
        for offset,key in [(P*(R-1),'worst'),(P*(R-1)/2,'same_half'),(F(0),'opposite_direction')]:
            assert numtail(n,float(P*(L-1)-offset-margin))<=float(F(cert['group_bounds'][entry][key]))+1e-14
    assert sum(numtail(n,float(t)) for n,t in [(N1,T1),(N2,T2)])<=float(F(cert['false_go_upper']))
    far=numtail(N1,float(F(D['bad_pair_gap'])+H1))
    assert 1-far>=float(F(cert['separated_bad_early_hold_lower']))-1e-14
    pairs_checked=0
    for k in range(17):
        # Exact extrema and interior values; include equality at the midpoint.
        m=P;mid=m*(1+R)/2
        ps=[mid+(m*R-mid)*F(i+1,k+1) for i in range(k)]
        ps += [m+(mid-m)*F(i,max(1,15-k)) for i in range(16-k)]
        for i,j in permutations(range(J),2):
            high,low=ps[i]>mid,ps[j]>mid
            b=m*(L-1)-(m*(R-1) if high and not low else (0 if not high and low else m*(R-1)/2))
            assert L*ps[j]-ps[i]>=b
            pairs_checked+=1
    with localcontext() as ctx:
        ctx.prec=70
        dec=lambda f:Dec(f.numerator)/Dec(f.denominator)
        kl=lambda p,q:p*(p/q).ln()+(1-p)*((1-p)/(1-q)).ln()
        a=dec(R/(1+R));b=dec(L/(1+L))
        bound=8*kl(Dec('.997'),Dec('.01'))/kl(a,b)
        assert int(bound)==cert['stopped_information_bound']['necessary_expected_total_floor']
    cases=['flat_50','unsafe_rare','unsafe_clear','indifference']
    eps=F(1,1000);C=prior.C
    p=truths()['unsafe_rare'];peak=p[0]*C/(1+eps*(C-1));trough=p[1]/(C*(1-eps*(1-1/C)))
    assert 0<trough<peak<=1 and prior.S*prior.D*peak/trough>prior.K
    assert truths()['unsafe_clear'][0]-L*truths()['unsafe_clear'][1]>=F(D['bad_pair_gap'])
    read=lambda f:json.loads((ROOT/'examples'/(f+'.json')).read_text())
    eg,eh,co,late=[read(k) for k in ('early_go','early_hold','continue','late_go')]
    assert evaluate(eg)['status']=='GO' and evaluate(eh)['status']=='HOLD_COUNTS'
    assert evaluate(co)['status']=='CONTINUE' and evaluate(late)['status']=='GO' and evaluate(late)['look']==2
    field=evaluate(read('field_no_evidence'))
    assert field['geometry']==evaluate(eh)['geometry'] and field['status']=='HOLD_ASSUMPTIONS'
    awaiting=deepcopy(co);awaiting['stages']=[]
    assert evaluate(awaiting)['status']=='AWAIT_FIRST_LOOK'
    final_hold=deepcopy(late);final_hold['stages'][1]['cells'][0]['detected']=0
    assert evaluate(final_hold)['status']=='HOLD_COUNTS' and evaluate(final_hold)['geometry']==field['geometry']
    geo=evaluate(late,1157840)['geometry']
    assert geo==json.loads((ROOT/'previous/records/verification.json').read_text())['synthetic_geometry_example']['geometry']
    negatives=[]
    for base in [eg,eh]:
        q=deepcopy(base);q['stages'].append(late['stages'][1]);negatives.append(q)
    for kind in ('unplanned_third','missing_first','wrong_id','cumulative_attempts','float','duplicate','missing_cell','overcount','negative','bool'):
        q=deepcopy(late);cells=q['stages'][1]['cells']
        if kind=='unplanned_third':q['stages'].append(q['stages'][1])
        if kind=='missing_first':q['stages']=q['stages'][1:]
        if kind=='wrong_id':q['design_id']=prior.DESIGN['id']
        if kind=='cumulative_attempts':cells[0]['attempted']=N2
        if kind=='float':cells[0]['detected']=9.0
        if kind=='duplicate':cells[1]['id']=cells[0]['id']
        if kind=='missing_cell':cells.pop()
        if kind=='overcount':cells[0]['detected']=N2-N1+1
        if kind=='negative':cells[0]['detected']=-1
        if kind=='bool':cells[0]['detected']=True
        negatives.append(q)
    for q in negatives:
        try:evaluate(q)
        except ValueError:pass
        else:raise AssertionError('invalid record accepted')
    try:evaluate(co,1157840)
    except ValueError:pass
    else:raise AssertionError('geometry before terminal GO')
    for n,t,look in [(N1,T1,1),(N2,T2,2)]:
        lo=n//2;edge=bound_for_minimum(lo,n,t).__floor__()
        assert decide_counts([lo]*15+[edge],look)=='GO' and decide_counts([lo]*15+[edge+1],look)!='GO'
    hi=bound_for_minimum(N1//2,N1,H1).__ceil__()
    assert decide_counts([N1//2]*15+[hi],1)=='HOLD_COUNTS' and decide_counts([N1//2]*15+[hi-1],1)=='CONTINUE'
    reps=0
    with np.load(ROOT/'records/counts.npz',allow_pickle=False) as data:
        audit=score(data)
        assert audit==json.loads((ROOT/'records/pilot.json').read_text())
        coef=[predicate(n,t) for n,t in [(N1,T1),(N1,H1),(N2,T2),(BASE,BASE_MARGIN)]]
        for name in PLAN['cases']:
            a=data[name];rows=[a[0],a[0],a[0]+a[1],a.sum(axis=0)]
            flags=[]
            for k,(D0,A,B) in enumerate(coef):
                flags.append([int(row.max())*D0 >= A*int(row.min())-B if k==1 else
                              int(row.max())*D0 <= A*int(row.min())-B for row in rows[k]])
            counts={'early_go':0,'early_hold':0,'continued':0,'late_go':0,'late_hold':0,'go':0,
                    'v06_47m_go':0,'final_only_46m_go':0,'go_only_due_to_early':0,'hold_only_due_to_early':0}
            for g,h,e,o in zip(*flags):
                assert not(g and h);c=not(g or h)
                for key,value in zip(counts,(g,h,c,c and e,c and not e,g or c and e,o,e,g and not e,h and e)):
                    counts[key]+=value
            assert all(audit[name][k]==v for k,v in counts.items())
            assert audit[name]['total_attempts_used']==J*(N1*PLAN['repetitions']+(N2-N1)*counts['continued'])
            reps+=PLAN['repetitions']
    return dict(status='PASS',profile_pairs_checked=pairs_checked, paired_cases_repetitions=reps,
                scalar_threshold_checks=4*reps, negative_protocol_checks=len(negatives)+1,
                confirmed_expected_lower_decimal=str(bound)[:23], actual_contrast_rare_unsafe=str(prior.S*prior.D*peak/trough),
                exact_toys=[exact_toy(ps) for ps in [(F(1,2),)*3,(F(1,4),F(1,2),F(3,4))]],
                field_example=field,late_go_geometry=geo)


if __name__=='__main__':
    print(json.dumps(main(),indent=2))
