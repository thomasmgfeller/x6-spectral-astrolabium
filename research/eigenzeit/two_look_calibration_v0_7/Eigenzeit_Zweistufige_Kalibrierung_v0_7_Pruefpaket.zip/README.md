# Eigenzeit v0.7 · Wann die relative Kalibrierung früher enden kann

Die 16-Zellen-Kalibrierung erhält einen festen Zwischenentscheid. Nach 33 Millionen Referenzversuchen je Zelle kann sie mit GO oder HOLD enden. In allen übrigen Fällen folgen genau 13 Millionen zusätzliche Versuche je Zelle. Maximal fallen 736 Millionen Versuche an. Unter den günstigen Bedingungen von v0.6 werden im Mittel höchstens 575.174.011 benötigt. Beide Fehlerobergrenzen von v0.6 werden eingehalten. Die Anwendung auf eine reale Messung bleibt mangels externer Nachweise und Referenzzählungen auf **HOLD**.

## Dateien

- **Bericht.pdf** zeigt den Messplan, die Grenzen des erwarteten Aufwands und die gepaarten Pilotbeispiele.
- **BEWEIS.md** enthält Schwellen, Fehlerrechnung für zwei abhängige Messstände, die Aufteilung der Zellen im Beweis sowie eine eigenständige Informationsuntergrenze für gestoppte Verfahren.
- **two_look.py** wertet das tatsächlich verfügbare Stufenprotokoll aus. **design.json** fixiert Budgets, Schwellen, externe Nachweisfelder und Simulation.
- **sequential_bounds.py** zertifiziert beide Fehlfreigabebeiträge, die günstigen HOLD-Beiträge, die frühen Entscheidungen, die Erwartungsschranken und die Untergrenze. **records/certificate.json** speichert die exakten rationalen Ergebnisse.
- **pilot.py**, **records/counts.npz** und **records/pilot.json** enthalten Generator, rohe inkrementelle Zellzählungen und Auswertung. Der Pilot umfasst acht Szenarien mit je 12.000 Wiederholungen. Jede Matrix enthält drei Zählstufen mit Form (3, 12000, 16), Datentyp uint32 little-endian. Die Stufen entsprechen 33, 13 und 1 Million Versuchen pro Zelle. Die dritte Stufe dient ausschließlich dem Vergleich mit v0.6. Kodiert sind Binomialzählungen, keine realen Detektorsignale.
- **verify.py** und **records/verification.json** dokumentieren die Prüfung. Darin stehen zwei vollständig ausgerechnete kleine Stoppexperimente, 4.080 Paarprüfungen, 384.000 unabhängig nachgezählte Schwellenvergleiche, 13 Negativprüfungen und die unabhängige Dezimalrechnung der Untergrenze.
- **previous/** enthält die bytegleich übernommenen v0.6-Bestandteile mit **ORIGIN-v06.json** und der darunter liegenden v0.4-Geometrieregel. Der Quellarchiv-Hash und alle übernommenen Dateien sind festgehalten.
- **FREEZE.sha256** identifiziert Design, ausführbare Regeln und Simulationsgenerator vor dem neuen Pilot. Diese lokale Fixierung ist keine öffentliche Vorregistrierung. **MANIFEST.sha256** deckt alle übrigen Paketdateien ab. Softwareversionen stehen in **records/environment.json**.

## Ausführung und Feldprotokoll

Im entpackten Verzeichnis ausführen. Die Kalibrierentscheidung und das neue Zertifikat verwenden Python-Standardbibliotheken. Für den Pilot und die wissenschaftliche Geometrieauswertung werden die in records/environment.json genannten NumPy-/SciPy-Versionen verwendet.

```sh
python -B two_look.py examples/field_no_evidence.json
python -B two_look.py examples/early_go.json
python -B two_look.py examples/early_hold.json
python -B two_look.py examples/continue.json
python -B two_look.py examples/late_go.json --count 1157840
```

**Vor dem ersten Versuch** werden Raster, Zeitraum, unabhängige Stichprobennahme, externe Kontrastgrenzen und die einzige Entscheidungsregel gemeinsam fixiert. Die sieben unter evidence genannten Angaben verweisen auf extern geprüfte Nachweise für Erzeugung, Zellumhüllung, Transfer, Referenzabdeckung, unabhängige Versuche und alle Ausfälle, separate Wissenschaftsordnung sowie vorab fixierte Stufenzahl und unveränderten Zwischenstand. Die Eingabe akzeptiert S, D, C als rationale Zeichenketten jeweils von 1 bis 1,0001. Eine lokale JSON-Datei beweist die zeitliche Integrität eines Feldprotokolls nicht. Das Versuchsteam muss den ersten Stand und seine Entscheidung vor einer etwaigen Fortsetzung verbindlich festhalten.

Die Vorlage **examples/field_worksheet.json** enthält C01 bis C16, die ersten 33 Millionen Versuche je Zelle und leere Nachweis- und Trefferfelder. Nachweisprüfung und Auswertung erfolgen im Feldmodus. Zwei Look-Objekte dürfen allein auf einen ersten CONTINUE folgen. Für die zweite Stufe sind 13 Millionen neue Versuche je Zelle einzutragen. Die Zellen werden nach ID zugeordnet. Jede Stufe muss vollständig sein. Nachträgliche Zusatzstufen, doppelte Zellen oder kumulative Versuche im zweiten Block lösen einen Eingabefehler aus.

| Rückgabe | Bedeutung |
|---|---|
| HOLD_ASSUMPTIONS | Nachweise fehlen oder liegen außerhalb der Designgrenzen. Voller Geometriebereich. |
| AWAIT_FIRST_LOOK | Externe Zusagen hinterlegt, erster abgeschlossener Messblock fehlt. |
| CONTINUE | Genau ein zusätzlicher Block von 13 Millionen Versuchen je Zelle erforderlich. Geometrieentscheidung ausstehend. |
| GO | Kalibrierung abgeschlossen. Ohne wissenschaftlichen Zähler steht die Geometrieausgabe aus. |
| HOLD_COUNTS | Zählregel beendet die Kalibrierung mit vollem Geometriebereich. |

Das Feld evaluated_attempts zählt nur formal ausgewertete Versuche. Ein leerer oder aus Annahmegründen gesperrter Datensatz hat hier den Wert null. Der optionale wissenschaftliche Zähler wird nach dem v0.4-Protokoll mit disjunkten Achtergruppen aus insgesamt 3,2 Millionen unabhängigen Ereignissen erhoben.

## Reproduktion

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B sequential_bounds.py > /tmp/x6-v07-cert.json
cmp records/certificate.json /tmp/x6-v07-cert.json
python -B pilot.py score records/counts.npz > /tmp/x6-v07-score.json
cmp records/pilot.json /tmp/x6-v07-score.json
python -B pilot.py replay records/counts.npz > /tmp/x6-v07-replay.json
cmp records/pilot.json /tmp/x6-v07-replay.json
python -B verify.py > /tmp/x6-v07-checks.json
cmp records/verification.json /tmp/x6-v07-checks.json
```

## Was der gepaarte Pilot vergleicht

Die ersten 33 Millionen Versuche pro Zelle sind für alle drei Pläne identisch. Die operative v0.7-Regel sieht den zweiten Block nur nach CONTINUE. Das Kontrollverfahren mit ausschließlich einem Endentscheid wertet die 46 Millionen immer aus. Die v0.6-Referenz erhält eine weitere unabhängige Million pro Zelle und ihre veröffentlichte eigene Schwelle. Die Bereitstellung potentieller Folgebeobachtungen im Pilot erlaubt den gepaarten Vergleich; die Verbrauchsrechnung belastet v0.7 nur mit den im Feld tatsächlich angeforderten Stufen.

| Szenario | Bedeutung |
|---|---|
| flat_50 | Alle Zellen bei 50 % |
| good_edge_8 / good_edge_1 | 8 bzw. 1 hohe Zelle(n), Zellmittel 0,49 und 0,49 × 1,0002 |
| boundary_pair | Zwei komplementäre Zellmittel mit Verhältnis L, übrige Zellen 0,5. Statistische Schwelle, physischer Kontrast bei konstanten Faktoren unter K*. |
| unsafe_rare | Zwei komplementäre Zellmittel mit Verhältnis L × 1,00001, übrige 0,5. In den zwei Zellen werden auf je 0,1 % Referenzmasse die C-Extreme ausgenutzt. Die Basiswerte werden so gewählt, dass die simulierten Zellmittel exakt gelten. S und D sind in der hohen Zelle maximal. Der tatsächliche Kontrast ist größer als K*. |
| unsafe_clear | Komplementäres Paar mit Verhältnis 1,0025, andere Zellen 0,5. Bei S=D=1 und zellkonstantem e ist das Profil unsicher; eines der Paare erfüllt den zusätzlichen Abstand von mindestens 0,0002. |
| indifference | Komplementäres Paar mit Verhältnis 1,0011, übrige 0,5. Bei konstanten Faktoren zwar sicher, außerhalb der günstigen Klasse. |
| safe_low | Homogene Nachweisrate von 0,1, bei konstanten Faktoren sicher, außerhalb der günstigen Klasse. |

Die genaue Realisierung für unsafe_rare ist in verify.py geprüft. In der hohen Zelle mit Mittel p_H sind die zwei Effizienzen p_H/[1+η(C−1)] und das C-Fache davon; in der niedrigen Zelle mit Mittel p_L sind sie p_L/[1−η(1−1/C)] und dieser Wert geteilt durch C. Jeweils der zweite Wert gilt auf Masse η=0,001. Schwellenmittel allein ersetzen die physische Begründung des Kontrasts nicht.
