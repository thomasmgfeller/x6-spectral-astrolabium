# Eigenzeit v0.14 · Erster KVF-Kontrollvergleich

**Status: CONDITIONAL_SYNTHETIC_CONTROL_COMPLETE. Feldanwendung: HOLD_FIELD_TRANSFER.**

Zwei freie Skalarfelder in derselben flachen Raumzeit wurden mit einer
gemeinsamen idealisierten Auslesebeschreibung verglichen. Ein endlicher
Korrelationsvektor unterscheidet das masselose Modell M0 von M1 mit
m ell0 = 1/2 unter den angegebenen Kalibrierannahmen.

| Ergebnis | Wert |
|---|---:|
| Nominale normierte Korrelation bei r/ell0 = 3, M0 | 0.28549938 |
| Nominale normierte Korrelation bei r/ell0 = 3, M1 | 0.20998236 |
| Hinreichendes Budget der primären Vorzeichenregel | 41045 unabhängige Paare |
| Entscheidung | M0 bei mehr als 23645 gleichen Vorzeichen, sonst M1 |
| Gleichmäßige bedingte Fehlerschranke je Richtung | unter 1 % |
| Synthetische Endpunktkontrolle | 18 / 20000 und 23 / 20000 Fehler |
| Zusätzliche GUM-Auswertung | drei Korrelationsgrößen mit gemeinsamer Kovarianz |

Diese Aussagen setzen zentrierte gaußförmige Rohdaten, unabhängige
Versuche, bekannte Abstände, eine effektive Breite innerhalb +/-2 %
und unabhängig begrenztes Detektorrauschen voraus. Diese Annahmen sind
hier festgelegte Modellbedingungen und wurden nicht an Hardware belegt.

Eine explizite Gegenkonstruktion zeigt: Außerhalb der Kalibriergrenzen
kann korreliertes Rauschen die gesamten Rohdatengesetze beider Modelle
identisch machen. Beliebig viele Messungen könnten diesen Alias nicht
auflösen. Für eine reale Anwendung ist daher die unabhängige
Charakterisierung des Rausch-Kreuzterms ein vorrangiger nächster Schritt.

## Inhalt

- [Ergebnisbericht](Bericht.pdf)
- [Herleitung, garantierte Bereiche und Gegenbeispiel](DERIVATION.md)
- [Acht GUM-Schritte und gemeinsame Verteilungsfortpflanzung](GUM.md)
- [Vertrag](CONTRACT.json), [Ergebnisse](records/summary.json), [Kontrollen](records/check.json)
- [Primärquellen](SOURCES.md), [ursprünglicher KVF-Entwurf](previous/DESIGN.md)
- `raw/`: alle sechs Paarmessreihen sowie die zwei Endpunktkampagnen

Der Antwortkanal bleibt ungemessen. Die Korrelationen dieses
Kontrollversuchs sind auch klassisch simulierbar; es wird weder ein
experimenteller Quantennachweis noch Quantengravitation beansprucht.
Die C01-Grenze von 2 ppm wird nicht auf die neuen Messgrößen übertragen.

## Reproduktion

Python 3.12, NumPy 2.3.5, SciPy 1.17.0 wurden verwendet.

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B reproduce.py
```

Der Lauf prüft das Inventar, rechnet die Integralschranken in einem
frischen Verzeichnis nach, erzeugt alle Rohdaten und GUM-Auswertungen
neu und vergleicht Ergebnisse und Rohdaten mit dem Paket. Eine externe
Reproduktion durch andere Personen steht aus. Die eigene separate
Gegenrechnung ist kein externer Audit.

Die anfängliche Rechenfassung, ihre Fixierung vor Datenerzeugung und
eine nachträgliche, ergebnisneutrale Präzisierung der gerichteten
Intervallrechnung sind unter `development/` dokumentiert. Der endgültige
Stand steht in FREEZE.sha256; die ursprünglichen Daten wurden beibehalten.

## Nächster Arbeitsschritt

Ein zeitversetztes Messmodell muss den Antwortkanal mit Feldkopplung,
Schaltfunktionen und Rückwirkung verbinden. Parallel ist zu prüfen,
wie Nullpunkte, zeitliche Abhängigkeit und das korrelierte
Detektorrauschen unabhängig messbar begrenzt werden können. Erst danach
kann aus diesem Kontrollvergleich ein konkreter Laborvertrag entstehen.
