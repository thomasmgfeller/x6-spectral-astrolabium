"""Rational nonasymptotic family coverage, three-model decision and necessary budgets."""
from fractions import Fraction as Q
from itertools import combinations
from math import comb
import json
from geometry_model import GRID,base,universal
from rule import CONFIG,table,total_pairs,G

def group_tail(params,n,b,d):
    pl,pu,vl,vu,*_=params
    low=(2*pl*(1-pl)+4*(b-2)*vl)/(b*(b-1))
    high=(2*pu*(1-pu)+4*(b-2)*vu)/(b*(b-1))
    root_groups=base.roots(Q(n//b))[0]
    z=d*root_groups/base.roots(high)[1]
    berry=Q(3328,10000)*((1-pl)/base.roots(low)[0]+Q(429,1000))/root_groups
    return base.round_upper(base.normal_tail(z)+berry)

def lower_budget(hi,hj):
    a,b=base.delta(hi),base.delta(hj)
    ref=base.cross(a,b)[0]**2/(base.cross(a,a)[1]*base.cross(b,b)[1])
    den=10**32; ell=base.down(ref,den)
    alpha=Q(CONFIG['family_coverage_target']); power=Q(CONFIG['correct_singleton_target'])
    assert 1-alpha==Q(1,20) and power==Q(4,5)
    cap=Q(121,400)
    def power_lower(n):
        x=ell;v=den
        while n:
            if n%2:v=v*x//den
            x=x*x//den;n//=2
        return Q(v,den)
    left,right=0,1
    while power_lower(right)>cap:right*=2
    while right-left>1:
        mid=(right+left)//2
        if power_lower(mid)>cap:left=mid
        else:right=mid
    return dict(h=[str(hi),str(hj)],necessary_N=right,lower_at_predecessor=str(power_lower(left)),
                affinity_squared_lower=str(Q(ell,den)),required_at_most=str(cap))

def worst_width(rad):
    hs,pl,pu,ql,qu=table();best=Q(0);pair=None;k=0
    for j in range(G):
        k=max(k,j)
        while k+1<G and pl[k+1]-pu[j+1]<=2*rad:k+=1
        width=qu[k+1]-ql[j]
        if width>best:best=width;pair=(j,k)
    return best,pair

def calculate():
    params,m3,rows=universal();_,pl,pu,_,_=table();idx=[int(2*G*h) for h in GRID]
    results={}
    for name,opt in CONFIG['methods'].items():
        n=opt['N'];r=Q(opt['radius'])
        def tail(d):
            if d<=0:raise ArithmeticError('grid not separated')
            if name=='full':return base.full_tail(n,d,params,m3)[0]
            return group_tail(params,n,opt['b'],d)
        one=tail(r); coverage=1-2*one;performance=[]
        for j,i in enumerate(idx):
            left=r if j==0 else min(r,pl[i]-pu[idx[j-1]]-r)
            right=r if j==len(idx)-1 else min(r,pl[idx[j+1]]-pu[i]-r)
            ll,rr=tail(left),tail(right)
            performance.append(dict(h=str(GRID[j]),left_margin=str(left),right_margin=str(right),
                                    left_failure_upper=str(ll),right_failure_upper=str(rr),singleton_lower=str(1-ll-rr)))
        width,pair=worst_width(r)
        if coverage<Q(CONFIG['family_coverage_target']) or any(Q(z['singleton_lower'])<Q(CONFIG['correct_singleton_target']) for z in performance):
            raise ArithmeticError('coverage or correct-singleton gate failed')
        results[name]=dict(n=n,queries=total_pairs(name),radius=str(r),coverage_lower=str(coverage),
                           grid_performance=performance,returned_q_width_upper=str(width),width_cell_pair=pair)
    return dict(formal_gate='PASS',methods=results,necessary=[lower_budget(i,j) for i,j in combinations(GRID,2)],
                model_pv_bounds=list(map(str,params[:4])),third_moment_upper=str(m3),
                variance_cell_bounds=[[str(lo),str(hi)] for lo,hi in rows],
                membership='all integer count inputs; same constants for each fixed h in [0,1/2]',
                singleton='correct and sole grid candidate, unconditional on issuing a singleton; on grid truths only')
if __name__=='__main__':print(json.dumps(calculate(),indent=2))
