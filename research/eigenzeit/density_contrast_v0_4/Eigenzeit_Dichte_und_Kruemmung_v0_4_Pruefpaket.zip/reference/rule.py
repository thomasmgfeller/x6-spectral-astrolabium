"""An outer curvature interval and compatible candidates from a certified count."""
from argparse import ArgumentParser
from bisect import bisect_left,bisect_right
from functools import lru_cache
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import json
import numpy as np
from geometry_model import BASE,GRID,base,ref

CONFIG=json.loads((BASE/'design.json').read_text())
G=CONFIG['interval_h_cells']

def total_pairs(method):
    cfg=CONFIG['methods'][method];n=cfg['N']
    return comb(n,2) if method=='full' else (n//cfg['b'])*comb(cfg['b'],2)

@lru_cache(None)
def table():
    ref.certificate()
    hs=[Q(j,2*G) for j in range(G+1)]
    p_lower=[];p_upper=[];q_lower=[];q_upper=[]
    for h in hs:
        pl,pu=ref.probability(h);ql,qu=ref.q_bounds(h)
        p_lower.append(Q(base.down(pl,10**13),10**13))
        p_upper.append(Q(base.up(pu,10**13),10**13))
        q_lower.append(Q(base.down(ql,10**9),10**9))
        q_upper.append(Q(base.up(qu,10**9),10**9))
    for values in (p_lower,p_upper,q_lower,q_upper):
        if values!=sorted(values):raise ArithmeticError('nonmonotone lookup table')
    return hs,p_lower,p_upper,q_lower,q_upper

def infer_count(method,n,count):
    opt=CONFIG['methods'][method];denom=total_pairs(method)
    if type(n) is not int or n!=opt['N'] or type(count) is not int or not 0<=count<=denom:
        raise ValueError('count or N does not match design')
    hs,pl,pu,ql,qu=table()
    u=Q(count,denom);r=Q(opt['radius']);lower,upper=u-r,u+r
    # A cell [h_j,h_(j+1)] survives if its lower p endpoint <= upper and its upper p endpoint >= lower.
    first=max(0,bisect_left(pu,lower)-1)
    last=min(G-1,bisect_right(pl,upper)-1)
    candidates=[str(h) for h in GRID if pl[int(2*G*h)]<=upper and pu[int(2*G*h)]>=lower]
    if first>last:return dict(candidates=candidates,h_interval=None,q_interval=None)
    return dict(candidates=candidates,h_interval=list(map(str,(hs[first],hs[last+1]))),
                q_interval=list(map(str,(ql[first],qu[last+1]))))

def block_counts(n,query,rng, *, chunk=2048,check=None):
    """query(i,j) returns Boolean comparability. Pair grouping is chosen independently of the order."""
    b=CONFIG['methods']['blocks']['b']
    if n%b or chunk<=0:raise ValueError('whole groups and positive chunk required')
    groups=rng.permutation(n).reshape(-1,b)
    out=np.zeros(len(groups),dtype=np.uint8);i,j=np.triu_indices(b,1)
    for start in range(0,len(groups),chunk):
        sub=groups[start:start+chunk]
        a,c=sub[:,i],sub[:,j]
        bits=np.asarray(query(a,c))
        if bits.shape!=a.shape or bits.dtype!=np.bool_:raise ValueError('invalid oracle result')
        if start==0 and check is not None:
            take=min(256,len(sub))
            if not np.array_equal(bits[:take],check(a[:take],c[:take])):raise ValueError('pair-predicate mismatch')
        out[start:start+len(sub)]=bits.sum(axis=1)
    return out

def count_from_outdegrees(n,degrees):
    """Strict transitive-closure outdegrees in any labelling. Validity of the supplied order is assumed."""
    total=rows=0
    for d in degrees:
        if type(d) is not int or not 0<=d<n:raise ValueError('invalid outdegree')
        total+=d;rows+=1
    if rows!=n or total>comb(n,2):raise ValueError('invalid degree summary')
    return total

def score_packed(path,method,seed=None):
    import secrets
    cfg=CONFIG['methods'][method];n=cfg['N'];stride=(n+7)//8
    if path.stat().st_size!=n*stride:raise ValueError('wrong packed order size')
    if method=='full':
        with path.open('rb') as stream:
            count=0
            for row in range(n):
                data=stream.read(stride)
                if len(data)!=stride or data[row//8]&(1<<(row%8)):raise ValueError('invalid row')
                count+=int.from_bytes(data,'little').bit_count()
        meta={}
    else:
        if seed is None:seed=secrets.randbits(128)
        if seed<0:raise ValueError('negative seed')
        x=np.memmap(path,dtype=np.uint8,mode='r',shape=(n,stride))
        def query(i,j):
            f=(x[i,j//8]>>(j%8))&1;g=(x[j,i//8]>>(i%8))&1
            if np.any(f&g):raise ValueError('asymmetric relation required')
            return (f|g).astype(bool)
        count=int(block_counts(n,query,np.random.Generator(np.random.PCG64(seed))).sum())
        meta={'seed':str(seed)}
    return dict(count=count,**infer_count(method,n,count),**meta)

if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('method',choices=['full','blocks'])
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--count',type=int);group.add_argument('--packed',type=Path);group.add_argument('--outdegrees',type=Path)
    parser.add_argument('--seed',type=int,help='Only for the independent random grouping of a packed order')
    a=parser.parse_args()
    if a.seed is not None and (a.method!='blocks' or a.packed is None):parser.error('--seed requires blocks --packed')
    if a.outdegrees is not None:
        if a.method!='full':parser.error('--outdegrees requires full')
        with a.outdegrees.open() as stream:a.count=count_from_outdegrees(CONFIG['methods']['full']['N'],(int(line) for line in stream))
    result=score_packed(a.packed,a.method,a.seed) if a.packed else infer_count(a.method,CONFIG['methods'][a.method]['N'],a.count)
    print(json.dumps(result,indent=2))
