"""Published moment models and certified bounds for every h in [0,1/2]."""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import sys
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'reference'))
import certificate as base
from moments import coefficients, numerator_tail, volume_bounds
ref=base.reference
GRID=(Q(0),Q(1,4),Q(1,2))

def dec_lower(x):return Q(base.down(x,10**12),10**12)
def dec_upper(x):return Q(base.up(x,10**12),10**12)

@lru_cache(None)
def universal():
    ref.certificate()
    coeff=coefficients()
    rows=[]
    pmin=ref.probability(GRID[0])[0]
    pmax=ref.probability(GRID[-1])[1]
    for j in range(64):
        a,b=Q(j,128),Q(j+1,128)
        # The wedge numerator is an h polynomial with an absolute symmetric remainder.
        remainder=numerator_tail(b)
        wlo=(sum(c*(a if c>=0 else b)**k for k,c in enumerate(coeff))-remainder)/volume_bounds(b)[1]**3
        whi=(sum(c*(b if c>=0 else a)**k for k,c in enumerate(coeff))+remainder)/volume_bounds(a)[0]**3
        plo=ref.probability(a)[0]
        phi=ref.probability(b)[1]
        rows.append((dec_lower(wlo-phi**2),dec_upper(whi-plo**2)))
    delta_max=base.delta(GRID[-1])[1]
    ratio=((1+delta_max)/(1-delta_max))**4
    dlo,dhi=1/ratio,ratio
    params=(dec_lower(pmin),dec_upper(pmax),min(l for l,u in rows),max(u for l,u in rows),dlo,dhi)
    if not 0<params[2]<=params[3] or not 0<params[0]<params[1]<Q(1,2):raise ValueError('bad uniform bounds')
    third=base.third_moment(params[0],params[1],dlo,dhi,128)
    return params,third,rows
