"""Simulate fixed cases. Score using only archived counts, then join labels."""
import argparse,hashlib,json,multiprocessing
from itertools import product
from fractions import Fraction as Q
from pathlib import Path
import numpy as np
from robust import DESIGN,B,infer,block_counts,ROOT
from sampling import rng,stress_cloud

def dump(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def schedule():
    cfg=DESIGN['pilot'];cases=[(h,profile,'aligned' if i%2 else 'original') for h,profile,i in product(cfg['truths'],cfg['perturbations'],range(cfg['repeats_each']))]
    return sorted((int(j),*case) for j,case in zip(rng('layout','permutation').permutation(len(cases)),cases))

def one(case):
    i,hs,profile,chart=case;cfg=DESIGN['protocols'][DESIGN['pilot']['protocol']]
    n=cfg['N'];h=float(Q(hs));K=float(Q(cfg['K']))
    cloud,proposed=stress_cloud(n,h,K,profile,chart,rng(i,'volume'))
    def query(a,b):
        d=cloud[a]-cloud[b]
        return d[:,:,0]**2>np.einsum('...i,...i->...',d[:,:,1:],d[:,:,1:])
    def check(a,b):
        x,y=cloud[a],cloud[b]
        return abs(x[:,:,0]-y[:,:,0])>np.linalg.norm(x[:,:,1:]-y[:,:,1:],axis=2)
    obs=block_counts(n,query,rng(i,'permutation'),check=check)
    meta=dict(id=i,h=hs,profile=profile,chart=chart,proposals=proposed,
              coordinates_sha256=hashlib.sha256(cloud.astype('<f8',copy=False).tobytes()).hexdigest(),
              blocks_sha256=hashlib.sha256(obs.tobytes()).hexdigest())
    return i,obs,meta

def generate(directory,workers):
    directory.mkdir(parents=True,exist_ok=False);sch=schedule()
    n=DESIGN['protocols'][DESIGN['pilot']['protocol']]['N']
    data=np.empty((len(sch),n//B),dtype=np.uint8);truth=[None]*len(sch)
    with multiprocessing.get_context('spawn').Pool(workers) as pool:
        for i,counts,row in pool.imap_unordered(one,sch):
            data[i]=counts;truth[i]=row
    if any(t is None for t in truth):raise ValueError('missing case')
    np.savez_compressed(directory/'observations.npz',blocks=data)
    dump(directory/'truth.json',truth)

def score(path):
    with np.load(path,allow_pickle=False) as f:x=f['blocks']
    protocol=DESIGN['pilot']['protocol'];n=DESIGN['protocols'][protocol]['N']
    if x.shape!=(len(schedule()),n//B) or x.dtype!=np.uint8 or np.any(x>28):raise ValueError('malformed observations')
    return [dict(id=i,count=int(k),**infer(protocol,int(k))) for i,k in enumerate(x.sum(axis=1,dtype=np.uint64))]

def audit(directory):
    truth=json.loads((directory/'truth.json').read_text());scored=json.loads((directory/'decisions.json').read_text())
    with np.load(directory/'observations.npz',allow_pickle=False) as f:x=f['blocks']
    expected=schedule()
    if not len(truth)==len(scored)==len(expected)==len(x):raise ValueError('size')
    for i,row in enumerate(truth):
        if [row[k] for k in ['id','h','profile','chart']]!=list(expected[i]) or scored[i]['id']!=i or row['blocks_sha256']!=hashlib.sha256(x[i].tobytes()).hexdigest() or scored[i]['count']!=int(x[i].sum()):
            raise ValueError('case mismatch')
    summary=[]
    for h,profile in product(DESIGN['pilot']['truths'],DESIGN['pilot']['perturbations']):
        obs=[s for t,s in zip(truth,scored) if t['h']==h and t['profile']==profile]
        summary.append(dict(h=h,profile=profile,n=len(obs),covered=sum(s['h_interval'] is not None and Q(s['h_interval'][0])<=Q(h)<=Q(s['h_interval'][1]) for s in obs),
                            singleton=sum(s['grid']==[h] for s in obs) if h in DESIGN['grid_h'] else None,
                            empty_grid=sum(not s['grid'] for s in obs),first_case=obs[0]))
    return dict(rows=summary,scope='Implementation stress test only; no empirical coverage or power qualification.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['generate','score','audit']);parser.add_argument('path',type=Path);parser.add_argument('--workers',type=int,default=2)
    args=parser.parse_args()
    if args.mode=='generate':generate(args.path,args.workers)
    elif args.mode=='score':print(json.dumps(score(args.path),indent=2))
    else:print(json.dumps(audit(args.path),indent=2))
