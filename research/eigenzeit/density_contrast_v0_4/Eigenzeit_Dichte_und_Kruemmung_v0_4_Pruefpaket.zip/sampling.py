"""Coordinate adapters for simulations only. Decision code receives relation counts."""
import hashlib,math
import numpy as np
from robust import DESIGN

def rng(key,role):
    s=f"{DESIGN['pilot']['seed_namespace']}/{key}/{role}"
    return np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(s.encode()).digest()[:16],'big')))

def delta(h):return (h/(2*(1+math.sqrt(1-h*h/4))))**2
def factor(h):return h/(1+math.sqrt(1-h*h/4))
def mobius(s,k):return (s+k/4)/(1+k*s)

def flat_profile(u,v):
    # u,v are unscaled null coordinates in the aligned chart.
    return (((1+2*u)*(1+2*v))**2+((1-2*u)*(1-2*v))**2)/16

def draw(n,stream,accept):
    points=np.empty((n,4));filled=proposals=0
    while filled<n:
        m=min(131072,max(4096,n-filled))
        half=.5*stream.random(m)**.25
        t=(.5-half)*np.where(stream.integers(0,2,m)==0,-1.,1.)
        r=half*np.cbrt(stream.random(m));a=accept(t,r)
        if np.any(~np.isfinite(a)) or np.any((a<0)|(a>1+2e-14)):raise ArithmeticError('rejection envelope')
        selected=stream.random(m)<=a
        t=t[selected][:n-filled];r=r[selected][:n-filled]
        ct=stream.uniform(-1,1,len(t));phi=stream.uniform(0,2*np.pi,len(t))
        transverse=r*np.sqrt((1-ct)*(1+ct));sl=points[filled:filled+len(t)]
        sl[:,0]=t;sl[:,1]=transverse*np.cos(phi);sl[:,2]=transverse*np.sin(phi);sl[:,3]=r*ct
        proposals+=m;filled+=len(t)
    return points,proposals

def stress_cloud(n,h,K,profile,chart,stream):
    d=delta(h);k=factor(h)
    def accept(t,r):
        u,v=t-r,t+r
        if chart=='original':
            base=((1-h/2)/(1-h*t))**4
            u,v=mobius(u,-k),mobius(v,-k)
        elif chart=='aligned':
            base=((1-d)/(1-4*d*u*v))**4
        else:raise ValueError(chart)
        above=flat_profile(u,v)>=.1
        if profile=='low_profile':above=~above
        elif profile!='high_profile':raise ValueError(profile)
        return base*np.where(above,1.,1/K)
    return draw(n,stream,accept)

def original_coordinates(x,h):
    if h==0:return x.copy()
    t=x[:,0];r=np.linalg.norm(x[:,1:],axis=1)
    u=mobius(t-r,factor(h));v=mobius(t+r,factor(h))
    scale=(1-factor(h)**2/4)/((1+factor(h)*(t-r))*(1+factor(h)*(t+r)))
    return np.column_stack(((u+v)/2,x[:,1:]*scale[:,None]))

def twin_cloud(n,hi,hj,mode,stream):
    a,b=delta(hi),delta(hj)
    def accept(t,r):
        s=4*(t*t-r*r)
        if mode=='only_weaker_biased':return ((1-b)/(1-b*s))**4
        if mode=='both_biased':return (((1-a)*(1-b))/((1-a*s)*(1-b*s)))**2
        raise ValueError(mode)
    aligned,_=draw(n,stream,accept)
    return original_coordinates(aligned,hi),original_coordinates(aligned,hj)
