"""Only strict pairwise comparability is required from the user-supplied order."""
import secrets
import numpy as np
from robust import DESIGN,block_counts,infer

def apply_oracle(protocol,n,comparable,seed=None):
    """comparable(i,j) takes arrays of indices and returns Boolean values of their shape.
    Grouping is independent of the input order. A seed may be supplied for an independently
    fixed replay; the assumed population contrast K must come from outside this observation.
    """
    expected=DESIGN['protocols'][protocol]['N']
    if type(n) is not int or n!=expected:raise ValueError('wrong N for this protocol')
    if seed is None:seed=secrets.randbits(128)
    if type(seed) is not int or seed<0:raise ValueError('invalid random seed')
    obs=block_counts(n,comparable,np.random.Generator(np.random.PCG64(seed)))
    count=int(obs.sum())
    return dict(N=n,K=DESIGN['protocols'][protocol]['K'],seed=str(seed),count=count,**infer(protocol,count))
