# Eigenzeit v0.4 · Welche Dichtevariation verträgt die Krümmungsaussage?

Die positive Regel setzt eine **extern bekannte** Obergrenze K für das Verhältnis der größten zur kleinsten Beprobungsdichte relativ zum physischen Volumen voraus. Die Dichte darf eine beliebige positive Raumzeitfunktion innerhalb dieser Klasse sein. Modell sind wie in v0.3 ein vollständiger 4D-Diamant, feste Ereigniszahl und iid-Ereignisse. Unter anderem für K≤1,002 sind eine kontinuierliche Krümmungsausgabe und ein Drei-Modell-Test nachgewiesen. Zwei exakte Gegenbeispiele erklären, was bei größerer Unsicherheit offen oder unmöglich wird.

## Einstieg

- Bericht.pdf fasst Kriterien, Kosten und Ergebnisse zusammen. BEWEIS.md gibt die Modellannahmen und alle wesentlichen Rechenschritte.
- Ansicht.html ist ein lokaler interaktiver Vergleich. Er trennt ein nachweislich unzureichendes Budget von einer offenen Lücke und von einer explizit hinreichenden Regel. Es werden ausschließlich tabellierte Kontraste verwendet.
- records/certificate.json ist die maschinenlesbare, rational nach außen gerundete Rechnung. records/controls.json enthält die unabhängigen Kontrollrechnungen; records/twins.json die 72 gepaarten Ordnungsprüfungen und den als solchen gekennzeichneten Rückblick auf v0.3. records/pilot.json enthält alle acht Belastungsgruppen einschließlich des nicht überdeckten Falles im Datenbestand.
- pilot/observations.npz enthält 32 × 400000 Gruppenzahlen für die beabsichtigte positive Belastungsprobe (uint8, 0 bis 28). pilot/truth.json enthält separat die Simulationswahrheit, die Karten und die Fingerabdrücke. pilot/decisions.json enthält die ohne Wahrheit aus den Zählungen erzeugten Resultate.
- reference/ enthält den benötigten Code der Vorstufen und die für den Rückblick benötigten v0.3-Falldateien mit Herkunfts- und Prüfsummennachweis.
- FREEZE.sha256 fixiert den lokalen Stand vor den neuen Beispielen. Dies ist keine öffentliche Vorregistrierung. Die Visualisierung und der Abschlussbericht sind später ergänzt.

## Reproduktion

Im Paketverzeichnis mit Python 3, NumPy und SciPy (siehe records/environment.json) sowie optional Node für die HTML-Prüfung. Die Zertifizierung verrechnet rationale Zahlen und ganze Zahlen. Alle Beispieldaten lassen sich aus den fixierten Seeds erneut erzeugen.

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B robust.py > /tmp/x6-v04-certificate.json
cmp records/certificate.json /tmp/x6-v04-certificate.json
python -B controls.py > /tmp/x6-v04-controls.json
cmp records/controls.json /tmp/x6-v04-controls.json
python -B twins.py > /tmp/x6-v04-twins.json
cmp records/twins.json /tmp/x6-v04-twins.json
python -B pilot.py score pilot/observations.npz > /tmp/x6-v04-decisions.json
cmp pilot/decisions.json /tmp/x6-v04-decisions.json
python -B pilot.py audit pilot > /tmp/x6-v04-audit.json
cmp records/pilot.json /tmp/x6-v04-audit.json
python visual/build.py /tmp/x6-v04-view.html
cmp Ansicht.html /tmp/x6-v04-view.html
node visual/verify.cjs
```

Für eine Wiederholung der Erzeugung muss das Zielverzeichnis neu sein:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python -B pilot.py generate /tmp/x6-v04-pilot --workers 3
cmp pilot/observations.npz /tmp/x6-v04-pilot/observations.npz
cmp pilot/truth.json /tmp/x6-v04-pilot/truth.json
```

Im lokalen Wiederholungslauf waren die Rohgruppenzahlen, Koordinatenhashes, Ausgaben, Zertifikate und Kontrollresultate bytegleich. Simulationskoordinaten können plattformabhängige Gleitkommaunterschiede aufweisen. Die vier Budgetzertifikate sind analytisch; der Pilot mit drei Rasterwahrheiten und einem Zwischenwert betrifft **nur** die Regel K=1,002 bei N=3200000.

## Verwendung bei einem eigenen Zählwert

```sh
python robust.py --protocol contrast_0_2 --count 1135459
```

Die Summe muss aus den spezifizierten, einmal unabhängig gebildeten Achtergruppen stammen. Für ein externes Vergleichbarkeitsorakel ist apply_order.apply_oracle verfügbar. Es akzeptiert eine Funktion, die für zwei Indexarrays boolesche Vergleichbarkeiten gleicher Form liefert. Ein beliebiger anderer Zähler oder nachträgliches Umgruppieren bis zu einer eindeutigen Ausgabe fallen außerhalb der Garantie. Die Wahl des Protokolls einschließlich der Kontrastobergrenze ist vor der Auswertung zu treffen.
