const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const h=fs.readFileSync('Ansicht.html','utf8'),c=JSON.parse(fs.readFileSync('records/certificate.json')),d=JSON.parse(fs.readFileSync('design.json'));
const els=new Map();for(const [,id] of h.matchAll(/\sid="([^"]+)"/g))els.set(id,{value:'',addEventListener(k,f){this[k]=f;}});
const el=id=>els.get(id);el('n').value=3200000;const cx={document:{getElementById:el}};vm.createContext(cx);vm.runInContext(h.match(/<script>([\s\S]*?)<\/script>/)[1],cx);
let total=0;
for(const k of d.necessary_contrasts){
 const rows=Object.values(c.pairs).map(r=>r.by_K[k].necessary_N);
 const fixed=Object.values(c.positive).find(z=>z.K===k)?.N;
 const l=Math.max(...rows);
 for(const n of new Set([1,900000,l-1,l,l+1,fixed?fixed-1:1000000,fixed??1500000,10**8])){
    const want=rows.includes(null)?'twin':n<l?'excluded':fixed&&n>=fixed?'sufficient':'open';
    assert.equal(cx.gate(k,n).code,want);total++;
 }
}
assert.equal(cx.gate('501/500',-1).code,'invalid');assert.equal(cx.gate('unknown',100).code,'invalid');
el('k').value='101/100';el('small').click();assert(el('decision').textContent.includes('nicht'));el('k').value='501/500';el('primary').click();assert(el('decision').textContent.includes('verfügbar'));
console.log('PASS',total,'budget decisions and input/control checks');
