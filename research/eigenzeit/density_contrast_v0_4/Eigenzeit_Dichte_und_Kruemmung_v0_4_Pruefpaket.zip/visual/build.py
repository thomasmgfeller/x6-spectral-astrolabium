import json,sys
from pathlib import Path
from fractions import Fraction as Q
root=Path(__file__).resolve().parents[1]
c=json.loads((root/'records/certificate.json').read_text());design=json.loads((root/'design.json').read_text())
pairs=list(c['pairs']);keys=design['necessary_contrasts']
protocols={Q(v['K']):v['N'] for v in c['positive'].values()}
data={k:dict(need=[c['pairs'][p]['by_K'][k]['necessary_N'] for p in pairs],sufficient=min((n for lim,n in protocols.items() if lim>=Q(k)),default=None)) for k in keys}
options=''
for k in keys:
    q=Q(k);value=float(100*(q-1));label=(f'{value:.4f}'.rstrip('0').rstrip('.')).replace('.',',')+' %' if q!=1 else '0 %'
    if q==Q(64,63):label='64/63 (≈ 1,5873 %)'
    options+=f'<option value="{k}">{label}</option>'
rows=''.join(f'<tr><td>{p.replace(" to "," und ")}</td><td id="need{i}"></td><td>{c["pairs"][p]["exact_both_varying"]}</td></tr>' for i,p in enumerate(pairs))
s=(root/'visual/template.html').read_text().replace('__OPTIONS__',options).replace('__ROWS__',rows).replace('__DATA__',json.dumps(data,separators=(',',':')))
Path(sys.argv[1]).write_text(s)
