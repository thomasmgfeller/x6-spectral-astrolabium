"""Full-relation checks of the coupling and a documented reinterpretation of the v0.3 pilot."""
from fractions import Fraction as Q
from itertools import combinations
import hashlib,json
from pathlib import Path
import numpy as np
from scipy.spatial.distance import pdist,squareform
from robust import GRID,ROOT
from sampling import twin_cloud,rng

def run():
    record=[]
    for a,b in combinations(GRID,2):
        for mode in ('only_weaker_biased','both_biased'):
            for i in range(12):
                key=f'twin-{a}-{b}-{mode}-{i}'
                x,y=twin_cloud(256,float(a),float(b),mode,rng(key,'couple'))
                dt=x[None,:,0]-x[:,None,0];g=(dt>0)&(dt*dt>squareform(pdist(x[:,1:],'sqeuclidean')))
                dy=y[None,:,0]-y[:,None,0]
                h=dy>np.linalg.norm(y[None,:,1:]-y[:,None,1:],axis=2)
                if not np.array_equal(g,h):raise AssertionError(key)
                record.append(dict(key=key,comparable=int(g.sum()),relation_sha256=hashlib.sha256(np.packbits(g,bitorder='little').tobytes()).hexdigest()))
    path=ROOT/'reference/pilot'
    truth=json.loads((path/'truth.json').read_text());results=json.loads((path/'decisions.json').read_text())
    rows=[s for t,s in zip(truth,results) if t['h']=='1/4']
    return dict(coupled_cases=record,same_complete_orders=len(record),relations_compared_unordered=len(record)*256*255//2,
                archived_uniform_weak_cases=len(rows),weaker_flat_twin_excluded=sum('0' not in s['candidates'] for s in rows),
                only_weak=sum(s['candidates']==['1/4'] for s in rows),
                warning='Archived results are the same observations reinterpreted under exact coupling; not new independent curves.')
if __name__=='__main__':print(json.dumps(run(),indent=2))
