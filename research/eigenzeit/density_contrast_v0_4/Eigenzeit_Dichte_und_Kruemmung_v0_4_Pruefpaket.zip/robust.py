"""Certified contrast sensitivity and three-model inference for one order."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
from functools import lru_cache
from bisect import bisect_left,bisect_right
import argparse,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference'))
from geometry_model import base,GRID,universal,ref
from rule import table,block_counts,G
from theorem import worst_width
DESIGN=json.loads((ROOT/'design.json').read_text())
B=DESIGN['group_size']
PAIRS=B*(B-1)//2

def svalue(h):
    return 1-h*h/4

def rational_twins(hi,hj):
    ratio=svalue(hi)/svalue(hj)
    return ratio**2,ratio

def delta_from_s(interval):
    lo=base.roots(interval[0],10**36)[0]
    hi=base.roots(interval[1],10**36)[1]
    return (1-hi)/(1+hi),(1-lo)/(1+lo)

def fidelity_limit(hi,hj,K):
    # Each physical measure can imitate a volume-uniform law closer to the other model.
    si,sj=svalue(hi),svalue(hj)
    if K>=si/sj:return dict(status='EXACT_TWIN',necessary_N=None)
    l,u=base.roots(K,10**36)
    di=delta_from_s((si/u,si/l))
    dj=delta_from_s((sj*l,sj*u))
    ell=base.cross(di,dj)[0]**2/(base.cross(di,di)[1]*base.cross(dj,dj)[1])
    den=10**32; e=base.down(ell,den)
    if not 0<e<den:raise ArithmeticError('affinity enclosure unresolved')
    def power_lo(n):
        val=den; x=e
        while n:
            if n%2:val=val*x//den
            x=x*x//den;n//=2
        return Q(val,den)
    cap=Q(121,400);lo,up=0,1
    while power_lo(up)>cap:up*=2
    while up-lo>1:
        mid=(lo+up)//2
        if power_lo(mid)>cap:lo=mid
        else:up=mid
    return dict(status='FINITE_NECESSARY',necessary_N=up,affinity_squared_lower=str(Q(e,den)),value_at_predecessor=str(power_lo(lo)))

def width_floor(K):
    # Choose flat and a matching curved geometry in the two-sided class.
    z=min(1-1/K,Q(1,16));j=24
    series=sum(z**i/(2*i+1) for i in range(j))
    err=z**j/((2*j+1)*(1-z))
    return str(Q(base.down(48*z*series**2,10**12),10**12)),str(base.round_upper(48*z*(series+err)**2,10**12))

def nuisance_bounds(K):
    if K<1:raise ValueError('invalid contrast')
    params=universal()[0];p0,p1,v0,v1=params[:4]
    eta=(K-1)/(2*base.roots(K)[0])
    gamma=base.roots(p1*(1-p1)-2*v0)[1]
    bias=base.round_upper(2*eta*base.roots(v1)[1]+eta**2*gamma,10**15)
    vlow=(2*p0*(1-p0)+4*(B-2)*v0)/(B*(B-1)*K**B)
    vhigh=(2*p1*(1-p1)+4*(B-2)*v1)*K**B/(B*(B-1))
    if not 0<=p0-bias<=p1+bias<Q(1,2):raise ValueError('outside bounded comparison range')
    return bias,vlow,vhigh,p0-bias

def tail(N,d,vlow,vhigh,plow):
    if N%B or d<=0:raise ValueError('invalid margin or N')
    rootm=base.roots(Q(N//B))[0]
    z=d*rootm/base.roots(vhigh)[1]
    be=Q(3328,10000)*((1-plow)/base.roots(vlow)[0]+Q(429,1000))/rootm
    return base.round_upper(base.normal_tail(z)+be)

def certify(name):
    cfg=DESIGN['protocols'][name];K=Q(cfg['K']);n=cfg['N'];r=Q(cfg['radius'])
    bias,vl,vu,plow=nuisance_bounds(K);_,pl,pu,_,_=table();idx=[int(2*G*h) for h in GRID]
    one=tail(n,r-bias,vl,vu,plow);coverage=1-2*one
    decisions=[]
    for i,j in enumerate(idx):
        l=r if i==0 else min(r,pl[j]-pu[idx[i-1]]-r)
        u=r if i==len(idx)-1 else min(r,pl[idx[i+1]]-pu[j]-r)
        a=tail(n,l-bias,vl,vu,plow);b=tail(n,u-bias,vl,vu,plow)
        decisions.append(dict(h=str(GRID[i]),left_error_upper=str(a),right_error_upper=str(b),correct_singleton_lower=str(1-a-b)))
    w,pair=worst_width(r)
    if coverage<Q(19,20) or any(Q(x['correct_singleton_lower'])<Q(4,5) for x in decisions):raise ArithmeticError('insufficient budget')
    return dict(K=str(K),N=n,comparisons=n//B*PAIRS,nominal_radius=str(r),pair_probability_bias_upper=str(bias),
                block_variance_bounds=[str(vl),str(vu)],coverage_lower=str(coverage),grid=decisions,
                reported_q_width_upper=str(w),width_cell_pair=pair,ambiguity_q90_floor=width_floor(K)[0])

def infer(name,count):
    cfg=DESIGN['protocols'][name];n=cfg['N'];den=n//B*PAIRS;r=Q(cfg['radius'])
    if type(count) is not int or not 0<=count<=den:raise ValueError('invalid comparable-pair count')
    y=Q(count,den);hs,pl,pu,ql,qu=table();lo,hi=y-r,y+r
    first=max(0,bisect_left(pu,lo)-1);last=min(G-1,bisect_right(pl,hi)-1)
    grid=[str(h) for h in GRID if pl[int(2*h*G)]<=hi and pu[int(2*h*G)]>=lo]
    if first>last:return dict(grid=grid,h_interval=None,q_interval=None)
    return dict(grid=grid,h_interval=[str(hs[first]),str(hs[last+1])],q_interval=[str(ql[first]),str(qu[last+1])])

def certificate():
    result={}
    for i,j in combinations(GRID,2):
        single,both=rational_twins(i,j)
        result[str(i)+' to '+str(j)]=dict(exact_uniform_curved_flat_or_weaker_varying=str(single),exact_both_varying=str(both),
                                          by_K={k:fidelity_limit(i,j,Q(k)) for k in DESIGN['necessary_contrasts']})
    return dict(positive={name:certify(name) for name in DESIGN['protocols']},pairs=result,
                prior_v03_N=DESIGN['protocols']['uniform']['N'],
                scope='Independent sampling with an externally bounded density contrast. No stochastic or smoothness assumptions on its spatial profile.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--protocol',choices=DESIGN['protocols']);parser.add_argument('--count',type=int)
    args=parser.parse_args()
    if (args.protocol is None)!=(args.count is None):parser.error('use --protocol and --count together')
    print(json.dumps(certificate() if args.protocol is None else infer(args.protocol,args.count),indent=2))
