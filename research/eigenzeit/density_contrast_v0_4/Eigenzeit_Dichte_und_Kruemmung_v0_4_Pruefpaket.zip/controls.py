"""Independent decimal/normal/binomial identity controls for the analytical certificate."""
from decimal import Decimal as D, localcontext, ROUND_CEILING
from fractions import Fraction as Q
from itertools import combinations,product
from math import sqrt,erfc,comb,atanh
import json
import numpy as np
from numpy.polynomial.legendre import leggauss
from robust import DESIGN,GRID,ROOT,base,table,G,infer,nuisance_bounds,width_floor,rational_twins

def require(x,msg):
    if not x:raise ArithmeticError(msg)

def decimal_check(hi,hj,contrast):
    with localcontext() as ctx:
        ctx.prec=80
        cv=lambda f:D(f.numerator)/D(f.denominator)
        si=1-cv(hi)**2/4;sj=1-cv(hj)**2/4;k=cv(contrast).sqrt()
        def delta(s):return (1-s.sqrt())/(1+s.sqrt())
        a,b=delta(si/k),delta(sj*k)
        def mixed(d,e):
            total=D(0);pd=[D(1)];pe=[D(1)]
            for _ in range(38):pd.append(pd[-1]*d);pe.append(pe[-1]*e)
            for n in range(39):
                # Flat-square moments for S = U*V under 3(V-U)^2/8.
                mu=D(3)/((n+1)*(n+3)) if n%2==0 else -D(3)/(n+2)**2
                total+=mu*sum((i+1)*(n+1-i)*pd[i]*pe[n-i] for i in range(n+1))
            return total
        a2=mixed(a,b)**2/(mixed(a,a)*mixed(b,b))
        return int(((D(121)/400).ln()/a2.ln()).to_integral_value(rounding=ROUND_CEILING))

def finite_model_checks():
    prob=(Q(1,5),Q(7,20),Q(9,20));n=3
    pair=lambda a,b:int({a,b} in ({0,1},{1,2}))
    def moments(p):
        r=[sum(p[j]*pair(i,j) for j in range(n)) for i in range(n)]
        mu=sum(x*y for x,y in zip(p,r));v=sum(x*(y-mu)**2 for x,y in zip(p,r))
        return r,mu,v
    r,p,v=moments(prob); b=4;gamma=p*(1-p)-2*v
    def var(m,w):return (2*m*(1-m)+4*(b-2)*w)/(b*(b-1))
    tests=0
    for k in [Q(1001,1000),Q(501,500),Q(6,5)]:
        for ws in product([Q(1),(1+k)/2,k],repeat=n):
            z=sum(x*y for x,y in zip(prob,ws));u=[w/z-1 for w in ws];q=[a*(e+1) for a,e in zip(prob,u)]
            r2,m2,v2=moments(q);chi=sum(a*e**2 for a,e in zip(prob,u));eta2=(k-1)**2/(4*k)
            require(chi<=eta2,'Kantorovich')
            lin=2*sum(a*e*(r0-p) for a,e,r0 in zip(prob,u,r))
            quad=sum(prob[i]*prob[j]*u[i]*u[j]*(pair(i,j)-r[i]-r[j]+p) for i,j in product(range(n),repeat=2))
            require(m2-p==lin+quad and lin*lin<=4*eta2*v and quad*quad<=eta2**2*gamma,'pair bias')
            require(var(p,v)/k**b<=var(m2,v2)<=var(p,v)*k**b,'changed block variance')
            tests+=1
    return tests

def main():
    c=json.loads((ROOT/'records/certificate.json').read_text())
    old=json.loads((ROOT/'reference/records/certificate.json').read_text())['methods']['blocks']
    zero=c['positive']['uniform']
    require(zero['coverage_lower']==old['coverage_lower'] and zero['reported_q_width_upper']==old['returned_q_width_upper'],'v0.3 limits')
    require([z['correct_singleton_lower'] for z in zero['grid']]==[z['singleton_lower'] for z in old['grid_performance']],'v0.3 singleton')
    finite=0;twin=0;nodes,w=leggauss(64);s=nodes[:,None]*nodes[None,:];dm=.375*(nodes[:,None]-nodes[None,:])**2*w[:,None]*w[None,:]
    for i,j in combinations(GRID,2):
        result=c['pairs'][str(i)+' to '+str(j)]
        di,dj=[(float(h)/(2*(1+sqrt(1-float(h)**2/4))))**2 for h in (i,j)]
        fi=(1-di*s)**-4;fj=(1-dj*s)**-4
        common=np.sqrt(fi*fj);common/=np.sum(common*dm)
        for f in [fi,fj]:
            pi=f/np.sum(dm*f);reweight=common/pi
            require(abs(np.sum(pi*dm*reweight)-1)<3e-14 and np.max(abs(pi*reweight-common))<3e-14,'midpoint quadrature')
        for k,record in result['by_K'].items():
            if record['status']=='EXACT_TWIN':require(Q(k)>=rational_twins(i,j)[1],'twin threshold');twin+=1
            else:
                require(decimal_check(i,j,Q(k))==record['necessary_N'],'decimal budget')
                require(Q(record['value_at_predecessor'])>Q(121,400),'boundary')
                finite+=1
    risks=0;scans=0;hs,pl,pu,ql,qu=table()
    for name,row in c['positive'].items():
        k=Q(row['K']);n=row['N'];m=n//8;r=Q(row['nominal_radius'])
        bias,vl,vu,p0=nuisance_bounds(k)
        for g,idx in zip(row['grid'],[0,G//2,G]):
            near=[x for x in [0,G//2,G] if x!=idx]
            L=min([r]+[pl[idx]-pu[x]-r for x in near if x<idx])-bias
            U=min([r]+[pl[x]-pu[idx]-r for x in near if x>idx])-bias
            for d,bound in [(L,g['left_error_upper']),(U,g['right_error_upper'])]:
                numeric=.5*erfc(float(d)*sqrt(m/(2*float(vu))))+.3328*((1-float(p0))/sqrt(float(vl))+.429)/sqrt(m)
                if not numeric-2e-12<=float(Q(bound))<=numeric+1e-5:raise ArithmeticError('finite normal comparison')
                risks+=1
        for bcount in np.linspace(.099,.105,17):
            count=round(float(bcount)*row['comparisons']);y=Q(count,row['comparisons']);ans=infer(name,count)
            cells=[j for j in range(G) if pl[j]<=y+r and pu[j+1]>=y-r]
            need=[str(ql[cells[0]]),str(qu[cells[-1]+1])] if cells else None
            require(ans['q_interval']==need,'full scan');scans+=1
        floor_low,floor_hi=map(Q,width_floor(k))
        point=48*atanh(sqrt(min(1-1/float(k),1/16)))**2
        require(float(floor_low)-1e-12<=point<=float(floor_hi)+1e-12,'width floor')
    return dict(status='PASS',finite_toy_nuisance_laws=finite_model_checks(),independent_decimal_lower_budgets=finite,
                exact_collision_entries=twin,normal_risk_checks=risks,cell_inversion_checks=scans,
                nominal_v03_recovered=True,midpoint_density_identities_checked='all three grid pairs')
if __name__=='__main__':print(json.dumps(main(),indent=2))
