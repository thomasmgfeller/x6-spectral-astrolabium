"""Independent numerical and operational controls for the finite-sample budgets."""
import hashlib
import json
import math
from fractions import Fraction as F
from copy import deepcopy
import numpy as np
from scipy.stats import binom
from calibrate import DESIGN, ROOT, J, L, MARGIN, apply, check, count_threshold
from budgets import binomial_cdf, certificate
from pilot import OLD, score


def exact_small(m,p,k):
    return sum(math.comb(m,i)*p**i*(1-p)**(m-i) for i in range(k+1))


def main():
    origin=json.loads((ROOT/'previous/ORIGIN.json').read_text())
    for name,entry in origin['files'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==entry['sha256']
    cert=certificate()
    assert cert==json.loads((ROOT/'records/certificate.json').read_text())
    n=DESIGN['relative']['n']
    gap=F(cert['min_good_gap'])
    vmax=(1+float(L)**2)/4
    numerical_cells=0
    for u,key in [(float(MARGIN),'slice_false_go_upper'),(float(gap-MARGIN),'slice_good_pair_hold_upper')]:
        for j,bound in enumerate(cert[key]):
            vl,vh=j*vmax/100,(j+1)*vmax/100
            lam=u/(vh+float(L)*u/3)
            val=math.exp(-n*u**2/(2*(vh+float(L)*u/3)))
            if vl:
                val*=min(1,(1/(lam*math.sqrt(2*math.pi))+1.12*float(L))/math.sqrt(n*vl*math.exp(-lam*float(L))))
            assert val<=float(F(bound))+1e-15
            numerical_cells+=1
    assert max(map(F,cert['slice_false_go_upper']))<F(1,100)
    assert J*(J-1)*max(map(F,cert['slice_good_pair_hold_upper']))<F(3,1000)
    toys=0
    for m in (7,22,75):
        for p in [F(1,9),F(1,2),F(8,9)]:
            mode=((m+1)*p).__floor__()
            for radius in [2,m+1]:
                for k in range(max(0,mode-radius),min(m,mode+radius)+1):
                    lo,hi=binomial_cdf(m,p,k,radius)
                    assert lo<=exact_small(m,p,k)<=hi
                    toys+=1
    witness=cert['necessary']
    r=F(DESIGN['relative']['good_ratio_max'])
    for key,p in [('favorable',r/(1+r)),('unsafe_limit',L/(1+L))]:
        lo,hi=map(F,witness['cdf'][key])
        value=binom.cdf(witness['cutoff'],witness['pair_total'],float(p))
        assert float(lo)-1e-10 < value < float(hi)+1e-10 and hi-lo<=F(2,10**12)
    examples=lambda k:json.loads((ROOT/'examples'/(k+'.json')).read_text())
    packet=examples('synthetic_go')
    assert check(packet)['status']=='GO'
    c=packet['cells']
    m=n//2
    c[-1]['detected']=count_threshold(m)
    assert check(packet)['status']=='GO'
    c[-1]['detected']+=1
    assert check(packet)['status']=='HOLD_COUNTS'
    field=check(examples('field_no_evidence'))
    assert field['status']=='HOLD_ASSUMPTIONS' and field['geometry']==check(packet)['geometry']
    for corrupt in ['duplicate','wrong_budget','float','missing','v05_id']:
        q=deepcopy(packet)
        if corrupt=='duplicate':q['cells'][1]['id']=q['cells'][0]['id']
        if corrupt=='wrong_budget':q['cells'][0]['attempted']=OLD['relative']['n']
        if corrupt=='float':q['cells'][0]['detected']=.5
        if corrupt=='missing':q['cells'].pop()
        if corrupt=='v05_id':q['design_id']=OLD['id']
        try:check(q)
        except ValueError:pass
        else:raise ValueError('bad input accepted: '+corrupt)
    accepted=apply(examples('synthetic_go'),1157840)
    previous=json.loads((ROOT/'previous/verification.json').read_text())
    assert accepted==previous['synthetic_geometry_example']
    with np.load(ROOT/'records/counts.npz',allow_pickle=False) as data:
        audited=score(data)
        assert audited==json.loads((ROOT/'records/pilot.json').read_text())
        # Independent per-realization integer comparison, including the published v0.5 control.
        direct=0
        for name in DESIGN['simulation']['cases']:
            counts=data[name]
            for tag,arr,cfg in [('new',counts[0],DESIGN),('old',counts[0]+counts[1],OLD)]:
                shift=cfg['relative']['n']*F(cfg['relative']['margin'])
                den=math.lcm(L.denominator,shift.denominator)
                a,b=int(L*den),int(shift*den)
                total=0
                for row in arr:
                    total+=int(int(row.max())*den<=a*int(row.min())-b)
                assert total==audited[name][tag+'_go']
                direct+=len(arr)
    return dict(status='PASS',exact_small_cdfs=toys,large_cdfs_checked_with_scipy=2,
                variance_slices_checked=numerical_cells,individual_pilot_gates_recounted=direct,
                verified_reference_files=len(origin['files']),field_without_evidence=field,
                synthetic_geometry_example=accepted)


if __name__=='__main__':
    print(json.dumps(main(),indent=2))
