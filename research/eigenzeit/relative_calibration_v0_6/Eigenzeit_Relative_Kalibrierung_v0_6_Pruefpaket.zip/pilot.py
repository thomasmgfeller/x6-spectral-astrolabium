"""Paired count-level comparison with v0.5. No data-dependent route selection."""
import argparse
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from calibrate import DESIGN, ROOT, J, L

OLD = json.loads((ROOT/'previous/design.json').read_text())
PLAN = DESIGN['simulation']


def scenarios():
    midpoint = L/(1+L)
    h = F(49,100)*F(5001,5000)
    return {
        'flat_50': [F(1,2)]*J,
        'good_1_high': [h]+[F(49,100)]*15,
        'good_8_high': [h]*8+[F(49,100)]*8,
        'good_15_high': [h]*15+[F(49,100)],
        'boundary_pair': [midpoint,1-midpoint]+[F(1,2)]*14,
        'unsafe_pair': [F(10021,20021),F(10000,20021)]+[F(1,2)]*14,
        'unsafe_one': [F(49,100)*F(10021,10000)]+[F(49,100)]*15,
        'low_safe': [F(1,10)]*J,
    }


def draw():
    arrays = {}
    n = DESIGN['relative']['n']
    extra = OLD['relative']['n']-n
    for i,name in enumerate(PLAN['cases']):
        probabilities = [float(p) for p in scenarios()[name]]
        stages = []
        for stage,size in enumerate([n,extra]):
            rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([PLAN['seed'],i,stage])))
            arr = rng.binomial(size,probabilities,size=(PLAN['repetitions'],J)).astype('<u4')
            stages.append(arr)
        arrays[name] = np.stack(stages)
    return arrays


def passed(arr,design):
    lo,hi = arr.min(axis=1),arr.max(axis=1)
    distinct,inverse = np.unique(lo,return_inverse=True)
    cfg = design['relative']
    shift = cfg['n']*F(cfg['margin'])
    cap = np.asarray([(L*int(k)-shift).__floor__() for k in distinct])
    return hi <= cap[inverse]


def score(arrays):
    if set(arrays)!=set(PLAN['cases']):
        raise ValueError('unexpected case inventory')
    result = {}
    for name in PLAN['cases']:
        block = arrays[name]
        n = DESIGN['relative']['n']
        if (block.shape!=(2,PLAN['repetitions'],J) or block.dtype!=np.dtype('<u4')
                or block[0].max()>n or block[1].max()>OLD['relative']['n']-n):
            raise ValueError('invalid count matrix')
        new = passed(block[0],DESIGN)
        old = passed(block[0]+block[1],OLD)
        result[name] = dict(repeats=len(new),new_go=int(new.sum()),old_go=int(old.sum()),
                            both_go=int((new&old).sum()),new_only=int((new&~old).sum()),
                            old_only=int((~new&old).sum()),both_hold=int((~new&~old).sum()),
                            stage_counts_sha256=hashlib.sha256(block.tobytes()).hexdigest())
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['generate','score','replay'])
    parser.add_argument('file',type=Path)
    args=parser.parse_args()
    if args.mode=='generate':
        np.savez_compressed(args.file,**draw())
    else:
        with np.load(args.file,allow_pickle=False) as data:
            if args.mode=='replay':
                for name,arr in draw().items():
                    if not np.array_equal(arr,data[name]):
                        raise ValueError('seed replay differs in '+name)
            print(json.dumps(score(data),indent=2))
