# Eigenzeit v0.6 · Wie viele Referenzversuche braucht die relative Kalibrierung?

Für dasselbe 16-Zellen-Modell, dieselben externen Dichtezusagen und dieselben Fehlerziele wie in v0.5 genügen bei mittlerer Nachweisrate **752.000.000** markierte Versuche. Das sind 47.000.000 pro Zelle und 288.000.000 weniger als zuvor. Die neue notwendige Gesamtzahl für beliebige feste Zellbudgets ist **mindestens 420.800.008**. Der Abstand zwischen Unter- und Obergrenze beträgt weniger als einen Faktor 1,79. Die Optimalität des Messplans bleibt offen. Für die physikalische Anwendung gilt mangels realer Referenzzählungen und externer Nachweise **HOLD**.

## Einstieg

- **Bericht.pdf** enthält die neue Budgetspanne, die garantierten Wahrscheinlichkeiten sowie den gepaarten Vergleich mit v0.5.
- **BEWEIS.md** enthält Modell, Herleitung der oberen Fehlerschranken, die beiden Anlagen für die Untergrenze und die Quellen. **budgets.py** zertifiziert die numerischen Grenzen mit gerichteter Arithmetik aus ganzen und rationalen Zahlen. Alle 200 Teilintervallgrenzen und beide eingeschlossenen Binomialwerte stehen in **records/certificate.json**.
- **design.json** enthält den neuen festen Messplan. **calibrate.py** ist bytegleich zur veröffentlichten v0.5-Implementierung und liest die neuen Designparameter. **examples/** enthält ein leeres Feldprotokoll und ein als synthetisch gekennzeichnetes GO-Beispiel. Der wissenschaftliche Beispielzähler stammt aus der Vorstudie.
- **pilot.py** erzeugt die Zählungen und wertet sie aus. **records/counts.npz** enthält für jedes der acht Szenarien ein Array mit Form (2, 30000, 16) und Datentyp uint32, little-endian. Achse 0 trennt die ersten 47 Millionen Versuche von den weiteren 18 Millionen pro Zelle. Jede Gruppe von 16 Einträgen besteht aus unabhängigen synthetischen Binomialzählungen. Pro Szenario und Wiederholung nutzt die v0.5-Vergleichsregel die Summe beider Stufen, v0.6 die erste. **records/pilot.json** enthält GO/HOLD-Paarhäufigkeiten und einen SHA-256-Hash der beiden vollständigen Zählmatrizen je Szenario.
- **verify.py** und **records/verification.json** dokumentieren die Kontrollen. Bei 362 kleinen Vergleichsfällen wurde das gerichtete Binomialintervall gegen exakt summierte rationale Wahrscheinlichkeiten geprüft. Für beide großen Verteilungen wurde unabhängig SciPy benutzt. Alle 200 Varianzschranken wurden gegen eine zweite numerische Formel geprüft. Alle 480.000 Pilotentscheidungen wurden zusätzlich je Zeile mit ganzen Zahlen nachgezählt.
- **previous/** enthält die aus dem verifizierten v0.5-Paket übernommenen Parameter, Zertifikate, Beispielfelder, Herkunft und früheren Beweis. **reference/** enthält die benötigten historischen Geometrieregeln und Herkunftshinweise einschließlich Lizenzen. **FREEZE.sha256** fixiert Design, wissenschaftliche Implementierung, Verweis auf den Vorgänger und Pilotgenerator vor der Erhebung der neuen Simulationsdaten. **MANIFEST.sha256** deckt alle anderen Paketdateien ab. Der Freeze ist lokal und keine öffentliche Vorregistrierung.

## Reproduktion

Im entpackten Verzeichnis. Kalibrierentscheidung und numerisches Zertifikat benötigen nur Python 3. Für Pilot, unabhängige Kontrollen und Anwendung auf Geometriezähler werden NumPy und SciPy benötigt. Die im Lauf verwendeten Versionen stehen in **records/environment.json**.

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B budgets.py > /tmp/x6-v06-certificate.json
cmp records/certificate.json /tmp/x6-v06-certificate.json
python -B pilot.py score records/counts.npz > /tmp/x6-v06-score.json
cmp records/pilot.json /tmp/x6-v06-score.json
python -B pilot.py replay records/counts.npz > /tmp/x6-v06-replay.json
cmp records/pilot.json /tmp/x6-v06-replay.json
python -B verify.py > /tmp/x6-v06-verify.json
cmp records/verification.json /tmp/x6-v06-verify.json
```

## Anwendung auf ein Feldprotokoll

```sh
python -B calibrate.py examples/field_no_evidence.json
python -B calibrate.py examples/synthetic_go.json --count 1157840
```

Eine Kopie des Feldprotokolls ausfüllen. Einschlussbereich, C01 bis C16, Referenzpositionen, Zeitfenster, genaue Zahl der Versuche, Unabhängigkeit und einzige zu verwendende Route müssen vor der Messung feststehen. Unter **contrast_caps** stehen rationale Zeichenketten für S, D und C. Die zulässige Spanne für jeden Faktor ist 1 bis 1,0001. Unter **evidence** werden Verweise auf sechs vorab geprüfte Nachweise eingetragen. Sie betreffen die Erzeugungsdichte, die Schwankung innerhalb der Zellen, den Transfer zur Wissenschaft einschließlich Drift, die Abdeckung, die unabhängige Erfassung aller Versuche und die getrennte Wissenschaftsordnung mit vorab gewählter Route. Das Werkzeug prüft formale Angaben und Zählungen. Die Gültigkeit der externen Nachweise ist fachlich zu prüfen.

Für die relative Route muss jede Zelle exakt 47.000.000 markierte Versuche einschließlich Ausfällen enthalten. Ohne externe Belege ergibt sich HOLD_ASSUMPTIONS, bei nicht bestandener Zählprüfung HOLD_COUNTS. Beide Fälle liefern die volle Modellmenge. GO ohne Geometriezähler bedeutet, dass erst die Kalibrierung erfolgt ist. Mit dem optionalen v0.4-Zähler wird die Geometrie ausgewertet. Das Verfahren erlaubt weder nachträglichen Routenwechsel noch Wiederholung bis zum Bestehen. Das absolute Hoch-Effizienz-Protokoll aus v0.5 bleibt unter eigener Vorabwahl mit 23.162 Versuchen je Zelle anwendbar; dafür gelten die in previous/certificate.json archivierten eigenen Schranken.

## Simulationsfälle

| Szenario | Wahre Zellmittel | Einordnung |
|---|---|---|
| flat_50 | Alle 0,5 | Günstig |
| good_1_high, good_8_high, good_15_high | 1, 8 bzw. 15 Zellen mit 0,49 × 1,0002, übrige 0,49 | Günstig am Rand |
| boundary_pair | Zwei komplementäre Zellen mit Verhältnis L, übrige 0,5 | Grenze der hinreichenden Zellmittelbedingung |
| unsafe_pair | Zwei komplementäre Zellen mit Verhältnis 1,0021, übrige 0,5 | Bei zellkonstantem e und s=t=1 physikalisch oberhalb der Grenze |
| unsafe_one | Eine Zelle mit 0,49 × 1,0021, übrige 0,49 | Bei zellkonstantem e und s=t=1 physikalisch oberhalb der Grenze |
| low_safe | Alle 0,1 | Sicher bei s=t=1 und homogener Effizienz, außerhalb der günstigen Klasse |

Die Simulation bildet die Verteilung der hinreichenden Zählungen ab. Es wurden keine realen Geräteimpulse aufgenommen. Der Vergleich der Routenversionen ist eine gepaarte Belastungsprobe. Überdeckung und Fehlfreigabe folgen aus den analytischen Schranken.
