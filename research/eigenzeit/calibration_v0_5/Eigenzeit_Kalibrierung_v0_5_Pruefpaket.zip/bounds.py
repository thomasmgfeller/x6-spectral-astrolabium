"""Directed finite-sample certificate. No floating-point decisions or external packages."""
import json
from fractions import Fraction as F
from math import isqrt
from calibrate import DESIGN, ROOT, K, S, D, C, J, L, MARGIN

SCALE = 2**384
DISPLAY = 10**12


def ceil_div(a, b):
    return -(-a // b)


def decimals(x, upper):
    num = x.numerator * DISPLAY
    return F(ceil_div(num, x.denominator) if upper else num // x.denominator, DISPLAY)


def scaled(x):
    return x.numerator * SCALE // x.denominator, ceil_div(x.numerator * SCALE, x.denominator)


def product(a, b):
    return a[0] * b[0] // SCALE, ceil_div(a[1] * b[1], SCALE)


def power(x, n):
    base = scaled(x)
    result = (SCALE, SCALE)
    while n:
        if n % 2:
            result = product(result, base)
        base = product(base, base)
        n //= 2
    return result


def binom_le(n, c, q):
    """Interval for P[Bin(n,q)<=c] via the mass recurrence from zero."""
    lo, hi = power(1 - q, n)
    total_lo, total_hi = lo, hi
    odds = q / (1 - q)
    for k in range(c):
        a = (n - k) * odds.numerator
        b = (k + 1) * odds.denominator
        lo, hi = lo * a // b, ceil_div(hi * a, b)
        total_lo += lo
        total_hi += hi
    return F(total_lo, SCALE), F(total_hi, SCALE)


def exp_minus_upper(x):
    """A positive Taylor partial sum lower-bounds exp(x)."""
    term = total = F(1)
    for k in range(1, 89):
        term *= x / k
        total += term
    return 1 / total


def sqrt_bounds(x):
    n = isqrt((x.numerator * SCALE**2) // x.denominator)
    return F(n, SCALE), F(n + 1, SCALE)


def necessary():
    """Affinity obstruction for a homogeneous 50% detector and a single weak cell."""
    p = F(1, 2) / K
    a = F(1, 2) + sqrt_bounds(p * (1 - p))[0]
    g, b = 1 - F(DESIGN["good_hold_max"]), F(DESIGN["wrong_go_max"])
    cap = g*b + (1-g)*(1-b) + 2*sqrt_bounds(g*b*(1-g)*(1-b))[1]
    lo, hi = 0, 1
    while F(power(a, hi)[0], SCALE) > cap:
        hi *= 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if F(power(a, mid)[0], SCALE) > cap:
            lo = mid
        else:
            hi = mid
    return {"per_cell_at_least": hi, "all_cells_at_least": hi * J,
            "affinity2_lower": str(decimals(a, False)),
            "decision_affinity2_upper": str(decimals(cap, True)),
            "predecessor_power_lower": str(decimals(F(power(a, lo)[0], SCALE), False))}


def certificate():
    delta = F(DESIGN["wrong_go_max"])
    beta = F(DESIGN["good_hold_max"])
    cfg = DESIGN["absolute"]
    n, c = cfg["n"], cfg["max_losses"]
    q0, qg = 1 - S*D*C/K, 1 - F(cfg["p_good_min"])
    wrong = binom_le(n, c, q0)[1]
    abstain = J * (1 - binom_le(n, c, qg)[0])
    other = DESIGN["relative"]
    d = F(other["p_good_min"]) * (L - F(other["good_ratio_max"]))
    a = 2 * other["n"] / (1 + L**2)
    assert 0 < MARGIN < d
    relative_wrong = exp_minus_upper(a * MARGIN**2)
    relative_abstain = J*(J-1)*exp_minus_upper(a * (d-MARGIN)**2)
    prior = json.loads((ROOT / "reference/records/certificate.json").read_text())
    geom = prior["positive"][DESIGN["geometry"]["protocol"]]
    cov = F(geom["coverage_lower"])
    rate = min(F(k["correct_singleton_lower"]) for k in geom["grid"])
    results = {}
    for name, fp, hold in (("absolute", wrong, abstain), ("relative", relative_wrong, relative_abstain)):
        fp, hold = decimals(fp, True), decimals(hold, True)
        assert fp <= delta and hold <= beta
        results[name] = dict(attempts=J*DESIGN[name]["n"], wrong_go_upper=str(fp),
            good_hold_upper=str(hold), good_go_lower=str(1-hold),
            unconditional_coverage_lower=str(min(cov, 1-fp)),
            good_correct_singleton_lower=str(decimals(rate*(1-hold), False)))
    return {"p_threshold_absolute": str(1-q0), "ratio_threshold_relative": str(L),
            "routes": results, "lower_bound_at_half": necessary(),
            "v04_coverage_lower": str(cov), "v04_grid_correct_lower": str(rate),
            "max_good_hold_for_80pct": str(1-F(4,5)/rate)}


if __name__ == "__main__":
    print(json.dumps(certificate(), indent=2))
