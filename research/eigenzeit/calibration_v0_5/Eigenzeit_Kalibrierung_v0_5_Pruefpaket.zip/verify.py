"""Independent numerical, input, boundary, and end-to-end regression checks."""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import json
from math import comb, exp
from pathlib import Path
import sys
import numpy as np
from scipy.stats import binom
from calibrate import ROOT, DESIGN, J, K, S, C, D, L, MARGIN, check, apply, counts_pass, count_threshold
from bounds import binom_le, certificate
from pilot import score, scenarios


def exact_cdf(n, c, q):
    # Integer polynomial with a common denominator, independent of the directed recurrence.
    a, b = q.numerator, q.denominator-q.numerator
    num = b**(n-c) * sum(comb(n,k)*a**k*b**(c-k) for k in range(c+1))
    return num, q.denominator**n


def check_binom(n, c, q):
    lo, hi = binom_le(n, c, q)
    num, den = exact_cdf(n, c, q)
    assert num*lo.denominator >= den*lo.numerator and num*hi.denominator <= den*hi.numerator
    assert abs(float(lo)-binom.cdf(c,n,float(q))) < 1e-11


def invalid(call):
    try:
        call()
    except ValueError:
        return
    raise AssertionError("invalid input accepted")


def main():
    source = ROOT / "reference"
    prov = json.loads((source/"PROVENANCE.json").read_text())
    for path, sha in prov["files"].items():
        assert hashlib.sha256((source/path).read_bytes()).hexdigest() == sha
    certified = certificate()
    assert certified == json.loads((ROOT/"records/certificate.json").read_text())
    cfg = DESIGN["absolute"]
    n, c = cfg["n"], cfg["max_losses"]
    for nn, cc in [(7, 2), (n, c)]:
        for q in [1-S*D*C/K, 1-F(cfg["p_good_min"])]:
            check_binom(nn, cc, q)
    eg = lambda name: json.loads((ROOT/"examples"/(name+".json")).read_text())
    a = eg("synthetic_absolute_go")
    b = eg("synthetic_relative_go")
    field = eg("field_no_evidence")
    assert check(field)["status"] == "HOLD_ASSUMPTIONS"
    assert check(a)["mode"] == check(b)["mode"] == "synthetic"
    assert check(a)["status"] == check(b)["status"] == "GO"
    for bad in [n+1, -1, True, 1.25, "4"]:
        invalid(lambda: counts_pass("absolute", [bad]+[n]*15))
    for kind in ["duplicate", "short", "attempts", "bool", "key"]:
        r = deepcopy(a)
        if kind == "duplicate": r["cells"][1]["id"] = r["cells"][0]["id"]
        if kind == "short": r["cells"].pop()
        if kind == "attempts": r["cells"][0]["attempted"] += 1
        if kind == "bool": r["cells"][0]["attempted"] = True
        if kind == "key": r["cells"][0].pop("detected")
        invalid(lambda: check(r))
    r = deepcopy(a)
    r["contrast_caps"]["S"] = "1001/1000"
    assert check(r)["status"] == "HOLD_ASSUMPTIONS"
    r = deepcopy(a)
    r["cells"][0]["detected"] = n-c-1
    abstain = apply(r, 1157840)
    assert abstain["status"] == "HOLD_COUNTS" and abstain["geometry"] == check(field)["geometry"]
    assert counts_pass("absolute", [n-c]*J)
    m = DESIGN["relative"]["n"]//2
    bound = count_threshold(m)
    assert counts_pass("relative", [m]*(J-1)+[bound])
    assert not counts_pass("relative", [m]*(J-1)+[bound+1])
    result = apply(a, 1157840)
    original = json.loads((source/"pilot/decisions.json").read_text())[0]
    assert result["geometry"] == {k:original[k] for k in ("grid","h_interval","q_interval")}
    from robust import certify
    previous = json.loads((source/"records/certificate.json").read_text())
    assert json.loads(json.dumps(certify("contrast_0_2"))) == previous["positive"]["contrast_0_2"]
    d = F(DESIGN["relative"]["p_good_min"])*(L-F(DESIGN["relative"]["good_ratio_max"]))
    nr = DESIGN["relative"]["n"]
    ref = [exp(float(-2*nr*MARGIN**2/(1+L**2))), J*(J-1)*exp(float(-2*nr*(d-MARGIN)**2/(1+L**2)))]
    for key, val in zip(("wrong_go_upper","good_hold_upper"),ref):
        enclosure = float(F(certified["routes"]["relative"][key]))
        assert -1e-15 < enclosure-val < 1.01e-12
    with np.load(ROOT/"records/counts.npz",allow_pickle=False) as arrays:
        audit = score(arrays)
        assert audit == json.loads((ROOT/"records/pilot.json").read_text())
        for name, (route, probabilities) in scenarios().items():
            arr = arrays[name]
            for row in arr[::250]:
                vals = [int(k) for k in row]
                if route == "relative":
                    independent = F(max(vals),nr)-L*F(min(vals),nr) <= -MARGIN
                else:
                    independent = all(n-v <= c for v in vals)
                assert counts_pass(route,vals) == independent
            if route == "absolute":
                prob = np.prod([binom.cdf(c, n, 1-p) for p in probabilities])
                reps = len(arr)
                assert abs(audit[name]["count_pass"]-reps*prob) <= 6*(reps*prob*(1-prob))**.5+1
        assert np.array_equal(arrays["rel_half_uniform"],arrays["rel_hidden_subcells"])
    return {"result":"PASS", "field_without_evidence":check(field), "synthetic_geometry_example":result,
            "v04_primary_recomputed":True, "large_binomials_exact_integer_crosscheck":2,
            "relative_rule_boundary_checked":True,"pilot_scalar_rule_checks":8*80,
            "independent_absolute_operating_curve_checks":4,"source_files_verified":len(prov["files"])}


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
