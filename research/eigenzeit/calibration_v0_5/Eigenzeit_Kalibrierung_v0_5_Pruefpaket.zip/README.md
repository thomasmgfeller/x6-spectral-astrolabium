# Eigenzeit v0.5 · Eine unabhängige Prüfung der Beprobungsdichte

Für das publizierte v0.4-Verfahren mit 3.200.000 Ereignissen musste das Verhältnis K der höchsten zur niedrigsten wissenschaftlichen Beprobungsdichte pro physischem Vierervolumen auf 1,002 begrenzt sein. Hier wird eine vorgeschaltete Referenzmessung entworfen. Zwei vorab wählbare Kalibrierungen haben jeweils höchstens 1 % Fehlfreigabe, falls K tatsächlich größer ist und die externen Modellzusagen stimmen. Der physikalische Feldstatus ohne Messungen und Belege ist **HOLD**.

## Was im Paket steht

- **Bericht.pdf** enthält die Messpläne, eine Annahmekurve und das Gegenbeispiel mit identischen Zellzählungen.
- **BEWEIS.md** leitet die Entscheidungsregeln, die gemeinsame Fehlergrenze, die notwendige Probezahl bei mittlerer Effizienz sowie die Grenzen endlicher Kalibrierung her.
- **design.json**, **calibrate.py** und **bounds.py** implementieren das Design, die Messregeln und das gerichtete Zertifikat. **verify.py** prüft unabhängig beide zentralen Binomialsummen, rekonstruiert das v0.4-Zertifikat und kontrolliert Eingaben, Grenzwerte, ein Geometriebeispiel und die Pilotdaten.
- **examples/field_no_evidence.json** ist das leere Feldprotokoll. Die beiden weiteren Protokolle in examples/ sind ausdrücklich synthetische Eingabe- und Grenzfälle.
- **records/certificate.json** nennt die gerichteten Schranken als exakte rationale Zahlen. **records/counts.npz** enthält pro Szenario eine 20.000 × 16-Matrix, je Eintrag die Anzahl erkannter Signale bei der festen Versuchszahl der Route. Datentyp ist uint32, little-endian. Es werden hinreichende Binomialzählungen simuliert. Es liegen keine individuellen realen Detektorsignale vor.
- **records/pilot.json** enthält alle Ergebnisse der Zählregeln und die SHA-256-Prüfsumme der unkomprimierten Matrix je Szenario. Die Unterzellen-Gegenkontrolle verwendet definitionsgemäß dieselben Zähler wie der über jede Zelle homogene Referenzfall. Es gibt sieben eigenständig simulierte Szenarien und eine gekoppelte achte Gegenkontrolle. **records/verification.json** und **records/environment.json** protokollieren die Prüfung und die verwendeten Softwareversionen.
- **reference/** enthält die aus dem geprüften v0.4-Archiv übernommenen Quellen für Geometrieauswertung und Zertifikat, das damalige Protokoll sowie die historischen Lizenz- und Herkunftsnachweise. **reference/PROVENANCE.json** nennt den v0.4-Merge, den Hash des vollständigen Quellarchivs und die Hashes aller übernommenen Dateien.
- **FREEZE.sha256** dokumentiert den lokalen Stand der wissenschaftlichen Regeln und des Simulationsgenerators vor dem Pilotlauf. Die unabhängigen Kontrollen wurden nach dem Lauf vervollständigt. **MANIFEST.sha256** umfasst alle übrigen Paketdateien. Der lokale Freeze ist keine öffentliche Vorregistrierung.

## Anwendung

Python 3 genügt für die Kalibrierung und ihr Zertifikat. Die vollständige Reproduktion einschließlich Geometrie und Pilot benötigt NumPy und SciPy. Im Paketverzeichnis ausführen.

```sh
python -B calibrate.py examples/field_no_evidence.json
python -B calibrate.py examples/synthetic_absolute_go.json --count 1157840
python -B calibrate.py examples/synthetic_relative_go.json
```

Vor der Erhebung genau eine Route wählen. Extern die Partition C01 bis C16 über den gesamten Diamanten festlegen, die tatsächlichen Messzellen eindeutig zuordnen und Referenzverteilung, Zeitraum, Signaldefinition und Auswahl dokumentieren. Die Referenz muss auch jeden nicht erkannten Versuch im Nenner erfassen. Für die absolute Route sind je Zelle genau 23.162, für die relative genau 65.000.000 Versuche vorgesehen. Es gibt keine datenabhängige Wahl der Route, kein nachträgliches Aussortieren von Zellen und kein wiederholtes Probieren innerhalb dieses Designs.

Eine Kopie des Feldprotokolls ausfüllen. Die Werte S, D, C unter **contrast_caps** sind rationale Zeichenketten (z. B. "10001/10000"); sie müssen jeweils mindestens 1 und höchstens 1,0001 sein. Die sechs Felder unter **evidence** sollen auf vorab fachlich geprüfte, für den Versuch gültige Nachweise verweisen. Ein Verweis bestätigt dem Programm die externe Prüfung. Das Programm kann weder die physikalische Richtigkeit noch die zeitliche Gültigkeit selbst prüfen.

| Feld | Was der Nachweis abdecken muss |
|---|---|
| source_contrast | Erzeugungsrate der wissenschaftlichen Ereignisse relativ zum physischen Vierervolumen, K(s)≤S |
| within_cell_envelope | Lokaler Effizienzkontrast ≤C in jeder vollständigen Zelle für Referenz und Wissenschaft |
| calibration_transfer | Kontrast der Änderung von Referenz zur Wissenschaft einschließlich Drift ≤D |
| partition_and_probe_support | Gesamte Messdomäne, Zellgrenzen, externer Ortsbezug und anwendbare Referenzverteilungen |
| fixed_independent_trials_and_all_attempts | Feste Anzahl, unabhängige Bernoulli-Versuche und Erfassung aller Versuche einschließlich Ausfällen |
| independent_geometry_and_preselected_route | Unabhängige Kausalordnung und Gruppierung, feste Messbedingungen und vor Beobachtung gewählte einzige Route |

Die maschinenlesbaren Status sind GO, HOLD_COUNTS und HOLD_ASSUMPTIONS. Ungültige oder doppelte Zellen und falsche Budgets werden bei ansonsten qualifizierten Eingaben abgelehnt (CLI-Exitcode 2). Bei HOLD wird der gesamte Modellbereich ausgegeben. GO ohne übergebenen v0.4-Zähler gibt geometry=null zurück. Die beiden synthetischen Beispiele werden im Ergebnis weiterhin als synthetisch gekennzeichnet.

Für eine echte Ordnung entsteht der Geometriezähler aus 400.000 unabhängig zugeteilten disjunkten Achtergruppen mit allen jeweils 28 Vergleichbarkeitsabfragen. Die unveränderte v0.4-Implementierung steht in reference/apply_order.py (apply_oracle). Das Beispiel mit Zähler 1.157.840 ist der archivierte Simulationsfall 0 aus v0.4.

## Vollständige Reproduktion

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B bounds.py > /tmp/x6-v05-certificate.json
cmp records/certificate.json /tmp/x6-v05-certificate.json
python -B pilot.py score records/counts.npz > /tmp/x6-v05-score.json
cmp records/pilot.json /tmp/x6-v05-score.json
python -B pilot.py replay records/counts.npz > /tmp/x6-v05-replay.json
cmp records/pilot.json /tmp/x6-v05-replay.json
python -B verify.py > /tmp/x6-v05-verification.json
cmp records/verification.json /tmp/x6-v05-verification.json
```

Die acht Szenarien hatten je 20.000 Wiederholungen. Die reine Zählregel bestand in der Reihenfolge des Designs 19.939, 207, 6, 0, 20.000, 20.000, 0 und 20.000 Mal. Der zweite Fall stresst die hinreichende Einzelzellenschwelle; er bezeichnet keine Überschreitung des physikalischen K bei konstanten übrigen Faktoren. Im letzten Fall sind die Unterzellen-Effizienzen 1/4 und 3/4. Die externe C-Annahme ist verletzt. Der gekoppelten Zählprüfung fehlt die Information, um dies zu erkennen. Bei ungeklärtem C gibt die vollständige Feldregel HOLD aus. Alle mathematischen Wahrscheinlichkeiten und Untergrenzen stammen aus der Herleitung, unabhängig von den zufälligen Pilotquoten.
