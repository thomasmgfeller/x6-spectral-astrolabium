"""Generate and independently score prespecified tagged-count experiments."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from calibrate import DESIGN, ROOT, K, S, D, C, J, count_threshold

SETUP = DESIGN["simulation"]


def scenarios():
    q = float(S*D*C/K)
    return {"abs_high_good": ("absolute", [.9995]*J),
            "abs_one_at_threshold": ("absolute", [q]+[1.]*(J-1)),
            "abs_one_unsafe": ("absolute", [.9979]+[1.]*(J-1)),
            "abs_half_uniform": ("absolute", [.5]*J),
            "rel_half_uniform": ("relative", [.5]*J),
            "rel_good_edge": ("relative", [.49]+[.49*1.0002]*(J-1)),
            "rel_unsafe": ("relative", [.5/1.0021]+[.5]*(J-1)),
            "rel_hidden_subcells": ("relative", [.5]*J)}


def draw():
    output = {}
    for i, name in enumerate(SETUP["cases"]):
        route, p = scenarios()[name]
        if name == "rel_hidden_subcells":
            # Exact coupling of cell-count laws. This case violates the declared internal envelope.
            output[name] = output["rel_half_uniform"].copy()
            continue
        rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([SETUP["seed"], i])))
        output[name] = rng.binomial(DESIGN[route]["n"], p,
                        size=(SETUP["repetitions"], J)).astype("<u4")
    return output


def score(arrays):
    if set(arrays) != set(SETUP["cases"]):
        raise ValueError("incomplete set of pilot arrays")
    result = {}
    for name in SETUP["cases"]:
        route, p = scenarios()[name]
        a = arrays[name]
        n = DESIGN[route]["n"]
        if a.shape != (SETUP["repetitions"], J) or a.dtype != np.dtype("<u4") or a.max() > n:
            raise ValueError("unexpected count file")
        low, high = a.min(axis=1), a.max(axis=1)
        if route == "absolute":
            go = low >= n - DESIGN[route]["max_losses"]
        else:
            # Use exact integer/Fraction thresholds, cached for each observed minimum.
            distinct, inverse = np.unique(low, return_inverse=True)
            thresholds = np.asarray([count_threshold(int(k)) for k in distinct])
            go = high <= thresholds[inverse]
        result[name] = dict(design=route, repetitions=len(a), count_pass=int(go.sum()),
                            count_hold=int(len(a)-go.sum()),
                            p_min=min(p), p_max=max(p),
                            raw_sha256=hashlib.sha256(a.tobytes(order="C")).hexdigest())
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=("generate", "score", "replay"))
    p.add_argument("file", type=Path)
    args = p.parse_args()
    if args.mode == "generate":
        np.savez_compressed(args.file, **draw())
    else:
        with np.load(args.file, allow_pickle=False) as data:
            if args.mode == "replay":
                replay = draw()
                assert set(replay) == set(data)
                for name, a in replay.items():
                    assert np.array_equal(a, data[name]), name
            print(json.dumps(score(data), indent=2))
