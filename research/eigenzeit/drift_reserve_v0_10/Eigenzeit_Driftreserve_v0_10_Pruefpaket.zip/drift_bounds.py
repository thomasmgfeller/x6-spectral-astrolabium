"""Outward finite-sample bounds using independent bounding counts for predictable residuals."""
from fractions import Fraction as F
import json
from drift_rule import ROOT,D,L,J,A,B,EPS,P,R,G,NS,CLEAR,HOLD,SCALE,schedule,prior
import bounds_three as oldb
from sequential_bounds import tail,rounded

SPLIT=F(59,100)


def pair_tail(n,u):
    # A smaller positive gap contains the event at the requested gap.
    return tail(n,F((u*10**12).__floor__(),10**12))


def triplet(n,net,m):
    # net = bias + clearance, or bias minus HOLD threshold.
    d=A*m*(L-1);w=A*m*(R-1)
    return [pair_tail(n,d-w-net),pair_tail(n,d-w/2-net),pair_tail(n,d-net)]


def unions(n,net,m):
    a,b,c=triplet(n,net,m);pair=[];cell=[]
    for k in range(J+1):
        l=J-k
        pair.append(k*l*(a+c)+(k*(k-1)+l*(l-1))*b)
        hi=min(1,2*(k-1)*b+l*(a+c)) if k else 0
        lo=min(1,2*(l-1)*b+k*(a+c)) if l else 0
        cell.append(k*hi+l*lo)
    return min(1,max(pair)),max(cell)


def endpoints(n,t):
    offset=(1+L)*EPS+t
    offsets=oldb.OFFSETS;by_k=[]
    assert A*P-EPS>=F(48,100) and B*SPLIT*R+EPS<=F(60,100)
    for k in range(J+1):
        total=F(0)
        for group,size in enumerate((J-k,k)):
            if not size:continue
            nlo=J-k-(group==0);nhi=k-(group==1)
            vals=[]
            for sub in range(4):
                al=offsets[group]+sub*(R-1)/8;ah=al+(R-1)/8
                out=[A*P*(L-1+L*v-ah)-offset for v in offsets[:2]]
                inc=[A*P*(L-1+L*al-v)-offset for v in offsets[1:]]
                assert min(out+inc)>0
                po=oldb.integrated(n,*out,F(1),L,nlo,nhi)
                pi=oldb.integrated(n,*inc,L,F(1),nlo,nhi)
                vals.append(min(1,po+pi))
            total+=size*max(vals)
        by_k.append(total)
    high=unions(n,offset,SPLIT)[1];simple=unions(n,offset,P)[1]
    return min(simple,max(high,max(by_k))),dict(near_by_k=list(map(str,by_k)),high=str(high),simple=str(simple))


def risks(ns,ts,hs,eps):
    bias=(1+L)*eps
    false=[pair_tail(n,t-bias) for n,t in zip(ns,ts)]
    holds=[unions(n,bias-h,P)[0] for n,h in zip(ns,hs)]+[unions(ns[-1],bias+ts[-1],P)[0]]
    return false,holds


def worlds(epsilon):
    # Same observed law at every stage in a good and an unsafe target world.
    lo=P-2*epsilon/A;hi=P*R+2*epsilon/A
    eta=F(1,1000);C=prior.old.baseline.prior.C
    physical=prior.old.baseline.prior.S*prior.old.baseline.prior.D*C**2*hi/lo*(1-eta*(1-1/C))/(1+eta*(C-1))
    qlo=A*P-epsilon;qhi=A*P*R+epsilon
    assert qlo==A*lo+epsilon and qhi==A*hi-epsilon
    return dict(epsilon=str(epsilon),good_target_low=str(P),good_target_high=str(P*R),bad_target_low=str(lo),
                bad_target_high=str(hi),observed_low=str(qlo),observed_high=str(qhi),rare_mass=str(eta),bad_physical_contrast=str(physical))


def certificate():
    prev=json.loads((ROOT/'previous/records/certificate.json').read_text())
    geom=json.loads((ROOT/'previous/previous/previous/previous/previous/certificate.json').read_text())
    rows=[]
    for ppm in D['sensitivity_ppm']:
        eps=F(ppm,10**6);ns,ts,hs,scale=schedule(eps);f,h=risks(ns,ts,hs,eps)
        assert sum(f)<=F(prev['false_go_upper']) and sum(h)<=F(prev['good_hold_upper'])
        rows.append(dict(ppm=ppm,ns=ns,factor=str(scale),false_go_upper=str(sum(f)),good_hold_upper=str(sum(h)),cap=J*ns[-1]))
    f,h=risks(NS,CLEAR,HOLD,EPS)
    x,c1=endpoints(NS[0],CLEAR[0]);y,c2=endpoints(NS[1],CLEAR[1])
    cost=J*NS[0]+(NS[1]-NS[0])*x+(NS[2]-NS[1])*min(x,y)
    nfp,nh=risks(prior.NS,prior.CLEAR,prior.HOLD,EPS)
    critical=A*G/(2*(1+L));w=worlds(F(180,10**6));assert F(w['bad_physical_contrast'])>prior.old.baseline.prior.K
    return dict(id=D['id'],critical_epsilon=str(critical),primary_epsilon=str(EPS),primary_bias=str((1+L)*EPS),
                primary_scale=str(SCALE),primary_ns=NS,clear_margins=list(map(str,CLEAR)),hold_thresholds=list(map(str,HOLD)),
                false_go_terms=list(map(str,f)),good_hold_terms=list(map(str,h)),false_go_upper=str(sum(f)),good_hold_upper=str(sum(h)),
                coverage_lower=str(min(F(geom['v04_coverage_lower']),1-sum(f))),
                good_singleton_lower=str(rounded((1-sum(h))*F(geom['v04_grid_correct_lower']),upper=False)),
                min_trials=J*NS[0],max_trials=J*NS[-1],good_expected_trials_upper=cost.__ceil__(),active_upper=list(map(str,[x,y])),
                endpoint_details=[c1,c2],nominal_v09_under_envelope_false_upper=str(sum(nfp)),
                nominal_v09_under_envelope_good_hold_upper=str(sum(nh)),sensitivity=rows,identical_worlds=w)


if __name__=='__main__':print(json.dumps(certificate(),indent=2))
