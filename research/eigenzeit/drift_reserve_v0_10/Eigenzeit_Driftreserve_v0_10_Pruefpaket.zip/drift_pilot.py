"""Paired drift stress test. Archive encoding stores exact uint32 counts around integer offsets."""
import argparse,hashlib,io,json,os
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from drift_rule import ROOT,D,L,J,NS,CLEAR,HOLD,A,EPS,P,R,prior
import trial as baseline_trial
from drift_bounds import worlds
from budgets import binomial_cdf

PLAN=D['pilot'];BLOCKS=PLAN['nested_blocks']
NOMINAL=(0,2,4);ROBUST=(1,3,5)
assert np.cumsum(BLOCKS)[list(NOMINAL)].tolist()==prior.NS and np.cumsum(BLOCKS)[list(ROBUST)].tolist()==NS
STABLE=[F(1)]*6
ALTERNATING=list(map(F,['.99','1.01','.99','1.01','.99','1.01']))


def profile(name):
    p=[F(1,2)]*J;g=STABLE;signs=[0]*J;eps=EPS
    if name=='good_widen':
        p=[P*R]*8+[P]*8;g=ALTERNATING;signs=[1]*8+[-1]*8
    if name in ('unsafe_mask','sign_change'):
        ratio=L*F(100001,100000)
        p=[ratio/(1+ratio),1/(1+ratio)]+p[2:]
        g=[A]*6 if name=='unsafe_mask' else ALTERNATING
        signs=[-1,1]+[0]*14
    if name=='gain_only':
        p=[P*R]*8+[P]*8;g=ALTERNATING
    if name=='low_eff':
        p=[F(1,10)]*J;g=ALTERNATING
    if name.startswith('alias_'):
        eps=F(180,10**6);w=worlds(eps);good=name=='alias_good_180'
        p=[F(w[('good' if good else 'bad')+'_target_high']),F(w[('good' if good else 'bad')+'_target_low'])]+[P]*14
        signs=([1,-1] if good else [-1,1])+[0]*14;g=[A]*6
    if name not in PLAN['cases']:raise ValueError(name)
    return p,g,signs,eps


def observed(name,j):
    p,g,s,e=profile(name)
    return [g[j]*v+sg*e for v,sg in zip(p,s)]


def generate(name,reps,seed):
    mats=[];p,g,s,eps=profile(name);flip=None
    for j,n in enumerate(BLOCKS):
        q=observed(name,j)
        probs=np.array([float(v) for v in q])
        if name=='sign_change' and j:
            # Predictable after the first 22 million: each run uses one of two residual directions.
            opposite=np.array([float(g[j]*v-sg*eps) for v,sg in zip(p,s)])
            probs=np.where(flip[:,None],opposite[None,:],probs[None,:])
        rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence([*seed,j])))
        mat=rng.binomial(n,probs,(reps,J)).astype('<u4')
        if name=='sign_change' and j==0:flip=mat[:,0]>=int(n*q[0])
        mats.append(mat)
    return np.stack(mats)


def unique_cases():
    return [s for s in PLAN['cases'] if s!='alias_bad_180']


def offsets(name):
    return np.array([[int(n*x) for x in observed(name,j)] for j,n in enumerate(BLOCKS)],dtype=np.int64)[:,None,:]


def encoded_draw():
    result={}
    for i,name in enumerate(unique_cases()):
        raw=generate(name,PLAN['repetitions'],[PLAN['seed'],i])
        centered=raw.astype(np.int64)-offsets(name)
        assert centered.min()>=-32768 and centered.max()<=32767
        result[name]=centered.astype('<i2')
    return result


def decode(arrays,name):
    key='alias_good_180' if name=='alias_bad_180' else name
    packed=arrays[key]
    if packed.shape!=(6,PLAN['repetitions'],J) or packed.dtype!=np.dtype('<i2'):raise ValueError('invalid raw record')
    a=packed.astype(np.int64)+offsets(name)
    if any(a[j].min()<0 or a[j].max()>n for j,n in enumerate(BLOCKS)):raise ValueError('invalid count')
    return a.astype('<u4')


def decisions(cum,indices,ns,clear,hold):
    reps=len(cum[0]);edges=np.ones((reps,J,J),dtype=bool)
    edges[:,np.arange(J),np.arange(J)]=False
    go=np.zeros(reps,dtype=bool);used=np.zeros(reps,dtype=np.int64);counts=[]
    for k,idx in enumerate(indices):
        used+=baseline_trial.cells(edges)*(ns[k]-(ns[k-1] if k else 0))
        prev=baseline_trial.any_edge(edges)
        early=(baseline_trial.any_edge(edges&baseline_trial.bad_pairs(cum[idx],ns[k],hold[k])) if k<2 else np.zeros(reps,dtype=bool))
        edges &= baseline_trial.previous_trial.relations(cum[idx],ns[k],clear[k])
        edges[early]=False
        opened=baseline_trial.any_edge(edges)
        cleared=prev&~early&~opened
        go|=cleared
        counts.append(dict(go=int(cleared.sum()),hold=int((early|(opened if k==2 else False)).sum())))
    return go,used,counts


def paired(raw):
    cum=np.cumsum(raw,axis=0,dtype=np.uint32)
    x,xc,xs=decisions(cum,NOMINAL,prior.NS,prior.CLEAR,prior.HOLD)
    y,yc,ys=decisions(cum,ROBUST,NS,CLEAR,HOLD)
    return dict(repetitions=len(x),nominal_go=int(x.sum()),robust_go=int(y.sum()),only_nominal=int((x&~y).sum()),
                only_robust=int((y&~x).sum()),nominal_stages=xs,robust_stages=ys,
                mean_trials_nominal=str(F(int(xc.sum()),len(x))),mean_trials_robust=str(F(int(yc.sum()),len(y))),
                raw_counts_sha256=hashlib.sha256(raw.tobytes()).hexdigest())


def score(arrays):
    if set(arrays)!=set(unique_cases()):raise ValueError('wrong cases')
    return {s:paired(decode(arrays,s)) for s in PLAN['cases']}


def focus():
    # Prespecified one-sided test of p<=1% for the unadjusted v0.9 rule on one unsafe profile.
    runs=[];n=PLAN['focus_batch_size']
    for i in range(PLAN['focus_batches']):
        raw=generate('unsafe_mask',n,[PLAN['focus_seed'],i])
        runs.append(paired(raw))
    k=sum(r['nominal_go'] for r in runs);m=n*len(runs)
    lo,hi=binomial_cdf(m,F(1,100),k-1,m)
    up=F(((1-lo)*10**15).__ceil__(),10**15)
    return dict(name='unsafe_mask',n=m,nominal_go=k,robust_go=sum(r['robust_go'] for r in runs),
                nominal_test_threshold='1/100',one_sided_p_upper=str(up),alpha=PLAN['focus_alpha'],
                reject_nominal_rate_at_most_one_percent=up<F(PLAN['focus_alpha']),batches=runs)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['generate','score','replay','focus']);parser.add_argument('file',type=Path,nargs='?')
    args=parser.parse_args()
    if args.mode=='focus':print(json.dumps(focus(),indent=2))
    elif args.file is None:parser.error('archive path required')
    elif args.mode=='generate':
        b=io.BytesIO();np.savez_compressed(b,**encoded_draw());tmp=args.file.with_suffix('.tmp')
        tmp.write_bytes(b.getvalue());os.replace(tmp,args.file)
    else:
        with np.load(args.file,allow_pickle=False) as data:
            if args.mode=='replay':
                for name,v in encoded_draw().items():
                    if not np.array_equal(data[name],v):raise ValueError('seed replay mismatch: '+name)
            print(json.dumps(score(data),indent=2))
