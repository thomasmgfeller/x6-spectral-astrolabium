"""Anchor-robust three-look classifier, conditional on independently supported drift bounds."""
import argparse,json,sys
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'previous'))
import three_look as prior
old=prior.old

D=json.loads((ROOT/'design.json').read_text())
J,L,IDS=old.J,old.L,old.IDS
A,B,EPS=(F(D[k]) for k in ('gain_floor','gain_ceiling','absolute_cell_error'))
P,R=F('0.49'),F('1.0002')
G=P*(L-R)


def schedule(epsilon):
    bias=(1+L)*epsilon
    scale=A-2*bias/G
    if epsilon<0 or scale<=0:raise ValueError('no positive separation for this schedule')
    ns=[1000000*(F(n,1000000)/scale**2).__ceil__() for n in prior.NS]
    return ns,[scale*t+bias for t in prior.CLEAR],[scale*h-bias for h in prior.HOLD],scale


NS,CLEAR,HOLD,SCALE=schedule(EPS)
INCREMENTS=[b-a for a,b in zip([0]+NS,NS)]
EVIDENCE=['fresh_trial_randomness_and_all_attempts' if k=='independent_stage_trials_and_all_attempts' else k for k in prior.EVIDENCE]+D['additional_evidence']
PAIRS=tuple((i,j) for i in range(J) for j in range(J) if i!=j)


def endpoints(pairs):
    return sorted({v for e in pairs for v in e})


def step(counts,pairs,look):
    n=NS[look-1]
    if look<3 and any(counts[i]>=L*counts[j]+n*HOLD[look-1] for i,j in pairs):
        return 'HOLD_COUNTS',()
    unresolved=tuple((i,j) for i,j in pairs if counts[i]>L*counts[j]-n*CLEAR[look-1])
    if not unresolved:
        return 'GO',()
    return ('CONTINUE',unresolved) if look<3 else ('HOLD_COUNTS',())


def evaluate(packet,science_count=None):
    if not isinstance(packet,dict) or packet.get('design_id')!=D['id'] or packet.get('route')!=D['route']:
        raise ValueError('unknown design or route')
    stages=packet.get('stages'); mode=packet.get('mode')
    evidence,caps=packet.get('evidence'),packet.get('contrast_caps')
    if mode not in ('field','synthetic') or not isinstance(stages,list) or len(stages)>3:
        raise ValueError('invalid mode or stage count')
    if not isinstance(evidence,dict) or not isinstance(caps,dict):
        raise ValueError('expected evidence and contrast caps')
    missing=[k for k in EVIDENCE if not isinstance(evidence.get(k),str) or not evidence[k].strip()]
    for k in ('S','D','C'):
        if not isinstance(caps.get(k),str) or not 1<=F(caps[k])<=F(old.baseline.prior.DESIGN[k]):
            missing.append(k)
    drift=packet.get('drift_caps',{})
    if not isinstance(drift,dict):raise ValueError('expected drift caps object')
    try:
        lo,hi,eps=(F(drift[k]) if isinstance(drift.get(k),str) else None for k in ('gain_floor','gain_ceiling','absolute_cell_error'))
    except (ValueError,ZeroDivisionError) as e:
        raise ValueError('drift caps must be rational strings') from e
    if lo is None or hi is None or not A<=lo<=hi<=B:missing.append('common_gain_bounds')
    if eps is None or not 0<=eps<=EPS:missing.append('absolute_cell_error')
    result=dict(mode=mode,status='AWAIT_FIRST_LOOK',look=None,evaluated_attempts=0,geometry=None)
    if missing:
        return dict(result,status='HOLD_ASSUMPTIONS',missing_or_ineligible=missing,geometry=old.baseline.prior.full_family())
    pairs=PAIRS;active=list(range(J));counts=[0]*J
    for look,stage in enumerate(stages,1):
        if not active:
            raise ValueError('additional observations after terminal decision')
        inc=old.read_stage(stage,look,active,INCREMENTS[look-1])
        for i,x in inc.items():counts[i]+=x
        result['evaluated_attempts']+=len(active)*INCREMENTS[look-1]
        status,pairs=step(counts,pairs,look)
        active=endpoints(pairs)
        result.update(status=status,look=look)
    if result['status'] in ('AWAIT_FIRST_LOOK','CONTINUE'):
        if science_count is not None:raise ValueError('calibration pending')
        result['next_cells']=[IDS[i] for i in active]
        result['next_attempts_per_required_cell']=INCREMENTS[len(stages)]
        if stages:result['unresolved_pairs']=[[IDS[i],IDS[j]] for i,j in pairs]
    elif result['status']=='HOLD_COUNTS':
        result['geometry']=old.baseline.prior.full_family()
    elif science_count is not None:
        sys.path.insert(0,str(old.baseline.prior.ROOT/'reference'))
        from robust import infer
        result['geometry']=infer(old.baseline.prior.DESIGN['geometry']['protocol'],science_count)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('packet',type=Path);p.add_argument('--count',type=int)
    args=p.parse_args()
    try:print(json.dumps(evaluate(json.loads(args.packet.read_text()),args.count),indent=2))
    except (ValueError,TypeError,KeyError,ZeroDivisionError) as e:p.exit(2,f'Invalid input: {e}\n')
