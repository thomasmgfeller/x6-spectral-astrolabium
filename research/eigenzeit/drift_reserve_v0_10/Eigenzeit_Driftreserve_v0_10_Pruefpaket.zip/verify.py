"""Independent arithmetic, adaptive coupling and scalar checks for the drift model."""
import hashlib,json,math
from copy import deepcopy
from fractions import Fraction as F
from itertools import product
from math import ceil,lcm,sqrt,exp,pi
import numpy as np
from scipy.stats import binom,beta
from drift_rule import ROOT,D,J,L,NS,INCREMENTS,CLEAR,HOLD,SCALE,A,B,EPS,P,R,G,IDS,evaluate,prior
from drift_pilot import PLAN,NOMINAL,ROBUST,decode,unique_cases,observed,profile


def coeff(n,t):
    den=lcm(L.denominator,t.denominator);return den,int(den*L),int(den*n*t)


def single(mats,ns,cc,hh):
    edges=[(i,j) for i in range(J) for j in range(J) if i!=j];used=0
    for k,row in enumerate(mats):
        used+=len({i for e in edges for i in e})*(ns[k]-(ns[k-1] if k else 0))
        d,a,b=cc[k];cap=[(a*x-b)//d for x in row]
        if k<2:
            d,a,b=hh[k];h=[-(-(a*x+b)//d) for x in row]
            if any(row[i]>=h[j] for i,j in edges):return False,used,k
        edges=[(i,j) for i,j in edges if row[i]>cap[j]]
        if not edges:return True,used,k
    return False,used,2


def audit(raw,r):
    total=[0,0];gg=[0,0];only=[0,0];hist=[[[0,0] for _ in range(3)] for _ in range(2)]
    configs=[]
    for idx,ns,ts,hs in [(NOMINAL,prior.NS,prior.CLEAR,prior.HOLD),(ROBUST,NS,CLEAR,HOLD)]:
        configs.append((idx,ns,[coeff(n,t) for n,t in zip(ns,ts)],[coeff(n,s) for n,s in zip(ns,hs)]))
    cum=raw.cumsum(axis=0,dtype=np.uint32)
    for z in range(len(raw[0])):
        bits=[]
        for i,(ix,ns,co,h) in enumerate(configs):
            g,n,step=single([cum[j,z].tolist() for j in ix],ns,co,h)
            gg[i]+=g;total[i]+=n;hist[i][step][int(not g)]+=1;bits.append(g)
        only[0]+=bits[0] and not bits[1];only[1]+=bits[1] and not bits[0]
    assert gg==[r['nominal_go'],r['robust_go']] and only==[r['only_nominal'],r['only_robust']]
    for j,key in enumerate(('nominal','robust')):
        assert F(total[j],len(raw[0]))==F(r['mean_trials_'+key])
        assert r[key+'_stages']==[dict(go=x,hold=y) for x,y in hist[j]]
    assert hashlib.sha256(raw.tobytes()).hexdigest()==r['raw_counts_sha256']


def tiny_coupling():
    # Three paired opportunities, 8 equiprobable uniforms per individual observation.
    # Residuals react to previous observations, including the first cell of the current pair.
    npaths=0;inequalities=0;nonzero_shift=False
    for u in product(range(8),repeat=6):
        x=y=lx=ly=hx=hy=0
        for j,center in enumerate((4,3,5)):
            l,h=center-1,center+1;px=h if (x+y)%2==0 else l
            dx=u[2*j]<px;py=h if dx else l;dy=u[2*j+1]<py
            x+=dx;y+=dy;lx+=u[2*j]<l;hx+=u[2*j]<h;ly+=u[2*j+1]<l;hy+=u[2*j+1]<h
            assert 3*lx-4*hy<=3*x-4*y<=3*hx-4*ly and 3*ly-4*hx<=3*y-4*x<=3*hy-4*lx
            inequalities+=2;nonzero_shift|=(px!=py)
        npaths+=1
    assert nonzero_shift
    return dict(paths=npaths,directed_prefix_checks=inequalities)


def double_tail(n,u):
    vmax=(1+float(L)**2)/4;vals=[]
    for j in range(100):
        lo,hi=vmax*j/100,vmax*(j+1)/100
        den=hi+float(L)*u/3;lam=u/den
        val=exp(-n*u*u/(2*den))
        if lo:val*=min(1,(1/(lam*sqrt(2*pi))+1.12*float(L))/sqrt(n*lo*exp(-lam*float(L))))
        vals.append(val)
    return max(vals)


def independent_cost(n,t,rows):
    from scipy.special import ndtr
    cuts=np.arange(-100,101)*.000005
    def S(z):return np.minimum(1,ndtr(-np.floor(100*z*np.sqrt(n/np.where(z>=0,.25,.239)))/100)+.56/sqrt(n*.239))
    sc=S(cuts);weights=np.r_[1-sc[0],-np.diff(sc),sc[-1]]
    of=np.array([0,.5,1])*(float(R)-1);Z=float(t+(1+L)*EPS)
    def direct(g,own,other,num):
        q=[S((v-own*cuts)/other) for v in g]
        f=1-(1-q[0])**num[0]*(1-q[1])**num[1]
        return f@weights[:-1]+weights[-1]
    for k,up in enumerate(rows):
        s=0.
        for idx,size in enumerate((J-k,k)):
            if not size:continue
            num=[J-k,k];num[idx]-=1;vals=[]
            for j in range(4):
                lo=of[idx]+j*(float(R)-1)/8;hi=lo+(float(R)-1)/8
                go=float(A*P)*(float(L)-1+float(L)*of[:2]-hi)-Z
                gi=float(A*P)*(float(L)-1+float(L)*lo-of[1:])-Z
                vals.append(min(1,direct(go,1,float(L),num)+direct(gi,float(L),1,num)))
            s+=size*max(vals)
        assert s<=float(F(up))+.000003 and float(F(up))-s<.002


def main():
    origin=json.loads((ROOT/'previous/ORIGIN-v09.json').read_text())
    for p,v in origin['files'].items():assert hashlib.sha256((ROOT/'previous'/p).read_bytes()).hexdigest()==v
    d=json.loads((ROOT/'records/certificate.json').read_text());ref=json.loads((ROOT/'previous/records/certificate.json').read_text())
    assert F(d['critical_epsilon'])==A*G/(2*(1+L))
    for r in d['sensitivity']:
        eps=F(r['ppm'],10**6);bias=(1+L)*eps;scale=A-2*bias/G
        n=[1000000*(F(x,1000000)/scale**2).__ceil__() for x in prior.NS]
        assert r['ns']==n
        f=sum(double_tail(nn,float(scale*t)) for nn,t in zip(n,prior.CLEAR))
        fail=0.
        for nn,t in zip(n,[-scale*h+2*bias for h in prior.HOLD]+[scale*prior.CLEAR[-1]+2*bias]):
            g=A*P*(L-1);w=A*P*(R-1);a,b,c=(double_tail(nn,float(g-off-t)) for off in (w,w/2,0))
            fail+=min(1,max(k*(J-k)*(a+c)+(k*(k-1)+(J-k)*(J-k-1))*b for k in range(J+1)))
        assert f<=float(F(r['false_go_upper']))+1e-13 and fail<=float(F(r['good_hold_upper']))+1e-13
        assert F(r['false_go_upper'])<=F(ref['false_go_upper']) and F(r['good_hold_upper'])<=F(ref['good_hold_upper'])
    for n,t,rec in zip(NS,CLEAR,d['endpoint_details']):independent_cost(n,t,rec['near_by_k'])
    assert int(d['good_expected_trials_upper'])==ceil(J*NS[0]+INCREMENTS[1]*F(d['active_upper'][0])+INCREMENTS[2]*min(map(F,d['active_upper'])))
    read=lambda name:json.loads((ROOT/'examples'/(name+'.json')).read_text())
    a,b,g,h=map(read,('after_first','after_middle','final_go','final_hold'))
    assert evaluate(a)['next_cells']==IDS[:3] and evaluate(b)['next_cells']==IDS[:2]
    assert evaluate(g,1157840)['geometry']==json.loads((ROOT/'previous/records/verification.json').read_text())['example_geometry']
    assert evaluate(h)['status']=='HOLD_COUNTS' and evaluate(g)['evaluated_attempts']==540000000
    for variant in ['field_worksheet','unsupported_180ppm']:assert evaluate(read(variant))['status']=='HOLD_ASSUMPTIONS'
    negative=0
    for k,v in [('gain_floor','.98'),('gain_ceiling','1.02'),('absolute_cell_error','-1/100'),('absolute_cell_error','21/1000000')]:
        q=deepcopy(g);q['drift_caps'][k]=v;assert evaluate(q)['status']=='HOLD_ASSUMPTIONS';negative+=1
    for k in D['additional_evidence']:
        q=deepcopy(g);del q['evidence'][k];assert evaluate(q)['status']=='HOLD_ASSUMPTIONS';negative+=1
    for typ in ('resurrect','extra_look','dup','old_id','negative','old_budget','changed_order','pending_science'):
        q=deepcopy(g);s=q['stages'][-1]['cells']
        if typ=='resurrect':s.append(dict(s[0],id=IDS[2]))
        if typ=='extra_look':q['stages'].append(q['stages'][-1])
        if typ=='dup':s[1]['id']=s[0]['id']
        if typ=='old_id':q['design_id']=prior.D['id']
        if typ=='negative':s[0]['detected']=-1
        if typ=='old_budget':s[0]['attempted']=prior.INCREMENTS[-1]
        if typ=='changed_order':q['stages'].reverse()
        if typ=='pending_science':q=a
        try:evaluate(q,1157840)
        except ValueError:negative+=1
        else:raise AssertionError(typ)
    world=d['identical_worlds'];assert F(world['bad_physical_contrast'])>F('1.002')
    for j in range(6):assert observed('alias_good_180',j)==observed('alias_bad_180',j)
    eps=F(20,10**6);s,d0,c=[prior.old.baseline.prior.DESIGN[k] for k in ('S','D','C')]
    hi,lo,*_=profile('unsafe_mask')[0];eta=F(1,1000);c=F(c)
    contrast=F(s)*F(d0)*c**2*hi/lo*(1-eta*(1-1/c))/(1+eta*(c-1));assert contrast>F('1.002')
    with np.load(ROOT/'records/counts.npz',allow_pickle=False) as archive:
        records=json.loads((ROOT/'records/pilot.json').read_text())
        assert set(archive)==set(unique_cases())
        for name in PLAN['cases']:audit(decode(archive,name),records[name])
    focus=json.loads((ROOT/'records/focus.json').read_text());m=focus['n'];k=focus['nominal_go']
    assert binom.sf(k-1,m,.01)<=float(F(focus['one_sided_p_upper']))+1e-15
    ci={}
    for key in ('nominal_go','robust_go'):
        x=focus[key];ci[key]=[f'{beta.ppf(.005,x,m-x+1):.7f}',f'{beta.ppf(.995,x+1,m-x):.7f}']
    return dict(status='PASS',inherited_files=len(origin['files']),paired_profile_records=PLAN['repetitions']*len(PLAN['cases']),
                independent_main_random_streams=len(unique_cases()),directed_risk_rows_checked=len(d['sensitivity']),
                endpoint_group_bounds_checked=2*17,robust_field_controls=negative,conditional_toy=tiny_coupling(),
                focus_nominal_p_scientific=f'{binom.sf(k-1,m,.01):.6e}',focus_99pct_binomial_intervals=ci,
                stress_true_physical_contrast=str(contrast),unmeasured_field='HOLD_ASSUMPTIONS')


if __name__=='__main__':print(json.dumps(main(),indent=2))
