# Eigenzeit v0.10 · Was kostet eine belastbare Driftreserve?

Der dreistufige Test vergleicht ein wissenschaftlich relevantes Zielprofil mit zeitlich schwankenden Kalibrierdaten. Ein gemeinsamer, von den Referenzzufällen unabhängiger Faktor darf zwischen 0,99 und 1,01 liegen. Zellabhängige bedingte Trefferwahrscheinlichkeiten dürfen je Gelegenheit um höchstens 20 ppm absolut vom so skalierten Ziel abweichen. Bei extern belegter Spanne und gültigen v0.5-Modellzusagen bleiben die öffentliche Fehlfreigabe- und HOLD-Garantie von v0.9 eingehalten. Der reale Feldstatus ist **HOLD**.

| Hauptplan | Wert |
|---|---:|
| Kumulative Versuche je noch aktiver Zelle | 29, 41, 61 Millionen |
| Gesamtaufwand erste Stufe / Maximum | 464 / 976 Millionen |
| Obergrenze des Erwartungswerts für jedes günstige Zielprofil | 546.942.262 |
| Wahrscheinlichkeit einer Fehlfreigabe bei physisch zu großem Kontrast | höchstens 0,93601 % |
| Günstige GO-Wahrscheinlichkeit | mindestens 99,7824 % |
| Unbedingte Überdeckung des Krümmungsintervalls einschließlich HOLD | mindestens 95,15 % |

Die günstige Klasse bezieht sich auf das **Ziel** (alle 16 Zellmittel mindestens 0,49, Verhältnis höchstens 1,0002). Der unbekannte gemeinsame Faktor muss nicht punktweise geschätzt werden. Seine extern begrenzte, für alle verglichenen Zellen gleich indizierte Folge ist Teil des Designs. Die individuelle Restabweichung darf von früheren Beobachtungen abhängen. 20 ppm sind 0,000020 auf der Wahrscheinlichkeitsskala und somit 0,002 Prozentpunkte. Ein Lauf mit scheinbar stabilen Zellmitteln liefert allein keinen Nachweis dafür.

## Dateien und Herkunft

- **Bericht.pdf** stellt Driftreserve, Kosten und Identifizierbarkeitsgrenze zusammen mit der Belastungsprobe dar.
- **BEWEIS.md** enthält den Koppelungsbeweis für vorhersehbare Zellabweichungen, die gerichteten Risiko- und Kostenschranken sowie zwei ununterscheidbare Kalibrierwelten.
- **drift_rule.py** ist der operative Feldprüfer. **drift_bounds.py** berechnet die rationalen Zertifikate. **design.json** enthält den primären 20-ppm-Entwurf und die vor der Simulation festgelegten Parameter.
- **records/certificate.json** umfasst die Hauptrechnung, die 17 Gruppenfälle je frühem Blick, das konkret konstruierte identische Beobachtungsgesetz und sechs zusätzliche bzw. wiederprüfende Tabellenzeilen für 0, 5, 20, 50, 100 und 150 ppm. Die Sensitivitätstabelle bestimmt kein nachträgliches Auswahlverfahren.
- **drift_pilot.py** erzeugt und wertet den gepaarten Pilot sowie den vorab definierten fokussierten Stresstest aus. **records/counts.npz** enthält sieben unterschiedliche Zählmatrizen, jede von der Form (6,8000,16). Gespeichert werden vorzeichenbehaftete little-endian int16-Abweichungen vom deterministischen ganzzahligen Offset floor(n·q), der für jede Stufe und Zelle in **offsets(name)** festgelegt ist. **decode** rekonstruiert die tatsächlichen ganzzahligen Trefferzahlen verlustfrei. Beim feedbackabhängigen sign_change bleibt der Speicher-Offset der feste Ausgangswert, unabhängig vom tatsächlich gewählten Vorzeichen. Die Rohdaten-Hashes beziehen sich auf die rekonstruierten uint32-Zählungen.
- **records/pilot.json** enthält acht Profilinterpretationen von je 8.000 gepaarten Durchläufen. Die beiden 180-ppm-Aliaswelten verwenden absichtlich **dieselbe** physische Zählmatrix. Somit entstehen 64.000 Profil-Durchläufe aus 56.000 eigenständig erzeugten Wiederholungen.
- **records/focus.json** enthält die 60.000 weiteren, unabhängig gesäten Wiederholungen des fokussierten Fehlfreigabetests in zwölf Batches, einschließlich gepaarter Entscheidungen, Kosten und Hash der vollständigen Zählmatrix je Batch. Die fokussierten Matrizen werden beim Befehl focus aus den Seeds neu erzeugt; sie sind nicht zusätzlich im NPZ abgelegt. Der einseitige Test bei α=0,01 betrifft nur die unveränderte v0.9-Zählregel und den vorab festgelegten Fall unsafe_mask.
- **verify.py** und **records/verification.json** prüfen die 64.000 gepaarten Profil-Durchläufe nochmals skalar, die sechs Risikobudgets und die gruppierten Kostenabschätzungen mit einer getrennten numerischen Rechnung sowie ein kleines exakt enumeriertes Modell mit vergangenheitsabhängiger Drift. Die zweiseitigen 99-%-Binomialintervalle im Prüfprotokoll beschreiben die simulierte Rate im jeweiligen Stressprofil. **records/environment.json** nennt die Softwarestände.
- **previous/** enthält bytegleiche Teile von v0.9 und dessen Vorgängerstufen; **previous/ORIGIN-v09.json** nennt den Quellarchiv-Hash, den Merge und die 56 übernommenen Dateien. **FREEZE.sha256** fixiert die Regeln, Seeds und Auswertungen lokal vor den neuen Beobachtungen. Das ist keine öffentliche Vorregistrierung. **MANIFEST.sha256** deckt alle übrigen Paketdateien ab.

## Anwendung

Am ersten Blick sind genau 29 Millionen Versuche in allen 16 Zellen zu erfassen. Der zweite Block enthält je 12 Millionen neue Versuche in den ausgegebenen Zellen, der dritte je 20 Millionen. Verglichen werden die kumulierten Trefferquoten. Unvollständige Zellmengen, nachträgliches Wiederaufnehmen einer Zelle, Wiederholen nach terminaler Entscheidung und die Verwendung der v0.9-Budgets werden abgelehnt.

```sh
python -B drift_rule.py examples/field_worksheet.json
python -B drift_rule.py examples/unsupported_180ppm.json
python -B drift_rule.py examples/after_first.json
python -B drift_rule.py examples/after_middle.json
python -B drift_rule.py examples/final_go.json --count 1157840
python -B drift_rule.py examples/final_hold.json --count 1157840
```

Zusätzlich zu den bisherigen externen Nachweisen werden Zielzeitraum und Transfertrennung, gemeinsame Verstärkungszuordnung und deren Begrenzung sowie die bedingte Restfehlerschranke verlangt. Im Feld drift_caps müssen die rationalen Zeichenketten gain_floor, gain_ceiling und absolute_cell_error angegeben und belegt sein. Engere Angaben sind möglich. Die freigegebene Feldregel bleibt stets dieselbe 20-ppm-Regel. Der Prüfer stellt weder Geräteparameter fest noch verifiziert er einen externen Nachweis inhaltlich. Die beiden synthetischen Fortsetzungen enden nach 540 Millionen Versuchen. Mit demselben Wissenschaftszähler bleibt bei GO nur h=1/2, bei HOLD bleiben h=0, 1/4 und 1/2 sowie das vollständige q-Intervall zulässig.

## Szenarien und Interpretation

Die gemeinsamen potentiellen Inkremente umfassen 22, 7, 2, 10, 5 und 15 Millionen je Zelle. Auf diesen identischen Chancen werden v0.9 bei 22/31/46 und v0.10 bei 29/41/61 Millionen geprüft. Die Kosten werden je Verfahren nach tatsächlicher Auswahl berechnet. Der Wert unter nominal bezeichnet die unveränderte Zählregel v0.9, welche ihre damalige Stabilitätsvoraussetzung nicht selbst überprüft.

- stable_50 hat durchgehend 50 % und keine Drift. good_widen verbreitert die wahren günstigen Randunterschiede mit ±20 ppm bei wechselndem gemeinsamem Faktor.
- unsafe_mask schöpft 20 ppm mit umgekehrtem Vorzeichen aus und verdeckt ein physisch unsicheres Ziel. In sign_change wechselt der gemeinsame Faktor; das Vorzeichen der späteren Restfehler hängt von der ersten C01-Zählung ab. In gain_only wechselt nur der gemeinsame Faktor. low_eff hat ein niedriges homogenes Ziel außerhalb der günstigen Klasse.
- alias_good_180 und alias_bad_180 stehen **außerhalb** der primären 20-ppm-Zusage. Ihre identischen rohen GO-Zahlen dienen ausschließlich dem Nachweis der Beobachtungsmehrdeutigkeit. Im 20-ppm-Feldprogramm muss die wahrheitsgemäße Angabe 180 ppm HOLD_ASSUMPTIONS ergeben. Eine solche Restunsicherheit lässt sich auch mit beliebig vielen Zellzählungen nicht auflösen.

## Reproduktion

Im entpackten Verzeichnis. Rechnerisch ungünstige und günstige Szenarien sind im Paket enthalten. Python 3.12 und die Versionen aus records/environment.json wurden verwendet. Die mathematische Hauptzertifizierung verwendet ganze und rationale Zahlen.

```sh
sha256sum -c MANIFEST.sha256
sha256sum -c FREEZE.sha256
python -B drift_bounds.py > /tmp/x6-v010-cert.json
cmp records/certificate.json /tmp/x6-v010-cert.json
python -B drift_pilot.py score records/counts.npz > /tmp/x6-v010-score.json
cmp records/pilot.json /tmp/x6-v010-score.json
python -B drift_pilot.py replay records/counts.npz > /tmp/x6-v010-replay.json
cmp records/pilot.json /tmp/x6-v010-replay.json
python -B drift_pilot.py focus > /tmp/x6-v010-focus.json
cmp records/focus.json /tmp/x6-v010-focus.json
python -B verify.py > /tmp/x6-v010-checks.json
cmp records/verification.json /tmp/x6-v010-checks.json
```
