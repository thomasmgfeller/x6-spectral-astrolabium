# Eigenzeit: Einstieg in 3+1 Dimensionen, v0.1

Datum: 27. Oktober 2026. Interpretation: drei Raumdimensionen und eine Zeitdimension.
Status: **PASS_EXACT_ALGEBRA_ONLY**. Ein ausführbarer exakter Geometrietest,
keine neue statistische oder physikalische Freigabe. Kein Neuheitsanspruch.

## Ausgangslage aus den heute gelesenen Quellen

Der bestehende lokale d'Alembertian-Pilot des X6-Projekts arbeitet in 2+1
Minkowski-Dimensionen. Die neueren Zähl- und Landmarkentests haben die
wissenschaftlichen HOLDs nicht aufgehoben. PR #122 ist am Abrufdatum ein
offener Draft; seine 38 verbleibenden Zellen betreffen einen festgelegten
dreidimensionalen Bewegungsparameterwürfel in **2+1 Raumzeit**. Drei
Suchparameter sind keine drei Raumdimensionen. Der Ausschluss von
99,072265625 % dieses Parametervolumens ist keine Erfolgswahrscheinlichkeit.

Die GFEST-Ergänzung v0.2 ist ein lokales Zertifikat unter expliziten
Voraussetzungen; sie schliesst weder diese 38 Zellen noch den allgemeinen
Stabilitätsclaim. Der 3+1-Einstieg wird separat bewertet. Gelesene Inhalte,
GitHub-Datei-SHAs und der PR-Head sind in `source_snapshot.json` festgehalten.

## Ziel dieses ersten Schritts

Aus exakten, vorzeichenbehafteten Intervallquadraten einen vierdimensionalen
Landmarkenrahmen und die Eigenzeit zwischen Stützpunkten rekonstruieren.
Dabei einen echten Informationsverlust erkennen, der beim blossen Einbetten
der alten Landmarken in z=0 entsteht.

Es gelten c=1, eta=diag(-1,1,1,1) und

    s(u,v) = -(t_u-t_v)^2 + (x_u-x_v)^2 + (y_u-y_v)^2 + (z_u-z_v)^2.

Für zeitartige Paare ist tau(u,v)^2=-s(u,v). Die Skala ist in diesem Test
bekannt. Aus einer blossen Kausalordnung folgt keine absolute Zeiteinheit.

## Exakter Gegenfall für vier Landmarken

Alle Koordinaten stehen in der Reihenfolge (t,x,y,z):

| Ereignis | Koordinaten |
|---|---|
| a0 | (-8, 0, 0, 0) |
| a1 | (-6, 1, 0, 0) |
| a2 | (-4, 0, 1, 0) |
| a3 | (-2, 0, 0, 0) |
| p | (1, 1/4, 1/4, 1/4) |
| q+ | (2, -1/4, 1/4, 1/4) |
| q- | (2, -1/4, 1/4, -1/4) |

Verglichen werden zwei Konfigurationen: (a0,a1,a2,a3,p,q+) und
(a0,a1,a2,a3,p,q-). Alle Landmarken haben z=0. Daher geht die z-Koordinate
jedes Stützpunkts in seine Landmarkenabstände nur quadratisch ein.

Die vier Werte s(ai,q+) und s(ai,q-) stimmen exakt überein:

    (-1597/16, -997/16, -565/16, -253/16).

Auch die beschriftete Kausalordnung beider Sechs-Ereignis-Konfigurationen
stimmt überein: a0 < a1 < a2 < a3 < p < q, jeweils streng zeitartig.
Trotzdem gilt

    tau(p,q+)^2 = 3/4,     tau(p,q-)^2 = 1/2.

Die Eigenzeiten sind sqrt(3)/2 und 1/sqrt(2). Ihr Verhältnis beträgt
sqrt(3/2). Die Fälle sind nicht bloss zwei globale Koordinatendarstellungen
derselben beschrifteten Geometrie, denn ihr invariantes Intervall p-q ist
unterschiedlich.

**Geltungsbereich des Gegenfalls:** Er betrifft die Beobachtungsmaske aus
Landmarkenabständen und Ordnung der ausgewählten Ereignisse. Bei gleicher
bekannter Dichte liefern die identischen zeitartigen Landmarkenintervalle
auch identische einzelne Poisson-Zählmittelwerte. Es wird ausdrücklich keine
Gleichheit der gemeinsamen Zählgesetze behauptet: Überlappungen können
Information liefern. Eine zusätzliche direkte Messung des p-q-Intervalls
würde die Fälle ebenfalls unterscheiden. Damit ist kein Gegenbeweis zum
vollständigen GFEST-Beobachtungsmodell und keine 10%-Unmöglichkeitsgrenze
bewiesen.

## Fünf Landmarken als ausreichender affiner Rahmen

Ergänze a4=(0,0,0,1). Dann unterscheiden sich bereits die beiden Abstände

    s(a4,q+)=-53/16,      s(a4,q-)=-37/16.

Alle in den beiden Sieben-Ereignis-Konfigurationen benötigten Paare sind
streng zeitartig. Die fünf Landmarken sind affin unabhängig.

Für fünf Landmarken a0,...,a4 setze ei=ai-a0, i=1,...,4. Aus den
Landmarkenintervallen allein folgt die Gram-Matrix

    G_ij = (s(a0,ai) + s(a0,aj) - s(ai,aj))/2.

Für einen Stützpunkt p erhält man ebenso

    b_i(p) = (s(a0,ai) + s(a0,p) - s(ai,p))/2.

Schreibe p-a0=E c(p), wobei E die ei als Spalten enthält. Aus G=E^T eta E
und b=E^T eta(p-a0) folgt bei invertierbarem E:

    c(p)=G^(-1)b(p),
    s(p,q)=(c(p)-c(q))^T G (c(p)-c(q)).

Damit ist die Rekonstruktion im affinen Landmarkenrahmen eindeutig.
Zusätzlich muss die Konsistenzgleichung

    s(a0,p) = b(p)^T G^(-1)b(p)

gelten. In verrauschten Daten ist ihr Residuum ein zu kalibrierendes
Diagnosemerkmal, keine nachträglich wegzudefinierende Abweichung.

Im Beispiel sind det(E)=6 und det(G)=-36. Die explizit geprüfte Kongruenz
G=E^T eta E und die Invertierbarkeit von E zeigen genau eine negative und
drei positive Richtungen. Eine negative Determinante allein würde diese
Signatur in vier Dimensionen nicht beweisen.

Vier Landmarken liefern höchstens drei affine Differenzvektoren. Fünf affin
unabhängige Landmarken sind für diese lineare Rekonstruktion ein
ausreichender vollständiger Rahmen. Das ist keine Behauptung, dass jede
andere Rekonstruktionsmethode zwingend fünf Landmarken benötigt: zusätzliche
Abstände, Überlappungen oder Modellannahmen können fehlende Information
ersetzen. Ebenso ist ein invertierbarer Rahmen noch kein stabiler Rahmen.

## Ausgeführte Kontrollen

`verify_4d.py` verwendet ausschliesslich die Python-Standardbibliothek und
exakte rationale Arithmetik (`fractions.Fraction`). Keine Rundungstoleranzen
gehen in die Entscheidungen ein.

- Exakte Gleichheit der vier Landmarkenabstände und der Kausalordnungen.
- Exakte Ungleichheit der gesuchten Eigenzeitquadrate.
- Rekonstruktion aus Intervallmatrizen für alle 120 Landmarkenpermutationen,
  jeweils für beide Konfigurationen; alle Konsistenzresiduen sind null.
- Invarianz unter einem rationalen, zeitorientierungserhaltenden Lorentz-Boost
  mit gamma=5/3 und gamma*beta=4/3, kombiniert mit einer Translation.
- Ablehnung eines singulären Fünf-Landmarkenrahmens als Negativkontrolle.
- Annäherung a4=(0,0,0,epsilon) an den alten Unterraum mit
  det(G)=-36 epsilon^2 für epsilon=1,1/2,1/4,1/8,0.

Ergebnis: **619 exakte Prüfaussagen bestanden**, Python 3.12.14.
Das sind algebraische Kontrollen desselben konstruierten Beispiels, keine
619 unabhängigen Experimente und keine externe Replikation. Der
Determinantentest belegt die Singularität bei epsilon=0; er ersetzt keine
skalierungsbereinigte Konditions- oder statistische Fehleranalyse.

Reproduktion im entpackten Verzeichnis:

```sh
python3 verify_4d.py > replay.json
```

`results.json` enthält das ausgeführte Ergebnis. Bei anderer Python-Version
kann sich das Metadatenfeld `python` unterscheiden. Die übrigen Resultate
sollten exakt übereinstimmen. Keine Zusatzbibliotheken sind erforderlich.

## Nächster 3+1-Prüfblock — noch nicht ausgeführt

1. **Geometrie und Dimensionsdiagnose.** Den bestehenden 4D-Sprinkler und
   seine radiale Verteilung prüfen; nach Dimension getrennte Referenzen
   führen. Für einen flachen 4D-Alexandrov-Diamanten gilt
   V4(tau)=pi*tau^4/24. Der Myrheim-Meyer-Referenzwert für den Anteil
   vergleichbarer ungeordneter Paare ist 1/10. Diese Statistik allein belegt
   weder eine vierdimensionale Mannigfaltigkeit noch eine richtige Metrik.
   Paarindikatoren sind abhängig; keine binomiale Standardfehlerformel für
   alle Paare verwenden. [S1]

2. **Landmarkenauswahl und endliche Zählungen.** Fünf Ereignisse allein aus
   zulässigen Kausal- und Zählinformationen auswählen. Mit exakten Intervallen
   als separatem Diagnosearm beginnen; danach dieselbe Konstruktion unter
   endlichen korrelierten Poisson-Zählungen prüfen. Im flachen Modell mit
   bekannter rho wäre der naive Plug-in-Wert
   tau_hat=(24N/(pi*rho))^(1/4). Seine Verzerrung und Unsicherheit sind zu
   kalibrieren. Überlappende Intervalle dürfen nicht als unabhängige Poisson-
   Beobachtungen behandelt werden. Entwicklungs- und Prüfgeometrien trennen;
   gegebenenfalls unabhängige Poisson-Färbungen für Auswahl und Zählung mit
   den entsprechend reduzierten Dichten verwenden. Rangunsicherheit,
   Signatur, Verfügbarkeit, Ausfälle und alle Stützpunktordnungen ausweisen.

3. **Eigenzeit und Operator getrennt bewerten.** Zuerst die Eigenzeiten
   zwischen zurückgehaltenen Stützpunkten prüfen. Anschliessend alle zehn
   unabhängigen Komponenten einer symmetrischen 4x4-Metrik über unabhängige
   Feldantworten prüfen. Für Box=-d_t^2+d_x^2+d_y^2+d_z^2 lauten die
   quadratischen Sollwerte Box(t^2)=-2, Box(x^2)=Box(y^2)=Box(z^2)=2;
   alle sechs gemischten Quadrate haben Antwort null. Konstanten und affine
   Felder ergänzen den Test. Auf Kalibrierfelder erzwungene Momente zählen
   nicht als unabhängige Validierung. Glatte zurückgehaltene Felder sowie
   diskrete Produktidentitäten sind gesondert auszuwerten.

4. **Stabilität, Rand und Krümmung.** Die lokalen 3+1-Fehlerfortpflanzungen
   und gemeinsamen Zählgesetze untersuchen. Dichte, physikalischen
   Nachbarschaftsradius und äusseres Fenster separat verändern. Erst nach
   bestandener flacher Referenz einen gekrümmten Benchmark eröffnen. Die
   BK-Arbeit demonstriert ihren numerischen Operatorversuch in 2+1; ihre
   4D-Kettenkonstantenprüfung hat eigene Rechenbudgetgrenzen. [S2] Ein neuer
   Preprint untersucht zudem Randverzerrungen bei Linkstatistiken, die durch
   reine Dichteerhöhung nicht verschwinden müssen. Das ist eine relevante
   Prüfspur, keine bewiesene Erklärung unserer bisherigen 4D-Auffälligkeit. [S3]

Für diese Folgeversuche sind Budget, Zielgrössen, Fehlerschwellen, Seeds und
Ausfallbehandlung vor den Testläufen festzulegen. Dieses Paket friert noch
keine Monte-Carlo-Kampagne ein und enthält keine neue Poisson-Simulation,
keine Operatorimplementierung und keine globale Stabilitätsfreigabe.

## Quellen und Bezug zum Repository

- [S1] S. Surya, *The causal set approach to quantum gravity*, Living Reviews
  in Relativity (2019), Abschnitt 4.1, Gleichungen 14–18:
  https://arxiv.org/html/1903.11544v2
- [S2] M. Boguñá, D. Krioukov, *Local d'Alembertian for causal sets*,
  Phys. Rev. D 113, 024046 (2026); Abschnitte IV.6 und Anhang A:
  https://arxiv.org/html/2506.18745v1
- [S3] M. Boguñá, D. Krioukov, *Sampling biases in sprinkled causal sets*,
  Preprint vom 2. Oktober 2026:
  https://arxiv.org/html/2610.03247v1
- X6, bestehender lokaler Operator-Pilot und Folgeprüfungen:
  https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/main/research/lorentz_local_dalembert
- GFEST-Veröffentlichungsstand:
  https://github.com/thomasmgfeller/x6-spectral-astrolabium/tree/main/docs/research/eigenzeit/gfest
- PR #122:
  https://github.com/thomasmgfeller/x6-spectral-astrolabium/pull/122

Die Herleitung und das rationale Beispiel oben sind eine hier ausgeführte
elementare Minkowski-Geometrieprüfung. Die Literaturquellen dienen der
Einordnung und der nächsten Prüfplanung, nicht als externe Bestätigung
dieses konkreten Rechenlaufs.
